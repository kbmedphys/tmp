# StataコードとPython実装の対応

元ファイルは `source_code/` と元ZIPに保持。ファイルのハッシュは `results/source_manifest.json` を参照。

| Stataの処理 | Python実装 | 検証 |
|---|---|---|
| 4式の変数・ラグ列挙 | `equation_specs` / `design` | 米国の全係数を照合 |
| `constraint define` / `cnsreg` | `restricted_fit`：制約の零空間内OLS | 係数、p値、制約誤差 |
| `test`：係数和・各ラグの同時検定 | `wald_test` / `coefficient_summaries` | 係数和p値・joint p値 |
| 無制約 `reg` 後の同次性検定 | `restricted_fit` 内の無制約OLS | 同梱p値と照合 |
| `corr y fitted` の二乗 | `r2_corr` | 配布R2とfloat32許容誤差内 |
| コロナ前／全期間 | `fit_system(end=...)` | 米国120／134観測 |
| `chow test.do` のRSS差の式 | `package_chow` | 原式・固定パラメータ数を明示 |
| 日本期待が非公開・欠損 | `japan_panel`：CIEへ明示的に代替 | 元期待列を復元したとは扱わない |
| 日本価格方程式の生産性除外 | `price_productivity=False` | 表2の係数和を小数点3桁で照合 |
| 動学応答・歴史分解 | `compile_system` / `simulate` / `historical_decomposition` | 新規実装。初期＋全寄与＝実績、当期商品応答の照合 |

## 該当する一般回帰コマンドと行番号

日本は元コードの国別ループに入っていないため、下記一般仕様を日本データへ適用する。ドイツ・ベルギー等の別仕様は移植対象としない。元コードの変更ではなく、Python側に日本の設定を追加している。

| 元ファイル | 行 | コマンド |
|---|---:|---|
| `(1) gw.do` | 43 | `cnsreg gw_`c' l1.gw_`c' l2.gw_`c' l3.gw_`c' l4.gw_`c' l1.cf1_`c' l2.cf1_`c' l3.cf1_`c' l4.cf1_`c' l1.magpty_`c' l1.vu_`c' l2.vu_`c' l3.vu_`c' l4.vu_`c' l1.diffcpicf_`c' l2.diffcpicf_`c' l3.diffcpicf_`c' l4.diffcpicf_`c' if inrange(period, tq(`startperiod_`c''),tq(2019:4)), c(1)` |
| `(1) gw.do` | 399 | `cnsreg gw_`c' l1.gw_`c' l2.gw_`c' l3.gw_`c' l4.gw_`c' l1.cf1_`c' l2.cf1_`c' l3.cf1_`c' l4.cf1_`c' l1.magpty_`c' l1.vu_`c' l2.vu_`c' l3.vu_`c' l4.vu_`c' l1.diffcpicf_`c' l2.diffcpicf_`c' l3.diffcpicf_`c' l4.diffcpicf_`c' dummyq2_2020 dummyq3_2020 if inrange(period, tq(`startperiod_`c''),tq(2023:2)), c(1)` |
| `(1) gw.do` | 533 | `cnsreg gw_`c' l1.gw_`c' l2.gw_`c' l3.gw_`c' l4.gw_`c' l1.cf1_`c' l2.cf1_`c' l3.cf1_`c' l4.cf1_`c' `m_`c'' l1.vu_`c' l2.vu_`c' l3.vu_`c' l4.vu_`c' l1.diffcpicf_`c' l2.diffcpicf_`c' l3.diffcpicf_`c' l4.diffcpicf_`c' if inrange(period, tq(`startperiod_`c''),tq(2023:2)), c(1)` |
| `(2) gcpi.do` | 42 | `cnsreg gcpi_`c' magpty_`c' l1.gcpi_`c' l2.gcpi_`c' l3.gcpi_`c' l4.gcpi_`c' gw_`c' l1.gw_`c' l2.gw_`c' l3.gw_`c' l4.gw_`c' grpe_`c' l1.grpe_`c' l2.grpe_`c' l3.grpe_`c' l4.grpe_`c' grpf_`c' l1.grpf_`c' l2.grpf_`c' l3.grpf_`c' l4.grpf_`c' shortage_`c' l1.shortage_`c' l2.shortage_`c' l3.shortage_`c' l4.shortage_`c' if inrange(period, tq(`startperiod_`c''),tq(2019:4)), c(2)` |
| `(2) gcpi.do` | 187 | `cnsreg gcpi_`c' magpty_`c' l1.gcpi_`c' l2.gcpi_`c' l3.gcpi_`c' l4.gcpi_`c' gw_`c' l1.gw_`c' l2.gw_`c' l3.gw_`c' l4.gw_`c' grpe_`c' l1.grpe_`c' l2.grpe_`c' l3.grpe_`c' l4.grpe_`c' grpf_`c' l1.grpf_`c' l2.grpf_`c' l3.grpf_`c' l4.grpf_`c' shortage_`c' l1.shortage_`c' l2.shortage_`c' l3.shortage_`c' l4.shortage_`c' if inrange(period, tq(`startperiod_`c''),tq(2023:2)), c(2)` |
| `(3) cf1.do` | 42 | `cnsreg cf1_`c' l1.cf1_`c' l2.cf1_`c' l3.cf1_`c' l4.cf1_`c' cf10_`c' l1.cf10_`c' l2.cf10_`c' l3.cf10_`c' l4.cf10_`c' gcpi_`c' l1.gcpi_`c' l2.gcpi_`c' l3.gcpi_`c' l4.gcpi_`c' if inrange(period, tq(`startperiod_`c''),tq(2019:4)), c(3) noconstant` |
| `(3) cf1.do` | 159 | `cnsreg cf1_`c' l1.cf1_`c' l2.cf1_`c' l3.cf1_`c' l4.cf1_`c' cf10_`c' l1.cf10_`c' l2.cf10_`c' l3.cf10_`c' l4.cf10_`c' gcpi_`c' l1.gcpi_`c' l2.gcpi_`c' l3.gcpi_`c' l4.gcpi_`c' if inrange(period, tq(`startperiod_`c''),tq(2023:2)), c(3) noconstant` |
| `(4) cf10.do` | 42 | `cnsreg cf10_`c' l1.cf10_`c' l2.cf10_`c' l3.cf10_`c' l4.cf10_`c' gcpi_`c' l1.gcpi_`c' l2.gcpi_`c' l3.gcpi_`c' l4.gcpi_`c' if inrange(period, tq(`startperiod_`c'':1),tq(2019:4)), c(4) noconstant ` |
| `(4) cf10.do` | 148 | `cnsreg cf10_`c' l1.cf10_`c' l2.cf10_`c' l3.cf10_`c' l4.cf10_`c' gcpi_`c' l1.gcpi_`c' l2.gcpi_`c' l3.gcpi_`c' l4.gcpi_`c' if inrange(period, tq(`startperiod_`c'':1),tq(2023:2)), c(4) noconstant` |

## 仕様差の明示

価格式の生産性は `gcpi.do` に合わせた当期値。国際比較論文付録の図式と一部ラグ表記が異なるが、Python移植ではコードを優先した。

日本CIEのcatch-upは日本論文の式(5)で新たに算出。米国の移植検証では、配布済みのcatch-up列を変えない。

Stataで `gen` によってfloat32に格納された係数和・R2は、保存ファイルとfloat64計算結果に約1e-8程度の差があり得る。出力係数（double）とp値は1e-9の許容差で照合している。

動学分解の基準経路（開始期、V/U基準、平均の計算窓）は `results/decomposition_settings_and_checks.json` に完全に保存した。原日本チームの非公開シミュレーターの初期化を推測・校正して一致させてはいない。
