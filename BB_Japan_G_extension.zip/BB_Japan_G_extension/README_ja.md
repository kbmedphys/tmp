# 日本BBモデル：政府消費＋一般政府投資の1系列拡張

## 利用方法

ZIPを展開し、このフォルダを作業ディレクトリにして `main.ipynb` を先頭から実行してください。Pythonコードはすべてノートブック内にあり、別の.pyファイルもネットワークアクセスも不要です。全セル実行済みです。

既存のuvプロジェクトで必要な依存を追加する例:

```bash
uv add numpy pandas scipy matplotlib ipykernel nbformat nbclient nbconvert
```

VS Code/Jupyterでは対象のuv環境をカーネルに指定してください。カレントディレクトリが異なる場合は、設定セルの `PROJECT_DIR` を変更します。

主仕様: `M0_common` 対 `MG_total`、1997Q3～2023Q2の104四半期。賃金には政府指標の1～5期、物価には当期～5期を追加します。1系列のままで、政府消費・投資の分解は今回行いません。

## 主結果

通常検定の共同p値は賃金0.5345、物価0.7558。HAC(8)でも主仕様は有意ではありません。修正済みR²・BICは改善しません。2023Q2の物価への政府指標の寄与は約+0.0138ポイント、点別95%区間は約[-0.3070,+0.3346]です。これは未収録の税・給付・補助金等を含む財政政策全体の効果ではありません。

一部の短い標本・HACの検定では有意となるため、すべての仕様で効果ゼロとは結論しません。主共通標本では賃金同次性制約も通常検定で棄却されます。詳細は `results/RESULTS_ja.md` と `results_view.html` を参照してください。

## 入力と追跡可能性

- `inputs/japan_model_input.csv`: 前回の基本BB実装の加工済みパネル。PIIE日本系列＋公開CIE。
- `inputs/expenditure_core_quarterly_candidates.csv`: 財政データ構築v2の作成済み部分指標。そのまま使用。
- `inputs/expenditure_benchmark_gaps_annual_fy.csv`: 四半期指標の年次参照用。
- `inputs/reference_basic_coefficients.csv`: 以前の基本BB推定との数値検査用。
- `source_code/`: 基となった配布Stataコード（元の日本用コードではありません）。
- `audit/`: 既存の実装・財政構築の方法説明と関数の出所。

政府指標は `core_gap_annualized_pct_prev_fy_gdp` を使用し、原CSVの値は書き換えません。`full_dm_ready=False` は維持し、部分C+I代理指標としてのみ利用します。

## 結果

`main_comparison.csv` が主比較、`fiscal_coefficients.csv` が財政項の検定、`fiscal_pointwise_intervals.csv` が共同HAC/deltaの区間です。後者は固定した生成系列を条件とする漸近近似で、bootstrapでも同時信頼帯でもありません。

`history_*.csv` は各方程式の歴史分解です。初期条件・各外生寄与・4式の残差寄与が含まれます。`equation_residuals` は4つの残差寄与の合計であり、両方を足すと二重計上になる点に注意してください。`actual`、`reconstructed`、`conditional_no_residual`は寄与項ではありません。

`conditional_evaluation.csv` はコロナ前係数を用いた2020Q1以降の条件付き評価です。実際の当期説明変数または実際の外生経路を利用しており、固定ビンテージのため厳密なリアルタイム予測ではありません。

`irfs.csv`の`expansion_pulse_minus1`は年率換算した支出乖離指標を1期だけ−1ポイント動かす仮定。実際の予算支出1%GDPの外生ショックではありません。

## 出所

Bernanke & Blanchard (2024), PIIE WP24-11; Bonam, Cerra Pacheco & Checherita-Westphal (2025), ECB WP3153; Nakamura et al. (2024), BOJ WP24-E-1; 利用者アップロードのSNA・日銀潜在成長率と財政構築v2。

（出所）長田・中澤（2024）、日本銀行、Bloomberg、QUICK月次調査＜債券＞、Consensus Economics「コンセンサス・フォーキャスト」。CIEの2006年以前は参考値です。
