# Layer A Notebook-only 実装

- `main_layer_a.ipynb`: Layer A本体。LSEG cache/API、baseline/full、可視化、Layer C用parquet保存。
- `test_layer_a.ipynb`: サンプルニュースによる単体テスト。
- `config_layer_a.yaml`: LSEG取得規模、baseline/full/compare、表示設定。

## 推奨開始設定

```yaml
run:
  mode: baseline
lseg:
  enable_fetch: false
  cache_only: true
```

LSEG接続確認時は `query_scale: tiny`, `enable_fetch: true`, `cache_only: false` から開始してください。
