# 日本の基本BBモデル — Python追試

## 開始するファイル

`main.ipynb` は実行済みです。結果だけを見る場合は `results_view.html` をブラウザで開いてください。要点は `results/RESULTS_ja.md` にあります。

## フォルダ構成

```text
BB_Japan_replication/
  main.ipynb                  全Pythonコード・説明・実行結果
  results_view.html           コード非表示の閲覧用HTML（図は埋込済み）
  README_ja.md                この文書
  IMPLEMENTATION_MAP.md       StataコードとPythonの対応
  pyproject.toml              uv用の依存指定
  inputs/
    wp24-11.zip               ユーザー提供のPIIEパッケージ（改変なし）
    rev24j05.zip               ユーザー提供の日銀CIE（改変なし）
  source_code/                元Stata .doファイルの改変しないコピー
  results/
    RESULTS_ja.md             自動生成した実行結果メモ
    main_coefficient_sums.csv 主仕様の係数和・F検定
    main_fit_metrics.csv      主仕様の期間・適合度
    all_coefficients.csv      全仕様の個別係数・標準誤差・係数CI
    validation_usa_detail.csv 米国8回帰の256項目照合
    estimated_models.json    全モデルの係数・共分散
    history_*.csv             4変数の歴史分解
    irfs.csv                  動学応答（点推定）
    figures/                  13点のPNG
    ...                       データ、診断、感応度、設定、ハッシュ等
```

全解析を1つのNotebookに収めており、別の `.py` のimportはありません。入力ファイルはNotebookと同じフォルダ内の `inputs/` を参照します。

## 再実行

ZIPを展開し、このフォルダを作業ディレクトリにしてください。既存のuvプロジェクトを使う場合：

```bash
uv add numpy pandas scipy matplotlib ipykernel nbformat nbclient nbconvert
```

このフォルダを独立プロジェクトとして利用する場合は、添付の `pyproject.toml` に従って `uv sync` で環境を作成できます。テストに用いた実バージョンは `results/environment_versions.json` に保存しています。環境のネットワーク制限・社内ミラーの収録状況は別途確認が必要です。

VS Code/Jupyterで対応するuv環境のカーネルを選び、`main.ipynb` を上から実行します。カレントディレクトリが異なる場合は、最初の設定セルの `PROJECT_DIR` を修正してください。Notebook自体は外部ネットワークへアクセスせず、手元の2つのZIPだけを使います。

この追試は2023Q2までの配布データを対象にしています。年率化・季節調整・CIE主成分推定を再び行うものではありません。

## モデル

- **M0_package_full**：配布一般仕様を日本の集計賃金に適用。価格方程式に当期生産性、賃金方程式に生産性1期ラグと2020Q2/Q3の2ダミー。期待は日銀CIEの1年後・10年後。賃金・物価117観測、期待123観測。
- **M0_JPprice_full**：価格方程式から生産性を除く比較仕様。日本原論文の価格表と照合。FT/PT拡張ではありません。
- コロナ前、共通標本、2007年以降、2009年以降（初期参考期待のラグを排除）、5年期待も追加比較。

Stata `cnsreg` に対応する制約付きOLS、通常の共分散、F検定、無制約OLSからの同次性検定を実装しました。HAC(4)は追加診断です。配布 `chow test.do` の式も別名で保存しますが、一般的な頑健構造変化検定とはみなしません。

## 主要な検証

1. 米国4式×2標本の係数・p値・R2・観測数・同次性検定など256項目を同梱Excelと照合。
2. 日本の生産性除外価格式：5係数和とR2が論文表示の小数点3桁で一致。
3. 同価格式の商品ショック当期応答が、配布された日本のIRF数値と一致。
4. 歴史分解：初期条件＋外生寄与＋ダミー＋4式残差の寄与＝実績を数値検査。
5. 入力ZIPと元StataコードのSHA-256を保存。

ただし、日本の非公開期待指標と今回の公開CIEが同じであるとは確認できません。そのため、日本全体については公開代理系列による再推定です。期待式・賃金式や全動学の数値的一致は主張しません。

## 歴史分解・IRFの位置付け

これらの生成コードはPIIEパッケージに収録されていないため、論文式から新規実装しています。最大8期の内生履歴を使い、当期の再帰順序は賃金→物価→長期期待→短期期待です。

食品・エネルギーの相対価格上昇率は外生入力として固定します。財政拡張論文の名目商品価格経路と賃金分母を内生更新する仕様は、この基本BBの追試には混ぜていません。

歴史分解は2020Q1開始、2019Q4を初期基準にします。供給不足・生産性の基準は1990Q1～2019Q4の非欠損値平均。相対価格上昇率をゼロ、V/Uを2019Q4の水準にする反実仮想との差です。残差寄与は直交化していません。

応答・歴史寄与は点推定です。それらの信頼区間、CIEの生成不確実性を含む推論、リアルタイム予測評価は未実施です。高いR2と残差込みの再構成一致は、因果識別や完全な歴史説明を保証しません。

価格生産性の推定係数は主仕様で正です。これを純粋な生産性ショックによる価格上昇と解釈せず、符号問題として明示し、生産性除外との比較に利用します。また、労働需給の賃金係数は長期標本と2007/2009年以降の標本で有意性が異なります。

## データの注意

CIEは元ExcelのB列（1年後）とK列（10年後）。L列の予測力ベース3年先は使用しません。C18は2年後の1991Q1欠損セルで、今回の入力には使いません。2006年以前のCIEは参考値です。四半期初日というExcel日付は公表日ではありません。

原入力を維持し、#N/Aをゼロ置換せず、catch-upを全履歴から計算してから標本を選択しています。PIIEは2023Q2までなので、CIEが2024Q1まで存在してもモデル全体の終了期は延ばしていません。

## 出典

Bernanke and Blanchard (2024), *An Analysis of Pandemic-Era Inflation in 11 Economies*, PIIE WP24-11、添付のReplication package_v3。

Nakamura, Nakano, Osada and Yamamoto (2024), *What Caused the Pandemic-Era Inflation?: Application of the Bernanke-Blanchard Model to Japan*, BOJ WP24-E-1、式(1)–(5)、表2。

**（出所）長田・中澤（2024）、日本銀行、Bloomberg、QUICK月次調査＜債券＞、Consensus Economics「コンセンサス・フォーキャスト」**

元ファイルの利用条件は原資料に従ってください。
