# ドキュメント要約依頼

**User:** Anonymous (kencharoffx@gmail.com)  
**Created:** 2/18/2026 20:21:55  
**Updated:** 2/18/2026 21:18:40  
**Exported:** 2/18/2026 22:04:50  
**Link:** [https://chatgpt.com/c/6995a09d-2c3c-83a8-86a1-b5e952235ba3](https://chatgpt.com/c/6995a09d-2c3c-83a8-86a1-b5e952235ba3)  

## Prompt:
Bootstrap rolling-window Granger causality dynamics between momentum and sentiment.pdf

PDF

Comomentum.pdf

PDF

Design and analysis of momentum trading strategies.pdf

PDF

Momentum Strategies Across Asset Classes.pdf

PDF

Parametric portfolio policy with momentum-based sentiment trading strategy.pdf

PDF

Short-term Momentum.pdf

PDF

Understanding Momentum and Reversals.pdf

PDF

添付したドキュメントについてそれぞれ内容を要約してください。内容を再現できるよう要点を詳細に解説してください

## Response:
思考時間: 43s

以下、**添付7本**について「何を主張し、どう再現できるか」を**実装できる粒度**で整理します（各論文ごとに：目的→データ→手法→再現手順→結果の読み方）。引用は添付PDFの該当箇所です。

* * *

1) Understanding Momentum and Reversal（Kelly, Moskowitz, Pruitt, 2021 preprint）
-------------------------------------------------------------------------------

### 目的（何を言いに行っているか）

*   **モメンタム／長期リバーサル等の“過去リターン特性”は、将来のベータ（実現β）を予測する** → つまりこれらは「行動バイアス」だけでなく、\*\*条件付きリスク補償（time-varying risk compensation）\*\*と整合的、という立て付け。
    Understanding Momentum and Reve…
*   その上で、**条件付きファクターモデル**（βが特性で動く）を推定し、従来の静学FFモデルで説明できないモメンタムをどこまで説明できるかを検証。
    Understanding Momentum and Reve…

### データ（再現に必要な入力）

*   1966–2014、銘柄リターン＋**Freyberger et al. (2020) の36特性**（論文内のKPSデータセット）を使用、各特性は**クロスセクション順位→\[−0.5,0.5\]にスケール**。
    Understanding Momentum and Reve…
*   実現βは**日次リターン**から月次/四半期/半年/年のOLSβとして構成。
    Understanding Momentum and Reve…

### 手法（数式・推定）

*   基本の条件付きファクター価格付け：
    $$
    r_{i,t+1}=\beta_{i,t}' f_{t+1}+\varepsilon_{i,t+1},\quad \mathbb{E}_t[r_{i,t+1}]=\beta_{i,t}'\lambda_t
    $$
    Understanding Momentum and Reve…
*   重要なのは**βが固定ではなく動く**必要がある、という議論（12-2が効く、銘柄の入替が速い、等）。
    Understanding Momentum and Reve…
*   推定には \*\*IPCA（Instrumented PCA）\*\*を使用。βを特性でパラメトライズ：
    $$
    r_{i,t+1}=(z_{i,t}'\Gamma)\, f_{t+1}+\varepsilon_{i,t+1}
    $$
    Understanding Momentum and Reve…

### 再現手順（実務的チェックリスト）

1.  **特徴量作成**：36特性を月次で揃え、各月で順位→\[−0.5,0.5\]化。
    Understanding Momentum and Reve…
2.  **実現β作成**：日次から当月OLSβ（market等）を作り、将来hか月（h=0,2,5,11）版も作る。
    Understanding Momentum and Reve…
3.  **β予測回帰**：β(t→t+h) を「12-2モメンタム」等で予測するパネル回帰（クラスタSE：銘柄×月）。
    Understanding Momentum and Reve…
4.  **IPCA推定**：latent factor数Kを決め、(zΓ)でloadings、fを推定（KPS手順）。
    Understanding Momentum and Reve…
5.  **期待リターン推定**： $\mu^{IPCA}_{i,t}=\beta_{i,t}'\lambda$  を出し、
    *   モメンタム特性と比較した予測R²や、
    *    $\mu^{IPCA}$ でソートしたLS戦略の性能  
        を評価。
        Understanding Momentum and Reve…

### 主要結論（読み方）

*   伝統モメンタム（12-2のQ5-Q1）は年率8.3%程度だが、**条件付きモデルが説明する成分の方が予測力が強い**、静学FFに対するαも消える方向、というストーリー。
    Understanding Momentum and Reve…

* * *

2) Parametric portfolio policy with momentum-based sentiment trading strategy（Lee et al., PLOS ONE 2025）
--------------------------------------------------------------------------------------------------------

### 目的

*   Markowitz MVに対し、Brandt et al.系の**Parametric Portfolio Policy（PPP）**へ拡張し、そこに**「モメンタム×センチメント」特性ベクトル**を入れて性能改善を狙う。
    Parametric portfolio policy wit…

### データ

*   S&P500 と Dow30 の構成銘柄、リバランスデータを使い、**15年投資地平**で検証（論文要旨）。
    Parametric portfolio policy wit…

### 手法（再現の核）

*   \*\*特性ベクトル（winnerポートフォリオ）\*\*をまず定義：  
    no-short条件で、winner集合に入った銘柄は等ウェイト  $1/N_w$ 、それ以外は0。
    Parametric portfolio policy wit…
*   重要：winnerの定義が2種類
    *   通常モメンタム：過去累積リターンで上位（例：上位10%）
    *   センチメント付：まず上位30%リターンから、\*\*センチメント上位10%\*\*を選ぶ（winner構成が変わる）。
        Parametric portfolio policy wit…
*   PPPは「**保有（前期ウェイト）・ベンチマーク（MV等）・特性ベクトル**」のトレードオフとしてウェイトを出す、という枠組み。
    Parametric portfolio policy wit…
    （※Eq.(2)以降の具体形はPDF後半に続きますが、少なくとも“3者トレードオフ”構造はここが再現の要点です。）

### 再現手順（実装設計）

1.  月次で各銘柄リターンを計算し、\*\*winner候補（上位30%）→センチメントで上位10%\*\*の2段階でwinner集合を確定。
    Parametric portfolio policy wit…
2.  特性ベクトル  $\hat m$  を作成（winner=1/Nw, else 0）。
    Parametric portfolio policy wit…
3.  ベンチマーク  $w_b$  を MV（あるいは min-var）で推定。
    Parametric portfolio policy wit…
4.  PPPで  $w_{target}$  を計算（前期保有と取引コストも入れる設計が売り）。
    Parametric portfolio policy wit…
5.  MV（素）、MV+Momentum、MV+Momentum×Sentiment（MV\_MS）を比較し、Sharpe等で評価。
    Parametric portfolio policy wit…

### 主要結論

*   センチメント付（MV\_MS）が、MVやMV\_MよりSharpe等で優位、危機局面ではセンチメント要素の選好が増える、という主張。
    Parametric portfolio policy wit…

* * *

3) Bootstrap rolling-window Granger causality dynamics between momentum and sentiment（Nakhli et al., Annals of Finance 2021）
----------------------------------------------------------------------------------------------------------------------------

### 目的

*   **センチメントとモメンタム戦略の因果（Granger）**が一方向か双方向か、かつ**時間で不安定**かを、rolling bootstrapで見る。
    Bootstrap rolling-window Grange…

### データ

*   CRSPのNYSE/NASDAQ/AMEX、月次、2001/4–2018/12。
    Bootstrap rolling-window Grange…
*   センチメントは Conference Boardの **CCI** を採用。
    Bootstrap rolling-window Grange…

### モメンタム戦略インデックス構成（再現の最重要）

*   **6ヶ月ルックバック／6ヶ月ホールド**のモメンタム：毎月、過去6ヶ月リターンでランク、等ウェイトの分位ポートフォリオを作り、Winner−Loserを6ヶ月保有。
    Bootstrap rolling-window Grange…
*   市場マイクロ構造バイアス回避として、保有期間開始時に一部ミニマム銘柄除外、12ヶ月未満履歴銘柄除外等。
    Bootstrap rolling-window Grange…

### 統計手法（2段階）

1.  **フルサンプルGranger** → その後、パラメータ安定性（短期/長期）を確認し、不安定なら rolling bootstrapへ。
    Bootstrap rolling-window Grange…
    *   例：Sent→Mom、Mom→Sent ともに有意で双方向を示唆（ただし不安定）。
    Bootstrap rolling-window Grange…
    2.  **Rolling-window Bootstrap Granger**
    *   windowは3年（36ヶ月）を使用。
    Bootstrap rolling-window Grange…
    3.  さらに「因果が有意になる確率」を**Probit**で説明：
    *   目的変数：Grangerが10%有意なら1、それ以外0。
    Bootstrap rolling-window Grange…
*   Probitの形： $\Pr(Y=1|X)=\Phi(X\beta)$ 。
    Bootstrap rolling-window Grange…
*   説明変数：VIX、ADS、Gold、Market return、Spot等。
    Bootstrap rolling-window Grange…

### 主要結論

*   SentとMomは**双方向Granger**だが時間的に不安定。
    Bootstrap rolling-window Grange…
*   ADS/VIXは「Sent→Momの起こりやすさ」を上げ、「Mom→Sent」を下げる方向、Goldは相互因果の確率を下げる。
    Bootstrap rolling-window Grange…

* * *

4) Design and analysis of momentum trading strategies（Richard J. Martin, 2023, arXiv）
-------------------------------------------------------------------------------------

### 目的

*   トレンドフォロー（モメンタム）戦略の\*\*“正の歪度（skewness）”\*\*が、線形/非線形の設計でどう決まるかを解析し、設計指針まで落とす。
    Design and analysis of momentum…

### 戦略の共通骨格（再現の最重要）

*   シグナル：移動平均（EMA等）で過去リターンを平滑化したモメンタム  $V_n$ 。
*   ポジション：\*\*活性化関数（activation）\*\*で  $V_n$  をポジション  $\phi_n$  に変換：
    $$
    V_n=\sum_{j\ge 0}a_j U_{n-j},\quad \phi_n=\psi(V_n)
    $$
    Design and analysis of momentum…
    （線形は  $\psi(x)=x$ 、非線形は閾値やシグモイド等）

### 設計上の結論（実装に効く“ルール”）

*   よくある「符号だけで +1/-1」の**不連続（binary bet）は良くない**、閾値（dead zone）を設ける等で改善できる。
    Design and analysis of momentum…
*   “dead zone幅 ε” を上げてもSharpeが大きく落ちない範囲があり、同時に歪度が改善するので、**ε≈0.6**が良い設計、という実証的結論（著者の設定）。
    Design and analysis of momentum…
*   非線形活性化を「シグモイド＋reversion部品」などの混合で設計する提案（具体式）。
    Design and analysis of momentum…

### 再現手順（最低限）

1.  各資産で日次/週次リターン  $U_t$  を作る
2.  EMAで  $V_t$  を作る（論文はEMAの一般線形結合を前提）。
    Design and analysis of momentum…
3.   $\psi(\cdot)$  を選ぶ：
    *   例：dead zone付き（閾値ε）→ 連続的に立ち上がる関数
4.  ポジション  $\phi_t$  を作り、P&L =  $\phi_t U_{t+1}$  を集計。
    Design and analysis of momentum…
5.  目的関数：Sharpe（実証）＋歪度（解析）を両方見る、という設計思想。
    Design and analysis of momentum…

* * *

5) Momentum Strategies Across Asset Classes（J.P. Morgan, 2015）
--------------------------------------------------------------

### 目的

*   クロスアセットのモメンタム（トレンド）を、**シグナル設計＋リスク管理＋ポートフォリオ化**まで体系化（実装指針のハンドブック的）。
*   特に“turning point（転換点）”でのテールリスクをどう減らすか。
    Momentum Strategies Across Asse…

### 実装指針（再現の核）

*   リスク低減の方法群：
    *   **ストップロス**（資産レベル／ポートフォリオレベル）
    *   **ロングオンリー化**（ショート脚が転換点に弱い場合）
    *   **クロスアセット分散**
    *   **シグナル分散**（中期＋長期など複数モメンタム信号の加重）
        Momentum Strategies Across Asse…
*   具体的な指数例：CDS指数のモメンタムは**5日MA vs 50日MA**、シグナルに応じて**0.25x刻みでエクスポージャー調整**し、±1xにキャップ。
    Momentum Strategies Across Asse…
*   リバランス頻度と保有期間：月次/日次などを比較し、「投資ホライズン」と「リバランス頻度」の切り分けを明確化（例：日次リバランスでも各ポジションは1ヶ月保有、のように設計可能）。
    Momentum Strategies Across Asse…

### 再現手順（プロトタイプ）

1.  各アセットでトレンドシグナル（例：過去12Mリターン、MAクロス等）を作る
2.  ボラ目標（vol targeting）やストップロス等のオーバーレイを定義（CPPI系として実装可能）。
    Momentum Strategies Across Asse…
3.  複数アセットの因子（シングルアセットモメンタム）を作り、MVOやリスクパリティ等で統合。
    Momentum Strategies Across Asse…

* * *

6) Comomentum（論文：モメンタムのクラッシュ条件を“相関構造”で捉える系）
-------------------------------------------

※このPDFは本文全体をここで展開しきれていませんが、**再現に必要な中心アイデア**は引用部分に出ています。

### 目的（中心命題）

*   モメンタムの成否（特にクラッシュ）を、Winner/Loser集合の\*\*内部の“部分相関”構造（comomentum）\*\*で測る。

### コア定義（再現の核）

*   月末に、標準的なモメンタム形成：**過去12ヶ月累積リターン（直近1ヶ月スキップ）でdecile**、$5未満やNYSEサイズ下位decileを除外。
    Comomentum
*   その上で、\*\*Loser decile内の平均ペア部分相関（平均pairwise partial return correlation）\*\*を  $\text{comom}^L$  として作り、月を  $\text{comom}^L$  の水準でグルーピング。
    Comomentum
*   頑健性：Winner側で計算、Winner+Loserを符号反転でスタック、マーケットやUMDボラ等をパージした残差comom、DGTW調整後リターン、業種中立化、など多様な再定義をテスト。
    Comomentum

### 再現手順（最小）

1.  月次リターンから 12-1モメンタムでWinner/Loser decileを構成（除外ルール込み）。
    Comomentum
2.  Loser decileの**週次（or高頻度）リターン**を作り、ペア部分相関の平均を算出して  $\text{comom}^L$  を得る。
    Comomentum
3.   $\text{comom}^L$  が高い局面/低い局面で、モメンタム（Winner−Loser）の成績差を比較。
    Comomentum

* * *

7) Short-term Momentum（RFS 2021 “STMOM”系）
-----------------------------------------

### 目的（この論文の位置づけ）

*   1ヶ月リターン等の「短期」領域にある収益性（STMOM）が、PEAD（決算後ドリフト）等の既存“短期モメンタム”と**どの程度独立か**を検証。

### 再現に必要な要点（引用範囲から）

*   STMOMは他の短期モメンタム（CAR3等）と相関はあるが強くはなく（例：18%）、**spanningしても残差収益が残る**（月0.96%など）。
    Short-term Momentum
*   決算発表日の影響を直接コントロール：前月に決算発表があった銘柄を除外してもSTMOMが残る、という検証（詳細はIA参照）。
    Short-term Momentum

### 再現手順（最低限）

1.  STMOMポートフォリオ（論文の定義に合わせた短期ソート）を月次で構築
2.  CAR3や従来モメンタム等、比較戦略を同様に構築
3.  相関、spanning回帰（STMOM ~ 他戦略）でαとR²を評価。
    Short-term Momentum
4.  感度分析：決算発表銘柄除外を入れて再計測。
    Short-term Momentum

* * *

次にやると精度が上がること（こちらで即やれます）
========================

上の要約は「再現に必要な核」を優先して書きましたが、\*\*各PDFの“式(2)以降、パラメータ、ハイパー、推定細部”\*\*まで完全再現するには、各論文で「手法セクションの該当ページ」をもう少し広く引いて整理するのが有効です。

必要なら、あなたの目的（例：ETFでの実装／日次データ縛り／ロングオンリー等）に合わせて、各論文を

*   **実装テンプレ（データ→特徴量→推定→検証→リークチェック）**
*   **再現に必要なパラメータ一覧（ルックバック、ホールド、除外、コスト、推定窓など）**  
    に落とし込んだ“実装仕様書”形式で再編集します。

## Prompt:
prices

| Price | Adj Close | Adj Close | Adj Close |
| --- | --- | --- | --- |
| Ticker | AGG | DBC | EEM |
| Date |  |  |  |
| 2005-01-03 | 52.43636703491211 |  | 14.562673568725586 |
| 2005-01-04 | 52.38518142700195 |  | 14.114311218261719 |
| 2005-01-05 | 52.36469650268555 |  | 13.9415283203125 |
| 2005-01-06 | 52.40054702758789 |  | 13.932052612304688 |
| 2005-01-07 | 52.38518142700195 |  | 13.959028244018555 |

それぞれについて添付のデータを用いてcodexで実装できるよう実装仕様書を作成してください。

## Response:
思考時間: 38s

以下は、**添付 `prices.csv` のみ**を入力として、Codexでそのまま実装に落とせるようにした \*\*「実装仕様書（Implementation Spec）」\*\*です。  
（※一部論文は本来「センチメント系列」や「銘柄特性（characteristics）」が必要ですが、今回は添付データ制約のもとで **(A) 代替仕様（price-only proxy）** と **(B) 後から差し替え可能な拡張点** を明示します。）

* * *

0\. 共通前提（全プロジェクト共通）
===================

0.1 入力データ
---------

*   ファイル：`/mnt/data/prices.csv`
*   中身：yfinance由来の「フィールド×ティッカー」の **擬似MultiIndex** が、CSV上で
    *   1行目：Ticker行（例：Adj Close列群の先頭に “AGG”, “DBC”, …）
    *   2行目：Dateラベル行
    *   3行目以降：日次データ  
        という形で入っています（通常の“ヘッダ2段”ではなく、**データ行としてティッカー行が混入**している）。

0.2 `prices.csv` のパース仕様（最重要）
----------------------------

### 目的

*   `DataFrame` を以下のどちらかに整形する
    1.  **tidy形式**：`[date, ticker, field, value]`
    2.  **panel形式**：`px[field][date, ticker]`（推奨：`dict[str, DataFrame]`）

### 期待するフィールド

*   少なくとも `Adj Close` を使う（分配金調整が必要な戦略が多い）
*   あれば `Volume`, `Open/High/Low/Close` も保持

### パース手順（仕様）

1.  CSVを通常読み込み（header=0）
2.  0行目（index=0）を “ticker\_row”、1行目（index=1）を捨て行として扱う
3.  `Date` 列は `df.iloc[2:, 0]` を `datetime` 化して index にする
4.  残り列は「元の列名（例：Adj Close, Adj Close.1…）→ベース名 Adj Close」へ正規化しつつ、
    *   tickerは `ticker_row[col]` を採用（例：ticker\_row\['Adj Close.1'\] == 'DBC'）
5.  出力は
    *   `panel["adj_close"] = DataFrame(index=date, columns=tickers)`
    *   `panel["close"]`, `panel["volume"]` …も同様
6.  欠損：
    *   連続欠損が長いティッカーは **ユニバースから除外**できるようにする（閾値はconfig）
    *   リターン計算前に `ffill` は基本しない（ETFは上場前NaNが多いので、期間を共通サンプルに切る）

### バリデーション（必須）

*   ティッカー一覧が期待通りかログ出力（例：AGG, DBC, EEM, …）
*   `Adj Close` が単調に存在する最初/最後日を tickerごとに出力

* * *

1\. 共通バックテスト基盤（全論文共通で流用）
========================

1.1 リターン・リバランス
--------------

*   日次リターン：`ret_d[t] = adj_close[t] / adj_close[t-1] - 1`
*   月次リターン：月末（ME）で `adj_close` をサンプルし、同様に計算
    *   pandasの `'M'` は使わず `'ME'` を使用（あなたの過去ログのエラー対策）

1.2 重みの適用と先読み排除（必須）
-------------------

*   月末 t にシグナル→ **翌営業日（t+1の最初の取引日）から適用**
*   実装は
    *   月末で `w_target[t]` を作り
    *   日次リターン適用時に `w_applied = w_target.shift(1, freq=rebalance_calendar)` の形で \*\*“月末→翌日”\*\*へずらす
*   取引コスト（任意）
    *   比例コスト：`cost = c * sum(abs(w_t - w_{t-1}))`
    *   証拠として turnover と cost series を outputs に保存

1.3 出力（各論文で最低限）
---------------

*   `outputs/perf/`：
    *   NAV、日次/週次/月次リターン、Sharpe、MaxDD、turnover
*   `outputs/plots/`：
    *   NAV推移、DD、月次リターンヒートマップ
*   `outputs/logs/`：
    *   ユニバース、サンプル期間、欠損、パラメータ、リーク検査（weights timing）結果

* * *

2\. 論文別：実装仕様書
=============

以下、\*\*各論文=1ノートブック（or 1スクリプト）\*\*で完結させます。  
ファイル名例：`projects/<proj>/notebooks/01_<paper_id>_replication.ipynb`

* * *

2.1 Understanding Momentum and Reversal（“条件付きβ”系）— price.csv制約下の代替仕様
--------------------------------------------------------------------

### 目的（price-onlyで再現できる部分）

*   「モメンタムが将来のリスク露出（β）の変化を予測する」  
    を、**ETFクロスセクション**で簡易検証する。

### 入力

*   `adj_close`（必須）
*   市場代理：`SPY`（なければ等ウェイト市場 proxy）

### 生成物（Outputs）

*   予測回帰結果：
    *   `beta_{i,t→t+h}` を `mom_{i,t}` で予測した係数・t値（h=1,3,6,12ヶ月）
*   戦略：
    *   “β予測”に基づく簡易ローテーション（任意）

### 手順（仕様）

1.  **月次パネル**作成：`px_m[t,i]`
2.  **モメンタム定義**（例：12-2）
    *   `mom12_2[t,i] = px_m[t-2]/px_m[t-12] - 1`
3.  **実現βの推定**
    *   日次で rolling OLS（窓：63営業日 or 252）
    *   `r_i ~ alpha + beta * r_SPY`
    *   β系列を月末サンプルして `beta[t,i]`
4.  **βの将来変化**
    *   `beta_fwd[h][t,i] = beta[t+h,i]`
5.  **パネル回帰**
    *   `beta_fwd[h] ~ mom12_2`（クロスセクション×時系列）
    *   SE：Newey-West（簡易）or 時系列クラスタ（ETF数が少ないので簡易でOK）
6.  **可視化**
    *   h別係数の棒グラフ
    *   momとbetaの散布（各月）

### 注意（限界と拡張点）

*   原論文のIPCA/36特性は price.csvだけでは不可  
    → 拡張点：`features.csv`（特性）を後から差し替え可能なI/Fを作る
    *   `get_characteristics(date)->DataFrame[ticker, features]`

* * *

2.2 Parametric Portfolio Policy with momentum-based sentiment（PPP）— センチメント代替仕様
------------------------------------------------------------------------------

### 目的

*   PPP（パラメトリック方策）で、
    *   ベンチマーク（min-var等）
    *   保有継続（turnover抑制）
    *   特性（momentum×sentiment winnerベクトル）  
        をトレードオフして改善する、を **price-only proxy** で実装。

### 代替センチメント（price-only）

*   “Risk-on sentiment proxy” を以下で定義（例）
    *   `sent[t] = zscore( mom_SPY_6M[t] - mom_TLT_6M[t] )`
    *   もしくは `SPY`の直近リターンの符号、VIXがないのでボラ proxy 等

### Inputs

*   `adj_close`（必須）
*   proxy構築に `SPY`, `TLT` が望ましい

### Outputs

*   3戦略比較
    1.  ベンチマーク：min-var（月次推定）
    2.  Momentum only（winner=過去リターン上位）
    3.  Momentum×Sentiment（winner候補→sent上位で絞る）
*   turnover/コスト込み成績

### PPPの具体形（実装可能な最小仕様）

*   目的：月次で `w_t` を決める
*   最小で以下の二次目的を採用（“PPPらしさ”を担保）
    $$
    \min_{w} \ \frac{1}{2} w^\top \Sigma_t w \ - \ \eta \, w^\top m_t \ + \ \gamma \| w - w_{t-1}\|_2^2
    $$
    *   `Σ_t`：過去Lヶ月（例：36）から推定した共分散
    *   `m_t`：winner特性ベクトル（等重みで1/Nw、それ以外0）
    *   `η`：特性への傾き（学習 or グリッド）
    *   `γ`：保有継続（turnover抑制）
*   制約：
    *   long-only：`w>=0, sum(w)=1`
    *   long-short版も任意（`sum(abs(w))<=leverage`）

### 手順

1.  月次リターン `ret_m`
2.  winner集合：
    *   momentum：過去6M or 12-2 で上位p%
    *   mom×sent：まずmom上位q% → その中で `sent[t]` が高い局面のみ/あるいは銘柄別sent proxy（ないので局面だけでもOK）
3.  `Σ_t` 推定（shrunk推定 optional）
4.  上のQPを解く（cvxpy無し前提なら：
    *   long-onlyは投影勾配法（projected gradient）で実装仕様を提示）
5.  比較：min-var / mom / mom×sent のNAV・Sharpe・DD・turnover

### 拡張点

*   将来 `sentiment.csv` を入れるI/F：
    *   `get_sentiment_series()->Series(date->sent)`
    *   銘柄別センチメントがあるなら `sent[t,i]` に拡張

* * *

2.3 Rolling-window Bootstrap Granger causality（Momentum↔Sentiment）— proxyセンチメントで再現
----------------------------------------------------------------------------------

### 目的

*   Sent→Mom / Mom→Sent のGranger因果が **時間で変わる**ことを、
    *   rolling window
    *   bootstrap p-value（簡易でOK）  
        で可視化。

### Inputs

*   `mom_ret[t]`：モメンタム戦略の月次リターン（ETFユニバースで構築）
*   `sent[t]`：2.2で定義したproxyセンチメント

### Outputs

*   rolling windowごとの
    *   p-value（Sent→Mom, Mom→Sent）
    *   有意フラグ
*   プロット：時間軸にp-value（2本）

### モメンタム戦略定義（ETF版）

*   月次で
    *   formation：過去6ヶ月累積（または12-2）
    *   long：上位k、short：下位k（ETF数が少ないので k=2 など）
    *   6ヶ月ホールドは「重ね持ち」する（オリジナル論文風）
*   ETF数が少ないので、**ホールド重ね持ちは実装できるが分散が粗い**  
    → 代替として “毎月リバランスのLS” も併記（2系列で検証）

### Granger実装（仕様）

1.  ラグ次数 `p` を固定（例：1〜3をAICで選択）
2.  各window（例：36ヶ月）でVAR(p) を推定
3.  Granger検定（Wald）
4.  bootstrap（簡易）
    *   残差再標本化→再推定→Waldの分布→p-value
5.  outputsにwindowごとの結果表を保存

* * *

2.4 Design and analysis of momentum trading strategies（非線形活性化）— ほぼ完全にprice-onlyで再現可能
------------------------------------------------------------------------------------

### 目的

*   EMA等で平滑化したモメンタム `V_t` を
    *   線形：`phi=V`
    *   binary：`phi=sign(V)`
    *   dead-zone：`phi = clip((|V|-ε)_+ * sign(V), [-1,1])` 等  
        で比較し、Sharpeと歪度（skew）を評価。

### Inputs

*   日次 `ret_d`（adj\_close）

### Outputs

*   活性化関数ごとの
    *   Sharpe、skew、MaxDD、turnover
    *   ポジション推移（例：SPY）と分布

### 手順

1.  各ETFで `V_t = EMA(ret_d, span=s)`（sはconfig）
2.  活性化関数セット：
    *   linear / sign / dead-zone(ε) / sigmoid(k) など
3.  `phi_t` を作り `pnl = phi_{t-1} * ret_t`（先読み排除）
4.  ETF横断の合成：
    *   等ウェイトで平均、または vol-target合成
5.  指標：
    *   年率Sharpe、skew、kurt、DD
6.  dead-zoneのεスイープ（例：0〜1）で感度分析（論文の主張をETFで追試）

* * *

2.5 JPM Momentum Strategies Across Asset Classes（トレンド×オーバーレイ）— price-onlyで実装可能
------------------------------------------------------------------------------

### 目的

*   クロスアセットETF（株/債券/クレジット/商品/REIT）で、
    *   複数シグナル（短期/中期/長期）
    *   リスク管理（vol targeting）
    *   ストップ等オーバーレイ  
        を入れたトレンド戦略を構築し、turning point耐性を比較。

### Inputs

*   `adj_close`（日次）

### Outputs

*   戦略バリエーション比較：
    1.  12Mモメンタムのみ
    2.  MA cross（例：fast/slow）
    3.  シグナル分散（複数 horizon の平均）
    4.  *   vol targeting
    5.  *   stop overlay（ドローダウン条件）

### 実装仕様（最小）

*   シグナル：
    *   `sig_h = sign( ret_cum(L_h) )` もしくは `MA_fast - MA_slow`
*   合成：
    *   `sig = mean_h(sig_h)` を \[-1,1\] に正規化
*   配分：
    *   `w_i ∝ sig_i / vol_i`（volはEWMA）
    *   `sum(abs(w))=1`（LS） or `sum(w)=1, w>=0`（LO）
*   ストップ：
    *   ポートDDが閾値を超えたらエクスポージャ縮小（例：0.5x）
*   月次/週次/日次リバランスの比較（あなたの用途なら月次中心でOK）

* * *

2.6 Comomentum（部分相関でクラッシュ条件を測る）— ETF少数版の“縮小再現”
----------------------------------------------

### 目的

*   Winner/Loser集合内の **共通変動（部分相関）** が高い局面ほど、モメンタムの挙動が変わる、をETFユニバースで検証。

### Inputs

*   週次リターン（推奨：日次→週末に集計）
*   月次でWinner/Loserを決める

### Outputs

*   `comom_L[t]`（Loser内の平均部分相関）
*   comomの高低で分けたモメンタム成績

### 実装仕様（ETF版）

1.  月末で 12-2（or 6M）でETFをランクし、Winner/Loser集合（各2本など）を作る
2.  Loser集合の週次リターン行列 `R (T×K)` を作る
3.  部分相関：
    *   逆共分散 `P = Cov(R)^{-1}`
    *   部分相関 `ρ_ij = -P_ij / sqrt(P_ii P_jj)`
4.  `comom_L = mean_{i<j} ρ_ij`
5.  `comom_L` の上位/下位分位で期間を分け、モメンタムLSの平均リターン・DD等を比較

### 注意

*   ETF本数が少ないので推定が不安定になりやすい  
    → shrinkage（Ledoit-Wolf相当）を“自前簡易”で入れる拡張点を用意

* * *

2.7 Short-term Momentum（STMOM）— ETF版の短期ソート再現
--------------------------------------------

### 目的

*   短期（1ヶ月等）のリターンに基づくモメンタムが、
    *   中期モメンタム（12-2）とは別物として残る  
        をETFユニバースで検証。

### Inputs

*   月次リターン

### Outputs

*   STMOM（例：1M）LS
*   中期モメンタム（12-2）LS
*   相関、spanning回帰（STMOM ~ 中期mom）でα

### 実装仕様

1.  STMOM：
    *   `stmom[t,i] = ret_1m[t,i]`
    *   上位kロング/下位kショート（ETF数が少ないのでk=2）
2.  中期mom：
    *   `mom12_2[t,i]`
3.  spanning：
    *   `stmom_ls_ret[t] = a + b * mom_ls_ret[t] + e[t]`
    *   αの有意性（Newey-Westで簡易）
4.  追加（任意）：
    *   月前半/後半などは本来「決算日」が必要だが、ETFでは難しい  
        → 今回は “月内2分割” の疑似検証は **やらない**（拡張点として残す）

* * *

3\. Codex向け「実装タスク定義」（そのまま貼れる粒度）
===============================

各ノートブック共通で、冒頭に以下を必須タスクとして書きます。

3.1 タスク一覧（Notebook内の章立て）
------------------------

1.  Load & Parse `prices.csv`（共通関数化）
2.  Build daily/monthly panels（adj\_close, returns）
3.  Strategy-specific signal construction
4.  Portfolio construction & execution timing（leak check）
5.  Metrics & plots
6.  Save artifacts to `outputs/`

3.2 共有関数I/F（最低限この5つ）
--------------------

*   `load_prices_csv(path) -> dict[field, DataFrame(date×ticker)]`
*   `make_returns(px, freq="D"|"ME") -> DataFrame`
*   `apply_weights(ret_d, w_rebal, rebalance_dates, cost_bps) -> Series(nav), DataFrame(weights_applied)`
*   `compute_metrics(nav, ret_d) -> dict`
*   `save_outputs(...)`

* * *

4\. 重要：この仕様で“できること/できないこと”を明確化
==============================

*   **price.csvだけで忠実再現できる**：
    *   Martin(非線形活性化), JPM(トレンド＋オーバーレイ), STMOM(ETF版), Comomentum(縮小ETF版)
*   **本来追加データが必要だが、proxyで再現可能**：
    *   PPP（センチメント proxy）, Granger（センチメント proxy）
*   **本来“銘柄特性”が必要で、proxyだと別物になる**：
    *   Understanding Momentum and Reversal（IPCA/特性βは不可）  
        → ただし「モメンタムがβ変化を予測する」方向性はETFでも検証可能

* * *

必要なら、この仕様を **そのまま `SPEC.md` としてプロジェクトに置ける体裁**（ディレクトリ、ファイル名、config例、出力ファイル名規約まで固定）にして、Codexに貼る“実行プロンプト”まで一括で作ります。

## Prompt:
お願いします

## Response:
実装仕様書と、Codexにそのまま貼れる実行プロンプトを **ファイル化**しました。

*   IMPLEMENTATION\_SPEC\_momentum\_papers.md
*   CODEX\_RUN\_PROMPT.md

この2つを Codex に渡せば、`/mnt/data/prices.csv` だけを使って **00〜07の8本ノートブック**を順に作り、各ノートが単独完走して `outputs/` に成果物を落とす流れまで、迷いなく実装できます。

## Prompt:
各手法についてより詳細な解説を追加してチャットで説明して

## Response:
了解。以下は、先ほどの **00〜07**（各論文/手法）について、\*\*「なぜその設計になるのか」「実装で何に注意すべきか」「このprices.csv制約下で何が再現できて何が代理になるか」\*\*まで含めて、チャット上で詳細解説します。  
（前提：`prices.csv`はETFの日次価格のみ。論文で本来必要な“センチメント/個別特性”は、**price-only proxy**で代替し、I/Fは差し替え可能にしてある。）

* * *

00 パース＆パネル化（全手法の土台）
===================

何が難しいか（このCSV特有）
---------------

*   yfinanceのMultiIndex列（Field×Ticker）が、CSV化の過程で崩れていて
    *   “ティッカー行がデータ行として混ざっている”
    *   “列名が Adj Close, Adj Close.1… のように連番化されている”
*   この状態で `header=[0,1]` などをやると **field/tickerの対応が壊れやすい**。

どう直すか（実装上の要点）
-------------

*   **0行目を ticker マップとして保持**し、以後の全列を「field×ticker」に復元する。
*   `adj_close` を最優先（配当調整済み）として panel を作る。
*   欠損（上場前）を `ffill` で埋めない。  
    → 埋めると「存在しない期間の価格を捏造」して **リターンが歪む**。

ここがバグりやすい
---------

*   「月末」リサンプルは `'M'` ではなく `'ME'`（pandasの仕様変更対策）。
*   価格が文字列として読まれてしまうケース → `to_numeric(coerce)` を強制。

* * *

01 UMR（Understanding Momentum and Reversal）— β予測の“縮小再現”
=======================================================

原論文の核（何をやっているか）
---------------

*   典型的なモメンタム（12-2）やリバーサルは、「行動」だけじゃなくて  
    **将来のリスク露出（β）が変わること**と整合的、という主張。
*   そのために「βが特性で動く（conditional beta）」モデルを推定（IPCAなど）。

prices.csvだけで何を再現するか
--------------------

*   本物のIPCA（36特性）や銘柄レベル特性は無いので不可。
*   代わりに、「ETFクロスセクションでも、モメンタムが将来βを説明するか」を検証する：
    1.  ETFのβ（対SPY）を日次ローリングで推定
    2.  βの将来値（t+h）をモメンタム（t）で説明する

実装のコア設計
-------

*   **β推定窓**：63日（3ヶ月）〜252日（1年）
    *   短いほどノイジー、長いほど構造変化に鈍い
*   **モメンタム**：12-2（スキップ1ヶ月）
    *   “直近1ヶ月はリバーサル/マイクロ構造の影響が混ざる”のでスキップが定番
*   **回帰**：
    *   `beta[t+h,i] = α + γ * mom[t,i] + ε`
    *   hを1/3/6/12ヶ月にして “どの先まで効くか”を見る

よくある失敗（リーク/二重ラグ）
----------------

*   βを月末にサンプルした後、さらにshiftしてしまうと **余計に遅れる**。
*   ここでは「βは t 時点情報」「モメンタムは t 時点情報」→「βの t+h を予測」。  
    戦略に落とす場合は、**tで予測→t+1営業日から適用**を徹底。

何が分かれば“論文の精神”を掴めたことになるか
-----------------------

*   γが有意で、h別に符号と大きさが変わる（短期だけ効く/中期まで効くなど）
*   ETFの性質上、銘柄ほど明確に出ないこともあるが、  
    “モメンタム＝単純にリターン自己相関”だけではない示唆が得られる。

* * *

02 PPP（Parametric Portfolio Policy）— “方策最適化”を価格だけで再現
====================================================

原論文の核
-----

*   「Markowitz最適化」ではなく、**方策（policy）を直接パラメトライズ**して
    *   取引コスト
    *   保有の慣性（turnover抑制）
    *   特性（momentum / sentiment）  
        を同時に扱う。

prices.csvだけだとセンチメントがない問題
-------------------------

*   論文はニュース/指数などのセンチメントを使う想定だが、ここでは **proxy** を用意：
    *   例：Risk-on proxy  
        `sent[t] = zscore( mom6m(SPY) - mom6m(TLT) )`
    *   解釈：株が債券より強い＝リスク選好が高い局面

実装（PPP風）の最小で強い形
---------------

実装は「PPPの精神」を残しつつ、解ける形にするのが重要です。  
そこで仕様では、次の“3項”目的を採用：

$$
\min_w \frac{1}{2} w^\top \Sigma w \;-\;\eta\, w^\top m\;+\;\gamma \|w-w_{t-1}\|^2
$$
*   **(1) リスク（共分散）**：Markowitzの芯
*   **(2) 特性ベット**：winner vector `m`（モメンタム上位に寄せる）
*   **(3) 慣性**：前期からあまり動かさない（turnover抑制）

これで

*   η↑：モメンタムへの寄せが強い
*   γ↑：売買が減るが追随が鈍る  
    という直観的トレードオフが出ます。

解法（依存追加なし）
----------

*   本来cvxpy等のQPソルバが楽だが、依存追加禁止なので
    *   **Projected Gradient Descent**
    *   long-onlyなら **simplex projection**  
        で解く。

ここが実務で重要
--------

*   ETFが少ない場合、Σが不安定 → shrink（ridge）を入れる（`Σ+λI`）
*   winnerが1〜2本しかない月がある → `m` が極端 → ηを上げすぎると一点集中
*   コストを入れると“勝ってた戦略が負ける”ことが多い  
    → だからこそγ（慣性）がPPPの主役になる

* * *

03 Rolling Granger（Mom ↔ Sent）— 「関係が時間で変わる」を可視化
===============================================

原論文の核
-----

*   “センチメントがモメンタムを駆動するのか”
*   “逆にモメンタム（価格動向）がセンチメントを駆動するのか”  
    を、単一の全期間推定で結論づけず、**rolling windowで時変性を見る**。

prices.csvでの再現
--------------

*   Mom：ETFモメンタムLSの月次リターン series（作れる）
*   Sent：02のproxy（作れる）
*   これで `Mom_ret` と `Sent` の2変数VARを rolling で推定し、Grangerを回す。

実装のコア
-----

*   window：36ヶ月（3年）
*   lag：p=2（またはAIC）
*   2方向：
    *   Sent → Mom
    *   Mom → Sent
*   bootstrap：残差再標本化で p-value を頑健化

何を読み取るか
-------

*   “常に有意”ではなく、危機/転換点で有意になったり消えたりするなら  
    **戦略のゲーティング**（センチメントが効く局面だけモメンタム強化）に落とせる。

* * *

04 Martin（非線形活性化）— price-onlyで最も忠実に追試できる
========================================

原論文の核
-----

*   トレンド/モメンタムの「歪度（skew）」は、  
    \*\*シグナル→ポジション変換（activation）\*\*の形で大きく変わる。
*   binary（±1）みたいな不連続は、転換点で損失を増やしがち。
*   dead-zone（小さい信号は取らない）やtanhなどで改善する余地。

実装の要点
-----

*   シグナル：`V_t = EMA(ret, span=s)`
*   activation候補：
    *   linear：`phi=V`（最も基本）
    *   sign：`phi=sign(V)`（不連続）
    *   dead-zone：`|V|<ε`は0、超えたら徐々に立つ
    *   tanh：滑らかに飽和

評価指標
----

*   Sharpeだけでなく **skew** を必ず見る  
    （トレンドは“平常時は小さく勝ち、危機で大きく勝つ”が理想の形）

実務に直結する示唆
---------

*   dead-zoneのε sweepで、
    *   turnoverが下がる
    *   skewが改善する
    *   Sharpeがあまり落ちない  
        という“設計の甘いスポット”が見つかることが多い。

* * *

05 JPM（クロスアセット・トレンド + オーバーレイ）
=============================

何が実務的に効くか
---------

JPM資料の価値は「モメンタムの教科書」ではなく、

*   **複数シグナルの分散**
*   **リスク管理（vol targeting / caps）**
*   **ストップ等のオーバーレイ**  
    が、トレンドの実運用に不可欠、という点。

prices.csvでの実装設計
----------------

*   シグナル：1M/3M/12M の sign を平均（多ホライズン）
*   配分：`w_i ∝ sig_i / vol_i`（EWMA vol）
*   レバ/集中にcap
*   DD stop：ポートDDが閾値超でエクスポージャ縮小

ここが落とし穴
-------

*   vol targetingは“勝ち負け”よりも **運用安定性**を作る  
    → 期待リターンが同等でもDDが激減することがある
*   stopは効くが、パラメータ次第で“勝ちも潰す”  
    → 比較として「stop無し」も必ず併記

* * *

06 Comomentum（部分相関）— ETF少数でも“局面指標”として使える
========================================

原論文の核（直観）
---------

*   モメンタムクラッシュは、Winner/Loserの中で
    *   “同じ方向に一斉に動く”（共通因子が強い）
    *   “密に結びつく”  
        局面で起こりやすい、という発想。
*   それを \*\*部分相関（precision matrix由来）\*\*で測る。

ETF版（縮小再現）のポイント
---------------

*   銘柄数が少ないので不安定  
    → precision を `inv(S + λI)` の ridge で安定化
*   Loser集合が2本しかないと部分相関は1点しか取れない  
    → universeを増やすか、kを調整できるようにする

何を見ればよいか
--------

*   comomが高い月と低い月で
    *   モメンタムLSの平均
    *   DD  
        が明確に変わるなら、comomは **モメンタムのリスク指標**になる。

* * *

07 STMOM（短期モメンタム）+ spanning
===========================

原論文の核（ETFでやる意味）
---------------

*   1ヶ月モメンタム（STMOM）は、12-2など中期と違う現象か？  
    → spanning回帰で「中期で説明できないαが残るか」を見る。

ETF版の注意
-------

*   ETFは個別株よりもイベント（決算等）の影響が薄い一方で
    *   短期の“需給/フロー”が出ることはある
*   ただし本数が少ないとノイズが強い  
    → k（top/bottom）や期間を柔軟にする

spanningの読み方
------------

*   `r_stmom = a + b * r_mom + e`
    *   aが正で有意：短期は中期と独立成分がある
    *   bが大：短期は中期の派生に近い

* * *

まとめ：この8本が「一つの研究パイプライン」になる理由
===========================

*   00：データ土台
*   04/05：トレンド設計（シグナル→ポジション、リスク管理）
*   07：短期 vs 中期の分解（信号の多様化）
*   06：クラッシュ/局面指標（リスク管理の補助）
*   03：外生（proxy）と因果関係の時変性（ゲーティングの根拠）
*   02：上を統合する“方策最適化”（turnover・特性・リスクの統合）
*   01：リスク露出（β）という“解釈”側の裏付け

* * *

必要なら次に、**あなたの prices.csv のティッカー集合（株/債券/商品など）に合わせて**、

*   05（クロスアセット）で使う “最適なシグナル集合（1M/3M/12M or MA設定）”
*   02（PPP）の η/γ の探索レンジ（グリッド）
*   06（comom）の推定窓とλ  
    を、**ETF本数と欠損状況に合わせて現実的な推奨値**に落とし込みます。

## Prompt:
各論文の手法について数式を交えて細かく説明して

## Response:
以下、\*\*各論文の“手法部分”\*\*を、実装で必要になるところまで **数式ベース**で細かく整理します。  
（注：あなたの `prices.csv` 制約で再現する場合は、論文が要求する外生データ（センチメント指数、個別株特性など）を **proxy** に置き換えます。その置換点も明示します。）

* * *

1) Understanding Momentum and Reversals（Kelly et al.）
=====================================================

1.1 論文の主モデル：条件付きファクター価格付け（conditional factor pricing）
-----------------------------------------------------

資産  $i$  の超過リターン  $r_{i,t+1}$  を

$$
r_{i,t+1} = \beta_{i,t}^\top f_{t+1} + \varepsilon_{i,t+1}
$$

とし、期待超過リターンは

$$
\mathbb{E}_t[r_{i,t+1}] = \beta_{i,t}^\top \lambda_t
$$

で与える（ $\lambda_t$  は条件付きリスクプレミアム）。  
重要なのは ** $\beta_{i,t}$  が時間変動する**点です。

1.2  $\beta_{i,t}$  を“特性でパラメトライズ”する（IPCAの骨格）
--------------------------------------------

特徴量（characteristics）を  $z_{i,t}\in\mathbb{R}^P$  として、

$$
\beta_{i,t} = \Gamma^\top z_{i,t} \quad (\Gamma\in\mathbb{R}^{P\times K})
$$

と置く。これを代入すると、

$$
r_{i,t+1} = z_{i,t}^\top \Gamma f_{t+1} + \varepsilon_{i,t+1}
$$

ここで  $K$  は潜在ファクター次元。  
IPCAは  $(\Gamma, f_{t+1})$  を「 $z$  を使った低ランク分解」として推定します。

> 直観：\*\*“どの特性を持つ資産が、どのファクターにどれだけ反応するか”\*\*を学習している。

1.3 実装に落とす最小形（prices.csv制約下）
----------------------------

論文の  $z_{i,t}$ （36特性）が無いので、ETF版は次を代替：

*   市場ファクター  $f_{t+1}=r_{m,t+1}$ （SPYなど）
*    $\beta_{i,t}$  は日次ローリングOLSで推定：
    
$$
r_{i,\tau} = \alpha_{i,t} + \beta_{i,t} r_{m,\tau} + u_{i,\tau}, \quad \tau\in[t-W+1,t]
$$

推定した  $\widehat{\beta}_{i,t}$  を月末でサンプルし、  
モメンタム特性（例：12-2）で将来βを予測する：

$$
\widehat{\beta}_{i,t+h} = a_h + \gamma_h \, \text{MOM}_{i,t} + e_{i,t,h}
$$
*    $\text{MOM}_{i,t}=\frac{P_{i,t-s}}{P_{i,t-L}}-1$ （ $L=12$ ,  $s=2$  等）
*    $h\in\{1,3,6,12\}$  で “先まで効くか” を測る

* * *

2) Parametric Portfolio Policy with momentum-based sentiment（Lee et al.）
========================================================================

2.1 論文の要点：特性に反応する“方策”を直接設計する
----------------------------

Brandt et al. 型 PPP の典型形は

$$
w_{t} = w^{\text{base}}_{t} + B^\top x_t
$$
*    $w_t$ ：ポートウェイト（ $N$ 次元）
*    $w^{\text{base}}_t$ ：ベース（等ウェイトやMV）
*    $x_t$ ：状態・特性（センチメント等）
*    $B$ ：学習パラメータ

論文では「winner特性ベクトル  $m_t$ 」を使うのが肝です。

2.2 winner特性ベクトル（論文に明示されている形）
-----------------------------

winner集合  $W_t$  を決めて、

$$
\hat m_{i,t} = \begin{cases} \frac{1}{|W_t|}, & i \in W_t \\ 0, & \text{otherwise} \end{cases}
$$

これが “momentum 特性ベクトル”。

さらに “momentum×sentiment” では

*   まず momentum 上位集合を作り
*   その中から sentiment 条件で絞る  
    という2段階で  $W_t$  を作る（論文の説明）。

2.3 実装に落とす：取引コスト/慣性込みのPPP-QP（依存なしで解ける形）
---------------------------------------

あなたの仕様書では、PPPの精神を残しつつ解ける形として、

$$
\min_{w_t} \frac{1}{2} w_t^\top \Sigma_t w_t \;-\; \eta \, w_t^\top m_t \;+\; \gamma \|w_t - w_{t-1}\|_2^2
$$
*   第1項：リスク最小化（MV）
*   第2項：winner（モメンタム）への寄せ
*   第3項：慣性（turnover抑制）

制約：

*   long-only:  $w_t \ge 0,\; \mathbf{1}^\top w_t = 1$ 

これを PGD で解く：

*   勾配：
    
$$
\nabla_w = \Sigma_t w_t - \eta m_t + 2\gamma (w_t-w_{t-1})
$$
*   更新：
    
$$
\tilde w \leftarrow w - \alpha \nabla_w,\quad w \leftarrow \Pi_{\Delta}(\tilde w)
$$

 $\Pi_{\Delta}$  は simplex への射影（ $\Delta=\{w\ge0,\mathbf{1}^\top w=1\}$ ）。

2.4 センチメントが無い場合の置換（prices-only proxy）
-------------------------------------

本来：外部センチメント指数  $S_t$   
代替：risk-on proxy

$$
S_t^{\text{proxy}} = z\big(\text{MOM}_{SPY,6M}(t)-\text{MOM}_{TLT,6M}(t)\big)
$$

これを使い、

*    $S_t$  が高い局面では  $\eta$  を大きく（攻める）
*   低い局面では  $\eta$  を小さく（守る）

例：

$$
\eta_t = \eta_0 + \eta_1 \cdot \mathbb{1}[S_t^{\text{proxy}}>\tau]
$$

* * *

3) Rolling-window bootstrap Granger causality（Nakhli et al.）
============================================================

3.1 2変数VARとGranger
------------------

2系列：モメンタム戦略リターン  $M_t$ 、センチメント  $S_t$ 

VAR(p):

$$
\begin{pmatrix} M_t \\ S_t \end{pmatrix} = c + \sum_{j=1}^p A_j \begin{pmatrix} M_{t-j} \\ S_{t-j} \end{pmatrix} + \varepsilon_t
$$

### Sent → Mom の Granger

帰無仮説：

$$
H_0:\ (A_j)_{1,2}=0 \quad \forall j=1,\dots,p
$$

（ $M_t$  方程式の中で  $S_{t-j}$  の係数が全部ゼロ）

Wald統計（概念）：

$$
W = (R\hat\theta)^\top (R\widehat{\text{Var}}(\hat\theta)R^\top)^{-1}(R\hat\theta) \sim \chi^2_{q}
$$

3.2 rolling window
------------------

window長  $L$ （例：36ヶ月）で、各窓  $t-L+1 \sim t$  のVARを推定し、  
各  $t$  について p-value を得る。

3.3 bootstrap（残差ブートストラップ）
-------------------------

窓内で

1.  VARを推定し残差  $\hat\varepsilon_t$  を得る
2.   $\hat\varepsilon_t$  を復元抽出して疑似系列を生成
3.  各疑似系列で Wald  $W^{(b)}$  を計算
4.  p-value を
    
$$
p \approx \frac{1}{B}\sum_{b=1}^B \mathbb{1}[W^{(b)} \ge W^{\text{obs}}]
$$

で評価。

3.4 prices-only版での  $M_t$ 
--------------------------

ETFクロスセクションで winner/loser を作る：

$$
\text{score}_{i,t}=\text{cumret}(i,t-L_f\to t-1)
$$
 
$$
M_t = \frac{1}{k}\sum_{i\in \text{Top}k} r_{i,t} - \frac{1}{k}\sum_{i\in \text{Bottom}k} r_{i,t}
$$

* * *

4) Design and analysis of momentum trading strategies（Martin）
=============================================================

4.1 一般形（論文が明示している骨格）
--------------------

リターンを  $U_t$ 、平滑化モメンタムを

$$
V_t=\sum_{j\ge 0} a_j U_{t-j}
$$

ポジションは活性化関数  $\psi$  によって

$$
\phi_t = \psi(V_t)
$$

戦略P&L（シンプル）：

$$
\pi_{t+1} = \phi_t \, U_{t+1}
$$

（**先読み排除**： $\phi_t$  は  $t$  までの情報で作り、 $t+1$  の収益に掛ける）

4.2 具体的な  $\psi$ （代表例）
----------------------

*   線形：
    
$$
\psi(V)=V
$$
*   符号（binary）：
    
$$
\psi(V)=\text{sign}(V)
$$
*   dead-zone（閾値  $\varepsilon$ ）：
    
$$
\psi(V)= \text{sign}(V)\cdot \max(|V|-\varepsilon,0)
$$

（実装ではスケールして  $[-1,1]$  にclipする）

*   tanh（滑らか飽和）：
    
$$
\psi(V)=\tanh(kV)
$$

4.3 何を最適化しているか（設計観点）
--------------------

*   Sharpe（平均/分散）だけでなく
*   \*\*歪度（skew）\*\*を見て “転換点での損失を減らす形” を探す  
    →  $\psi$  の形で tail が変わる。

* * *

5) Momentum Strategies Across Asset Classes（JPM）
================================================

※レポートの性格上、単一の数式体系というより「実装ルールの集合」だが、実装に落とせる数式で整理。

5.1 多ホライズン・シグナル分散
-----------------

各ホライズン  $h\in H$  について

$$
s_{i,t}^{(h)} = \text{sign}\big(\text{cumret}_{i}(t-h,t)\big)
$$

合成：

$$
s_{i,t} = \frac{1}{|H|}\sum_{h\in H} s_{i,t}^{(h)}
$$

5.2 vol targeting
-----------------

EWMAボラ：

$$
\sigma_{i,t} = \sqrt{\lambda \sigma_{i,t-1}^2 + (1-\lambda) r_{i,t}^2}
$$

配分（LSなら）：

$$
w_{i,t} \propto \frac{s_{i,t}}{\sigma_{i,t}} ,\quad \sum_i |w_{i,t}| = 1
$$

（long-onlyなら  $w_{i,t}\propto \max(s_{i,t},0)/\sigma_{i,t}$ ）

5.3 ストップ/スケール（DDオーバーレイ）
-----------------------

ポートNAV  $N_t$  とピーク  $\bar N_t=\max_{\tau\le t}N_\tau$ 

$$
DD_t = 1 - \frac{N_t}{\bar N_t}
$$

閾値  $d^*$  超で縮小：

$$
w_{t} \leftarrow \kappa w_t\quad (\text{if } DD_t>d^*)
$$

* * *

6) Comomentum（部分相関）
===================

6.1 部分相関（precision matrix）定義
----------------------------

Loser集合のリターンベクトル  $R_t\in\mathbb{R}^k$ 。  
（週次等、窓長  $T$  のデータで推定）

共分散：

$$
S = \text{Cov}(R)
$$

precision：

$$
P = S^{-1}
$$

部分相関：

$$
\rho_{ij\cdot \text{others}} = -\frac{P_{ij}}{\sqrt{P_{ii}P_{jj}}}
$$

comomentum 指標（例：Loser側）：

$$
\text{comom}_t^{L} = \frac{2}{k(k-1)}\sum_{i<j}\rho_{ij\cdot \text{others}}
$$

6.2 ETF少数での安定化（必須）
------------------

 $S$  が不安定になりやすいので ridge：

$$
P = (S + \lambda I)^{-1}
$$

6.3 局面分割
--------

 $\text{comom}_t^L$  の分位で月を分けて、条件付き平均を比較：

$$
\mathbb{E}[M_t\mid \text{comom}_t^L \in \text{TopQ}] \quad\text{vs}\quad \mathbb{E}[M_t\mid \text{comom}_t^L \in \text{BottomQ}]
$$

* * *

7) Short-term Momentum（STMOM）
=============================

7.1 STMOM戦略（ETF版）
-----------------

短期スコア：

$$
\text{STMOM}_{i,t} = r_{i,t-1}^{(1M)}
$$

LSリターン：

$$
R_t^{\text{STMOM}}= \frac{1}{k}\sum_{i\in \text{Top}k} r_{i,t} - \frac{1}{k}\sum_{i\in \text{Bottom}k} r_{i,t}
$$

中期mom（12-2）も同様に  $R_t^{\text{MOM}}$  を作る。

7.2 spanning回帰
--------------

$$
R_t^{\text{STMOM}} = a + b\,R_t^{\text{MOM}} + e_t
$$
*    $a>0$  有意：STMOMは中期momで説明できない独立成分が残る
*    $b$  が大：STMOMは中期momの派生成分が強い

NW標準誤差で  $t(a)$  を出す（自己相関対策）。

* * *

次に（より“原論文に忠実”にするための分岐）
======================

あなたが希望する忠実度に応じて分けられます：

1.  **prices.csvだけで最大限忠実**（推奨）  
    → Martin / JPM / Comom / STMOM を中心に「ETFで論文骨格を実証」
2.  **センチメント系列を1本追加**（CCI等）  
    → PPPとGrangerが一気に原論文に近づく
3.  **特性データ（KPSの36特性相当）を追加**  
    → UMR（IPCA）を原論文の主張ラインまで再現可能

希望があれば、まず `prices.csv` のティッカー一覧（資産クラス）に合わせて、  
上の数式の各パラメータ（lookback、k、λ、η/γなど）を **実務的な推奨値**に固定して、仕様書もアップデートします。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)