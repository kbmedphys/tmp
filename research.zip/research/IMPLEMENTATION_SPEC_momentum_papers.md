# Momentum / Sentiment / Comomentum Papers — Implementation Specification (price.csv only)

> 入力は **`/mnt/data/prices.csv` のみ**（追加データなし）を前提。  
> 追加データ（sentiment/characteristics）を後から差し替えられるように **拡張I/F** を明記。  
> 実装は **1プロジェクト=1つの notebooks** で完結させ、`src/` 参照は不要（ノートブック内に全関数を転記）。

---

## 1. Project layout (Codex が生成する想定)

```
projects/
  pXXX_momentum_papers_replication/
    AGENTS.md
    README.md
    notebooks/
      00_parse_prices_and_panel.ipynb
      01_umr_beta_proxy.ipynb
      02_ppp_mom_sent_proxy.ipynb
      03_rolling_granger_bootstrap.ipynb
      04_nonlinear_activation_martin.ipynb
      05_jpm_trend_overlay.ipynb
      06_comomentum_partialcorr.ipynb
      07_short_term_momentum_spanning.ipynb
    outputs/
      logs/
      perf/
      plots/
      tables/
```

- **必須**: すべての成果物（csv/png/md/log）は `outputs/` 配下に保存。
- **禁止**: 依存追加。必要なら「提案のみ」。  
- **先読み排除**: 月末で決めたウェイトは **翌営業日から適用**（後述の Timing 仕様を厳守）。

---

## 2. Input data contract (prices.csv)

### 2.1 File
- Path: `/mnt/data/prices.csv`

### 2.2 Observed format (重要)
このCSVは、yfinance由来の「フィールド×ティッカー」の **擬似MultiIndex** が **崩れた形**で保存されている。

- 0行目: ティッカー行（各列の ticker が文字列で入っている）
- 1行目: `Date` 等のラベル行（捨て）
- 2行目以降: 実データ（日次）

> したがって「通常の header=[0,1] 読み込み」は前提にしない。

### 2.3 Parsing output (canonical)
パースの結果は下記の **panel形式**を標準にする：

- `panel: dict[str, pd.DataFrame]`
  - key: `"adj_close"`, `"close"`, `"open"`, `"high"`, `"low"`, `"volume"` など（存在するものだけ）
  - value: `DataFrame(index=date, columns=ticker, dtype=float)`

最低限 `panel["adj_close"]` があれば全ノートは動く。

---

## 3. Shared functions (全ノートブック共通で**同一コード**を転記)

> すべて notebook 内に定義し、各 notebook の先頭セルで完結させる。

### 3.1 `load_prices_csv(path) -> dict[field, DataFrame]`
**仕様**
1. `pd.read_csv(path)` で生読み（ヘッダはそのまま）
2. `ticker_row = df.iloc[0]` を保持
3. 1行目（ラベル行）は破棄
4. 2行目以降をデータとして扱う
5. `Date` は `df.iloc[2:, 0]` を `pd.to_datetime` して index にする
6. 残り列は「列名から field を抽出」「ticker_row から ticker を抽出」
7. field 名は正規化：
   - `"Adj Close"` → `"adj_close"`
   - `"Close"` → `"close"` 等（lower_snake）
8. 値は `pd.to_numeric(errors="coerce")`

**Validation (必須ログ)**
- `panel.keys()`、ticker数、期間（min/max date）
- tickerごとの有効開始日/終了日（NaNでない最初/最後）
- `adj_close` の欠損率上位ティッカー一覧

### 3.2 `to_month_end(px_d) -> px_m`
- 日次 `px_d` を月末（`"ME"`）にサンプル
- `px_d.resample("ME").last()`（営業日月末の最終取引日を採用）

### 3.3 `returns_from_prices(px) -> ret`
- `ret = px.pct_change()`
- 月次も日次も同じ関数でOK

### 3.4 Execution timing (先読み排除の統一)
**月次で `w_target` を決める** → **翌営業日から日次で適用**。

- `rebalance_dates = px_m.index`（月末の取引日）
- `w_target` は index=rebalance_dates
- 日次への展開：
  - 各 `t`（月末）で決めた `w_target.loc[t]` を
  - 次の取引日 `t_next = next_trading_day(t)` から
  - 次のリバランス日まで `ffill` で保持

> 重要: **shift(1) を“月次系列のまま”やると二重ラグになりやすい**  
> ここでは必ず「月末 → 翌営業日」へのマッピング関数で実装する。

### 3.5 `apply_portfolio(ret_d, w_target, cost_bps=0.0) -> dict`
**Inputs**
- `ret_d`: 日次リターン（date×ticker）
- `w_target`: 月末で決めたターゲット（rebalance_date×ticker）
- `cost_bps`: 取引コスト（片道、bps）

**Process**
1. `w_applied_d`: 日次に展開（3.4）
2. turnover: `sum(|w_t - w_{t-1}|)`（日次で計測、初日は0）
3. cost: `cost = (cost_bps/1e4) * sum(|w_t - w_{t-1}|)`
4. portfolio return: `r_p = sum(w_applied_d.shift(1) * ret_d)`  ※当日リターンは前日保有で得る
5. net return: `r_net = r_p - cost`
6. nav: `nav = (1 + r_net).cumprod()`

**Outputs**
- `nav`, `ret_net`, `turnover`, `cost`, `w_applied_d`

### 3.6 `metrics(nav, ret_d_or_m) -> dict`
- CAGR, vol, Sharpe, MaxDD, Calmar, skew/kurt（可能なら）
- すべて年率換算（freqは引数で）

### 3.7 Output saving (必須)
- `outputs/perf/*.csv`: nav, ret, turnover, cost
- `outputs/plots/*.png`: nav, dd, weight heatmap（tickers少なら）
- `outputs/logs/*.md`: run config + validation summary

---

## 4. Notebook 00 — Parse & panel sanity (必須)

### File
- `notebooks/00_parse_prices_and_panel.ipynb`

### Goal
- `prices.csv` を canonical panel に変換し、以後のノートが参照する `panel.pkl`（or parquet）を作る。

### Outputs
- `outputs/tables/panel_summary.csv`（欠損率、開始/終了日）
- `outputs/logs/00_parse_validation.md`

### Success criteria
- `adj_close` が date×ticker の float DataFrame になっている
- 月末サンプル `px_m` が作れる
- 欠損の多いティッカーを除外できる `UNIVERSE_FILTER` を config 化

---

## 5. Notebook 01 — Understanding Momentum & Reversal (β proxy)

### File
- `01_umr_beta_proxy.ipynb`

### Objective (price-only proxy)
「モメンタムが将来βを予測する」をETFで簡易追試。

### Inputs
- `adj_close`（必須）
- market proxy ticker: `SPY`（なければ equal-weight market proxy）

### Feature
- Momentum: 12-2（configで変更可）
  - `mom12_2[t,i] = px_m[t-2]/px_m[t-12] - 1`

### Beta estimation
- Daily rolling OLS over window `W` trading days（63 or 252）
  - `r_i = a + b * r_mkt + e`
- `beta_d` → 月末にサンプルして `beta_m`

### Regression
- horizons `h = {1,3,6,12}` months
- panel regression:
  - `beta_m[t+h,i] = α_h + γ_h * mom12_2[t,i] + ε`
- 出力：`γ_h` と t-stats（簡易NW）

### Outputs
- `outputs/tables/umr_beta_panel_reg.csv`
- `outputs/plots/umr_gamma_by_h.png`
- `outputs/logs/01_umr.md`

---

## 6. Notebook 02 — PPP with momentum×sentiment (sentiment proxy)

### File
- `02_ppp_mom_sent_proxy.ipynb`

### Objective
PPP風のポートフォリオ方策を、price-only proxy sentimentで実装。

### Sentiment proxy (choose 1; config)
- `sent[t] = zscore(mom6m_SPY[t] - mom6m_TLT[t])`  (risk-on proxy)
- 代替: `sent[t] = -zscore(vol_ewma_SPY[t])`

### Winner selection
- momentum winners: past `L_form` months cumulative return top `p%`
- momentum×sent winners:
  - (A) **regime gating**: sent[t] が高いときのみ momentum を強める
  - (B) **two-stage**: momentum上位q% → その中で（proxyが銘柄別でないので）等扱い

### Policy optimization (QP)
毎月 t に `w_t` を解く：

min_w 0.5 w^T Σ_t w - η w^T m_t + γ ||w - w_{t-1}||_2^2

- `Σ_t`: lookback `L_cov` months covariance（shrink optional）
- `m_t`: winner indicator vector（winner=1/Nw, else 0）
- constraints:
  - long-only: `w>=0`, `sum(w)=1`
  - optional long-short: `sum(|w|)<=lev`, `sum(w)=0`

**Solver**
- 依存追加なし前提：projected gradient descent（PGD）
  - simplex projection（long-only）
  - L1-ball projection（long-short）

### Benchmarks (必須比較)
1. Equal-weight（EQW）
2. Min-variance（MV）
3. PPP-Mom
4. PPP-Mom×Sent proxy

### Outputs
- `outputs/perf/ppp_*.csv`
- `outputs/plots/ppp_nav_compare.png`
- `outputs/tables/ppp_metrics.csv`
- `outputs/logs/02_ppp.md`

---

## 7. Notebook 03 — Rolling bootstrap Granger (Mom ↔ Sent proxy)

### File
- `03_rolling_granger_bootstrap.ipynb`

### Objective
Mom戦略リターンとsent proxyのGranger因果をrollingで可視化。

### Mom strategy series
- monthly cross-sectional LS:
  - formation `L_form=6` months (or 12-2)
  - long top k, short bottom k（ETF数が少ないので k=2 など）
- optional: 6-month overlapping holding（config）

### VAR and Granger
- rolling window: 36 months
- lag order p: fixed {1,2,3} or AIC
- Wald test for:
  - Sent → Mom
  - Mom → Sent

### Bootstrap p-value
- residual bootstrap（依存追加なし）

### Outputs
- `outputs/tables/granger_rolling.csv`
- `outputs/plots/granger_pvalues.png`
- `outputs/logs/03_granger.md`

---

## 8. Notebook 04 — Martin (nonlinear activation momentum)

### File
- `04_nonlinear_activation_martin.ipynb`

### Objective
EMA momentum と activation の設計比較（Sharpe & skew）。

### Activations
- linear / sign / dead-zone / sigmoid(tanh)

### Outputs
- `outputs/tables/activation_metrics.csv`
- `outputs/plots/deadzone_sweep.png`
- `outputs/logs/04_activation.md`

---

## 9. Notebook 05 — JPM trend overlay

### File
- `05_jpm_trend_overlay.ipynb`

### Objective
Cross-asset trend with overlays: multi-horizon, vol targeting, stop.

### Outputs
- `outputs/tables/jpm_metrics.csv`
- `outputs/plots/jpm_nav_compare.png`
- `outputs/logs/05_jpm.md`

---

## 10. Notebook 06 — Comomentum (partial correlation)

### File
- `06_comomentum_partialcorr.ipynb`

### Objective
Loser集合の平均部分相関で局面分割し、mom成績差を見る。

### Outputs
- `outputs/tables/comom_series.csv`
- `outputs/tables/mom_by_comom_bucket.csv`
- `outputs/plots/comom_and_nav.png`
- `outputs/logs/06_comom.md`

---

## 11. Notebook 07 — Short-term momentum (STMOM) + spanning

### File
- `07_short_term_momentum_spanning.ipynb`

### Objective
STMOM と中期mom のspanning回帰でαを見る。

### Outputs
- `outputs/tables/spanning_reg.csv`
- `outputs/plots/stmom_nav_compare.png`
- `outputs/logs/07_stmom.md`

---

## 12. Config example

```python
CONFIG = {
  "universe_min_coverage": 0.7,
  "rebalance": "ME",
  "cost_bps": 5.0,

  "mom_lookback_m": 12,
  "mom_skip_m": 1,
  "mom_form_m": 6,

  "beta_window_d": 252,

  "cov_lookback_m": 36,
  "ppp_eta": 2.0,
  "ppp_gamma": 10.0,

  "granger_window_m": 36,
  "granger_lags": 2,
  "bootstrap_B": 500,

  "activation_span": 63,
  "deadzone_eps_grid": [0.0,0.2,0.4,0.6,0.8,1.0],

  "trend_horizons_m": [1,3,12],
  "vol_ewma_span": 63,
  "dd_stop": 0.2,
  "stop_scale": 0.5,
}
```

---

## 13. Definition of Done (DoD)

各 notebook について：

1. `outputs/logs/<nb>.md` に **入力検証**（ticker/期間/欠損/採用ユニバース）と **パラメータ**を記録  
2. `outputs/perf/` に nav と（少なくとも）日次リターンを保存  
3. `outputs/plots/` に nav 比較（最低1枚）を保存  
4. 先読み排除がタイミング検査で確認できる（適用開始日をログに残す）
