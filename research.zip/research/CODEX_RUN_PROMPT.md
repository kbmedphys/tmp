# Codex 実行プロンプト（コピペ用）

あなたはこのプロジェクトの実装担当です。最初に必ず workspace 直下の AGENTS.md を読み、すべてのルールに従ってください。
- 依存追加は禁止（必要なら提案のみ）
- 変更は incremental（広範囲リファクタ禁止）
- 出力は outputs/ 配下
- 説明は日本語

## 目的
添付の `IMPLEMENTATION_SPEC_momentum_papers.md` に従い、`/mnt/data/prices.csv` を入力として、
notebooks/ 配下に 00〜07 の8本の ipynb を作成し、それぞれ先頭から実行して outputs を生成できる状態にする。

## 最重要（先読み排除）
月末で決めたターゲットウェイトは **翌営業日から適用**する。月次 series の shift で済ませないこと。
必ず「月末→翌営業日」のマッピングを実装し、ログに証拠（適用開始日一覧）を残す。

## 実装手順（厳守）
1) `notebooks/00_parse_prices_and_panel.ipynb` を作成し、prices.csv のパース関数と検証ログを完成させる。
   - 成果物：outputs/logs/00_parse_validation.md, outputs/tables/panel_summary.csv
2) 次に 01〜07 を **1本ずつ**作成し、各ノートが単独で完走することを確認する（外部 src 呼び出し禁止）。
3) 各ノートは共通関数（load, to_month_end, apply_portfolio, metrics 等）をノート内に転記する。
4) 各ノート実行後に outputs が更新されたことを確認し、ログに「完走した」証拠（主要ファイル名）を残す。

## 追加要件
- ETF本数が少ない場合でも落ちないように、k（top/bottom）や lookback が小さいケースを許容する。
- 欠損が多いティッカーは config に従い自動除外し、除外理由をログに出す。
- すべての図は outputs/plots に保存（plt.show() だけで終わらせない）。

以上。
