"""Daily TSFM engine for an integrated existing + purified-theme universe.

Candidate signals are updated daily.  Actual holdings are updated only on
configured daily, weekly, or monthly rebalance dates.  Between rebalances, the
last executed stock mimicking matrix, theme-basket mapping, basket constituent
matrix, factor weights, and scale are held fixed.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Literal, Mapping, Sequence

import numpy as np
import pandas as pd

from integrated_factor_replication import (
    INTEGRATED_REPLICATION_SCHEMA_VERSION,
    IntegratedFactorBundle,
    calendar_month_window,
    has_calendar_history,
    matrix_dict_to_long,
    normalize_factor_weights,
    one_way_turnover,
    stable_json_hash,
    write_table_with_fallback,
)


INTEGRATED_STRATEGY_SCHEMA_VERSION = "2.0.0-integrated-daily"


@dataclass
class IntegratedStrategyConfig:
    # Factor return and signal universe
    factor_return_source: Literal[
        "combined_hybrid_replicated",
        "combined_stock_replicated",
        "combined_model",
        "external_mixed",
    ] = "combined_hybrid_replicated"
    signal_universe: str | list[str] = "combined"
    factor_weighting_mode: Literal["factor_equal", "block_equal", "custom_block"] = "factor_equal"
    block_gross_targets: dict[str, float] | None = None
    factor_gross_target: float = 1.0

    # Implementation
    implementation_mode: Literal[
        "unified_stock", "hybrid_theme_basket", "direct_factor_instruments"
    ] = "hybrid_theme_basket"
    strategy_scale_mode: Literal["none", "lookthrough_stock_gross"] = "lookthrough_stock_gross"
    target_lookthrough_stock_gross: float = 1.0

    # Daily signal windows
    formation_months: int = 12
    min_history_months: int = 12
    formation_min_coverage: float = 0.98
    volatility_lookback_months: int = 36
    vol_min_observations: int = 252
    factor_vol_floor: float = 1e-8

    # Quality policy
    allow_soft_theme_basket_fallback: bool = True
    allowed_stock_solver_status: tuple[str, ...] = ("solved", "approximate")
    allowed_hard_basket_solver_status: tuple[str, ...] = ("hard_solved", "hard_solved_pinv")
    max_stock_target_exposure_error: float = 1e-5
    max_stock_control_exposure: float = 1e-5
    max_theme_target_exposure_error: float | None = None
    max_theme_existing_factor_contamination: float | None = None
    max_theme_control_exposure: float | None = None
    min_factor_return_coverage: float = 0.98

    # Rebalance
    rebalance_frequency: Literal["daily", "weekly", "monthly"] = "monthly"
    weekly_anchor: str = "W-FRI"

    # Execution and costs
    execution_model: Literal["lookthrough_stock", "hybrid_separate_instruments"] = "lookthrough_stock"
    stock_transaction_cost_bps_one_way: float = 10.0
    basket_transaction_cost_bps_one_way: float = 10.0
    missing_return_policy: Literal["propagate_nan", "coverage_threshold"] = "coverage_threshold"
    min_return_coverage: float = 0.98

    # Diagnostics and persistence
    annualization: int = 252
    return_identity_tolerance: float = 1e-10
    rolling_metric_observations: int = 252
    save_held_stock_weights: bool = True
    save_theme_basket_weights: bool = True


StrategyConfig = IntegratedStrategyConfig


@dataclass
class IntegratedHeldState:
    rebalance_date: pd.Timestamp
    factor_weights: pd.Series
    scaled_factor_weights: pd.Series
    factor_metadata: pd.DataFrame
    M_existing: pd.DataFrame
    M_all: pd.DataFrame
    H_theme: pd.DataFrame
    P_theme: pd.DataFrame
    existing_stock_weights: pd.Series
    theme_basket_weights: pd.Series
    theme_lookthrough_stock_weights: pd.Series
    total_lookthrough_stock_weights: pd.Series
    scale: float
    quality: pd.DataFrame


# ---------------------------------------------------------------------------
# Date and metadata helpers
# ---------------------------------------------------------------------------


def make_rebalance_dates(
    index: pd.DatetimeIndex,
    cfg: IntegratedStrategyConfig,
) -> pd.DatetimeIndex:
    idx = pd.DatetimeIndex(index).sort_values().unique()
    if cfg.rebalance_frequency == "daily":
        return idx
    series = pd.Series(idx, index=idx)
    if cfg.rebalance_frequency == "weekly":
        periods = idx.to_period(cfg.weekly_anchor)
    elif cfg.rebalance_frequency == "monthly":
        periods = idx.to_period("M")
    else:
        raise ValueError(f"Unknown rebalance_frequency: {cfg.rebalance_frequency}")
    return pd.DatetimeIndex(series.groupby(periods).last().to_numpy()).sort_values()


def _latest_dict_value(
    values: Mapping[pd.Timestamp, Any], date: pd.Timestamp, name: str
) -> Any:
    date = pd.Timestamp(date)
    if date in values:
        return values[date]
    keys = pd.DatetimeIndex(sorted(pd.Timestamp(k) for k in values))
    eligible = keys[keys <= pd.Timestamp(date)]
    if eligible.empty:
        raise KeyError(f"No {name} available on or before {date}")
    return values[pd.Timestamp(eligible[-1])]


def _metadata_at(bundle: IntegratedFactorBundle, date: pd.Timestamp) -> pd.DataFrame:
    return _latest_dict_value(bundle.factor_metadata_by_date, date, "factor metadata").copy()


def _replication_diagnostic_lookup(
    bundle: IntegratedFactorBundle,
) -> dict[str, dict[pd.Timestamp, pd.DataFrame]]:
    """Build a date/layer lookup once per bundle.

    The strategy loop is daily and can run several comparison variants.  Re-parsing
    and filtering the full long diagnostics table for every date dominates runtime
    on multi-year daily data.  The cache is purely an indexing optimization and does
    not change the point-in-time selection rule.
    """
    cached = getattr(bundle, "_strategy_replication_diagnostic_lookup", None)
    if cached is not None:
        return cached

    output: dict[str, dict[pd.Timestamp, pd.DataFrame]] = {
        "stock": {},
        "theme_basket": {},
    }
    diagnostics = bundle.replication_diagnostics
    if diagnostics is not None and not diagnostics.empty:
        required = {"replication_layer", "exposure_date", "factor_id"}
        if required.issubset(diagnostics.columns):
            work = diagnostics.copy()
            work["exposure_date"] = pd.to_datetime(work["exposure_date"])
            work = work.loc[work["factor_id"].notna()].copy()
            for (layer, exposure_date), group in work.groupby(
                ["replication_layer", "exposure_date"], sort=False, dropna=False
            ):
                layer_name = str(layer)
                if layer_name not in output:
                    continue
                indexed = (
                    group.drop_duplicates(subset=["factor_id"], keep="last")
                    .set_index("factor_id")
                    .sort_index()
                )
                output[layer_name][pd.Timestamp(exposure_date)] = indexed
    setattr(bundle, "_strategy_replication_diagnostic_lookup", output)
    return output


def _replication_diagnostics_at(
    bundle: IntegratedFactorBundle,
    date: pd.Timestamp,
    layer: str,
) -> pd.DataFrame:
    mapping = _replication_diagnostic_lookup(bundle).get(layer, {})
    if not mapping:
        return pd.DataFrame()
    date = pd.Timestamp(date)
    if date in mapping:
        return mapping[date]
    keys = pd.DatetimeIndex(sorted(mapping))
    eligible = keys[keys <= date]
    if eligible.empty:
        return pd.DataFrame()
    return mapping[pd.Timestamp(eligible[-1])]


def _return_source(bundle: IntegratedFactorBundle, cfg: IntegratedStrategyConfig) -> pd.DataFrame:
    if cfg.factor_return_source == "external_mixed":
        stock = bundle.factor_returns_by_source.get("combined_stock_replicated")
        external = bundle.factor_returns_by_source.get("external_existing")
        if stock is None or external is None:
            raise KeyError("external_mixed requires external_existing and combined_stock_replicated")
        out = stock.copy()
        common = out.columns.intersection(external.columns)
        out.loc[:, common] = external.reindex(out.index)[common]
        return out
    key = cfg.factor_return_source
    if key not in bundle.factor_returns_by_source:
        raise KeyError(f"Factor return source not found: {key}")
    return bundle.factor_returns_by_source[key].copy()


def _filter_signal_universe(meta: pd.DataFrame, signal_universe: str | list[str]) -> pd.Index:
    base = meta.index[
        meta["effective_role"].eq("investable_signal")
        & meta["signal_enabled"].astype(bool)
    ]
    if isinstance(signal_universe, (list, tuple, set)):
        return base.intersection(pd.Index([str(x) for x in signal_universe]))
    if signal_universe == "combined":
        return base
    if signal_universe == "existing_only":
        return base.intersection(meta.index[meta["factor_type"].eq("existing")])
    if signal_universe == "theme_only":
        return base.intersection(meta.index[meta["factor_type"].eq("theme")])
    raise ValueError(f"Unknown signal_universe: {signal_universe}")


# ---------------------------------------------------------------------------
# Signals and factor allocation
# ---------------------------------------------------------------------------


def _formation_window(
    factor_history: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: IntegratedStrategyConfig,
) -> pd.DataFrame:
    return calendar_month_window(
        factor_history, signal_date, cfg.formation_months, include_end=True
    )


def _allocate_factor_weights(
    raw: pd.Series,
    metadata: pd.DataFrame,
    cfg: IntegratedStrategyConfig,
) -> pd.Series:
    raw = raw.replace([np.inf, -np.inf], np.nan).dropna().astype(float)
    if raw.empty:
        return pd.Series(0.0, index=metadata.index)
    full = pd.Series(0.0, index=metadata.index, dtype=float)
    if cfg.factor_weighting_mode == "factor_equal":
        full.loc[raw.index] = normalize_factor_weights(raw, cfg.factor_gross_target)
        return full

    blocks = metadata.loc[raw.index, "block_id"].astype(str)
    active_blocks = list(dict.fromkeys(blocks.tolist()))
    if not active_blocks:
        return full
    if cfg.factor_weighting_mode == "block_equal":
        targets = {block: cfg.factor_gross_target / len(active_blocks) for block in active_blocks}
    elif cfg.factor_weighting_mode == "custom_block":
        if not cfg.block_gross_targets:
            raise ValueError("custom_block requires block_gross_targets")
        specified = {b: float(cfg.block_gross_targets.get(b, 0.0)) for b in active_blocks}
        total = sum(max(v, 0.0) for v in specified.values())
        if total <= 0:
            raise ValueError("No positive custom block gross target for active blocks")
        targets = {b: cfg.factor_gross_target * max(v, 0.0) / total for b, v in specified.items()}
    else:
        raise ValueError(f"Unknown factor_weighting_mode: {cfg.factor_weighting_mode}")
    for block in active_blocks:
        members = blocks.index[blocks.eq(block)]
        full.loc[members] = normalize_factor_weights(raw.reindex(members), targets[block])
    return full


def binary_tsfm_12m_signal(
    factor_history: pd.DataFrame,
    factor_metadata: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: IntegratedStrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    signal_date = pd.Timestamp(signal_date)
    eligible_ids = _filter_signal_universe(factor_metadata, cfg.signal_universe)
    window = _formation_window(factor_history, signal_date, cfg)
    rows: list[dict[str, Any]] = []
    raw = pd.Series(dtype=float)
    if not has_calendar_history(pd.DatetimeIndex(factor_history.index), signal_date, cfg.min_history_months):
        full = pd.Series(0.0, index=factor_metadata.index)
        for factor in factor_metadata.index:
            rows.append({"factor_id": factor, "signal_date": signal_date, "signal_status": "insufficient_calendar_history", "factor_weight": 0.0})
        return full, pd.DataFrame(rows)

    raw_values: dict[str, float] = {}
    for factor in factor_metadata.index:
        series = window[factor] if factor in window.columns else pd.Series(dtype=float)
        coverage = float(series.notna().mean()) if len(series) else 0.0
        complete = coverage >= cfg.formation_min_coverage
        formation = float((1.0 + series.dropna()).prod() - 1.0) if complete and len(series.dropna()) else np.nan
        sign = float(np.sign(formation)) if np.isfinite(formation) else np.nan
        status = "eligible" if factor in eligible_ids and complete and sign != 0 else (
            "not_in_signal_universe" if factor not in eligible_ids else
            "incomplete_formation_history" if not complete else
            "zero_or_missing_signal"
        )
        if status == "eligible":
            raw_values[factor] = sign
        rows.append(
            {
                "factor_id": factor,
                "signal_date": signal_date,
                "factor_type": factor_metadata.loc[factor, "factor_type"],
                "block_id": factor_metadata.loc[factor, "block_id"],
                "formation_return": formation,
                "formation_coverage": coverage,
                "signal": sign,
                "raw_weight": sign if status == "eligible" else np.nan,
                "signal_status": status,
            }
        )
    raw = pd.Series(raw_values, dtype=float)
    weights = _allocate_factor_weights(raw, factor_metadata, cfg)
    table = pd.DataFrame(rows).set_index("factor_id")
    table["factor_weight"] = weights
    return weights, table.reset_index()


def vol_scaled_tsfm_signal(
    factor_history: pd.DataFrame,
    factor_metadata: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: IntegratedStrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    signal_date = pd.Timestamp(signal_date)
    eligible_ids = _filter_signal_universe(factor_metadata, cfg.signal_universe)
    formation_window = _formation_window(factor_history, signal_date, cfg)
    vol_window = calendar_month_window(
        factor_history, signal_date, cfg.volatility_lookback_months, include_end=True
    )
    rows: list[dict[str, Any]] = []
    raw_values: dict[str, float] = {}
    if not has_calendar_history(pd.DatetimeIndex(factor_history.index), signal_date, cfg.min_history_months):
        full = pd.Series(0.0, index=factor_metadata.index)
        for factor in factor_metadata.index:
            rows.append({"factor_id": factor, "signal_date": signal_date, "signal_status": "insufficient_calendar_history", "factor_weight": 0.0})
        return full, pd.DataFrame(rows)

    for factor in factor_metadata.index:
        formation_series = formation_window[factor] if factor in formation_window.columns else pd.Series(dtype=float)
        coverage = float(formation_series.notna().mean()) if len(formation_series) else 0.0
        complete = coverage >= cfg.formation_min_coverage
        formation = float((1.0 + formation_series.dropna()).prod() - 1.0) if complete and len(formation_series.dropna()) else np.nan
        sign = float(np.sign(formation)) if np.isfinite(formation) else np.nan
        vol_series = vol_window[factor].dropna() if factor in vol_window.columns else pd.Series(dtype=float)
        vol_nobs = len(vol_series)
        daily_vol = float(vol_series.std(ddof=1)) if vol_nobs > 1 else np.nan
        annualized_vol = daily_vol * np.sqrt(cfg.annualization) if np.isfinite(daily_vol) else np.nan
        vol_ok = vol_nobs >= cfg.vol_min_observations and np.isfinite(daily_vol) and daily_vol > cfg.factor_vol_floor
        status = "eligible" if factor in eligible_ids and complete and sign != 0 and vol_ok else (
            "not_in_signal_universe" if factor not in eligible_ids else
            "incomplete_formation_history" if not complete else
            "zero_or_missing_signal" if sign == 0 or not np.isfinite(sign) else
            "insufficient_volatility_history"
        )
        raw_weight = sign / daily_vol if status == "eligible" else np.nan
        if status == "eligible":
            raw_values[factor] = raw_weight
        rows.append(
            {
                "factor_id": factor,
                "signal_date": signal_date,
                "factor_type": factor_metadata.loc[factor, "factor_type"],
                "block_id": factor_metadata.loc[factor, "block_id"],
                "formation_return": formation,
                "formation_coverage": coverage,
                "signal": sign,
                "daily_vol": daily_vol,
                "annualized_vol": annualized_vol,
                "vol_nobs": vol_nobs,
                "raw_weight": raw_weight,
                "signal_status": status,
            }
        )
    weights = _allocate_factor_weights(pd.Series(raw_values, dtype=float), factor_metadata, cfg)
    table = pd.DataFrame(rows).set_index("factor_id")
    table["factor_weight"] = weights
    return weights, table.reset_index()


# ---------------------------------------------------------------------------
# Point-in-time quality and candidate holdings
# ---------------------------------------------------------------------------


def eligible_factors_at_date(
    bundle: IntegratedFactorBundle,
    signal_date: pd.Timestamp,
    signal_table: pd.DataFrame,
    cfg: IntegratedStrategyConfig,
) -> pd.DataFrame:
    date = pd.Timestamp(signal_date)
    meta = _metadata_at(bundle, date)
    base = signal_table.set_index("factor_id").copy()
    quality = pd.DataFrame(index=meta.index)
    quality["factor_id"] = quality.index
    quality["factor_type"] = meta["factor_type"]
    quality["block_id"] = meta["block_id"]
    quality["signal_enabled"] = meta["signal_enabled"].astype(bool)
    quality["signal_status"] = base["signal_status"].reindex(quality.index)
    quality["return_history_complete"] = quality["signal_status"].eq("eligible")

    stock_idx = _replication_diagnostics_at(bundle, date, "stock")
    basket_idx = _replication_diagnostics_at(bundle, date, "theme_basket")

    rows = []
    for factor in quality.index:
        factor_type = meta.loc[factor, "factor_type"]
        stock_status = stock_idx.loc[factor, "solver_status"] if not stock_idx.empty and factor in stock_idx.index else "missing"
        stock_target = abs(float(stock_idx.loc[factor, "target_exposure_error"])) if not stock_idx.empty and factor in stock_idx.index else np.inf
        stock_control = abs(float(stock_idx.loc[factor, "max_control_exposure"])) if not stock_idx.empty and factor in stock_idx.index else np.inf
        stock_ok = (
            stock_status in cfg.allowed_stock_solver_status
            and stock_target <= cfg.max_stock_target_exposure_error
            and stock_control <= cfg.max_stock_control_exposure
        )
        basket_status = "not_applicable"
        basket_target = 0.0
        basket_existing = 0.0
        basket_control = 0.0
        basket_ok = True
        if factor_type == "theme" and cfg.implementation_mode == "hybrid_theme_basket":
            if not basket_idx.empty and factor in basket_idx.index:
                basket_status = str(basket_idx.loc[factor, "solver_status"])
                basket_target = abs(float(basket_idx.loc[factor, "target_exposure_error"]))
                basket_existing = abs(float(basket_idx.loc[factor, "max_existing_factor_contamination"]))
                basket_control = abs(float(basket_idx.loc[factor, "max_control_exposure"]))
                allowed = basket_status in cfg.allowed_hard_basket_solver_status or (
                    cfg.allow_soft_theme_basket_fallback and basket_status.startswith("soft_")
                )
                basket_ok = allowed
                if cfg.max_theme_target_exposure_error is not None:
                    basket_ok &= basket_target <= cfg.max_theme_target_exposure_error
                if cfg.max_theme_existing_factor_contamination is not None:
                    basket_ok &= basket_existing <= cfg.max_theme_existing_factor_contamination
                if cfg.max_theme_control_exposure is not None:
                    basket_ok &= basket_control <= cfg.max_theme_control_exposure
            else:
                basket_status = "missing"
                basket_ok = False
        implementation_ok = stock_ok if cfg.implementation_mode == "unified_stock" or factor_type == "existing" else basket_ok
        signal_ok = quality.loc[factor, "return_history_complete"] and quality.loc[factor, "signal_enabled"]
        eligible = bool(signal_ok and implementation_ok)
        reason = "" if eligible else (
            "signal_history_or_metadata" if not signal_ok else
            "stock_mimicking_quality" if not stock_ok and (cfg.implementation_mode == "unified_stock" or factor_type == "existing") else
            "theme_basket_quality"
        )
        rows.append(
            {
                "signal_date": date,
                "factor_id": factor,
                "factor_type": factor_type,
                "block_id": meta.loc[factor, "block_id"],
                "stock_solver_status": stock_status,
                "stock_target_exposure_error": stock_target,
                "stock_control_exposure": stock_control,
                "theme_basket_solver_status": basket_status,
                "theme_target_exposure_error": basket_target,
                "existing_factor_contamination": basket_existing,
                "theme_control_exposure": basket_control,
                "signal_eligible": bool(signal_ok),
                "implementation_eligible": bool(implementation_ok),
                "eligible": eligible,
                "exclusion_reason": reason,
            }
        )
    return pd.DataFrame(rows)


def construct_integrated_strategy_weights(
    bundle: IntegratedFactorBundle,
    signal_date: pd.Timestamp,
    factor_weights: pd.Series,
    quality: pd.DataFrame,
    cfg: IntegratedStrategyConfig,
) -> IntegratedHeldState:
    date = pd.Timestamp(signal_date)
    meta = _metadata_at(bundle, date)
    eligible = quality.set_index("factor_id")["eligible"].reindex(factor_weights.index).fillna(False)
    fw = factor_weights.where(eligible, 0.0)
    fw = _allocate_factor_weights(fw[fw.ne(0.0)], meta, cfg)
    if float(fw.abs().sum()) <= 0:
        raise ValueError("no_eligible_factors")
    M_all = _latest_dict_value(bundle.stock_mimicking_weights_by_date, date, "stock mimicking weights").copy()
    M_all = M_all.reindex(columns=meta.index.intersection(M_all.columns))
    fw = fw.reindex(M_all.columns).fillna(0.0)
    existing_ids = meta.index[meta["factor_type"].eq("existing")].intersection(M_all.columns)
    theme_ids = meta.index[meta["factor_type"].eq("theme")].intersection(M_all.columns)
    M_existing = M_all.reindex(columns=existing_ids)
    all_stocks = M_all.index
    existing_stock = M_existing.dot(fw.reindex(existing_ids).fillna(0.0)) if len(existing_ids) else pd.Series(0.0, index=all_stocks)

    if cfg.implementation_mode == "unified_stock":
        theme_basket = pd.Series(dtype=float)
        H_theme = pd.DataFrame()
        P_theme = pd.DataFrame(index=all_stocks)
        theme_stock = M_all.reindex(columns=theme_ids).dot(fw.reindex(theme_ids).fillna(0.0)) if len(theme_ids) else pd.Series(0.0, index=all_stocks)
        total_stock = M_all.dot(fw)
    elif cfg.implementation_mode == "hybrid_theme_basket":
        H_theme = _latest_dict_value(bundle.theme_basket_mapping_by_date, date, "theme basket mapping").copy()
        P_theme = _latest_dict_value(bundle.theme_basket_constituents_by_date, date, "theme basket constituents").copy()
        active_theme_ids = theme_ids.intersection(H_theme.columns)
        H_theme = H_theme.reindex(columns=active_theme_ids)
        theme_basket = H_theme.dot(fw.reindex(active_theme_ids).fillna(0.0)) if len(active_theme_ids) else pd.Series(0.0, index=H_theme.index)
        theme_stock = P_theme.reindex(columns=theme_basket.index).fillna(0.0).dot(theme_basket)
        total_stock = existing_stock.reindex(all_stocks, fill_value=0.0).add(
            theme_stock.reindex(all_stocks, fill_value=0.0), fill_value=0.0
        )
    else:
        raise ValueError("direct_factor_instruments requires direct instrument input and is not available")

    pre_gross = float(total_stock.abs().sum())
    if cfg.strategy_scale_mode == "none":
        scale = 1.0
    elif cfg.strategy_scale_mode == "lookthrough_stock_gross":
        if pre_gross <= 0:
            raise ValueError("invalid_scale_denominator")
        scale = cfg.target_lookthrough_stock_gross / pre_gross
    else:
        raise ValueError(cfg.strategy_scale_mode)
    return IntegratedHeldState(
        rebalance_date=date,
        factor_weights=fw,
        scaled_factor_weights=fw * scale,
        factor_metadata=meta.copy(),
        M_existing=M_existing.copy(),
        M_all=M_all.copy(),
        H_theme=H_theme.copy(),
        P_theme=P_theme.copy(),
        existing_stock_weights=existing_stock * scale,
        theme_basket_weights=theme_basket * scale,
        theme_lookthrough_stock_weights=theme_stock * scale,
        total_lookthrough_stock_weights=total_stock * scale,
        scale=float(scale),
        quality=quality.copy(),
    )


# ---------------------------------------------------------------------------
# Backtest
# ---------------------------------------------------------------------------


def _covered_dot(
    weights: pd.Series,
    returns: pd.Series,
    cfg: IntegratedStrategyConfig,
) -> tuple[float, float]:
    aligned = returns.reindex(weights.index)
    gross = float(weights.abs().sum())
    if gross <= 0:
        return 0.0, 1.0
    coverage = float(weights.abs().where(aligned.notna(), 0.0).sum() / gross)
    if cfg.missing_return_policy == "propagate_nan" and coverage < 1.0 - 1e-12:
        return np.nan, coverage
    if coverage < cfg.min_return_coverage:
        return np.nan, coverage
    return float(weights[aligned.notna()].dot(aligned.dropna())), coverage


def _held_return_paths(
    held: IntegratedHeldState,
    stock_return: pd.Series,
    cfg: IntegratedStrategyConfig,
) -> tuple[dict[str, float], pd.Series, pd.Series, pd.Series]:
    total_return, total_coverage = _covered_dot(held.total_lookthrough_stock_weights, stock_return, cfg)
    existing_return, existing_coverage = _covered_dot(held.existing_stock_weights, stock_return, cfg)
    theme_look_return, theme_coverage = _covered_dot(held.theme_lookthrough_stock_weights, stock_return, cfg)

    factor_impl = pd.Series(0.0, index=held.scaled_factor_weights.index)
    existing_ids = held.factor_metadata.index[held.factor_metadata["factor_type"].eq("existing")].intersection(factor_impl.index)
    theme_ids = held.factor_metadata.index[held.factor_metadata["factor_type"].eq("theme")].intersection(factor_impl.index)
    if len(existing_ids):
        factor_impl.loc[existing_ids] = held.M_existing.reindex(columns=existing_ids).T.dot(
            stock_return.reindex(held.M_existing.index)
        )
    base_basket_returns = pd.Series(dtype=float)
    if len(theme_ids) and not held.H_theme.empty:
        base_basket_returns = held.P_theme.T.dot(stock_return.reindex(held.P_theme.index))
        factor_impl.loc[theme_ids.intersection(held.H_theme.columns)] = held.H_theme.T.dot(base_basket_returns).reindex(theme_ids).fillna(0.0)
    elif len(theme_ids):
        # Unified-stock implementation: theme factors are represented by their
        # columns in the joint stock-level mimicking matrix.
        factor_impl.loc[theme_ids] = held.M_all.reindex(columns=theme_ids).T.dot(
            stock_return.reindex(held.M_all.index)
        )
    factor_contrib = held.scaled_factor_weights * factor_impl.reindex(held.scaled_factor_weights.index).fillna(0.0)
    factor_path = float(factor_contrib.sum())
    existing_factor_contrib = factor_contrib.reindex(existing_ids).fillna(0.0)
    theme_factor_contrib = factor_contrib.reindex(theme_ids).fillna(0.0)
    basket_contrib = held.theme_basket_weights * base_basket_returns.reindex(held.theme_basket_weights.index).fillna(0.0)
    paths = {
        "gross_return": total_return,
        "factor_path_return": factor_path,
        "existing_factor_pnl": float(existing_factor_contrib.sum()),
        "theme_factor_pnl": float(theme_factor_contrib.sum()),
        "existing_stock_path_return": existing_return,
        "theme_basket_path_return": float(basket_contrib.sum()),
        "theme_lookthrough_path_return": theme_look_return,
        "return_identity_error": abs(factor_path - total_return) if np.isfinite(total_return) else np.nan,
        "theme_identity_error": abs(float(theme_factor_contrib.sum()) - theme_look_return) if np.isfinite(theme_look_return) else np.nan,
        "stock_return_coverage": total_coverage,
        "existing_return_coverage": existing_coverage,
        "theme_return_coverage": theme_coverage,
    }
    return paths, factor_contrib, basket_contrib, factor_impl


def run_integrated_factor_strategy_backtest(
    bundle: IntegratedFactorBundle,
    cfg: IntegratedStrategyConfig,
    signal_func: Callable[[pd.DataFrame, pd.DataFrame, pd.Timestamp, IntegratedStrategyConfig], tuple[pd.Series, pd.DataFrame]],
    *,
    strategy_name: str,
    stock_returns: pd.DataFrame | None = None,
    collect_details: bool = True,
) -> dict[str, Any]:
    factor_returns = _return_source(bundle, cfg).sort_index()
    stock_returns = stock_returns if stock_returns is not None else bundle.stock_returns
    if stock_returns is None:
        raise ValueError("stock_returns are required for strategy backtest")
    stock_returns = stock_returns.copy().sort_index()
    stock_returns.index = pd.to_datetime(stock_returns.index)
    signal_dates = pd.DatetimeIndex(factor_returns.index).intersection(stock_returns.index).sort_values()
    signal_dates = signal_dates[signal_dates < stock_returns.index.max()]
    rebalance_dates = set(make_rebalance_dates(signal_dates, cfg))

    returns_rows: list[dict[str, Any]] = []
    candidate_rows: list[pd.Series] = []
    held_rows: list[pd.Series] = []
    stock_rows: list[pd.Series] = []
    basket_rows: list[pd.Series] = []
    signal_diag_rows: list[pd.DataFrame] = []
    quality_rows: list[pd.DataFrame] = []
    factor_contrib_rows: list[pd.Series] = []
    basket_contrib_rows: list[pd.Series] = []
    block_contrib_rows: list[pd.Series] = []
    turnover_rows: list[dict[str, Any]] = []

    held: IntegratedHeldState | None = None
    previous_total = pd.Series(dtype=float)
    previous_existing = pd.Series(dtype=float)
    previous_theme_basket = pd.Series(dtype=float)
    previous_theme_stock = pd.Series(dtype=float)
    holding_age = 0

    for signal_date in signal_dates:
        signal_date = pd.Timestamp(signal_date)
        next_pos = stock_returns.index.searchsorted(signal_date, side="right")
        if next_pos >= len(stock_returns.index):
            continue
        return_date = pd.Timestamp(stock_returns.index[next_pos])
        meta = _metadata_at(bundle, signal_date)
        history = factor_returns.loc[factor_returns.index <= signal_date]
        candidate_weights, signal_table = signal_func(history, meta, signal_date, cfg)
        quality = eligible_factors_at_date(bundle, signal_date, signal_table, cfg)
        candidate_weights = candidate_weights.where(
            quality.set_index("factor_id")["eligible"].reindex(candidate_weights.index).fillna(False),
            0.0,
        )
        candidate_weights = _allocate_factor_weights(
            candidate_weights[candidate_weights.ne(0.0)], meta, cfg
        )
        if collect_details:
            candidate_rows.append(candidate_weights.rename(signal_date))
            signal_table = signal_table.copy()
            signal_table["signal_date"] = signal_date
            signal_diag_rows.append(signal_table)
            quality_rows.append(quality)

        scheduled = signal_date in rebalance_dates
        executed = False
        candidate_status = "valid" if float(candidate_weights.abs().sum()) > 0 else "no_eligible_factors"
        action = "held"
        new_state: IntegratedHeldState | None = None
        if scheduled and candidate_status == "valid":
            try:
                new_state = construct_integrated_strategy_weights(
                    bundle, signal_date, candidate_weights, quality, cfg
                )
                held = new_state
                executed = True
                action = "rebalanced"
                holding_age = 0
            except Exception as exc:
                candidate_status = f"candidate_error:{type(exc).__name__}:{exc}"
                action = "held_after_failed_rebalance" if held is not None else "no_successful_rebalance_yet"
        elif scheduled:
            action = "held_after_failed_rebalance" if held is not None else "no_successful_rebalance_yet"
        elif held is None:
            action = "no_successful_rebalance_yet"

        if held is None:
            returns_rows.append(
                {
                    "return_date": return_date,
                    "signal_date": signal_date,
                    "strategy": strategy_name,
                    "factor_return_source": cfg.factor_return_source,
                    "signal_universe": str(cfg.signal_universe),
                    "factor_weighting_mode": cfg.factor_weighting_mode,
                    "implementation_mode": cfg.implementation_mode,
                    "rebalance_frequency": cfg.rebalance_frequency,
                    "is_rebalance_date": scheduled,
                    "rebalance_executed": False,
                    "position_action": action,
                    "candidate_status": candidate_status,
                    "status": "no_position",
                }
            )
            continue

        paths, factor_contrib, basket_contrib, factor_impl = _held_return_paths(
            held, stock_returns.loc[return_date], cfg
        )
        if executed:
            total_turnover = one_way_turnover(previous_total, held.total_lookthrough_stock_weights)
            existing_turnover = one_way_turnover(previous_existing, held.existing_stock_weights)
            theme_basket_turnover = one_way_turnover(previous_theme_basket, held.theme_basket_weights)
            theme_stock_turnover = one_way_turnover(previous_theme_stock, held.theme_lookthrough_stock_weights)
            if cfg.execution_model == "lookthrough_stock":
                cost = total_turnover * cfg.stock_transaction_cost_bps_one_way / 10000.0
            elif cfg.execution_model == "hybrid_separate_instruments":
                cost = (
                    existing_turnover * cfg.stock_transaction_cost_bps_one_way
                    + theme_basket_turnover * cfg.basket_transaction_cost_bps_one_way
                ) / 10000.0
            else:
                raise ValueError(cfg.execution_model)
            previous_total = held.total_lookthrough_stock_weights.copy()
            previous_existing = held.existing_stock_weights.copy()
            previous_theme_basket = held.theme_basket_weights.copy()
            previous_theme_stock = held.theme_lookthrough_stock_weights.copy()
        else:
            total_turnover = existing_turnover = theme_basket_turnover = theme_stock_turnover = cost = 0.0
            holding_age += 1

        net_return = paths["gross_return"] - cost if np.isfinite(paths["gross_return"]) else np.nan
        status = "ok" if paths["return_identity_error"] <= cfg.return_identity_tolerance else "return_identity_failure"
        meta_held = held.factor_metadata.reindex(held.scaled_factor_weights.index)
        block_contrib = factor_contrib.groupby(meta_held["block_id"]).sum()
        returns_rows.append(
            {
                "return_date": return_date,
                "signal_date": signal_date,
                "last_rebalance_date": held.rebalance_date,
                "strategy": strategy_name,
                "factor_return_source": cfg.factor_return_source,
                "signal_universe": str(cfg.signal_universe),
                "factor_weighting_mode": cfg.factor_weighting_mode,
                "implementation_mode": cfg.implementation_mode,
                "execution_model": cfg.execution_model,
                "rebalance_frequency": cfg.rebalance_frequency,
                "weekly_anchor": cfg.weekly_anchor,
                "is_rebalance_date": scheduled,
                "rebalance_executed": executed,
                "position_action": action,
                "candidate_status": candidate_status,
                "holding_age_observations": holding_age,
                **paths,
                "transaction_cost": cost,
                "net_return": net_return,
                "total_lookthrough_turnover": total_turnover,
                "existing_stock_turnover": existing_turnover,
                "theme_basket_turnover": theme_basket_turnover,
                "theme_lookthrough_turnover": theme_stock_turnover,
                "factor_gross": float(held.scaled_factor_weights.abs().sum()),
                "existing_factor_gross": float(held.scaled_factor_weights.reindex(meta_held.index[meta_held["factor_type"].eq("existing")]).abs().sum()),
                "theme_factor_gross": float(held.scaled_factor_weights.reindex(meta_held.index[meta_held["factor_type"].eq("theme")]).abs().sum()),
                "stock_gross": float(held.total_lookthrough_stock_weights.abs().sum()),
                "stock_net": float(held.total_lookthrough_stock_weights.sum()),
                "existing_stock_gross": float(held.existing_stock_weights.abs().sum()),
                "theme_lookthrough_gross": float(held.theme_lookthrough_stock_weights.abs().sum()),
                "theme_basket_gross": float(held.theme_basket_weights.abs().sum()),
                "scale_factor": held.scale,
                "n_long_factors": int((held.scaled_factor_weights > 1e-12).sum()),
                "n_short_factors": int((held.scaled_factor_weights < -1e-12).sum()),
                "n_long_stocks": int((held.total_lookthrough_stock_weights > 1e-12).sum()),
                "n_short_stocks": int((held.total_lookthrough_stock_weights < -1e-12).sum()),
                "n_long_baskets": int((held.theme_basket_weights > 1e-12).sum()),
                "n_short_baskets": int((held.theme_basket_weights < -1e-12).sum()),
                "status": status,
            }
        )
        if collect_details:
            held_rows.append(held.scaled_factor_weights.rename(return_date))
            stock_rows.append(held.total_lookthrough_stock_weights.rename(return_date))
            basket_rows.append(held.theme_basket_weights.rename(return_date))
            factor_contrib_rows.append(factor_contrib.rename(return_date))
            basket_contrib_rows.append(basket_contrib.rename(return_date))
            block_contrib_rows.append(block_contrib.rename(return_date))
            turnover_rows.append(
                {
                    "return_date": return_date,
                    "signal_date": signal_date,
                    "rebalance_executed": executed,
                    "total_lookthrough_turnover": total_turnover,
                    "existing_stock_turnover": existing_turnover,
                    "theme_basket_turnover": theme_basket_turnover,
                    "theme_lookthrough_turnover": theme_stock_turnover,
                    "transaction_cost": cost,
                }
            )

    returns = pd.DataFrame(returns_rows)
    if not returns.empty:
        returns = returns.set_index("return_date").sort_index()
    return {
        "strategy_name": strategy_name,
        "config": cfg,
        "returns": returns,
        "candidate_factor_weights": pd.DataFrame(candidate_rows).sort_index(),
        "held_factor_weights": pd.DataFrame(held_rows).sort_index(),
        "stock_weights": pd.DataFrame(stock_rows).sort_index(),
        "theme_basket_weights": pd.DataFrame(basket_rows).sort_index(),
        "signal_diagnostics": pd.concat(signal_diag_rows, ignore_index=True) if signal_diag_rows else pd.DataFrame(),
        "factor_quality_diagnostics": pd.concat(quality_rows, ignore_index=True) if quality_rows else pd.DataFrame(),
        "factor_contributions": pd.DataFrame(factor_contrib_rows).sort_index(),
        "basket_contributions": pd.DataFrame(basket_contrib_rows).sort_index(),
        "block_contributions": pd.DataFrame(block_contrib_rows).sort_index(),
        "turnover_decomposition": pd.DataFrame(turnover_rows).set_index("return_date").sort_index() if turnover_rows else pd.DataFrame(),
    }


# ---------------------------------------------------------------------------
# Comparison, metrics, validation, persistence
# ---------------------------------------------------------------------------


def performance_metrics(
    returns: pd.DataFrame,
    cfg: IntegratedStrategyConfig,
) -> pd.DataFrame:
    rows = []
    for column in [c for c in ["gross_return", "net_return", "existing_factor_pnl", "theme_factor_pnl"] if c in returns]:
        r = returns[column].dropna().astype(float)
        if r.empty:
            continue
        ann_return = float(r.mean() * cfg.annualization)
        ann_vol = float(r.std(ddof=1) * np.sqrt(cfg.annualization)) if len(r) > 1 else np.nan
        wealth = (1.0 + r).cumprod()
        drawdown = wealth / wealth.cummax() - 1.0
        rows.append(
            {
                "series": column,
                "n_obs": len(r),
                "annualized_mean_return": ann_return,
                "annualized_volatility": ann_vol,
                "sharpe": ann_return / ann_vol if np.isfinite(ann_vol) and ann_vol > 0 else np.nan,
                "mean_t_value": float(r.mean() / (r.std(ddof=1) / np.sqrt(len(r)))) if len(r) > 1 and r.std(ddof=1) > 0 else np.nan,
                "max_drawdown": float(drawdown.min()),
                "hit_rate": float((r > 0).mean()),
            }
        )
    return pd.DataFrame(rows)


def run_integrated_strategy_comparison_grid(
    bundle: IntegratedFactorBundle,
    cfg: IntegratedStrategyConfig,
    signal_func: Callable,
    *,
    strategy_prefix: str,
    stock_returns: pd.DataFrame | None = None,
    retain_full_results: bool = True,
) -> dict[str, Any]:
    specifications = {
        "existing_only_factor_equal_unified_stock": replace(
            cfg, signal_universe="existing_only", factor_weighting_mode="factor_equal", implementation_mode="unified_stock"
        ),
        "theme_only_factor_equal_hybrid": replace(
            cfg, signal_universe="theme_only", factor_weighting_mode="factor_equal", implementation_mode="hybrid_theme_basket"
        ),
        "combined_factor_equal_unified_stock": replace(
            cfg, signal_universe="combined", factor_weighting_mode="factor_equal", implementation_mode="unified_stock"
        ),
        "combined_factor_equal_hybrid": replace(
            cfg, signal_universe="combined", factor_weighting_mode="factor_equal", implementation_mode="hybrid_theme_basket"
        ),
        "combined_block_equal_unified_stock": replace(
            cfg, signal_universe="combined", factor_weighting_mode="block_equal", implementation_mode="unified_stock"
        ),
        "combined_block_equal_hybrid": replace(
            cfg, signal_universe="combined", factor_weighting_mode="block_equal", implementation_mode="hybrid_theme_basket"
        ),
    }
    results: dict[str, dict[str, Any]] = {}
    return_columns = {}
    metric_rows = []
    for name, spec in specifications.items():
        result = run_integrated_factor_strategy_backtest(
            bundle,
            spec,
            signal_func,
            strategy_name=f"{strategy_prefix}:{name}",
            stock_returns=stock_returns,
            collect_details=False,
        )
        if retain_full_results:
            results[name] = result
        if not result["returns"].empty and "net_return" in result["returns"]:
            return_columns[name] = result["returns"]["net_return"]
        metrics = performance_metrics(result["returns"], spec)
        if not metrics.empty:
            metrics.insert(0, "strategy_id", name)
            metric_rows.append(metrics)
        if not retain_full_results:
            # Comparison mode only needs returns and summary metrics.  Explicitly
            # release intermediate DataFrames to keep daily notebook execution
            # stable under constrained-memory Jupyter kernels.
            import gc
            del result
            gc.collect()
    comparison_returns = pd.DataFrame(return_columns).sort_index()
    common = comparison_returns.dropna(how="any")
    common_rows = []
    for column in common.columns:
        r = common[column]
        common_rows.append(
            {
                "strategy_id": column,
                "n_common_obs": len(r),
                "annualized_mean_return": float(r.mean() * cfg.annualization),
                "annualized_volatility": float(r.std(ddof=1) * np.sqrt(cfg.annualization)),
                "sharpe": float(r.mean() * np.sqrt(cfg.annualization) / r.std(ddof=1)) if r.std(ddof=1) > 0 else np.nan,
            }
        )
    return {
        "results": results,
        "comparison_returns": comparison_returns,
        "comparison_metrics": pd.concat(metric_rows, ignore_index=True) if metric_rows else pd.DataFrame(),
        "common_sample_metrics": pd.DataFrame(common_rows),
    }


def run_strategy_validation_checks(
    result: Mapping[str, Any],
    cfg: IntegratedStrategyConfig,
) -> pd.DataFrame:
    returns = result["returns"]
    ok = returns[returns.get("status", pd.Series(index=returns.index, dtype=object)).eq("ok")] if not returns.empty else pd.DataFrame()
    non_rebalance = returns[~returns.get("rebalance_executed", pd.Series(False, index=returns.index)).astype(bool)] if not returns.empty else pd.DataFrame()
    max_identity = float(ok["return_identity_error"].dropna().max()) if not ok.empty else np.nan
    max_nonreb_turnover = float(non_rebalance["total_lookthrough_turnover"].fillna(0.0).abs().max()) if not non_rebalance.empty and "total_lookthrough_turnover" in non_rebalance else 0.0
    max_nonreb_cost = float(non_rebalance["transaction_cost"].fillna(0.0).abs().max()) if not non_rebalance.empty and "transaction_cost" in non_rebalance else 0.0
    block_error = float(
        (
            ok["existing_factor_pnl"] + ok["theme_factor_pnl"] - ok["gross_return"]
        ).abs().max()
    ) if not ok.empty else np.nan
    return pd.DataFrame(
        [
            {
                "check": "daily_return_identity",
                "value": max_identity,
                "limit": cfg.return_identity_tolerance,
                "passed": np.isnan(max_identity) or max_identity <= cfg.return_identity_tolerance,
            },
            {
                "check": "non_rebalance_turnover_zero",
                "value": max_nonreb_turnover,
                "limit": 1e-14,
                "passed": max_nonreb_turnover <= 1e-14,
            },
            {
                "check": "non_rebalance_cost_zero",
                "value": max_nonreb_cost,
                "limit": 1e-14,
                "passed": max_nonreb_cost <= 1e-14,
            },
            {
                "check": "existing_plus_theme_pnl_equals_total",
                "value": block_error,
                "limit": cfg.return_identity_tolerance,
                "passed": np.isnan(block_error) or block_error <= cfg.return_identity_tolerance,
            },
            {
                "check": "candidate_signals_daily",
                "value": len(result["candidate_factor_weights"]),
                "limit": len(returns),
                "passed": len(result["candidate_factor_weights"]) == len(returns),
            },
        ]
    )


def save_integrated_strategy_outputs(
    result: Mapping[str, Any],
    cfg: IntegratedStrategyConfig,
    output_dir: str | Path,
    *,
    comparison: Mapping[str, Any] | None = None,
    validation_checks: pd.DataFrame | None = None,
) -> tuple[Path, dict[str, Any]]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    result["returns"].to_csv(out / "strategy_returns.csv")
    result["candidate_factor_weights"].to_csv(out / "candidate_factor_weights.csv")
    result["held_factor_weights"].to_csv(out / "held_factor_weights.csv")
    result["factor_contributions"].to_csv(out / "factor_contributions.csv")
    result["block_contributions"].to_csv(out / "block_contributions.csv")
    files: dict[str, Any] = {}
    files["signal_diagnostics"] = write_table_with_fallback(
        result["signal_diagnostics"], out / "signal_diagnostics.parquet"
    )
    files["factor_quality_diagnostics"] = write_table_with_fallback(
        result["factor_quality_diagnostics"], out / "factor_quality_diagnostics.parquet"
    )
    files["turnover_decomposition"] = write_table_with_fallback(
        result["turnover_decomposition"].reset_index(), out / "turnover_decomposition.parquet"
    )
    if cfg.save_held_stock_weights:
        files["strategy_stock_weights_long"] = write_table_with_fallback(
            result["stock_weights"].rename_axis("return_date").reset_index().melt(
                id_vars="return_date", var_name="stock_id", value_name="weight"
            ),
            out / "strategy_stock_weights_long.parquet",
        )
    if cfg.save_theme_basket_weights:
        files["strategy_theme_basket_weights_long"] = write_table_with_fallback(
            result["theme_basket_weights"].rename_axis("return_date").reset_index().melt(
                id_vars="return_date", var_name="base_basket", value_name="weight"
            ),
            out / "strategy_theme_basket_weights_long.parquet",
        )
        files["basket_contributions"] = write_table_with_fallback(
            result["basket_contributions"].rename_axis("return_date").reset_index().melt(
                id_vars="return_date", var_name="base_basket", value_name="contribution"
            ),
            out / "basket_contributions.parquet",
        )
    metrics = performance_metrics(result["returns"], cfg)
    metrics.to_csv(out / "performance_metrics.csv", index=False)
    if comparison is not None:
        comparison["comparison_returns"].to_csv(out / "comparison_grid_returns.csv")
        comparison["comparison_metrics"].to_csv(out / "comparison_grid_metrics.csv", index=False)
        comparison["common_sample_metrics"].to_csv(out / "comparison_common_sample_metrics.csv", index=False)
    if validation_checks is not None:
        validation_checks.to_csv(out / "validation_checks.csv", index=False)
    payload = {
        **asdict(cfg),
        "strategy_schema_version": INTEGRATED_STRATEGY_SCHEMA_VERSION,
        "replication_schema_version": INTEGRATED_REPLICATION_SCHEMA_VERSION,
        "config_hash": stable_json_hash(asdict(cfg)),
    }
    (out / "config.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    manifest = {
        "strategy_schema_version": INTEGRATED_STRATEGY_SCHEMA_VERSION,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "strategy_name": result.get("strategy_name"),
        "n_return_rows": len(result["returns"]),
        "files": files,
    }
    (out / "save_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return out, manifest


__all__ = [
    "INTEGRATED_STRATEGY_SCHEMA_VERSION",
    "IntegratedStrategyConfig",
    "StrategyConfig",
    "IntegratedHeldState",
    "make_rebalance_dates",
    "binary_tsfm_12m_signal",
    "vol_scaled_tsfm_signal",
    "eligible_factors_at_date",
    "construct_integrated_strategy_weights",
    "run_integrated_factor_strategy_backtest",
    "run_integrated_strategy_comparison_grid",
    "performance_metrics",
    "run_strategy_validation_checks",
    "save_integrated_strategy_outputs",
]
