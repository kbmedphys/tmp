# Integrated Existing / Barra / Purified Theme Factor Universe

## 1. 実装概要

本パッケージは、次の因子を同じ統合ファクター・ユニバースとして扱います。

1. Barraから選択した投資対象既存因子
2. 独自に用意した投資対象既存因子
3. Barra、投資対象既存因子、非投資既存因子で純化したテーマ因子

純化テーマは、同じ統合ユニバースに対して次の2経路で複製できます。

- `combined_stock_replicated`: 既存因子・純化テーマ因子の双方を個別銘柄mimickingで実装
- `combined_hybrid_replicated`: 既存因子は個別銘柄mimicking、純化テーマ因子はテーマバスケットL/Sで実装

TSFMでは、既存因子とテーマ因子を同じ日次リターン行列、同じメタデータ、同じquality filter、同じfactor grossの下で扱います。

## 2. ファイル構成

### 共通モジュール

- `integrated_factor_replication.py`
  - point-in-time入力の正規化
  - metadata／role解決
  - Barra・既存因子によるテーマ純化
  - 統合個別銘柄mimicking
  - 統合制約を用いたテーマバスケットL/S mapping
  - model／stock-replicated／hybrid-replicated日次リターン
  - 診断、保存、再読込、合成入力
- `integrated_factor_tsfm.py`
  - Binary TSFM 12M
  - Vol-scaled TSFM 12M (`sign / sigma`)
  - factor-equal／block-equal／custom-block配分
  - unified-stock／hybrid-theme-basket実装
  - 日次候補シグナルと日次・週次・月次リバランス
  - 保有mapping固定、日次P&L、turnover、cost、恒等式診断
  - 比較グリッド、保存
- `integrated_factor_mimicking.py`
  - `integrated_factor_replication.py`への互換import
- `theme_basket_mimicking.py`、`theme_basket_tsfm.py`
  - 既存のtheme-only実装を残した後方互換モジュール

### ノートブック

1. `00_combined_factor_mimicking_diagnostics_integrated_implemented.ipynb`
2. `01_binary_combined_factor_tsfm_12m_integrated_implemented.ipynb`
3. `02_vol_scaled_combined_factor_tsfm_12m_integrated_implemented.ipynb`

末尾が `_clean.ipynb` のファイルは未実行版です。末尾に `_clean` がないファイルは同梱の合成日次データで実行済みです。

### 実行・検証

- `run_integrated_factor_pipeline.py`: CLIによる00→01／02の一括実行
- `run_all_notebooks.py`: clean notebookを依存順に実行
- `test_integrated_factor_universe.py`: 自動テスト
- `integrated_existing_barra_theme_factor_universe_requirements.md`: 実装要件定義

## 3. 数理構造

### 3.1 統合対象因子

時点 `t` の投資対象既存因子を `E_t`、純化テーマを `Z_t` とし、統合対象行列を次で定義します。

```text
F_t = [E_t, Z_t]
```

テーマ純化の基底は次です。

```text
Q_t = [intercept, Barra controls, investable existing factors, existing controls]
```

テーマは、`Q_t`に対するリッジ残差を列別L2正規化して構築します。

```text
Z_raw_t = A_t - Q_t (Q_t' Q_t + ridge I)^+ Q_t' A_t
Z_t     = columnwise_L2_normalize(Z_raw_t)
```

投資対象既存因子はテーマ純化には含めますが、最終個別銘柄mimickingのゼロ中立化対象には入れません。targetとcontrolへ同じcanonical factorを同時登録した場合はエラーにします。

### 3.2 統合個別銘柄mimicking

すべての投資対象因子を同時に解きます。

```text
F_t' M_t ≈ I
R_t' M_t ≈ 0
```

`R_t`は切片、非投資Barra、`purification_basis`、`risk_control_only`等です。

### 3.3 テーマバスケットL/S

取引可能テーマバスケット構成を`P_t`、純化テーマへのバスケット配分を`H_t`とします。

```text
W_theme_t = P_t H_t
```

各テーマ列は、統合因子全体に対して次を目標にします。

```text
F_t' P_t H_t ≈ [0_existing ; I_theme]
R_t' P_t H_t ≈ 0
```

完全実現不能時はsoft penaltyへ退避し、以下を保存します。

- target theme exposure error
- existing-factor contamination
- other-theme contamination
- control exposure
- rank、condition number
- hard／soft solver status
- basket gross、look-through gross

### 3.4 ハイブリッド戦略

TSFM因子ウェイトを既存因子block `w_E` とテーマblock `w_Z` に分けます。

```text
existing stock weights = M_E,t w_E,t
theme basket weights   = H_t w_Z,t
theme stock weights    = P_t H_t w_Z,t
total stock weights    = M_E,t w_E,t + P_t H_t w_Z,t
```

日次で以下の一致を検証します。

```text
factor-path return
= existing-stock path + theme-basket path
= total look-through stock return
```

## 4. 入力データ契約

デフォルト入力は次です。

```text
data/combined_factor_inputs.pkl
```

必須キー:

```python
{
    "stock_returns": pd.DataFrame,
    "barra_exposures_by_date": dict[pd.Timestamp, pd.DataFrame],
    "existing_factor_exposures_by_date": dict[pd.Timestamp, pd.DataFrame],
    "theme_exposures_by_date": dict[pd.Timestamp, pd.DataFrame],
    "theme_basket_weights_by_date": dict[pd.Timestamp, pd.DataFrame],
    "factor_metadata": pd.DataFrame,
}
```

### 行列の形

| キー | 行 | 列 | 値 |
|---|---|---|---|
| `stock_returns` | return date | stock ID | 日次個別銘柄リターン |
| `barra_exposures_by_date[t]` | stock ID | Barra factor | point-in-time exposure |
| `existing_factor_exposures_by_date[t]` | stock ID | existing factor | point-in-time exposure／portfolio score |
| `theme_exposures_by_date[t]` | stock ID | raw theme | 因子定義用テーマ行列 |
| `theme_basket_weights_by_date[t]` | stock ID | base basket | 取引可能テーマバスケット構成 |

テーマ定義用行列と取引可能バスケットは別入力です。本番では次を維持してください。

```python
basket_fallback_to_theme_exposures=False
```

### 任意キー

```python
{
    "factor_alias_mapping": dict | pd.DataFrame,
    "external_existing_factor_returns": pd.DataFrame,
    "metadata": dict,
}
```

## 5. Factor metadata

最低限、次の列を使用します。

```text
factor_id
base_factor_id
source_type
source_factor_id
factor_type
role
block_id
is_momentum_related
normalization_policy
```

### `source_type`

- `barra`
- `existing`
- `theme`

### `role`

| role | テーマ純化基底 | 最終control | TSFM対象 |
|---|---:|---:|---:|
| `investable_signal` | 使用 | 使用しない | 対象 |
| `purification_basis` | 使用 | 使用 | 対象外 |
| `risk_control_only` | 設定により使用 | 使用 | 対象外 |
| `excluded` | 使用しない | 使用しない | 対象外 |

Barraと独自既存因子で同じ経済概念を表す場合は、`factor_alias_mapping`でcanonical IDを指定してください。重複列を自動平均しません。

## 6. TSFMシグナル

### Binary 12M

各因子の日次リターンを過去12カ月のカレンダー窓で複利し、その符号を使用します。

```text
signal_k,t = sign(prod(1 + factor_return_k) - 1)
```

### Vol-scaled 12M

同じ符号を、最大36カ月の日次標準偏差で割ります。

```text
raw_weight_k,t = signal_k,t / daily_sigma_k,t
```

これは因子間の逆ボラティリティ配分であり、ポートフォリオ全体のボラティリティターゲットではありません。

### 配分方式

- `factor_equal`: 全active因子のfactor grossを均等化
- `block_equal`: active blockへ同じgrossを配分し、block内を正規化
- `custom_block`: `block_gross_targets`に基づき配分

## 7. 日次・週次・月次リバランス

候補シグナルは全モードで毎営業日計算します。

```python
rebalance_frequency="daily"    # 毎営業日
rebalance_frequency="weekly"   # W-FRI内の最終観測営業日
rebalance_frequency="monthly"  # 暦月内の最終観測営業日
```

週次・月次では、非リバランス日に次を更新しません。

- factor weights
- joint stock mimicking matrix
- theme-basket mapping `H`
- basket constituents `P`
- strategy scale
- final stock／basket holdings

非リバランス日のturnoverとtransaction costは0です。リバランス候補が不適格な場合は、既存保有を継続します。

## 8. 実行方法

### ノートブック

次の順序で実行します。

```text
00 → 01 → 02
```

```bash
python run_all_notebooks.py
```

### CLI

実データ:

```bash
python run_integrated_factor_pipeline.py \
  --input-pickle data/combined_factor_inputs.pkl \
  --output-dir integrated_factor_outputs \
  --signals both \
  --rebalance-frequency monthly \
  --factor-return-source combined_hybrid_replicated \
  --implementation-mode hybrid_theme_basket \
  --factor-weighting-mode block_equal
```

合成データによる実装確認:

```bash
python run_integrated_factor_pipeline.py \
  --allow-synthetic \
  --save-synthetic-input \
  --signals both
```

本番では`--allow-theme-basket-fallback`を指定しないでください。

## 9. 出力

```text
integrated_factor_outputs/
├── 00_combined_factor_mimicking_diagnostics/
├── 01_binary_combined_factor_tsfm_12m/
└── 02_vol_scaled_combined_factor_tsfm_12m/
```

### 00の主な出力

- `combined_model_factor_returns.csv`
- `combined_stock_replicated_factor_returns.csv`
- `combined_hybrid_replicated_factor_returns.csv`
- `combined_stock_mimicking_weights_long.*`
- `theme_basket_mapping_long.*`
- `theme_basket_constituents_long.*`
- `theme_lookthrough_weights_long.*`
- `factor_metadata_by_date.*`
- `purification_diagnostics.*`
- `replication_diagnostics.*`
- `factor_quality_diagnostics.*`
- `factor_return_coverage.*`
- `validation_checks.csv`
- `config.json`
- `save_manifest.json`

### 01・02の主な出力

- `strategy_returns.csv`
- `candidate_factor_weights.csv`
- `held_factor_weights.csv`
- `factor_contributions.csv`
- `block_contributions.csv`
- `strategy_stock_weights_long.*`
- `strategy_theme_basket_weights_long.*`
- `basket_contributions.*`
- `turnover_decomposition.*`
- `performance_metrics.csv`
- `comparison_grid_returns.csv`
- `comparison_grid_metrics.csv`
- `comparison_common_sample_metrics.csv`
- `validation_checks.csv`
- `config.json`
- `save_manifest.json`

Parquet engineがない環境では、同内容のCSVへ自動フォールバックし、実ファイル名をmanifestへ記録します。

## 10. 比較グリッド

両TSFMノートブックは次を比較します。

1. existing-only / factor-equal / unified-stock
2. theme-only / factor-equal / hybrid
3. combined / factor-equal / unified-stock
4. combined / factor-equal / hybrid
5. combined / block-equal / unified-stock
6. combined / block-equal / hybrid

これにより、因子ユニバース、block配分、実装経路の影響を分離できます。

## 11. 自動検証

```bash
pytest -q
```

テスト対象:

- targetとcontrolの競合拒否
- 投資対象既存因子・controlに対するテーマ純化
- 統合個別銘柄mimickingのidentity／control制約
- テーマバスケット経路とルックスルー経路の一致
- 日次・週次・月次のリバランス回数
- 非リバランス日のturnover／costが0
- block-equal gross
- 保存bundleと再計算の一致
- ラベル順序不変性

## 12. 同梱の実行済み結果

実データpickleは提供されていないため、実行済みノートブックは次の合成日次データを使用しています。

- 18カ月
- 20銘柄
- 3 Barra列
- 2独自投資対象既存因子に加え、Barra SIZEを投資対象化
- 3テーマ
- 6ベーステーマバスケット
- seed 42

実行例では、Binary／Vol-scaledとも390日の日次候補シグナルを計算し、月次リバランスの主戦略で109日の有効P&Lを得ています。これらの収益値は実装確認用であり、投資判断用ではありません。
