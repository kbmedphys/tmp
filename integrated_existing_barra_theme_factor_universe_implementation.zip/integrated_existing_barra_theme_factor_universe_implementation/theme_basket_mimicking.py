"""Daily theme-factor purification and theme-basket long/short replication.

The public API is intentionally compatible with the earlier monthly implementation.
The only semantic change is that every input row is treated as one observed trading
period, while fields ending in ``_months`` are interpreted as calendar months.
"""
from __future__ import annotations

import hashlib
import json
import pickle
from dataclasses import asdict, dataclass, fields
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd

REPLICATION_SCHEMA_VERSION = "1.2.0-daily"


@dataclass
class ReplicationConfig:
    # Data
    input_pickle: str = "data/theme_factor_inputs.pkl"
    output_dir: str = "theme_factor_momentum_outputs"
    replication_output_subdir: str = "00_mimicking_portfolio_diagnostics_theme_basket"
    use_synthetic_if_missing: bool = True
    random_seed: int = 42
    n_months: int = 60  # calendar months of synthetic business-daily data
    n_stocks: int = 80
    n_barra: int = 6
    n_themes: int = 8
    start_date: str = "2018-01-02"

    # Estimation
    ridge: float = 1e-6
    pinv_rcond: float = 1e-10
    include_intercept_in_barra: bool = True
    theme_return_ridge_alpha: float = 1e-6
    min_history_months: int = 24
    risk_lookback_months: int = 36
    momentum_neutral: bool = False
    skip_recent_months_for_stock_mom: int = 1
    stock_mom_lookback_months: int = 11

    # Tradable theme baskets
    theme_basket_weights_key: str = "theme_basket_weights_by_date"
    basket_fallback_to_theme_exposures: bool = True
    normalize_basket_columns_to_one: bool = True
    basket_net_sum_tolerance: float = 1e-8
    allow_negative_basket_constituent_weights: bool = False

    # Basket replication
    basket_replication_mode: str = "constrained_risk_projection"
    basket_risk_metric: str = "specific_diag"
    basket_ridge_alpha: float = 1e-8
    basket_theme_penalty: float = 0.0
    basket_neutrality_penalty: float = 1e7
    basket_target_penalty: float = 1e7
    basket_constraint_tolerance: float = 1e-6
    basket_solver_tolerance: float = 1e-10
    basket_rank_tolerance: float = 1e-10
    basket_condition_number_warn: float = 1e12
    allow_soft_fallback: bool = True
    active_weight_tolerance: float = 1e-10

    # Return handling
    missing_return_policy: str = "coverage_threshold"  # propagate_nan / coverage_threshold
    min_return_coverage: float = 0.98

    # Daily diagnostics/persistence
    annualization: int = 252
    rolling_metric_months: int = 36
    save_full_basket_weights: bool = True
    save_lookthrough_stock_weights: bool = True
    save_stock_coefficient_weights: bool = True
    save_basket_constituent_weights: bool = True
    stock_replication_tolerance: float = 1e-7
    basket_identity_tolerance: float = 1e-10


Config = ReplicationConfig


@dataclass
class ThemeSnapshot:
    exposure_date: pd.Timestamp
    barra_exposures: pd.DataFrame
    neutralization_exposures: pd.DataFrame
    raw_theme_exposures: pd.DataFrame
    purified_theme_exposures: pd.DataFrame
    tradable_basket_weights: pd.DataFrame
    normalization_scale: pd.Series
    diagnostics: dict[str, Any]


@dataclass
class BasketReplicationArtifacts:
    raw_basket_returns: pd.DataFrame
    basket_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    basket_constituent_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    stock_coefficient_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    lookthrough_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    replication_diagnostics: pd.DataFrame
    basis_diagnostics: pd.DataFrame
    return_coverage: pd.DataFrame

    @property
    def basket_weights_long(self) -> pd.DataFrame:
        return matrix_dict_to_long(self.basket_weights_by_date, "base_basket", "target_theme")

    @property
    def basket_constituent_weights_long(self) -> pd.DataFrame:
        return matrix_dict_to_long(
            self.basket_constituent_weights_by_date, "stock_id", "base_basket"
        )

    @property
    def stock_coefficient_weights_long(self) -> pd.DataFrame:
        return matrix_dict_to_long(
            self.stock_coefficient_weights_by_date, "stock_id", "target_theme"
        )

    @property
    def lookthrough_weights_long(self) -> pd.DataFrame:
        return matrix_dict_to_long(
            self.lookthrough_weights_by_date, "stock_id", "target_theme"
        )


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------


def calendar_month_window(
    frame: pd.DataFrame | pd.Series,
    end_date: pd.Timestamp,
    months: int,
    *,
    include_end: bool = True,
):
    """Return observations in ``(end_date-months, end_date]`` (or right-open)."""
    if months <= 0:
        raise ValueError("months must be positive")
    end = pd.Timestamp(end_date)
    start = end - pd.DateOffset(months=months)
    index = pd.DatetimeIndex(frame.index)
    right = index <= end if include_end else index < end
    return frame.loc[(index > start) & right]


def has_calendar_history(index: pd.DatetimeIndex, end_date: pd.Timestamp, months: int) -> bool:
    idx = pd.DatetimeIndex(index)
    required_start = pd.Timestamp(end_date) - pd.DateOffset(months=months)
    return len(idx) > 0 and pd.Timestamp(idx.min()) <= required_start


def _json_default(value: Any):
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def stable_json_hash(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, ensure_ascii=False, default=_json_default)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def config_hash(cfg: ReplicationConfig) -> str:
    return stable_json_hash(asdict(cfg))


def config_from_dict(payload: Mapping[str, Any]) -> ReplicationConfig:
    valid = {f.name for f in fields(ReplicationConfig)}
    return ReplicationConfig(**{k: v for k, v in payload.items() if k in valid})


def fingerprint_inputs(data: Mapping[str, Any], cfg: ReplicationConfig | None = None) -> str:
    r = data["stock_returns"]
    summary: dict[str, Any] = {
        "shape": r.shape,
        "date_start": pd.Timestamp(r.index.min()).isoformat(),
        "date_end": pd.Timestamp(r.index.max()).isoformat(),
        "stock_labels": list(map(str, r.columns)),
        "barra_dates": [pd.Timestamp(x).isoformat() for x in sorted(data["barra_exposures_by_date"])],
        "theme_dates": [pd.Timestamp(x).isoformat() for x in sorted(data["theme_exposures_by_date"])],
        "sample_values": np.nan_to_num(r.iloc[: min(5, len(r)), : min(5, r.shape[1])].to_numpy()).round(12).tolist(),
    }
    if cfg is not None:
        summary["basket_key"] = cfg.theme_basket_weights_key
        summary["basket_dates"] = [
            pd.Timestamp(x).isoformat() for x in sorted(data.get(cfg.theme_basket_weights_key, {}))
        ]
    return stable_json_hash(summary)


def input_fingerprint(data: Mapping[str, Any], cfg: ReplicationConfig | None = None) -> str:
    return fingerprint_inputs(data, cfg)


def matrix_dict_to_long(
    matrices: Mapping[pd.Timestamp, pd.DataFrame],
    row_name: str,
    column_name: str,
) -> pd.DataFrame:
    rows: list[pd.DataFrame] = []
    for date, matrix in sorted(matrices.items()):
        wide = matrix.rename_axis(index=row_name, columns=column_name)
        try:
            stacked = wide.stack(future_stack=True)
        except TypeError:  # pandas < 2.1
            stacked = wide.stack(dropna=False)
        temp = stacked.rename("weight").reset_index()
        temp.insert(0, "exposure_date", pd.Timestamp(date))
        rows.append(temp)
    if not rows:
        return pd.DataFrame(columns=["exposure_date", row_name, column_name, "weight"])
    return pd.concat(rows, ignore_index=True)


def matrices_to_long(
    matrices: Mapping[pd.Timestamp, pd.DataFrame], row_name: str, column_name: str
) -> pd.DataFrame:
    return matrix_dict_to_long(matrices, row_name, column_name)


def long_to_matrix_dict(
    table: pd.DataFrame,
    row_name: str,
    column_name: str,
    value_name: str = "weight",
) -> dict[pd.Timestamp, pd.DataFrame]:
    out: dict[pd.Timestamp, pd.DataFrame] = {}
    if table is None or table.empty:
        return out
    temp = table.copy()
    temp["exposure_date"] = pd.to_datetime(temp["exposure_date"])
    for date, group in temp.groupby("exposure_date", sort=True):
        out[pd.Timestamp(date)] = group.pivot(index=row_name, columns=column_name, values=value_name).sort_index()
    return out


def long_to_matrices(
    table: pd.DataFrame,
    row_name: str,
    column_name: str,
    value_name: str = "weight",
) -> dict[pd.Timestamp, pd.DataFrame]:
    return long_to_matrix_dict(table, row_name, column_name, value_name)


def write_table_with_fallback(
    frame: pd.DataFrame, path: str | Path, *, index: bool = False
) -> dict[str, str]:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix.lower() == ".parquet":
        try:
            frame.to_parquet(path, index=index)
            return {"actual": path.name, "format": "parquet"}
        except Exception:
            fallback = path.with_suffix(".csv")
            frame.to_csv(fallback, index=index)
            return {"actual": fallback.name, "format": "csv"}
    frame.to_csv(path, index=index)
    return {"actual": path.name, "format": "csv"}


def read_table_with_fallback(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    candidates = [path, path.with_suffix(".csv")] if path.suffix.lower() == ".parquet" else [path]
    for candidate in candidates:
        if candidate.exists():
            return pd.read_parquet(candidate) if candidate.suffix.lower() == ".parquet" else pd.read_csv(candidate)
    raise FileNotFoundError(path)


def normalize_factor_weights(weights: pd.Series, gross: float = 1.0) -> pd.Series:
    out = weights.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    denom = float(out.abs().sum())
    return out * 0.0 if denom <= 0 else gross * out / denom


def one_way_turnover(previous: pd.Series, current: pd.Series) -> float:
    labels = previous.index.union(current.index)
    return 0.5 * float(
        (current.reindex(labels, fill_value=0.0) - previous.reindex(labels, fill_value=0.0)).abs().sum()
    )


# ---------------------------------------------------------------------------
# Synthetic daily data and input loading
# ---------------------------------------------------------------------------


def residualize_df(A: pd.DataFrame, X: pd.DataFrame, ridge: float = 1e-8) -> pd.DataFrame:
    common = A.index.intersection(X.index)
    av = A.loc[common].astype(float).to_numpy()
    xv = X.loc[common].astype(float).to_numpy()
    gram = av.T @ av + ridge * np.eye(av.shape[1])
    beta = np.linalg.pinv(gram) @ av.T @ xv
    return pd.DataFrame(xv - av @ beta, index=common, columns=X.columns)


def normalize_l2_with_scale(X: pd.DataFrame, eps: float = 1e-12) -> tuple[pd.DataFrame, pd.Series]:
    norm = np.sqrt((X.astype(float) ** 2).sum(axis=0))
    keep = norm[norm > eps].index
    return X[keep].divide(norm[keep], axis=1), norm[keep].rename("l2_scale")


def normalize_l2(X: pd.DataFrame, eps: float = 1e-12) -> pd.DataFrame:
    return normalize_l2_with_scale(X, eps)[0]


def add_barra_intercept(B: pd.DataFrame, cfg: ReplicationConfig) -> pd.DataFrame:
    B = B.astype(float).copy()
    if cfg.include_intercept_in_barra:
        if "INTERCEPT" in B.columns:
            raise ValueError("Input Barra exposures already contain INTERCEPT")
        B.insert(0, "INTERCEPT", 1.0)
    return B


def _daily_dates(start_date: str, n_months: int) -> pd.DatetimeIndex:
    start = pd.Timestamp(start_date)
    end = start + pd.DateOffset(months=n_months)
    dates = pd.bdate_range(start=start, end=end, inclusive="left")
    if len(dates) < 2:
        raise ValueError("Synthetic date range must contain at least two business days")
    return dates


def generate_synthetic_inputs(cfg: ReplicationConfig) -> dict[str, Any]:
    """Generate deterministic business-daily data with point-in-time exposures."""
    rng = np.random.default_rng(cfg.random_seed)
    dates = _daily_dates(cfg.start_date, cfg.n_months)
    stocks = [f"S{i:04d}" for i in range(1, cfg.n_stocks + 1)]
    barra_cols = ["BETA", "SIZE", "VALUE", "PROFIT", "INVEST", "VOL"][: cfg.n_barra]
    themes = [f"Theme_{i:02d}" for i in range(1, cfg.n_themes + 1)]

    B_state = rng.normal(size=(cfg.n_stocks, cfg.n_barra))
    theme_logits = rng.normal(scale=0.8, size=(cfg.n_stocks, cfg.n_themes))
    barra_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    theme_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    basket_by_date: dict[pd.Timestamp, pd.DataFrame] = {}

    for date in dates:
        B_state = 0.995 * B_state + rng.normal(scale=0.04, size=B_state.shape)
        theme_logits = 0.997 * theme_logits + rng.normal(scale=0.025, size=theme_logits.shape)
        B = pd.DataFrame(B_state, index=stocks, columns=barra_cols)
        positive = np.exp(theme_logits - theme_logits.max(axis=0, keepdims=True))
        P = positive / positive.sum(axis=0, keepdims=True)
        P_df = pd.DataFrame(P, index=stocks, columns=themes)
        # Factor-definition scores are related to, but not identical to, tradable baskets.
        X_df = pd.DataFrame(
            P + rng.normal(scale=max(P.mean() * 0.10, 1e-6), size=P.shape),
            index=stocks,
            columns=themes,
        ).clip(lower=0.0)
        X_df = X_df.divide(X_df.sum(axis=0), axis=1)
        barra_by_date[pd.Timestamp(date)] = B
        theme_by_date[pd.Timestamp(date)] = X_df
        basket_by_date[pd.Timestamp(date)] = P_df

    returns = np.zeros((len(dates), cfg.n_stocks), dtype=float)
    returns[0] = rng.normal(scale=0.01, size=cfg.n_stocks)
    for t in range(len(dates) - 1):
        B = barra_by_date[pd.Timestamp(dates[t])]
        X = theme_by_date[pd.Timestamp(dates[t])]
        A = add_barra_intercept(B, cfg)
        Z = normalize_l2(residualize_df(A, X, cfg.ridge))
        f = rng.normal(scale=0.004 / np.sqrt(cfg.annualization / 252), size=A.shape[1])
        g = rng.normal(scale=0.0025 / np.sqrt(cfg.annualization / 252), size=Z.shape[1])
        eps = rng.normal(scale=0.010, size=cfg.n_stocks)
        returns[t + 1] = A.to_numpy() @ f + Z.to_numpy() @ g + eps

    stock_returns = pd.DataFrame(returns, index=dates, columns=stocks)
    return {
        "stock_returns": stock_returns,
        "barra_exposures_by_date": barra_by_date,
        "theme_exposures_by_date": theme_by_date,
        cfg.theme_basket_weights_key: basket_by_date,
        "cash_returns": pd.Series(0.0, index=dates, name="cash_return"),
        "metadata": {
            "source": "synthetic_daily",
            "frequency": "business_daily",
            "basket_weights_source": "explicit input",
            "random_seed": cfg.random_seed,
        },
    }


def _as_timestamp_keyed_dict(value: Mapping[Any, pd.DataFrame]) -> dict[pd.Timestamp, pd.DataFrame]:
    return {pd.Timestamp(k): v.copy() for k, v in value.items()}


def load_or_generate_inputs(cfg: ReplicationConfig) -> dict[str, Any]:
    path = Path(cfg.input_pickle)
    if path.exists():
        with path.open("rb") as handle:
            data = pickle.load(handle)
        required = ["stock_returns", "barra_exposures_by_date", "theme_exposures_by_date"]
        missing = [key for key in required if key not in data]
        if missing:
            raise KeyError(f"Input pickle is missing required keys: {missing}")
        data["stock_returns"] = data["stock_returns"].copy()
        data["stock_returns"].index = pd.to_datetime(data["stock_returns"].index)
        data["stock_returns"] = data["stock_returns"].sort_index()
        data["barra_exposures_by_date"] = _as_timestamp_keyed_dict(data["barra_exposures_by_date"])
        data["theme_exposures_by_date"] = _as_timestamp_keyed_dict(data["theme_exposures_by_date"])
        for key in [cfg.theme_basket_weights_key, "specific_variances_by_date", "specific_risks_by_date"]:
            if key in data:
                data[key] = _as_timestamp_keyed_dict(data[key])
        if cfg.theme_basket_weights_key not in data:
            if not cfg.basket_fallback_to_theme_exposures:
                raise KeyError(f"Input is missing {cfg.theme_basket_weights_key!r}")
            data[cfg.theme_basket_weights_key] = {
                date: matrix.copy() for date, matrix in data["theme_exposures_by_date"].items()
            }
            data.setdefault("metadata", {})["basket_weights_source"] = "theme_exposures_fallback"
        data.setdefault("metadata", {})["source"] = str(path)
        data.setdefault("metadata", {})["frequency"] = "observed_trading_days"
        return data
    if not cfg.use_synthetic_if_missing:
        raise FileNotFoundError(path)
    return generate_synthetic_inputs(cfg)


# ---------------------------------------------------------------------------
# Point-in-time purification and stock mimicking portfolios
# ---------------------------------------------------------------------------


def prior_stock_momentum(
    stock_returns: pd.DataFrame, date: Any, cfg: ReplicationConfig
) -> pd.Series:
    date = pd.Timestamp(date)
    formation_end = date - pd.DateOffset(months=cfg.skip_recent_months_for_stock_mom)
    window = calendar_month_window(
        stock_returns,
        formation_end,
        cfg.stock_mom_lookback_months,
        include_end=True,
    )
    required_start = formation_end - pd.DateOffset(months=cfg.stock_mom_lookback_months)
    if window.empty or pd.Timestamp(stock_returns.index.min()) > required_start:
        return pd.Series(np.nan, index=stock_returns.columns, name="PRIOR_STOCK_MOM")
    complete = window.notna().all(axis=0)
    result = pd.Series(np.nan, index=stock_returns.columns, name="PRIOR_STOCK_MOM")
    result.loc[complete] = (1.0 + window.loc[:, complete]).prod(axis=0) - 1.0
    return result


def prepare_theme_basket_weights(
    data: Mapping[str, Any],
    date: Any,
    stock_index: pd.Index,
    cfg: ReplicationConfig,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    date = pd.Timestamp(date)
    source = "explicit"
    if date in data.get(cfg.theme_basket_weights_key, {}):
        P = data[cfg.theme_basket_weights_key][date].copy()
    elif cfg.basket_fallback_to_theme_exposures and date in data["theme_exposures_by_date"]:
        P = data["theme_exposures_by_date"][date].copy()
        source = "theme_exposures_fallback"
    else:
        raise KeyError(f"No tradable theme basket matrix for {date.date()}")
    if P.index.has_duplicates or P.columns.has_duplicates:
        raise ValueError("Duplicate stock or basket labels")
    P = P.reindex(stock_index).replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    if not cfg.allow_negative_basket_constituent_weights and (P < -cfg.basket_net_sum_tolerance).any().any():
        raise ValueError("Negative constituent weight in a long-only base basket")
    gross = P.abs().sum(axis=0)
    P = P.loc[:, gross > cfg.basket_solver_tolerance]
    if P.empty:
        raise ValueError("All base baskets are empty")
    net_before = P.sum(axis=0)
    if cfg.normalize_basket_columns_to_one:
        if (net_before.abs() <= cfg.basket_solver_tolerance).any():
            raise ValueError("Zero-net base basket cannot be normalized")
        P = P.divide(net_before, axis=1)
    return P, {
        "source": source,
        "n_baskets": int(P.shape[1]),
        "max_abs_net_error_after": float((P.sum(axis=0) - 1.0).abs().max()),
    }


def snapshot_for_date(
    data: Mapping[str, Any],
    date: Any,
    cfg: ReplicationConfig,
    momentum_neutral: bool | None = None,
) -> ThemeSnapshot:
    date = pd.Timestamp(date)
    momentum_neutral = cfg.momentum_neutral if momentum_neutral is None else momentum_neutral
    if date not in data["barra_exposures_by_date"] or date not in data["theme_exposures_by_date"]:
        raise KeyError(f"Exposure data unavailable on {date.date()}")
    stocks = data["stock_returns"].columns
    B = data["barra_exposures_by_date"][date].copy()
    X = data["theme_exposures_by_date"][date].copy()
    common = stocks.intersection(B.index).intersection(X.index)
    B = B.reindex(common).replace([np.inf, -np.inf], np.nan).dropna(how="any").astype(float)
    X = X.reindex(B.index).replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    B_aug = add_barra_intercept(B, cfg)
    A = B_aug.copy()
    if momentum_neutral:
        mom = prior_stock_momentum(data["stock_returns"], date, cfg).reindex(A.index)
        A = pd.concat([A, mom], axis=1).dropna(how="any")
        X = X.reindex(A.index)
        B_aug = B_aug.reindex(A.index)
    Z_raw = residualize_df(A, X, cfg.ridge)
    Z, scale = normalize_l2_with_scale(Z_raw)
    A = A.reindex(Z.index)
    B_aug = B_aug.reindex(Z.index)
    X = X.reindex(Z.index).loc[:, Z.columns]
    P, pdiag = prepare_theme_basket_weights(data, date, Z.index, cfg)
    return ThemeSnapshot(
        exposure_date=date,
        barra_exposures=B_aug,
        neutralization_exposures=A,
        raw_theme_exposures=X,
        purified_theme_exposures=Z,
        tradable_basket_weights=P,
        normalization_scale=scale,
        diagnostics={
            **pdiag,
            "n_stocks": len(Z),
            "n_themes": Z.shape[1],
            "rank_neutralization": int(np.linalg.matrix_rank(A.to_numpy())),
            "rank_purified_theme": int(np.linalg.matrix_rank(Z.to_numpy())),
        },
    )


exposure_snapshot_for_date = snapshot_for_date


def _return_vector_with_policy(
    raw: pd.Series, activity_weights: pd.Series, cfg: ReplicationConfig
) -> tuple[pd.Series, float, list[str]]:
    raw = raw.astype(float)
    activity = activity_weights.reindex(raw.index).fillna(0.0).abs()
    active = activity > cfg.active_weight_tolerance
    total = float(activity[active].sum())
    available = float(activity[active & raw.notna()].sum())
    coverage = 1.0 if total <= 0 else available / total
    missing = list(map(str, raw.index[active & raw.isna()]))
    if missing and cfg.missing_return_policy == "propagate_nan":
        return raw, coverage, missing
    if missing and coverage < cfg.min_return_coverage:
        return pd.Series(np.nan, index=raw.index), coverage, missing
    return raw.fillna(0.0), coverage, missing


def estimate_theme_returns(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    momentum_neutral: bool | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[pd.Series] = []
    diag_rows: list[dict[str, Any]] = []
    dates = pd.DatetimeIndex(data["stock_returns"].index).sort_values()
    for pos in range(1, len(dates)):
        exposure_date, return_date = dates[pos - 1], dates[pos]
        try:
            snap = snapshot_for_date(data, exposure_date, cfg, momentum_neutral)
            raw = data["stock_returns"].loc[return_date].reindex(snap.purified_theme_exposures.index)
            activity = pd.Series(1.0, index=raw.index)
            r, coverage, missing = _return_vector_with_policy(raw, activity, cfg)
            if r.isna().any():
                raise ValueError(f"return coverage {coverage:.4f} below threshold")
            A = snap.neutralization_exposures.to_numpy()
            rv = r.to_numpy()
            beta = np.linalg.pinv(A.T @ A + cfg.ridge * np.eye(A.shape[1])) @ A.T @ rv
            u = rv - A @ beta
            Z = snap.purified_theme_exposures.to_numpy()
            g = np.linalg.pinv(
                Z.T @ Z + cfg.theme_return_ridge_alpha * np.eye(Z.shape[1]),
                rcond=cfg.pinv_rcond,
            ) @ Z.T @ u
            rows.append(pd.Series(g, index=snap.purified_theme_exposures.columns, name=return_date))
            diag_rows.append(
                {
                    "exposure_date": exposure_date,
                    "return_date": return_date,
                    "coverage": coverage,
                    "n_missing_returns": len(missing),
                    "n_stocks": len(r),
                    "status": "ok",
                }
            )
        except Exception as exc:
            diag_rows.append(
                {
                    "exposure_date": exposure_date,
                    "return_date": return_date,
                    "status": f"skipped:{type(exc).__name__}:{exc}",
                }
            )
    return pd.DataFrame(rows).sort_index(), pd.DataFrame(diag_rows)


def specific_risk_diag(
    data: Mapping[str, Any], date: Any, stock_index: pd.Index, cfg: ReplicationConfig
) -> pd.Series:
    date = pd.Timestamp(date)
    if date in data.get("specific_variances_by_date", {}):
        source = data["specific_variances_by_date"][date]
        if isinstance(source, pd.DataFrame):
            source = source.iloc[:, 0]
        return source.reindex(stock_index).astype(float).clip(lower=1e-8).fillna(source.median())
    if date in data.get("specific_risks_by_date", {}):
        source = data["specific_risks_by_date"][date]
        if isinstance(source, pd.DataFrame):
            source = source.iloc[:, 0]
        return source.reindex(stock_index).astype(float).pow(2).clip(lower=1e-8).fillna(source.median() ** 2)
    hist = calendar_month_window(
        data["stock_returns"], date, cfg.risk_lookback_months, include_end=False
    ).reindex(columns=stock_index)
    if hist.empty:
        return pd.Series(1.0, index=stock_index)
    variance = hist.var(axis=0, ddof=1).replace([np.inf, -np.inf], np.nan)
    fill = float(variance.median()) if variance.notna().any() else 1.0
    return variance.fillna(fill).clip(lower=max(fill * 1e-6, 1e-8))


def construct_stock_mimicking_portfolios(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    date: Any,
    momentum_neutral: bool | None = None,
    mode: str = "coefficient",
) -> tuple[pd.DataFrame, dict[str, Any]]:
    snap = snapshot_for_date(data, date, cfg, momentum_neutral)
    Z = snap.purified_theme_exposures
    if mode == "coefficient":
        gram = Z.to_numpy().T @ Z.to_numpy() + cfg.theme_return_ridge_alpha * np.eye(Z.shape[1])
        Mv = Z.to_numpy() @ np.linalg.pinv(gram, rcond=cfg.pinv_rcond)
        M = pd.DataFrame(Mv, index=Z.index, columns=Z.columns)
    elif mode == "min_risk":
        variance = specific_risk_diag(data, date, Z.index, cfg)
        Dinv = np.diag(1.0 / variance.to_numpy())
        A = snap.neutralization_exposures.to_numpy()
        M = pd.DataFrame(0.0, index=Z.index, columns=Z.columns)
        for k, theme in enumerate(Z.columns):
            C = np.vstack([A.T, Z.iloc[:, k].to_numpy()[None, :]])
            target = np.r_[np.zeros(A.shape[1]), 1.0]
            core = C @ Dinv @ C.T
            w = Dinv @ C.T @ np.linalg.pinv(core, rcond=cfg.pinv_rcond) @ target
            M.loc[:, theme] = w
    else:
        raise ValueError(f"Unsupported stock mimicking mode: {mode}")
    neutral = pd.DataFrame(
        snap.neutralization_exposures.to_numpy().T @ M.to_numpy(),
        index=snap.neutralization_exposures.columns,
        columns=M.columns,
    )
    theme_exp = pd.DataFrame(
        Z.to_numpy().T @ M.to_numpy(), index=Z.columns, columns=M.columns
    )
    return M, {
        "neutralization_exposure": neutral,
        "theme_exposure": theme_exp,
        "portfolio_summary": pd.concat(
            [M.abs().sum().rename("gross"), M.sum().rename("net")], axis=1
        ),
        "snapshot": snap,
    }


def construct_mimicking_portfolios(*args, **kwargs):
    return construct_stock_mimicking_portfolios(*args, **kwargs)


def stock_replicated_theme_returns(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool | None = None,
    mode: str = "coefficient",
    return_diagnostics: bool = False,
):
    rows: list[pd.Series] = []
    diagnostics: list[dict[str, Any]] = []
    stock_dates = pd.DatetimeIndex(data["stock_returns"].index)
    for return_date in theme_returns.index:
        if return_date not in stock_dates:
            continue
        pos = stock_dates.get_loc(return_date)
        if pos == 0:
            continue
        exposure_date = stock_dates[pos - 1]
        try:
            M, diag = construct_stock_mimicking_portfolios(
                data, cfg, exposure_date, momentum_neutral, mode
            )
            raw = data["stock_returns"].loc[return_date].reindex(M.index)
            activity = M.abs().sum(axis=1)
            r, coverage, missing = _return_vector_with_policy(raw, activity, cfg)
            if r.isna().any():
                raise ValueError("insufficient return coverage")
            rows.append(pd.Series(M.T @ r, name=return_date))
            diagnostics.append(
                {
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "coverage": coverage,
                    "n_missing_returns": len(missing),
                    "max_abs_neutralization_exposure": float(diag["neutralization_exposure"].abs().max().max()),
                    "status": "ok",
                }
            )
        except Exception as exc:
            diagnostics.append(
                {
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "status": f"skipped:{type(exc).__name__}:{exc}",
                }
            )
    out = pd.DataFrame(rows).sort_index()
    diag_frame = pd.DataFrame(diagnostics)
    return (out, diag_frame) if return_diagnostics else out


coefficient_replicated_theme_returns = stock_replicated_theme_returns


# ---------------------------------------------------------------------------
# Theme-basket mapping
# ---------------------------------------------------------------------------


def _row_space_basis(matrix: np.ndarray, tolerance: float) -> np.ndarray:
    if matrix.size == 0:
        return np.empty((0, matrix.shape[1]))
    _, singular, vt = np.linalg.svd(matrix, full_matrices=False)
    rank = int((singular > tolerance * max(singular[0] if len(singular) else 1.0, 1.0)).sum())
    return vt[:rank]


def _condition_number(matrix: np.ndarray, tolerance: float) -> float:
    singular = np.linalg.svd(matrix, compute_uv=False)
    if len(singular) == 0 or singular[-1] <= tolerance:
        return np.inf
    return float(singular[0] / singular[-1])


def _solve_basket_projection(
    G: np.ndarray,
    c: np.ndarray,
    neutrality: np.ndarray,
    target_row: np.ndarray,
    theme_mapping: np.ndarray,
    target_index: int,
    cfg: ReplicationConfig,
) -> tuple[np.ndarray, dict[str, Any]]:
    N = _row_space_basis(neutrality, cfg.basket_rank_tolerance)
    if N.shape[0] < G.shape[0]:
        _, _, vt = np.linalg.svd(N, full_matrices=True)
        null = vt[N.shape[0] :].T
    else:
        null = np.empty((G.shape[0], 0))
    feasible_strength = float(np.linalg.norm(target_row @ null)) if null.size else 0.0
    if feasible_strength > cfg.basket_solver_tolerance:
        C = np.vstack([N, target_row[None, :]])
        d = np.r_[np.zeros(N.shape[0]), 1.0]
        K = np.block([[G, C.T], [C, np.zeros((C.shape[0], C.shape[0]))]])
        rhs = np.r_[c, d]
        solution = np.linalg.pinv(K, rcond=cfg.pinv_rcond) @ rhs
        h = solution[: G.shape[0]]
        residual = float(np.max(np.abs(C @ h - d)))
        if np.isfinite(h).all() and residual <= cfg.basket_constraint_tolerance:
            return h, {
                "solver_status": "hard_solved_pinv",
                "constraint_feasibility_residual": residual,
                "condition_number_kkt": _condition_number(K, cfg.basket_rank_tolerance),
            }
    Gs = G + cfg.basket_neutrality_penalty * neutrality.T @ neutrality
    Gs += cfg.basket_target_penalty * np.outer(target_row, target_row)
    cs = c + cfg.basket_target_penalty * target_row
    if cfg.basket_theme_penalty > 0 and theme_mapping.size:
        target = np.zeros(theme_mapping.shape[0])
        target[target_index] = 1.0
        Gs += cfg.basket_theme_penalty * theme_mapping.T @ theme_mapping
        cs += cfg.basket_theme_penalty * theme_mapping.T @ target
    h = np.linalg.pinv(Gs, rcond=cfg.pinv_rcond) @ cs
    return h, {
        "solver_status": "soft_solved_pinv",
        "constraint_feasibility_residual": feasible_strength,
        "condition_number_kkt": _condition_number(Gs, cfg.basket_rank_tolerance),
    }


def construct_basket_mimicking_portfolios(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    date: Any,
    profile: str = "raw",
    previous_basket_weights: pd.DataFrame | None = None,
    momentum_neutral: bool | None = None,
    stock_target_mode: str = "coefficient",
    basket_mode: str | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    basket_mode = basket_mode or cfg.basket_replication_mode
    if basket_mode != "constrained_risk_projection":
        raise ValueError(f"Unsupported basket replication mode: {basket_mode}")
    M_stock, stock_diag = construct_stock_mimicking_portfolios(
        data, cfg, date, momentum_neutral, stock_target_mode
    )
    snap: ThemeSnapshot = stock_diag["snapshot"]
    A = snap.neutralization_exposures.reindex(M_stock.index)
    Z = snap.purified_theme_exposures.reindex(M_stock.index)
    P = snap.tradable_basket_weights.reindex(M_stock.index).fillna(0.0)
    if cfg.basket_risk_metric == "specific_diag":
        q = specific_risk_diag(data, date, M_stock.index, cfg)
        Q = np.diag(q.to_numpy())
    elif cfg.basket_risk_metric == "identity":
        Q = np.eye(len(M_stock))
    else:
        raise ValueError(f"Unsupported basket risk metric: {cfg.basket_risk_metric}")
    Pv, Av, Zv, Mv = P.to_numpy(), A.to_numpy(), Z.to_numpy(), M_stock.to_numpy()
    G = Pv.T @ Q @ Pv + cfg.basket_ridge_alpha * np.eye(P.shape[1])
    neutrality = Av.T @ Pv
    theme_mapping = Zv.T @ Pv
    H = pd.DataFrame(index=P.columns, columns=Z.columns, dtype=float)
    rows: list[dict[str, Any]] = []
    for k, theme in enumerate(Z.columns):
        target_m = Mv[:, k]
        c = Pv.T @ Q @ target_m
        target_row = Zv[:, k].T @ Pv
        h, info = _solve_basket_projection(
            G, c, neutrality, target_row, theme_mapping, k, cfg
        )
        if not cfg.allow_soft_fallback and info["solver_status"].startswith("soft"):
            h[:] = np.nan
            info["solver_status"] = "infeasible_no_fallback"
        H.loc[:, theme] = h
        w = Pv @ h
        neutral_exp = Av.T @ w
        theme_exp = Zv.T @ w
        off = np.delete(theme_exp, k)
        distance = w - target_m
        rows.append(
            {
                "exposure_date": pd.Timestamp(date),
                "profile": profile,
                "target_theme": theme,
                **info,
                "target_theme_exposure": float(theme_exp[k]),
                "target_theme_exposure_error": float(theme_exp[k] - 1.0),
                "max_abs_neutralization_exposure": float(np.max(np.abs(neutral_exp))),
                "off_target_theme_exposure_l2": float(np.linalg.norm(off)),
                "basket_gross": float(np.sum(np.abs(h))),
                "basket_net": float(np.sum(h)),
                "max_abs_basket_weight": float(np.max(np.abs(h))),
                "n_active_long_baskets": int((h > cfg.active_weight_tolerance).sum()),
                "n_active_short_baskets": int((h < -cfg.active_weight_tolerance).sum()),
                "lookthrough_stock_gross": float(np.sum(np.abs(w))),
                "lookthrough_stock_net": float(np.sum(w)),
                "risk_weighted_distance_to_stock_target": float(
                    np.sqrt(max(distance.T @ Q @ distance, 0.0))
                ),
            }
        )
    W = P @ H
    diagnostics = {
        "per_theme": pd.DataFrame(rows),
        "snapshot": snap,
        "stock_target_weights": M_stock,
        "basis": {
            "exposure_date": pd.Timestamp(date),
            "rank_basket_matrix": int(np.linalg.matrix_rank(Pv)),
            "rank_neutralization_exposure_on_baskets": int(np.linalg.matrix_rank(neutrality)),
            "neutral_nullspace_dimension": int(P.shape[1] - np.linalg.matrix_rank(neutrality)),
            "rank_theme_exposure_in_neutral_space": int(np.linalg.matrix_rank(theme_mapping)),
            "condition_number_basket_matrix": _condition_number(Pv, cfg.basket_rank_tolerance),
        },
    }
    return H, W, diagnostics


def compute_theme_basket_returns(
    P: pd.DataFrame,
    stock_return: pd.Series,
    cfg: ReplicationConfig,
) -> tuple[pd.Series, dict[str, Any]]:
    raw = stock_return.reindex(P.index)
    activity = P.abs().sum(axis=1)
    r, coverage, missing = _return_vector_with_policy(raw, activity, cfg)
    if r.isna().any():
        return pd.Series(np.nan, index=P.columns), {
            "coverage": coverage,
            "n_missing_returns": len(missing),
            "status": "insufficient_coverage",
        }
    return P.T @ r, {
        "coverage": coverage,
        "n_missing_returns": len(missing),
        "status": "ok",
    }


def basket_replicated_theme_returns(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool | None = None,
    return_artifacts: bool = False,
):
    rows: list[pd.Series] = []
    raw_rows: list[pd.Series] = []
    diag_rows: list[pd.DataFrame] = []
    basis_rows: list[dict[str, Any]] = []
    coverage_rows: list[dict[str, Any]] = []
    H_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    P_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    M_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    W_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    stock_dates = pd.DatetimeIndex(data["stock_returns"].index)
    previous_H: pd.DataFrame | None = None
    for return_date in theme_returns.index:
        if return_date not in stock_dates:
            continue
        pos = stock_dates.get_loc(return_date)
        if pos == 0:
            continue
        exposure_date = stock_dates[pos - 1]
        try:
            H, W, diagnostics = construct_basket_mimicking_portfolios(
                data,
                cfg,
                exposure_date,
                previous_basket_weights=previous_H,
                momentum_neutral=momentum_neutral,
            )
            snap: ThemeSnapshot = diagnostics["snapshot"]
            P = snap.tradable_basket_weights
            q, qdiag = compute_theme_basket_returns(
                P, data["stock_returns"].loc[return_date], cfg
            )
            if q.isna().any():
                raise ValueError("insufficient base-basket return coverage")
            g_basket = H.T @ q
            r = data["stock_returns"].loc[return_date].reindex(W.index).fillna(0.0)
            via_lookthrough = W.T @ r
            identity = float((g_basket - via_lookthrough).abs().max())
            rows.append(pd.Series(g_basket, name=return_date))
            raw_rows.append(pd.Series(q, name=return_date))
            per_theme = diagnostics["per_theme"].copy()
            per_theme.insert(1, "return_date", return_date)
            per_theme["identity_error"] = identity
            diag_rows.append(per_theme)
            basis_rows.append(diagnostics["basis"])
            coverage_rows.append(
                {
                    "exposure_date": exposure_date,
                    "return_date": return_date,
                    "basket_return_coverage": qdiag["coverage"],
                    "n_missing_returns": qdiag["n_missing_returns"],
                    "identity_error": identity,
                    "status": "ok" if identity <= cfg.basket_identity_tolerance else "identity_failure",
                }
            )
            H_by_date[pd.Timestamp(exposure_date)] = H
            P_by_date[pd.Timestamp(exposure_date)] = P
            M_by_date[pd.Timestamp(exposure_date)] = diagnostics["stock_target_weights"]
            W_by_date[pd.Timestamp(exposure_date)] = W
            previous_H = H
        except Exception as exc:
            coverage_rows.append(
                {
                    "exposure_date": exposure_date,
                    "return_date": return_date,
                    "status": f"skipped:{type(exc).__name__}:{exc}",
                }
            )
    basket_return = pd.DataFrame(rows).sort_index()
    artifacts = BasketReplicationArtifacts(
        raw_basket_returns=pd.DataFrame(raw_rows).sort_index(),
        basket_weights_by_date=H_by_date,
        basket_constituent_weights_by_date=P_by_date,
        stock_coefficient_weights_by_date=M_by_date,
        lookthrough_weights_by_date=W_by_date,
        replication_diagnostics=pd.concat(diag_rows, ignore_index=True) if diag_rows else pd.DataFrame(),
        basis_diagnostics=pd.DataFrame(basis_rows),
        return_coverage=pd.DataFrame(coverage_rows),
    )
    if return_artifacts:
        return basket_return, artifacts.replication_diagnostics, artifacts
    return basket_return


def _pair_metrics(target: pd.DataFrame, replica: pd.DataFrame, pair: str, annualization: int) -> pd.DataFrame:
    target, replica = target.align(replica, join="inner", axis=0)
    target, replica = target.align(replica, join="inner", axis=1)
    rows: list[dict[str, Any]] = []
    for theme in target.columns:
        panel = pd.concat([target[theme], replica[theme]], axis=1).dropna()
        if panel.empty:
            continue
        x, y = panel.iloc[:, 0], panel.iloc[:, 1]
        error = y - x
        beta = float(np.cov(x, y, ddof=1)[0, 1] / np.var(x, ddof=1)) if len(panel) > 1 and np.var(x, ddof=1) > 0 else np.nan
        rows.append(
            {
                "pair": pair,
                "theme": theme,
                "n_obs": len(panel),
                "correlation": x.corr(y),
                "tracking_error_daily": error.std(ddof=1),
                "tracking_error_annualized": error.std(ddof=1) * np.sqrt(annualization),
                "bias_daily": error.mean(),
                "rmse": float(np.sqrt(np.mean(error**2))),
                "beta": beta,
            }
        )
    return pd.DataFrame(rows)


def compare_replication_methods(
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    basket_rep: pd.DataFrame,
    diagnostics: pd.DataFrame | None,
    cfg: ReplicationConfig,
) -> dict[str, Any]:
    metrics = pd.concat(
        [
            _pair_metrics(purified, stock_rep, "purified_vs_stock_coefficient", cfg.annualization),
            _pair_metrics(purified, basket_rep, "purified_vs_basket_ls", cfg.annualization),
            _pair_metrics(stock_rep, basket_rep, "stock_coefficient_vs_basket_ls", cfg.annualization),
        ],
        ignore_index=True,
    )
    aggregate = (
        metrics.groupby("pair")[["correlation", "tracking_error_daily", "tracking_error_annualized", "rmse", "beta"]]
        .agg(["mean", "median", "min", "max"])
        .stack(level=0, future_stack=True)
        .rename_axis(["pair", "metric"])
        .reset_index()
    ) if not metrics.empty else pd.DataFrame()
    return {
        "metrics_by_theme": metrics,
        "metrics_aggregate": aggregate,
        "replication_diagnostics": diagnostics if diagnostics is not None else pd.DataFrame(),
    }


def validate_replication_result(
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    basket_rep: pd.DataFrame,
    basket_diagnostics: pd.DataFrame,
    cfg: ReplicationConfig,
) -> pd.DataFrame:
    p, s = purified.align(stock_rep, join="inner", axis=0)
    p, s = p.align(s, join="inner", axis=1)
    stock_error = float((s - p).abs().max().max()) if not p.empty else np.nan
    identity_error = (
        float(basket_diagnostics["identity_error"].max())
        if not basket_diagnostics.empty and "identity_error" in basket_diagnostics
        else np.nan
    )
    hard = basket_diagnostics[
        basket_diagnostics.get("solver_status", pd.Series(dtype=str)).astype(str).str.startswith("hard_solved")
    ] if not basket_diagnostics.empty else pd.DataFrame()
    neutral_error = float(hard["max_abs_neutralization_exposure"].max()) if not hard.empty else np.nan
    target_error = float(hard["target_theme_exposure_error"].abs().max()) if not hard.empty else np.nan
    return pd.DataFrame(
        [
            {
                "check": "stock_coefficient_replication_max_abs_error",
                "value": stock_error,
                "limit": cfg.stock_replication_tolerance,
                "passed": bool(np.isfinite(stock_error) and stock_error <= cfg.stock_replication_tolerance),
            },
            {
                "check": "basket_return_identity_max_abs_error",
                "value": identity_error,
                "limit": cfg.basket_identity_tolerance,
                "passed": bool(np.isfinite(identity_error) and identity_error <= cfg.basket_identity_tolerance),
            },
            {
                "check": "hard_solution_neutrality_max_abs_error",
                "value": neutral_error,
                "limit": cfg.basket_constraint_tolerance,
                "passed": bool(hard.empty or neutral_error <= cfg.basket_constraint_tolerance),
            },
            {
                "check": "hard_solution_target_exposure_max_abs_error",
                "value": target_error,
                "limit": cfg.basket_constraint_tolerance,
                "passed": bool(hard.empty or target_error <= cfg.basket_constraint_tolerance),
            },
            {
                "check": "daily_replication_has_observations",
                "value": int(basket_rep.notna().any(axis=1).sum()),
                "limit": 1,
                "passed": bool(basket_rep.notna().any(axis=1).sum() > 0),
            },
        ]
    )


def run_theme_basket_replication(
    data: Mapping[str, Any], cfg: ReplicationConfig
) -> dict[str, Any]:
    purified, theme_diag = estimate_theme_returns(data, cfg, cfg.momentum_neutral)
    stock_coef, stock_diag = stock_replicated_theme_returns(
        data, cfg, purified, cfg.momentum_neutral, "coefficient", True
    )
    stock_min, stock_min_diag = stock_replicated_theme_returns(
        data, cfg, purified, cfg.momentum_neutral, "min_risk", True
    )
    basket_rep, basket_diag, artifacts = basket_replicated_theme_returns(
        data, cfg, purified, cfg.momentum_neutral, True
    )
    comparison = compare_replication_methods(purified, stock_coef, basket_rep, basket_diag, cfg)
    validation = validate_replication_result(purified, stock_coef, basket_rep, basket_diag, cfg)
    return {
        "purified_theme_returns": purified,
        "stock_coefficient_replicated_theme_returns": stock_coef,
        "stock_min_risk_replicated_theme_returns": stock_min,
        "basket_replicated_theme_returns": basket_rep,
        "theme_return_diagnostics": theme_diag,
        "stock_coefficient_diagnostics": stock_diag,
        "stock_min_risk_diagnostics": stock_min_diag,
        "basket_artifacts": artifacts,
        "comparison": comparison,
        "validation_checks": validation,
        "input_fingerprint": fingerprint_inputs(data, cfg),
        "config_hash": config_hash(cfg),
    }


# ---------------------------------------------------------------------------
# Persistence and plots
# ---------------------------------------------------------------------------


def save_replication_outputs(
    result: Mapping[str, Any],
    cfg: ReplicationConfig,
    out_dir: str | Path | None = None,
) -> tuple[Path, dict[str, Any]]:
    out = Path(out_dir) if out_dir is not None else Path(cfg.output_dir) / cfg.replication_output_subdir
    out.mkdir(parents=True, exist_ok=True)
    artifacts: BasketReplicationArtifacts = result["basket_artifacts"]
    files: dict[str, Any] = {}

    def save_indexed(frame: pd.DataFrame, name: str) -> None:
        temp = frame.copy()
        temp.index.name = "return_date"
        temp.to_csv(out / name)
        files[name] = {"actual": name, "format": "csv"}

    save_indexed(result["purified_theme_returns"], "purified_theme_returns.csv")
    save_indexed(result["stock_coefficient_replicated_theme_returns"], "stock_coefficient_replicated_theme_returns.csv")
    save_indexed(result["stock_min_risk_replicated_theme_returns"], "stock_min_risk_replicated_theme_returns.csv")
    save_indexed(result["basket_replicated_theme_returns"], "basket_ls_replicated_theme_returns.csv")
    save_indexed(artifacts.raw_basket_returns, "raw_theme_basket_returns.csv")
    tables = {
        "theme_return_estimation_diagnostics.csv": result["theme_return_diagnostics"],
        "stock_coefficient_replication_diagnostics.csv": result["stock_coefficient_diagnostics"],
        "stock_min_risk_replication_diagnostics.csv": result["stock_min_risk_diagnostics"],
        "basket_mimicking_diagnostics.csv": artifacts.replication_diagnostics,
        "basket_basis_rank_diagnostics.csv": artifacts.basis_diagnostics,
        "basket_return_coverage.csv": artifacts.return_coverage,
        "replication_metrics_by_theme.csv": result["comparison"]["metrics_by_theme"],
        "replication_metrics_aggregate.csv": result["comparison"]["metrics_aggregate"],
        "validation_checks.csv": result["validation_checks"],
    }
    for name, table in tables.items():
        table.to_csv(out / name, index=False)
        files[name] = {"actual": name, "format": "csv"}
    long_specs = []
    if cfg.save_full_basket_weights:
        long_specs.append(("basket_weights_long.parquet", artifacts.basket_weights_long))
    if cfg.save_lookthrough_stock_weights:
        long_specs.append(("basket_lookthrough_stock_weights_long.parquet", artifacts.lookthrough_weights_long))
    if cfg.save_stock_coefficient_weights:
        long_specs.append(("stock_coefficient_weights_long.parquet", artifacts.stock_coefficient_weights_long))
    if cfg.save_basket_constituent_weights:
        long_specs.append(("tradable_basket_constituent_weights_long.parquet", artifacts.basket_constituent_weights_long))
    for name, table in long_specs:
        files[name] = write_table_with_fallback(table, out / name, index=False)
    with (out / "comparison_config.json").open("w", encoding="utf-8") as handle:
        json.dump(asdict(cfg), handle, indent=2, ensure_ascii=False)
    input_manifest = {
        "replication_schema_version": REPLICATION_SCHEMA_VERSION,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "input_fingerprint": result["input_fingerprint"],
        "config_hash": result["config_hash"],
        "date_start": result["purified_theme_returns"].index.min().isoformat(),
        "date_end": result["purified_theme_returns"].index.max().isoformat(),
        "n_return_dates": int(len(result["purified_theme_returns"])),
        "frequency": "observed_trading_days",
        "annualization": cfg.annualization,
    }
    with (out / "input_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(input_manifest, handle, indent=2, ensure_ascii=False)
    manifest = {**input_manifest, "files": files}
    with (out / "save_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    return out, manifest


def plot_replication_overview(result: Mapping[str, Any], max_themes: int = 4):
    import matplotlib.pyplot as plt

    purified = result["purified_theme_returns"]
    basket = result["basket_replicated_theme_returns"]
    common = purified.columns.intersection(basket.columns)[:max_themes]
    if len(common) == 0:
        return None
    fig, axes = plt.subplots(len(common), 1, figsize=(10, 2.7 * len(common)), squeeze=False)
    for ax, theme in zip(axes[:, 0], common):
        pd.concat([purified[theme].rename("purified"), basket[theme].rename("basket L/S")], axis=1).dropna().cumsum().plot(ax=ax)
        ax.set_title(str(theme))
    fig.tight_layout()
    return fig


def plot_basket_mapping_heatmap(
    artifacts: BasketReplicationArtifacts, exposure_date: pd.Timestamp | None = None
):
    import matplotlib.pyplot as plt

    if not artifacts.basket_weights_by_date:
        return None
    date = pd.Timestamp(exposure_date) if exposure_date is not None else max(artifacts.basket_weights_by_date)
    H = artifacts.basket_weights_by_date[date]
    fig, ax = plt.subplots(figsize=(10, 6))
    image = ax.imshow(H.to_numpy(), aspect="auto")
    ax.set_xticks(range(H.shape[1]), labels=H.columns, rotation=90)
    ax.set_yticks(range(H.shape[0]), labels=H.index)
    ax.set_title(f"Theme-basket mapping H at {date.date()}")
    fig.colorbar(image, ax=ax)
    fig.tight_layout()
    return fig


__all__ = [
    "REPLICATION_SCHEMA_VERSION",
    "ReplicationConfig",
    "Config",
    "ThemeSnapshot",
    "BasketReplicationArtifacts",
    "calendar_month_window",
    "has_calendar_history",
    "generate_synthetic_inputs",
    "load_or_generate_inputs",
    "snapshot_for_date",
    "exposure_snapshot_for_date",
    "estimate_theme_returns",
    "specific_risk_diag",
    "prior_stock_momentum",
    "construct_stock_mimicking_portfolios",
    "construct_mimicking_portfolios",
    "stock_replicated_theme_returns",
    "coefficient_replicated_theme_returns",
    "construct_basket_mimicking_portfolios",
    "compute_theme_basket_returns",
    "basket_replicated_theme_returns",
    "compare_replication_methods",
    "run_theme_basket_replication",
    "validate_replication_result",
    "save_replication_outputs",
    "fingerprint_inputs",
    "input_fingerprint",
    "stable_json_hash",
    "config_hash",
    "config_from_dict",
    "matrix_dict_to_long",
    "matrices_to_long",
    "long_to_matrix_dict",
    "long_to_matrices",
    "write_table_with_fallback",
    "read_table_with_fallback",
    "plot_replication_overview",
    "plot_basket_mapping_heatmap",
    "normalize_factor_weights",
    "one_way_turnover",
]
