#!/usr/bin/env python3
"""Execute clean integrated-factor notebooks in dependency order."""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

NOTEBOOKS = [
    "00_combined_factor_mimicking_diagnostics_integrated_implemented.ipynb",
    "01_binary_combined_factor_tsfm_12m_integrated_implemented.ipynb",
    "02_vol_scaled_combined_factor_tsfm_12m_integrated_implemented.ipynb",
]
THREAD_VARIABLES = (
    "OPENBLAS_NUM_THREADS",
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
)


def execute_one(root: Path, target_name: str, timeout: int) -> None:
    import nbformat
    from nbclient import NotebookClient

    target = root / target_name
    clean = target.with_name(f"{target.stem}_clean.ipynb")
    if not clean.exists():
        raise FileNotFoundError(clean)
    shutil.copy2(clean, target)
    notebook = nbformat.read(target, as_version=4)
    try:
        NotebookClient(
            notebook,
            timeout=timeout,
            kernel_name="python3",
            allow_errors=False,
            record_timing=True,
        ).execute(cwd=str(root))
    except BaseException:
        failed = target.with_name(f"{target.stem}_failed.ipynb")
        nbformat.write(notebook, failed)
        raise
    nbformat.write(notebook, target)
    target.with_name(f"{target.stem}_failed.ipynb").unlink(missing_ok=True)
    print(f"Completed: {target.name}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeout", type=int, default=1200)
    parser.add_argument("--single", choices=NOTEBOOKS, help=argparse.SUPPRESS)
    parser.add_argument("--preserve-outputs", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent

    for variable in THREAD_VARIABLES:
        os.environ.setdefault(variable, "1")

    if args.single:
        execute_one(root, args.single, args.timeout)
        return

    if not args.preserve_outputs:
        shutil.rmtree(root / "integrated_factor_outputs", ignore_errors=True)
        # Keep a real user input intact. Delete only the generated synthetic file
        # when its metadata marker exists next to it.
    env = os.environ.copy()
    for name in NOTEBOOKS:
        subprocess.run(
            [
                sys.executable,
                str(Path(__file__).resolve()),
                "--single",
                name,
                "--timeout",
                str(args.timeout),
            ],
            cwd=root,
            env=env,
            check=True,
        )
    print("All integrated-factor notebooks completed successfully.", flush=True)


if __name__ == "__main__":
    main()
