"""Integrated existing-factor and purified-theme replication.

This module combines investable existing factors with themes purified against
Barra controls and existing factors.  It produces two implementable factor
return universes:

* ``combined_stock_replicated``: all factors are implemented with stock-level
  mimicking portfolios;
* ``combined_hybrid_replicated``: existing factors use stock-level mimicking
  portfolios and purified themes use theme-basket long/short mappings.

All snapshots are point-in-time.  With daily stock returns, the previous
available exposure snapshot is applied to the next daily return observation.
"""
from __future__ import annotations

import hashlib
import json
import pickle
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Literal, Mapping, Sequence

import numpy as np
import pandas as pd


INTEGRATED_REPLICATION_SCHEMA_VERSION = "2.0.0-integrated-daily"


@dataclass
class IntegratedReplicationConfig:
    # Input / output
    input_pickle: str = "data/combined_factor_inputs.pkl"
    output_dir: str = "outputs"
    replication_output_subdir: str = "00_combined_factor_mimicking_diagnostics"
    use_synthetic_if_missing: bool = True
    save_synthetic_input: bool = True

    # Synthetic daily input
    random_seed: int = 42
    n_months: int = 36
    n_stocks: int = 48
    n_barra: int = 4
    n_existing_investable: int = 3
    n_themes: int = 5
    n_base_baskets: int = 9
    start_date: str = "2019-01-02"
    synthetic_frequency: str = "B"

    # Input keys
    stock_returns_key: str = "stock_returns"
    barra_exposures_key: str = "barra_exposures_by_date"
    existing_factor_exposures_key: str = "existing_factor_exposures_by_date"
    theme_exposures_key: str = "theme_exposures_by_date"
    theme_basket_weights_key: str = "theme_basket_weights_by_date"
    factor_metadata_key: str = "factor_metadata"
    factor_alias_mapping_key: str = "factor_alias_mapping"
    external_existing_factor_returns_key: str = "external_existing_factor_returns"

    # Backward-compatible aliases accepted on load
    existing_factor_exposures_aliases: tuple[str, ...] = ("existing_factor_exposures",)
    theme_basket_long_aliases: tuple[str, ...] = ("theme_basket_weights",)

    # Role policy
    enable_existing_factors: bool = True
    exclude_momentum_related_from_signal: bool = True
    include_excluded_momentum_as_control: bool = True
    include_risk_control_in_theme_purification: bool = True
    reject_target_control_conflict: bool = True

    # Normalization and purification
    existing_factor_normalization: str = "zscore_l2"
    barra_style_normalization: str = "as_provided_l2"
    control_normalization: str = "as_provided_l2"
    theme_purification_ridge: float = 1e-8
    minimum_purified_theme_norm: float = 1e-10
    include_intercept: bool = True
    matrix_rank_tolerance: float = 1e-10
    pinv_rcond: float = 1e-10

    # Stock mimicking
    stock_mimicking_method: Literal["minimum_norm", "minimum_risk"] = "minimum_norm"
    stock_mimicking_ridge: float = 1e-8
    risk_lookback_months: int = 36
    combined_factor_condition_number_warn: float = 1e10
    combined_factor_condition_number_fail: float | None = None
    stock_constraint_tolerance: float = 1e-6

    # Tradable baskets
    basket_fallback_to_theme_exposures: bool = True
    normalize_basket_columns_to_one: bool = True
    allow_negative_basket_constituent_weights: bool = False
    basket_net_sum_tolerance: float = 1e-10

    # Theme-basket mapping
    theme_basket_target_scope: str = "full_combined_factor_identity"
    basket_risk_metric: Literal["identity", "specific_diag"] = "identity"
    basket_ridge_alpha: float = 1e-8
    basket_factor_penalty: float = 1e7
    basket_control_penalty: float = 1e7
    basket_constraint_tolerance: float = 1e-6
    basket_rank_tolerance: float = 1e-10
    allow_soft_fallback: bool = True
    active_weight_tolerance: float = 1e-10

    # Return handling
    missing_return_policy: Literal["propagate_nan", "coverage_threshold"] = "coverage_threshold"
    min_return_coverage: float = 0.98
    model_return_ridge: float = 1e-8
    return_identity_tolerance: float = 1e-10

    # Persistence
    annualization: int = 252
    save_stock_returns_used: bool = False
    save_full_snapshots: bool = False


ReplicationConfig = IntegratedReplicationConfig


@dataclass
class IntegratedFactorSnapshot:
    exposure_date: pd.Timestamp
    eligible_stocks: pd.Index
    barra_control_exposures: pd.DataFrame
    existing_investable_exposures: pd.DataFrame
    existing_control_exposures: pd.DataFrame
    raw_theme_exposures: pd.DataFrame
    purified_theme_exposures: pd.DataFrame
    combined_factor_exposures: pd.DataFrame
    control_exposures: pd.DataFrame
    purification_basis: pd.DataFrame
    tradable_theme_basket_weights: pd.DataFrame
    factor_metadata: pd.DataFrame
    normalization_scales: pd.DataFrame
    purification_diagnostics: pd.DataFrame
    diagnostics: dict[str, Any]


@dataclass
class IntegratedFactorBundle:
    factor_returns_by_source: dict[str, pd.DataFrame]
    factor_metadata_by_date: dict[pd.Timestamp, pd.DataFrame]
    combined_snapshots_by_date: dict[pd.Timestamp, IntegratedFactorSnapshot]
    stock_mimicking_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    theme_basket_mapping_by_date: dict[pd.Timestamp, pd.DataFrame]
    theme_basket_constituents_by_date: dict[pd.Timestamp, pd.DataFrame]
    theme_lookthrough_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    replication_diagnostics: pd.DataFrame
    purification_diagnostics: pd.DataFrame
    factor_quality_diagnostics: pd.DataFrame
    factor_return_coverage: pd.DataFrame
    config: dict[str, Any]
    manifest: dict[str, Any]
    stock_returns: pd.DataFrame | None = None


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------


def _json_default(value: Any) -> Any:
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, set):
        return sorted(value)
    raise TypeError(type(value).__name__)


def stable_json_hash(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), default=_json_default)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def config_from_dict(values: Mapping[str, Any]) -> IntegratedReplicationConfig:
    names = {f.name for f in fields(IntegratedReplicationConfig)}
    return IntegratedReplicationConfig(**{k: v for k, v in values.items() if k in names})


def calendar_month_window(
    frame: pd.DataFrame | pd.Series,
    end_date: pd.Timestamp,
    months: int,
    *,
    include_end: bool = True,
) -> pd.DataFrame | pd.Series:
    if months <= 0:
        raise ValueError("months must be positive")
    end = pd.Timestamp(end_date)
    start = end - pd.DateOffset(months=months)
    idx = pd.DatetimeIndex(frame.index)
    right = idx <= end if include_end else idx < end
    return frame.loc[(idx > start) & right]


def has_calendar_history(index: pd.DatetimeIndex, date: pd.Timestamp, months: int) -> bool:
    idx = pd.DatetimeIndex(index)
    if idx.empty:
        return False
    return pd.Timestamp(idx.min()) <= pd.Timestamp(date) - pd.DateOffset(months=months)


def normalize_factor_weights(weights: pd.Series, gross: float = 1.0) -> pd.Series:
    out = weights.astype(float).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    denom = float(out.abs().sum())
    return out * 0.0 if denom <= 0 else out * (gross / denom)


def one_way_turnover(previous: pd.Series, current: pd.Series) -> float:
    labels = previous.index.union(current.index)
    return 0.5 * float(
        (
            current.reindex(labels, fill_value=0.0)
            - previous.reindex(labels, fill_value=0.0)
        ).abs().sum()
    )


def matrix_dict_to_long(
    matrices: Mapping[pd.Timestamp, pd.DataFrame],
    row_name: str,
    column_name: str,
) -> pd.DataFrame:
    rows: list[pd.DataFrame] = []
    for date, matrix in sorted(matrices.items()):
        wide = matrix.rename_axis(index=row_name, columns=column_name).reset_index()
        temp = wide.melt(id_vars=[row_name], var_name=column_name, value_name="weight")
        temp.insert(0, "exposure_date", pd.Timestamp(date))
        rows.append(temp)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(
        columns=["exposure_date", row_name, column_name, "weight"]
    )


def long_to_matrix_dict(
    table: pd.DataFrame,
    row_name: str,
    column_name: str,
    value_name: str = "weight",
) -> dict[pd.Timestamp, pd.DataFrame]:
    if table.empty:
        return {}
    work = table.copy()
    work["exposure_date"] = pd.to_datetime(work["exposure_date"])
    out: dict[pd.Timestamp, pd.DataFrame] = {}
    for date, group in work.groupby("exposure_date", sort=True):
        out[pd.Timestamp(date)] = (
            group.pivot(index=row_name, columns=column_name, values=value_name)
            .sort_index()
            .sort_index(axis=1)
        )
    return out


def write_table_with_fallback(frame: pd.DataFrame, parquet_path: Path) -> dict[str, str]:
    parquet_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        frame.to_parquet(parquet_path, index=False)
        return {"actual": parquet_path.name, "format": "parquet"}
    except Exception:
        csv_path = parquet_path.with_suffix(".csv")
        frame.to_csv(csv_path, index=False)
        return {"actual": csv_path.name, "format": "csv"}


def read_table_with_fallback(parquet_path: Path) -> pd.DataFrame:
    if parquet_path.exists():
        return pd.read_parquet(parquet_path)
    csv_path = parquet_path.with_suffix(".csv")
    if csv_path.exists():
        return pd.read_csv(csv_path)
    raise FileNotFoundError(parquet_path)


def _timestamp_dict(values: Mapping[Any, pd.DataFrame]) -> dict[pd.Timestamp, pd.DataFrame]:
    return {pd.Timestamp(k): v.copy() for k, v in values.items()}


def _latest_matrix(
    matrices: Mapping[pd.Timestamp, pd.DataFrame], date: pd.Timestamp, name: str
) -> tuple[pd.DataFrame, pd.Timestamp]:
    keys = pd.DatetimeIndex(sorted(pd.Timestamp(k) for k in matrices))
    eligible = keys[keys <= pd.Timestamp(date)]
    if eligible.empty:
        raise KeyError(f"No {name} snapshot available on or before {pd.Timestamp(date)}")
    knowledge_date = pd.Timestamp(eligible[-1])
    return matrices[knowledge_date].copy(), knowledge_date


def _long_snapshot_to_dict(
    frame: pd.DataFrame,
    *,
    date_candidates: Sequence[str],
    row_candidates: Sequence[str],
    column_candidates: Sequence[str],
    value_candidates: Sequence[str],
) -> dict[pd.Timestamp, pd.DataFrame]:
    columns = set(frame.columns)
    date_col = next((c for c in date_candidates if c in columns), None)
    row_col = next((c for c in row_candidates if c in columns), None)
    col_col = next((c for c in column_candidates if c in columns), None)
    value_col = next((c for c in value_candidates if c in columns), None)
    if not all([date_col, row_col, col_col, value_col]):
        raise ValueError(
            "Long exposure table must contain date, row, column, and value fields; "
            f"received columns={list(frame.columns)}"
        )
    work = frame[[date_col, row_col, col_col, value_col]].copy()
    work[date_col] = pd.to_datetime(work[date_col])
    work[row_col] = work[row_col].astype(str)
    work[col_col] = work[col_col].astype(str)
    out: dict[pd.Timestamp, pd.DataFrame] = {}
    for date, group in work.groupby(date_col, sort=True):
        out[pd.Timestamp(date)] = group.pivot_table(
            index=row_col, columns=col_col, values=value_col, aggfunc="sum"
        )
    return out


def _coerce_exposure_mapping(value: Any, kind: str) -> dict[pd.Timestamp, pd.DataFrame]:
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return _timestamp_dict(value)
    if not isinstance(value, pd.DataFrame):
        raise TypeError(f"{kind} exposures must be a mapping or DataFrame")
    if isinstance(value.index, pd.MultiIndex) or {
        "date", "knowledge_date", "effective_date", "exposure_date"
    }.intersection(value.columns):
        if kind == "existing":
            return _long_snapshot_to_dict(
                value,
                date_candidates=("knowledge_date", "exposure_date", "effective_date", "date"),
                row_candidates=("security_id", "stock_id", "asset_id"),
                column_candidates=("factor_id", "factor", "existing_factor_id"),
                value_candidates=("exposure", "value", "weight"),
            )
        return _long_snapshot_to_dict(
            value,
            date_candidates=("knowledge_date", "exposure_date", "effective_date", "date"),
            row_candidates=("security_id", "stock_id", "asset_id"),
            column_candidates=("theme_id", "basket_id", "factor_id"),
            value_candidates=("weight", "exposure", "value"),
        )
    raise ValueError(f"Static wide {kind} exposures require an explicit date mapping")


def normalize_integrated_inputs(
    data: Mapping[str, Any], cfg: IntegratedReplicationConfig
) -> dict[str, Any]:
    out = dict(data)
    if cfg.stock_returns_key not in out:
        raise KeyError(cfg.stock_returns_key)
    stock_returns = out[cfg.stock_returns_key].copy().astype(float)
    stock_returns.index = pd.to_datetime(stock_returns.index)
    stock_returns.columns = stock_returns.columns.astype(str)
    if stock_returns.index.has_duplicates or stock_returns.columns.has_duplicates:
        raise ValueError("stock_returns has duplicate dates or stock labels")
    out[cfg.stock_returns_key] = stock_returns.sort_index()

    # Existing-factor aliases used by the attached reference notebooks.
    if cfg.existing_factor_exposures_key not in out:
        for alias in cfg.existing_factor_exposures_aliases:
            if alias in out:
                out[cfg.existing_factor_exposures_key] = out[alias]
                break
    out[cfg.existing_factor_exposures_key] = _coerce_exposure_mapping(
        out.get(cfg.existing_factor_exposures_key), "existing"
    )
    out[cfg.barra_exposures_key] = _coerce_exposure_mapping(
        out.get(cfg.barra_exposures_key), "existing"
    )
    out[cfg.theme_exposures_key] = _coerce_exposure_mapping(
        out.get(cfg.theme_exposures_key), "theme"
    )

    if cfg.theme_basket_weights_key not in out:
        for alias in cfg.theme_basket_long_aliases:
            if alias in out:
                out[cfg.theme_basket_weights_key] = out[alias]
                break
    out[cfg.theme_basket_weights_key] = _coerce_exposure_mapping(
        out.get(cfg.theme_basket_weights_key), "theme"
    )
    if not out[cfg.theme_exposures_key] and out[cfg.theme_basket_weights_key]:
        # Backward-compatible reference notebook format: one long-only theme
        # definition table is used as both the raw theme definition and tradable basket.
        out[cfg.theme_exposures_key] = {
            k: v.copy() for k, v in out[cfg.theme_basket_weights_key].items()
        }
    if not out[cfg.theme_basket_weights_key] and out[cfg.theme_exposures_key]:
        if cfg.basket_fallback_to_theme_exposures:
            out[cfg.theme_basket_weights_key] = {
                k: v.copy() for k, v in out[cfg.theme_exposures_key].items()
            }
        else:
            raise KeyError(cfg.theme_basket_weights_key)

    for key in (
        cfg.barra_exposures_key,
        cfg.existing_factor_exposures_key,
        cfg.theme_exposures_key,
        cfg.theme_basket_weights_key,
    ):
        fixed: dict[pd.Timestamp, pd.DataFrame] = {}
        for date, frame in out[key].items():
            temp = frame.copy().astype(float)
            temp.index = temp.index.astype(str)
            temp.columns = temp.columns.astype(str)
            if temp.index.has_duplicates or temp.columns.has_duplicates:
                raise ValueError(f"Duplicate labels in {key} at {date}")
            fixed[pd.Timestamp(date)] = temp.sort_index().sort_index(axis=1)
        out[key] = fixed

    metadata = out.get(cfg.factor_metadata_key)
    if metadata is not None:
        if not isinstance(metadata, pd.DataFrame):
            metadata = pd.DataFrame(metadata)
        out[cfg.factor_metadata_key] = metadata.copy()
    else:
        out[cfg.factor_metadata_key] = pd.DataFrame()
    out.setdefault(cfg.factor_alias_mapping_key, {})
    if cfg.external_existing_factor_returns_key in out:
        ext = out[cfg.external_existing_factor_returns_key].copy().astype(float)
        ext.index = pd.to_datetime(ext.index)
        ext.columns = ext.columns.astype(str)
        out[cfg.external_existing_factor_returns_key] = ext.sort_index()
    return out


def input_fingerprint(data: Mapping[str, Any], cfg: IntegratedReplicationConfig) -> str:
    returns = data[cfg.stock_returns_key]
    payload = {
        "return_dates": [str(x) for x in returns.index],
        "stocks": [str(x) for x in returns.columns],
        "return_shape": returns.shape,
        "return_checksum": float(np.nansum(returns.to_numpy())),
        "barra_dates": sorted(str(x) for x in data.get(cfg.barra_exposures_key, {})),
        "existing_dates": sorted(str(x) for x in data.get(cfg.existing_factor_exposures_key, {})),
        "theme_dates": sorted(str(x) for x in data.get(cfg.theme_exposures_key, {})),
        "basket_dates": sorted(str(x) for x in data.get(cfg.theme_basket_weights_key, {})),
        "metadata_hash": stable_json_hash(
            data.get(cfg.factor_metadata_key, pd.DataFrame()).fillna("").to_dict("records")
        ),
        "alias_hash": stable_json_hash(data.get(cfg.factor_alias_mapping_key, {})),
    }
    return stable_json_hash(payload)


# ---------------------------------------------------------------------------
# Metadata and exposure normalization
# ---------------------------------------------------------------------------


def _is_momentum_name(value: str) -> bool:
    upper = str(value).upper()
    return any(token in upper for token in ("MOM", "REVERSAL", "STR", "52W", "TREND"))


def _canonical_default(source_type: str, raw: str) -> str:
    prefix = {"existing": "EXISTING", "barra": "BARRA", "theme": "THEME"}[source_type]
    return f"{prefix}::{raw}"


def _alias_for(alias_mapping: Mapping[str, str], source_type: str, raw: str) -> str | None:
    for key in (f"{source_type}:{raw}", f"{source_type}::{raw}", raw):
        if key in alias_mapping:
            return str(alias_mapping[key])
    return None


def _union_columns(matrices: Mapping[pd.Timestamp, pd.DataFrame]) -> list[str]:
    seen: dict[str, None] = {}
    for _, frame in sorted(matrices.items()):
        for col in frame.columns:
            seen.setdefault(str(col), None)
    return list(seen)


def resolve_factor_metadata(
    data: Mapping[str, Any],
    cfg: IntegratedReplicationConfig,
) -> pd.DataFrame:
    """Resolve canonical IDs, source mappings, roles, and implementation types.

    Metadata may describe raw factors using ``factor_id`` only, or explicitly
    provide ``source_type`` and ``source_factor_id``.  Processing logic uses the
    resolved columns, never string prefixes.
    """
    meta_in = data.get(cfg.factor_metadata_key, pd.DataFrame()).copy()
    if meta_in.empty:
        meta_in = pd.DataFrame(columns=["factor_id"])
    if "factor_id" not in meta_in.columns:
        raise ValueError("factor_metadata must contain factor_id")
    meta_in["factor_id"] = meta_in["factor_id"].astype(str)
    if "source_factor_id" not in meta_in.columns:
        meta_in["source_factor_id"] = meta_in["factor_id"]
    meta_in["source_factor_id"] = meta_in["source_factor_id"].astype(str)
    if "source_type" not in meta_in.columns:
        meta_in["source_type"] = ""
    meta_in["source_type"] = meta_in["source_type"].fillna("").astype(str).str.lower()

    aliases = data.get(cfg.factor_alias_mapping_key, {}) or {}
    source_sets = {
        "existing": _union_columns(data.get(cfg.existing_factor_exposures_key, {})),
        "barra": _union_columns(data.get(cfg.barra_exposures_key, {})),
        "theme": _union_columns(data.get(cfg.theme_exposures_key, {})),
    }
    rows: list[dict[str, Any]] = []
    used_meta_indices: set[int] = set()

    for source_type, raw_values in source_sets.items():
        for raw in raw_values:
            candidates = meta_in.index[
                (meta_in["source_factor_id"] == raw)
                & (
                    (meta_in["source_type"] == source_type)
                    | (meta_in["source_type"] == "")
                )
            ].tolist()
            # An unspecified source is assigned to existing first, then theme,
            # while Barra requires explicit source_type if the same raw name is
            # also present in existing exposures.
            if source_type == "barra" and raw in source_sets["existing"]:
                explicit = [i for i in candidates if meta_in.loc[i, "source_type"] == "barra"]
                candidates = explicit
            if len(candidates) > 1:
                raise ValueError(f"Ambiguous metadata for {source_type}:{raw}")
            record: dict[str, Any]
            if candidates:
                idx = candidates[0]
                used_meta_indices.add(idx)
                record = meta_in.loc[idx].to_dict()
                canonical = str(record["factor_id"])
            else:
                record = {}
                canonical = _alias_for(aliases, source_type, raw) or _canonical_default(source_type, raw)
            role_default = "investable_signal" if source_type == "existing" else (
                "risk_control_only" if source_type == "barra" else "investable_signal"
            )
            role = str(record.get("role", role_default) or role_default)
            factor_type = str(record.get("factor_type", "theme" if source_type == "theme" else "existing"))
            is_momentum = bool(record.get("is_momentum_related", _is_momentum_name(raw)))
            effective_role = role
            if role == "investable_signal" and is_momentum and cfg.exclude_momentum_related_from_signal:
                effective_role = "purification_basis" if cfg.include_excluded_momentum_as_control else "excluded"
            signal_enabled = bool(record.get("signal_enabled", True)) and effective_role == "investable_signal"
            block_default = "theme" if factor_type == "theme" else "existing"
            rows.append(
                {
                    **record,
                    "factor_id": canonical,
                    "base_factor_id": str(record.get("base_factor_id", raw)),
                    "source_factor_id": raw,
                    "source_type": source_type,
                    "factor_type": factor_type,
                    "role": role,
                    "effective_role": effective_role,
                    "block_id": str(record.get("block_id", block_default)),
                    "is_momentum_related": is_momentum,
                    "implementation_type": str(
                        record.get(
                            "implementation_type",
                            "theme_basket" if factor_type == "theme" else "stock_mimicking",
                        )
                    ),
                    "normalization_policy": str(
                        record.get(
                            "normalization_policy",
                            cfg.existing_factor_normalization
                            if factor_type != "theme"
                            else "purified_l2",
                        )
                    ),
                    "signal_enabled": signal_enabled,
                }
            )

    # Explicit metadata rows not represented in any exposure are retained as
    # inactive metadata so factor lifecycle is visible rather than silently lost.
    for idx, row in meta_in.iterrows():
        if idx in used_meta_indices:
            continue
        source_type = str(row.get("source_type", "") or "existing")
        factor_type = str(row.get("factor_type", "theme" if source_type == "theme" else "existing"))
        role = str(row.get("role", "excluded"))
        is_momentum = bool(row.get("is_momentum_related", _is_momentum_name(row["factor_id"])))
        effective_role = role
        if role == "investable_signal" and is_momentum and cfg.exclude_momentum_related_from_signal:
            effective_role = "purification_basis" if cfg.include_excluded_momentum_as_control else "excluded"
        rows.append(
            {
                **row.to_dict(),
                "factor_id": str(row["factor_id"]),
                "base_factor_id": str(row.get("base_factor_id", row["source_factor_id"])),
                "source_factor_id": str(row["source_factor_id"]),
                "source_type": source_type,
                "factor_type": factor_type,
                "role": role,
                "effective_role": effective_role,
                "block_id": str(row.get("block_id", "theme" if factor_type == "theme" else "existing")),
                "is_momentum_related": is_momentum,
                "implementation_type": str(row.get("implementation_type", "none")),
                "normalization_policy": str(row.get("normalization_policy", "as_provided")),
                "signal_enabled": bool(row.get("signal_enabled", True)) and effective_role == "investable_signal",
            }
        )

    meta = pd.DataFrame(rows)
    if meta.empty:
        raise ValueError("No factor metadata could be resolved")
    duplicate_sources = meta.groupby("factor_id")[["source_type", "source_factor_id"]].nunique()
    conflict_ids = duplicate_sources.index[
        (duplicate_sources["source_type"] > 1) | (duplicate_sources["source_factor_id"] > 1)
    ].tolist()
    if conflict_ids:
        raise ValueError(
            "A canonical factor maps to multiple raw sources. Resolve with explicit metadata: "
            + ", ".join(conflict_ids)
        )
    meta = meta.drop_duplicates("factor_id", keep="first").copy()
    if cfg.reject_target_control_conflict:
        # One row per canonical factor makes a role conflict explicit if callers
        # attempted to encode multiple roles in a delimited value.
        bad = meta[meta["effective_role"].astype(str).str.contains(r"investable.*(?:control|basis)|(?:control|basis).*investable", regex=True)]
        if not bad.empty:
            raise ValueError(f"Target/control role conflict: {bad['factor_id'].tolist()}")
    role_order = {"investable_signal": 0, "purification_basis": 1, "risk_control_only": 2, "excluded": 3}
    type_order = {"existing": 0, "theme": 1}
    meta["_type_order"] = meta["factor_type"].map(type_order).fillna(9)
    meta["_role_order"] = meta["effective_role"].map(role_order).fillna(9)
    meta = meta.sort_values(["_role_order", "_type_order", "factor_id"]).drop(columns=["_type_order", "_role_order"])
    meta["stable_order"] = np.arange(len(meta))
    return meta.set_index("factor_id", drop=False)


def _source_exposure_matrix(
    raw: pd.DataFrame,
    metadata: pd.DataFrame,
    source_type: str,
) -> pd.DataFrame:
    rows = metadata[metadata["source_type"].eq(source_type)]
    columns: dict[str, pd.Series] = {}
    for factor_id, row in rows.iterrows():
        raw_id = str(row["source_factor_id"])
        if raw_id in raw.columns:
            columns[factor_id] = raw[raw_id]
    return pd.DataFrame(columns, index=raw.index, dtype=float)


def _normalize_series(series: pd.Series, policy: str, floor: float = 1e-12) -> tuple[pd.Series, dict[str, float]]:
    x = series.astype(float).copy()
    raw_norm = float(np.linalg.norm(x.fillna(0.0)))
    mean = 0.0
    std = 1.0
    if policy in {"zscore", "zscore_l2"}:
        mean = float(x.mean())
        x = x - mean
        std = float(x.std(ddof=0))
        if not np.isfinite(std) or std <= floor:
            return x * np.nan, {"raw_norm": raw_norm, "mean": mean, "std": std, "l2": 0.0}
        x = x / std
    elif policy in {"center", "center_l2"}:
        mean = float(x.mean())
        x = x - mean
    elif policy not in {"l2", "as_provided", "as_provided_l2", "none"}:
        raise ValueError(f"Unknown normalization policy: {policy}")
    l2 = float(np.linalg.norm(x.fillna(0.0)))
    if policy in {"zscore_l2", "center_l2", "l2", "as_provided_l2"}:
        if not np.isfinite(l2) or l2 <= floor:
            return x * np.nan, {"raw_norm": raw_norm, "mean": mean, "std": std, "l2": l2}
        x = x / l2
    return x, {"raw_norm": raw_norm, "mean": mean, "std": std, "l2": l2}


def _normalize_exposure_frame(
    frame: pd.DataFrame,
    metadata: pd.DataFrame | None,
    default_policy: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    out: dict[str, pd.Series] = {}
    rows: list[dict[str, Any]] = []
    for col in frame.columns:
        policy = default_policy
        if metadata is not None and col in metadata.index:
            policy = str(metadata.loc[col, "normalization_policy"] or default_policy)
        normalized, diag = _normalize_series(frame[col], policy)
        if normalized.notna().all() and float(np.linalg.norm(normalized)) > 1e-12:
            out[col] = normalized
            rows.append({"factor_id": col, "policy": policy, **diag, "active": True})
        else:
            rows.append({"factor_id": col, "policy": policy, **diag, "active": False})
    return pd.DataFrame(out, index=frame.index), pd.DataFrame(rows).set_index("factor_id") if rows else pd.DataFrame()


def _independent_columns(frame: pd.DataFrame, tolerance: float) -> tuple[pd.DataFrame, list[str]]:
    if frame.empty:
        return frame.copy(), []
    selected: list[str] = []
    dropped: list[str] = []
    current = np.empty((len(frame), 0))
    rank = 0
    for col in frame.columns:
        vector = frame[col].to_numpy()[:, None]
        candidate = np.hstack([current, vector])
        candidate_rank = np.linalg.matrix_rank(candidate, tol=tolerance)
        if candidate_rank > rank:
            selected.append(col)
            current = candidate
            rank = candidate_rank
        else:
            dropped.append(col)
    return frame[selected], dropped


def _validate_baskets(P: pd.DataFrame, cfg: IntegratedReplicationConfig) -> pd.DataFrame:
    out = P.astype(float).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    if not cfg.allow_negative_basket_constituent_weights and (
        out < -cfg.basket_net_sum_tolerance
    ).any().any():
        raise ValueError("Tradable basket constituent weights contain negative values")
    gross = out.abs().sum(axis=0)
    out = out.loc[:, gross > cfg.basket_net_sum_tolerance]
    if out.empty:
        raise ValueError("No non-zero tradable theme baskets")
    if cfg.normalize_basket_columns_to_one:
        net = out.sum(axis=0)
        if (net.abs() <= cfg.basket_net_sum_tolerance).any():
            raise ValueError("A tradable theme basket has zero net weight")
        out = out.divide(net, axis=1)
    return out


# ---------------------------------------------------------------------------
# Point-in-time integrated snapshot
# ---------------------------------------------------------------------------


def build_integrated_factor_snapshot(
    data: Mapping[str, Any],
    cfg: IntegratedReplicationConfig,
    date: Any,
    *,
    resolved_metadata: pd.DataFrame | None = None,
) -> IntegratedFactorSnapshot:
    date = pd.Timestamp(date)
    metadata = resolved_metadata.copy() if resolved_metadata is not None else resolve_factor_metadata(data, cfg)
    stock_returns = data[cfg.stock_returns_key]

    barra_raw, barra_date = _latest_matrix(data.get(cfg.barra_exposures_key, {}), date, "Barra") if data.get(cfg.barra_exposures_key) else (pd.DataFrame(index=stock_returns.columns), date)
    existing_raw, existing_date = _latest_matrix(data.get(cfg.existing_factor_exposures_key, {}), date, "existing-factor") if data.get(cfg.existing_factor_exposures_key) else (pd.DataFrame(index=stock_returns.columns), date)
    theme_raw, theme_date = _latest_matrix(data.get(cfg.theme_exposures_key, {}), date, "theme")
    basket_raw, basket_date = _latest_matrix(data.get(cfg.theme_basket_weights_key, {}), date, "theme-basket")

    matrices = [stock_returns.columns, theme_raw.index, basket_raw.index]
    if not barra_raw.empty:
        matrices.append(barra_raw.index)
    if not existing_raw.empty:
        matrices.append(existing_raw.index)
    common = pd.Index(matrices[0].astype(str))
    for idx in matrices[1:]:
        common = common.intersection(pd.Index(idx.astype(str)))
    if len(common) < 8:
        raise ValueError(f"Insufficient common stocks at {date}: {len(common)}")

    barra_raw = barra_raw.reindex(common)
    existing_raw = existing_raw.reindex(common)
    theme_raw = theme_raw.reindex(common).fillna(0.0)
    basket_raw = basket_raw.reindex(common).fillna(0.0)

    barra_all = _source_exposure_matrix(barra_raw, metadata, "barra")
    existing_all = _source_exposure_matrix(existing_raw, metadata, "existing")
    source_combined = pd.concat([barra_all, existing_all], axis=1)

    investable_ids = metadata.index[
        metadata["factor_type"].eq("existing")
        & metadata["effective_role"].eq("investable_signal")
        & metadata["signal_enabled"].astype(bool)
    ].tolist()
    barra_control_ids = metadata.index[
        metadata["source_type"].eq("barra")
        & metadata["effective_role"].isin(["purification_basis", "risk_control_only"])
    ].tolist()
    existing_control_ids = metadata.index[
        metadata["source_type"].eq("existing")
        & metadata["effective_role"].isin(["purification_basis", "risk_control_only"])
    ].tolist()

    conflict = set(investable_ids).intersection(barra_control_ids + existing_control_ids)
    if conflict and cfg.reject_target_control_conflict:
        raise ValueError(f"Target/control conflict at {date}: {sorted(conflict)}")

    E_raw = source_combined.reindex(columns=[c for c in investable_ids if c in source_combined.columns])
    Bc_raw = barra_all.reindex(columns=[c for c in barra_control_ids if c in barra_all.columns])
    C_raw = existing_all.reindex(columns=[c for c in existing_control_ids if c in existing_all.columns])

    required = pd.concat([E_raw, Bc_raw, C_raw], axis=1)
    valid_rows = required.replace([np.inf, -np.inf], np.nan).notna().all(axis=1) if not required.empty else pd.Series(True, index=common)
    eligible = common[valid_rows.to_numpy()]
    E_raw = E_raw.reindex(eligible)
    Bc_raw = Bc_raw.reindex(eligible)
    C_raw = C_raw.reindex(eligible)
    theme_raw = theme_raw.reindex(eligible).fillna(0.0)
    basket_raw = basket_raw.reindex(eligible).fillna(0.0)

    E, E_scale = _normalize_exposure_frame(E_raw, metadata, cfg.existing_factor_normalization)
    Bc, B_scale = _normalize_exposure_frame(Bc_raw, metadata, cfg.barra_style_normalization)
    C, C_scale = _normalize_exposure_frame(C_raw, metadata, cfg.control_normalization)

    basis_parts: list[pd.DataFrame] = []
    if cfg.include_intercept:
        basis_parts.append(pd.DataFrame({"CONTROL::INTERCEPT": 1.0}, index=eligible))
    if not Bc.empty:
        basis_parts.append(Bc)
    if not E.empty:
        basis_parts.append(E)
    if not C.empty:
        include_ids = []
        for col in C.columns:
            role = metadata.loc[col, "effective_role"]
            if role == "purification_basis" or cfg.include_risk_control_in_theme_purification:
                include_ids.append(col)
        if include_ids:
            basis_parts.append(C[include_ids])
    Q = pd.concat(basis_parts, axis=1) if basis_parts else pd.DataFrame(index=eligible)
    Q, dropped_basis = _independent_columns(Q, cfg.matrix_rank_tolerance)

    # Map raw theme columns to canonical theme IDs.
    theme_meta = metadata[metadata["source_type"].eq("theme")]
    raw_to_theme = {
        str(row["source_factor_id"]): factor_id for factor_id, row in theme_meta.iterrows()
    }
    A = theme_raw.rename(columns={raw: raw_to_theme.get(str(raw), _canonical_default("theme", str(raw))) for raw in theme_raw.columns})
    A = A.loc[:, ~A.columns.duplicated()].astype(float)

    if Q.empty:
        residual = A.copy()
        beta = pd.DataFrame(index=[], columns=A.columns)
        fitted = A * 0.0
    else:
        Qv, Av = Q.to_numpy(), A.to_numpy()
        beta_v = np.linalg.pinv(
            Qv.T @ Qv + cfg.theme_purification_ridge * np.eye(Qv.shape[1]),
            rcond=cfg.pinv_rcond,
        ) @ Qv.T @ Av
        fitted = pd.DataFrame(Qv @ beta_v, index=eligible, columns=A.columns)
        residual = A - fitted
        beta = pd.DataFrame(beta_v, index=Q.columns, columns=A.columns)

    z_cols: dict[str, pd.Series] = {}
    purification_rows: list[dict[str, Any]] = []
    for theme in A.columns:
        raw_vec = A[theme]
        resid = residual[theme]
        raw_norm = float(np.linalg.norm(raw_vec))
        resid_norm = float(np.linalg.norm(resid))
        active = np.isfinite(resid_norm) and resid_norm > cfg.minimum_purified_theme_norm
        if active:
            z = resid / resid_norm
            z_cols[theme] = z
        else:
            z = pd.Series(np.nan, index=eligible)
        total_ss = float(np.sum((raw_vec - raw_vec.mean()) ** 2))
        resid_ss = float(np.sum(resid**2))
        r2 = 1.0 - resid_ss / total_ss if total_ss > 0 else np.nan
        def group_max(frame: pd.DataFrame) -> float:
            return float(frame.T.dot(z).abs().max()) if active and not frame.empty else 0.0
        purification_rows.append(
            {
                "exposure_date": date,
                "factor_id": theme,
                "raw_norm": raw_norm,
                "purified_residual_norm": resid_norm,
                "normalization_scale": resid_norm,
                "purification_r_squared": r2,
                "max_abs_barra_control_exposure": group_max(Bc),
                "max_abs_investable_existing_exposure": group_max(E),
                "max_abs_existing_control_exposure": group_max(C),
                "active": active,
                "inactive_reason": "" if active else "purified_norm_below_threshold",
            }
        )
    Z = pd.DataFrame(z_cols, index=eligible)

    F = pd.concat([E, Z], axis=1)
    if F.columns.has_duplicates:
        raise ValueError("Combined factor IDs are not unique")
    nonzero = F.columns[np.linalg.norm(F.to_numpy(), axis=0) > cfg.minimum_purified_theme_norm]
    F = F.loc[:, nonzero]

    control_parts: list[pd.DataFrame] = []
    if cfg.include_intercept:
        control_parts.append(pd.DataFrame({"CONTROL::INTERCEPT": 1.0}, index=eligible))
    if not Bc.empty:
        control_parts.append(Bc)
    if not C.empty:
        control_parts.append(C)
    R = pd.concat(control_parts, axis=1) if control_parts else pd.DataFrame(index=eligible)
    R, dropped_controls = _independent_columns(R, cfg.matrix_rank_tolerance)
    target_control_overlap = set(F.columns).intersection(R.columns)
    if target_control_overlap and cfg.reject_target_control_conflict:
        raise ValueError(f"Target/control overlap: {sorted(target_control_overlap)}")

    P = _validate_baskets(basket_raw, cfg)
    P.index = eligible

    current_meta = metadata.loc[metadata.index.intersection(F.columns)].copy()
    current_meta["active"] = True
    current_meta["exposure_date"] = date
    current_meta = current_meta.sort_values("stable_order")

    norm_scales = pd.concat(
        [
            E_scale.assign(group="existing_investable"),
            B_scale.assign(group="barra_control"),
            C_scale.assign(group="existing_control"),
        ],
        axis=0,
    ) if any(not x.empty for x in (E_scale, B_scale, C_scale)) else pd.DataFrame()

    Fv = F.to_numpy()
    rank_f = int(np.linalg.matrix_rank(Fv, tol=cfg.matrix_rank_tolerance)) if F.shape[1] else 0
    condition_f = float(np.linalg.cond(Fv)) if F.shape[1] else np.nan
    if cfg.combined_factor_condition_number_fail is not None and condition_f > cfg.combined_factor_condition_number_fail:
        raise ValueError(f"Combined factor condition number exceeds fail threshold: {condition_f}")

    diagnostics = {
        "exposure_date": date,
        "barra_knowledge_date": barra_date,
        "existing_knowledge_date": existing_date,
        "theme_knowledge_date": theme_date,
        "basket_knowledge_date": basket_date,
        "n_stocks": len(eligible),
        "n_existing_investable": E.shape[1],
        "n_existing_controls": C.shape[1],
        "n_barra_controls": Bc.shape[1],
        "n_themes": Z.shape[1],
        "n_combined_factors": F.shape[1],
        "combined_factor_rank": rank_f,
        "combined_factor_condition_number": condition_f,
        "dropped_purification_basis_columns": dropped_basis,
        "dropped_control_columns": dropped_controls,
        "purification_beta": beta,
    }
    return IntegratedFactorSnapshot(
        exposure_date=date,
        eligible_stocks=eligible,
        barra_control_exposures=Bc,
        existing_investable_exposures=E,
        existing_control_exposures=C,
        raw_theme_exposures=A.reindex(columns=Z.columns),
        purified_theme_exposures=Z,
        combined_factor_exposures=F,
        control_exposures=R,
        purification_basis=Q,
        tradable_theme_basket_weights=P,
        factor_metadata=current_meta,
        normalization_scales=norm_scales,
        purification_diagnostics=pd.DataFrame(purification_rows),
        diagnostics=diagnostics,
    )


# ---------------------------------------------------------------------------
# Replication solvers
# ---------------------------------------------------------------------------


def specific_variance_diag(
    data: Mapping[str, Any],
    cfg: IntegratedReplicationConfig,
    date: pd.Timestamp,
    stocks: pd.Index,
) -> pd.Series:
    for key in ("specific_variances_by_date", "specific_risks_by_date"):
        values = data.get(key)
        if values:
            try:
                raw, _ = _latest_matrix(values, date, key)
            except Exception:
                raw = None
            if raw is not None:
                series = raw.iloc[:, 0] if isinstance(raw, pd.DataFrame) else pd.Series(raw)
                series = series.reindex(stocks).astype(float)
                if key == "specific_risks_by_date":
                    series = series**2
                fallback = float(series.dropna().median()) if series.notna().any() else 1.0
                return series.fillna(fallback).clip(lower=1e-8)
    history = calendar_month_window(
        data[cfg.stock_returns_key], pd.Timestamp(date), cfg.risk_lookback_months, include_end=False
    ).reindex(columns=stocks)
    variance = history.var(axis=0, ddof=1)
    fallback = float(variance.dropna().median()) if variance.notna().any() else 1e-4
    if not np.isfinite(fallback) or fallback <= 0:
        fallback = 1e-4
    return variance.fillna(fallback).clip(lower=1e-8)


def construct_integrated_stock_mimicking_portfolios(
    data: Mapping[str, Any],
    cfg: IntegratedReplicationConfig,
    snapshot: IntegratedFactorSnapshot,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    R = snapshot.control_exposures
    F = snapshot.combined_factor_exposures
    constraints = pd.concat([R, F], axis=1)
    Cv = constraints.to_numpy()
    n_controls = R.shape[1]
    n_factors = F.shape[1]
    target = np.zeros((constraints.shape[1], n_factors))
    target[n_controls:, :] = np.eye(n_factors)
    if cfg.stock_mimicking_method == "minimum_norm":
        Qinv = np.eye(len(constraints))
    elif cfg.stock_mimicking_method == "minimum_risk":
        variance = specific_variance_diag(data, cfg, snapshot.exposure_date, constraints.index)
        Qinv = np.diag(1.0 / variance.to_numpy())
    else:
        raise ValueError(f"Unknown stock_mimicking_method: {cfg.stock_mimicking_method}")
    middle = np.linalg.pinv(
        Cv.T @ Qinv @ Cv + cfg.stock_mimicking_ridge * np.eye(Cv.shape[1]),
        rcond=cfg.pinv_rcond,
    )
    Mv = Qinv @ Cv @ middle @ target
    M = pd.DataFrame(Mv, index=constraints.index, columns=F.columns)
    factor_exposure = F.T.dot(M)
    control_exposure = R.T.dot(M)
    rows: list[dict[str, Any]] = []
    for factor in F.columns:
        k = F.columns.get_loc(factor)
        exposure = factor_exposure[factor]
        off = exposure.drop(index=factor)
        target_error = float(exposure.loc[factor] - 1.0)
        control_max = float(control_exposure[factor].abs().max()) if not R.empty else 0.0
        other_max = float(off.abs().max()) if len(off) else 0.0
        status = "solved" if max(abs(target_error), control_max, other_max) <= cfg.stock_constraint_tolerance else "approximate"
        rows.append(
            {
                "exposure_date": snapshot.exposure_date,
                "factor_id": factor,
                "factor_type": snapshot.factor_metadata.loc[factor, "factor_type"],
                "solver_status": status,
                "target_exposure": float(exposure.loc[factor]),
                "target_exposure_error": target_error,
                "max_other_factor_exposure": other_max,
                "max_control_exposure": control_max,
                "gross": float(M[factor].abs().sum()),
                "net": float(M[factor].sum()),
                "long_gross": float(M[factor].clip(lower=0).sum()),
                "short_gross": float(-M[factor].clip(upper=0).sum()),
                "max_abs_stock_weight": float(M[factor].abs().max()),
                "constraint_rank": int(np.linalg.matrix_rank(Cv, tol=cfg.matrix_rank_tolerance)),
                "condition_number": float(np.linalg.cond(Cv)),
            }
        )
    return M, pd.DataFrame(rows), pd.concat(
        {"control": control_exposure, "factor": factor_exposure}, axis=0
    )


def _independent_rows(matrix: np.ndarray, tolerance: float) -> np.ndarray:
    selected: list[int] = []
    current = np.empty((0, matrix.shape[1]))
    rank = 0
    for i, row in enumerate(matrix):
        candidate = np.vstack([current, row])
        candidate_rank = np.linalg.matrix_rank(candidate, tol=tolerance)
        if candidate_rank > rank:
            selected.append(i)
            current = candidate
            rank = candidate_rank
    return np.asarray(selected, dtype=int)


def _solve_equality_qp(
    G: np.ndarray,
    c: np.ndarray,
    constraints: np.ndarray,
    targets: np.ndarray,
    cfg: IntegratedReplicationConfig,
) -> tuple[np.ndarray | None, dict[str, Any]]:
    keep = _independent_rows(constraints, cfg.basket_rank_tolerance)
    C = constraints[keep]
    d = targets[keep]
    KKT = np.block([[G, C.T], [C, np.zeros((C.shape[0], C.shape[0]))]])
    rhs = np.concatenate([c, d])
    condition = float(np.linalg.cond(KKT))
    try:
        solution = np.linalg.solve(KKT, rhs)
        status = "hard_solved"
    except np.linalg.LinAlgError:
        solution = np.linalg.pinv(KKT, rcond=cfg.pinv_rcond) @ rhs
        status = "hard_solved_pinv"
    h = solution[: G.shape[0]]
    residual = float(np.max(np.abs(constraints @ h - targets)))
    if not np.isfinite(h).all() or residual > cfg.basket_constraint_tolerance:
        return None, {
            "solver_status": "hard_infeasible",
            "condition_number_kkt": condition,
            "hard_constraint_residual": residual,
        }
    return h, {
        "solver_status": status,
        "condition_number_kkt": condition,
        "hard_constraint_residual": residual,
    }


def construct_integrated_theme_basket_mapping(
    data: Mapping[str, Any],
    cfg: IntegratedReplicationConfig,
    snapshot: IntegratedFactorSnapshot,
    stock_mimicking_weights: pd.DataFrame,
    previous_mapping: pd.DataFrame | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    F = snapshot.combined_factor_exposures
    R = snapshot.control_exposures
    P = snapshot.tradable_theme_basket_weights.reindex(F.index).fillna(0.0)
    theme_ids = snapshot.factor_metadata.index[
        snapshot.factor_metadata["factor_type"].eq("theme")
    ].tolist()
    if not theme_ids:
        empty_h = pd.DataFrame(index=P.columns)
        empty_w = pd.DataFrame(index=P.index)
        return empty_h, empty_w, pd.DataFrame(), {
            "exposure_date": snapshot.exposure_date,
            "n_base_baskets": P.shape[1],
            "n_themes": 0,
        }
    M_theme = stock_mimicking_weights.reindex(columns=theme_ids)
    if cfg.basket_risk_metric == "identity":
        Q = np.eye(len(P))
    elif cfg.basket_risk_metric == "specific_diag":
        Q = np.diag(specific_variance_diag(data, cfg, snapshot.exposure_date, P.index).to_numpy())
    else:
        raise ValueError(f"Unknown basket_risk_metric: {cfg.basket_risk_metric}")

    Pv, Fv, Rv = P.to_numpy(), F.to_numpy(), R.to_numpy()
    G = Pv.T @ Q @ Pv + cfg.basket_ridge_alpha * np.eye(P.shape[1])
    factor_on_basket = Fv.T @ Pv
    control_on_basket = Rv.T @ Pv
    constraints = np.vstack([control_on_basket, factor_on_basket])
    H = pd.DataFrame(index=P.columns, columns=theme_ids, dtype=float)
    rows: list[dict[str, Any]] = []
    for theme in theme_ids:
        target_stock = M_theme[theme].to_numpy()
        c = Pv.T @ Q @ target_stock
        target = np.zeros(R.shape[1] + F.shape[1])
        target[R.shape[1] + F.columns.get_loc(theme)] = 1.0
        h, info = _solve_equality_qp(G, c, constraints, target, cfg)
        if h is None:
            if not cfg.allow_soft_fallback:
                h = np.full(P.shape[1], np.nan)
                info["solver_status"] = "infeasible_no_fallback"
            else:
                soft_G = (
                    G
                    + cfg.basket_control_penalty * control_on_basket.T @ control_on_basket
                    + cfg.basket_factor_penalty * factor_on_basket.T @ factor_on_basket
                )
                desired_factor = np.zeros(F.shape[1])
                desired_factor[F.columns.get_loc(theme)] = 1.0
                soft_c = c + cfg.basket_factor_penalty * factor_on_basket.T @ desired_factor
                try:
                    h = np.linalg.solve(soft_G, soft_c)
                    status = "soft_solved"
                except np.linalg.LinAlgError:
                    h = np.linalg.pinv(soft_G, rcond=cfg.pinv_rcond) @ soft_c
                    status = "soft_solved_pinv"
                info = {
                    "solver_status": status,
                    "condition_number_kkt": float(np.linalg.cond(soft_G)),
                    "hard_constraint_residual": float(np.max(np.abs(constraints @ h - target))),
                }
        H[theme] = h
        w = Pv @ h
        fexp = Fv.T @ w
        rexp = Rv.T @ w
        target_idx = F.columns.get_loc(theme)
        existing_mask = snapshot.factor_metadata.reindex(F.columns)["factor_type"].eq("existing").to_numpy()
        theme_mask = snapshot.factor_metadata.reindex(F.columns)["factor_type"].eq("theme").to_numpy()
        theme_mask[target_idx] = False
        distance = w - target_stock
        prev_h = (
            previous_mapping[theme].reindex(P.columns).fillna(0.0).to_numpy()
            if previous_mapping is not None and theme in previous_mapping.columns
            else np.zeros(P.shape[1])
        )
        rows.append(
            {
                "exposure_date": snapshot.exposure_date,
                "factor_id": theme,
                "factor_type": "theme",
                "solver_status": info["solver_status"],
                "target_theme_exposure": float(fexp[target_idx]),
                "target_exposure_error": float(fexp[target_idx] - 1.0),
                "max_other_theme_exposure": float(np.max(np.abs(fexp[theme_mask]))) if theme_mask.any() else 0.0,
                "max_existing_factor_contamination": float(np.max(np.abs(fexp[existing_mask]))) if existing_mask.any() else 0.0,
                "max_control_exposure": float(np.max(np.abs(rexp))) if len(rexp) else 0.0,
                "basket_gross": float(np.sum(np.abs(h))),
                "basket_net": float(np.sum(h)),
                "lookthrough_gross": float(np.sum(np.abs(w))),
                "lookthrough_net": float(np.sum(w)),
                "max_abs_basket_weight": float(np.max(np.abs(h))),
                "n_long_baskets": int(np.sum(h > cfg.active_weight_tolerance)),
                "n_short_baskets": int(np.sum(h < -cfg.active_weight_tolerance)),
                "risk_weighted_distance_to_stock_target": float(np.sqrt(max(distance.T @ Q @ distance, 0.0))),
                "mapping_turnover_from_previous": 0.5 * float(np.sum(np.abs(h - prev_h))),
                **info,
            }
        )
    W = P.dot(H)
    basis = {
        "exposure_date": snapshot.exposure_date,
        "n_stocks": len(P),
        "n_base_baskets": P.shape[1],
        "n_themes": len(theme_ids),
        "rank_basket_matrix": int(np.linalg.matrix_rank(Pv, tol=cfg.basket_rank_tolerance)),
        "rank_factor_on_basket": int(np.linalg.matrix_rank(factor_on_basket, tol=cfg.basket_rank_tolerance)),
        "rank_control_on_basket": int(np.linalg.matrix_rank(control_on_basket, tol=cfg.basket_rank_tolerance)),
        "condition_number_basket_matrix": float(np.linalg.cond(Pv)),
        "constraint_nullspace_dimension": int(
            P.shape[1] - np.linalg.matrix_rank(constraints, tol=cfg.basket_rank_tolerance)
        ),
    }
    return H, W, pd.DataFrame(rows), basis


def _weighted_return_vector(
    returns: pd.Series,
    weights: pd.DataFrame,
    cfg: IntegratedReplicationConfig,
) -> tuple[pd.Series, pd.Series]:
    if weights.empty:
        return pd.Series(dtype=float), pd.Series(dtype=float)
    aligned = returns.reindex(weights.index)
    denominator_abs = weights.abs().sum(axis=0).replace(0.0, np.nan)
    coverage = weights.abs().where(aligned.notna(), 0.0).sum(axis=0) / denominator_abs
    if cfg.missing_return_policy == "propagate_nan":
        values = weights.T.dot(aligned)
        values.loc[coverage < 1.0 - 1e-12] = np.nan
        return values, coverage
    if cfg.missing_return_policy != "coverage_threshold":
        raise ValueError(cfg.missing_return_policy)
    valid = aligned.notna()
    numerator = weights.loc[valid].T.dot(aligned.loc[valid])
    values = numerator.copy()
    long_only = (weights >= -1e-14).all(axis=0)
    for col in long_only[long_only].index:
        available_net = float(weights.loc[valid, col].sum())
        full_net = float(weights[col].sum())
        values.loc[col] = numerator.loc[col] * full_net / available_net if abs(available_net) > 1e-14 else np.nan
    values.loc[coverage < cfg.min_return_coverage] = np.nan
    return values, coverage


def _model_factor_return(
    stock_return: pd.Series,
    snapshot: IntegratedFactorSnapshot,
    cfg: IntegratedReplicationConfig,
) -> tuple[pd.Series, float]:
    X = pd.concat([snapshot.control_exposures, snapshot.combined_factor_exposures], axis=1)
    y = stock_return.reindex(X.index)
    valid = y.notna() & X.notna().all(axis=1)
    coverage = float(valid.mean())
    if coverage < cfg.min_return_coverage:
        return pd.Series(np.nan, index=snapshot.combined_factor_exposures.columns), coverage
    Xv = X.loc[valid].to_numpy()
    yv = y.loc[valid].to_numpy()
    beta = np.linalg.pinv(
        Xv.T @ Xv + cfg.model_return_ridge * np.eye(Xv.shape[1]),
        rcond=cfg.pinv_rcond,
    ) @ Xv.T @ yv
    values = beta[-snapshot.combined_factor_exposures.shape[1]:]
    return pd.Series(values, index=snapshot.combined_factor_exposures.columns), coverage


# ---------------------------------------------------------------------------
# End-to-end replication
# ---------------------------------------------------------------------------


def run_integrated_factor_replication(
    data: Mapping[str, Any],
    cfg: IntegratedReplicationConfig,
) -> IntegratedFactorBundle:
    normalized = normalize_integrated_inputs(data, cfg)
    metadata = resolve_factor_metadata(normalized, cfg)
    stock_returns = normalized[cfg.stock_returns_key]
    dates = pd.DatetimeIndex(stock_returns.index)

    model_rows: list[pd.Series] = []
    stock_rows: list[pd.Series] = []
    hybrid_rows: list[pd.Series] = []
    return_coverage_rows: list[dict[str, Any]] = []
    stock_diag_rows: list[pd.DataFrame] = []
    basket_diag_rows: list[pd.DataFrame] = []
    snapshot_diag_rows: list[dict[str, Any]] = []
    purification_rows: list[pd.DataFrame] = []
    quality_rows: list[pd.DataFrame] = []

    snapshots: dict[pd.Timestamp, IntegratedFactorSnapshot] = {}
    metadata_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    M_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    H_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    P_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    W_theme_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    previous_H: pd.DataFrame | None = None

    # Cache identical exposure snapshots for minimum-norm / identity-risk mode.
    solver_cache: dict[tuple[Any, ...], tuple[IntegratedFactorSnapshot, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]] = {}

    for i in range(len(dates) - 1):
        exposure_date = pd.Timestamp(dates[i])
        return_date = pd.Timestamp(dates[i + 1])
        try:
            snapshot = build_integrated_factor_snapshot(
                normalized, cfg, exposure_date, resolved_metadata=metadata
            )
            key = (
                snapshot.diagnostics["barra_knowledge_date"],
                snapshot.diagnostics["existing_knowledge_date"],
                snapshot.diagnostics["theme_knowledge_date"],
                snapshot.diagnostics["basket_knowledge_date"],
                tuple(snapshot.combined_factor_exposures.columns),
            )
            can_cache = cfg.stock_mimicking_method == "minimum_norm" and cfg.basket_risk_metric == "identity"
            if can_cache and key in solver_cache:
                _, M_template, stock_diag_template, H_template, W_template, basket_pack = solver_cache[key]
                M = M_template.copy()
                stock_diag = stock_diag_template.copy()
                stock_diag["exposure_date"] = exposure_date
                H = H_template.copy()
                W_theme = W_template.copy()
                basket_diag = basket_pack["diag"].copy()
                if not basket_diag.empty:
                    basket_diag["exposure_date"] = exposure_date
                basis = dict(basket_pack["basis"])
                basis["exposure_date"] = exposure_date
            else:
                M, stock_diag, _ = construct_integrated_stock_mimicking_portfolios(
                    normalized, cfg, snapshot
                )
                H, W_theme, basket_diag, basis = construct_integrated_theme_basket_mapping(
                    normalized, cfg, snapshot, M, previous_H
                )
                if can_cache:
                    solver_cache[key] = (
                        snapshot,
                        M.copy(),
                        stock_diag.copy(),
                        H.copy(),
                        W_theme.copy(),
                        {"diag": basket_diag.copy(), "basis": dict(basis)},
                    )

            r = stock_returns.loc[return_date]
            model_values, model_coverage = _model_factor_return(r, snapshot, cfg)
            stock_values, stock_coverage = _weighted_return_vector(r, M, cfg)
            base_basket_values, basket_coverage = _weighted_return_vector(
                r, snapshot.tradable_theme_basket_weights, cfg
            )
            theme_values = H.T.dot(base_basket_values) if not H.empty else pd.Series(dtype=float)
            theme_look_values, theme_coverage = _weighted_return_vector(r, W_theme, cfg)
            theme_identity_error = float(
                (theme_values - theme_look_values.reindex(theme_values.index)).abs().max()
            ) if len(theme_values) else 0.0

            hybrid_values = stock_values.copy()
            for factor in theme_values.index:
                hybrid_values.loc[factor] = theme_values.loc[factor]
            hybrid_values = hybrid_values.reindex(snapshot.combined_factor_exposures.columns)

            model_rows.append(model_values.rename(return_date))
            stock_rows.append(stock_values.rename(return_date))
            hybrid_rows.append(hybrid_values.rename(return_date))
            return_coverage_rows.append(
                {
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "model_stock_coverage": model_coverage,
                    "min_stock_mimicking_coverage": float(stock_coverage.min()) if len(stock_coverage) else np.nan,
                    "min_base_basket_coverage": float(basket_coverage.min()) if len(basket_coverage) else np.nan,
                    "min_theme_lookthrough_coverage": float(theme_coverage.min()) if len(theme_coverage) else np.nan,
                    "theme_return_identity_error": theme_identity_error,
                    "status": "ok" if theme_identity_error <= cfg.return_identity_tolerance else "identity_failure",
                }
            )

            # Point-in-time factor quality table.
            quality = stock_diag.copy()
            quality = quality.rename(
                columns={
                    "solver_status": "stock_mimicking_status",
                    "max_other_factor_exposure": "other_factor_exposure",
                    "max_control_exposure": "control_exposure",
                }
            )
            quality["return_coverage"] = stock_coverage.reindex(quality["factor_id"]).to_numpy()
            quality["theme_basket_solver_status"] = "not_applicable"
            quality["existing_factor_contamination"] = 0.0
            quality["basket_return_coverage"] = np.nan
            if not basket_diag.empty:
                bindex = basket_diag.set_index("factor_id")
                for factor in quality.loc[quality["factor_type"].eq("theme"), "factor_id"]:
                    if factor in bindex.index:
                        quality.loc[quality["factor_id"].eq(factor), "theme_basket_solver_status"] = bindex.loc[factor, "solver_status"]
                        quality.loc[quality["factor_id"].eq(factor), "existing_factor_contamination"] = bindex.loc[factor, "max_existing_factor_contamination"]
                        quality.loc[quality["factor_id"].eq(factor), "basket_return_coverage"] = theme_coverage.get(factor, np.nan)
            quality["signal_eligible"] = quality["factor_id"].map(snapshot.factor_metadata["signal_enabled"]).fillna(False)
            quality["implementation_eligible"] = quality["stock_mimicking_status"].isin(["solved", "approximate"])
            quality["eligible"] = quality["signal_eligible"] & quality["implementation_eligible"]
            quality["exclusion_reason"] = np.where(quality["eligible"], "", "metadata_or_solver")
            quality["exposure_date"] = exposure_date

            snapshots[exposure_date] = snapshot
            metadata_by_date[exposure_date] = snapshot.factor_metadata.copy()
            M_by_date[exposure_date] = M
            H_by_date[exposure_date] = H
            P_by_date[exposure_date] = snapshot.tradable_theme_basket_weights.copy()
            W_theme_by_date[exposure_date] = W_theme
            previous_H = H
            stock_diag_rows.append(stock_diag)
            if not basket_diag.empty:
                basket_diag_rows.append(basket_diag)
            snap_diag = {k: v for k, v in snapshot.diagnostics.items() if not isinstance(v, (pd.DataFrame, pd.Series))}
            snap_diag.update(basis)
            snapshot_diag_rows.append(snap_diag)
            purification_rows.append(snapshot.purification_diagnostics)
            quality_rows.append(quality)
        except Exception as exc:
            return_coverage_rows.append(
                {
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "status": f"error:{type(exc).__name__}:{exc}",
                }
            )

    factor_returns = {
        "combined_model": pd.DataFrame(model_rows).sort_index(),
        "combined_stock_replicated": pd.DataFrame(stock_rows).sort_index(),
        "combined_hybrid_replicated": pd.DataFrame(hybrid_rows).sort_index(),
    }
    external = normalized.get(cfg.external_existing_factor_returns_key)
    if external is not None:
        factor_returns["external_existing"] = external.copy()

    config_payload = asdict(cfg)
    fingerprint = input_fingerprint(normalized, cfg)
    config_hash = stable_json_hash(config_payload)
    manifest = {
        "replication_schema_version": INTEGRATED_REPLICATION_SCHEMA_VERSION,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "input_fingerprint": fingerprint,
        "config_hash": config_hash,
        "date_start": str(stock_returns.index.min()),
        "date_end": str(stock_returns.index.max()),
        "n_stock_return_dates": len(stock_returns),
        "n_replication_dates": len(factor_returns["combined_hybrid_replicated"]),
        "factor_ids": list(factor_returns["combined_hybrid_replicated"].columns),
    }
    replication_diag_parts = []
    if stock_diag_rows:
        replication_diag_parts.append(pd.concat(stock_diag_rows, ignore_index=True).assign(replication_layer="stock"))
    if basket_diag_rows:
        replication_diag_parts.append(pd.concat(basket_diag_rows, ignore_index=True).assign(replication_layer="theme_basket"))
    snapshot_diag = pd.DataFrame(snapshot_diag_rows)
    if not snapshot_diag.empty:
        snapshot_diag["replication_layer"] = "snapshot"
        replication_diag_parts.append(snapshot_diag)

    return IntegratedFactorBundle(
        factor_returns_by_source=factor_returns,
        factor_metadata_by_date=metadata_by_date,
        combined_snapshots_by_date=snapshots,
        stock_mimicking_weights_by_date=M_by_date,
        theme_basket_mapping_by_date=H_by_date,
        theme_basket_constituents_by_date=P_by_date,
        theme_lookthrough_weights_by_date=W_theme_by_date,
        replication_diagnostics=pd.concat(replication_diag_parts, ignore_index=True, sort=False) if replication_diag_parts else pd.DataFrame(),
        purification_diagnostics=pd.concat(purification_rows, ignore_index=True) if purification_rows else pd.DataFrame(),
        factor_quality_diagnostics=pd.concat(quality_rows, ignore_index=True) if quality_rows else pd.DataFrame(),
        factor_return_coverage=pd.DataFrame(return_coverage_rows),
        config={
            **config_payload,
            "replication_schema_version": INTEGRATED_REPLICATION_SCHEMA_VERSION,
            "input_fingerprint": fingerprint,
            "config_hash": config_hash,
        },
        manifest=manifest,
        stock_returns=stock_returns.copy(),
    )


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


def save_integrated_replication_outputs(
    bundle: IntegratedFactorBundle,
    cfg: IntegratedReplicationConfig,
    output_dir: str | Path | None = None,
) -> tuple[Path, dict[str, Any]]:
    out = Path(output_dir or (Path(cfg.output_dir) / cfg.replication_output_subdir))
    out.mkdir(parents=True, exist_ok=True)
    name_map = {
        "combined_model": "combined_model_factor_returns.csv",
        "combined_stock_replicated": "combined_stock_replicated_factor_returns.csv",
        "combined_hybrid_replicated": "combined_hybrid_replicated_factor_returns.csv",
        "external_existing": "external_existing_factor_returns.csv",
    }
    for source, frame in bundle.factor_returns_by_source.items():
        frame.to_csv(out / name_map.get(source, f"{source}_factor_returns.csv"))

    files: dict[str, Any] = {}
    meta_rows = []
    for date, meta in sorted(bundle.factor_metadata_by_date.items()):
        temp = meta.reset_index(drop=True).copy()
        temp = temp.drop(columns=["exposure_date"], errors="ignore")
        temp.insert(0, "exposure_date", pd.Timestamp(date))
        meta_rows.append(temp)
    files["factor_metadata_by_date"] = write_table_with_fallback(
        pd.concat(meta_rows, ignore_index=True) if meta_rows else pd.DataFrame(),
        out / "factor_metadata_by_date.parquet",
    )
    tables = [
        ("combined_stock_mimicking_weights_long", bundle.stock_mimicking_weights_by_date, "stock_id", "factor_id"),
        ("theme_basket_mapping_long", bundle.theme_basket_mapping_by_date, "base_basket", "factor_id"),
        ("theme_basket_constituents_long", bundle.theme_basket_constituents_by_date, "stock_id", "base_basket"),
        ("theme_lookthrough_weights_long", bundle.theme_lookthrough_weights_by_date, "stock_id", "factor_id"),
    ]
    for stem, matrices, row_name, column_name in tables:
        files[stem] = write_table_with_fallback(
            matrix_dict_to_long(matrices, row_name, column_name), out / f"{stem}.parquet"
        )
    files["replication_diagnostics"] = write_table_with_fallback(
        bundle.replication_diagnostics, out / "replication_diagnostics.parquet"
    )
    files["purification_diagnostics"] = write_table_with_fallback(
        bundle.purification_diagnostics, out / "purification_diagnostics.parquet"
    )
    files["factor_quality_diagnostics"] = write_table_with_fallback(
        bundle.factor_quality_diagnostics, out / "factor_quality_diagnostics.parquet"
    )
    files["factor_return_coverage"] = write_table_with_fallback(
        bundle.factor_return_coverage, out / "factor_return_coverage.parquet"
    )
    if cfg.save_stock_returns_used and bundle.stock_returns is not None:
        bundle.stock_returns.to_csv(out / "stock_returns_used.csv")

    if not bundle.replication_diagnostics.empty and "replication_layer" in bundle.replication_diagnostics:
        bundle.replication_diagnostics.loc[
            bundle.replication_diagnostics["replication_layer"].eq("stock")
        ].to_csv(out / "combined_stock_mimicking_diagnostics.csv", index=False)
        bundle.replication_diagnostics.loc[
            bundle.replication_diagnostics["replication_layer"].eq("theme_basket")
        ].to_csv(out / "integrated_theme_basket_diagnostics.csv", index=False)
        bundle.replication_diagnostics.loc[
            bundle.replication_diagnostics["replication_layer"].eq("snapshot")
        ].to_csv(out / "combined_factor_snapshot_diagnostics.csv", index=False)

    correlation_rows: list[dict[str, Any]] = []
    for date, snapshot in sorted(bundle.combined_snapshots_by_date.items()):
        corr = snapshot.combined_factor_exposures.corr()
        for i, left in enumerate(corr.columns):
            for right in corr.columns[i + 1 :]:
                value = float(corr.loc[left, right])
                correlation_rows.append({
                    "exposure_date": pd.Timestamp(date),
                    "factor_id_left": left,
                    "factor_id_right": right,
                    "correlation": value,
                    "high_correlation": abs(value) >= 0.95,
                })
    correlation_table = pd.DataFrame(correlation_rows)
    files["combined_factor_correlation"] = write_table_with_fallback(
        correlation_table, out / "combined_factor_correlation.parquet"
    )
    correlation_table.loc[correlation_table.get("high_correlation", pd.Series(dtype=bool)).fillna(False)].to_csv(
        out / "high_correlation_factor_pairs.csv", index=False
    )

    (out / "config.json").write_text(
        json.dumps(bundle.config, indent=2, ensure_ascii=False, default=_json_default), encoding="utf-8"
    )
    manifest = dict(bundle.manifest)
    manifest["files"] = files
    (out / "save_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False, default=_json_default), encoding="utf-8"
    )
    return out, manifest


def _read_return_csv(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, index_col=0)
    frame.index = pd.to_datetime(frame.index)
    return frame


def load_integrated_factor_bundle(
    output_dir: str | Path,
    *,
    stock_returns: pd.DataFrame | None = None,
) -> IntegratedFactorBundle:
    out = Path(output_dir)
    config = json.loads((out / "config.json").read_text(encoding="utf-8"))
    manifest = json.loads((out / "save_manifest.json").read_text(encoding="utf-8"))
    sources = {}
    candidates = {
        "combined_model": "combined_model_factor_returns.csv",
        "combined_stock_replicated": "combined_stock_replicated_factor_returns.csv",
        "combined_hybrid_replicated": "combined_hybrid_replicated_factor_returns.csv",
        "external_existing": "external_existing_factor_returns.csv",
    }
    for source, filename in candidates.items():
        path = out / filename
        if path.exists():
            sources[source] = _read_return_csv(path)

    meta_table = read_table_with_fallback(out / "factor_metadata_by_date.parquet")
    metadata_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    if not meta_table.empty:
        meta_table["exposure_date"] = pd.to_datetime(meta_table["exposure_date"])
        for date, group in meta_table.groupby("exposure_date", sort=True):
            metadata_by_date[pd.Timestamp(date)] = group.drop(columns="exposure_date").set_index("factor_id", drop=False)

    M = long_to_matrix_dict(
        read_table_with_fallback(out / "combined_stock_mimicking_weights_long.parquet"),
        "stock_id", "factor_id"
    )
    H = long_to_matrix_dict(
        read_table_with_fallback(out / "theme_basket_mapping_long.parquet"),
        "base_basket", "factor_id"
    )
    P = long_to_matrix_dict(
        read_table_with_fallback(out / "theme_basket_constituents_long.parquet"),
        "stock_id", "base_basket"
    )
    W = long_to_matrix_dict(
        read_table_with_fallback(out / "theme_lookthrough_weights_long.parquet"),
        "stock_id", "factor_id"
    )
    if stock_returns is None and (out / "stock_returns_used.csv").exists():
        stock_returns = _read_return_csv(out / "stock_returns_used.csv")
    elif stock_returns is not None:
        stock_returns = stock_returns.copy()
        stock_returns.index = pd.to_datetime(stock_returns.index)

    return IntegratedFactorBundle(
        factor_returns_by_source=sources,
        factor_metadata_by_date=metadata_by_date,
        combined_snapshots_by_date={},
        stock_mimicking_weights_by_date=M,
        theme_basket_mapping_by_date=H,
        theme_basket_constituents_by_date=P,
        theme_lookthrough_weights_by_date=W,
        replication_diagnostics=read_table_with_fallback(out / "replication_diagnostics.parquet"),
        purification_diagnostics=read_table_with_fallback(out / "purification_diagnostics.parquet"),
        factor_quality_diagnostics=read_table_with_fallback(out / "factor_quality_diagnostics.parquet"),
        factor_return_coverage=read_table_with_fallback(out / "factor_return_coverage.parquet"),
        config=config,
        manifest=manifest,
        stock_returns=stock_returns,
    )


# ---------------------------------------------------------------------------
# Synthetic daily data
# ---------------------------------------------------------------------------


def _make_long_only_baskets(
    rng: np.random.Generator, n_stocks: int, n_baskets: int
) -> np.ndarray:
    P = np.zeros((n_stocks, n_baskets))
    low = max(6, n_stocks // 8)
    high = max(low + 1, min(n_stocks, n_stocks // 2))
    for j in range(n_baskets):
        count = int(rng.integers(low, high + 1))
        selected = rng.choice(n_stocks, size=count, replace=False)
        weights = rng.lognormal(0.0, 0.6, size=count)
        P[selected, j] = weights / weights.sum()
    return P


def generate_synthetic_integrated_inputs(
    cfg: IntegratedReplicationConfig,
) -> dict[str, Any]:
    rng = np.random.default_rng(cfg.random_seed)
    start = pd.Timestamp(cfg.start_date)
    end = start + pd.DateOffset(months=cfg.n_months)
    dates = pd.date_range(start, end, freq=cfg.synthetic_frequency)
    stocks = pd.Index([f"STK{i:04d}" for i in range(cfg.n_stocks)], name="stock_id")
    month_groups = pd.Series(dates, index=dates).groupby(dates.to_period("M"))
    snapshot_dates = pd.DatetimeIndex([group.iloc[0] for _, group in month_groups])

    barra_raw_ids = ["SIZE", "BETA", "VOLATILITY", "LEVERAGE"][: cfg.n_barra]
    existing_raw_ids = ["VALUE", "QUALITY", "PROFITABILITY", "MOM12", "LIQUIDITY"]
    theme_raw_ids = [f"THEME_{i:02d}" for i in range(1, cfg.n_themes + 1)]
    basket_ids = [f"BASKET_{i:02d}" for i in range(1, cfg.n_base_baskets + 1)]

    base_barra = rng.normal(size=(cfg.n_stocks, len(barra_raw_ids)))
    base_existing = rng.normal(size=(cfg.n_stocks, len(existing_raw_ids)))
    if "SIZE" in barra_raw_ids:
        base_existing[:, 0] += 0.25 * base_barra[:, barra_raw_ids.index("SIZE")]
    barra_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    existing_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    theme_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    basket_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    basket_base = _make_long_only_baskets(rng, cfg.n_stocks, cfg.n_base_baskets)

    for j, date in enumerate(snapshot_dates):
        B = pd.DataFrame(
            base_barra + rng.normal(scale=0.06, size=base_barra.shape),
            index=stocks,
            columns=barra_raw_ids,
        )
        E = pd.DataFrame(
            base_existing + rng.normal(scale=0.08, size=base_existing.shape),
            index=stocks,
            columns=existing_raw_ids,
        )
        if j > 0 and j % 6 == 0:
            basket_base = 0.9 * basket_base + 0.1 * _make_long_only_baskets(
                rng, cfg.n_stocks, cfg.n_base_baskets
            )
            basket_base = basket_base / basket_base.sum(axis=0, keepdims=True)
        P = pd.DataFrame(basket_base, index=stocks, columns=basket_ids)
        A = pd.DataFrame(index=stocks)
        for k, theme in enumerate(theme_raw_ids):
            core = P.iloc[:, k % P.shape[1]]
            contamination = 0.35 * E["VALUE"] - 0.20 * E["MOM12"]
            if "BETA" in B.columns:
                contamination = contamination + 0.20 * B["BETA"]
            A[theme] = core + contamination / max(float(contamination.abs().sum()), 1.0)
        barra_by_date[pd.Timestamp(date)] = B
        existing_by_date[pd.Timestamp(date)] = E
        theme_by_date[pd.Timestamp(date)] = A
        basket_by_date[pd.Timestamp(date)] = P

    metadata_rows = [
        {
            "factor_id": "EXISTING::SIZE",
            "base_factor_id": "SIZE",
            "source_type": "barra",
            "source_factor_id": "SIZE",
            "factor_type": "existing",
            "role": "investable_signal",
            "block_id": "existing",
            "is_momentum_related": False,
            "normalization_policy": "zscore_l2",
        },
        {
            "factor_id": "EXISTING::VALUE",
            "base_factor_id": "VALUE",
            "source_type": "existing",
            "source_factor_id": "VALUE",
            "factor_type": "existing",
            "role": "investable_signal",
            "block_id": "existing",
            "is_momentum_related": False,
            "normalization_policy": "zscore_l2",
        },
        {
            "factor_id": "EXISTING::QUALITY",
            "base_factor_id": "QUALITY",
            "source_type": "existing",
            "source_factor_id": "QUALITY",
            "factor_type": "existing",
            "role": "investable_signal",
            "block_id": "existing",
            "is_momentum_related": False,
            "normalization_policy": "zscore_l2",
        },
        {
            "factor_id": "EXISTING::PROFITABILITY",
            "base_factor_id": "PROFITABILITY",
            "source_type": "existing",
            "source_factor_id": "PROFITABILITY",
            "factor_type": "existing",
            "role": "investable_signal",
            "block_id": "existing",
            "is_momentum_related": False,
            "normalization_policy": "zscore_l2",
        },
        {
            "factor_id": "EXISTING::MOM12",
            "base_factor_id": "MOM12",
            "source_type": "existing",
            "source_factor_id": "MOM12",
            "factor_type": "existing",
            "role": "purification_basis",
            "block_id": "control",
            "is_momentum_related": True,
            "normalization_policy": "zscore_l2",
        },
        {
            "factor_id": "EXISTING::LIQUIDITY",
            "base_factor_id": "LIQUIDITY",
            "source_type": "existing",
            "source_factor_id": "LIQUIDITY",
            "factor_type": "existing",
            "role": "risk_control_only",
            "block_id": "control",
            "is_momentum_related": False,
            "normalization_policy": "zscore_l2",
        },
    ]
    factor_metadata = pd.DataFrame(metadata_rows)

    zero_returns = pd.DataFrame(0.0, index=dates, columns=stocks)
    provisional = {
        cfg.stock_returns_key: zero_returns,
        cfg.barra_exposures_key: barra_by_date,
        cfg.existing_factor_exposures_key: existing_by_date,
        cfg.theme_exposures_key: theme_by_date,
        cfg.theme_basket_weights_key: basket_by_date,
        cfg.factor_metadata_key: factor_metadata,
        cfg.factor_alias_mapping_key: {},
    }
    provisional = normalize_integrated_inputs(provisional, cfg)
    resolved = resolve_factor_metadata(provisional, cfg)
    stock_returns = pd.DataFrame(np.nan, index=dates, columns=stocks)
    stock_returns.iloc[0] = rng.normal(0.0, 0.008, size=cfg.n_stocks)
    latent_existing: dict[str, float] = {}
    latent_theme: dict[str, float] = {}
    true_existing_rows = []
    for i in range(len(dates) - 1):
        date, next_date = pd.Timestamp(dates[i]), pd.Timestamp(dates[i + 1])
        snap = build_integrated_factor_snapshot(provisional, cfg, date, resolved_metadata=resolved)
        eids = snap.factor_metadata.index[snap.factor_metadata["factor_type"].eq("existing")]
        tids = snap.factor_metadata.index[snap.factor_metadata["factor_type"].eq("theme")]
        g = pd.Series(0.0, index=snap.combined_factor_exposures.columns)
        for factor in eids:
            previous = latent_existing.get(factor, 0.0)
            value = 0.08 * previous + rng.normal(0.00006, 0.0012)
            latent_existing[factor] = value
            g.loc[factor] = value
        for factor in tids:
            previous = latent_theme.get(factor, 0.0)
            value = 0.10 * previous + rng.normal(0.00004, 0.0015)
            latent_theme[factor] = value
            g.loc[factor] = value
        control_shock = rng.normal(0.0, 0.0006, size=snap.control_exposures.shape[1])
        return_vector = (
            snap.combined_factor_exposures.to_numpy() @ g.to_numpy()
            + snap.control_exposures.to_numpy() @ control_shock
            + rng.normal(0.0, 0.009, size=len(snap.eligible_stocks))
        )
        stock_returns.loc[next_date, snap.eligible_stocks] = return_vector
        true_existing_rows.append(pd.Series(g.reindex(eids), name=next_date))
    provisional[cfg.stock_returns_key] = stock_returns
    provisional[cfg.external_existing_factor_returns_key] = pd.DataFrame(true_existing_rows).sort_index()
    provisional["metadata"] = {"source": "synthetic_integrated_daily", "seed": cfg.random_seed}
    return provisional


def load_or_generate_integrated_inputs(
    cfg: IntegratedReplicationConfig,
) -> dict[str, Any]:
    path = Path(cfg.input_pickle)
    if path.exists():
        with path.open("rb") as handle:
            data = pickle.load(handle)
        normalized = normalize_integrated_inputs(data, cfg)
        normalized.setdefault("metadata", {})["source"] = str(path)
        return normalized
    if not cfg.use_synthetic_if_missing:
        raise FileNotFoundError(path)
    data = generate_synthetic_integrated_inputs(cfg)
    if cfg.save_synthetic_input:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("wb") as handle:
            pickle.dump(data, handle)
        data.setdefault("metadata", {})["source"] = str(path)
    return data


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def run_replication_validation_checks(
    bundle: IntegratedFactorBundle,
    cfg: IntegratedReplicationConfig,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    stock_diag = bundle.replication_diagnostics.query("replication_layer == 'stock'") if not bundle.replication_diagnostics.empty and "replication_layer" in bundle.replication_diagnostics else pd.DataFrame()
    basket_diag = bundle.replication_diagnostics.query("replication_layer == 'theme_basket'") if not bundle.replication_diagnostics.empty and "replication_layer" in bundle.replication_diagnostics else pd.DataFrame()
    max_stock_target = float(stock_diag["target_exposure_error"].abs().max()) if not stock_diag.empty else np.nan
    max_stock_control = float(stock_diag["max_control_exposure"].abs().max()) if not stock_diag.empty else np.nan
    max_theme_identity = float(bundle.factor_return_coverage["theme_return_identity_error"].dropna().max()) if "theme_return_identity_error" in bundle.factor_return_coverage else np.nan
    target_control_overlap = 0
    for snap in bundle.combined_snapshots_by_date.values():
        target_control_overlap += len(set(snap.combined_factor_exposures.columns).intersection(snap.control_exposures.columns))
    rows.extend(
        [
            {
                "check": "no_target_control_overlap",
                "value": target_control_overlap,
                "limit": 0,
                "passed": target_control_overlap == 0,
            },
            {
                "check": "stock_target_exposure_error",
                "value": max_stock_target,
                "limit": cfg.stock_constraint_tolerance,
                "passed": np.isnan(max_stock_target) or max_stock_target <= cfg.stock_constraint_tolerance,
            },
            {
                "check": "stock_control_exposure",
                "value": max_stock_control,
                "limit": cfg.stock_constraint_tolerance,
                "passed": np.isnan(max_stock_control) or max_stock_control <= cfg.stock_constraint_tolerance,
            },
            {
                "check": "theme_basket_return_identity",
                "value": max_theme_identity,
                "limit": cfg.return_identity_tolerance,
                "passed": np.isnan(max_theme_identity) or max_theme_identity <= cfg.return_identity_tolerance,
            },
            {
                "check": "combined_factor_sources_present",
                "value": int(
                    {"combined_model", "combined_stock_replicated", "combined_hybrid_replicated"}
                    .issubset(bundle.factor_returns_by_source)
                ),
                "limit": 1,
                "passed": {"combined_model", "combined_stock_replicated", "combined_hybrid_replicated"}.issubset(bundle.factor_returns_by_source),
            },
            {
                "check": "daily_point_in_time_order",
                "value": int(
                    (
                        pd.to_datetime(bundle.factor_return_coverage["exposure_date"])
                        < pd.to_datetime(bundle.factor_return_coverage["return_date"])
                    ).dropna().all()
                ) if not bundle.factor_return_coverage.empty else 0,
                "limit": 1,
                "passed": bool(
                    (
                        pd.to_datetime(bundle.factor_return_coverage["exposure_date"])
                        < pd.to_datetime(bundle.factor_return_coverage["return_date"])
                    ).dropna().all()
                ) if not bundle.factor_return_coverage.empty else False,
            },
        ]
    )
    if not basket_diag.empty:
        max_existing_contamination = float(basket_diag["max_existing_factor_contamination"].abs().max())
        rows.append(
            {
                "check": "theme_basket_existing_factor_contamination_reported",
                "value": max_existing_contamination,
                "limit": np.nan,
                "passed": np.isfinite(max_existing_contamination),
            }
        )
    return pd.DataFrame(rows)


__all__ = [
    "INTEGRATED_REPLICATION_SCHEMA_VERSION",
    "IntegratedReplicationConfig",
    "ReplicationConfig",
    "IntegratedFactorSnapshot",
    "IntegratedFactorBundle",
    "calendar_month_window",
    "has_calendar_history",
    "normalize_factor_weights",
    "one_way_turnover",
    "matrix_dict_to_long",
    "long_to_matrix_dict",
    "write_table_with_fallback",
    "read_table_with_fallback",
    "normalize_integrated_inputs",
    "resolve_factor_metadata",
    "build_integrated_factor_snapshot",
    "construct_integrated_stock_mimicking_portfolios",
    "construct_integrated_theme_basket_mapping",
    "run_integrated_factor_replication",
    "save_integrated_replication_outputs",
    "load_integrated_factor_bundle",
    "generate_synthetic_integrated_inputs",
    "load_or_generate_integrated_inputs",
    "run_replication_validation_checks",
    "stable_json_hash",
    "input_fingerprint",
]
