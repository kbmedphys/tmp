from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from integrated_factor_replication import (
    IntegratedReplicationConfig,
    build_integrated_factor_snapshot,
    construct_integrated_stock_mimicking_portfolios,
    construct_integrated_theme_basket_mapping,
    generate_synthetic_integrated_inputs,
    load_integrated_factor_bundle,
    resolve_factor_metadata,
    run_integrated_factor_replication,
    save_integrated_replication_outputs,
)
from integrated_factor_tsfm import (
    IntegratedStrategyConfig,
    binary_tsfm_12m_signal,
    run_integrated_factor_strategy_backtest,
    run_strategy_validation_checks,
)


def make_data(months: int = 7):
    cfg = IntegratedReplicationConfig(
        n_months=months,
        n_stocks=20,
        n_themes=2,
        n_base_baskets=5,
        random_seed=7,
        save_synthetic_input=False,
        basket_risk_metric="identity",
        stock_mimicking_method="minimum_norm",
    )
    return cfg, generate_synthetic_integrated_inputs(cfg)


def make_strategy(frequency: str = "monthly") -> IntegratedStrategyConfig:
    return IntegratedStrategyConfig(
        formation_months=2,
        min_history_months=2,
        volatility_lookback_months=4,
        vol_min_observations=20,
        rebalance_frequency=frequency,
        allow_soft_theme_basket_fallback=True,
    )


def test_role_resolution_and_theme_purification():
    cfg, data = make_data(4)
    metadata = resolve_factor_metadata(data, cfg)
    date = data["stock_returns"].index[20]
    snapshot = build_integrated_factor_snapshot(data, cfg, date, resolved_metadata=metadata)

    assert "EXISTING::SIZE" in snapshot.combined_factor_exposures.columns
    assert "EXISTING::SIZE" not in snapshot.control_exposures.columns
    assert set(snapshot.combined_factor_exposures.columns).isdisjoint(snapshot.control_exposures.columns)

    z = snapshot.purified_theme_exposures
    assert not z.empty
    existing_residual = snapshot.existing_investable_exposures.T.dot(z).abs().to_numpy().max()
    control_residual = snapshot.control_exposures.T.dot(z).abs().to_numpy().max()
    assert existing_residual < 1e-5
    assert control_residual < 1e-5


def test_stock_identity_and_theme_basket_return_identity():
    cfg, data = make_data(4)
    metadata = resolve_factor_metadata(data, cfg)
    date = data["stock_returns"].index[10]
    snapshot = build_integrated_factor_snapshot(data, cfg, date, resolved_metadata=metadata)
    M, diagnostics, _ = construct_integrated_stock_mimicking_portfolios(data, cfg, snapshot)

    factor_exposure = snapshot.combined_factor_exposures.T.dot(M)
    control_exposure = snapshot.control_exposures.T.dot(M)
    np.testing.assert_allclose(factor_exposure.to_numpy(), np.eye(len(factor_exposure)), atol=2e-5)
    assert float(control_exposure.abs().to_numpy().max()) < 2e-5
    assert diagnostics["solver_status"].isin(["solved", "approximate"]).all()

    H, W, _, _ = construct_integrated_theme_basket_mapping(data, cfg, snapshot, M)
    r = data["stock_returns"].iloc[11].reindex(snapshot.eligible_stocks)
    via_baskets = H.T.dot(snapshot.tradable_theme_basket_weights.T.dot(r))
    via_lookthrough = W.T.dot(r)
    np.testing.assert_allclose(via_baskets.to_numpy(), via_lookthrough.to_numpy(), atol=1e-12)


def test_daily_weekly_monthly_rebalance_and_hold_behavior():
    cfg, data = make_data(7)
    bundle = run_integrated_factor_replication(data, cfg)
    results = {}
    for frequency in ("daily", "weekly", "monthly"):
        scfg = make_strategy(frequency)
        result = run_integrated_factor_strategy_backtest(
            bundle,
            scfg,
            binary_tsfm_12m_signal,
            strategy_name=frequency,
            stock_returns=data["stock_returns"],
        )
        checks = run_strategy_validation_checks(result, scfg)
        assert checks["passed"].all(), checks
        results[frequency] = result

    candidate_counts = {k: len(v["candidate_factor_weights"]) for k, v in results.items()}
    assert len(set(candidate_counts.values())) == 1
    executed = {
        k: int(v["returns"].get("rebalance_executed", pd.Series(dtype=bool)).fillna(False).sum())
        for k, v in results.items()
    }
    assert executed["daily"] > executed["weekly"] > executed["monthly"] > 0

    for frequency in ("weekly", "monthly"):
        returns = results[frequency]["returns"]
        held = returns[~returns["rebalance_executed"].fillna(False)]
        assert float(held["total_lookthrough_turnover"].fillna(0.0).abs().max()) == 0.0
        assert float(held["transaction_cost"].fillna(0.0).abs().max()) == 0.0


def test_block_equal_gives_equal_active_block_gross():
    cfg, data = make_data(7)
    bundle = run_integrated_factor_replication(data, cfg)
    scfg = replace(make_strategy("monthly"), factor_weighting_mode="block_equal")
    factor_returns = bundle.factor_returns_by_source["combined_hybrid_replicated"]
    signal_date = factor_returns.index[-1]
    metadata_date = max(d for d in bundle.factor_metadata_by_date if d <= signal_date)
    metadata = bundle.factor_metadata_by_date[metadata_date]
    weights, _ = binary_tsfm_12m_signal(
        factor_returns.loc[:signal_date], metadata, signal_date, scfg
    )
    active = weights[weights.ne(0.0)]
    gross_by_block = active.abs().groupby(metadata.loc[active.index, "block_id"]).sum()
    if len(gross_by_block) >= 2:
        np.testing.assert_allclose(
            gross_by_block.to_numpy(),
            np.repeat(scfg.factor_gross_target / len(gross_by_block), len(gross_by_block)),
            atol=1e-12,
        )


def test_save_load_recompute_parity(tmp_path: Path):
    cfg, data = make_data(4)
    cfg = replace(cfg, output_dir=str(tmp_path), save_stock_returns_used=True)
    bundle = run_integrated_factor_replication(data, cfg)
    out, _ = save_integrated_replication_outputs(bundle, cfg)
    loaded = load_integrated_factor_bundle(out)

    for source in (
        "combined_model",
        "combined_stock_replicated",
        "combined_hybrid_replicated",
    ):
        pd.testing.assert_frame_equal(
            bundle.factor_returns_by_source[source],
            loaded.factor_returns_by_source[source],
            check_exact=False,
            atol=1e-14,
            rtol=1e-14,
        )

    scfg = make_strategy("weekly")
    direct = run_integrated_factor_strategy_backtest(
        bundle, scfg, binary_tsfm_12m_signal, strategy_name="direct", stock_returns=data["stock_returns"]
    )
    from_disk = run_integrated_factor_strategy_backtest(
        loaded, scfg, binary_tsfm_12m_signal, strategy_name="disk"
    )
    pd.testing.assert_series_equal(
        direct["returns"]["gross_return"],
        from_disk["returns"]["gross_return"],
        check_names=False,
        check_exact=False,
        atol=1e-14,
        rtol=1e-14,
    )


def test_target_control_conflict_is_rejected():
    cfg, data = make_data(3)
    duplicate = data["factor_metadata"].loc[
        data["factor_metadata"]["source_factor_id"].eq("VALUE")
    ].copy()
    duplicate["role"] = "risk_control_only"
    data = dict(data)
    data["factor_metadata"] = pd.concat([data["factor_metadata"], duplicate], ignore_index=True)
    with pytest.raises(ValueError):
        resolve_factor_metadata(data, cfg)


def test_label_permutation_does_not_change_snapshot_values():
    cfg, data = make_data(3)
    metadata = resolve_factor_metadata(data, cfg)
    date = data["stock_returns"].index[15]
    left = build_integrated_factor_snapshot(data, cfg, date, resolved_metadata=metadata)

    shuffled = dict(data)
    shuffled["stock_returns"] = data["stock_returns"].sample(frac=1.0, axis=1, random_state=1)
    for key in (
        "barra_exposures_by_date",
        "existing_factor_exposures_by_date",
        "theme_exposures_by_date",
        "theme_basket_weights_by_date",
    ):
        shuffled[key] = {
            d: frame.sample(frac=1.0, axis=0, random_state=2).sample(frac=1.0, axis=1, random_state=3)
            for d, frame in data[key].items()
        }
    right = build_integrated_factor_snapshot(shuffled, cfg, date, resolved_metadata=metadata)
    pd.testing.assert_frame_equal(
        left.combined_factor_exposures.sort_index().sort_index(axis=1),
        right.combined_factor_exposures.sort_index().sort_index(axis=1),
        check_exact=False,
        atol=1e-12,
        rtol=1e-12,
    )

