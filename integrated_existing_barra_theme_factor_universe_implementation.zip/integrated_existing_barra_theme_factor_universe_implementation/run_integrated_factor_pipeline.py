#!/usr/bin/env python3
"""Run integrated replication and Binary / Vol-scaled TSFM strategies."""
from __future__ import annotations

import argparse
import json
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any

# Keep small daily cross-sectional linear algebra deterministic and avoid BLAS
# over-subscription in notebook/CI environments.
for variable in (
    "OPENBLAS_NUM_THREADS",
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
):
    os.environ.setdefault(variable, "1")

import pandas as pd

from integrated_factor_replication import (
    IntegratedReplicationConfig,
    load_or_generate_integrated_inputs,
    run_integrated_factor_replication,
    run_replication_validation_checks,
    save_integrated_replication_outputs,
)
from integrated_factor_tsfm import (
    IntegratedStrategyConfig,
    binary_tsfm_12m_signal,
    run_integrated_factor_strategy_backtest,
    run_integrated_strategy_comparison_grid,
    run_strategy_validation_checks,
    save_integrated_strategy_outputs,
    vol_scaled_tsfm_signal,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build a joint existing/Barra/purified-theme factor universe and run "
            "daily-signal TSFM strategies with daily, weekly, or monthly rebalancing."
        )
    )
    parser.add_argument("--input-pickle", default="data/combined_factor_inputs.pkl")
    parser.add_argument("--output-dir", default="integrated_factor_outputs")
    parser.add_argument("--signals", choices=("binary", "vol", "both"), default="both")
    parser.add_argument(
        "--rebalance-frequency", choices=("daily", "weekly", "monthly"), default="monthly"
    )
    parser.add_argument("--weekly-anchor", default="W-FRI")
    parser.add_argument(
        "--factor-return-source",
        choices=(
            "combined_hybrid_replicated",
            "combined_stock_replicated",
            "combined_model",
            "external_mixed",
        ),
        default="combined_hybrid_replicated",
    )
    parser.add_argument(
        "--implementation-mode",
        choices=("unified_stock", "hybrid_theme_basket"),
        default="hybrid_theme_basket",
    )
    parser.add_argument(
        "--factor-weighting-mode",
        choices=("factor_equal", "block_equal", "custom_block"),
        default="block_equal",
    )
    parser.add_argument(
        "--signal-universe", choices=("combined", "existing_only", "theme_only"), default="combined"
    )
    parser.add_argument(
        "--execution-model",
        choices=("lookthrough_stock", "hybrid_separate_instruments"),
        default="lookthrough_stock",
    )
    parser.add_argument("--allow-synthetic", action="store_true")
    parser.add_argument("--save-synthetic-input", action="store_true")
    parser.add_argument("--allow-theme-basket-fallback", action="store_true")
    parser.add_argument("--skip-comparison-grid", action="store_true")
    parser.add_argument("--random-seed", type=int, default=42)
    parser.add_argument("--synthetic-months", type=int, default=18)
    parser.add_argument("--synthetic-stocks", type=int, default=20)
    parser.add_argument("--synthetic-barra", type=int, default=3)
    parser.add_argument("--synthetic-existing", type=int, default=2)
    parser.add_argument("--synthetic-themes", type=int, default=3)
    parser.add_argument("--synthetic-baskets", type=int, default=6)
    return parser.parse_args()


def strategy_config(args: argparse.Namespace) -> IntegratedStrategyConfig:
    return IntegratedStrategyConfig(
        factor_return_source=args.factor_return_source,
        signal_universe=args.signal_universe,
        factor_weighting_mode=args.factor_weighting_mode,
        implementation_mode=args.implementation_mode,
        formation_months=12,
        min_history_months=12,
        formation_min_coverage=0.98,
        volatility_lookback_months=36,
        vol_min_observations=252,
        rebalance_frequency=args.rebalance_frequency,
        weekly_anchor=args.weekly_anchor,
        execution_model=args.execution_model,
        annualization=252,
    )


def run_strategy(
    *,
    signal_id: str,
    signal_func: Any,
    bundle: Any,
    cfg: IntegratedStrategyConfig,
    output_root: Path,
    run_comparison: bool,
) -> dict[str, Any]:
    subdir = (
        "01_binary_combined_factor_tsfm_12m"
        if signal_id == "binary"
        else "02_vol_scaled_combined_factor_tsfm_12m"
    )
    result = run_integrated_factor_strategy_backtest(
        bundle,
        cfg,
        signal_func,
        strategy_name=f"{signal_id}_combined_integrated",
    )
    checks = run_strategy_validation_checks(result, cfg)
    if not checks["passed"].all():
        raise AssertionError(checks.loc[~checks["passed"]].to_string(index=False))
    comparison = None
    if run_comparison:
        comparison = run_integrated_strategy_comparison_grid(
            bundle,
            cfg,
            signal_func,
            strategy_prefix=signal_id,
            retain_full_results=False,
        )
    out, manifest = save_integrated_strategy_outputs(
        result,
        cfg,
        output_root / subdir,
        comparison=comparison,
        validation_checks=checks,
    )
    returns = result["returns"]
    return {
        "signal_id": signal_id,
        "output_dir": str(out),
        "n_return_rows": len(returns),
        "n_ok_rows": int(returns.get("status", pd.Series(dtype=object)).eq("ok").sum()),
        "n_rebalances": int(
            returns.get("rebalance_executed", pd.Series(dtype=bool)).fillna(False).sum()
        ),
        "max_return_identity_error": float(
            returns.get("return_identity_error", pd.Series(dtype=float)).dropna().max()
        )
        if returns.get("return_identity_error", pd.Series(dtype=float)).notna().any()
        else None,
        "manifest": manifest,
    }


def main() -> None:
    args = parse_args()
    output_root = Path(args.output_dir)
    output_root.mkdir(parents=True, exist_ok=True)

    replication_cfg = IntegratedReplicationConfig(
        input_pickle=args.input_pickle,
        output_dir=str(output_root),
        replication_output_subdir="00_combined_factor_mimicking_diagnostics",
        use_synthetic_if_missing=args.allow_synthetic,
        save_synthetic_input=args.save_synthetic_input,
        random_seed=args.random_seed,
        n_months=args.synthetic_months,
        n_stocks=args.synthetic_stocks,
        n_barra=args.synthetic_barra,
        n_existing_investable=args.synthetic_existing,
        n_themes=args.synthetic_themes,
        n_base_baskets=args.synthetic_baskets,
        basket_fallback_to_theme_exposures=args.allow_theme_basket_fallback,
        save_stock_returns_used=True,
        annualization=252,
    )
    data = load_or_generate_integrated_inputs(replication_cfg)
    bundle = run_integrated_factor_replication(data, replication_cfg)
    replication_checks = run_replication_validation_checks(bundle, replication_cfg)
    if not replication_checks["passed"].all():
        raise AssertionError(
            replication_checks.loc[~replication_checks["passed"]].to_string(index=False)
        )
    replication_out, replication_manifest = save_integrated_replication_outputs(
        bundle, replication_cfg
    )
    replication_checks.to_csv(replication_out / "validation_checks.csv", index=False)

    cfg = strategy_config(args)
    selected = []
    if args.signals in ("binary", "both"):
        selected.append(("binary", binary_tsfm_12m_signal))
    if args.signals in ("vol", "both"):
        selected.append(("vol", vol_scaled_tsfm_signal))

    strategy_summaries = [
        run_strategy(
            signal_id=name,
            signal_func=func,
            bundle=bundle,
            cfg=cfg,
            output_root=output_root,
            run_comparison=not args.skip_comparison_grid,
        )
        for name, func in selected
    ]
    summary = {
        "replication_config": asdict(replication_cfg),
        "strategy_config": asdict(cfg),
        "replication_output_dir": str(replication_out),
        "replication_manifest": replication_manifest,
        "strategies": strategy_summaries,
    }
    summary_path = output_root / "pipeline_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    print(f"Pipeline completed successfully. Summary: {summary_path.resolve()}")


if __name__ == "__main__":
    main()
