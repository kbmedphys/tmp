# 既存因子・Barra・純化テーマ因子の統合ファクター・ユニバース拡張
## 実装要件定義書

対象資料:

- `00_combined_factor_mimicking_diagnostics(1).ipynb`
- `01_binary_combined_factor_tsfm_12m(1).ipynb`
- `02_vol_scaled_combined_factor_tsfm_12m(1).ipynb`
- 既存の日次テーマバスケット複製・TSFM実装

---

## 1. 目的

既存因子と、Barra因子および既存因子で純化したテーマ因子を、同一のファクターID体系、シグナル計算、配分ルール、品質判定、バックテストで扱えるようにする。

統合ファクター・ユニバースを、時点 `t` について次のように定義する。

\[
F_t=[E_t,Z_t]
\]

- `E_t`: 投資対象とする既存因子エクスポージャー
- `Z_t`: Barra、投資対象既存因子、非投資既存因子およびその他controlで純化したテーマ因子

主な利用目的は以下である。

1. 既存因子のみ、純化テーマ因子のみ、両者を統合したTSFMを同一エンジンで比較する
2. Binary TSFMおよびVol-scaled TSFMを統合ユニバースへ適用する
3. 日次でファクターリターンと候補シグナルを更新し、日次・週次・月次の選択頻度でリバランスする
4. 個別銘柄による統合ファクター複製と、テーマ因子をテーマバスケットL/Sで実装するハイブリッド複製を比較する
5. 既存因子ブロックとテーマ因子ブロックの収益、リスク、回転、コスト、複製誤差を分解する

本拡張では、横断回帰係数をそのまま売買リターンとみなすのではなく、原則として実際の実装ウェイトから得られる複製可能リターンをシグナルに使用する。

---

## 2. 添付プログラムの設計と現行実装との差分

### 2.1 添付プログラムから採用する設計

添付プログラムは次を実装している。

- 既存因子を `investable_signal`、`purification_basis`、`risk_control_only`、`excluded` に分類する
- 投資対象既存因子 `E_t` と純化テーマ `Z_t` を連結し、`F_t=[E_t,Z_t]` を作る
- テーマを、ドル、投資対象既存因子、非投資既存因子で純化する
- 統合因子ごとの個別銘柄mimicking portfolioを作る
- `existing_only`、`theme_only`、`combined_factor_equal`、`combined_block_equal` を比較する
- Binary TSFMとVol-scaled TSFMを同一の統合因子集合へ適用する

この考え方を統合ファクター・ユニバースの基礎とする。

### 2.2 そのまま移植しない項目

添付プログラムには、現行の日次テーマバスケット実装へそのまま移植してはならない点がある。

- 日次株式リターンを月次へリサンプルしている
- TSFM、複製、バックテストが月次前提である
- 最終実装が個別銘柄mimicking portfolioだけである
- テーマ定義行列と売買可能テーマバスケットを同一入力として扱っている
- 欠損翌月リターンを0で補完している
- `EXISTING__`、`THEME__` の文字列prefixに処理ロジックが依存している
- pinvで解けたことと、制約が実際に満たされたことを区別していない
- 3ノートブックへ約729行の共通コードを複製している

今回の実装では、既存の日次、保有状態、リバランス頻度切替、テーマバスケット複製、明示的な欠損処理、solver diagnosticsを維持する。

---

## 3. 用語と数理定義

時点 `t` における記号を以下とする。

- `N_t`: 有効個別銘柄数
- `P_B`: Barra/control因子数
- `K_E`: 投資対象既存因子数
- `K_C`: 非投資既存control因子数
- `K_Z`: 純化テーマ因子数
- `J`: 売買可能なベーステーマバスケット数

### 3.1 エクスポージャー行列

- `B_t ∈ R^(N_t×P_B)`: Barraエクスポージャー
- `E_t ∈ R^(N_t×K_E)`: 投資対象既存因子
- `C_t ∈ R^(N_t×K_C)`: purification basisまたはrisk-control-onlyの既存因子
- `A_t ∈ R^(N_t×K_Z)`: 生テーマ定義行列
- `P_t ∈ R^(N_t×J)`: 売買可能なテーマバスケット構成ウェイト

テーマの純化基底を、重複列除去後に次で定義する。

\[
Q_t=[\mathbf 1,B_t^{control},E_t,C_t]
\]

純化テーマは、ridge付き残差化と列別正規化により、

\[
\widetilde Z_t
=
A_t-Q_t(Q_t'Q_t+\lambda_Q I)^{+}Q_t'A_t
\]

\[
Z_t[:,k]
=
\frac{\widetilde Z_t[:,k]}
{\|\widetilde Z_t[:,k]\|_2}
\]

とする。

統合投資対象因子は、

\[
F_t=[E_t,Z_t]
\]

とする。

### 3.2 controlの定義

最終mimicking portfolioでゼロ中立化するcontrol行列を、

\[
R_t=[\mathbf 1,B_t^{control},C_t]
\]

とする。

重要な規則は以下である。

- `E_t` に含めた既存因子を `R_t` に含めてはならない
- 投資対象にしたBarra因子も `B_t^{control}` から除外する
- 同じcanonical factorをtargetとcontrolへ同時登録した場合はエラーとする
- 投資対象因子へのゼロ中立化を黙って優先・解除してはならない

### 3.3 統合個別銘柄mimicking portfolio

統合因子 `h` の個別銘柄ウェイト `m^S_{h,t}` は、次を満たすことを目標とする。

\[
F_t'm^S_{h,t}=e_h
\]

\[
R_t'm^S_{h,t}=0
\]

minimum normの場合は、

\[
\min_m \|m\|_2^2
\]

minimum riskの場合は、

\[
\min_m m'\Sigma_t m
\]

を上記制約下で解く。

全因子の個別銘柄複製行列を、

\[
M^S_t=[m^S_{1,t},\ldots,m^S_{K_E+K_Z,t}]
\]

とする。

### 3.4 テーマバスケットL/Sによるテーマ因子複製

テーマ因子 `k` を複製するベーステーマバスケット配分を `h_{k,t}` とし、

\[
w^B_{k,t}=P_th_{k,t}
\]

とする。

テーマバスケット複製は、テーマ部分だけでなく、統合因子全体に対して次を目標とする。

\[
F_t'P_th_{k,t}=e_{K_E+k}
\]

すなわち、

- 対象テーマ因子エクスポージャーは1
- 他テーマ因子エクスポージャーは0
- 投資対象既存因子エクスポージャーは0

とする。さらに、

\[
R_t'P_th_{k,t}=0
\]

を目標とする。

完全実現できない場合は、個別銘柄統合mimicking portfolioのテーマ列をターゲットとして、

\[
\min_h
\|M^S_{Z,k,t}-P_th\|^2_{\Sigma_t}
+
\lambda_F\|F_t'P_th-e_{K_E+k}\|_2^2
+
\lambda_R\|R_t'P_th\|_2^2
+
\lambda_h\|h\|_2^2
\]

を解く。

既存のテーマのみの制約ではなく、`E_t` への汚染を含む統合エクスポージャーを必ず診断する。

### 3.5 統合複製リターン

#### 統合個別銘柄複製リターン

\[
g^S_{t+1}={M^S_t}'r_{t+1}
\]

#### ハイブリッド複製リターン

既存因子は個別銘柄mimicking、テーマ因子はテーマバスケットL/Sで複製する。

\[
g^H_{t+1}
=
\begin{bmatrix}
{M^S_{E,t}}'r_{t+1}\\
H_t'P_t'r_{t+1}
\end{bmatrix}
\]

`g^H` は本番のハイブリッド実装に対応する主シグナル候補、`g^S` は全因子を同じ個別銘柄実装で比較する基準系列とする。

#### モデル係数リターン

横断回帰係数は診断用に保存する。

\[
r_{t+1}=[R_t,F_t]\beta_{t+1}+\epsilon_{t+1}
\]

`F_t` 部分の係数を `g^model` とする。デフォルトの売買シグナルには使用しない。

---

## 4. ファクター・メタデータ要件

### 4.1 canonical factor ID

全処理は文字列prefixではなく、canonical `factor_id` とメタデータで分岐する。

推奨ID:

```text
EXISTING__VALUE
EXISTING__QUALITY
THEME__AI
THEME__CLIMATE
```

prefixは表示と後方互換のために残してよいが、`startswith()` を投資判断ロジックに使用しない。

### 4.2 必須メタデータ列

`factor_metadata` は最低限、以下を持つ。

| 列 | 内容 |
|---|---|
| `factor_id` | canonicalで一意なID |
| `base_factor_id` | 元データ上のID |
| `factor_type` | `existing` / `theme_purified` |
| `source_type` | `barra` / `custom_existing` / `theme` |
| `role` | `investable_signal` / `purification_basis` / `risk_control_only` / `excluded` |
| `block_id` | 原則 `existing` / `theme` |
| `is_momentum_related` | モメンタム関連フラグ |
| `implementation_type` | `stock_mimicking` / `theme_basket_ls` / `direct_instrument` |
| `normalization_policy` | 適用する横断正規化 |
| `start_date` | 利用開始日、任意 |
| `end_date` | 利用終了日、任意 |

推奨追加列:

- `display_name`
- `source_system`
- `currency`
- `country_scope`
- `transaction_cost_bps_one_way`
- `borrow_cost_policy`
- `expected_update_frequency`
- `max_staleness_days`
- `signal_enabled`

### 4.3 roleの意味

| role | テーマ純化 | 最終中立化 | TSFM対象 |
|---|---:|---:|---:|
| `investable_signal` | 使用 | 中立化しない | 対象 |
| `purification_basis` | 使用 | 中立化する | 対象外 |
| `risk_control_only` | 設定により使用 | 中立化する | 対象外 |
| `excluded` | 使用しない | 使用しない | 対象外 |

### 4.4 モメンタム関連因子

`exclude_momentum_related_from_signal=True` の場合、`investable_signal` かつ `is_momentum_related=True` の因子を、実効roleとして次のいずれかへ変更する。

- デフォルト: `purification_basis`
- 設定により: `excluded`

変更後の `effective_role` を日付別メタデータへ保存する。

本番では因子名から `MOM` 等を推測するのではなく、明示メタデータを必須とする。名称推測は合成データまたはresearch fallbackに限定する。

### 4.5 重複factorの扱い

Barra因子と既存因子に同一概念が含まれる場合、`factor_alias_mapping` によりcanonical IDへ統合する。

例:

```text
Barra VALUE -> EXISTING__VALUE
Custom VALUE_SCORE -> EXISTING__VALUE
```

同じcanonical factorについて複数ソースが同時に有効な場合は、優先ソースをメタデータで指定する。自動平均は禁止する。

---

## 5. 入力データ契約

入力は日次株式リターンを基準とする。

```python
{
    "stock_returns": DataFrame[return_date x stock_id],
    "barra_exposures_by_date": dict[knowledge_date, DataFrame[stock_id x barra_factor]],
    "existing_factor_exposures_by_date": dict[knowledge_date, DataFrame[stock_id x existing_factor]],
    "theme_exposures_by_date": dict[knowledge_date, DataFrame[stock_id x theme_id]],
    "theme_basket_weights_by_date": dict[knowledge_date, DataFrame[stock_id x base_basket]],
    "factor_metadata": DataFrame,
}
```

### 5.1 必須入力

#### `stock_returns`

- 日次の単純リターン
- indexは一意かつ昇順
- columnはcanonical stock ID
- active positionの欠損を無条件に0としない

#### `barra_exposures_by_date`

- Barra因子は原則controlまたはpurification basis
- 投資対象とする場合はメタデータに明示
- industry dummy等のrank redundancyを許容し、内部でrow-space reductionする

#### `existing_factor_exposures_by_date`

- 既存因子を実装可能な個別銘柄ポートフォリオへ変換するため必須
- 外部の既存因子リターンだけでは、統合mimicking portfolioを構築できない
- dict形式またはlong形式をloaderで受け付ける

#### `theme_exposures_by_date`

- 純化テーマを定義する生テーマ行列 `A_t`
- 売買可能バスケットとは意味を分離する

#### `theme_basket_weights_by_date`

- テーマバスケットL/S実装に用いる `P_t`
- `theme_exposures_by_date` からのfallbackはresearch modeだけで許可する
- 本番では `basket_fallback_to_theme_exposures=False`

### 5.2 任意入力

```python
{
    "existing_factor_returns": DataFrame,                 # 外部benchmark用
    "existing_factor_tradable_weights_by_date": dict,    # 直接売買可能な既存因子portfolio
    "specific_risk_by_date": dict,
    "stock_transaction_cost_bps": DataFrame | Series,
    "basket_transaction_cost_bps": DataFrame | Series,
    "shortability_by_date": dict,
    "borrow_cost_by_date": dict,
    "cash_returns": Series,
    "factor_alias_mapping": DataFrame,
}
```

外部既存因子リターンをシグナルに使用するモードは許可できるが、実装リターンとの恒等式が成立しないため、`external_return_only` と明示し、主分析から分離する。

### 5.3 point-in-time日付

各exposureおよびbasketには以下を保持する。

- `effective_date`: 経済的な基準日
- `knowledge_date`: 実際に利用可能になった日

時点 `t` では `knowledge_date <= t` の最新スナップショットのみ使用する。

日次入力に対して月次更新のexposureを前方保持することは可能だが、次を保存する。

- 使用したsnapshot date
- exposure age in business days
- stale flag

`max_staleness_days` 超過時の利用可否をConfigで制御する。

---

## 6. 正規化要件

### 6.1 既存因子

既存因子エクスポージャーは、原則として以下を適用する。

1. 横断平均を0へcenter
2. 横断標準偏差で標準化
3. L2 normを1へ正規化

ただし、入力がすでに売買ウェイトまたは所定の単位エクスポージャーである場合は、メタデータの `normalization_policy` により無変換を選べるようにする。

変換前後のscaleを保存する。

### 6.2 Barra因子

- continuous style factor: 設定に従い標準化
- industry/country dummy: カテゴリ構造を維持
- interceptは別列 `DOLLAR`
- full dummy + interceptによるrank deficiencyはSVDで独立row-spaceへ縮約する

### 6.3 テーマ

- 生テーマ行列 `A_t` はテーマ定義に従う
- 純化残差 `Z_t` を列別L2 norm 1へ正規化
- 純化後normが閾値以下のテーマはinactiveとする
- inactiveを0 returnとして残さず、その期間はNaNおよび明示statusとする

---

## 7. 機能要件

### FR-001 統合スナップショット

新規の共通スナップショットを構築する。

```python
@dataclass
class IntegratedFactorSnapshot:
    exposure_date: pd.Timestamp
    eligible_stocks: pd.Index
    barra_control_exposures: pd.DataFrame
    existing_investable_exposures: pd.DataFrame
    existing_control_exposures: pd.DataFrame
    raw_theme_exposures: pd.DataFrame
    purified_theme_exposures: pd.DataFrame
    combined_factor_exposures: pd.DataFrame
    control_exposures: pd.DataFrame
    tradable_theme_basket_weights: pd.DataFrame
    factor_metadata: pd.DataFrame
    normalization_scales: pd.DataFrame
    diagnostics: dict
```

`ThemeSnapshot` は後方互換wrapperとして残す。

### FR-002 ユニバース整列

すべての行列をstock labelで明示的に整列する。

- 配列位置による結合禁止
- 重複stock/factor label禁止
- 共通有効銘柄ルールを全リターン経路で使用
- factor列順はメタデータのstable orderで固定
- 日付間でinactive factorがあっても、factor IDの意味を変えない

### FR-003 role解決

`factor_metadata` から日付別のeffective roleを作る。

優先順位:

1. `excluded`
2. 明示的な投資除外設定
3. momentum-related exclusion
4. metadataのrole

同一canonical factorがtargetとcontrolへ同時に入る場合は、snapshotをエラーとする。

### FR-004 純化基底

テーマ純化基底へ以下を含める。

- dollar/intercept
- 非投資Barra control
- 投資対象既存因子
- `purification_basis` の既存因子
- Configで指定した `risk_control_only`
- 任意の個別銘柄モメンタムcontrol

含めた列と除外した列をdiagnosticsへ保存する。

### FR-005 純化診断

テーマ×日付について以下を保存する。

- raw norm
- purified residual norm
- normalization scale
- purification R-squared
- max absolute exposure to Barra controls
- max absolute exposure to investable existing factors
- max absolute exposure to non-investable existing controls
- residual rank
- inactive reason

### FR-006 統合因子行列

`F_t=[E_t,Z_t]` を作り、以下を検証する。

- column unique
- finite values
- nonzero norm
- rank
- singular values
- condition number
- factor correlation
- high correlation pairs
- block別factor数

condition numberが閾値を超えた場合、solverを実行して成功扱いにせず、warningまたは除外policyを適用する。

### FR-007 統合個別銘柄mimicking

`M^S_t` を全因子同時のidentity targetで構築する。

保存するdiagnostics:

- solver status
- target exposure error
- max other integrated-factor exposure
- max Barra/control exposure
- dollar exposure
- gross/net
- long/short gross
- max stock weight
- condition number
- constraint rank
- fallback有無

`pinv` を使用しただけで `solved` とせず、制約残差を判定する。

### FR-008 テーマバスケットmapping

テーマ因子用の `H_t` は、統合因子 `F_t` に対するtargetを用いる。

必須diagnostics:

- target theme exposure
- other theme contamination
- investable existing factor contamination
- Barra/control contamination
- target stock-mimicking portfolioとのrisk-weighted distance
- basket gross/net
- look-through gross/net
- active long/short basket数
- rank、condition number、null-space dimension
- hard/soft solver status

### FR-009 統合リターン系列

最低限、以下を生成する。

| 系列 | 既存因子 | テーマ因子 | 用途 |
|---|---|---|---|
| `combined_model_factor_returns` | 横断回帰係数 | 横断回帰係数 | 診断 |
| `combined_stock_replicated_factor_returns` | 個別銘柄M | 個別銘柄M | 共通実装benchmark |
| `combined_hybrid_replicated_factor_returns` | 個別銘柄M | テーマバスケットH/P | 本番候補 |
| `external_existing_factor_returns` | 外部系列 | なし | 任意benchmark |

全系列のcolumnsは同じcanonical factor ID集合とし、存在しない期間はNaNとする。

### FR-010 factor returnの主シグナルsource

Configで次を切り替える。

```python
factor_return_source = (
    "combined_hybrid_replicated"
    | "combined_stock_replicated"
    | "combined_model"
    | "external_mixed"
)
```

推奨デフォルト:

- production/hybrid implementation: `combined_hybrid_replicated`
- 因子研究の共通比較: `combined_stock_replicated`
- `combined_model`: 診断のみ

### FR-011 統合bundle

テーマ専用bundleを一般化する。

```python
@dataclass
class IntegratedFactorBundle:
    factor_returns_by_source: dict[str, pd.DataFrame]
    factor_metadata_by_date: dict[pd.Timestamp, pd.DataFrame]
    combined_snapshots_by_date: dict[pd.Timestamp, IntegratedFactorSnapshot]
    stock_mimicking_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    theme_basket_mapping_by_date: dict[pd.Timestamp, pd.DataFrame]
    theme_basket_constituents_by_date: dict[pd.Timestamp, pd.DataFrame]
    theme_lookthrough_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    replication_diagnostics: pd.DataFrame
    purification_diagnostics: pd.DataFrame
    factor_quality_diagnostics: pd.DataFrame
    config: dict
    manifest: dict
```

`BasketReplicationBundle` はtheme-onlyの互換viewとして残す。

### FR-012 シグナル関数の一般化

既存のBinaryおよびVol-scaled関数を、factor typeに依存しない関数として利用する。

```python
def binary_tsfm_12m_signal(
    factor_history,
    factor_metadata,
    signal_date,
    cfg,
) -> tuple[pd.Series, pd.DataFrame]:
    ...
```

```python
def vol_scaled_tsfm_signal(...):
    ...
```

日次データでは、

- formation: 直近12カレンダー月の日次複利
- volatility: 直近36カレンダー月の日次標準偏差
- annualization: `sqrt(252)`
- minimum observations: Config値、デフォルト252

とする。

### FR-013 シグナル対象フィルター

次のユニバースをConfigで指定できる。

```python
signal_universe = (
    "existing_only"
    | "theme_only"
    | "combined"
    | list[str]
)
```

さらにmetadataで、

- `signal_enabled`
- `factor_type`
- `block_id`
- `effective_role`

を判定する。

### FR-014 配分ルール

最低限、次を実装する。

#### `factor_equal`

有効な全因子でfactor grossを配分する。

#### `block_equal`

既存因子blockとテーマ因子blockへ同一grossを配分し、block内で因子配分する。

一方のblockに有効因子がない場合のデフォルトは、残るactive blockへgrossを再配分する。

#### `custom_block`

```python
block_gross_targets = {
    "existing": 0.5,
    "theme": 0.5,
}
```

を許可する。

品質フィルター後に再正規化し、前に正規化したウェイトを単純に欠落させない。

### FR-015 因子品質フィルター

共通列を持つ日付×factorのquality tableを作る。

共通列:

- `factor_id`
- `factor_type`
- `signal_eligible`
- `implementation_eligible`
- `eligible`
- `exclusion_reason`
- `return_history_complete`
- `return_coverage`
- `solver_status`
- `target_exposure_error`
- `other_factor_exposure`
- `control_exposure`
- `condition_number`

テーマ固有列:

- `purification_residual_norm`
- `existing_factor_contamination`
- `theme_basket_solver_status`
- `basket_return_coverage`

既存因子固有列:

- `existing_exposure_snapshot_age`
- `stock_mimicking_status`

全期間の相関・tracking errorをpoint-in-time選別へ使用しない。

### FR-016 リバランス頻度

既存の次のConfigをそのまま維持する。

```python
rebalance_frequency = "daily" | "weekly" | "monthly"
weekly_anchor = "W-FRI"
```

- 統合因子リターンと候補シグナルは毎営業日更新
- 実保有ウェイトはリバランス日にだけ更新
- 非リバランス日は前回成功リバランス時の全mappingとウェイトを保持
- 非リバランス日のturnoverとcostは0
- リバランス候補失敗時は既存ポジションを保持

### FR-017 実装モード

最低限、次を実装する。

#### `unified_stock`

全因子を統合個別銘柄mimickingで実装する。

\[
w^{stock}_t=M^S_tw^F_t
\]

#### `hybrid_theme_basket`

既存因子を個別銘柄mimicking、テーマ因子をテーマバスケットL/Sで実装する。

\[
w^{stock,E}_t=M^S_{E,t}w^E_t
\]

\[
b^Z_t=H_tw^Z_t
\]

\[
w^{stock,Z}_t=P_tb^Z_t
\]

\[
w^{stock,total}_t=w^{stock,E}_t+w^{stock,Z}_t
\]

#### `direct_factor_instruments`

既存因子の直接売買ウェイトまたは指数商品が入力された場合だけ許可する。入力がない場合はエラーとし、個別銘柄mimickingへ黙ってfallbackしない。

### FR-018 リバランス時に保持する状態

```python
@dataclass
class IntegratedHeldState:
    rebalance_date: pd.Timestamp
    factor_weights: pd.Series
    scaled_factor_weights: pd.Series
    factor_metadata: pd.DataFrame
    M_existing: pd.DataFrame
    M_all: pd.DataFrame
    H_theme: pd.DataFrame
    P_theme: pd.DataFrame
    existing_stock_weights: pd.Series
    theme_basket_weights: pd.Series
    theme_lookthrough_stock_weights: pd.Series
    total_lookthrough_stock_weights: pd.Series
    scale: float
    quality: pd.DataFrame
```

非リバランス日に当日推定された `M_t`、`H_t`、`P_t` で保有P&Lを書き換えてはならない。

### FR-019 保有期間中のP&L

最後の成功リバランス日を `r` とする。

既存因子block:

\[
R^E_{t+1}
=
(w^E_r)'{M^S_{E,r}}'r^{stock}_{t+1}
\]

テーマblock:

\[
R^Z_{t+1}
=
(w^Z_r)'H_r'P_r'r^{stock}_{t+1}
\]

合計:

\[
R^{total}_{t+1}=R^E_{t+1}+R^Z_{t+1}
\]

ルックスルー経路:

\[
R^{lookthrough}_{t+1}
=
(w^{stock,E}_r+w^{stock,Z}_r)'r^{stock}_{t+1}
\]

日次で、

\[
|R^{total}_{t+1}-R^{lookthrough}_{t+1}|
\le tolerance
\]

を検証する。

### FR-020 P&L分解

最低限、以下を保存する。

- factor別寄与度
- existing block P&L
- theme block P&L
- base theme basket別寄与度
- stock look-through P&L
- factor-space return
- implementation tracking error
- cost前／cost後

factor contributionのkeyは `target_theme` ではなく一般化した `factor_id` とする。

### FR-021 スケール

デフォルトは、両blockを集約し銘柄nettingした後のlook-through grossを1にする。

\[
c_t
=
\frac{G^*}
{\|w^{stock,E}_t+w^{stock,Z}_t\|_1}
\]

同じ `c_t` を全blockへ適用する。

block別に別々にgross 1へ正規化した後で合算することをデフォルトにしてはならない。block配分比率と銘柄nettingが崩れるためである。

追加モード:

- `none`
- `lookthrough_stock_gross`
- `hybrid_instrument_gross`
- 将来の `ex_ante_vol_target`

### FR-022 ターンオーバー

#### unified stock

集約後個別銘柄ウェイトから計算する。

\[
TO^{stock}_t
=
\frac12\sum_i|w^{stock,total}_{i,t}-w^{stock,total}_{i,t-1}|
\]

#### hybrid direct basket execution

- 既存因子個別銘柄turnover
- テーマバスケット商品turnover
- テーマlook-through stock turnover
- 全stock look-through turnover

を別々に保存する。

既存因子blockとテーマblockで同一銘柄が相殺される場合、look-through実行ではnetting後にコスト計算する。

### FR-023 コスト

実行モデル別に分ける。

- `lookthrough_stock`: 集約後stock turnover × stock cost
- `hybrid_direct`: existing stock cost + theme basket instrument cost
- borrow、financingは別項目

block別コストと総コストが一致することを検証する。

### FR-024 欠損処理

- active weightのリターン欠損を無条件に0へしない
- coverage threshold未満は当日P&Lをinvalidとする
- factor不在期間はNaN
- inactive factorを0 returnとしてTSFM履歴へ含めない
- 将来の欠損を見てsignal dateのウェイトを再配分しない

### FR-025 比較戦略

Binary、Vol-scaledの双方で最低限、次を比較する。

1. `existing_only_factor_equal`
2. `theme_only_factor_equal`
3. `combined_factor_equal`
4. `combined_block_equal`

さらに実装比較として、

5. `combined_unified_stock`
6. `combined_hybrid_theme_basket`

を共通サンプルで比較する。

必要に応じて、signal return sourceも、

- stock-replicated combined
- hybrid-replicated combined

で比較する。

比較軸を増やす場合はstrategy IDへ以下を含める。

```text
signal_mode
signal_universe
weighting_mode
factor_return_source
implementation_mode
rebalance_frequency
```

### FR-026 diagnostics比較

factor type別に以下を集計する。

- factor数
- active率
- return coverage
- average gross
- turnover
- solver failure率
- target exposure error
- other factor contamination
- control exposure
- factor return volatility
- TSFM weight gross
- P&L contribution

### FR-027 エラーstatus

無言の `except: continue` を禁止する。

最低限、次を使用する。

- `ok`
- `missing_existing_exposure`
- `missing_barra_exposure`
- `missing_theme_exposure`
- `missing_tradable_theme_basket`
- `duplicate_canonical_factor`
- `target_control_role_conflict`
- `insufficient_purification_residual`
- `combined_factor_rank_deficient`
- `stock_mimicking_constraint_failure`
- `theme_basket_constraint_failure`
- `insufficient_return_coverage`
- `no_eligible_factors`
- `held_after_failed_rebalance`
- `return_identity_failure`
- `stale_exposure`

---

## 8. API変更要件

### 8.1 `theme_basket_mimicking.py`

新規または一般化する関数:

```python
def resolve_factor_metadata(...):
    ...


def build_integrated_factor_snapshot(...):
    ...


def estimate_integrated_model_factor_returns(...):
    ...


def construct_integrated_stock_mimicking_portfolios(...):
    ...


def construct_integrated_theme_basket_mapping(...):
    ...


def compute_integrated_replicated_factor_returns(...):
    ...


def run_integrated_factor_replication(...):
    ...
```

既存関数はwrapperとして維持する。

```python
snapshot_for_date(...)                   # theme-only wrapper
estimate_theme_returns(...)              # theme-only wrapper
construct_stock_mimicking_portfolios(...)# theme-only wrapper
run_theme_basket_replication(...)        # theme-only wrapper
```

### 8.2 `theme_basket_tsfm.py`

一般化する関数:

```python
def eligible_factors_at_date(...):
    ...


def construct_integrated_strategy_weights(...):
    ...


def run_integrated_factor_strategy_backtest(...):
    ...


def run_integrated_strategy_comparison_grid(...):
    ...
```

後方互換:

```python
eligible_themes_at_date(...) -> eligible_factors_at_date(...)
run_basket_factor_strategy_backtest(...) -> integrated engine with theme-only bundle
```

### 8.3 notebook

ノートブックへ共通関数をコピーしない。

推奨成果物:

```text
00_combined_factor_mimicking_diagnostics.ipynb
01_binary_combined_factor_tsfm_12m.ipynb
02_vol_scaled_combined_factor_tsfm_12m.ipynb
theme_basket_mimicking.py
theme_basket_tsfm.py
```

または、モジュール名を明確化する場合:

```text
integrated_factor_replication.py
integrated_factor_tsfm.py
```

---

## 9. Config追加要件

```python
@dataclass
class ReplicationConfig:
    # Existing factor inputs
    existing_factor_exposures_key: str = "existing_factor_exposures_by_date"
    factor_metadata_key: str = "factor_metadata"
    factor_alias_mapping_key: str = "factor_alias_mapping"
    enable_existing_factors: bool = True

    # Role policy
    exclude_momentum_related_from_signal: bool = True
    include_excluded_momentum_as_control: bool = True
    include_risk_control_in_theme_purification: bool = True
    reject_target_control_conflict: bool = True

    # Normalization
    existing_factor_normalization: str = "zscore_l2"
    barra_style_normalization: str = "as_provided"
    theme_purification_ridge: float = 1e-8
    minimum_purified_theme_norm: float = 1e-10

    # Combined replication
    stock_mimicking_method: str = "minimum_norm"
    combined_factor_condition_number_warn: float = 1e10
    combined_factor_condition_number_fail: float | None = None
    theme_basket_target_scope: str = "full_combined_factor_identity"
```

```python
@dataclass
class StrategyConfig:
    factor_return_source: Literal[
        "combined_hybrid_replicated",
        "combined_stock_replicated",
        "combined_model",
        "external_mixed",
    ] = "combined_hybrid_replicated"

    signal_universe: str = "combined"
    factor_weighting_mode: Literal[
        "factor_equal", "block_equal", "custom_block"
    ] = "factor_equal"
    block_gross_targets: dict[str, float] | None = None

    implementation_mode: Literal[
        "unified_stock",
        "hybrid_theme_basket",
        "direct_factor_instruments",
    ] = "hybrid_theme_basket"

    # Existing daily rebalance settings remain unchanged
    rebalance_frequency: Literal["daily", "weekly", "monthly"] = "monthly"
    weekly_anchor: str = "W-FRI"
    annualization: int = 252
```

Config hashにはメタデータpolicyとalias mappingのhashも含める。

---

## 10. 出力要件

### 10.1 factor returns

- `combined_model_factor_returns.csv`
- `combined_stock_replicated_factor_returns.csv`
- `combined_hybrid_replicated_factor_returns.csv`
- `external_existing_factor_returns.csv`（任意）

### 10.2 metadata / snapshots

- `factor_metadata_by_date.parquet`
- `factor_role_resolution_diagnostics.parquet`
- `combined_factor_snapshot_diagnostics.csv`
- `purification_diagnostics.parquet`
- `combined_factor_correlation.parquet`
- `high_correlation_factor_pairs.csv`

### 10.3 replication weights

- `combined_stock_mimicking_weights_long.parquet`
  - exposure_date、stock_id、factor_id、weight
- `theme_basket_mapping_long.parquet`
  - exposure_date、base_basket、factor_id、weight
- `theme_lookthrough_weights_long.parquet`
  - exposure_date、stock_id、factor_id、weight
- `theme_basket_constituents_long.parquet`

### 10.4 replication diagnostics

- `combined_stock_mimicking_diagnostics.parquet`
- `integrated_theme_basket_diagnostics.parquet`
- `factor_return_coverage.parquet`
- `replication_validation_checks.csv`

### 10.5 strategy outputs

- `strategy_returns.csv`
- `candidate_factor_weights.csv`
- `held_factor_weights.csv`
- `factor_quality_diagnostics.parquet`
- `strategy_stock_weights_long.parquet`
- `strategy_theme_basket_weights_long.parquet`
- `factor_contributions.parquet`
- `block_contributions.parquet`
- `basket_contributions.parquet`
- `turnover_decomposition.parquet`
- `comparison_grid_returns.csv`
- `comparison_grid_metrics.csv`
- `validation_checks.csv`
- `config.json`
- `input_manifest.json`
- `save_manifest.json`

### 10.6 strategy return列

最低限、以下を含める。

- `return_date`
- `signal_date`
- `last_rebalance_date`
- `rebalance_frequency`
- `is_rebalance_date`
- `rebalance_executed`
- `factor_return_source`
- `signal_universe`
- `weighting_mode`
- `implementation_mode`
- `gross_return`
- `net_return`
- `existing_factor_pnl`
- `theme_factor_pnl`
- `factor_space_return`
- `lookthrough_stock_return`
- `return_identity_error`
- `factor_gross`
- `existing_factor_gross`
- `theme_factor_gross`
- `lookthrough_stock_gross`
- `existing_stock_turnover`
- `theme_basket_turnover`
- `lookthrough_stock_turnover`
- `transaction_cost`
- `n_active_existing_factors`
- `n_active_theme_factors`
- `status`

---

## 11. 受入基準

### 11.1 メタデータとrole

1. 同一canonical factorをtargetとcontrolへ登録すると明示エラーになる
2. investable既存因子は最終中立化controlへ入らない
3. momentum exclusion設定に従ってeffective roleが再現される
4. factor列順を変更しても結果が不変
5. prefixを変更してもmetadataが同じなら結果が不変

### 11.2 純化

hard purification対象について、

\[
\max|Q_t'Z_t|\le tolerance
\]

を満たす。

最低限、以下を別々に検証する。

- dollar exposure
- Barra control exposure
- investable existing factor exposure
- non-investable existing factor exposure

### 11.3 統合個別銘柄mimicking

\[
\max|{M^S_t}'F_t-I|\le tolerance
\]

\[
\max|{M^S_t}'R_t|\le tolerance
\]

を満たす。

rank不足の人工ケースでは、成功扱いではなくfailureまたはsoft statusを返す。

### 11.4 テーマバスケットmapping

hard solutionについて、

- target theme exposure error ≤ tolerance
- existing factor contamination ≤ tolerance
- other theme contamination ≤ tolerance
- control exposure ≤ tolerance

を満たす。

`P_t` の列空間がテーマtargetを完全に張る人工ケースでは、個別銘柄theme mimicking returnとbasket returnが一致する。

### 11.5 リターン恒等式

統合個別銘柄実装:

\[
(w^F_t)'g^S_{t+1}
=
(M^S_tw^F_t)'r_{t+1}
\]

ハイブリッド実装:

\[
(w^E_t)'g^S_{E,t+1}
+
(w^Z_t)'g^B_{Z,t+1}
=
(w^{stock,E}_t+w^{stock,Z}_t)'r_{t+1}
\]

最大絶対誤差は `1e-10` 以下とする。

### 11.6 signal compatibility

- theme-only入力時、新エンジンのBinary signalが既存theme-only実装と一致
- theme-only入力時、新エンジンのVol-scaled signalが既存theme-only実装と一致
- existing-only入力時、添付combined notebookのsignalロジックと一致
- `factor_equal`、`block_equal` のfactor grossが設定値へ一致

### 11.7 日次・週次・月次

- 全頻度で候補シグナルは同じ日次系列
- 非リバランス日はfactor weight、M、H、P、実装ウェイトが固定
- 非リバランス日のturnoverとcostが0
- weeklyは各週の実観測最終営業日
- monthlyは各暦月の実観測最終営業日
- 将来リターンを変更しても過去のsignalとウェイトが変わらない

### 11.8 block分解

- `gross_return = existing_factor_pnl + theme_factor_pnl`
- factor contributionsの合計がgross returnへ一致
- basket contributionsの合計がtheme factor P&Lへ一致
- transaction costのblock合計が総コストへ一致

### 11.9 欠損・factor lifecycle

- factor開始前・終了後はNaN return、weight 0、理由付きinactive
- 欠損を0 returnとして形成リターンへ混入させない
- factor追加・削除時も既存factor IDの意味が変化しない
- quality filter後にウェイトを再正規化する

### 11.10 後方互換

existing factor入力を空にした場合、既存theme-onlyパイプラインと以下が許容誤差内で一致する。

- 純化テーマエクスポージャー
- 純化テーマリターン
- stock coefficient replica
- theme basket replica
- Binary／Vol-scaled signal
- 日次・週次・月次の主戦略P&L

### 11.11 load/recompute

同一入力・Configについて、保存済みbundle読込と再計算で以下が一致する。

- factor metadata
- combined factor returns
- M、H、P
- factor quality
- strategy weights
- strategy returns

---

## 12. テストケース

最低限、以下の合成ケースを用意する。

1. 既存因子2本、テーマ2本、Barra control2本の完全rankケース
2. Barraと既存因子が同一canonical IDとなる重複ケース
3. target/control role conflictケース
4. theme raw exposureが既存因子と完全共線となり、純化残差が0になるケース
5. 統合Fがrank deficientとなるケース
6. テーマバスケット空間がtargetを完全に張るケース
7. テーマバスケット空間が既存因子中立化を満たせないケース
8. factor追加・削除があるケース
9. 月次exposure、日次returnのas-of joinケース
10. 金曜休場を含む週次リバランスケース
11. 非リバランス日にM/H/Pが更新されても、保有P&Lが変わらないケース
12. active stock return欠損のcoverageケース
13. column permutationケース
14. theme-only後方互換ケース
15. external existing factor returnのみで実装不可となるケース

---

## 13. 可視化要件

### 00 diagnostics

- 統合因子相関heatmap
- `M'F` identity heatmap
- `M'R` control exposure heatmap
- theme basket `F'PH` heatmap
- purification exposure heatmap
- factor type別mimicking gross
- rank・condition number時系列
- stock replica vs hybrid replica vs model coefficientの比較

### 01 / 02 strategy

- existing-only / theme-only / combinedの累積リターン
- factor-equal / block-equalの比較
- unified-stock / hybrid-theme-basketの比較
- existing/theme block P&L
- factor weight heatmap
- block gross時系列
- factor type別active数
- turnoverとcost分解
- rolling correlation / tracking error
- strategy-level control exposure

---

## 14. 実装順序

### Phase 1: データとmetadata

1. `existing_factor_exposures_by_date` loader
2. factor metadataとalias解決
3. point-in-time snapshot selection
4. normalization diagnostics

### Phase 2: 統合スナップショット

1. `E_t`、`C_t`、`B_t` のrole分離
2. `Q_t` によるテーマ純化
3. `F_t=[E_t,Z_t]`
4. rank・condition diagnostics

### Phase 3: 統合複製

1. 全因子のjoint stock mimicking `M^S_t`
2. full combined targetを用いたtheme basket mapping `H_t`
3. stock／hybrid／model return生成
4. 保存bundleとvalidation

### Phase 4: 戦略一般化

1. theme-specific bundleをintegrated bundleへ一般化
2. `eligible_themes` を `eligible_factors` へ一般化
3. factor-equal / block-equal
4. unified-stock / hybrid implementation
5. held-state、daily/weekly/monthly機能へ接続

### Phase 5: notebooksと比較

1. 00 diagnostics
2. 01 Binary Combined TSFM
3. 02 Vol-scaled Combined TSFM
4. existing-only / theme-only / combined比較
5. unified-stock / hybrid比較

### Phase 6: 回帰テスト

1. theme-only既存結果との一致
2. 添付combined notebookのmonthly synthetic resultとの方向整合
3. 日次・週次・月次リバランス
4. load/recompute
5. 全受入チェック

---

## 15. 実装上の重要な決定事項

1. **既存因子は投資対象かcontrolのどちらか一方である。** 1つのfactorを同時にtargetと中立化対象にしない。
2. **テーマはBarraだけでなく、投資対象既存因子に対しても純化する。**
3. **テーマバスケット複製も統合F全体をtargetにする。** テーマ同士だけを見て既存因子汚染を無視しない。
4. **同じ統合ユニバースとは、同じID、metadata、return matrix、signal、quality、weightingを使うことを意味する。** 実装手段まで必ず同一である必要はなく、unified-stockとhybridを明示的に比較する。
5. **主シグナルは実装可能リターンを使う。** 横断回帰係数は診断系列とする。
6. **日次系列を月次へリサンプルしない。** 12カ月・36カ月はカレンダー窓として日次観測から計算する。
7. **非リバランス日はmappingを更新しない。** 日次の新しいM/H/Pは候補計算にだけ使い、保有P&Lには最後の成功リバランス時点のmappingを使う。
8. **最終grossとコストはblock合算・netting後に計算する。**
9. **テーマ定義行列と売買可能テーマバスケットを分離する。**
10. **ノートブックへ共通コードを複製しない。** 実装はモジュールへ集約し、ノートブックは設定・実行・診断に限定する。

---

## 16. 完了定義

以下をすべて満たした時点で実装完了とする。

- 既存因子、Barra、テーマ因子のroleがmetadataから一意に解決される
- テーマがBarraおよび既存因子でpoint-in-time純化される
- `F_t=[E_t,Z_t]` が日次で構築される
- 全統合因子のjoint stock mimicking portfolioが構築される
- テーマ因子のテーマバスケットL/S mappingが統合Fに対して構築される
- stock-replicated、hybrid-replicated、model coefficient returnが生成される
- Binary、Vol-scaled TSFMが同一統合ユニバースで動く
- existing-only、theme-only、combined factor-equal、combined block-equalを比較できる
- unified-stockとhybrid-theme-basketを比較できる
- 日次・週次・月次リバランス切替が維持される
- factor／block／basket／stock経路のP&L恒等式が通る
- role conflict、rank deficiency、solver failure、欠損、stale exposureが明示statusになる
- theme-only既存実装との後方互換テストが通る
- 実行済み00・01・02、共通モジュール、テスト、出力例、manifestが揃う
