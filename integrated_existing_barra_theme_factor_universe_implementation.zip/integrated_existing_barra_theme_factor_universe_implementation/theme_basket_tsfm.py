"""TSFM strategies implemented with daily signals and configurable rebalancing.

Pure factor returns, basket-replicated factor returns, and candidate signals are
calculated on every observed trading day.  Portfolio holdings change only on
scheduled daily/weekly/monthly rebalance dates.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Literal, Mapping

import numpy as np
import pandas as pd

from theme_basket_mimicking import (
    REPLICATION_SCHEMA_VERSION,
    BasketReplicationArtifacts,
    ReplicationConfig,
    calendar_month_window,
    config_from_dict,
    fingerprint_inputs,
    has_calendar_history,
    long_to_matrix_dict,
    read_table_with_fallback,
    run_theme_basket_replication,
    save_replication_outputs,
    snapshot_for_date,
    stable_json_hash,
    write_table_with_fallback,
)

STRATEGY_SCHEMA_VERSION = "1.2.0-daily-rebalance"
SignalFunction = Callable[[pd.DataFrame, pd.Timestamp, "StrategyConfig"], tuple[pd.Series, pd.DataFrame]]


@dataclass
class StrategyConfig:
    # Replication bundle
    replication_output_dir: str = "theme_factor_momentum_outputs/00_mimicking_portfolio_diagnostics_theme_basket"
    replication_data_mode: Literal["auto", "load_00_outputs", "recompute"] = "auto"
    output_dir: str = "theme_factor_momentum_outputs"
    expected_replication_schema_version: str = REPLICATION_SCHEMA_VERSION
    require_config_hash_match: bool = False
    require_input_fingerprint_match: bool = False

    # Signal / implementation
    signal_return_source: Literal["purified", "basket_replicated"] = "basket_replicated"
    implementation_mode: Literal["stock_coefficient", "theme_basket_ls"] = "theme_basket_ls"

    # Signal windows: calendar months, even when observations are daily
    formation_months: int = 12
    min_history_months: int = 24
    risk_lookback_months: int = 36
    vol_min_observations: int = 252
    factor_vol_floor: float = 1e-8
    factor_weight_gross: float = 1.0

    # Minimal-change rebalance switch
    rebalance_frequency: Literal["daily", "weekly", "monthly"] = "monthly"
    weekly_anchor: str = "W-FRI"

    # Point-in-time replication quality
    apply_replication_quality_filter: bool = True
    allow_soft_fallback: bool = True
    allowed_solver_status: tuple[str, ...] = ("hard_solved_pinv", "soft_solved_pinv")
    max_target_exposure_error: float = 5.0
    max_neutralization_exposure: float = 1.0
    min_replication_return_coverage: float = 0.98
    max_condition_number: float | None = None

    # Scale
    strategy_scale_mode: Literal[
        "none", "lookthrough_stock_gross", "basket_instrument_gross"
    ] = "lookthrough_stock_gross"
    target_lookthrough_stock_gross: float = 1.0
    target_basket_instrument_gross: float = 1.0

    # Execution/cost
    execution_model: Literal["basket_instrument", "lookthrough_stock"] = "basket_instrument"
    basket_transaction_cost_bps_one_way: float = 10.0
    stock_transaction_cost_bps_one_way: float = 10.0

    # Return handling
    missing_return_policy: Literal["propagate_nan", "coverage_threshold"] = "coverage_threshold"
    min_return_coverage: float = 0.98

    # Validation
    return_identity_tolerance: float = 1e-10
    weight_normalization_tolerance: float = 1e-12
    gross_target_tolerance: float = 1e-10

    # Output / metrics
    run_comparison_grid: bool = True
    comparison_common_sample: bool = True
    rolling_metric_months: int = 36
    save_basket_weights: bool = True
    save_lookthrough_stock_weights: bool = True
    annualization: int = 252


@dataclass
class BasketReplicationBundle:
    purified_theme_returns: pd.DataFrame
    stock_coefficient_replicated_theme_returns: pd.DataFrame
    basket_replicated_theme_returns: pd.DataFrame
    raw_basket_returns: pd.DataFrame
    basket_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    basket_constituent_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    stock_mimicking_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    lookthrough_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    replication_diagnostics: pd.DataFrame
    basis_diagnostics: pd.DataFrame
    return_coverage: pd.DataFrame
    config: dict[str, Any]
    manifest: dict[str, Any]
    source_mode: str


@dataclass
class BasketStrategyWeights:
    factor_weights: pd.Series
    scaled_factor_weights: pd.Series
    basket_weights_pre_scale: pd.Series
    basket_weights: pd.Series
    lookthrough_stock_weights_pre_scale: pd.Series | None
    lookthrough_stock_weights: pd.Series | None
    scale: float
    diagnostics: dict[str, Any]


@dataclass
class _HeldState:
    rebalance_date: pd.Timestamp
    factor_weights: pd.Series
    scaled_factor_weights: pd.Series
    weights: BasketStrategyWeights
    implementation_mode: str
    H: pd.DataFrame | None = None
    P: pd.DataFrame | None = None
    M: pd.DataFrame | None = None
    quality: pd.DataFrame = field(default_factory=pd.DataFrame)
    exposure_diagnostics: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Replication bundle persistence
# ---------------------------------------------------------------------------


def _read_indexed_csv(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, index_col=0, parse_dates=True)
    frame.index = pd.DatetimeIndex(frame.index)
    return frame.sort_index()


def _manifest_path(output_dir: Path, manifest: Mapping[str, Any], requested: str) -> Path:
    entry = manifest.get("files", {}).get(requested, {})
    actual = entry.get("actual") or entry.get("path") or requested
    return output_dir / actual


def build_basket_replication_bundle(
    data: Mapping[str, Any],
    replication_cfg: ReplicationConfig,
    *,
    persist_output_dir: str | Path | None = None,
) -> BasketReplicationBundle:
    result = run_theme_basket_replication(data, replication_cfg)
    artifacts: BasketReplicationArtifacts = result["basket_artifacts"]
    manifest: dict[str, Any] = {
        "replication_schema_version": REPLICATION_SCHEMA_VERSION,
        "config_hash": result["config_hash"],
        "input_fingerprint": result["input_fingerprint"],
    }
    if persist_output_dir is not None:
        _, manifest = save_replication_outputs(result, replication_cfg, persist_output_dir)
    config = asdict(replication_cfg)
    config["config_hash"] = result["config_hash"]
    config["input_fingerprint"] = result["input_fingerprint"]
    return BasketReplicationBundle(
        purified_theme_returns=result["purified_theme_returns"],
        stock_coefficient_replicated_theme_returns=result[
            "stock_coefficient_replicated_theme_returns"
        ],
        basket_replicated_theme_returns=result["basket_replicated_theme_returns"],
        raw_basket_returns=artifacts.raw_basket_returns,
        basket_weights_by_date=artifacts.basket_weights_by_date,
        basket_constituent_weights_by_date=artifacts.basket_constituent_weights_by_date,
        stock_mimicking_weights_by_date=artifacts.stock_coefficient_weights_by_date,
        lookthrough_weights_by_date=artifacts.lookthrough_weights_by_date,
        replication_diagnostics=artifacts.replication_diagnostics,
        basis_diagnostics=artifacts.basis_diagnostics,
        return_coverage=artifacts.return_coverage,
        config=config,
        manifest=manifest,
        source_mode="recompute",
    )


def load_basket_replication_bundle(
    output_dir: str | Path, cfg: StrategyConfig
) -> BasketReplicationBundle:
    out = Path(output_dir)
    with (out / "save_manifest.json").open("r", encoding="utf-8") as handle:
        manifest = json.load(handle)
    with (out / "comparison_config.json").open("r", encoding="utf-8") as handle:
        rep_config = json.load(handle)

    def matrix_file(requested: str, row: str, column: str) -> dict[pd.Timestamp, pd.DataFrame]:
        table = read_table_with_fallback(_manifest_path(out, manifest, requested))
        return long_to_matrix_dict(table, row, column)

    return BasketReplicationBundle(
        purified_theme_returns=_read_indexed_csv(out / "purified_theme_returns.csv"),
        stock_coefficient_replicated_theme_returns=_read_indexed_csv(
            out / "stock_coefficient_replicated_theme_returns.csv"
        ),
        basket_replicated_theme_returns=_read_indexed_csv(
            out / "basket_ls_replicated_theme_returns.csv"
        ),
        raw_basket_returns=_read_indexed_csv(out / "raw_theme_basket_returns.csv"),
        basket_weights_by_date=matrix_file(
            "basket_weights_long.parquet", "base_basket", "target_theme"
        ),
        basket_constituent_weights_by_date=matrix_file(
            "tradable_basket_constituent_weights_long.parquet", "stock_id", "base_basket"
        ),
        stock_mimicking_weights_by_date=matrix_file(
            "stock_coefficient_weights_long.parquet", "stock_id", "target_theme"
        ),
        lookthrough_weights_by_date=matrix_file(
            "basket_lookthrough_stock_weights_long.parquet", "stock_id", "target_theme"
        ),
        replication_diagnostics=pd.read_csv(out / "basket_mimicking_diagnostics.csv", parse_dates=["exposure_date", "return_date"]),
        basis_diagnostics=pd.read_csv(out / "basket_basis_rank_diagnostics.csv", parse_dates=["exposure_date"]),
        return_coverage=pd.read_csv(out / "basket_return_coverage.csv", parse_dates=["exposure_date", "return_date"]),
        config=rep_config,
        manifest=manifest,
        source_mode="load_00_outputs",
    )


def validate_replication_bundle(
    bundle: BasketReplicationBundle,
    cfg: StrategyConfig,
    data: Mapping[str, Any] | None = None,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []

    def add(check: str, value: Any, limit: Any, passed: bool) -> None:
        rows.append({"check": check, "value": value, "limit": limit, "passed": bool(passed)})

    common_themes = bundle.purified_theme_returns.columns.intersection(
        bundle.basket_replicated_theme_returns.columns
    )
    add("theme_labels_overlap", len(common_themes), 1, len(common_themes) > 0)
    add(
        "daily_return_indexes_sorted_unique",
        int(bundle.basket_replicated_theme_returns.index.is_monotonic_increasing and bundle.basket_replicated_theme_returns.index.is_unique),
        1,
        bundle.basket_replicated_theme_returns.index.is_monotonic_increasing
        and bundle.basket_replicated_theme_returns.index.is_unique,
    )
    add("basket_mapping_snapshots_exist", len(bundle.basket_weights_by_date), 1, len(bundle.basket_weights_by_date) > 0)
    label_ok = True
    finite_ok = True
    for date, H in bundle.basket_weights_by_date.items():
        label_ok &= set(H.columns).issubset(set(bundle.basket_replicated_theme_returns.columns))
        P = bundle.basket_constituent_weights_by_date.get(date)
        label_ok &= P is not None and set(H.index).issubset(set(P.columns))
        finite_ok &= np.isfinite(H.to_numpy()).all()
    add("mapping_labels_align", label_ok, True, label_ok)
    add("mapping_weights_finite", finite_ok, True, finite_ok)
    if data is not None:
        expected = fingerprint_inputs(data, config_from_dict(bundle.config))
        actual = bundle.manifest.get("input_fingerprint") or bundle.config.get("input_fingerprint")
        passed = (not cfg.require_input_fingerprint_match) or actual == expected
        add("input_fingerprint_match", actual == expected, True, passed)
    schema = bundle.manifest.get("replication_schema_version")
    add(
        "replication_schema_compatible",
        schema,
        cfg.expected_replication_schema_version,
        schema == cfg.expected_replication_schema_version,
    )
    return pd.DataFrame(rows)


def prepare_replication_bundle(
    data: Mapping[str, Any],
    replication_cfg: ReplicationConfig,
    strategy_cfg: StrategyConfig,
) -> tuple[BasketReplicationBundle, str, pd.DataFrame]:
    mode = strategy_cfg.replication_data_mode
    out = Path(strategy_cfg.replication_output_dir)
    if mode == "auto":
        mode = "load_00_outputs" if (out / "save_manifest.json").exists() else "recompute"
    if mode == "load_00_outputs":
        bundle = load_basket_replication_bundle(out, strategy_cfg)
    elif mode == "recompute":
        bundle = build_basket_replication_bundle(data, replication_cfg, persist_output_dir=out)
    else:
        raise ValueError(f"Unsupported replication_data_mode: {mode}")
    validation = validate_replication_bundle(bundle, strategy_cfg, data)
    return bundle, mode, validation


# ---------------------------------------------------------------------------
# Calendar windows and rebalance calendar
# ---------------------------------------------------------------------------


def make_rebalance_dates(
    index: pd.DatetimeIndex, cfg: StrategyConfig
) -> pd.DatetimeIndex:
    dates = pd.DatetimeIndex(index).drop_duplicates().sort_values()
    frequency = cfg.rebalance_frequency
    if frequency == "daily":
        return dates
    values = pd.Series(dates, index=dates)
    if frequency == "weekly":
        try:
            periods = dates.to_period(cfg.weekly_anchor)
        except Exception as exc:
            raise ValueError(f"invalid weekly_anchor {cfg.weekly_anchor!r}") from exc
        return pd.DatetimeIndex(values.groupby(periods).last().to_numpy())
    if frequency == "monthly":
        return pd.DatetimeIndex(values.groupby(dates.to_period("M")).last().to_numpy())
    raise ValueError(
        f"invalid_rebalance_frequency:{frequency}; expected daily, weekly, or monthly"
    )


# ---------------------------------------------------------------------------
# Daily candidate signals using calendar-month windows
# ---------------------------------------------------------------------------


def normalize_factor_weights(weights: pd.Series, gross: float = 1.0) -> pd.Series:
    out = weights.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    denominator = float(out.abs().sum())
    return out * 0.0 if denominator <= 0 else gross * out / denominator


def binary_tsfm_12m_signal(
    factor_history: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: StrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    signal_date = pd.Timestamp(signal_date)
    history = factor_history.loc[:signal_date].sort_index()
    columns = history.columns
    history_available = has_calendar_history(
        history.index, signal_date, max(cfg.formation_months, cfg.min_history_months)
    )
    past = calendar_month_window(history, signal_date, cfg.formation_months)
    complete = pd.Series(False, index=columns)
    if history_available and not past.empty:
        complete = past.notna().all(axis=0)
    formation_return = pd.Series(np.nan, index=columns, dtype=float)
    if complete.any():
        formation_return.loc[complete] = (1.0 + past.loc[:, complete]).prod(axis=0) - 1.0
    signal = pd.Series(0.0, index=columns)
    signal.loc[complete] = np.sign(formation_return.loc[complete]).fillna(0.0)
    weights = normalize_factor_weights(signal, cfg.factor_weight_gross)
    info = pd.DataFrame(
        {
            "formation_return": formation_return,
            "signal": signal,
            "formation_nobs": past.notna().sum(axis=0),
            "calendar_history_available": history_available,
            "formation_complete": complete,
            "signal_eligible": complete & signal.ne(0.0),
            "pre_quality_weight": weights,
        }
    )
    info.index.name = "target_theme"
    return weights, info


def vol_scaled_tsfm_signal(
    factor_history: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: StrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    signal_date = pd.Timestamp(signal_date)
    history = factor_history.loc[:signal_date].sort_index()
    columns = history.columns
    formation_history = has_calendar_history(
        history.index, signal_date, max(cfg.formation_months, cfg.min_history_months)
    )
    past = calendar_month_window(history, signal_date, cfg.formation_months)
    formation_complete = pd.Series(False, index=columns)
    if formation_history and not past.empty:
        formation_complete = past.notna().all(axis=0)
    formation_return = pd.Series(np.nan, index=columns, dtype=float)
    if formation_complete.any():
        formation_return.loc[formation_complete] = (
            1.0 + past.loc[:, formation_complete]
        ).prod(axis=0) - 1.0
    vol_window = calendar_month_window(history, signal_date, cfg.risk_lookback_months)
    sigma = vol_window.std(axis=0, ddof=1)
    vol_nobs = vol_window.notna().sum(axis=0)
    vol_eligible = (vol_nobs >= cfg.vol_min_observations) & (sigma > cfg.factor_vol_floor)
    eligible = formation_complete & vol_eligible
    raw_signal = pd.Series(0.0, index=columns)
    raw_signal.loc[eligible] = np.sign(formation_return.loc[eligible]) / sigma.loc[eligible]
    weights = normalize_factor_weights(raw_signal, cfg.factor_weight_gross)
    info = pd.DataFrame(
        {
            "formation_return": formation_return,
            "sigma": sigma,
            "vol_nobs": vol_nobs,
            "formation_nobs": past.notna().sum(axis=0),
            "raw_signal": raw_signal,
            "calendar_history_available": formation_history,
            "formation_complete": formation_complete,
            "vol_eligible": vol_eligible,
            "signal_eligible": eligible & raw_signal.ne(0.0),
            "pre_quality_weight": weights,
        }
    )
    info.index.name = "target_theme"
    return weights, info


# ---------------------------------------------------------------------------
# Quality and portfolio construction
# ---------------------------------------------------------------------------


def eligible_themes_at_date(
    bundle: BasketReplicationBundle,
    signal_date: pd.Timestamp,
    signal_info: pd.DataFrame,
    cfg: StrategyConfig,
) -> pd.DataFrame:
    signal_date = pd.Timestamp(signal_date)
    quality = signal_info.copy()
    diagnostics = bundle.replication_diagnostics
    cache = getattr(bundle, "_replication_diagnostics_by_date", None)
    if cache is None:
        cache = {}
        if not diagnostics.empty and "exposure_date" in diagnostics.columns:
            temp_diag = diagnostics.copy()
            temp_diag["exposure_date"] = pd.to_datetime(temp_diag["exposure_date"])
            for diag_date, group in temp_diag.groupby("exposure_date", sort=False):
                cache[pd.Timestamp(diag_date)] = group.set_index("target_theme")
        setattr(bundle, "_replication_diagnostics_by_date", cache)
    current = cache.get(signal_date, pd.DataFrame()).copy()
    if not current.empty:
        columns = [
                c
                for c in [
                    "solver_status",
                    "target_theme_exposure_error",
                    "max_abs_neutralization_exposure",
                    "condition_number_kkt",
                ]
                if c in current
            ]
        quality = quality.join(current[columns], how="left")
    quality["mapping_available"] = signal_date in bundle.basket_weights_by_date
    quality["stock_mapping_available"] = signal_date in bundle.stock_mimicking_weights_by_date
    quality["solver_allowed"] = quality.get("solver_status", pd.Series(index=quality.index, dtype=object)).isin(
        cfg.allowed_solver_status
    )
    if cfg.allow_soft_fallback:
        quality["solver_allowed"] |= quality.get(
            "solver_status", pd.Series(index=quality.index, dtype=object)
        ).astype(str).str.startswith("soft_solved")
    quality["target_error_ok"] = quality.get(
        "target_theme_exposure_error", pd.Series(np.nan, index=quality.index)
    ).abs().le(cfg.max_target_exposure_error)
    quality["neutrality_ok"] = quality.get(
        "max_abs_neutralization_exposure", pd.Series(np.nan, index=quality.index)
    ).le(cfg.max_neutralization_exposure)
    if cfg.max_condition_number is None:
        quality["condition_ok"] = True
    else:
        quality["condition_ok"] = quality.get(
            "condition_number_kkt", pd.Series(np.nan, index=quality.index)
        ).le(cfg.max_condition_number)
    if cfg.apply_replication_quality_filter:
        quality["eligible"] = (
            quality.get("signal_eligible", False).astype(bool)
            & quality["mapping_available"]
            & quality["stock_mapping_available"]
            & quality["solver_allowed"]
            & quality["target_error_ok"]
            & quality["neutrality_ok"]
            & quality["condition_ok"]
        )
    else:
        quality["eligible"] = quality.get("signal_eligible", False).astype(bool)
    reasons: list[str] = []
    for _, row in quality.iterrows():
        failed = []
        for name in [
            "signal_eligible",
            "mapping_available",
            "stock_mapping_available",
            "solver_allowed",
            "target_error_ok",
            "neutrality_ok",
            "condition_ok",
        ]:
            if not bool(row.get(name, False)):
                failed.append(name)
        reasons.append("ok" if not failed else "|".join(failed))
    quality["eligibility_reason"] = reasons
    return quality


def construct_basket_strategy_weights(
    H_t: pd.DataFrame,
    factor_weights: pd.Series,
    P_t: pd.DataFrame | None,
    cfg: StrategyConfig,
) -> BasketStrategyWeights:
    wF = normalize_factor_weights(
        factor_weights.reindex(H_t.columns).fillna(0.0), cfg.factor_weight_gross
    )
    b_pre = H_t.dot(wF)
    m_pre = P_t.dot(b_pre) if P_t is not None else None
    if cfg.strategy_scale_mode == "none":
        scale = 1.0
    elif cfg.strategy_scale_mode == "basket_instrument_gross":
        denominator = float(b_pre.abs().sum())
        if denominator <= cfg.weight_normalization_tolerance:
            raise ValueError("invalid_scale_denominator:basket_gross")
        scale = cfg.target_basket_instrument_gross / denominator
    elif cfg.strategy_scale_mode == "lookthrough_stock_gross":
        if m_pre is None:
            raise ValueError("missing_lookthrough_matrix")
        denominator = float(m_pre.abs().sum())
        if denominator <= cfg.weight_normalization_tolerance:
            raise ValueError("invalid_scale_denominator:lookthrough_gross")
        scale = cfg.target_lookthrough_stock_gross / denominator
    else:
        raise ValueError(f"Unsupported strategy_scale_mode: {cfg.strategy_scale_mode}")
    b = b_pre * scale
    m = m_pre * scale if m_pre is not None else None
    diagnostics = {
        "pre_scale_basket_gross": float(b_pre.abs().sum()),
        "pre_scale_basket_net": float(b_pre.sum()),
        "post_scale_basket_gross": float(b.abs().sum()),
        "post_scale_basket_net": float(b.sum()),
        "pre_scale_lookthrough_gross": float(m_pre.abs().sum()) if m_pre is not None else np.nan,
        "pre_scale_lookthrough_net": float(m_pre.sum()) if m_pre is not None else np.nan,
        "post_scale_lookthrough_gross": float(m.abs().sum()) if m is not None else np.nan,
        "post_scale_lookthrough_net": float(m.sum()) if m is not None else np.nan,
        "scale_factor": float(scale),
        "max_abs_basket_weight": float(b.abs().max()) if len(b) else 0.0,
        "n_long_baskets": int((b > cfg.weight_normalization_tolerance).sum()),
        "n_short_baskets": int((b < -cfg.weight_normalization_tolerance).sum()),
    }
    return BasketStrategyWeights(
        factor_weights=wF,
        scaled_factor_weights=wF * scale,
        basket_weights_pre_scale=b_pre,
        basket_weights=b,
        lookthrough_stock_weights_pre_scale=m_pre,
        lookthrough_stock_weights=m,
        scale=float(scale),
        diagnostics=diagnostics,
    )


def _construct_stock_strategy_weights(
    M_t: pd.DataFrame, factor_weights: pd.Series, cfg: StrategyConfig
) -> BasketStrategyWeights:
    wF = normalize_factor_weights(
        factor_weights.reindex(M_t.columns).fillna(0.0), cfg.factor_weight_gross
    )
    m_pre = M_t.dot(wF)
    denominator = float(m_pre.abs().sum())
    if cfg.strategy_scale_mode == "none":
        scale = 1.0
    elif cfg.strategy_scale_mode == "lookthrough_stock_gross":
        if denominator <= cfg.weight_normalization_tolerance:
            raise ValueError("invalid_scale_denominator:lookthrough_gross")
        scale = cfg.target_lookthrough_stock_gross / denominator
    else:
        raise ValueError("basket_instrument_gross is not defined for stock implementation")
    m = m_pre * scale
    empty = pd.Series(dtype=float)
    return BasketStrategyWeights(
        factor_weights=wF,
        scaled_factor_weights=wF * scale,
        basket_weights_pre_scale=empty,
        basket_weights=empty,
        lookthrough_stock_weights_pre_scale=m_pre,
        lookthrough_stock_weights=m,
        scale=float(scale),
        diagnostics={
            "pre_scale_basket_gross": np.nan,
            "pre_scale_basket_net": np.nan,
            "post_scale_basket_gross": np.nan,
            "post_scale_basket_net": np.nan,
            "pre_scale_lookthrough_gross": denominator,
            "pre_scale_lookthrough_net": float(m_pre.sum()),
            "post_scale_lookthrough_gross": float(m.abs().sum()),
            "post_scale_lookthrough_net": float(m.sum()),
            "scale_factor": float(scale),
            "max_abs_basket_weight": np.nan,
            "n_long_baskets": 0,
            "n_short_baskets": 0,
        },
    )


def one_way_turnover(previous: pd.Series | None, current: pd.Series | None) -> float:
    previous = pd.Series(dtype=float) if previous is None else previous.astype(float)
    current = pd.Series(dtype=float) if current is None else current.astype(float)
    labels = previous.index.union(current.index)
    return 0.5 * float(
        (current.reindex(labels, fill_value=0.0) - previous.reindex(labels, fill_value=0.0)).abs().sum()
    )


def _candidate_state(
    bundle: BasketReplicationBundle,
    data: Mapping[str, Any],
    cfg: StrategyConfig,
    signal_date: pd.Timestamp,
    raw_factor_weights: pd.Series,
    signal_info: pd.DataFrame,
    implementation_mode: str,
) -> tuple[_HeldState | None, pd.DataFrame, str]:
    quality = eligible_themes_at_date(bundle, signal_date, signal_info, cfg)
    candidate_wF = raw_factor_weights.reindex(quality.index).where(quality["eligible"], 0.0)
    candidate_wF = normalize_factor_weights(candidate_wF, cfg.factor_weight_gross)
    quality["post_quality_weight"] = candidate_wF
    if candidate_wF.abs().sum() <= cfg.weight_normalization_tolerance:
        return None, quality, "no_eligible_themes"
    try:
        if implementation_mode == "theme_basket_ls":
            H = bundle.basket_weights_by_date.get(signal_date)
            P = bundle.basket_constituent_weights_by_date.get(signal_date)
            if H is None or P is None:
                return None, quality, "missing_H_or_P_on_signal_date"
            weights = construct_basket_strategy_weights(H, candidate_wF, P, cfg)
            M = None
        elif implementation_mode == "stock_coefficient":
            M = bundle.stock_mimicking_weights_by_date.get(signal_date)
            if M is None:
                return None, quality, "missing_M_on_signal_date"
            weights = _construct_stock_strategy_weights(M, candidate_wF, cfg)
            H = P = None
        else:
            raise ValueError(f"Unsupported implementation_mode: {implementation_mode}")
        exposure_diag: dict[str, Any] = {}
        if weights.lookthrough_stock_weights is not None:
            try:
                rep_cfg = config_from_dict(bundle.config)
                snap = snapshot_for_date(data, signal_date, rep_cfg)
                w = weights.lookthrough_stock_weights.reindex(snap.neutralization_exposures.index).fillna(0.0)
                neutral = snap.neutralization_exposures.T @ w
                theme_exp = snap.purified_theme_exposures.T @ w
                intended = weights.scaled_factor_weights.reindex(theme_exp.index).fillna(0.0)
                exposure_diag = {
                    "max_neutralization_exposure": float(neutral.abs().max()),
                    "theme_exposure_distortion_l2": float(np.linalg.norm(theme_exp - intended)),
                }
            except Exception:
                exposure_diag = {
                    "max_neutralization_exposure": np.nan,
                    "theme_exposure_distortion_l2": np.nan,
                }
        return (
            _HeldState(
                rebalance_date=signal_date,
                factor_weights=weights.factor_weights,
                scaled_factor_weights=weights.scaled_factor_weights,
                weights=weights,
                implementation_mode=implementation_mode,
                H=H,
                P=P,
                M=M,
                quality=quality,
                exposure_diagnostics=exposure_diag,
            ),
            quality,
            "valid",
        )
    except Exception as exc:
        return None, quality, f"candidate_error:{type(exc).__name__}:{exc}"


def _held_return(
    held: _HeldState,
    stock_return: pd.Series,
    cfg: StrategyConfig,
) -> dict[str, Any]:
    m = held.weights.lookthrough_stock_weights
    m_pre = held.weights.lookthrough_stock_weights_pre_scale
    if m is None or m_pre is None:
        raise ValueError("missing_held_matrix")
    raw = stock_return.reindex(m.index)
    active = m.abs() > cfg.weight_normalization_tolerance
    total = float(m.abs().sum())
    available = float(m.abs()[raw.notna()].sum())
    coverage = 1.0 if total <= 0 else available / total
    if raw[active].isna().any() and cfg.missing_return_policy == "propagate_nan":
        raise ValueError("missing_daily_return")
    if coverage < cfg.min_return_coverage:
        raise ValueError(f"missing_daily_return:coverage={coverage:.6f}")
    r = raw.fillna(0.0)
    if held.implementation_mode == "theme_basket_ls":
        if held.P is None or held.H is None:
            raise ValueError("missing_held_matrix")
        r_full = stock_return.reindex(held.P.index).fillna(0.0)
        q = held.P.T @ r_full
        g = held.H.T @ q
        factor_pre = float(held.factor_weights.reindex(g.index).fillna(0.0) @ g)
        basket_pre = float(held.weights.basket_weights_pre_scale.reindex(q.index).fillna(0.0) @ q)
        lookthrough_pre = float(m_pre.reindex(r.index).fillna(0.0) @ r)
        factor_post = factor_pre * held.weights.scale
        basket_post = float(held.weights.basket_weights.reindex(q.index).fillna(0.0) @ q)
        lookthrough_post = float(m.reindex(r.index).fillna(0.0) @ r)
        factor_contribution = held.scaled_factor_weights.reindex(g.index).fillna(0.0) * g
        basket_contribution = held.weights.basket_weights.reindex(q.index).fillna(0.0) * q
    else:
        if held.M is None:
            raise ValueError("missing_held_matrix")
        g = held.M.T @ r.reindex(held.M.index).fillna(0.0)
        factor_pre = float(held.factor_weights.reindex(g.index).fillna(0.0) @ g)
        lookthrough_pre = float(m_pre.reindex(r.index).fillna(0.0) @ r)
        factor_post = factor_pre * held.weights.scale
        lookthrough_post = float(m.reindex(r.index).fillna(0.0) @ r)
        basket_pre = basket_post = np.nan
        factor_contribution = held.scaled_factor_weights.reindex(g.index).fillna(0.0) * g
        basket_contribution = pd.Series(dtype=float)
    factor_basket = abs(factor_post - basket_post) if np.isfinite(basket_post) else 0.0
    basket_stock = abs(basket_post - lookthrough_post) if np.isfinite(basket_post) else 0.0
    factor_stock = abs(factor_post - lookthrough_post)
    return {
        "factor_path_return_pre_scale": factor_pre,
        "basket_path_return_pre_scale": basket_pre,
        "lookthrough_path_return_pre_scale": lookthrough_pre,
        "factor_path_return": factor_post,
        "basket_path_return": basket_post,
        "lookthrough_path_return": lookthrough_post,
        "gross_return": basket_post if held.implementation_mode == "theme_basket_ls" else lookthrough_post,
        "factor_basket_identity_error": factor_basket,
        "basket_lookthrough_identity_error": basket_stock,
        "return_identity_error": max(factor_stock, factor_basket, basket_stock),
        "return_coverage": coverage,
        "factor_contribution": factor_contribution,
        "basket_contribution": basket_contribution,
    }


def _turnover_decomposition(
    previous: _HeldState | None, current: _HeldState, executed: bool
) -> dict[str, Any]:
    if not executed:
        return {
            "signal_change_component_l1": 0.0,
            "mapping_change_component_l1": 0.0,
            "scale_change_component_l1": 0.0,
            "decomposition_residual_l1": 0.0,
        }
    if previous is None or current.implementation_mode != "theme_basket_ls" or previous.implementation_mode != "theme_basket_ls":
        return {
            "signal_change_component_l1": np.nan,
            "mapping_change_component_l1": np.nan,
            "scale_change_component_l1": np.nan,
            "decomposition_residual_l1": np.nan,
        }
    old_H, new_H = previous.H, current.H
    if old_H is None or new_H is None:
        return {
            "signal_change_component_l1": np.nan,
            "mapping_change_component_l1": np.nan,
            "scale_change_component_l1": np.nan,
            "decomposition_residual_l1": np.nan,
        }
    baskets = old_H.index.union(new_H.index)
    themes = old_H.columns.union(new_H.columns)
    old_H = old_H.reindex(index=baskets, columns=themes, fill_value=0.0)
    new_H = new_H.reindex(index=baskets, columns=themes, fill_value=0.0)
    old_w = previous.factor_weights.reindex(themes, fill_value=0.0)
    new_w = current.factor_weights.reindex(themes, fill_value=0.0)
    signal_component = old_H @ (new_w - old_w) * previous.weights.scale
    mapping_component = (new_H - old_H) @ new_w * previous.weights.scale
    unscaled_new = new_H @ new_w
    scale_component = unscaled_new * (current.weights.scale - previous.weights.scale)
    actual = current.weights.basket_weights.reindex(baskets, fill_value=0.0) - previous.weights.basket_weights.reindex(baskets, fill_value=0.0)
    residual = actual - signal_component - mapping_component - scale_component
    return {
        "signal_change_component_l1": float(signal_component.abs().sum()),
        "mapping_change_component_l1": float(mapping_component.abs().sum()),
        "scale_change_component_l1": float(scale_component.abs().sum()),
        "decomposition_residual_l1": float(residual.abs().sum()),
    }


# ---------------------------------------------------------------------------
# Daily backtest with held state
# ---------------------------------------------------------------------------


def run_basket_factor_strategy_backtest(
    bundle: BasketReplicationBundle,
    data: Mapping[str, Any],
    cfg: StrategyConfig,
    signal_func: SignalFunction,
    strategy_name: str,
    signal_return_source: str | None = None,
    implementation_mode: str | None = None,
    strategy_id: str | None = None,
    rebalance_dates: pd.DatetimeIndex | None = None,
) -> dict[str, Any]:
    signal_return_source = signal_return_source or cfg.signal_return_source
    implementation_mode = implementation_mode or cfg.implementation_mode
    strategy_id = strategy_id or "D"
    signal_returns = (
        bundle.purified_theme_returns
        if signal_return_source == "purified"
        else bundle.basket_replicated_theme_returns
    ).sort_index()
    stock_returns = data["stock_returns"].sort_index()
    stock_dates = pd.DatetimeIndex(stock_returns.index)
    if signal_returns.empty:
        raise ValueError("No signal returns")
    first_signal = signal_returns.index.min()
    start_pos = int(stock_dates.searchsorted(first_signal, side="left"))
    signal_dates = stock_dates[start_pos:-1]
    if rebalance_dates is None:
        rebalance_dates = make_rebalance_dates(signal_dates, cfg)
    rebalance_set = set(pd.DatetimeIndex(rebalance_dates))

    records: list[dict[str, Any]] = []
    candidate_weight_rows: list[pd.Series] = []
    held_factor_rows: list[pd.Series] = []
    held_scaled_rows: list[pd.Series] = []
    signal_diag_rows: list[pd.DataFrame] = []
    basket_weight_rows: list[pd.DataFrame] = []
    stock_weight_rows: list[pd.DataFrame] = []
    factor_contribution_rows: list[pd.DataFrame] = []
    basket_contribution_rows: list[pd.DataFrame] = []
    replication_rows: list[dict[str, Any]] = []
    turnover_rows: list[dict[str, Any]] = []

    held: _HeldState | None = None
    for pos in range(start_pos, len(stock_dates) - 1):
        signal_date, return_date = stock_dates[pos], stock_dates[pos + 1]
        if signal_date not in signal_returns.index:
            raw_candidate = pd.Series(0.0, index=signal_returns.columns)
            signal_info = pd.DataFrame(index=signal_returns.columns)
            signal_info["signal_eligible"] = False
            candidate_status = "missing_daily_signal_return"
        else:
            history = signal_returns.loc[:signal_date]
            raw_candidate, signal_info = signal_func(history, signal_date, cfg)
            candidate_status = "signal_computed"
        is_rebalance = signal_date in rebalance_set
        quality = eligible_themes_at_date(bundle, signal_date, signal_info, cfg)
        filtered_candidate = normalize_factor_weights(
            raw_candidate.reindex(quality.index).where(quality["eligible"], 0.0),
            cfg.factor_weight_gross,
        )
        quality["post_quality_weight"] = filtered_candidate
        candidate_weight_rows.append(filtered_candidate.rename(signal_date))
        quality["signal_date"] = signal_date
        quality["is_rebalance_date"] = is_rebalance
        signal_diag_rows.append(quality.reset_index())

        previous = held
        executed = False
        action = "held" if held is not None else "no_position"
        if is_rebalance:
            candidate, quality, candidate_status = _candidate_state(
                bundle,
                data,
                cfg,
                signal_date,
                raw_candidate,
                signal_info,
                implementation_mode,
            )
            if candidate is not None:
                held = candidate
                executed = True
                action = "rebalanced"
            elif held is not None:
                action = "held_after_failed_rebalance"
            else:
                action = "no_successful_rebalance_yet"

        if held is None:
            records.append(
                {
                    "return_date": return_date,
                    "signal_date": signal_date,
                    "strategy_id": strategy_id,
                    "strategy_name": strategy_name,
                    "signal_return_source": signal_return_source,
                    "implementation_mode": implementation_mode,
                    "rebalance_frequency": cfg.rebalance_frequency,
                    "weekly_anchor": cfg.weekly_anchor,
                    "is_rebalance_date": is_rebalance,
                    "rebalance_executed": False,
                    "position_action": action,
                    "candidate_status": candidate_status,
                    "last_rebalance_date": pd.NaT,
                    "holding_age_observations": np.nan,
                    "gross_return": np.nan,
                    "transaction_cost": 0.0,
                    "net_return": np.nan,
                    "basket_turnover": 0.0,
                    "lookthrough_turnover": 0.0,
                    "status": "no_successful_rebalance_yet",
                }
            )
            continue

        basket_turnover = (
            one_way_turnover(
                previous.weights.basket_weights if previous is not None else None,
                held.weights.basket_weights,
            )
            if executed and implementation_mode == "theme_basket_ls"
            else 0.0
        )
        lookthrough_turnover = (
            one_way_turnover(
                previous.weights.lookthrough_stock_weights if previous is not None else None,
                held.weights.lookthrough_stock_weights,
            )
            if executed
            else 0.0
        )
        if implementation_mode == "stock_coefficient" or cfg.execution_model == "lookthrough_stock":
            cost_turnover = lookthrough_turnover
            cost_bps = cfg.stock_transaction_cost_bps_one_way
        else:
            cost_turnover = basket_turnover
            cost_bps = cfg.basket_transaction_cost_bps_one_way
        transaction_cost = cost_turnover * cost_bps / 10_000.0

        try:
            realized = _held_return(held, stock_returns.loc[return_date], cfg)
            status = (
                "return_identity_failure"
                if realized["return_identity_error"] > cfg.return_identity_tolerance
                else "ok"
            )
            gross_return = realized["gross_return"]
            net_return = gross_return - transaction_cost
        except Exception as exc:
            realized = {
                "factor_path_return_pre_scale": np.nan,
                "basket_path_return_pre_scale": np.nan,
                "lookthrough_path_return_pre_scale": np.nan,
                "factor_path_return": np.nan,
                "basket_path_return": np.nan,
                "lookthrough_path_return": np.nan,
                "gross_return": np.nan,
                "factor_basket_identity_error": np.nan,
                "basket_lookthrough_identity_error": np.nan,
                "return_identity_error": np.nan,
                "return_coverage": np.nan,
                "factor_contribution": pd.Series(dtype=float),
                "basket_contribution": pd.Series(dtype=float),
            }
            gross_return = net_return = np.nan
            status = f"{type(exc).__name__}:{exc}"

        holding_age = pos - int(stock_dates.get_loc(held.rebalance_date))
        active_quality = held.quality.loc[
            held.factor_weights.abs() > cfg.weight_normalization_tolerance
        ]
        max_target_error = (
            float(active_quality["target_theme_exposure_error"].abs().max())
            if "target_theme_exposure_error" in active_quality and len(active_quality)
            else np.nan
        )
        record = {
            "return_date": return_date,
            "signal_date": signal_date,
            "strategy_id": strategy_id,
            "strategy_name": strategy_name,
            "signal_return_source": signal_return_source,
            "implementation_mode": implementation_mode,
            "scale_mode": cfg.strategy_scale_mode,
            "execution_model": cfg.execution_model,
            "rebalance_frequency": cfg.rebalance_frequency,
            "weekly_anchor": cfg.weekly_anchor,
            "is_rebalance_date": is_rebalance,
            "rebalance_executed": executed,
            "position_action": action,
            "candidate_status": candidate_status,
            "last_rebalance_date": held.rebalance_date,
            "holding_age_observations": holding_age,
            **{k: v for k, v in realized.items() if not isinstance(v, pd.Series)},
            "transaction_cost": transaction_cost,
            "net_return": net_return,
            "basket_turnover": basket_turnover,
            "lookthrough_turnover": lookthrough_turnover,
            "cost_turnover": cost_turnover,
            "cost_bps_one_way": cost_bps,
            **held.weights.diagnostics,
            "n_long_factors": int((held.factor_weights > cfg.weight_normalization_tolerance).sum()),
            "n_short_factors": int((held.factor_weights < -cfg.weight_normalization_tolerance).sum()),
            "factor_weight_gross": float(held.factor_weights.abs().sum()),
            "max_target_exposure_error": max_target_error,
            **held.exposure_diagnostics,
            "status": status,
        }
        records.append(record)

        held_factor_rows.append(held.factor_weights.rename(signal_date))
        held_scaled_rows.append(held.scaled_factor_weights.rename(signal_date))
        if implementation_mode == "theme_basket_ls" and cfg.save_basket_weights:
            temp = held.weights.basket_weights.rename("weight").rename_axis("base_basket").reset_index()
            temp.insert(0, "signal_date", signal_date)
            temp.insert(1, "last_rebalance_date", held.rebalance_date)
            basket_weight_rows.append(temp)
        if held.weights.lookthrough_stock_weights is not None and cfg.save_lookthrough_stock_weights:
            temp = held.weights.lookthrough_stock_weights.rename("weight").rename_axis("stock_id").reset_index()
            temp.insert(0, "signal_date", signal_date)
            temp.insert(1, "last_rebalance_date", held.rebalance_date)
            stock_weight_rows.append(temp)
        if not realized["factor_contribution"].empty:
            temp = realized["factor_contribution"].rename("contribution").rename_axis("target_theme").reset_index()
            temp.insert(0, "return_date", return_date)
            temp.insert(1, "signal_date", signal_date)
            factor_contribution_rows.append(temp)
        if not realized["basket_contribution"].empty:
            temp = realized["basket_contribution"].rename("contribution").rename_axis("base_basket").reset_index()
            temp.insert(0, "return_date", return_date)
            temp.insert(1, "signal_date", signal_date)
            basket_contribution_rows.append(temp)
        replication_rows.append(
            {
                "signal_date": signal_date,
                "return_date": return_date,
                "last_rebalance_date": held.rebalance_date,
                "is_rebalance_date": is_rebalance,
                "rebalance_executed": executed,
                "return_identity_error": realized["return_identity_error"],
                **held.exposure_diagnostics,
                "status": status,
            }
        )
        turnover_rows.append(
            {
                "signal_date": signal_date,
                "return_date": return_date,
                "is_rebalance_date": is_rebalance,
                "rebalance_executed": executed,
                "basket_turnover": basket_turnover,
                "lookthrough_turnover": lookthrough_turnover,
                **_turnover_decomposition(previous, held, executed),
                "candidate_status": candidate_status,
            }
        )

    returns = pd.DataFrame(records)
    if not returns.empty:
        returns["return_date"] = pd.to_datetime(returns["return_date"])
        returns["signal_date"] = pd.to_datetime(returns["signal_date"])
        returns["last_rebalance_date"] = pd.to_datetime(returns["last_rebalance_date"])
        returns = returns.set_index("return_date").sort_index()
    candidate_factor_weights = pd.DataFrame(candidate_weight_rows).sort_index()
    factor_weights = pd.DataFrame(held_factor_rows).sort_index()
    scaled_factor_weights = pd.DataFrame(held_scaled_rows).sort_index()
    signal_diagnostics = pd.concat(signal_diag_rows, ignore_index=True) if signal_diag_rows else pd.DataFrame()
    basket_weights_long = pd.concat(basket_weight_rows, ignore_index=True) if basket_weight_rows else pd.DataFrame()
    stock_weights_long = pd.concat(stock_weight_rows, ignore_index=True) if stock_weight_rows else pd.DataFrame()
    factor_contributions = pd.concat(factor_contribution_rows, ignore_index=True) if factor_contribution_rows else pd.DataFrame()
    basket_contributions = pd.concat(basket_contribution_rows, ignore_index=True) if basket_contribution_rows else pd.DataFrame()
    replication_diagnostics = pd.DataFrame(replication_rows)
    turnover_decomposition = pd.DataFrame(turnover_rows)
    return {
        "strategy_id": strategy_id,
        "strategy_name": strategy_name,
        "signal_return_source": signal_return_source,
        "implementation_mode": implementation_mode,
        "rebalance_dates": pd.DatetimeIndex(rebalance_dates),
        "returns": returns,
        "candidate_factor_weights": candidate_factor_weights,
        "factor_weights": factor_weights,
        "scaled_factor_weights": scaled_factor_weights,
        "signal_diagnostics": signal_diagnostics,
        "basket_weights_long": basket_weights_long,
        "lookthrough_stock_weights_long": stock_weights_long,
        "factor_contributions": factor_contributions,
        "basket_contributions": basket_contributions,
        "strategy_replication_diagnostics": replication_diagnostics,
        "turnover_decomposition": turnover_decomposition,
        "metrics": performance_metrics(returns, cfg),
    }


# ---------------------------------------------------------------------------
# Comparison, metrics, validation
# ---------------------------------------------------------------------------


def performance_metrics(returns: pd.DataFrame, cfg: StrategyConfig) -> pd.DataFrame:
    if returns is None or returns.empty:
        return pd.DataFrame()
    valid = returns["status"].eq("ok") if "status" in returns else pd.Series(True, index=returns.index)
    rows: list[dict[str, Any]] = []
    for column in ["gross_return", "net_return"]:
        if column not in returns:
            continue
        r = returns.loc[valid, column].dropna()
        if r.empty:
            continue
        ann_mean = float(r.mean() * cfg.annualization)
        ann_vol = float(r.std(ddof=1) * np.sqrt(cfg.annualization))
        nav = (1.0 + r).cumprod()
        drawdown = nav / nav.cummax() - 1.0
        daily_cost = float(returns.loc[valid, "transaction_cost"].mean()) if "transaction_cost" in returns else np.nan
        rows.append(
            {
                "series": column,
                "n_obs": len(r),
                "n_months": len(r),  # deprecated compatibility column
                "ann_mean": ann_mean,
                "ann_vol": ann_vol,
                "sharpe": ann_mean / ann_vol if ann_vol > 0 else np.nan,
                "t_stat_mean": r.mean() / r.std(ddof=1) * np.sqrt(len(r)) if r.std(ddof=1) > 0 else np.nan,
                "max_drawdown": float(drawdown.min()),
                "hit_rate": float((r > 0).mean()),
                "skew": float(r.skew()),
                "final_growth_of_one": float(nav.iloc[-1]),
                "avg_annual_basket_turnover": float(returns.loc[valid, "basket_turnover"].mean() * cfg.annualization),
                "avg_annual_lookthrough_turnover": float(returns.loc[valid, "lookthrough_turnover"].mean() * cfg.annualization),
                "avg_daily_transaction_cost": daily_cost,
                "annualized_transaction_cost": daily_cost * cfg.annualization,
                "avg_monthly_transaction_cost": daily_cost,  # deprecated compatibility column
            }
        )
    return pd.DataFrame(rows).set_index("series") if rows else pd.DataFrame()


def run_strategy_comparison_grid(
    bundle: BasketReplicationBundle,
    data: Mapping[str, Any],
    cfg: StrategyConfig,
    signal_func: SignalFunction,
    strategy_label: str,
) -> dict[str, Any]:
    stock_dates = pd.DatetimeIndex(data["stock_returns"].index)
    first = max(
        bundle.purified_theme_returns.index.min(),
        bundle.basket_replicated_theme_returns.index.min(),
    )
    start = int(stock_dates.searchsorted(first, side="left"))
    master_signal_dates = stock_dates[start:-1]
    common_rebalance_dates = make_rebalance_dates(master_signal_dates, cfg)
    grid = {
        "A": ("purified", "stock_coefficient"),
        "B": ("purified", "theme_basket_ls"),
        "C": ("basket_replicated", "stock_coefficient"),
        "D": ("basket_replicated", "theme_basket_ls"),
    }
    results: dict[str, dict[str, Any]] = {}
    for key, (source, implementation) in grid.items():
        local_cfg = cfg
        if implementation == "stock_coefficient" and cfg.strategy_scale_mode == "basket_instrument_gross":
            local_cfg = replace(cfg, strategy_scale_mode="lookthrough_stock_gross")
        results[key] = run_basket_factor_strategy_backtest(
            bundle,
            data,
            local_cfg,
            signal_func,
            f"{strategy_label} [{key}]",
            source,
            implementation,
            key,
            common_rebalance_dates,
        )
    wide_parts: list[pd.DataFrame] = []
    native_metrics: list[pd.DataFrame] = []
    common_dates: pd.Index | None = None
    for key, result in results.items():
        r = result["returns"]
        cols = [c for c in ["gross_return", "net_return", "status", "rebalance_executed"] if c in r]
        part = r[cols].copy()
        part.columns = pd.MultiIndex.from_product([[key], part.columns])
        wide_parts.append(part)
        ok = r.index[r["status"].eq("ok") & r["net_return"].notna()]
        common_dates = ok if common_dates is None else common_dates.intersection(ok)
        if not result["metrics"].empty:
            temp = result["metrics"].reset_index()
            temp.insert(0, "strategy_id", key)
            native_metrics.append(temp)
    common_dates = pd.Index([]) if common_dates is None else common_dates.sort_values()
    common_returns = pd.DataFrame(index=common_dates)
    common_metric_rows: list[dict[str, Any]] = []
    for key, result in results.items():
        r = result["returns"].reindex(common_dates)
        common_returns[f"{key}_gross_return"] = r.get("gross_return")
        common_returns[f"{key}_net_return"] = r.get("net_return")
        temp = r.copy()
        if not temp.empty:
            temp["status"] = "ok"
            metrics = performance_metrics(temp, cfg)
            for series, row in metrics.iterrows():
                common_metric_rows.append({"strategy_id": key, "series": series, **row.to_dict()})
    effects = pd.DataFrame(index=common_dates)
    if len(common_dates):
        effects["implementation_effect_on_purified_signal_B_minus_A"] = common_returns["B_gross_return"] - common_returns["A_gross_return"]
        effects["signal_effect_on_stock_impl_C_minus_A"] = common_returns["C_gross_return"] - common_returns["A_gross_return"]
        effects["combined_effect_D_minus_A"] = common_returns["D_gross_return"] - common_returns["A_gross_return"]
        effects["signal_effect_on_basket_impl_D_minus_B"] = common_returns["D_gross_return"] - common_returns["B_gross_return"]
        effects["implementation_effect_on_basket_signal_D_minus_C"] = common_returns["D_gross_return"] - common_returns["C_gross_return"]
    return {
        "results": results,
        "rebalance_dates": common_rebalance_dates,
        "returns_wide": pd.concat(wide_parts, axis=1).sort_index(),
        "metrics_native": pd.concat(native_metrics, ignore_index=True) if native_metrics else pd.DataFrame(),
        "common_dates": common_dates,
        "common_returns": common_returns,
        "common_metrics": pd.DataFrame(common_metric_rows),
        "effects": effects,
    }


def run_strategy_validation_checks(
    bundle: BasketReplicationBundle,
    data: Mapping[str, Any],
    cfg: StrategyConfig,
    signal_func: SignalFunction,
    comparison: Mapping[str, Any],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []

    def add(check: str, value: Any, limit: Any, passed: bool) -> None:
        rows.append({"check": check, "value": value, "limit": limit, "passed": bool(passed)})

    results = comparison["results"]
    add("A_to_D_present", set(results), {"A", "B", "C", "D"}, set(results) == {"A", "B", "C", "D"})
    add("annualization_is_daily", cfg.annualization, 252, cfg.annualization == 252)
    max_identity = 0.0
    non_rebalance_turnover = 0.0
    non_rebalance_cost = 0.0
    held_change = 0.0
    candidate_counts = set()
    schedule_equal = True
    expected_rebalance = pd.DatetimeIndex(comparison["rebalance_dates"])
    for result in results.values():
        r = result["returns"]
        ok_identity = r.loc[r["status"].eq("ok"), "return_identity_error"].dropna()
        if len(ok_identity):
            max_identity = max(max_identity, float(ok_identity.max()))
        non = r[~r["rebalance_executed"].fillna(False)]
        if len(non):
            non_rebalance_turnover = max(
                non_rebalance_turnover,
                float(non[["basket_turnover", "lookthrough_turnover"]].abs().max().max()),
            )
            non_rebalance_cost = max(non_rebalance_cost, float(non["transaction_cost"].abs().max()))
        candidate_counts.add(len(result["candidate_factor_weights"]))
        schedule_equal &= result["rebalance_dates"].equals(expected_rebalance)
        weights = result["factor_weights"]
        returns = r.reset_index().set_index("signal_date")
        common = weights.index.intersection(returns.index)
        if len(common) > 1:
            w = weights.reindex(common)
            actions = returns.reindex(common)["position_action"]
            diff = w.diff().abs().sum(axis=1)
            held_dates = actions.isin(["held", "held_after_failed_rebalance"])
            if held_dates.any():
                held_change = max(held_change, float(diff[held_dates].max()))
    add("daily_candidate_signal_count_equal_across_A_D", len(candidate_counts), 1, len(candidate_counts) == 1)
    add("common_rebalance_calendar_A_D", schedule_equal, True, schedule_equal)
    add("non_rebalance_turnover_zero", non_rebalance_turnover, 0.0, non_rebalance_turnover == 0.0)
    add("non_rebalance_cost_zero", non_rebalance_cost, 0.0, non_rebalance_cost == 0.0)
    add("held_factor_weights_unchanged_between_rebalances", held_change, cfg.weight_normalization_tolerance, held_change <= cfg.weight_normalization_tolerance)
    add("daily_return_identity", max_identity, cfg.return_identity_tolerance, max_identity <= cfg.return_identity_tolerance)
    add("common_A_D_daily_sample_exists", len(comparison["common_dates"]), 1, len(comparison["common_dates"]) > 0)
    # Schedule semantics.
    dates = pd.DatetimeIndex(data["stock_returns"].index[:-1])
    schedule = make_rebalance_dates(dates, cfg)
    if cfg.rebalance_frequency == "daily":
        schedule_ok = schedule.equals(dates)
    elif cfg.rebalance_frequency == "weekly":
        expected = pd.Series(dates, index=dates).groupby(dates.to_period(cfg.weekly_anchor)).last()
        schedule_ok = schedule.equals(pd.DatetimeIndex(expected.to_numpy()))
    else:
        expected = pd.Series(dates, index=dates).groupby(dates.to_period("M")).last()
        schedule_ok = schedule.equals(pd.DatetimeIndex(expected.to_numpy()))
    add("rebalance_schedule_semantics", schedule_ok, True, schedule_ok)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Persistence / plots
# ---------------------------------------------------------------------------


def save_basket_strategy_outputs(
    result: Mapping[str, Any],
    comparison: Mapping[str, Any],
    cfg: StrategyConfig,
    subdir: str,
    *,
    bundle: BasketReplicationBundle | None = None,
    validation_checks: pd.DataFrame | None = None,
) -> tuple[Path, dict[str, Any]]:
    out = Path(cfg.output_dir) / subdir
    out.mkdir(parents=True, exist_ok=True)
    files: dict[str, Any] = {}

    def save_csv(frame: pd.DataFrame, name: str, *, index: bool = True) -> None:
        frame.to_csv(out / name, index=index)
        files[name] = {"actual": name, "format": "csv"}

    save_csv(result["returns"], "strategy_returns.csv")
    save_csv(result["candidate_factor_weights"], "candidate_factor_weights.csv")
    save_csv(result["factor_weights"], "factor_weights.csv")
    save_csv(result["scaled_factor_weights"], "scaled_factor_weights.csv")
    for requested, key in [
        ("signal_diagnostics.parquet", "signal_diagnostics"),
        ("strategy_basket_weights_long.parquet", "basket_weights_long"),
        ("strategy_lookthrough_stock_weights_long.parquet", "lookthrough_stock_weights_long"),
        ("factor_contributions.parquet", "factor_contributions"),
        ("basket_contributions.parquet", "basket_contributions"),
        ("strategy_replication_diagnostics.parquet", "strategy_replication_diagnostics"),
        ("turnover_decomposition.parquet", "turnover_decomposition"),
    ]:
        files[requested] = write_table_with_fallback(result[key], out / requested, index=False)
    save_csv(result["metrics"], "performance_metrics.csv")
    save_csv(comparison["metrics_native"], "comparison_grid_metrics.csv", index=False)
    save_csv(comparison["common_returns"], "comparison_grid_returns.csv")
    save_csv(comparison["common_metrics"], "comparison_common_sample_metrics.csv", index=False)
    save_csv(comparison["effects"], "comparison_effects.csv")
    if validation_checks is not None:
        save_csv(validation_checks, "validation_checks.csv", index=False)
    with (out / "config.json").open("w", encoding="utf-8") as handle:
        json.dump(asdict(cfg), handle, indent=2, ensure_ascii=False)
    input_manifest = {
        "strategy_schema_version": STRATEGY_SCHEMA_VERSION,
        "replication_schema_version": bundle.manifest.get("replication_schema_version") if bundle else None,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rebalance_frequency": cfg.rebalance_frequency,
        "weekly_anchor": cfg.weekly_anchor,
        "annualization": cfg.annualization,
        "signal_observation_frequency": "observed_trading_days",
        "n_candidate_signal_dates": int(len(result["candidate_factor_weights"])),
        "n_return_dates": int(len(result["returns"])),
        "n_rebalances_executed": int(result["returns"].get("rebalance_executed", pd.Series(dtype=bool)).sum()),
    }
    with (out / "input_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(input_manifest, handle, indent=2, ensure_ascii=False)
    manifest = {**input_manifest, "files": files}
    with (out / "save_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    return out, manifest


def plot_strategy_result(result: Mapping[str, Any]):
    import matplotlib.pyplot as plt

    returns = result["returns"]
    ok = returns[returns["status"].eq("ok")]
    figures = []
    if not ok.empty:
        fig, ax = plt.subplots(figsize=(10, 4))
        (1.0 + ok[["gross_return", "net_return"]]).cumprod().plot(ax=ax)
        ax.set_title(result["strategy_name"] + ": daily cumulative return")
        fig.tight_layout()
        figures.append(fig)
        fig, ax = plt.subplots(figsize=(10, 3))
        ok[["basket_turnover", "lookthrough_turnover"]].plot(ax=ax)
        ax.set_title(result["strategy_name"] + ": daily one-way turnover")
        fig.tight_layout()
        figures.append(fig)
    return figures


def plot_comparison_grid(comparison: Mapping[str, Any], *, net: bool = True):
    import matplotlib.pyplot as plt

    common = comparison["common_returns"]
    suffix = "net_return" if net else "gross_return"
    columns = [column for column in common if column.endswith(suffix)]
    if not columns:
        return None
    fig, ax = plt.subplots(figsize=(10, 4))
    (1.0 + common[columns]).cumprod().plot(ax=ax)
    ax.set_title("A-D daily comparison on common sample")
    fig.tight_layout()
    return fig


def save_strategy_figures(
    out_dir: str | Path,
    result: Mapping[str, Any],
    comparison: Mapping[str, Any],
) -> list[Path]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []
    for i, figure in enumerate(plot_strategy_result(result), 1):
        path = out / f"strategy_figure_{i:02d}.png"
        figure.savefig(path, dpi=150, bbox_inches="tight")
        saved.append(path)
    figure = plot_comparison_grid(comparison)
    if figure is not None:
        path = out / "comparison_grid_cumulative.png"
        figure.savefig(path, dpi=150, bbox_inches="tight")
        saved.append(path)
    return saved


__all__ = [
    "STRATEGY_SCHEMA_VERSION",
    "StrategyConfig",
    "BasketReplicationBundle",
    "BasketStrategyWeights",
    "calendar_month_window",
    "has_calendar_history",
    "make_rebalance_dates",
    "load_basket_replication_bundle",
    "build_basket_replication_bundle",
    "prepare_replication_bundle",
    "validate_replication_bundle",
    "binary_tsfm_12m_signal",
    "vol_scaled_tsfm_signal",
    "eligible_themes_at_date",
    "construct_basket_strategy_weights",
    "run_basket_factor_strategy_backtest",
    "run_strategy_comparison_grid",
    "run_strategy_validation_checks",
    "performance_metrics",
    "save_basket_strategy_outputs",
    "plot_strategy_result",
    "plot_comparison_grid",
    "save_strategy_figures",
    "normalize_factor_weights",
    "one_way_turnover",
]
