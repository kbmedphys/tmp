"""Compatibility alias for the integrated replication implementation.

New code should import :mod:`integrated_factor_replication`.  This module keeps
an intuitive mimicking-oriented import path for notebooks and downstream code.
"""
from integrated_factor_replication import *  # noqa: F401,F403
