"""TSFM strategies implemented with theme-basket long/short portfolios.

The engine separates two choices:
  * the factor return history used to form the TSFM signal; and
  * the instruments used to implement the next-month position.

This makes the A/B/C/D comparison explicit and prevents signal and execution
changes from being conflated.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, fields, replace
from pathlib import Path
from typing import Any, Callable, Literal, Mapping

import numpy as np
import pandas as pd

from theme_basket_mimicking import (
    REPLICATION_SCHEMA_VERSION,
    BasketReplicationArtifacts,
    ReplicationConfig,
    config_from_dict,
    construct_stock_mimicking_portfolios,
    fingerprint_inputs,
    long_to_matrix_dict,
    read_table_with_fallback,
    run_theme_basket_replication,
    save_replication_outputs,
    stable_json_hash,
    write_table_with_fallback,
)


STRATEGY_SCHEMA_VERSION = "1.2.0"


@dataclass
class StrategyConfig:
    # Replication data source
    replication_output_dir: str = (
        "theme_factor_momentum_outputs/00_mimicking_portfolio_diagnostics_theme_basket"
    )
    replication_data_mode: Literal["auto", "load_00_outputs", "recompute"] = "auto"
    output_dir: str = "theme_factor_momentum_outputs"
    require_schema_version_match: bool = True
    require_config_hash_match: bool = False
    require_input_fingerprint_match: bool = True

    # Signal source / implementation
    signal_return_source: Literal["purified", "basket_replicated"] = "basket_replicated"
    implementation_mode: Literal["stock_coefficient", "theme_basket_ls"] = "theme_basket_ls"

    # Formation
    formation_months: int = 12
    min_history_months: int = 24
    risk_lookback_months: int = 36
    vol_min_observations: int = 24
    factor_vol_floor: float = 1e-8
    factor_weight_gross: float = 1.0

    # Point-in-time quality
    apply_replication_quality_filter: bool = True
    allow_soft_fallback: bool = False
    allowed_solver_status: tuple[str, ...] = ("hard_solved", "hard_solved_pinv")
    max_target_exposure_error: float = 1e-6
    max_neutralization_exposure: float = 1e-6
    min_replication_return_coverage: float = 0.98
    max_condition_number: float | None = None

    # Strategy scale
    strategy_scale_mode: Literal[
        "none", "lookthrough_stock_gross", "basket_instrument_gross"
    ] = "lookthrough_stock_gross"
    target_lookthrough_stock_gross: float = 1.0
    target_basket_instrument_gross: float = 1.0

    # Execution and costs
    execution_model: Literal["basket_instrument", "lookthrough_stock"] = "basket_instrument"
    basket_transaction_cost_bps_one_way: float = 10.0
    stock_transaction_cost_bps_one_way: float = 10.0

    # Missing data
    missing_return_policy: Literal["propagate_nan", "coverage_threshold"] = "coverage_threshold"
    min_realized_return_coverage: float = 0.98

    # Numerical validation
    return_identity_tolerance: float = 1e-10
    weight_normalization_tolerance: float = 1e-12
    gross_target_tolerance: float = 1e-10

    # Comparison, reporting, and saving
    run_comparison_grid: bool = True
    comparison_common_sample: bool = True
    rolling_metric_months: int = 36
    save_basket_weights: bool = True
    save_lookthrough_stock_weights: bool = True
    annualization: int = 12
    max_weight_table_rows: int = 12


@dataclass
class BasketReplicationBundle:
    purified_theme_returns: pd.DataFrame
    stock_coefficient_replicated_theme_returns: pd.DataFrame
    basket_replicated_theme_returns: pd.DataFrame
    raw_basket_returns: pd.DataFrame
    basket_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    replication_diagnostics: pd.DataFrame
    basis_diagnostics: pd.DataFrame
    return_coverage: pd.DataFrame
    lookthrough_weights_by_date: dict[pd.Timestamp, pd.DataFrame] | None
    stock_coefficient_weights_by_date: dict[pd.Timestamp, pd.DataFrame] | None
    basket_constituent_weights_by_date: dict[pd.Timestamp, pd.DataFrame] | None
    config: dict[str, Any]
    manifest: dict[str, Any]


@dataclass
class BasketStrategyWeights:
    factor_weights: pd.Series
    scaled_factor_weights: pd.Series
    basket_weights_pre_scale: pd.Series
    basket_weights: pd.Series
    lookthrough_stock_weights_pre_scale: pd.Series | None
    lookthrough_stock_weights: pd.Series | None
    scale: float
    diagnostics: dict[str, Any]


SignalFunction = Callable[
    [pd.DataFrame, pd.Timestamp, StrategyConfig], tuple[pd.Series, pd.DataFrame]
]


# ---------------------------------------------------------------------------
# Data loading and validation
# ---------------------------------------------------------------------------


def _read_indexed_return_csv(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, index_col=0)
    frame.index = pd.to_datetime(frame.index)
    return frame.sort_index().astype(float)


def _read_optional_table(output_dir: Path, stem: str) -> pd.DataFrame:
    parquet = output_dir / f"{stem}.parquet"
    csv = output_dir / f"{stem}.csv"
    if parquet.exists() or csv.exists():
        return read_table_with_fallback(parquet)
    return pd.DataFrame()


def bundle_from_replication_result(result: Mapping[str, Any]) -> BasketReplicationBundle:
    artifacts: BasketReplicationArtifacts = result["basket_artifacts"]
    manifest = {
        "replication_schema_version": REPLICATION_SCHEMA_VERSION,
        "input_fingerprint": result["input_fingerprint"],
        "config_hash": result["config_hash"],
    }
    config = asdict(result.get("replication_config", ReplicationConfig())) if result.get("replication_config") else {}
    return BasketReplicationBundle(
        purified_theme_returns=result["purified_theme_returns"].copy(),
        stock_coefficient_replicated_theme_returns=result[
            "stock_coefficient_replicated_theme_returns"
        ].copy(),
        basket_replicated_theme_returns=result["basket_replicated_theme_returns"].copy(),
        raw_basket_returns=artifacts.raw_basket_returns.copy(),
        basket_weights_by_date={d: x.copy() for d, x in artifacts.basket_weights_by_date.items()},
        replication_diagnostics=artifacts.replication_diagnostics.copy(),
        basis_diagnostics=artifacts.basis_diagnostics.copy(),
        return_coverage=artifacts.return_coverage.copy(),
        lookthrough_weights_by_date={d: x.copy() for d, x in artifacts.lookthrough_weights_by_date.items()},
        stock_coefficient_weights_by_date={
            d: x.copy() for d, x in artifacts.stock_coefficient_weights_by_date.items()
        },
        basket_constituent_weights_by_date={
            d: x.copy() for d, x in artifacts.basket_constituent_weights_by_date.items()
        },
        config=config,
        manifest=manifest,
    )


def load_basket_replication_bundle(
    output_dir: str | Path,
    cfg: StrategyConfig,
    *,
    expected_input_fingerprint: str | None = None,
    expected_config_hash: str | None = None,
) -> BasketReplicationBundle:
    output = Path(output_dir)
    required = [
        "purified_theme_returns.csv",
        "stock_coefficient_replicated_theme_returns.csv",
        "basket_ls_replicated_theme_returns.csv",
        "raw_theme_basket_returns.csv",
        "basket_mimicking_diagnostics.csv",
        "basket_basis_rank_diagnostics.csv",
        "basket_return_coverage.csv",
        "comparison_config.json",
        "save_manifest.json",
    ]
    missing = [name for name in required if not (output / name).exists()]
    if missing:
        raise FileNotFoundError(f"Replication output is missing files: {missing}")

    purified = _read_indexed_return_csv(output / "purified_theme_returns.csv")
    stock_coef_rep = _read_indexed_return_csv(
        output / "stock_coefficient_replicated_theme_returns.csv"
    )
    basket_rep = _read_indexed_return_csv(output / "basket_ls_replicated_theme_returns.csv")
    raw_baskets = _read_indexed_return_csv(output / "raw_theme_basket_returns.csv")
    H_long = _read_optional_table(output, "basket_weights_long")
    if H_long.empty:
        raise FileNotFoundError("basket_weights_long.parquet or CSV fallback is required")
    H_by_date = long_to_matrix_dict(H_long, "base_basket", "target_theme")

    lookthrough_long = _read_optional_table(output, "basket_lookthrough_stock_weights_long")
    lookthrough = (
        long_to_matrix_dict(lookthrough_long, "stock_id", "target_theme")
        if not lookthrough_long.empty
        else None
    )
    stock_long = _read_optional_table(output, "stock_coefficient_weights_long")
    stock_weights = (
        long_to_matrix_dict(stock_long, "stock_id", "target_theme")
        if not stock_long.empty
        else None
    )
    P_long = _read_optional_table(output, "tradable_basket_constituent_weights_long")
    P_by_date = (
        long_to_matrix_dict(P_long, "stock_id", "base_basket") if not P_long.empty else None
    )

    replication_diag = pd.read_csv(output / "basket_mimicking_diagnostics.csv")
    basis_diag = pd.read_csv(output / "basket_basis_rank_diagnostics.csv")
    coverage = pd.read_csv(output / "basket_return_coverage.csv")
    for frame, cols in [
        (replication_diag, ["exposure_date", "return_date"]),
        (basis_diag, ["exposure_date"]),
        (coverage, ["exposure_date", "return_date"]),
    ]:
        for col in cols:
            if col in frame.columns:
                frame[col] = pd.to_datetime(frame[col])

    with (output / "comparison_config.json").open("r", encoding="utf-8") as f:
        config = json.load(f)
    with (output / "save_manifest.json").open("r", encoding="utf-8") as f:
        manifest = json.load(f)

    schema = manifest.get("replication_schema_version")
    if cfg.require_schema_version_match and schema != REPLICATION_SCHEMA_VERSION:
        raise ValueError(
            f"Replication schema mismatch: expected {REPLICATION_SCHEMA_VERSION}, got {schema}"
        )
    if (
        cfg.require_input_fingerprint_match
        and expected_input_fingerprint is not None
        and manifest.get("input_fingerprint") != expected_input_fingerprint
    ):
        raise ValueError("Input fingerprint mismatch between 00 outputs and strategy data")
    if (
        cfg.require_config_hash_match
        and expected_config_hash is not None
        and manifest.get("config_hash") != expected_config_hash
    ):
        raise ValueError("Replication config hash mismatch")

    bundle = BasketReplicationBundle(
        purified_theme_returns=purified,
        stock_coefficient_replicated_theme_returns=stock_coef_rep,
        basket_replicated_theme_returns=basket_rep,
        raw_basket_returns=raw_baskets,
        basket_weights_by_date=H_by_date,
        replication_diagnostics=replication_diag,
        basis_diagnostics=basis_diag,
        return_coverage=coverage,
        lookthrough_weights_by_date=lookthrough,
        stock_coefficient_weights_by_date=stock_weights,
        basket_constituent_weights_by_date=P_by_date,
        config=config,
        manifest=manifest,
    )
    validation = validate_replication_bundle(bundle, cfg)
    if not validation["passed"].all():
        failed = validation.loc[~validation["passed"], "check"].tolist()
        raise ValueError(f"Replication bundle validation failed: {failed}")
    return bundle


def prepare_replication_bundle(
    data: Mapping[str, Any],
    replication_cfg: ReplicationConfig,
    strategy_cfg: StrategyConfig,
) -> tuple[BasketReplicationBundle, str, pd.DataFrame]:
    mode = strategy_cfg.replication_data_mode
    output_dir = Path(strategy_cfg.replication_output_dir)
    expected_fingerprint = fingerprint_inputs(data, replication_cfg)
    expected_config_hash = stable_json_hash(asdict(replication_cfg))

    if mode in {"auto", "load_00_outputs"}:
        try:
            bundle = load_basket_replication_bundle(
                output_dir,
                strategy_cfg,
                expected_input_fingerprint=expected_fingerprint,
                expected_config_hash=expected_config_hash,
            )
            return bundle, "load_00_outputs", validate_replication_bundle(bundle, strategy_cfg)
        except (FileNotFoundError, ValueError):
            if mode == "load_00_outputs":
                raise

    if mode not in {"auto", "recompute"}:
        raise ValueError(f"Unknown replication_data_mode: {mode}")
    result = run_theme_basket_replication(data, replication_cfg)
    result["replication_config"] = replication_cfg
    save_replication_outputs(result, replication_cfg, output_dir)
    bundle = load_basket_replication_bundle(
        output_dir,
        strategy_cfg,
        expected_input_fingerprint=expected_fingerprint,
        expected_config_hash=expected_config_hash,
    )
    return bundle, "recompute", validate_replication_bundle(bundle, strategy_cfg)


def validate_replication_bundle(
    bundle: BasketReplicationBundle,
    cfg: StrategyConfig,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []

    def add(check: str, passed: bool, value: Any = None, detail: str = "") -> None:
        rows.append({"check": check, "passed": bool(passed), "value": value, "detail": detail})

    for name, frame in [
        ("purified_theme_returns", bundle.purified_theme_returns),
        (
            "stock_coefficient_replicated_theme_returns",
            bundle.stock_coefficient_replicated_theme_returns,
        ),
        ("basket_replicated_theme_returns", bundle.basket_replicated_theme_returns),
        ("raw_basket_returns", bundle.raw_basket_returns),
    ]:
        add(f"{name}_date_index_unique", frame.index.is_unique, len(frame))
        add(f"{name}_date_index_sorted", frame.index.is_monotonic_increasing, len(frame))
        add(f"{name}_column_labels_unique", frame.columns.is_unique, len(frame.columns))

    stock_common_themes = bundle.purified_theme_returns.columns.intersection(
        bundle.stock_coefficient_replicated_theme_returns.columns
    )
    add(
        "purified_and_stock_coefficient_theme_labels_match",
        set(bundle.purified_theme_returns.columns)
        == set(bundle.stock_coefficient_replicated_theme_returns.columns),
        len(stock_common_themes),
    )
    common_themes = bundle.purified_theme_returns.columns.intersection(
        bundle.basket_replicated_theme_returns.columns
    )
    add(
        "purified_and_basket_theme_labels_match",
        set(bundle.purified_theme_returns.columns) == set(bundle.basket_replicated_theme_returns.columns),
        len(common_themes),
    )
    add("basket_weight_snapshots_exist", bool(bundle.basket_weights_by_date), len(bundle.basket_weights_by_date))

    h_label_ok = True
    h_finite = True
    q_label_ok = True
    for date, H in bundle.basket_weights_by_date.items():
        h_label_ok &= set(H.columns) == set(bundle.basket_replicated_theme_returns.columns)
        q_label_ok &= set(H.index).issubset(set(bundle.raw_basket_returns.columns))
        h_finite &= np.isfinite(H.to_numpy()).all()
    add("H_target_theme_labels_match", h_label_ok)
    add("H_base_basket_labels_match_raw_returns", q_label_ok)
    add("H_weights_finite", h_finite)

    date_order_ok = True
    h_dates = sorted(bundle.basket_weights_by_date)
    q_dates = sorted(bundle.raw_basket_returns.index)
    if h_dates and q_dates:
        for h_date in h_dates:
            later = [d for d in q_dates if d > h_date]
            if not later:
                continue
            date_order_ok &= h_date < later[0]
    add("exposure_dates_precede_next_return_dates", date_order_ok)

    schema = bundle.manifest.get("replication_schema_version")
    add(
        "replication_schema_version",
        (not cfg.require_schema_version_match) or schema == REPLICATION_SCHEMA_VERSION,
        schema,
    )
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Signal functions
# ---------------------------------------------------------------------------


def normalize_factor_weights(weights: pd.Series, gross: float = 1.0) -> pd.Series:
    w = weights.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    denominator = float(w.abs().sum())
    return w if denominator <= 0 else gross * w / denominator


def binary_tsfm_12m_signal(
    factor_history: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: StrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    history = factor_history.loc[: pd.Timestamp(signal_date)].sort_index()
    columns = history.columns
    past = history.tail(cfg.formation_months)
    complete = pd.Series(False, index=columns)
    if len(past) == cfg.formation_months:
        complete = past.notna().all(axis=0)
    formation_return = pd.Series(np.nan, index=columns, dtype=float)
    if complete.any():
        formation_return.loc[complete] = (1.0 + past.loc[:, complete]).prod(axis=0) - 1.0
    signal = pd.Series(0.0, index=columns)
    signal.loc[complete] = np.sign(formation_return.loc[complete]).fillna(0.0)
    weights = normalize_factor_weights(signal, cfg.factor_weight_gross)
    info = pd.DataFrame(
        {
            "formation_return": formation_return,
            "signal": signal,
            "formation_complete": complete,
            "signal_eligible": complete & signal.ne(0.0),
            "pre_quality_weight": weights,
        }
    )
    info.index.name = "target_theme"
    return weights, info


def vol_scaled_tsfm_signal(
    factor_history: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: StrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    history = factor_history.loc[: pd.Timestamp(signal_date)].sort_index()
    columns = history.columns
    past = history.tail(cfg.formation_months)
    formation_complete = pd.Series(False, index=columns)
    if len(past) == cfg.formation_months:
        formation_complete = past.notna().all(axis=0)
    formation_return = pd.Series(np.nan, index=columns, dtype=float)
    if formation_complete.any():
        formation_return.loc[formation_complete] = (
            (1.0 + past.loc[:, formation_complete]).prod(axis=0) - 1.0
        )
    vol_window = history.tail(max(cfg.risk_lookback_months, cfg.formation_months))
    sigma = vol_window.std(axis=0, ddof=1)
    vol_nobs = vol_window.notna().sum(axis=0)
    vol_eligible = (vol_nobs >= cfg.vol_min_observations) & (sigma > cfg.factor_vol_floor)
    eligible = formation_complete & vol_eligible
    raw_signal = pd.Series(0.0, index=columns)
    raw_signal.loc[eligible] = np.sign(formation_return.loc[eligible]) / sigma.loc[eligible]
    weights = normalize_factor_weights(raw_signal, cfg.factor_weight_gross)
    info = pd.DataFrame(
        {
            "formation_return": formation_return,
            "sigma": sigma,
            "vol_nobs": vol_nobs,
            "raw_signal": raw_signal,
            "formation_complete": formation_complete,
            "vol_eligible": vol_eligible,
            "signal_eligible": eligible & raw_signal.ne(0.0),
            "pre_quality_weight": weights,
        }
    )
    info.index.name = "target_theme"
    return weights, info


# ---------------------------------------------------------------------------
# Point-in-time quality filters and portfolio construction
# ---------------------------------------------------------------------------


def _quality_reason(row: pd.Series) -> str:
    reasons: list[str] = []
    if not bool(row.get("signal_eligible", False)):
        reasons.append("signal_ineligible")
    if row.get("requires_replication_quality", False):
        if not bool(row.get("H_available", False)):
            reasons.append("missing_H")
        if not bool(row.get("solver_allowed", False)):
            reasons.append("solver_not_allowed")
        if not bool(row.get("target_exposure_ok", False)):
            reasons.append("target_exposure_error")
        if not bool(row.get("neutrality_ok", False)):
            reasons.append("neutrality_error")
        if not bool(row.get("condition_number_ok", True)):
            reasons.append("condition_number")
        if not bool(row.get("historical_coverage_ok", False)):
            reasons.append("historical_coverage")
    return "ok" if not reasons else "|".join(reasons)


def eligible_themes_at_date(
    bundle: BasketReplicationBundle,
    signal_date: pd.Timestamp,
    signal_info: pd.DataFrame,
    cfg: StrategyConfig,
    *,
    implementation_mode: str | None = None,
) -> pd.DataFrame:
    signal_date = pd.Timestamp(signal_date)
    implementation_mode = implementation_mode or cfg.implementation_mode
    info = signal_info.copy()
    info.index = info.index.astype(str)
    themes = info.index
    requires_quality = cfg.apply_replication_quality_filter and implementation_mode == "theme_basket_ls"
    info["requires_replication_quality"] = requires_quality

    H = bundle.basket_weights_by_date.get(signal_date)
    info["H_available"] = False if H is None else info.index.isin(H.columns.astype(str))

    diagnostics = bundle.replication_diagnostics
    if not diagnostics.empty and "exposure_date" in diagnostics.columns:
        part = diagnostics[diagnostics["exposure_date"].eq(signal_date)].copy()
        if "target_theme" in part.columns:
            part["target_theme"] = part["target_theme"].astype(str)
            part = part.drop_duplicates("target_theme", keep="last").set_index("target_theme")
        else:
            part = pd.DataFrame(index=themes)
    else:
        part = pd.DataFrame(index=themes)

    for col in [
        "solver_status",
        "target_theme_exposure_error",
        "max_abs_neutralization_exposure",
        "condition_number_kkt",
        "basket_gross",
        "lookthrough_stock_gross",
    ]:
        info[col] = part[col].reindex(themes) if col in part.columns else np.nan

    status = info["solver_status"].fillna("").astype(str)
    allowed = status.isin(cfg.allowed_solver_status)
    if cfg.allow_soft_fallback:
        allowed |= status.str.startswith("soft_solved")
    info["solver_allowed"] = allowed
    info["target_exposure_ok"] = (
        info["target_theme_exposure_error"].abs() <= cfg.max_target_exposure_error
    )
    info["neutrality_ok"] = (
        info["max_abs_neutralization_exposure"] <= cfg.max_neutralization_exposure
    )
    info["condition_number_ok"] = True
    if cfg.max_condition_number is not None:
        info["condition_number_ok"] = (
            info["condition_number_kkt"].fillna(np.inf) <= cfg.max_condition_number
        )

    history = bundle.basket_replicated_theme_returns.loc[:signal_date].tail(cfg.formation_months)
    historical_coverage = history.notna().mean(axis=0).reindex(themes).fillna(0.0)
    info["historical_replication_return_coverage"] = historical_coverage
    info["historical_coverage_ok"] = (
        historical_coverage >= cfg.min_replication_return_coverage
    )

    if requires_quality:
        info["eligible"] = (
            info["signal_eligible"].fillna(False)
            & info["H_available"].fillna(False)
            & info["solver_allowed"].fillna(False)
            & info["target_exposure_ok"].fillna(False)
            & info["neutrality_ok"].fillna(False)
            & info["condition_number_ok"].fillna(False)
            & info["historical_coverage_ok"].fillna(False)
        )
    else:
        info["eligible"] = info["signal_eligible"].fillna(False)
    info["exclusion_reason"] = info.apply(_quality_reason, axis=1)
    return info


def construct_basket_strategy_weights(
    H_t: pd.DataFrame,
    factor_weights: pd.Series,
    P_t: pd.DataFrame | None,
    cfg: StrategyConfig,
    *,
    lookthrough_theme_weights: pd.DataFrame | None = None,
) -> BasketStrategyWeights:
    if H_t.index.has_duplicates or H_t.columns.has_duplicates:
        raise ValueError("H_t contains duplicate labels")
    wF = factor_weights.reindex(H_t.columns).fillna(0.0).astype(float)
    wF = normalize_factor_weights(wF, cfg.factor_weight_gross)
    b_pre = H_t.dot(wF)

    m_pre: pd.Series | None = None
    if lookthrough_theme_weights is not None:
        M = lookthrough_theme_weights.reindex(columns=H_t.columns).fillna(0.0)
        m_pre = M.dot(wF)
    elif P_t is not None:
        P = P_t.reindex(columns=H_t.index).fillna(0.0)
        b_for_p = b_pre.reindex(P.columns).fillna(0.0)
        m_pre = P.dot(b_for_p)

    pre_basket_gross = float(b_pre.abs().sum())
    pre_lookthrough_gross = float(m_pre.abs().sum()) if m_pre is not None else np.nan
    if cfg.strategy_scale_mode == "none":
        scale = 1.0
    elif cfg.strategy_scale_mode == "basket_instrument_gross":
        if pre_basket_gross <= cfg.weight_normalization_tolerance:
            raise ValueError("invalid_scale_denominator:basket_gross")
        scale = cfg.target_basket_instrument_gross / pre_basket_gross
    elif cfg.strategy_scale_mode == "lookthrough_stock_gross":
        if m_pre is None:
            raise ValueError("lookthrough weights are required for lookthrough_stock_gross")
        if pre_lookthrough_gross <= cfg.weight_normalization_tolerance:
            raise ValueError("invalid_scale_denominator:lookthrough_gross")
        scale = cfg.target_lookthrough_stock_gross / pre_lookthrough_gross
    else:
        raise ValueError(f"Unsupported strategy_scale_mode: {cfg.strategy_scale_mode}")

    b = b_pre * scale
    m = m_pre * scale if m_pre is not None else None
    diagnostics = {
        "pre_scale_basket_gross": pre_basket_gross,
        "pre_scale_basket_net": float(b_pre.sum()),
        "post_scale_basket_gross": float(b.abs().sum()),
        "post_scale_basket_net": float(b.sum()),
        "pre_scale_lookthrough_gross": pre_lookthrough_gross,
        "pre_scale_lookthrough_net": float(m_pre.sum()) if m_pre is not None else np.nan,
        "post_scale_lookthrough_gross": float(m.abs().sum()) if m is not None else np.nan,
        "post_scale_lookthrough_net": float(m.sum()) if m is not None else np.nan,
        "scale_factor": float(scale),
        "max_abs_basket_weight": float(b.abs().max()) if len(b) else 0.0,
        "n_long_baskets": int((b > cfg.weight_normalization_tolerance).sum()),
        "n_short_baskets": int((b < -cfg.weight_normalization_tolerance).sum()),
    }
    return BasketStrategyWeights(
        factor_weights=wF,
        scaled_factor_weights=wF * scale,
        basket_weights_pre_scale=b_pre,
        basket_weights=b,
        lookthrough_stock_weights_pre_scale=m_pre,
        lookthrough_stock_weights=m,
        scale=float(scale),
        diagnostics=diagnostics,
    )


def _construct_stock_strategy_weights(
    M_t: pd.DataFrame,
    factor_weights: pd.Series,
    cfg: StrategyConfig,
) -> BasketStrategyWeights:
    wF = normalize_factor_weights(
        factor_weights.reindex(M_t.columns).fillna(0.0), cfg.factor_weight_gross
    )
    m_pre = M_t.dot(wF)
    pre_gross = float(m_pre.abs().sum())
    if cfg.strategy_scale_mode == "none":
        scale = 1.0
    elif cfg.strategy_scale_mode == "lookthrough_stock_gross":
        if pre_gross <= cfg.weight_normalization_tolerance:
            raise ValueError("invalid_scale_denominator:lookthrough_gross")
        scale = cfg.target_lookthrough_stock_gross / pre_gross
    elif cfg.strategy_scale_mode == "basket_instrument_gross":
        raise ValueError("basket_instrument_gross is not defined for stock implementation")
    else:
        raise ValueError(f"Unsupported strategy_scale_mode: {cfg.strategy_scale_mode}")
    m = m_pre * scale
    empty = pd.Series(dtype=float)
    diagnostics = {
        "pre_scale_basket_gross": np.nan,
        "pre_scale_basket_net": np.nan,
        "post_scale_basket_gross": np.nan,
        "post_scale_basket_net": np.nan,
        "pre_scale_lookthrough_gross": pre_gross,
        "pre_scale_lookthrough_net": float(m_pre.sum()),
        "post_scale_lookthrough_gross": float(m.abs().sum()),
        "post_scale_lookthrough_net": float(m.sum()),
        "scale_factor": float(scale),
        "max_abs_basket_weight": np.nan,
        "n_long_baskets": 0,
        "n_short_baskets": 0,
    }
    return BasketStrategyWeights(
        factor_weights=wF,
        scaled_factor_weights=wF * scale,
        basket_weights_pre_scale=empty,
        basket_weights=empty,
        lookthrough_stock_weights_pre_scale=m_pre,
        lookthrough_stock_weights=m,
        scale=float(scale),
        diagnostics=diagnostics,
    )


def one_way_turnover(previous: pd.Series | None, current: pd.Series | None) -> float:
    previous = pd.Series(dtype=float) if previous is None else previous.astype(float)
    current = pd.Series(dtype=float) if current is None else current.astype(float)
    labels = previous.index.union(current.index)
    delta = current.reindex(labels, fill_value=0.0) - previous.reindex(labels, fill_value=0.0)
    return 0.5 * float(delta.abs().sum())


def _weighted_return(
    weights: pd.Series,
    returns: pd.Series,
    cfg: StrategyConfig,
) -> tuple[float, float, list[str]]:
    weights = weights.astype(float)
    returns = returns.reindex(weights.index).astype(float)
    active = weights.abs() > cfg.weight_normalization_tolerance
    gross = float(weights[active].abs().sum())
    if gross <= cfg.weight_normalization_tolerance:
        return 0.0, 1.0, []
    available = returns.notna()
    coverage = float(weights[active & available].abs().sum() / gross)
    missing = list(map(str, returns.index[active & ~available]))
    if cfg.missing_return_policy == "propagate_nan" and missing:
        return np.nan, coverage, missing
    if (
        cfg.missing_return_policy == "coverage_threshold"
        and coverage + 1e-15 < cfg.min_realized_return_coverage
    ):
        return np.nan, coverage, missing
    if cfg.missing_return_policy not in {"propagate_nan", "coverage_threshold"}:
        raise ValueError(f"Unknown missing_return_policy: {cfg.missing_return_policy}")
    # No forward-looking renormalization: missing contribution is zero only after passing coverage.
    return float(weights.dot(returns.fillna(0.0))), coverage, missing


def _get_stock_coefficient_matrix(
    bundle: BasketReplicationBundle,
    data: Mapping[str, Any] | None,
    signal_date: pd.Timestamp,
) -> pd.DataFrame:
    if bundle.stock_coefficient_weights_by_date is not None and signal_date in bundle.stock_coefficient_weights_by_date:
        return bundle.stock_coefficient_weights_by_date[signal_date]
    if data is None:
        raise KeyError(f"No stock coefficient weights for {signal_date.date()}")
    replication_cfg = config_from_dict(bundle.config) if bundle.config else ReplicationConfig()
    M, _ = construct_stock_mimicking_portfolios(
        data,
        replication_cfg,
        signal_date,
        momentum_neutral=replication_cfg.momentum_neutral,
        mode="coefficient",
    )
    if bundle.stock_coefficient_weights_by_date is None:
        bundle.stock_coefficient_weights_by_date = {}
    bundle.stock_coefficient_weights_by_date[signal_date] = M
    return M


def _strategy_exposure_diagnostics(
    bundle: BasketReplicationBundle,
    data: Mapping[str, Any] | None,
    signal_date: pd.Timestamp,
    weights: BasketStrategyWeights,
) -> dict[str, float]:
    if data is None or weights.lookthrough_stock_weights is None:
        return {
            "max_abs_neutralization_exposure": np.nan,
            "max_abs_theme_exposure_error": np.nan,
        }
    from theme_basket_mimicking import snapshot_for_date

    replication_cfg = config_from_dict(bundle.config) if bundle.config else ReplicationConfig()
    try:
        snap = snapshot_for_date(data, signal_date, replication_cfg, replication_cfg.momentum_neutral)
        m = weights.lookthrough_stock_weights.reindex(snap.purified_theme_exposures.index).fillna(0.0)
        neutral = snap.neutralization_exposures.to_numpy().T @ m.to_numpy()
        actual_theme = snap.purified_theme_exposures.to_numpy().T @ m.to_numpy()
        expected = weights.scaled_factor_weights.reindex(
            snap.purified_theme_exposures.columns
        ).fillna(0.0).to_numpy()
        return {
            "max_abs_neutralization_exposure": float(np.max(np.abs(neutral))),
            "max_abs_theme_exposure_error": float(np.max(np.abs(actual_theme - expected))),
        }
    except Exception:
        return {
            "max_abs_neutralization_exposure": np.nan,
            "max_abs_theme_exposure_error": np.nan,
        }


def _post_scale_turnover_decomposition(
    previous_H: pd.DataFrame | None,
    current_H: pd.DataFrame,
    previous_wF: pd.Series | None,
    current_wF: pd.Series,
    previous_scale: float | None,
    current_scale: float,
    previous_basket_weights: pd.Series | None,
    current_basket_weights: pd.Series,
) -> dict[str, float]:
    if previous_H is None or previous_wF is None or previous_scale is None:
        return {
            "signal_change_component_l1_half": 0.0,
            "mapping_change_component_l1_half": 0.0,
            "scale_change_component_l1_half": 0.5 * float(current_basket_weights.abs().sum()),
            "total_change_l1_half": 0.5 * float(current_basket_weights.abs().sum()),
            "decomposition_residual_max_abs": 0.0,
        }
    baskets = previous_H.index.union(current_H.index)
    themes = previous_H.columns.union(current_H.columns).union(current_wF.index).union(previous_wF.index)
    H_prev = previous_H.reindex(index=baskets, columns=themes, fill_value=0.0)
    H_cur = current_H.reindex(index=baskets, columns=themes, fill_value=0.0)
    w_prev = previous_wF.reindex(themes, fill_value=0.0)
    w_cur = current_wF.reindex(themes, fill_value=0.0)
    signal_component = previous_scale * H_prev.dot(w_cur - w_prev)
    mapping_component = previous_scale * (H_cur - H_prev).dot(w_cur)
    scale_component = (current_scale - previous_scale) * H_cur.dot(w_cur)
    actual = current_basket_weights.reindex(baskets, fill_value=0.0) - (
        previous_basket_weights.reindex(baskets, fill_value=0.0)
        if previous_basket_weights is not None
        else 0.0
    )
    residual = actual - signal_component - mapping_component - scale_component
    return {
        "signal_change_component_l1_half": 0.5 * float(signal_component.abs().sum()),
        "mapping_change_component_l1_half": 0.5 * float(mapping_component.abs().sum()),
        "scale_change_component_l1_half": 0.5 * float(scale_component.abs().sum()),
        "total_change_l1_half": 0.5 * float(actual.abs().sum()),
        "decomposition_residual_max_abs": float(residual.abs().max()),
    }


# ---------------------------------------------------------------------------
# Backtest and comparison grid
# ---------------------------------------------------------------------------


def run_basket_factor_strategy_backtest(
    bundle: BasketReplicationBundle,
    data: Mapping[str, Any] | None,
    cfg: StrategyConfig,
    signal_func: SignalFunction,
    strategy_name: str,
    signal_return_source: str | None = None,
    implementation_mode: str | None = None,
    strategy_id: str | None = None,
) -> dict[str, Any]:
    signal_return_source = signal_return_source or cfg.signal_return_source
    implementation_mode = implementation_mode or cfg.implementation_mode
    if signal_return_source == "purified":
        signal_returns = bundle.purified_theme_returns
    elif signal_return_source == "basket_replicated":
        signal_returns = bundle.basket_replicated_theme_returns
    else:
        raise ValueError(f"Unknown signal_return_source: {signal_return_source}")

    dates = list(signal_returns.sort_index().index)
    records: list[dict[str, Any]] = []
    factor_weight_rows: list[pd.Series] = []
    scaled_factor_weight_rows: list[pd.Series] = []
    signal_diag_rows: list[pd.DataFrame] = []
    basket_weight_rows: list[pd.DataFrame] = []
    stock_weight_rows: list[pd.DataFrame] = []
    factor_contribution_rows: list[pd.DataFrame] = []
    basket_contribution_rows: list[pd.DataFrame] = []
    replication_rows: list[dict[str, Any]] = []
    turnover_rows: list[dict[str, Any]] = []

    previous_basket_weights: pd.Series | None = None
    previous_stock_weights: pd.Series | None = None
    previous_H: pd.DataFrame | None = None
    previous_wF: pd.Series | None = None
    previous_scale: float | None = None

    start = max(cfg.min_history_months, cfg.formation_months)
    for i in range(start, len(dates) - 1):
        signal_date = pd.Timestamp(dates[i])
        return_date = pd.Timestamp(dates[i + 1])
        base_record: dict[str, Any] = {
            "return_date": return_date,
            "signal_date": signal_date,
            "strategy_id": strategy_id,
            "strategy_name": strategy_name,
            "signal_return_source": signal_return_source,
            "implementation_mode": implementation_mode,
            "scale_mode": cfg.strategy_scale_mode,
            "execution_model": (
                "lookthrough_stock" if implementation_mode == "stock_coefficient" else cfg.execution_model
            ),
            "status": "unexpected_error",
        }
        try:
            history = signal_returns.loc[:signal_date]
            raw_wF, signal_info = signal_func(history, signal_date, cfg)
            quality = eligible_themes_at_date(
                bundle,
                signal_date,
                signal_info,
                cfg,
                implementation_mode=implementation_mode,
            )
            raw_wF = raw_wF.reindex(quality.index).fillna(0.0)
            filtered_wF = raw_wF.where(quality["eligible"], 0.0)
            wF = normalize_factor_weights(filtered_wF, cfg.factor_weight_gross)
            quality["post_quality_weight"] = wF
            quality.insert(0, "signal_date", signal_date)
            quality.insert(1, "signal_return_source", signal_return_source)
            quality.insert(2, "implementation_mode", implementation_mode)
            signal_diag_rows.append(quality.reset_index())

            if float(wF.abs().sum()) <= cfg.weight_normalization_tolerance:
                base_record["status"] = "no_eligible_themes"
                records.append(base_record)
                continue

            if implementation_mode == "theme_basket_ls":
                H = bundle.basket_weights_by_date.get(signal_date)
                if H is None:
                    base_record["status"] = "missing_H_on_signal_date"
                    records.append(base_record)
                    continue
                M_b = (
                    bundle.lookthrough_weights_by_date.get(signal_date)
                    if bundle.lookthrough_weights_by_date is not None
                    else None
                )
                P = (
                    bundle.basket_constituent_weights_by_date.get(signal_date)
                    if bundle.basket_constituent_weights_by_date is not None
                    else None
                )
                weights = construct_basket_strategy_weights(
                    H,
                    wF,
                    P,
                    cfg,
                    lookthrough_theme_weights=M_b,
                )
                implementation_factor_returns = bundle.basket_replicated_theme_returns.loc[
                    return_date
                ]
                q_next = bundle.raw_basket_returns.loc[return_date]
                factor_pre, factor_coverage, missing_factor = _weighted_return(
                    weights.factor_weights, implementation_factor_returns, cfg
                )
                basket_pre, basket_coverage, missing_baskets = _weighted_return(
                    weights.basket_weights_pre_scale, q_next, cfg
                )
                if weights.lookthrough_stock_weights_pre_scale is not None and data is not None:
                    stock_next = data["stock_returns"].loc[return_date]
                    lookthrough_pre, lookthrough_coverage, missing_stocks = _weighted_return(
                        weights.lookthrough_stock_weights_pre_scale,
                        stock_next,
                        cfg,
                    )
                else:
                    lookthrough_pre = np.nan
                    lookthrough_coverage = np.nan
                    missing_stocks = []
                implementation_pre = basket_pre
            elif implementation_mode == "stock_coefficient":
                M_stock = _get_stock_coefficient_matrix(bundle, data, signal_date)
                weights = _construct_stock_strategy_weights(M_stock, wF, cfg)
                # The stock implementation must use the coefficient-replicated factor return
                # series, not the regression target itself.  This preserves the exact
                # factor-to-stock return identity while leaving the selected signal source
                # (purified or basket-replicated) unchanged.
                implementation_factor_returns = (
                    bundle.stock_coefficient_replicated_theme_returns.loc[return_date]
                )
                factor_pre, factor_coverage, missing_factor = _weighted_return(
                    weights.factor_weights, implementation_factor_returns, cfg
                )
                if data is None:
                    raise ValueError("Stock return data is required for stock implementation")
                stock_next = data["stock_returns"].loc[return_date]
                lookthrough_pre, lookthrough_coverage, missing_stocks = _weighted_return(
                    weights.lookthrough_stock_weights_pre_scale,
                    stock_next,
                    cfg,
                )
                basket_pre = np.nan
                basket_coverage = np.nan
                missing_baskets = []
                implementation_pre = lookthrough_pre
                H = None
            else:
                raise ValueError(f"Unknown implementation_mode: {implementation_mode}")

            if not np.isfinite(implementation_pre) or not np.isfinite(factor_pre):
                base_record.update(
                    {
                        "status": "missing_realized_return",
                        "factor_return_coverage": factor_coverage,
                        "basket_return_coverage": basket_coverage,
                        "lookthrough_return_coverage": lookthrough_coverage,
                        "n_missing_factor_returns": len(missing_factor),
                        "n_missing_basket_returns": len(missing_baskets),
                        "n_missing_stock_returns": len(missing_stocks),
                    }
                )
                records.append(base_record)
                continue

            factor_post = factor_pre * weights.scale
            basket_post = basket_pre * weights.scale if np.isfinite(basket_pre) else np.nan
            lookthrough_post = (
                lookthrough_pre * weights.scale if np.isfinite(lookthrough_pre) else np.nan
            )
            if implementation_mode == "theme_basket_ls":
                identity_factor_basket = abs(factor_post - basket_post)
                identity_basket_lookthrough = (
                    abs(basket_post - lookthrough_post) if np.isfinite(lookthrough_post) else np.nan
                )
                return_identity_error = float(
                    np.nanmax([identity_factor_basket, identity_basket_lookthrough])
                )
            else:
                identity_factor_basket = np.nan
                identity_basket_lookthrough = abs(factor_post - lookthrough_post)
                return_identity_error = float(identity_basket_lookthrough)

            basket_turnover = one_way_turnover(
                previous_basket_weights,
                weights.basket_weights if implementation_mode == "theme_basket_ls" else None,
            )
            lookthrough_turnover = one_way_turnover(
                previous_stock_weights,
                weights.lookthrough_stock_weights,
            )
            if implementation_mode == "stock_coefficient" or cfg.execution_model == "lookthrough_stock":
                cost_turnover = lookthrough_turnover
                cost_bps = cfg.stock_transaction_cost_bps_one_way
            else:
                cost_turnover = basket_turnover
                cost_bps = cfg.basket_transaction_cost_bps_one_way
            transaction_cost = cost_turnover * cost_bps / 10_000.0
            gross_return = implementation_pre * weights.scale
            net_return = gross_return - transaction_cost

            exposure_diag = _strategy_exposure_diagnostics(
                bundle, data, signal_date, weights
            )
            active_quality = quality.loc[wF.abs() > cfg.weight_normalization_tolerance]
            weighted_replication_coverage = float(
                np.nanmin([factor_coverage, basket_coverage, lookthrough_coverage])
            )
            status = (
                "return_identity_failure"
                if return_identity_error > cfg.return_identity_tolerance
                else "ok"
            )
            base_record.update(
                {
                    "factor_path_return_pre_scale": factor_pre,
                    "basket_path_return_pre_scale": basket_pre,
                    "lookthrough_path_return_pre_scale": lookthrough_pre,
                    "factor_path_return": factor_post,
                    "basket_path_return": basket_post,
                    "lookthrough_path_return": lookthrough_post,
                    "gross_return": gross_return,
                    "transaction_cost": transaction_cost,
                    "net_return": net_return,
                    "basket_turnover": basket_turnover,
                    "lookthrough_turnover": lookthrough_turnover,
                    "cost_turnover": cost_turnover,
                    "cost_bps_one_way": cost_bps,
                    **weights.diagnostics,
                    "n_long_factors": int((wF > cfg.weight_normalization_tolerance).sum()),
                    "n_short_factors": int((wF < -cfg.weight_normalization_tolerance).sum()),
                    "factor_weight_gross": float(wF.abs().sum()),
                    "weighted_replication_coverage": weighted_replication_coverage,
                    "factor_return_coverage": factor_coverage,
                    "basket_return_coverage": basket_coverage,
                    "lookthrough_return_coverage": lookthrough_coverage,
                    "max_target_exposure_error": float(
                        active_quality["target_theme_exposure_error"].abs().max()
                    )
                    if "target_theme_exposure_error" in active_quality and len(active_quality)
                    else np.nan,
                    "max_neutralization_exposure_from_theme_diagnostics": float(
                        active_quality["max_abs_neutralization_exposure"].max()
                    )
                    if "max_abs_neutralization_exposure" in active_quality and len(active_quality)
                    else np.nan,
                    **exposure_diag,
                    "factor_basket_identity_error": identity_factor_basket,
                    "basket_lookthrough_identity_error": identity_basket_lookthrough,
                    "return_identity_error": return_identity_error,
                    "status": status,
                }
            )
            records.append(base_record)

            factor_weight_rows.append(wF.rename(signal_date))
            scaled_factor_weight_rows.append(weights.scaled_factor_weights.rename(signal_date))
            if implementation_mode == "theme_basket_ls":
                b_frame = weights.basket_weights.rename("weight").rename_axis("base_basket").reset_index()
                b_frame.insert(0, "signal_date", signal_date)
                basket_weight_rows.append(b_frame)
            if weights.lookthrough_stock_weights is not None and cfg.save_lookthrough_stock_weights:
                s_frame = (
                    weights.lookthrough_stock_weights.rename("weight")
                    .rename_axis("stock_id")
                    .reset_index()
                )
                s_frame.insert(0, "signal_date", signal_date)
                stock_weight_rows.append(s_frame)

            factor_contrib = (
                weights.scaled_factor_weights
                * implementation_factor_returns.reindex(weights.scaled_factor_weights.index)
            ).rename("contribution").rename_axis("target_theme").reset_index()
            factor_contrib.insert(0, "return_date", return_date)
            factor_contrib.insert(1, "signal_date", signal_date)
            factor_contribution_rows.append(factor_contrib)
            if implementation_mode == "theme_basket_ls":
                basket_contrib = (
                    weights.basket_weights * q_next.reindex(weights.basket_weights.index)
                ).rename("contribution").rename_axis("base_basket").reset_index()
                basket_contrib.insert(0, "return_date", return_date)
                basket_contrib.insert(1, "signal_date", signal_date)
                basket_contribution_rows.append(basket_contrib)

            replication_rows.append(
                {
                    "signal_date": signal_date,
                    "return_date": return_date,
                    "strategy_id": strategy_id,
                    "signal_return_source": signal_return_source,
                    "implementation_mode": implementation_mode,
                    "factor_basket_identity_error": identity_factor_basket,
                    "basket_lookthrough_identity_error": identity_basket_lookthrough,
                    "return_identity_error": return_identity_error,
                    **exposure_diag,
                    "status": status,
                }
            )
            if implementation_mode == "theme_basket_ls" and H is not None:
                turnover_decomp = _post_scale_turnover_decomposition(
                    previous_H,
                    H,
                    previous_wF,
                    wF,
                    previous_scale,
                    weights.scale,
                    previous_basket_weights,
                    weights.basket_weights,
                )
                turnover_rows.append(
                    {
                        "signal_date": signal_date,
                        "return_date": return_date,
                        **turnover_decomp,
                    }
                )
                previous_H = H.copy()
                previous_wF = wF.copy()
                previous_scale = weights.scale
                previous_basket_weights = weights.basket_weights.copy()
            previous_stock_weights = (
                weights.lookthrough_stock_weights.copy()
                if weights.lookthrough_stock_weights is not None
                else previous_stock_weights
            )
        except Exception as exc:
            base_record["status"] = f"unexpected_error:{type(exc).__name__}"
            base_record["error_message"] = str(exc)
            records.append(base_record)

    returns = pd.DataFrame(records)
    if not returns.empty:
        returns["return_date"] = pd.to_datetime(returns["return_date"])
        returns["signal_date"] = pd.to_datetime(returns["signal_date"])
        returns = returns.set_index("return_date").sort_index()
    factor_weights = pd.DataFrame(factor_weight_rows).sort_index() if factor_weight_rows else pd.DataFrame()
    scaled_factor_weights = (
        pd.DataFrame(scaled_factor_weight_rows).sort_index()
        if scaled_factor_weight_rows
        else pd.DataFrame()
    )
    signal_diagnostics = (
        pd.concat(signal_diag_rows, ignore_index=True) if signal_diag_rows else pd.DataFrame()
    )
    basket_weights_long = (
        pd.concat(basket_weight_rows, ignore_index=True) if basket_weight_rows else pd.DataFrame()
    )
    stock_weights_long = (
        pd.concat(stock_weight_rows, ignore_index=True) if stock_weight_rows else pd.DataFrame()
    )
    factor_contributions = (
        pd.concat(factor_contribution_rows, ignore_index=True)
        if factor_contribution_rows
        else pd.DataFrame()
    )
    basket_contributions = (
        pd.concat(basket_contribution_rows, ignore_index=True)
        if basket_contribution_rows
        else pd.DataFrame()
    )
    replication_diagnostics = pd.DataFrame(replication_rows)
    turnover_decomposition = pd.DataFrame(turnover_rows)
    metrics = performance_metrics(returns, cfg)
    return {
        "strategy_id": strategy_id,
        "strategy_name": strategy_name,
        "signal_return_source": signal_return_source,
        "implementation_mode": implementation_mode,
        "returns": returns,
        "factor_weights": factor_weights,
        "scaled_factor_weights": scaled_factor_weights,
        "signal_diagnostics": signal_diagnostics,
        "basket_weights_long": basket_weights_long,
        "lookthrough_stock_weights_long": stock_weights_long,
        "factor_contributions": factor_contributions,
        "basket_contributions": basket_contributions,
        "strategy_replication_diagnostics": replication_diagnostics,
        "turnover_decomposition": turnover_decomposition,
        "metrics": metrics,
    }


def performance_metrics(returns: pd.DataFrame, cfg: StrategyConfig) -> pd.DataFrame:
    if returns is None or returns.empty:
        return pd.DataFrame()
    valid_status = returns["status"].eq("ok") if "status" in returns.columns else pd.Series(True, index=returns.index)
    rows: list[dict[str, Any]] = []
    for column in ["gross_return", "net_return"]:
        if column not in returns.columns:
            continue
        r = returns.loc[valid_status, column].dropna()
        if r.empty:
            continue
        annual_mean = float(r.mean() * cfg.annualization)
        annual_vol = float(r.std(ddof=1) * np.sqrt(cfg.annualization))
        cumulative = (1.0 + r).cumprod()
        drawdown = cumulative / cumulative.cummax() - 1.0
        rows.append(
            {
                "series": column,
                "n_months": len(r),
                "ann_mean": annual_mean,
                "ann_vol": annual_vol,
                "sharpe": annual_mean / annual_vol if annual_vol > 0 else np.nan,
                "t_stat_mean": r.mean() / r.std(ddof=1) * np.sqrt(len(r))
                if r.std(ddof=1) > 0
                else np.nan,
                "max_drawdown": float(drawdown.min()),
                "hit_rate": float((r > 0).mean()),
                "skew": float(r.skew()),
                "final_growth_of_one": float(cumulative.iloc[-1]),
                "avg_annual_basket_turnover": float(
                    returns.loc[valid_status, "basket_turnover"].mean() * cfg.annualization
                )
                if "basket_turnover" in returns
                else np.nan,
                "avg_annual_lookthrough_turnover": float(
                    returns.loc[valid_status, "lookthrough_turnover"].mean() * cfg.annualization
                )
                if "lookthrough_turnover" in returns
                else np.nan,
                "avg_monthly_transaction_cost": float(
                    returns.loc[valid_status, "transaction_cost"].mean()
                )
                if "transaction_cost" in returns
                else np.nan,
            }
        )
    return pd.DataFrame(rows).set_index("series") if rows else pd.DataFrame()


def run_strategy_comparison_grid(
    bundle: BasketReplicationBundle,
    data: Mapping[str, Any],
    cfg: StrategyConfig,
    signal_func: SignalFunction,
    strategy_label: str,
) -> dict[str, Any]:
    grid_spec = {
        "A": ("purified", "stock_coefficient"),
        "B": ("purified", "theme_basket_ls"),
        "C": ("basket_replicated", "stock_coefficient"),
        "D": ("basket_replicated", "theme_basket_ls"),
    }
    results: dict[str, dict[str, Any]] = {}
    for key, (source, implementation) in grid_spec.items():
        local_cfg = cfg
        if implementation == "stock_coefficient" and cfg.strategy_scale_mode == "basket_instrument_gross":
            local_cfg = replace(cfg, strategy_scale_mode="lookthrough_stock_gross")
        results[key] = run_basket_factor_strategy_backtest(
            bundle=bundle,
            data=data,
            cfg=local_cfg,
            signal_func=signal_func,
            strategy_name=f"{strategy_label} [{key}]",
            signal_return_source=source,
            implementation_mode=implementation,
            strategy_id=key,
        )

    wide_parts: list[pd.DataFrame] = []
    metric_parts: list[pd.DataFrame] = []
    for key, result in results.items():
        r = result["returns"]
        cols = [c for c in ["gross_return", "net_return", "status"] if c in r.columns]
        if cols:
            part = r[cols].copy()
            part.columns = pd.MultiIndex.from_product([[key], part.columns])
            wide_parts.append(part)
        if not result["metrics"].empty:
            metrics = result["metrics"].reset_index()
            metrics.insert(0, "strategy_id", key)
            metrics.insert(1, "signal_return_source", result["signal_return_source"])
            metrics.insert(2, "implementation_mode", result["implementation_mode"])
            metric_parts.append(metrics)
    wide = pd.concat(wide_parts, axis=1).sort_index() if wide_parts else pd.DataFrame()
    metrics_native = pd.concat(metric_parts, ignore_index=True) if metric_parts else pd.DataFrame()

    ok_dates: pd.Index | None = None
    for result in results.values():
        r = result["returns"]
        dates = r.index[r["status"].eq("ok") & r["net_return"].notna()]
        ok_dates = dates if ok_dates is None else ok_dates.intersection(dates)
    common_dates = pd.Index([]) if ok_dates is None else ok_dates.sort_values()
    common_metric_rows: list[dict[str, Any]] = []
    common_returns = pd.DataFrame(index=common_dates)
    for key, result in results.items():
        r = result["returns"].reindex(common_dates)
        common_returns[f"{key}_gross_return"] = r.get("gross_return")
        common_returns[f"{key}_net_return"] = r.get("net_return")
        temp = r.copy()
        if not temp.empty:
            temp["status"] = "ok"
            metrics = performance_metrics(temp, cfg)
            for series, row in metrics.iterrows():
                common_metric_rows.append(
                    {"strategy_id": key, "series": series, **row.to_dict()}
                )
    common_metrics = pd.DataFrame(common_metric_rows)

    effects = pd.DataFrame(index=common_dates)
    if len(common_dates):
        effects["implementation_effect_on_purified_signal_B_minus_A"] = (
            common_returns["B_gross_return"] - common_returns["A_gross_return"]
        )
        effects["signal_effect_on_stock_impl_C_minus_A"] = (
            common_returns["C_gross_return"] - common_returns["A_gross_return"]
        )
        effects["combined_effect_D_minus_A"] = (
            common_returns["D_gross_return"] - common_returns["A_gross_return"]
        )
        effects["signal_effect_on_basket_impl_D_minus_B"] = (
            common_returns["D_gross_return"] - common_returns["B_gross_return"]
        )
        effects["implementation_effect_on_basket_signal_D_minus_C"] = (
            common_returns["D_gross_return"] - common_returns["C_gross_return"]
        )
    return {
        "results": results,
        "returns_wide": wide,
        "metrics_native": metrics_native,
        "common_dates": common_dates,
        "common_returns": common_returns,
        "common_metrics": common_metrics,
        "effects": effects,
    }


# ---------------------------------------------------------------------------
# Acceptance checks, persistence, and figures
# ---------------------------------------------------------------------------


def run_strategy_validation_checks(
    bundle: BasketReplicationBundle,
    data: Mapping[str, Any],
    cfg: StrategyConfig,
    signal_func: SignalFunction,
    comparison: Mapping[str, Any],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []

    def add(check: str, value: Any, limit: Any, passed: bool) -> None:
        rows.append({"check": check, "value": value, "limit": limit, "passed": bool(passed)})

    # Signal compatibility against the exact legacy formulas.
    rng = np.random.default_rng(123)
    idx = pd.date_range("2018-01-31", periods=48, freq="ME")
    cols = [f"T{i}" for i in range(6)]
    hist = pd.DataFrame(rng.normal(0.001, 0.02, size=(48, 6)), index=idx, columns=cols)
    test_date = idx[-1]
    new_w, _ = signal_func(hist, test_date, cfg)
    past = hist.tail(cfg.formation_months).dropna(axis=1, how="any")
    formation = (1.0 + past).prod(axis=0) - 1.0
    if signal_func is binary_tsfm_12m_signal:
        legacy_raw = np.sign(formation).replace(0.0, np.nan).fillna(0.0)
    else:
        sigma = hist.tail(max(cfg.risk_lookback_months, cfg.formation_months))[past.columns].std(axis=0)
        legacy_raw = np.sign(formation) / sigma.replace(0.0, np.nan)
    legacy_w = normalize_factor_weights(legacy_raw, cfg.factor_weight_gross)
    signal_error = float(
        (new_w.reindex(cols, fill_value=0.0) - legacy_w.reindex(cols, fill_value=0.0)).abs().max()
    )
    add("legacy_signal_compatibility", signal_error, 1e-12, signal_error <= 1e-12)

    # Future changes must not alter a historical signal.
    historical_date = idx[-6]
    original, _ = signal_func(hist.loc[:historical_date], historical_date, cfg)
    changed = hist.copy()
    changed.loc[changed.index > historical_date] = changed.loc[changed.index > historical_date] + 100.0
    after, _ = signal_func(changed, historical_date, cfg)
    no_lookahead_error = float(
        (original.reindex(cols, fill_value=0.0) - after.reindex(cols, fill_value=0.0)).abs().max()
    )
    add("signal_no_lookahead", no_lookahead_error, 0.0, no_lookahead_error == 0.0)

    # Label permutation invariance for H @ wF.
    date = sorted(bundle.basket_weights_by_date)[len(bundle.basket_weights_by_date) // 2]
    H = bundle.basket_weights_by_date[date]
    w = pd.Series(np.arange(1, H.shape[1] + 1, dtype=float), index=H.columns)
    w = normalize_factor_weights(w)
    base = H.dot(w)
    perm_H = H.sample(frac=1.0, axis=0, random_state=7).sample(frac=1.0, axis=1, random_state=8)
    perm_w = w.sample(frac=1.0, random_state=9)
    perm = perm_H.dot(perm_w.reindex(perm_H.columns))
    label_error = float((base.sort_index() - perm.sort_index()).abs().max())
    add("label_permutation_invariance", label_error, 1e-12, label_error <= 1e-12)

    main = comparison["results"]["D"]["returns"]
    ok = main[main["status"].eq("ok")]
    identity_error = float(ok["return_identity_error"].max()) if len(ok) else np.nan
    add(
        "main_strategy_return_identity",
        identity_error,
        cfg.return_identity_tolerance,
        np.isfinite(identity_error) and identity_error <= cfg.return_identity_tolerance,
    )
    if cfg.strategy_scale_mode == "lookthrough_stock_gross" and len(ok):
        gross_error = float(
            (ok["post_scale_lookthrough_gross"] - cfg.target_lookthrough_stock_gross)
            .abs()
            .max()
        )
        add(
            "lookthrough_gross_target",
            gross_error,
            cfg.gross_target_tolerance,
            gross_error <= cfg.gross_target_tolerance,
        )
    elif cfg.strategy_scale_mode == "basket_instrument_gross" and len(ok):
        gross_error = float(
            (ok["post_scale_basket_gross"] - cfg.target_basket_instrument_gross)
            .abs()
            .max()
        )
        add(
            "basket_gross_target",
            gross_error,
            cfg.gross_target_tolerance,
            gross_error <= cfg.gross_target_tolerance,
        )

    first_ok = ok.iloc[0] if len(ok) else None
    if first_ok is not None:
        expected_initial = 0.5 * (
            first_ok["post_scale_basket_gross"]
            if cfg.execution_model == "basket_instrument"
            else first_ok["post_scale_lookthrough_gross"]
        )
        observed_initial = (
            first_ok["basket_turnover"]
            if cfg.execution_model == "basket_instrument"
            else first_ok["lookthrough_turnover"]
        )
        initial_error = abs(observed_initial - expected_initial)
        add("initial_turnover_half_gross", initial_error, 1e-12, initial_error <= 1e-12)
        expected_cost = first_ok["cost_turnover"] * first_ok["cost_bps_one_way"] / 10_000.0
        cost_error = abs(first_ok["transaction_cost"] - expected_cost)
        add("transaction_cost_formula", cost_error, 1e-15, cost_error <= 1e-15)

    add(
        "comparison_grid_contains_A_to_D",
        sorted(comparison["results"].keys()),
        ["A", "B", "C", "D"],
        set(comparison["results"].keys()) == {"A", "B", "C", "D"},
    )
    add(
        "comparison_common_sample_nonempty",
        len(comparison["common_dates"]),
        1,
        len(comparison["common_dates"]) > 0,
    )
    return pd.DataFrame(rows)


def _result_table_long_or_empty(result: Mapping[str, Any], key: str) -> pd.DataFrame:
    table = result.get(key)
    return table if isinstance(table, pd.DataFrame) else pd.DataFrame()


def save_basket_strategy_outputs(
    result: Mapping[str, Any],
    comparison: Mapping[str, Any],
    cfg: StrategyConfig,
    subdir: str,
    *,
    bundle: BasketReplicationBundle,
    validation_checks: pd.DataFrame,
) -> tuple[Path, dict[str, Any]]:
    out = Path(cfg.output_dir) / subdir
    out.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, Any] = {"files": {}}

    returns = result["returns"].copy()
    returns.index.name = "return_date"
    returns.to_csv(out / "strategy_returns.csv")
    manifest["files"]["strategy_returns.csv"] = {"format": "csv"}

    for key, filename in [
        ("factor_weights", "factor_weights.csv"),
        ("scaled_factor_weights", "scaled_factor_weights.csv"),
        ("metrics", "performance_metrics.csv"),
    ]:
        table = _result_table_long_or_empty(result, key)
        if not table.empty:
            temp = table.copy()
            temp.index.name = "signal_date" if "weights" in key else temp.index.name
            temp.to_csv(out / filename)
            manifest["files"][filename] = {"format": "csv"}

    long_tables = [
        ("signal_diagnostics", "signal_diagnostics.parquet"),
        ("basket_weights_long", "strategy_basket_weights_long.parquet"),
        ("factor_contributions", "factor_contributions.parquet"),
        ("basket_contributions", "basket_contributions.parquet"),
        ("strategy_replication_diagnostics", "strategy_replication_diagnostics.parquet"),
        ("turnover_decomposition", "turnover_decomposition.parquet"),
    ]
    if cfg.save_lookthrough_stock_weights:
        long_tables.append(
            ("lookthrough_stock_weights_long", "strategy_lookthrough_stock_weights_long.parquet")
        )
    for key, filename in long_tables:
        table = _result_table_long_or_empty(result, key)
        info = write_table_with_fallback(table, out / filename, index=False)
        manifest["files"][filename] = info

    comparison["metrics_native"].to_csv(out / "comparison_grid_metrics.csv", index=False)
    comparison["common_metrics"].to_csv(out / "comparison_common_sample_metrics.csv", index=False)
    comparison["common_returns"].to_csv(out / "comparison_grid_returns.csv")
    comparison["effects"].to_csv(out / "comparison_effects.csv")
    validation_checks.to_csv(out / "validation_checks.csv", index=False)

    with (out / "config.json").open("w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, indent=2, ensure_ascii=False)
    input_manifest = {
        "strategy_schema_version": STRATEGY_SCHEMA_VERSION,
        "replication_schema_version": bundle.manifest.get("replication_schema_version"),
        "replication_input_fingerprint": bundle.manifest.get("input_fingerprint"),
        "replication_config_hash": bundle.manifest.get("config_hash"),
        "strategy_config_hash": stable_json_hash(asdict(cfg)),
        "signal_return_source": result["signal_return_source"],
        "implementation_mode": result["implementation_mode"],
    }
    with (out / "input_manifest.json").open("w", encoding="utf-8") as f:
        json.dump(input_manifest, f, indent=2, ensure_ascii=False)
    manifest.update(input_manifest)
    with (out / "save_manifest.json").open("w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    return out, manifest


def plot_strategy_result(result: Mapping[str, Any]):
    import matplotlib.pyplot as plt

    returns = result["returns"]
    ok = returns[returns["status"].eq("ok")]
    figures = []
    if not ok.empty:
        fig, ax = plt.subplots(figsize=(10, 4))
        (1.0 + ok[["gross_return", "net_return"]]).cumprod().plot(ax=ax)
        ax.set_title(result["strategy_name"] + ": cumulative return")
        ax.set_ylabel("Growth of 1")
        fig.tight_layout()
        figures.append(fig)

        fig, ax = plt.subplots(figsize=(10, 3))
        ok[["basket_turnover", "lookthrough_turnover"]].plot(ax=ax)
        ax.set_title(result["strategy_name"] + ": one-way turnover")
        fig.tight_layout()
        figures.append(fig)
    return figures


def plot_comparison_grid(comparison: Mapping[str, Any], *, net: bool = True):
    import matplotlib.pyplot as plt

    common = comparison["common_returns"]
    suffix = "net_return" if net else "gross_return"
    columns = [c for c in common.columns if c.endswith(suffix)]
    if not columns:
        return None
    fig, ax = plt.subplots(figsize=(10, 4))
    (1.0 + common[columns]).cumprod().plot(ax=ax)
    ax.set_title("A-D comparison on common sample")
    ax.set_ylabel("Growth of 1")
    fig.tight_layout()
    return fig


def save_strategy_figures(
    out_dir: str | Path,
    result: Mapping[str, Any],
    comparison: Mapping[str, Any],
) -> list[Path]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []
    for i, fig in enumerate(plot_strategy_result(result), start=1):
        path = out / f"strategy_figure_{i:02d}.png"
        fig.savefig(path, dpi=150, bbox_inches="tight")
        saved.append(path)
    fig = plot_comparison_grid(comparison)
    if fig is not None:
        path = out / "comparison_grid_cumulative.png"
        fig.savefig(path, dpi=150, bbox_inches="tight")
        saved.append(path)
    return saved


__all__ = [
    "STRATEGY_SCHEMA_VERSION",
    "StrategyConfig",
    "BasketReplicationBundle",
    "BasketStrategyWeights",
    "load_basket_replication_bundle",
    "prepare_replication_bundle",
    "validate_replication_bundle",
    "binary_tsfm_12m_signal",
    "vol_scaled_tsfm_signal",
    "eligible_themes_at_date",
    "construct_basket_strategy_weights",
    "run_basket_factor_strategy_backtest",
    "run_strategy_comparison_grid",
    "run_strategy_validation_checks",
    "performance_metrics",
    "save_basket_strategy_outputs",
    "plot_strategy_result",
    "plot_comparison_grid",
    "save_strategy_figures",
    "normalize_factor_weights",
    "one_way_turnover",
]
