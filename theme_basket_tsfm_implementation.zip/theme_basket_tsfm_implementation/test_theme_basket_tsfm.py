from __future__ import annotations

from pathlib import Path

import pytest

from theme_basket_mimicking import ReplicationConfig, load_or_generate_inputs
from theme_basket_tsfm import (
    StrategyConfig,
    binary_tsfm_12m_signal,
    prepare_replication_bundle,
    run_strategy_comparison_grid,
    run_strategy_validation_checks,
    vol_scaled_tsfm_signal,
)


@pytest.fixture(scope="module")
def pipeline_fixture(tmp_path_factory):
    root = tmp_path_factory.mktemp("theme_basket_tsfm")
    replication_cfg = ReplicationConfig(
        input_pickle=str(root / "missing.pkl"),
        output_dir=str(root),
        replication_output_subdir="00",
        random_seed=7,
        n_months=60,
        n_stocks=80,
        n_themes=8,
        save_full_basket_weights=True,
        save_lookthrough_stock_weights=True,
        save_stock_coefficient_weights=True,
        save_basket_constituent_weights=True,
    )
    data = load_or_generate_inputs(replication_cfg)
    strategy_cfg = StrategyConfig(
        replication_output_dir=str(root / "00"),
        replication_data_mode="recompute",
        output_dir=str(root),
        min_history_months=24,
        vol_min_observations=24,
        save_lookthrough_stock_weights=True,
    )
    bundle, mode, bundle_validation = prepare_replication_bundle(
        data, replication_cfg, strategy_cfg
    )
    return data, strategy_cfg, bundle, mode, bundle_validation


def test_replication_bundle_contract(pipeline_fixture):
    _, _, bundle, mode, validation = pipeline_fixture
    assert mode == "recompute"
    assert validation["passed"].all()
    assert bundle.stock_coefficient_replicated_theme_returns.columns.equals(
        bundle.purified_theme_returns.columns
    )
    assert bundle.basket_weights_by_date


@pytest.mark.parametrize(
    "label,signal_func",
    [
        ("Binary TSFM 12M", binary_tsfm_12m_signal),
        ("Vol-scaled TSFM", vol_scaled_tsfm_signal),
    ],
)
def test_a_to_d_strategies_and_return_identities(
    pipeline_fixture, label, signal_func
):
    data, strategy_cfg, bundle, _, _ = pipeline_fixture
    comparison = run_strategy_comparison_grid(
        bundle, data, strategy_cfg, signal_func, strategy_label=label
    )
    checks = run_strategy_validation_checks(
        bundle, data, strategy_cfg, signal_func, comparison
    )
    assert checks["passed"].all(), checks.loc[~checks["passed"]].to_dict("records")
    assert set(comparison["results"]) == {"A", "B", "C", "D"}
    assert len(comparison["common_dates"]) > 0
    for result in comparison["results"].values():
        returns = result["returns"]
        assert returns["status"].eq("ok").all(), returns["status"].value_counts().to_dict()
        assert returns["return_identity_error"].max() <= strategy_cfg.return_identity_tolerance
    main = comparison["results"]["D"]["returns"]
    assert (
        main["post_scale_lookthrough_gross"]
        - strategy_cfg.target_lookthrough_stock_gross
    ).abs().max() <= strategy_cfg.gross_target_tolerance
