#!/usr/bin/env python3
"""Run 00 replication and the 01/02 theme-basket TSFM strategies.

The script is the command-line equivalent of the three delivered notebooks.
It is intentionally explicit about the separation between signal return source
and implementation instruments.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from theme_basket_mimicking import ReplicationConfig, load_or_generate_inputs
from theme_basket_tsfm import (
    StrategyConfig,
    binary_tsfm_12m_signal,
    prepare_replication_bundle,
    run_strategy_comparison_grid,
    run_strategy_validation_checks,
    save_basket_strategy_outputs,
    save_strategy_figures,
    vol_scaled_tsfm_signal,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-pickle", default="data/theme_factor_inputs.pkl")
    parser.add_argument("--output-dir", default="theme_factor_momentum_outputs")
    parser.add_argument(
        "--replication-data-mode",
        choices=["auto", "load_00_outputs", "recompute"],
        default="auto",
    )
    parser.add_argument("--signals", choices=["binary", "vol", "both"], default="both")
    parser.add_argument("--no-synthetic-fallback", action="store_true")
    parser.add_argument("--synthetic-months", type=int, default=72)
    parser.add_argument("--synthetic-stocks", type=int, default=100)
    parser.add_argument("--synthetic-themes", type=int, default=10)
    parser.add_argument("--random-seed", type=int, default=42)
    parser.add_argument(
        "--strategy-scale-mode",
        choices=["none", "lookthrough_stock_gross", "basket_instrument_gross"],
        default="lookthrough_stock_gross",
    )
    parser.add_argument(
        "--execution-model",
        choices=["basket_instrument", "lookthrough_stock"],
        default="basket_instrument",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output_root = Path(args.output_dir).resolve()
    replication_cfg = ReplicationConfig(
        input_pickle=args.input_pickle,
        output_dir=str(output_root),
        replication_output_subdir="00_mimicking_portfolio_diagnostics_theme_basket",
        use_synthetic_if_missing=not args.no_synthetic_fallback,
        random_seed=args.random_seed,
        n_months=args.synthetic_months,
        n_stocks=args.synthetic_stocks,
        n_themes=args.synthetic_themes,
        save_full_basket_weights=True,
        save_lookthrough_stock_weights=True,
        save_stock_coefficient_weights=True,
        save_basket_constituent_weights=True,
    )
    strategy_cfg = StrategyConfig(
        replication_output_dir=str(output_root / replication_cfg.replication_output_subdir),
        replication_data_mode=args.replication_data_mode,
        output_dir=str(output_root),
        signal_return_source="basket_replicated",
        implementation_mode="theme_basket_ls",
        strategy_scale_mode=args.strategy_scale_mode,
        execution_model=args.execution_model,
        save_basket_weights=True,
        save_lookthrough_stock_weights=True,
    )

    data = load_or_generate_inputs(replication_cfg)
    bundle, mode_used, bundle_validation = prepare_replication_bundle(
        data, replication_cfg, strategy_cfg
    )
    if not bundle_validation["passed"].all():
        raise RuntimeError("Replication bundle validation failed")

    specs = []
    if args.signals in {"binary", "both"}:
        specs.append(
            (
                "01_binary_tsfm_12m_theme_basket_ls",
                "Binary TSFM 12M",
                binary_tsfm_12m_signal,
            )
        )
    if args.signals in {"vol", "both"}:
        specs.append(
            (
                "02_vol_scaled_tsfm_theme_basket_ls",
                "Vol-scaled TSFM",
                vol_scaled_tsfm_signal,
            )
        )

    summary_rows: list[dict[str, object]] = []
    for subdir, label, signal_func in specs:
        comparison = run_strategy_comparison_grid(
            bundle, data, strategy_cfg, signal_func, strategy_label=label
        )
        main_result = comparison["results"]["D"]
        checks = run_strategy_validation_checks(
            bundle, data, strategy_cfg, signal_func, comparison
        )
        if not checks["passed"].all():
            failed = checks.loc[~checks["passed"], "check"].tolist()
            raise RuntimeError(f"{label} validation failed: {failed}")
        non_ok = {
            key: result["returns"].loc[~result["returns"]["status"].eq("ok"), "status"].tolist()
            for key, result in comparison["results"].items()
            if not result["returns"]["status"].eq("ok").all()
        }
        if non_ok:
            raise RuntimeError(f"{label} has non-ok strategy months: {non_ok}")

        out, manifest = save_basket_strategy_outputs(
            result=main_result,
            comparison=comparison,
            cfg=strategy_cfg,
            subdir=subdir,
            bundle=bundle,
            validation_checks=checks,
        )
        save_strategy_figures(out / "figures", main_result, comparison)
        for series, row in main_result["metrics"].iterrows():
            summary_rows.append(
                {
                    "strategy": label,
                    "series": series,
                    "replication_data_mode": mode_used,
                    "output_dir": str(out),
                    **row.to_dict(),
                }
            )

    summary = pd.DataFrame(summary_rows)
    output_root.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output_root / "theme_basket_tsfm_pipeline_summary.csv", index=False)
    with (output_root / "theme_basket_tsfm_pipeline_run.json").open("w", encoding="utf-8") as f:
        json.dump(
            {
                "replication_data_mode": mode_used,
                "input_pickle": args.input_pickle,
                "output_dir": str(output_root),
                "signals": args.signals,
                "all_bundle_checks_passed": bool(bundle_validation["passed"].all()),
            },
            f,
            indent=2,
            ensure_ascii=False,
        )
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
