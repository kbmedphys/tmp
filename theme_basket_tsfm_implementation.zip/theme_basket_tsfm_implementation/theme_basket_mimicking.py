"""Theme-factor purification and theme-basket long/short replication.

This module is shared by the 00 diagnostics notebook and the TSFM strategy
notebooks.  It intentionally keeps all portfolio joins label based and all
portfolio construction point-in-time.
"""

from __future__ import annotations

import hashlib
import json
import math
import pickle
from dataclasses import asdict, dataclass, fields
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

import numpy as np
import pandas as pd


REPLICATION_SCHEMA_VERSION = "1.1.0"


@dataclass
class ReplicationConfig:
    # Data
    input_pickle: str = "data/theme_factor_inputs.pkl"
    output_dir: str = "theme_factor_momentum_outputs"
    replication_output_subdir: str = "00_mimicking_portfolio_diagnostics_theme_basket"
    use_synthetic_if_missing: bool = True
    random_seed: int = 42
    n_months: int = 120
    n_stocks: int = 160
    n_barra: int = 6
    n_themes: int = 14
    start_date: str = "2010-01-31"

    # Estimation
    ridge: float = 1e-6
    pinv_rcond: float = 1e-10
    include_intercept_in_barra: bool = True
    theme_return_ridge_alpha: float = 1e-6
    min_history_months: int = 24
    risk_lookback_months: int = 36
    momentum_neutral: bool = False
    skip_recent_months_for_stock_mom: int = 1
    stock_mom_lookback_months: int = 11

    # Tradable theme basket input
    theme_basket_weights_key: str = "theme_basket_weights_by_date"
    basket_fallback_to_theme_exposures: bool = True
    normalize_basket_columns_to_one: bool = True
    basket_net_sum_tolerance: float = 1e-8
    allow_negative_basket_constituent_weights: bool = False

    # Basket replication
    basket_replication_mode: str = "constrained_risk_projection"
    basket_risk_metric: str = "specific_diag"  # specific_diag or identity
    basket_ridge_alpha: float = 1e-8
    basket_theme_penalty: float = 0.0
    basket_neutrality_penalty: float = 1e7
    basket_target_penalty: float = 1e7
    basket_constraint_tolerance: float = 1e-6
    basket_solver_tolerance: float = 1e-10
    basket_rank_tolerance: float = 1e-10
    basket_condition_number_warn: float = 1e12
    allow_soft_fallback: bool = True
    active_weight_tolerance: float = 1e-10

    # Return handling
    missing_return_policy: str = "coverage_threshold"  # propagate_nan or coverage_threshold
    min_return_coverage: float = 0.98

    # Persistence and diagnostics
    annualization: int = 12
    rolling_metric_months: int = 36
    save_full_basket_weights: bool = True
    save_lookthrough_stock_weights: bool = True
    save_stock_coefficient_weights: bool = True
    save_basket_constituent_weights: bool = True
    stock_replication_tolerance: float = 1e-7
    basket_identity_tolerance: float = 1e-10


# Backward-compatible name for notebooks that used Config.
Config = ReplicationConfig


@dataclass
class ThemeSnapshot:
    exposure_date: pd.Timestamp
    barra_exposures: pd.DataFrame
    neutralization_exposures: pd.DataFrame
    theme_definition_weights: pd.DataFrame
    purified_theme_exposures: pd.DataFrame
    tradable_basket_weights: pd.DataFrame
    normalization_scale: pd.Series
    diagnostics: dict[str, Any]


@dataclass
class BasketReplicationArtifacts:
    raw_basket_returns: pd.DataFrame
    basket_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    lookthrough_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    stock_coefficient_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    basket_constituent_weights_by_date: dict[pd.Timestamp, pd.DataFrame]
    replication_diagnostics: pd.DataFrame
    basis_diagnostics: pd.DataFrame
    return_coverage: pd.DataFrame

    @property
    def basket_weights_long(self) -> pd.DataFrame:
        return matrix_dict_to_long(
            self.basket_weights_by_date,
            row_name="base_basket",
            column_name="target_theme",
        )

    @property
    def lookthrough_weights_long(self) -> pd.DataFrame:
        return matrix_dict_to_long(
            self.lookthrough_weights_by_date,
            row_name="stock_id",
            column_name="target_theme",
        )

    @property
    def stock_coefficient_weights_long(self) -> pd.DataFrame:
        return matrix_dict_to_long(
            self.stock_coefficient_weights_by_date,
            row_name="stock_id",
            column_name="target_theme",
        )

    @property
    def basket_constituent_weights_long(self) -> pd.DataFrame:
        return matrix_dict_to_long(
            self.basket_constituent_weights_by_date,
            row_name="stock_id",
            column_name="base_basket",
        )


# ---------------------------------------------------------------------------
# Generic utilities
# ---------------------------------------------------------------------------


def _json_default(value: Any) -> Any:
    if isinstance(value, (pd.Timestamp, datetime)):
        return pd.Timestamp(value).isoformat()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        value = float(value)
        return None if not np.isfinite(value) else value
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def stable_json_hash(obj: Any) -> str:
    payload = json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=_json_default,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def config_from_dict(config_dict: Mapping[str, Any]) -> ReplicationConfig:
    allowed = {f.name for f in fields(ReplicationConfig)}
    return ReplicationConfig(**{k: v for k, v in dict(config_dict).items() if k in allowed})


def _as_timestamp_keyed_dict(d: Mapping[Any, pd.DataFrame]) -> dict[pd.Timestamp, pd.DataFrame]:
    return {pd.Timestamp(k): v.copy() for k, v in d.items()}


def _ensure_datetime_index(obj: pd.DataFrame | pd.Series) -> pd.DataFrame | pd.Series:
    out = obj.copy()
    out.index = pd.to_datetime(out.index)
    return out.sort_index()


def _hash_dataframe(hasher: "hashlib._Hash", frame: pd.DataFrame, label: str) -> None:
    hasher.update(label.encode("utf-8"))
    hasher.update("|".join(map(str, frame.index)).encode("utf-8"))
    hasher.update("|".join(map(str, frame.columns)).encode("utf-8"))
    hashed = pd.util.hash_pandas_object(frame, index=True).to_numpy(dtype="uint64")
    hasher.update(hashed.tobytes())


def fingerprint_inputs(data: Mapping[str, Any], cfg: ReplicationConfig | None = None) -> str:
    """Create a deterministic fingerprint of the point-in-time input bundle."""
    h = hashlib.sha256()
    returns = data["stock_returns"].sort_index().sort_index(axis=1)
    _hash_dataframe(h, returns, "stock_returns")
    for key in ["barra_exposures_by_date", "theme_exposures_by_date"]:
        h.update(key.encode("utf-8"))
        for date, frame in sorted(data[key].items(), key=lambda x: pd.Timestamp(x[0])):
            h.update(pd.Timestamp(date).isoformat().encode("utf-8"))
            _hash_dataframe(h, frame.sort_index().sort_index(axis=1), key)
    basket_key = cfg.theme_basket_weights_key if cfg is not None else "theme_basket_weights_by_date"
    if basket_key in data:
        h.update(basket_key.encode("utf-8"))
        for date, frame in sorted(data[basket_key].items(), key=lambda x: pd.Timestamp(x[0])):
            h.update(pd.Timestamp(date).isoformat().encode("utf-8"))
            _hash_dataframe(h, frame.sort_index().sort_index(axis=1), basket_key)
    return h.hexdigest()


def matrix_dict_to_long(
    matrices: Mapping[pd.Timestamp, pd.DataFrame],
    row_name: str,
    column_name: str,
) -> pd.DataFrame:
    rows: list[pd.DataFrame] = []
    for date, frame in sorted(matrices.items()):
        if frame is None or frame.empty:
            continue
        temp = (
            frame.rename_axis(index=row_name, columns=column_name)
            .reset_index()
            .melt(id_vars=[row_name], var_name=column_name, value_name="weight")
        )
        temp.insert(0, "exposure_date", pd.Timestamp(date))
        rows.append(temp)
    if not rows:
        return pd.DataFrame(columns=["exposure_date", row_name, column_name, "weight"])
    return pd.concat(rows, ignore_index=True)


def long_to_matrix_dict(
    table: pd.DataFrame,
    row_name: str,
    column_name: str,
    value_name: str = "weight",
) -> dict[pd.Timestamp, pd.DataFrame]:
    if table is None or table.empty:
        return {}
    required = {"exposure_date", row_name, column_name, value_name}
    missing = required.difference(table.columns)
    if missing:
        raise ValueError(f"Long weight table is missing columns: {sorted(missing)}")
    out: dict[pd.Timestamp, pd.DataFrame] = {}
    temp = table.copy()
    temp["exposure_date"] = pd.to_datetime(temp["exposure_date"])
    for date, part in temp.groupby("exposure_date", sort=True):
        if part.duplicated([row_name, column_name]).any():
            raise ValueError(f"Duplicate ({row_name}, {column_name}) labels on {pd.Timestamp(date).date()}")
        frame = part.pivot(index=row_name, columns=column_name, values=value_name).sort_index().sort_index(axis=1)
        out[pd.Timestamp(date)] = frame.astype(float)
    return out


def write_table_with_fallback(
    table: pd.DataFrame,
    preferred_path: str | Path,
    *,
    index: bool = False,
) -> dict[str, Any]:
    """Write Parquet when available; otherwise write a same-stem CSV."""
    path = Path(preferred_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix.lower() == ".parquet":
        try:
            table.to_parquet(path, index=index)
            return {"requested": path.name, "actual": path.name, "format": "parquet"}
        except (ImportError, ModuleNotFoundError, ValueError):
            csv_path = path.with_suffix(".csv")
            table.to_csv(csv_path, index=index)
            return {"requested": path.name, "actual": csv_path.name, "format": "csv_fallback"}
    table.to_csv(path, index=index)
    return {"requested": path.name, "actual": path.name, "format": "csv"}


def read_table_with_fallback(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    candidates = [path]
    if path.suffix.lower() == ".parquet":
        candidates.append(path.with_suffix(".csv"))
    for candidate in candidates:
        if not candidate.exists():
            continue
        if candidate.suffix.lower() == ".parquet":
            return pd.read_parquet(candidate)
        return pd.read_csv(candidate)
    raise FileNotFoundError(f"Neither {path} nor its CSV fallback exists")


# ---------------------------------------------------------------------------
# Input generation and purification
# ---------------------------------------------------------------------------


def add_barra_intercept(B: pd.DataFrame, cfg: ReplicationConfig) -> pd.DataFrame:
    B = B.copy().astype(float)
    if cfg.include_intercept_in_barra:
        if "INTERCEPT" in B.columns:
            raise ValueError("Input Barra exposure already contains INTERCEPT")
        B.insert(0, "INTERCEPT", 1.0)
    return B


def residualize_df(A: pd.DataFrame, X: pd.DataFrame, ridge: float = 1e-8) -> pd.DataFrame:
    A = A.astype(float)
    X = X.astype(float)
    common = A.index.intersection(X.index)
    A = A.loc[common]
    X = X.loc[common]
    av = A.to_numpy()
    xv = X.to_numpy()
    gram = av.T @ av + ridge * np.eye(av.shape[1])
    beta = np.linalg.pinv(gram) @ av.T @ xv
    resid = xv - av @ beta
    return pd.DataFrame(resid, index=common, columns=X.columns)


def normalize_l2_with_scale(X: pd.DataFrame, eps: float = 1e-12) -> tuple[pd.DataFrame, pd.Series]:
    X = X.copy().astype(float)
    norm = np.sqrt((X**2).sum(axis=0))
    keep = norm[norm > eps].index
    return X[keep].divide(norm[keep], axis=1), norm[keep].rename("l2_scale")


def normalize_l2(X: pd.DataFrame, eps: float = 1e-12) -> pd.DataFrame:
    return normalize_l2_with_scale(X, eps=eps)[0]


def prior_stock_momentum(stock_returns: pd.DataFrame, date: Any, cfg: ReplicationConfig) -> pd.Series:
    date = pd.Timestamp(date)
    idx = stock_returns.index.get_loc(date)
    end = idx - cfg.skip_recent_months_for_stock_mom
    start = end - cfg.stock_mom_lookback_months
    if start < 0 or end <= start:
        return pd.Series(np.nan, index=stock_returns.columns, name="PRIOR_STOCK_MOM")
    window = stock_returns.iloc[start:end]
    return ((1.0 + window).prod(axis=0) - 1.0).rename("PRIOR_STOCK_MOM")


def generate_synthetic_inputs(cfg: ReplicationConfig) -> dict[str, Any]:
    """Generate deterministic monthly data, including explicit tradable baskets."""
    rng = np.random.default_rng(cfg.random_seed)
    dates = pd.date_range(cfg.start_date, periods=cfg.n_months, freq="ME")
    stocks = [f"S{i:04d}" for i in range(1, cfg.n_stocks + 1)]
    barra_cols = ["BETA", "SIZE", "VALUE", "PROFIT", "INVEST", "VOL"][: cfg.n_barra]
    themes = [f"Theme_{i:02d}" for i in range(1, cfg.n_themes + 1)]

    base_X = np.zeros((cfg.n_stocks, cfg.n_themes))
    for k in range(cfg.n_themes):
        low = max(12, cfg.n_stocks // 12)
        high = max(low + 1, max(16, cfg.n_stocks // 4))
        basket_size = int(rng.integers(low, high))
        selected = rng.choice(cfg.n_stocks, size=basket_size, replace=False)
        weights = rng.lognormal(mean=0.0, sigma=0.7, size=basket_size)
        base_X[selected, k] = weights / weights.sum()

    barra_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    theme_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    basket_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    B_prev = rng.normal(size=(cfg.n_stocks, cfg.n_barra))
    f_prev = np.zeros(cfg.n_barra)
    g_prev = np.zeros(cfg.n_themes)
    returns: list[np.ndarray] = []

    for date in dates:
        B_now = 0.97 * B_prev + 0.03 * rng.normal(size=(cfg.n_stocks, cfg.n_barra))
        B_now = (B_now - B_now.mean(axis=0)) / B_now.std(axis=0)
        B_df = pd.DataFrame(B_now, index=stocks, columns=barra_cols)
        barra_by_date[pd.Timestamp(date)] = B_df

        X_now = base_X * rng.lognormal(mean=0.0, sigma=0.02, size=base_X.shape)
        X_now = X_now / np.maximum(X_now.sum(axis=0, keepdims=True), 1e-12)
        X_df = pd.DataFrame(X_now, index=stocks, columns=themes)
        theme_by_date[pd.Timestamp(date)] = X_df

        # Synthetic tradable baskets use the same membership with a distinct object.
        # Production data may provide a different basket matrix via the configured key.
        basket_by_date[pd.Timestamp(date)] = X_df.copy()

        B_aug = add_barra_intercept(B_df, cfg)
        Z = normalize_l2(residualize_df(B_aug, X_df, cfg.ridge))
        f_now = 0.15 * f_prev + rng.normal(0.0, 0.012, size=cfg.n_barra)
        g_now = 0.35 * g_prev + rng.normal(0.0015, 0.015, size=cfg.n_themes)
        eps = rng.normal(0.0, 0.035, size=cfg.n_stocks)
        r = B_df.to_numpy() @ f_now + Z.to_numpy() @ g_now + eps
        returns.append(r)
        B_prev, f_prev, g_prev = B_now, f_now, g_now

    stock_returns = pd.DataFrame(returns, index=dates, columns=stocks)
    cash_returns = pd.Series(0.0, index=dates, name="cash_return")
    return {
        "stock_returns": stock_returns,
        "barra_exposures_by_date": barra_by_date,
        "theme_exposures_by_date": theme_by_date,
        cfg.theme_basket_weights_key: basket_by_date,
        "cash_returns": cash_returns,
        "metadata": {
            "source": "synthetic",
            "random_seed": cfg.random_seed,
            "note": "Replace with point-in-time production input pickle.",
        },
    }


def load_or_generate_inputs(cfg: ReplicationConfig) -> dict[str, Any]:
    path = Path(cfg.input_pickle)
    if path.exists():
        with path.open("rb") as f:
            data = pickle.load(f)
        if not isinstance(data, dict):
            raise TypeError("Input pickle must contain a dict")
        required = {"stock_returns", "barra_exposures_by_date", "theme_exposures_by_date"}
        missing = required.difference(data)
        if missing:
            raise KeyError(f"Input pickle is missing keys: {sorted(missing)}")
        data["stock_returns"] = _ensure_datetime_index(data["stock_returns"])
        data["barra_exposures_by_date"] = _as_timestamp_keyed_dict(data["barra_exposures_by_date"])
        data["theme_exposures_by_date"] = _as_timestamp_keyed_dict(data["theme_exposures_by_date"])
        if cfg.theme_basket_weights_key in data:
            data[cfg.theme_basket_weights_key] = _as_timestamp_keyed_dict(data[cfg.theme_basket_weights_key])
        elif cfg.basket_fallback_to_theme_exposures:
            data[cfg.theme_basket_weights_key] = {
                d: x.copy() for d, x in data["theme_exposures_by_date"].items()
            }
            data.setdefault("metadata", {})["basket_weights_source"] = "theme_exposures_fallback"
        else:
            raise KeyError(
                f"Input is missing {cfg.theme_basket_weights_key!r} and fallback is disabled"
            )
        data.setdefault("metadata", {})["source"] = str(path)
        return data
    if not cfg.use_synthetic_if_missing:
        raise FileNotFoundError(f"Input pickle not found: {path}")
    return generate_synthetic_inputs(cfg)


def prepare_theme_basket_weights(
    data: Mapping[str, Any],
    date: Any,
    stock_index: pd.Index,
    cfg: ReplicationConfig,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    date = pd.Timestamp(date)
    key = cfg.theme_basket_weights_key
    source = "explicit"
    if key in data and date in data[key]:
        P = data[key][date].copy()
    elif cfg.basket_fallback_to_theme_exposures and date in data["theme_exposures_by_date"]:
        P = data["theme_exposures_by_date"][date].copy()
        source = "theme_exposures_fallback"
    else:
        raise KeyError(f"No tradable theme basket matrix for {date.date()}")

    if P.index.has_duplicates or P.columns.has_duplicates:
        raise ValueError(f"Duplicate stock or basket labels on {date.date()}")
    P = P.reindex(stock_index).astype(float)
    if not np.isfinite(P.fillna(0.0).to_numpy()).all():
        raise ValueError(f"Non-finite basket constituent weight on {date.date()}")
    P = P.fillna(0.0)
    if not cfg.allow_negative_basket_constituent_weights and (P < -cfg.basket_net_sum_tolerance).any().any():
        raise ValueError(f"Negative constituent weights found in a long-only tradable basket on {date.date()}")
    gross = P.abs().sum(axis=0)
    nonzero = gross[gross > cfg.basket_solver_tolerance].index
    P = P[nonzero]
    if P.empty:
        raise ValueError(f"All tradable baskets are empty on {date.date()}")
    net_before = P.sum(axis=0)
    if cfg.normalize_basket_columns_to_one:
        invalid = net_before.abs() <= cfg.basket_solver_tolerance
        if invalid.any():
            raise ValueError(f"Zero-net basket cannot be normalized on {date.date()}: {list(net_before[invalid].index)}")
        P = P.divide(net_before, axis=1)
    net_after = P.sum(axis=0)
    diag = {
        "source": source,
        "n_baskets": int(P.shape[1]),
        "min_net_before": float(net_before.min()),
        "max_net_before": float(net_before.max()),
        "max_abs_net_error_after": float((net_after - 1.0).abs().max()),
        "min_basket_gross_after": float(P.abs().sum(axis=0).min()),
        "max_basket_gross_after": float(P.abs().sum(axis=0).max()),
    }
    return P, diag


def snapshot_for_date(
    data: Mapping[str, Any],
    date: Any,
    cfg: ReplicationConfig,
    momentum_neutral: bool | None = None,
) -> ThemeSnapshot:
    date = pd.Timestamp(date)
    momentum_neutral = cfg.momentum_neutral if momentum_neutral is None else momentum_neutral
    stock_returns = data["stock_returns"]
    if date not in data["barra_exposures_by_date"] or date not in data["theme_exposures_by_date"]:
        raise KeyError(f"Missing exposure snapshot on {date.date()}")
    B = data["barra_exposures_by_date"][date].copy()
    X = data["theme_exposures_by_date"][date].copy()
    if B.index.has_duplicates or B.columns.has_duplicates or X.index.has_duplicates or X.columns.has_duplicates:
        raise ValueError(f"Duplicate labels in exposure matrices on {date.date()}")

    common = stock_returns.columns.intersection(B.index).intersection(X.index)
    B = B.loc[common].dropna(axis=0, how="any").astype(float)
    X = X.reindex(B.index).fillna(0.0).astype(float)
    B_aug = add_barra_intercept(B, cfg)
    A = B_aug.copy()

    if momentum_neutral:
        p = prior_stock_momentum(stock_returns, date, cfg).reindex(A.index)
        A = pd.concat([A, p], axis=1).dropna(axis=0, how="any")
        if len(A) < A.shape[1] + X.shape[1] + 5:
            raise ValueError(
                f"Insufficient stocks with prior momentum on {date.date()} for momentum-neutral purification"
            )
        B_aug = B_aug.loc[A.index]
        X = X.loc[A.index]

    Z_raw = residualize_df(A, X, cfg.ridge)
    Z, scale = normalize_l2_with_scale(Z_raw)
    if Z.empty:
        raise ValueError(f"No nonzero purified themes on {date.date()}")
    X = X.loc[Z.index, Z.columns]
    A = A.loc[Z.index]
    B_aug = B_aug.loc[Z.index]
    P, basket_diag = prepare_theme_basket_weights(data, date, Z.index, cfg)

    diag = {
        "n_stocks": int(len(Z.index)),
        "n_barra_columns": int(B_aug.shape[1]),
        "n_neutralization_columns": int(A.shape[1]),
        "n_target_themes": int(Z.shape[1]),
        "n_base_baskets": int(P.shape[1]),
        "max_abs_A_transpose_Z": float(np.abs(A.to_numpy().T @ Z.to_numpy()).max()),
        **{f"basket_{k}": v for k, v in basket_diag.items()},
    }
    return ThemeSnapshot(
        exposure_date=date,
        barra_exposures=B_aug,
        neutralization_exposures=A,
        theme_definition_weights=X,
        purified_theme_exposures=Z,
        tradable_basket_weights=P,
        normalization_scale=scale,
        diagnostics=diag,
    )


def _return_vector_with_policy(
    returns: pd.Series,
    absolute_weights: pd.Series,
    cfg: ReplicationConfig,
) -> tuple[pd.Series, float, list[str]]:
    returns = returns.astype(float)
    absolute_weights = absolute_weights.reindex(returns.index).fillna(0.0).abs()
    active = absolute_weights > cfg.active_weight_tolerance
    denominator = float(absolute_weights[active].sum())
    if denominator <= 0:
        return returns.fillna(0.0), 1.0, []
    available = returns.notna()
    coverage = float(absolute_weights[active & available].sum() / denominator)
    missing_labels = list(map(str, returns.index[active & ~available]))
    if cfg.missing_return_policy == "propagate_nan" and missing_labels:
        return returns, coverage, missing_labels
    if cfg.missing_return_policy == "coverage_threshold" and coverage + 1e-15 < cfg.min_return_coverage:
        return returns, coverage, missing_labels
    if cfg.missing_return_policy not in {"propagate_nan", "coverage_threshold"}:
        raise ValueError(f"Unknown missing_return_policy: {cfg.missing_return_policy}")
    # Missing contribution is treated as zero only after explicitly passing coverage.
    return returns.fillna(0.0), coverage, missing_labels


def estimate_theme_returns(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    momentum_neutral: bool | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    stock_returns = data["stock_returns"]
    dates = list(stock_returns.index)
    rows: list[pd.Series] = []
    diag_rows: list[dict[str, Any]] = []
    for i in range(1, len(dates)):
        exposure_date, return_date = dates[i - 1], dates[i]
        try:
            snap = snapshot_for_date(data, exposure_date, cfg, momentum_neutral)
            r_raw = stock_returns.loc[return_date].reindex(snap.purified_theme_exposures.index)
            equal_abs = pd.Series(1.0, index=r_raw.index)
            r, coverage, missing_labels = _return_vector_with_policy(r_raw, equal_abs, cfg)
            if r.isna().any():
                raise ValueError(
                    f"Stock return coverage {coverage:.4f} below threshold; missing {len(missing_labels)} active stocks"
                )
            A = snap.neutralization_exposures.to_numpy()
            y = r.to_numpy()
            beta_neutral = np.linalg.pinv(
                A.T @ A + cfg.ridge * np.eye(A.shape[1]),
                rcond=cfg.pinv_rcond,
            ) @ A.T @ y
            u = y - A @ beta_neutral
            Z = snap.purified_theme_exposures.to_numpy()
            g = np.linalg.pinv(
                Z.T @ Z + cfg.theme_return_ridge_alpha * np.eye(Z.shape[1]),
                rcond=cfg.pinv_rcond,
            ) @ Z.T @ u
            rows.append(pd.Series(g, index=snap.purified_theme_exposures.columns, name=return_date))
            sst = float(np.sum((y - y.mean()) ** 2))
            fit_neutral = A @ beta_neutral
            fit_full = fit_neutral + Z @ g
            r2_neutral = np.nan if sst <= 0 else 1.0 - float(np.sum((y - fit_neutral) ** 2)) / sst
            r2_full = np.nan if sst <= 0 else 1.0 - float(np.sum((y - fit_full) ** 2)) / sst
            diag_rows.append(
                {
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "n_stocks": len(snap.purified_theme_exposures.index),
                    "n_themes": len(snap.purified_theme_exposures.columns),
                    "stock_return_coverage": coverage,
                    "n_missing_stock_returns": len(missing_labels),
                    "r2_neutralization": r2_neutral,
                    "r2_neutralization_plus_theme": r2_full,
                    "status": "ok",
                }
            )
        except Exception as exc:  # diagnostic output is required; no silent continue
            diag_rows.append(
                {
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "status": f"skipped:{type(exc).__name__}:{exc}",
                }
            )
    theme_returns = pd.DataFrame(rows).sort_index()
    diag = pd.DataFrame(diag_rows)
    if not diag.empty:
        diag["return_date"] = pd.to_datetime(diag["return_date"])
        diag["exposure_date"] = pd.to_datetime(diag["exposure_date"])
        diag = diag.sort_values("return_date").reset_index(drop=True)
    return theme_returns, diag


# ---------------------------------------------------------------------------
# Stock and basket mimicking portfolios
# ---------------------------------------------------------------------------


def specific_risk_diag(
    data: Mapping[str, Any],
    date: Any,
    stocks: Iterable[Any],
    cfg: ReplicationConfig,
) -> pd.Series:
    stock_returns = data["stock_returns"]
    date = pd.Timestamp(date)
    idx = stock_returns.index.get_loc(date)
    hist = stock_returns.iloc[max(0, idx - cfg.risk_lookback_months) : idx].reindex(columns=list(stocks))
    variance = hist.var(axis=0, ddof=1)
    fallback = float(variance.dropna().median()) if variance.notna().any() else float(stock_returns.var().median())
    if not np.isfinite(fallback) or fallback <= 0:
        fallback = 1e-4
    return variance.fillna(fallback).clip(lower=1e-8)


def construct_stock_mimicking_portfolios(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    date: Any,
    momentum_neutral: bool | None = None,
    mode: str = "coefficient",
) -> tuple[pd.DataFrame, dict[str, Any]]:
    snap = snapshot_for_date(data, date, cfg, momentum_neutral)
    Z = snap.purified_theme_exposures
    A = snap.neutralization_exposures
    Zv = Z.to_numpy()

    if mode == "coefficient":
        gram = Zv.T @ Zv + cfg.theme_return_ridge_alpha * np.eye(Zv.shape[1])
        Mv = Zv @ np.linalg.pinv(gram, rcond=cfg.pinv_rcond)
        target = None
    elif mode == "min_risk":
        constraints = pd.concat([A, Z], axis=1)
        q = specific_risk_diag(data, date, constraints.index, cfg)
        Qinv = np.diag(1.0 / q.reindex(constraints.index).to_numpy())
        Cv = constraints.to_numpy()
        target_matrix = np.zeros((Cv.shape[1], Z.shape[1]))
        target_matrix[-Z.shape[1] :, :] = np.eye(Z.shape[1])
        middle = np.linalg.pinv(
            Cv.T @ Qinv @ Cv + cfg.ridge * np.eye(Cv.shape[1]),
            rcond=cfg.pinv_rcond,
        )
        Mv = Qinv @ Cv @ middle @ target_matrix
        target = pd.DataFrame(target_matrix, index=constraints.columns, columns=Z.columns)
    else:
        raise ValueError("mode must be 'coefficient' or 'min_risk'")

    M = pd.DataFrame(Mv, index=Z.index, columns=Z.columns)
    neutral_exp = pd.DataFrame(A.to_numpy().T @ M.to_numpy(), index=A.columns, columns=M.columns)
    theme_exp = pd.DataFrame(Z.to_numpy().T @ M.to_numpy(), index=Z.columns, columns=M.columns)
    diagnostics = {
        "target": target,
        "neutralization_exposure": neutral_exp,
        "barra_exposure": pd.DataFrame(
            snap.barra_exposures.to_numpy().T @ M.to_numpy(),
            index=snap.barra_exposures.columns,
            columns=M.columns,
        ),
        "theme_exposure": theme_exp,
        "portfolio_summary": pd.concat(
            [
                M.abs().sum(axis=0).rename("gross"),
                M.sum(axis=0).rename("net"),
                M.max(axis=0).rename("max_weight"),
                M.min(axis=0).rename("min_weight"),
            ],
            axis=1,
        ),
        "snapshot": snap,
    }
    return M, diagnostics


# Backward-compatible wrapper.
def construct_mimicking_portfolios(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    date: Any,
    momentum_neutral: bool = False,
    mode: str | None = None,
):
    return construct_stock_mimicking_portfolios(
        data,
        cfg,
        date,
        momentum_neutral=momentum_neutral,
        mode=mode or "coefficient",
    )


def stock_replicated_theme_returns(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool | None = None,
    mode: str = "coefficient",
    return_diagnostics: bool = False,
) -> pd.DataFrame | tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[pd.Series] = []
    diagnostics: list[dict[str, Any]] = []
    stock_dates = data["stock_returns"].index
    for return_date in theme_returns.index:
        if return_date not in stock_dates:
            diagnostics.append({"return_date": return_date, "status": "missing_return_date"})
            continue
        pos = stock_dates.get_loc(return_date)
        if pos == 0:
            continue
        exposure_date = stock_dates[pos - 1]
        try:
            M, diag = construct_stock_mimicking_portfolios(
                data, cfg, exposure_date, momentum_neutral=momentum_neutral, mode=mode
            )
            r_raw = data["stock_returns"].loc[return_date].reindex(M.index)
            abs_weight = M.abs().sum(axis=1)
            r, coverage, missing = _return_vector_with_policy(r_raw, abs_weight, cfg)
            if r.isna().any():
                raise ValueError(f"Return coverage {coverage:.4f} below threshold")
            replicated = M.T @ r
            rows.append(pd.Series(replicated, index=M.columns, name=return_date))
            diagnostics.append(
                {
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "mode": mode,
                    "coverage": coverage,
                    "n_missing_returns": len(missing),
                    "max_abs_neutralization_exposure": float(diag["neutralization_exposure"].abs().max().max()),
                    "max_abs_theme_exposure_error": float(
                        (diag["theme_exposure"] - np.eye(diag["theme_exposure"].shape[0])).abs().max().max()
                    ),
                    "status": "ok",
                }
            )
        except Exception as exc:
            diagnostics.append(
                {
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "mode": mode,
                    "status": f"skipped:{type(exc).__name__}:{exc}",
                }
            )
    out = pd.DataFrame(rows).sort_index()
    diag_df = pd.DataFrame(diagnostics)
    return (out, diag_df) if return_diagnostics else out


def coefficient_replicated_theme_returns(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool = False,
) -> pd.DataFrame:
    return stock_replicated_theme_returns(
        data,
        cfg,
        theme_returns,
        momentum_neutral=momentum_neutral,
        mode="coefficient",
        return_diagnostics=False,
    )


def _svd_rank_and_nullspace(A: np.ndarray, tolerance: float) -> tuple[int, np.ndarray, np.ndarray]:
    if A.size == 0:
        return 0, np.eye(A.shape[1]), np.array([], dtype=float)
    _, singular_values, vh = np.linalg.svd(A, full_matrices=True)
    scale = singular_values[0] if singular_values.size else 1.0
    threshold = tolerance * max(A.shape) * max(scale, 1.0)
    rank = int(np.sum(singular_values > threshold))
    null = vh[rank:].T.copy()
    return rank, null, singular_values


def _safe_condition_number(matrix: np.ndarray) -> float:
    if matrix.size == 0:
        return np.nan
    try:
        value = float(np.linalg.cond(matrix))
        return value if np.isfinite(value) else np.inf
    except np.linalg.LinAlgError:
        return np.inf


def _solve_hard_basket_projection(
    G: np.ndarray,
    c: np.ndarray,
    neutral_constraints: np.ndarray,
    target_vector: np.ndarray,
    cfg: ReplicationConfig,
) -> tuple[np.ndarray | None, dict[str, Any]]:
    rank_neutral, nullspace, neutral_s = _svd_rank_and_nullspace(
        neutral_constraints, cfg.basket_rank_tolerance
    )
    info: dict[str, Any] = {
        "rank_neutral_constraints": rank_neutral,
        "neutral_nullspace_dimension": int(nullspace.shape[1]),
        "neutral_constraint_singular_min": float(neutral_s[-1]) if neutral_s.size else np.nan,
    }
    if nullspace.shape[1] == 0:
        info["failure_reason"] = "neutral_nullspace_empty"
        return None, info
    a = target_vector @ nullspace
    if float(np.linalg.norm(a)) <= cfg.basket_solver_tolerance:
        info["failure_reason"] = "target_not_spanned_in_neutral_nullspace"
        return None, info
    Gn = nullspace.T @ G @ nullspace
    cn = nullspace.T @ c
    kkt = np.block(
        [
            [Gn, a.reshape(-1, 1)],
            [a.reshape(1, -1), np.zeros((1, 1))],
        ]
    )
    rhs = np.concatenate([cn, np.array([1.0])])
    condition = _safe_condition_number(kkt)
    info["condition_number_kkt"] = condition
    try:
        if condition <= cfg.basket_condition_number_warn:
            solution = np.linalg.solve(kkt, rhs)
            status = "hard_solved"
        else:
            solution = np.linalg.pinv(kkt, rcond=cfg.pinv_rcond) @ rhs
            status = "hard_solved_pinv"
    except np.linalg.LinAlgError:
        solution = np.linalg.pinv(kkt, rcond=cfg.pinv_rcond) @ rhs
        status = "hard_solved_pinv"
    y = solution[:-1]
    h = nullspace @ y
    info["solver_status"] = status
    return h, info


def _solve_soft_basket_projection(
    G: np.ndarray,
    c: np.ndarray,
    neutral_constraints: np.ndarray,
    target_vector: np.ndarray,
    theme_mapping: np.ndarray,
    target_index: int,
    cfg: ReplicationConfig,
) -> tuple[np.ndarray, dict[str, Any]]:
    Gs = G.copy()
    cs = c.copy()
    if neutral_constraints.size:
        Gs += cfg.basket_neutrality_penalty * (neutral_constraints.T @ neutral_constraints)
    Gs += cfg.basket_target_penalty * np.outer(target_vector, target_vector)
    cs += cfg.basket_target_penalty * target_vector
    if cfg.basket_theme_penalty > 0:
        target_theme = np.zeros(theme_mapping.shape[0])
        target_theme[target_index] = 1.0
        Gs += cfg.basket_theme_penalty * (theme_mapping.T @ theme_mapping)
        cs += cfg.basket_theme_penalty * (theme_mapping.T @ target_theme)
    condition = _safe_condition_number(Gs)
    if condition <= cfg.basket_condition_number_warn:
        try:
            h = np.linalg.solve(Gs, cs)
            status = "soft_solved"
        except np.linalg.LinAlgError:
            h = np.linalg.pinv(Gs, rcond=cfg.pinv_rcond) @ cs
            status = "soft_solved_pinv"
    else:
        h = np.linalg.pinv(Gs, rcond=cfg.pinv_rcond) @ cs
        status = "soft_solved_pinv"
    return h, {"solver_status": status, "condition_number_kkt": condition}


def construct_basket_mimicking_portfolios(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    date: Any,
    profile: str = "raw",
    previous_basket_weights: pd.DataFrame | None = None,
    momentum_neutral: bool | None = None,
    stock_target_mode: str = "coefficient",
    basket_mode: str | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Replicate each purified theme using long/short positions in base baskets.

    The raw profile uses a hard neutralization constraint and unit target-theme
    exposure whenever feasible.  If the basket basis cannot satisfy those
    constraints, an explicitly labelled soft-penalty fallback is used when
    allowed by configuration.
    """
    basket_mode = basket_mode or cfg.basket_replication_mode
    if basket_mode != "constrained_risk_projection":
        raise ValueError(f"Unsupported basket replication mode: {basket_mode}")
    if profile not in {"raw", "implementable"}:
        raise ValueError("profile must be 'raw' or 'implementable'")

    M_stock, stock_diag = construct_stock_mimicking_portfolios(
        data,
        cfg,
        date,
        momentum_neutral=momentum_neutral,
        mode=stock_target_mode,
    )
    snap: ThemeSnapshot = stock_diag["snapshot"]
    A = snap.neutralization_exposures.reindex(M_stock.index)
    Z = snap.purified_theme_exposures.reindex(M_stock.index)
    P = snap.tradable_basket_weights.reindex(M_stock.index).fillna(0.0)

    if cfg.basket_risk_metric == "specific_diag":
        q = specific_risk_diag(data, date, M_stock.index, cfg)
        Q = np.diag(q.reindex(M_stock.index).to_numpy())
    elif cfg.basket_risk_metric == "identity":
        q = pd.Series(1.0, index=M_stock.index)
        Q = np.eye(len(M_stock.index))
    else:
        raise ValueError(f"Unknown basket_risk_metric: {cfg.basket_risk_metric}")

    Pv = P.to_numpy()
    Av = A.to_numpy()
    Zv = Z.to_numpy()
    Mv = M_stock.to_numpy()
    G = Pv.T @ Q @ Pv + cfg.basket_ridge_alpha * np.eye(Pv.shape[1])
    neutral_constraints = Av.T @ Pv
    theme_mapping = Zv.T @ Pv

    H = pd.DataFrame(0.0, index=P.columns, columns=Z.columns)
    theme_rows: list[dict[str, Any]] = []

    for k, theme in enumerate(Z.columns):
        target_m = Mv[:, k]
        c = Pv.T @ Q @ target_m
        target_vector = Zv[:, k].T @ Pv
        h, info = _solve_hard_basket_projection(
            G,
            c,
            neutral_constraints,
            target_vector,
            cfg,
        )
        if h is None:
            if not cfg.allow_soft_fallback:
                status = "infeasible_no_fallback"
                h = np.full(P.shape[1], np.nan)
                info["solver_status"] = status
            else:
                h, soft_info = _solve_soft_basket_projection(
                    G,
                    c,
                    neutral_constraints,
                    target_vector,
                    theme_mapping,
                    k,
                    cfg,
                )
                info.update(soft_info)
        H.loc[:, theme] = h

        w = Pv @ h if np.isfinite(h).all() else np.full(Pv.shape[0], np.nan)
        neutral_exposure = Av.T @ w if np.isfinite(w).all() else np.full(Av.shape[1], np.nan)
        theme_exposure = Zv.T @ w if np.isfinite(w).all() else np.full(Zv.shape[1], np.nan)
        target_exposure = float(theme_exposure[k]) if np.isfinite(theme_exposure[k]) else np.nan
        off = np.delete(theme_exposure, k) if np.isfinite(theme_exposure).all() else np.array([np.nan])
        distance = w - target_m if np.isfinite(w).all() else np.full_like(target_m, np.nan)
        risk_distance = (
            float(np.sqrt(max(distance.T @ Q @ distance, 0.0)))
            if np.isfinite(distance).all()
            else np.nan
        )
        previous_h = (
            previous_basket_weights[theme].reindex(H.index).fillna(0.0).to_numpy()
            if previous_basket_weights is not None and theme in previous_basket_weights.columns
            else np.zeros(len(H.index))
        )
        theme_rows.append(
            {
                "exposure_date": pd.Timestamp(date),
                "profile": profile,
                "target_theme": theme,
                "solver_status": info.get("solver_status", "unknown"),
                "failure_reason": info.get("failure_reason"),
                "target_theme_exposure": target_exposure,
                "target_theme_exposure_error": target_exposure - 1.0 if np.isfinite(target_exposure) else np.nan,
                "max_abs_neutralization_exposure": float(np.nanmax(np.abs(neutral_exposure)))
                if np.isfinite(neutral_exposure).any()
                else np.nan,
                "neutralization_exposure_l2": float(np.linalg.norm(neutral_exposure))
                if np.isfinite(neutral_exposure).all()
                else np.nan,
                "off_target_theme_exposure_max_abs": float(np.nanmax(np.abs(off)))
                if np.isfinite(off).any()
                else np.nan,
                "off_target_theme_exposure_l2": float(np.linalg.norm(off))
                if np.isfinite(off).all()
                else np.nan,
                "basket_gross": float(np.nansum(np.abs(h))),
                "basket_net": float(np.nansum(h)),
                "max_abs_basket_weight": float(np.nanmax(np.abs(h))) if np.isfinite(h).any() else np.nan,
                "n_active_long_baskets": int(np.sum(h > cfg.active_weight_tolerance)) if np.isfinite(h).all() else 0,
                "n_active_short_baskets": int(np.sum(h < -cfg.active_weight_tolerance)) if np.isfinite(h).all() else 0,
                "effective_number_of_baskets": (
                    float((np.sum(np.abs(h)) ** 2) / np.sum(h**2))
                    if np.isfinite(h).all() and np.sum(h**2) > 0
                    else np.nan
                ),
                "lookthrough_stock_gross": float(np.nansum(np.abs(w))),
                "lookthrough_stock_net": float(np.nansum(w)),
                "max_abs_stock_weight": float(np.nanmax(np.abs(w))) if np.isfinite(w).any() else np.nan,
                "risk_weighted_distance_to_stock_target": risk_distance,
                "basket_weight_turnover_from_previous": 0.5 * float(np.nansum(np.abs(h - previous_h))),
                "rank_neutral_constraints": info.get("rank_neutral_constraints"),
                "neutral_nullspace_dimension": info.get("neutral_nullspace_dimension"),
                "condition_number_kkt": info.get("condition_number_kkt"),
            }
        )

    W = P @ H
    rank_P, _, s_P = _svd_rank_and_nullspace(Pv, cfg.basket_rank_tolerance)
    rank_neutral, null_neutral, s_neutral = _svd_rank_and_nullspace(
        neutral_constraints, cfg.basket_rank_tolerance
    )
    neutral_theme_mapping = theme_mapping @ null_neutral if null_neutral.shape[1] else np.empty((Z.shape[1], 0))
    rank_neutral_theme, _, s_neutral_theme = _svd_rank_and_nullspace(
        neutral_theme_mapping, cfg.basket_rank_tolerance
    )
    basis_row = {
        "exposure_date": pd.Timestamp(date),
        "n_stocks": int(P.shape[0]),
        "n_base_baskets": int(P.shape[1]),
        "n_target_themes": int(Z.shape[1]),
        "n_neutralization_constraints": int(A.shape[1]),
        "rank_basket_matrix": rank_P,
        "rank_neutralization_exposure_on_baskets": rank_neutral,
        "neutral_nullspace_dimension": int(null_neutral.shape[1]),
        "rank_theme_exposure_in_neutral_space": rank_neutral_theme,
        "condition_number_basket_matrix": _safe_condition_number(Pv),
        "condition_number_neutral_constraints": _safe_condition_number(neutral_constraints),
        "smallest_singular_value_basket_matrix": float(s_P[-1]) if s_P.size else np.nan,
        "smallest_singular_value_neutral_constraints": float(s_neutral[-1]) if s_neutral.size else np.nan,
        "smallest_singular_value_neutral_theme_mapping": float(s_neutral_theme[-1])
        if s_neutral_theme.size
        else np.nan,
        **snap.diagnostics,
    }
    diagnostics = {
        "per_theme": pd.DataFrame(theme_rows),
        "basis": pd.DataFrame([basis_row]),
        "basket_weights": H,
        "lookthrough_weights": W,
        "stock_target_weights": M_stock,
        "basket_constituent_weights": P,
        "neutralization_exposure": pd.DataFrame(A.to_numpy().T @ W.to_numpy(), index=A.columns, columns=W.columns),
        "theme_exposure": pd.DataFrame(Z.to_numpy().T @ W.to_numpy(), index=Z.columns, columns=W.columns),
        "snapshot": snap,
    }
    return H, W, diagnostics


def compute_theme_basket_returns(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    exposure_date: Any,
    return_date: Any,
    stock_index: pd.Index | None = None,
) -> tuple[pd.Series, pd.DataFrame, pd.DataFrame]:
    exposure_date = pd.Timestamp(exposure_date)
    return_date = pd.Timestamp(return_date)
    if stock_index is None:
        stock_index = data["stock_returns"].columns
    P, _ = prepare_theme_basket_weights(data, exposure_date, stock_index, cfg)
    stock_r = data["stock_returns"].loc[return_date].reindex(P.index)
    q: dict[str, float] = {}
    coverage_rows: list[dict[str, Any]] = []
    processed_returns = pd.Series(index=P.index, dtype=float)
    for basket in P.columns:
        r_processed, coverage, missing = _return_vector_with_policy(stock_r, P[basket].abs(), cfg)
        value = np.nan if r_processed.isna().any() else float(P[basket].dot(r_processed))
        q[basket] = value
        coverage_rows.append(
            {
                "return_date": return_date,
                "exposure_date": exposure_date,
                "base_basket": basket,
                "coverage": coverage,
                "n_missing_active_stock_returns": len(missing),
                "status": "ok" if np.isfinite(value) else "insufficient_return_coverage",
            }
        )
        if processed_returns.isna().all() and not r_processed.isna().any():
            processed_returns = r_processed
    # A shared processed stock-return vector is valid when all baskets passed the same policy.
    if processed_returns.isna().all():
        processed_returns = stock_r
    return pd.Series(q, name=return_date, dtype=float), pd.DataFrame(coverage_rows), P


def basket_replicated_theme_returns(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool | None = None,
    return_artifacts: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame] | tuple[pd.DataFrame, pd.DataFrame, BasketReplicationArtifacts]:
    rows: list[pd.Series] = []
    diag_rows: list[pd.DataFrame] = []
    basis_rows: list[pd.DataFrame] = []
    coverage_rows: list[pd.DataFrame] = []
    basket_return_rows: list[pd.Series] = []
    H_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    W_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    M_stock_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    P_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    stock_dates = data["stock_returns"].index
    previous_H: pd.DataFrame | None = None

    for return_date in theme_returns.index:
        if return_date not in stock_dates:
            continue
        pos = stock_dates.get_loc(return_date)
        if pos == 0:
            continue
        exposure_date = pd.Timestamp(stock_dates[pos - 1])
        try:
            H, W, diagnostics = construct_basket_mimicking_portfolios(
                data,
                cfg,
                exposure_date,
                profile="raw",
                previous_basket_weights=previous_H,
                momentum_neutral=momentum_neutral,
            )
            P = diagnostics["basket_constituent_weights"]
            stock_r_raw = data["stock_returns"].loc[return_date].reindex(P.index)
            q_values: dict[str, float] = {}
            local_coverage_rows: list[dict[str, Any]] = []
            # Use one explicit coverage check per base basket.
            for basket in P.columns:
                r_processed, coverage, missing = _return_vector_with_policy(
                    stock_r_raw, P[basket].abs(), cfg
                )
                q_values[basket] = (
                    np.nan if r_processed.isna().any() else float(P[basket].dot(r_processed))
                )
                local_coverage_rows.append(
                    {
                        "return_date": return_date,
                        "exposure_date": exposure_date,
                        "base_basket": basket,
                        "coverage": coverage,
                        "n_missing_active_stock_returns": len(missing),
                        "status": "ok" if np.isfinite(q_values[basket]) else "insufficient_return_coverage",
                    }
                )
            q = pd.Series(q_values, name=return_date).reindex(H.index)
            g = H.T @ q

            # Identity uses the same stock-return policy, assessed against aggregate look-through activity.
            aggregate_abs = W.abs().sum(axis=1)
            stock_r_processed, stock_coverage, missing_stock = _return_vector_with_policy(
                stock_r_raw.reindex(W.index), aggregate_abs, cfg
            )
            lookthrough = W.T @ stock_r_processed if not stock_r_processed.isna().any() else pd.Series(np.nan, index=W.columns)
            identity_error = (g - lookthrough.reindex(g.index)).abs()

            rows.append(pd.Series(g, index=H.columns, name=return_date))
            basket_return_rows.append(q.rename(return_date))
            theme_diag = diagnostics["per_theme"].copy()
            theme_diag["return_date"] = return_date
            theme_diag["identity_error"] = theme_diag["target_theme"].map(identity_error)
            theme_diag["aggregate_stock_return_coverage"] = stock_coverage
            theme_diag["n_missing_aggregate_active_stock_returns"] = len(missing_stock)
            diag_rows.append(theme_diag)
            basis_rows.append(diagnostics["basis"])
            coverage_rows.append(pd.DataFrame(local_coverage_rows))
            H_by_date[exposure_date] = H.copy()
            W_by_date[exposure_date] = W.copy()
            M_stock_by_date[exposure_date] = diagnostics["stock_target_weights"].copy()
            P_by_date[exposure_date] = P.copy()
            previous_H = H
        except Exception as exc:
            diag_rows.append(
                pd.DataFrame(
                    [
                        {
                            "exposure_date": exposure_date,
                            "return_date": return_date,
                            "target_theme": None,
                            "solver_status": f"unexpected_error:{type(exc).__name__}",
                            "error_message": str(exc),
                        }
                    ]
                )
            )

    basket_returns = pd.DataFrame(rows).sort_index()
    raw_basket_returns = pd.DataFrame(basket_return_rows).sort_index()
    replication_diag = pd.concat(diag_rows, ignore_index=True) if diag_rows else pd.DataFrame()
    basis_diag = pd.concat(basis_rows, ignore_index=True) if basis_rows else pd.DataFrame()
    coverage = pd.concat(coverage_rows, ignore_index=True) if coverage_rows else pd.DataFrame()
    artifacts = BasketReplicationArtifacts(
        raw_basket_returns=raw_basket_returns,
        basket_weights_by_date=H_by_date,
        lookthrough_weights_by_date=W_by_date,
        stock_coefficient_weights_by_date=M_stock_by_date,
        basket_constituent_weights_by_date=P_by_date,
        replication_diagnostics=replication_diag,
        basis_diagnostics=basis_diag,
        return_coverage=coverage,
    )
    if return_artifacts:
        return basket_returns, replication_diag, artifacts
    return basket_returns, replication_diag


# ---------------------------------------------------------------------------
# Comparison, validation, and persistence
# ---------------------------------------------------------------------------


def _pairwise_replication_metrics(
    left: pd.DataFrame,
    right: pd.DataFrame,
    pair_name: str,
    cfg: ReplicationConfig,
) -> pd.DataFrame:
    left, right = left.align(right, join="inner", axis=0)
    left, right = left.align(right, join="inner", axis=1)
    rows: list[dict[str, Any]] = []
    for theme in left.columns:
        pair = pd.concat([left[theme].rename("left"), right[theme].rename("right")], axis=1).dropna()
        if pair.empty:
            continue
        error = pair["right"] - pair["left"]
        x = pair["left"].to_numpy()
        y = pair["right"].to_numpy()
        if len(pair) >= 2 and np.std(x, ddof=1) > 0:
            beta, alpha = np.polyfit(x, y, 1)
            fitted = alpha + beta * x
            sst = float(np.sum((y - y.mean()) ** 2))
            r2 = np.nan if sst <= 0 else 1.0 - float(np.sum((y - fitted) ** 2)) / sst
        else:
            alpha = beta = r2 = np.nan
        rows.append(
            {
                "pair": pair_name,
                "theme": theme,
                "n_obs": len(pair),
                "coverage_ratio": len(pair) / max(len(left), 1),
                "correlation": pair["left"].corr(pair["right"]),
                "spearman_correlation": pair["left"].corr(pair["right"], method="spearman"),
                "tracking_error_monthly": error.std(ddof=1),
                "tracking_error_annualized": error.std(ddof=1) * np.sqrt(cfg.annualization),
                "bias_monthly": error.mean(),
                "bias_annualized": error.mean() * cfg.annualization,
                "rmse": float(np.sqrt(np.mean(error**2))),
                "mae": error.abs().mean(),
                "alpha_monthly": alpha,
                "beta": beta,
                "r_squared": r2,
                "vol_ratio": pair["right"].std(ddof=1) / pair["left"].std(ddof=1)
                if pair["left"].std(ddof=1) > 0
                else np.nan,
                "sign_hit_rate": float((np.sign(pair["left"]) == np.sign(pair["right"])).mean()),
                "max_abs_cumulative_arithmetic_error": float(error.cumsum().abs().max()),
            }
        )
    return pd.DataFrame(rows)


def compare_replication_methods(
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    basket_rep: pd.DataFrame,
    diagnostics: pd.DataFrame | None,
    cfg: ReplicationConfig,
) -> dict[str, pd.DataFrame]:
    metrics = pd.concat(
        [
            _pairwise_replication_metrics(
                purified, stock_rep, "purified_vs_stock_coefficient", cfg
            ),
            _pairwise_replication_metrics(
                purified, basket_rep, "purified_vs_basket_ls", cfg
            ),
            _pairwise_replication_metrics(
                stock_rep, basket_rep, "stock_coefficient_vs_basket_ls", cfg
            ),
        ],
        ignore_index=True,
    )
    numeric = [
        c
        for c in metrics.columns
        if c not in {"pair", "theme"} and pd.api.types.is_numeric_dtype(metrics[c])
    ]
    aggregate_rows: list[dict[str, Any]] = []
    for pair, part in metrics.groupby("pair"):
        for metric in numeric:
            aggregate_rows.extend(
                [
                    {"pair": pair, "metric": metric, "statistic": "mean", "value": part[metric].mean()},
                    {"pair": pair, "metric": metric, "statistic": "median", "value": part[metric].median()},
                    {"pair": pair, "metric": metric, "statistic": "min", "value": part[metric].min()},
                    {"pair": pair, "metric": metric, "statistic": "max", "value": part[metric].max()},
                ]
            )
    aggregate = pd.DataFrame(aggregate_rows)

    common_dates = purified.index.intersection(stock_rep.index).intersection(basket_rep.index)
    common_themes = purified.columns.intersection(stock_rep.columns).intersection(basket_rep.columns)
    return_panel = pd.concat(
        {
            "purified": purified.reindex(index=common_dates, columns=common_themes),
            "stock_coefficient": stock_rep.reindex(index=common_dates, columns=common_themes),
            "basket_ls": basket_rep.reindex(index=common_dates, columns=common_themes),
        },
        axis=1,
    )
    return {
        "metrics_by_theme": metrics,
        "metrics_aggregate": aggregate,
        "return_panel": return_panel,
        "replication_diagnostics": diagnostics if diagnostics is not None else pd.DataFrame(),
    }


def run_theme_basket_replication(
    data: Mapping[str, Any],
    cfg: ReplicationConfig,
) -> dict[str, Any]:
    purified, theme_diag = estimate_theme_returns(data, cfg, cfg.momentum_neutral)
    stock_coef, stock_diag = stock_replicated_theme_returns(
        data,
        cfg,
        purified,
        cfg.momentum_neutral,
        mode="coefficient",
        return_diagnostics=True,
    )
    stock_min, stock_min_diag = stock_replicated_theme_returns(
        data,
        cfg,
        purified,
        cfg.momentum_neutral,
        mode="min_risk",
        return_diagnostics=True,
    )
    basket_rep, basket_diag, artifacts = basket_replicated_theme_returns(
        data,
        cfg,
        purified,
        cfg.momentum_neutral,
        return_artifacts=True,
    )
    comparison = compare_replication_methods(purified, stock_coef, basket_rep, basket_diag, cfg)
    validation = validate_replication_result(
        purified,
        stock_coef,
        basket_rep,
        basket_diag,
        cfg,
    )
    return {
        "purified_theme_returns": purified,
        "stock_coefficient_replicated_theme_returns": stock_coef,
        "stock_min_risk_replicated_theme_returns": stock_min,
        "basket_replicated_theme_returns": basket_rep,
        "theme_return_diagnostics": theme_diag,
        "stock_coefficient_diagnostics": stock_diag,
        "stock_min_risk_diagnostics": stock_min_diag,
        "basket_artifacts": artifacts,
        "comparison": comparison,
        "validation_checks": validation,
        "input_fingerprint": fingerprint_inputs(data, cfg),
        "config_hash": stable_json_hash(asdict(cfg)),
    }


def validate_replication_result(
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    basket_rep: pd.DataFrame,
    basket_diagnostics: pd.DataFrame,
    cfg: ReplicationConfig,
) -> pd.DataFrame:
    p, s = purified.align(stock_rep, join="inner", axis=0)
    p, s = p.align(s, join="inner", axis=1)
    stock_error = float((s - p).abs().max().max()) if not p.empty else np.nan
    identity_error = (
        float(basket_diagnostics["identity_error"].dropna().max())
        if "identity_error" in basket_diagnostics and basket_diagnostics["identity_error"].notna().any()
        else np.nan
    )
    hard = basket_diagnostics[
        basket_diagnostics.get("solver_status", pd.Series(dtype=str)).astype(str).str.startswith("hard_solved")
    ] if not basket_diagnostics.empty else pd.DataFrame()
    neutral_error = (
        float(hard["max_abs_neutralization_exposure"].max()) if not hard.empty else np.nan
    )
    target_error = (
        float(hard["target_theme_exposure_error"].abs().max()) if not hard.empty else np.nan
    )
    rows = [
        {
            "check": "stock_coefficient_replication_max_abs_error",
            "value": stock_error,
            "limit": cfg.stock_replication_tolerance,
            "passed": bool(np.isfinite(stock_error) and stock_error <= cfg.stock_replication_tolerance),
        },
        {
            "check": "basket_return_identity_max_abs_error",
            "value": identity_error,
            "limit": cfg.basket_identity_tolerance,
            "passed": bool(np.isfinite(identity_error) and identity_error <= cfg.basket_identity_tolerance),
        },
        {
            "check": "hard_solution_neutrality_max_abs_error",
            "value": neutral_error,
            "limit": cfg.basket_constraint_tolerance,
            "passed": bool(hard.empty or neutral_error <= cfg.basket_constraint_tolerance),
        },
        {
            "check": "hard_solution_target_exposure_max_abs_error",
            "value": target_error,
            "limit": cfg.basket_constraint_tolerance,
            "passed": bool(hard.empty or target_error <= cfg.basket_constraint_tolerance),
        },
        {
            "check": "basket_replication_has_observations",
            "value": int(basket_rep.notna().any(axis=1).sum()),
            "limit": 1,
            "passed": bool(basket_rep.notna().any(axis=1).sum() > 0),
        },
    ]
    return pd.DataFrame(rows)


def save_replication_outputs(
    result: Mapping[str, Any],
    cfg: ReplicationConfig,
    out_dir: str | Path | None = None,
) -> tuple[Path, dict[str, Any]]:
    out = Path(out_dir) if out_dir is not None else Path(cfg.output_dir) / cfg.replication_output_subdir
    out.mkdir(parents=True, exist_ok=True)
    artifacts: BasketReplicationArtifacts = result["basket_artifacts"]
    manifest_files: dict[str, Any] = {}

    def save_indexed(frame: pd.DataFrame, name: str, index_label: str = "return_date") -> None:
        path = out / name
        temp = frame.copy()
        temp.index.name = index_label
        temp.to_csv(path)
        manifest_files[name] = {"actual": name, "format": "csv"}

    save_indexed(result["purified_theme_returns"], "purified_theme_returns.csv")
    save_indexed(
        result["stock_coefficient_replicated_theme_returns"],
        "stock_coefficient_replicated_theme_returns.csv",
    )
    save_indexed(
        result["stock_min_risk_replicated_theme_returns"],
        "stock_min_risk_replicated_theme_returns.csv",
    )
    save_indexed(result["basket_replicated_theme_returns"], "basket_ls_replicated_theme_returns.csv")
    save_indexed(artifacts.raw_basket_returns, "raw_theme_basket_returns.csv")

    tables = {
        "theme_return_estimation_diagnostics.csv": result["theme_return_diagnostics"],
        "stock_coefficient_replication_diagnostics.csv": result["stock_coefficient_diagnostics"],
        "stock_min_risk_replication_diagnostics.csv": result["stock_min_risk_diagnostics"],
        "basket_mimicking_diagnostics.csv": artifacts.replication_diagnostics,
        "basket_basis_rank_diagnostics.csv": artifacts.basis_diagnostics,
        "basket_return_coverage.csv": artifacts.return_coverage,
        "replication_metrics_by_theme.csv": result["comparison"]["metrics_by_theme"],
        "replication_metrics_aggregate.csv": result["comparison"]["metrics_aggregate"],
        "validation_checks.csv": result["validation_checks"],
    }
    for name, table in tables.items():
        table.to_csv(out / name, index=False)
        manifest_files[name] = {"actual": name, "format": "csv"}

    long_tables: list[tuple[str, pd.DataFrame]] = []
    if cfg.save_full_basket_weights:
        long_tables.append(("basket_weights_long.parquet", artifacts.basket_weights_long))
    if cfg.save_lookthrough_stock_weights:
        long_tables.append(
            ("basket_lookthrough_stock_weights_long.parquet", artifacts.lookthrough_weights_long)
        )
    if cfg.save_stock_coefficient_weights:
        long_tables.append(
            ("stock_coefficient_weights_long.parquet", artifacts.stock_coefficient_weights_long)
        )
    if cfg.save_basket_constituent_weights:
        long_tables.append(
            ("tradable_basket_constituent_weights_long.parquet", artifacts.basket_constituent_weights_long)
        )
    for requested, table in long_tables:
        info = write_table_with_fallback(table, out / requested, index=False)
        manifest_files[requested] = info

    config_dict = asdict(cfg)
    with (out / "comparison_config.json").open("w", encoding="utf-8") as f:
        json.dump(config_dict, f, indent=2, ensure_ascii=False, default=_json_default)
    input_manifest = {
        "replication_schema_version": REPLICATION_SCHEMA_VERSION,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "input_fingerprint": result["input_fingerprint"],
        "config_hash": result["config_hash"],
        "date_start": result["purified_theme_returns"].index.min().isoformat(),
        "date_end": result["purified_theme_returns"].index.max().isoformat(),
        "n_return_dates": int(len(result["purified_theme_returns"])),
        "target_theme_labels": list(map(str, result["purified_theme_returns"].columns)),
        "base_basket_labels": list(
            map(str, artifacts.raw_basket_returns.columns)
        ),
        "target_theme_label_hash": stable_json_hash(list(map(str, result["purified_theme_returns"].columns))),
        "base_basket_label_hash": stable_json_hash(list(map(str, artifacts.raw_basket_returns.columns))),
    }
    with (out / "input_manifest.json").open("w", encoding="utf-8") as f:
        json.dump(input_manifest, f, indent=2, ensure_ascii=False)
    save_manifest = {
        **input_manifest,
        "files": manifest_files,
    }
    with (out / "save_manifest.json").open("w", encoding="utf-8") as f:
        json.dump(save_manifest, f, indent=2, ensure_ascii=False)
    return out, save_manifest


def load_saved_replication_config(output_dir: str | Path) -> ReplicationConfig:
    path = Path(output_dir) / "comparison_config.json"
    with path.open("r", encoding="utf-8") as f:
        return config_from_dict(json.load(f))


# ---------------------------------------------------------------------------
# Plot helpers used by notebooks
# ---------------------------------------------------------------------------


def plot_replication_overview(result: Mapping[str, Any], max_themes: int = 4):
    import matplotlib.pyplot as plt

    purified = result["purified_theme_returns"]
    basket = result["basket_replicated_theme_returns"]
    common = purified.columns.intersection(basket.columns)[:max_themes]
    if len(common) == 0:
        return None
    fig, axes = plt.subplots(len(common), 1, figsize=(10, 2.7 * len(common)), squeeze=False)
    for ax, theme in zip(axes[:, 0], common):
        panel = pd.concat(
            [purified[theme].rename("purified"), basket[theme].rename("basket L/S")], axis=1
        ).dropna()
        panel.cumsum().plot(ax=ax)
        ax.set_title(str(theme))
        ax.set_ylabel("Cumulative arithmetic return")
    fig.tight_layout()
    return fig


def plot_basket_mapping_heatmap(
    artifacts: BasketReplicationArtifacts,
    exposure_date: pd.Timestamp | None = None,
):
    import matplotlib.pyplot as plt

    if not artifacts.basket_weights_by_date:
        return None
    date = pd.Timestamp(exposure_date) if exposure_date is not None else max(artifacts.basket_weights_by_date)
    H = artifacts.basket_weights_by_date[date]
    fig, ax = plt.subplots(figsize=(10, 6))
    image = ax.imshow(H.to_numpy(), aspect="auto")
    ax.set_xticks(range(H.shape[1]), labels=H.columns, rotation=90)
    ax.set_yticks(range(H.shape[0]), labels=H.index)
    ax.set_title(f"Theme-basket mapping H at {date.date()}")
    fig.colorbar(image, ax=ax)
    fig.tight_layout()
    return fig


__all__ = [
    "REPLICATION_SCHEMA_VERSION",
    "ReplicationConfig",
    "Config",
    "ThemeSnapshot",
    "BasketReplicationArtifacts",
    "add_barra_intercept",
    "residualize_df",
    "normalize_l2",
    "prior_stock_momentum",
    "generate_synthetic_inputs",
    "load_or_generate_inputs",
    "snapshot_for_date",
    "estimate_theme_returns",
    "specific_risk_diag",
    "construct_stock_mimicking_portfolios",
    "construct_mimicking_portfolios",
    "stock_replicated_theme_returns",
    "coefficient_replicated_theme_returns",
    "construct_basket_mimicking_portfolios",
    "compute_theme_basket_returns",
    "basket_replicated_theme_returns",
    "compare_replication_methods",
    "run_theme_basket_replication",
    "validate_replication_result",
    "save_replication_outputs",
    "fingerprint_inputs",
    "stable_json_hash",
    "config_from_dict",
    "matrix_dict_to_long",
    "long_to_matrix_dict",
    "write_table_with_fallback",
    "read_table_with_fallback",
    "plot_replication_overview",
    "plot_basket_mapping_heatmap",
]

# ---------------------------------------------------------------------------
# Compatibility helpers used by the TSFM strategy module
# ---------------------------------------------------------------------------

def config_hash(cfg: ReplicationConfig) -> str:
    """Hash a replication configuration using the module's stable JSON codec."""
    return stable_json_hash(asdict(cfg))


def input_fingerprint(data: Mapping[str, Any], cfg: ReplicationConfig | None = None) -> str:
    """Backward-compatible alias for fingerprint_inputs."""
    return fingerprint_inputs(data, cfg)


def matrices_to_long(
    matrices: Mapping[pd.Timestamp, pd.DataFrame],
    row_name: str,
    column_name: str,
) -> pd.DataFrame:
    return matrix_dict_to_long(matrices, row_name=row_name, column_name=column_name)


def long_to_matrices(
    table: pd.DataFrame,
    row_name: str,
    column_name: str,
    value_name: str = "weight",
) -> dict[pd.Timestamp, pd.DataFrame]:
    return long_to_matrix_dict(
        table,
        row_name=row_name,
        column_name=column_name,
        value_name=value_name,
    )


def normalize_factor_weights(weights: pd.Series, gross: float = 1.0) -> pd.Series:
    out = weights.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    denominator = float(out.abs().sum())
    if denominator <= 0:
        return out * 0.0
    return gross * out / denominator


def one_way_turnover(previous: pd.Series, current: pd.Series) -> float:
    labels = previous.index.union(current.index)
    delta = current.reindex(labels, fill_value=0.0) - previous.reindex(labels, fill_value=0.0)
    return 0.5 * float(delta.abs().sum())
