# テーマバスケットL/S複製リターンを用いたTSFM戦略
## 実装要件定義書

- 対象パイプライン: `00_mimicking_portfolio_diagnostics_theme_basket_implemented.ipynb`
- 参照戦略:
  - `01_binary_tsfm_12m(2).ipynb`
  - `02_vol_scaled_tsfm(2).ipynb`
- 作成日: 2026-07-14

---

## 1. 目的

`00` で生成した**テーマバスケットL/Sによる純化テーマファクター複製リターン**をシグナル系列として、現行 `01`、`02` と同じTSFM戦略を構築する。

実装対象は次の2戦略とする。

1. **Binary TSFM 12M**
   - 過去12カ月のテーマ複製リターンが正ならロング、負ならショート
2. **Vol-scaled TSFM**
   - 上記の符号シグナルを、各テーマ複製リターンの過去ボラティリティの逆数でスケール

主戦略では、シグナル生成だけでなく最終売買もテーマバスケットL/Sで行う。

すなわち、以下を主系列とする。

> **signal return source = basket-replicated purified theme return**  
> **trading implementation = theme-basket L/S**

純化テーマファクター推定ロジックおよびテーマバスケット複製ロジック自体は本改修の対象外とし、`00` の出力または共通モジュールを再利用する。

---

## 2. 現行プログラムの整理

### 2.1 `00` のテーマバスケット複製

時点 `t` について、以下の行列を使用する。

- `P_t`: 個別銘柄 × ベーステーマバスケットの構成ウェイト
- `H_t`: ベーステーマバスケット × 複製対象純化テーマの配分
- `M_t^B = P_t H_t`: 個別銘柄ルックスルーの複製ウェイト
- `q_(t+1) = P_t' r_(t+1)`: ベーステーマバスケットの翌月リターン
- `g^B_(t+1) = H_t' q_(t+1)`: テーマバスケットL/Sによる純化テーマ複製リターン

`00` は各月について次の恒等式を検証している。

\[
H_t'\left(P_t'r_{t+1}\right)
=
\left(P_tH_t\right)'r_{t+1}.
\]

現行 `00` の主要保存物は以下である。

- `basket_ls_replicated_theme_returns.csv`: `g^B`
- `raw_theme_basket_returns.csv`: `q`
- `basket_weights_long.parquet`: `H_t`
- `basket_mimicking_diagnostics.csv`
- `basket_basis_rank_diagnostics.csv`
- `basket_return_coverage.csv`
- `comparison_config.json`
- `save_manifest.json`
- 任意保存: `basket_lookthrough_stock_weights_long.parquet`

### 2.2 現行 `01` のシグナル

現行Binary TSFMは、純化テーマリターンの過去12カ月複利リターン

\[
R^{12M}_{k,t}
=
\prod_{s=t-11}^{t}(1+g_{k,s})-1
\]

に対し、

\[
s_{k,t}=\operatorname{sign}(R^{12M}_{k,t})
\]

を計算し、全テーマの絶対ウェイト合計が1になるよう正規化している。

### 2.3 現行 `02` のシグナル

現行Vol-scaled TSFMは、上記の符号をテーマファクターの過去ボラティリティで割り、

\[
\widetilde s_{k,t}
=
\frac{\operatorname{sign}(R^{12M}_{k,t})}{\sigma_{k,t}}
\]

とした後、絶対ウェイト合計を1に正規化している。

ここで `sigma` は最大36カ月の利用可能なテーマリターンから計算される。これは**符号TSFMの逆ボラティリティ配分**であり、連続スコア型TSFMやポートフォリオ全体のボラティリティターゲットではない。

### 2.4 現行バックテストの実装層

現行 `01`、`02` は、ファクターウェイト `w^F_t` を個別銘柄複製行列へ展開し、

\[
w^{stock}_t=M^{stock}_tw^F_t
\]

を作成している。その後、個別銘柄グロスを1へスケールし、翌月個別銘柄リターン、個別銘柄ターンオーバー、取引コストを計算している。

今回の改修では、この実装層をテーマバスケット配分へ置き換える。

---

## 3. 対象戦略の数理仕様

### 3.1 シグナル入力

主戦略のシグナル入力は、`00` が生成した

\[
g^B_{k,t}
\]

とする。

`g^B_{k,t}` は、前月末の `H_(t-1)` と `P_(t-1)` を当月リターンへ適用した実現リターンである。

### 3.2 シグナル日とリターン日の対応

シグナル日を月末 `t`、次のリターン日を `t+1` とする。

1. `g^B` の履歴を `t` まで使用する
2. `w^F_t` を計算する
3. `t` 時点で利用可能な `H_t` を取得する
4. 最終テーマバスケットウェイトを構築する
5. `t+1` のベーステーマバスケットリターン `q_(t+1)` を適用する

`g^B_t` はすでに `H_(t-1)` を用いて実現したリターンであるため、シグナル計算時にさらに1期ラグを加えてはならない。

### 3.3 最終テーマバスケットウェイト

対象純化テーマに対するTSFMファクターウェイトを

\[
w^F_t\in\mathbb{R}^{K}
\]

とする。

最終的に売買するベーステーマバスケットのウェイトは、

\[
b_t=H_tw^F_t
\]

とする。

個別銘柄ルックスルーウェイトは、

\[
m_t=P_tb_t=P_tH_tw^F_t
\]

である。

### 3.4 戦略リターンの恒等式

スケール前・コスト前の戦略リターンは、以下の3経路で一致しなければならない。

\[
\begin{aligned}
r^{factor}_{t+1}
&={w^F_t}'g^B_{t+1},\\
r^{basket}_{t+1}
&=b_t'q_{t+1},\\
r^{lookthrough}_{t+1}
&=m_t'r_{t+1}.
\end{aligned}
\]

したがって、

\[
{w^F_t}'g^B_{t+1}
=
{b_t}'q_{t+1}
=
{m_t}'r_{t+1}
\]

を月次で検証する。

ポートフォリオスケール係数を `c_t` とする場合も、3系列すべてへ同じ `c_t` を掛けた後に一致すること。

---

## 4. 比較設計

単に新戦略と旧戦略を比較するだけでは、差が「シグナル系列の違い」か「売買実装の違い」かを判別できない。したがって、最低限、以下の2×2比較を実装する。

| ID | シグナル生成に使うリターン | 最終実装 | 位置づけ |
|---|---|---|---|
| A | 純化テーマファクターリターン | 個別銘柄coefficient replica | 現行01・02の基準 |
| B | 純化テーマファクターリターン | テーマバスケットL/S | 実装手段だけを変更 |
| C | バスケット複製テーマリターン | 個別銘柄coefficient replica | シグナル履歴だけを変更 |
| D | バスケット複製テーマリターン | テーマバスケットL/S | 今回の主戦略 |

主報告は `A` と `D` の比較とする。`B`、`C` により、次を分離する。

- `B - A`: 実装手段による差
- `C - A`: 複製リターンをシグナルに使うことによる差
- `D` と `B`／`C` の差: 両者の複合効果

全方式の共通サンプル比較と、各方式固有の利用可能サンプル比較を分けて出力する。

---

## 5. 機能要件

### FR-001 共通モジュール化

現行 `01`、`02` に重複している以下の処理をノートブックから分離する。

- データ読込
- 純化テーマリターン推定
- 個別銘柄複製
- テーマバスケット複製
- ウェイト正規化
- バックテスト
- パフォーマンス指標
- 保存処理

推奨構成:

```text
theme_basket_mimicking.py     # 00で実装済みの複製処理
theme_basket_tsfm.py          # 今回追加する戦略共通処理
01_binary_tsfm_12m_theme_basket_ls.ipynb
02_vol_scaled_tsfm_theme_basket_ls.ipynb
```

ノートブックは設定、実行、可視化、保存を行う薄いラッパーとし、約400行の共通コードを複製しない。

### FR-002 複製データ取得モード

以下の2モードを実装する。

#### `load_00_outputs`

`00` の保存結果を読み込む。

必須ファイル:

- `basket_ls_replicated_theme_returns.csv`
- `raw_theme_basket_returns.csv`
- `basket_weights_long.parquet` またはCSV fallback
- `basket_mimicking_diagnostics.csv`
- `basket_basis_rank_diagnostics.csv`
- `basket_return_coverage.csv`
- `comparison_config.json`
- `save_manifest.json`

#### `recompute`

元のpoint-in-time入力から、`basket_replicated_theme_returns(..., return_artifacts=True)` を呼び出し、同一プロセス内で再計算する。

研究再現性の基準は `recompute` とし、パイプライン分離運用では `load_00_outputs` を使用できるようにする。

### FR-003 複製バンドル

次の共通データ構造を新設する。

```python
@dataclass
class BasketReplicationBundle:
    purified_theme_returns: pd.DataFrame
    basket_replicated_theme_returns: pd.DataFrame
    raw_basket_returns: pd.DataFrame
    basket_weights_by_date: dict[pd.Timestamp, pd.DataFrame]  # H_t
    replication_diagnostics: pd.DataFrame
    basis_diagnostics: pd.DataFrame
    return_coverage: pd.DataFrame
    lookthrough_weights_by_date: dict[pd.Timestamp, pd.DataFrame] | None
    config: dict
    manifest: dict
```

`basket_weights_long` は読込時に次の形へpivotする。

- key: `exposure_date`
- row: `base_basket`
- column: `target_theme`
- value: `weight`

### FR-004 入力整合性検証

読込時に以下を検証する。

- 日付は一意、昇順、月次
- テーマラベルとバスケットラベルは重複なし
- `H_t` の列と複製テーマリターンの列が対応する
- `H_t` の行と翌月 `raw_basket_returns` の列が対応する
- `exposure_date < return_date`
- `00` と戦略側のConfigが整合する
- schema versionが対応する
- input fingerprint／config hashが一致する
- 数値が有限である
- solver failure、coverage不足、soft fallbackを識別できる

`00` 側にfingerprintがない場合は、次を追加する。

- `replication_schema_version`
- 元入力ファイルのhashまたは入力識別子
- Config hash
- date range
- stock／theme／basket label hash
- 作成日時

異なるデータまたはConfigで作られたリターンと `H_t` を混在させてはならない。

### FR-005 Binary TSFMシグナル

```python
def binary_tsfm_12m_signal(
    factor_history: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: StrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    ...
```

現行 `01` と同じ計算を維持する。

1. `signal_date` を含む直近12カ月を取得
2. 12カ月内に1つでも欠損があるテーマは除外
3. 複利形成リターンを計算
4. 正なら `+1`、負なら `-1`、0なら `0`
5. 全テーマの絶対ウェイト合計を1に正規化

ロング側とショート側を各50%へ強制してはならない。全テーマが正の場合にネットロングとなる現行仕様を維持する。

### FR-006 Vol-scaled TSFMシグナル

```python
def vol_scaled_tsfm_signal(
    factor_history: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: StrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    ...
```

現行 `02` と同じ計算を主仕様とする。

1. 直近12カ月の複利形成リターンを計算
2. 符号を取得
3. 最大36カ月の利用可能履歴から月次標準偏差を計算
4. `sign / sigma` を計算
5. 全テーマの絶対ウェイト合計を1に正規化

追加要件:

- テーマ別 `vol_nobs` を保存
- `vol_min_observations` 未満は不適格
- `sigma <= factor_vol_floor` は不適格
- pandasの標準偏差定義を明示し、主仕様は `ddof=1`
- ポートフォリオ全体のvolatility targetingは別機能・別系列として扱う
- `continuous_clip` は本戦略で使用しない

### FR-007 Point-in-time品質フィルター

シグナル日 `t` に利用可能な情報だけでテーマの適格性を判定する。

使用可能な項目:

- 当該 `H_t` の `solver_status`
- target theme exposure error
- neutralization exposure error
- basket return coverageの過去値
- condition number
- active basket数
- 過去時点までのrolling replication error

使用禁止:

- 全期間の相関
- 全期間のtracking error
- `t+1` 以降を含む診断値
- 翌月リターンのcoverage

不適格テーマのファクターウェイトを0にした後、適格テーマだけで絶対ウェイト合計を1へ再正規化する。除外理由をテーマ×シグナル日で保存する。

デフォルトでは、少なくとも以下を満たすテーマを利用する。

- 12カ月形成履歴が完全
- 当該 `H_t` が存在
- solver statusが許可リスト内
- target exposure errorが閾値以下
- neutrality errorが閾値以下

soft fallbackを許可するかはConfigで切り替える。

### FR-008 バスケット戦略ウェイト構築

```python
def construct_basket_strategy_weights(
    H_t: pd.DataFrame,
    factor_weights: pd.Series,
    P_t: pd.DataFrame | None,
    cfg: StrategyConfig,
) -> BasketStrategyWeights:
    ...
```

返却値:

```python
@dataclass
class BasketStrategyWeights:
    factor_weights: pd.Series
    basket_weights_pre_scale: pd.Series
    basket_weights: pd.Series
    lookthrough_stock_weights_pre_scale: pd.Series | None
    lookthrough_stock_weights: pd.Series | None
    scale: float
    diagnostics: dict
```

計算手順:

1. ラベルで `factor_weights` と `H_t.columns` を整列
2. 不適格テーマを0にする
3. factor grossを1へ正規化
4. `b_pre = H_t @ wF_t`
5. 必要なら `m_pre = P_t @ b_pre`
6. 設定したスケール方式で `c_t` を計算
7. `b_t = c_t b_pre`、`m_t = c_t m_pre`

配列位置による暗黙結合を禁止する。

### FR-009 スケール方式

以下を実装する。

#### `none`

- `c_t = 1`
- 係数スケールの恒等式診断用

#### `lookthrough_stock_gross`

\[
c_t
=
\frac{G^*}{\sum_i|m_{i,t}^{pre}|}
\]

- 現行 `01`、`02` の `target_stock_gross=1` と最も近い比較
- 2×2比較の主スケール

#### `basket_instrument_gross`

\[
c_t
=
\frac{G_B^*}{\sum_j|b_{j,t}^{pre}|}
\]

- テーマバスケットをETF、TRS、指数バスケット等として直接売買する場合の実務スケール

#### 任意のrobustness

- `ex_ante_vol_target`
- `realized_vol_target`

これらは現行 `02` の「テーマ別逆ボラティリティ配分」と混同しない系列名を使用する。

全出力に以下を保存する。

- pre-scale basket gross／net
- post-scale basket gross／net
- pre-scale look-through gross／net
- post-scale look-through gross／net
- scale factor
- max absolute basket weight
- long／short basket数

### FR-010 月次バックテスト

```python
def run_basket_factor_strategy_backtest(
    bundle: BasketReplicationBundle,
    data: dict | None,
    cfg: StrategyConfig,
    signal_func,
    strategy_name: str,
    signal_return_source: str = "basket_replicated",
    implementation_mode: str = "theme_basket_ls",
) -> dict:
    ...
```

各シグナル日 `t` について以下を行う。

1. シグナル入力系列を `t` まで切り出す
2. シグナルを計算
3. `t` 時点のpoint-in-time品質フィルターを適用
4. `H_t` を取得
5. `b_t = H_t w^F_t` を構築
6. スケールを適用
7. `t+1` の `q_(t+1)` を取得
8. gross returnを計算
9. ターンオーバー、コスト、net returnを計算
10. 恒等式と制約診断を保存

現行と同様に、月末 `t` のリターンが確定した後にポジションを形成し、翌月 `t+1` のリターンを得るものとする。

### FR-011 リターン恒等式検証

各月について次を計算する。

```python
factor_path = scale * factor_weights @ basket_replicated_returns.loc[next_date]
basket_path = basket_weights @ raw_basket_returns.loc[next_date]
lookthrough_path = lookthrough_stock_weights @ stock_returns.loc[next_date]
```

検証項目:

- `abs(factor_path - basket_path) <= tolerance`
- look-throughを利用できる場合、`abs(basket_path - lookthrough_path) <= tolerance`

違反時はゼロ埋めや継続処理を行わず、当該月をerror statusとして記録する。

### FR-012 ターンオーバー

#### バスケット商品ターンオーバー

\[
TO^B_t
=
\frac12\sum_j|b_{j,t}-b_{j,t-1}|.
\]

#### ルックスルー個別銘柄ターンオーバー

\[
TO^S_t
=
\frac12\sum_i|m_{i,t}-m_{i,t-1}|.
\]

最終的に集約・nettingした戦略ウェイトから計算する。各純化テーマポートフォリオのターンオーバーを単純合算してはならない。

初回ポジションは現行コードとの互換性のため、前月ウェイト0として扱い、`0.5 × gross` をターンオーバーとする。

追加診断として、次の正確な分解を保存する。

\[
\Delta b_t
=
H_{t-1}(w^F_t-w^F_{t-1})
+(H_t-H_{t-1})w^F_t.
\]

- signal change component
- replication mapping change component
- total change

構成銘柄のリターンドリフト後ウェイトを使うproduction turnoverは補足系列とし、現行互換のtarget-weight turnoverを置換しない。

### FR-013 取引コスト

実行モデルを明示する。

#### `basket_instrument`

- コスト対象: `TO^B_t`
- ETF、TRS、先物、カスタム指数等を直接売買する想定

#### `lookthrough_stock`

- コスト対象: `TO^S_t`
- ベーステーマバスケットを構成銘柄まで展開して売買する想定

```python
cost = turnover * one_way_cost_bps / 10_000
net_return = gross_return - cost
```

以下を混ぜない。

- basket instrument cost
- constituent stock cost
- borrow／short cost
- financing cost

主比較では現行と同じone-way 10bpを使用可能とするが、basketとstockで別パラメータを持たせる。

### FR-014 欠損値処理

現行バックテストの無条件な `fillna(0.0)` は使用しない。

- 形成期間内に欠損があるテーマはシグナル不適格
- 翌月の加重対象リターンが欠損する場合、当該月を無効または明示的なcoverage policyに従う
- 将来の欠損を見てシグナル日ウェイトを再配分しない
- 欠損理由、coverage、無効化した月を保存
- 構造的に存在しないラベルを0ウェイトにする処理と、リターン欠損の0埋めを区別する

推奨デフォルトは `propagate_nan` または `coverage_threshold` とする。

### FR-015 戦略レベルのエクスポージャー診断

テーマ別複製診断だけでなく、最終戦略ポートフォリオについて以下を計算する。

- Barra／中立化エクスポージャー: `A_t' m_t`
- 実現テーマエクスポージャー: `Z_t' m_t`
- 期待テーマエクスポージャーとの差

\[
Z_t'P_tH_tw^F_t-w^F_t
\]

- max absolute neutrality exposure
- target theme exposure distortion
- off-theme contamination
- strategy-level basket gross／look-through gross
- mapping condition number
- weighted solver status構成比
- weighted replication coverage

各 `H_t` 列がsoft fallbackの場合、組合せ後の中立性が悪化または改善する可能性があるため、必ず最終ポートフォリオで再計算する。

### FR-016 比較指標

各戦略・実装方式について以下を算出する。

- 観測月数、coverage
- 年率平均リターン
- 年率ボラティリティ
- Sharpe ratio
- 平均リターンのt値
- 最大ドローダウン
- 月次hit rate
- 年率ターンオーバー
- 年率取引コスト
- 平均basket gross／look-through gross
- 最大basket gross
- long／short basket本数

方式間比較:

- 月次リターン相関
- 月次・年率tracking error
- 平均リターン差
- beta、alpha、R-squared
- cumulative return差
- rolling 36カ月相関
- rolling 36カ月tracking error

最低限、以下を比較する。

- A vs D
- A vs B
- A vs C
- B vs D
- C vs D

### FR-017 寄与度

月次で以下を保存する。

#### 複製対象テーマ別寄与度

\[
Contribution^{theme}_{k,t+1}
=c_tw^F_{k,t}g^B_{k,t+1}.
\]

#### ベーステーマバスケット別寄与度

\[
Contribution^{basket}_{j,t+1}
=b_{j,t}q_{j,t+1}.
\]

両寄与度の合計がgross returnと一致すること。

### FR-018 可視化

各ノートブックで最低限、以下を表示・保存する。

- gross／net累積リターン
- A～Dの累積比較
- 月次ターンオーバー
- basket instrument turnover vs look-through turnover
- basket gross、look-through gross、scale factor
- long／short factor数、long／short basket数
- 最新factor weights
- 最新base basket weights
- 最大絶対ウェイト上位バスケット
- rolling correlation／tracking error
- strategy-level neutrality exposure
- signal change／mapping change turnover分解

---

## 6. Config追加要件

```python
from dataclasses import dataclass
from typing import Literal

@dataclass
class StrategyConfig:
    # Replication bundle
    replication_input_mode: Literal["load_00_outputs", "recompute"] = "load_00_outputs"
    replication_output_dir: str = (
        "theme_factor_momentum_outputs/00_mimicking_portfolio_diagnostics"
    )
    expected_replication_schema_version: str = "1.0"
    require_config_hash_match: bool = True
    require_input_fingerprint_match: bool = True

    # Signal source / implementation
    signal_return_source: Literal["purified", "basket_replicated"] = "basket_replicated"
    implementation_mode: Literal["stock_coefficient", "theme_basket_ls"] = "theme_basket_ls"

    # Formation
    formation_months: int = 12
    min_history_months: int = 24
    risk_lookback_months: int = 36
    vol_min_observations: int = 24
    factor_vol_floor: float = 1e-8
    factor_weight_gross: float = 1.0

    # Point-in-time quality
    apply_replication_quality_filter: bool = True
    allow_soft_fallback: bool = False
    allowed_solver_status: tuple[str, ...] = ("hard_solved",)
    max_target_exposure_error: float = 1e-6
    max_neutralization_exposure: float = 1e-6
    min_replication_return_coverage: float = 0.98
    max_condition_number: float | None = None

    # Strategy scale
    strategy_scale_mode: Literal[
        "none",
        "lookthrough_stock_gross",
        "basket_instrument_gross",
        "ex_ante_vol_target",
    ] = "lookthrough_stock_gross"
    target_lookthrough_stock_gross: float = 1.0
    target_basket_instrument_gross: float = 1.0
    target_annualized_vol: float | None = None

    # Execution and costs
    execution_model: Literal["basket_instrument", "lookthrough_stock"] = "basket_instrument"
    basket_transaction_cost_bps_one_way: float = 10.0
    stock_transaction_cost_bps_one_way: float = 10.0
    include_borrow_cost: bool = False
    include_financing_cost: bool = False

    # Missing data
    missing_return_policy: Literal[
        "propagate_nan", "coverage_threshold"
    ] = "coverage_threshold"

    # Numerical validation
    return_identity_tolerance: float = 1e-10
    weight_normalization_tolerance: float = 1e-12
    gross_target_tolerance: float = 1e-10

    # Comparison and saving
    run_comparison_grid: bool = True
    comparison_common_sample: bool = True
    rolling_metric_months: int = 36
    save_basket_weights: bool = True
    save_lookthrough_stock_weights: bool = False
    annualization: int = 12
```

`Config` の複製設定と戦略設定を同一dataclassに詰め込まず、可能であれば次の2階層に分ける。

- `ReplicationConfig`
- `StrategyConfig`

---

## 7. API要件

```python
def load_basket_replication_bundle(
    output_dir: str | Path,
    cfg: StrategyConfig,
) -> BasketReplicationBundle:
    ...


def validate_replication_bundle(
    bundle: BasketReplicationBundle,
    cfg: StrategyConfig,
) -> pd.DataFrame:
    ...


def binary_tsfm_12m_signal(
    factor_history: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: StrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    ...


def vol_scaled_tsfm_signal(
    factor_history: pd.DataFrame,
    signal_date: pd.Timestamp,
    cfg: StrategyConfig,
) -> tuple[pd.Series, pd.DataFrame]:
    ...


def eligible_themes_at_date(
    bundle: BasketReplicationBundle,
    signal_date: pd.Timestamp,
    signal_info: pd.DataFrame,
    cfg: StrategyConfig,
) -> pd.DataFrame:
    ...


def construct_basket_strategy_weights(
    H_t: pd.DataFrame,
    factor_weights: pd.Series,
    P_t: pd.DataFrame | None,
    cfg: StrategyConfig,
) -> BasketStrategyWeights:
    ...


def run_basket_factor_strategy_backtest(
    bundle: BasketReplicationBundle,
    data: dict | None,
    cfg: StrategyConfig,
    signal_func,
    strategy_name: str,
) -> dict:
    ...


def run_strategy_comparison_grid(
    bundle: BasketReplicationBundle,
    data: dict,
    cfg: StrategyConfig,
    signal_func,
) -> dict[str, dict]:
    ...


def save_basket_strategy_outputs(
    result: dict,
    comparison: dict,
    cfg: StrategyConfig,
    subdir: str,
) -> Path:
    ...
```

---

## 8. 出力要件

### 8.1 ノートブック

- `01_binary_tsfm_12m_theme_basket_ls.ipynb`
- `02_vol_scaled_tsfm_theme_basket_ls.ipynb`

既存 `01_binary_tsfm_12m(2).ipynb`、`02_vol_scaled_tsfm(2).ipynb` は上書きしない。

### 8.2 出力ディレクトリ

```text
theme_factor_momentum_outputs/
  01_binary_tsfm_12m_theme_basket_ls/
  02_vol_scaled_tsfm_theme_basket_ls/
```

### 8.3 必須ファイル

#### `strategy_returns.csv`

最低限の列:

- `return_date`
- `signal_date`
- `signal_return_source`
- `implementation_mode`
- `scale_mode`
- `execution_model`
- `factor_path_return_pre_scale`
- `basket_path_return_pre_scale`
- `lookthrough_path_return_pre_scale`
- `gross_return`
- `transaction_cost`
- `net_return`
- `basket_turnover`
- `lookthrough_turnover`
- `pre_scale_basket_gross`
- `post_scale_basket_gross`
- `pre_scale_lookthrough_gross`
- `post_scale_lookthrough_gross`
- `scale_factor`
- `n_long_factors`
- `n_short_factors`
- `n_long_baskets`
- `n_short_baskets`
- `weighted_replication_coverage`
- `max_neutralization_exposure`
- `return_identity_error`
- `status`

#### その他

- `factor_weights.csv`
- `signal_diagnostics.parquet`
- `strategy_basket_weights_long.parquet`
- `strategy_lookthrough_stock_weights_long.parquet`（任意）
- `factor_contributions.parquet`
- `basket_contributions.parquet`
- `strategy_replication_diagnostics.parquet`
- `turnover_decomposition.parquet`
- `performance_metrics.csv`
- `comparison_grid_metrics.csv`
- `comparison_grid_returns.csv`
- `comparison_common_sample_metrics.csv`
- `config.json`
- `input_manifest.json`
- `validation_checks.csv`
- 図表一式

---

## 9. エラー・ステータス要件

例外を無言で握りつぶして `continue` してはならない。各シグナル日について少なくとも次のstatusを返す。

- `ok`
- `insufficient_signal_history`
- `no_eligible_themes`
- `missing_H_on_signal_date`
- `missing_raw_basket_return`
- `replication_solver_not_allowed`
- `replication_coverage_below_threshold`
- `target_exposure_error`
- `neutrality_error`
- `return_identity_failure`
- `config_hash_mismatch`
- `input_fingerprint_mismatch`
- `invalid_scale_denominator`
- `unexpected_error:<ExceptionType>`

skipped monthをパフォーマンス計算から除外する場合も、件数と理由を集計して保存する。

---

## 10. 受入基準

### 10.1 シグナル互換性

1. 同じリターン入力を与えた場合、新Binaryシグナルが現行 `01` と数値一致する。
2. 同じリターン入力を与えた場合、新Vol-scaledシグナルが現行 `02` と数値一致する。
3. Binary、Vol-scaledとも、適格テーマがある場合のfactor grossが1となる。
4. 現行 `02` が連続スコア型ではなく `sign / sigma` であることを維持する。

許容誤差: `1e-12`。

### 10.2 日付・ルックアヘッド

1. `g^B_t` の生成に使用する `H` は `t-1` 時点である。
2. シグナル日 `t` の形成窓は `t` までである。
3. 翌月実装に使用する `H_t` の `exposure_date` は `signal_date=t` である。
4. 実現リターンは `t+1` である。
5. `t+1` 以降のリターンを変更しても、`t` 以前のシグナルとウェイトが変化しない。

### 10.3 リターン恒等式

月次で、

\[
|r^{factor}_{t+1}-r^{basket}_{t+1}|
\le 10^{-10}
\]

を満たす。

ルックスルーが利用可能な場合、

\[
|r^{basket}_{t+1}-r^{lookthrough}_{t+1}|
\le 10^{-10}
\]

を満たす。

### 10.4 スケール

- `lookthrough_stock_gross` モードで有効分母がある場合、post-scale look-through grossが目標値へ一致
- `basket_instrument_gross` モードでpost-scale basket grossが目標値へ一致
- factor、basket、look-throughの3経路へ同じscaleを適用

許容誤差: `1e-10`。

### 10.5 ターンオーバー・コスト

- 最終集約ウェイトから計算される
- 初回ターンオーバーが `0.5 × initial gross`
- `cost = turnover × bps / 10,000`
- `net = gross - cost`
- basket実行とlook-through実行で異なるturnoverを混同しない

### 10.6 ラベル整合性

- テーマ列、バスケット列、銘柄列を入れ替えても結果が不変
- `H_t.columns` とfactor weightをラベル結合
- `H_t.index` とraw basket returnをラベル結合
- 存在しないラベルを暗黙に別ラベルへ割り当てない

### 10.7 欠損・失敗

- 欠損リターンを無条件に0としない
- solver failureを成功として扱わない
- quality filter除外理由を保存
- realized return欠損を見て過去ウェイトを変更しない
- skipped monthが出力上確認できる

### 10.8 00出力読込と再計算の一致

同じ入力・Configについて、

- `load_00_outputs`
- `recompute`

から得られる以下が許容誤差内で一致する。

- `g^B`
- `q`
- `H_t`
- 戦略gross return
- factor／basket contributions

### 10.9 2×2比較

- A～Dを同一シグナル日・同一return dateで比較可能
- 共通サンプル指標とnative coverage指標を分離
- 全方式で同じコスト前スケールを選べる
- 総差をsignal effectとimplementation effectへ追跡可能

### 10.10 再現性

- 同一入力、同一Config、同一コードで完全再現
- Config、入力fingerprint、schema versionを保存
- 合成データを使用した場合はseedを保存

---

## 11. ノートブック構成

両ノートブックを次の構成に統一する。

### Step 0. Config

- 00出力パス
- シグナルパラメータ
- quality filter
- スケール
- execution／cost
- 保存設定

### Step 1. Replication bundle読込・検証

- `g^B`
- `q`
- `H_t`
- diagnostics
- manifest／hash

### Step 2. 複製リターン確認

- 累積リターン
- coverage
- solver status
- ランク
- 直近 `H_t`

### Step 3. シグナル確認

- 形成リターン
- 符号
- sigma（02のみ）
- eligibility
- pre／post filter factor weight

### Step 4. 主戦略D

- basket strategy weights
- monthly return
- turnover／cost
- strategy-level exposures
- identity checks

### Step 5. A～D比較

- 共通サンプル
- パフォーマンス
- rolling metrics
- signal／implementation差

### Step 6. 保存

- 結果ファイル
- config／manifest
- validation checks
- 図表

---

## 12. 実装順序

### Phase 1: 共通基盤

1. `theme_basket_mimicking.py` を共通モジュールとして固定
2. `00` 出力にschema versionとfingerprintを追加
3. `BasketReplicationBundle` loader／validatorを実装
4. `basket_weights_long` のpivotと日付整合性テストを実装

### Phase 2: 戦略エンジン

1. Binary／Vol-scaledシグナルを共通モジュールへ移植
2. eligibility filterを実装
3. `H_t w^F_t` によるバスケットウェイト構築
4. スケール、リターン、恒等式検証を実装
5. basket／look-through turnoverとコストを実装

### Phase 3: ノートブック

1. `01_binary_tsfm_12m_theme_basket_ls.ipynb`
2. `02_vol_scaled_tsfm_theme_basket_ls.ipynb`
3. A～D比較と可視化
4. 保存処理

### Phase 4: テスト

1. 現行01／02シグナルとの互換テスト
2. no-look-aheadテスト
3. return identityテスト
4. label permutationテスト
5. missing／solver failureテスト
6. load／recompute一致テスト
7. 2×2共通サンプルテスト

---

## 13. 実装時の主要な注意事項

1. **`basket_ls_replicated_theme_returns.csv` だけでは最終売買を再現できない。**  
   シグナルには `g^B`、売買には `H_t` と `q_(t+1)` が必要である。

2. **リターンのラグとポートフォリオのラグを混同しない。**  
   `g^B_t` は `H_(t-1)` による実現値であり、次月売買には `H_t` を使う。

3. **最終ターンオーバーは集約後ウェイトで計算する。**  
   `H_t` の列別ターンオーバーをfactor weightで単純加重しても、バスケット間nettingを反映できない。

4. **現行02はポートフォリオvol targetingではない。**  
   各テーマの `sign / sigma` 配分を維持し、ポートフォリオvol targetは別系列とする。

5. **全期間の複製精度をテーマ選別へ使わない。**  
   point-in-time diagnosticsまたは過去時点までのrolling diagnosticsのみ利用する。

6. **係数スケールと投資可能スケールを分ける。**  
   恒等式診断はscaleなし、現行比較はlook-through gross 1、実務分析はbasket gross 1を併記する。

7. **個別銘柄とテーマバスケットのコスト率を分離する。**  
   どの実行モデルのnet returnかを系列名と出力列で明示する。

---

## 14. 完了定義

実装完了は、次のすべてを満たす状態とする。

- 01と同じBinary TSFMをbasket-replicated returnで生成できる
- 02と同じVol-scaled TSFMをbasket-replicated returnで生成できる
- 最終ウェイトが `H_t w^F_t` としてテーマバスケット単位で保存される
- factor／basket／look-throughのreturn identityが通る
- no-look-aheadが自動テストで確認される
- A～Dの比較結果が共通サンプルで出力される
- basket／look-through turnoverとcostが分離される
- quality failureと欠損月が可視化される
- Config／input fingerprint／schema version付きで再現可能
- 実行済みノートブック、共通モジュール、テスト、出力例が揃う
