# テーマバスケットL/S複製リターンを用いたTSFM実装

## 1. 実装対象

本パッケージは、純化テーマファクターリターンをテーマバスケットのロング・ショートで複製し、その複製リターンをシグナル入力および最終売買手段として使う二つの戦略を実装する。

- **01 Binary TSFM 12M**: 過去12カ月の複利テーマリターンの符号を使用
- **02 Vol-scaled TSFM**: 上記の符号を最大36カ月のテーマ標準偏差で除した `sign / sigma` を使用

主戦略Dは次の構成である。

- シグナル系列: テーマバスケットL/S複製テーマリターン
- 実装手段: テーマバスケットL/S
- 純化テーマウェイト: `wF_t`
- 純化テーマからベーステーマバスケットへの写像: `H_t`
- 最終テーマバスケットウェイト: `b_t = H_t @ wF_t`
- ルックスルー個別銘柄ウェイト: `m_t = P_t @ H_t @ wF_t`

各月について、係数スケール上の次の恒等式を検証する。

```text
wF_t' gB_(t+1) = b_t' q_(t+1) = m_t' r_(t+1)
```

## 2. ファイル構成

| ファイル | 内容 |
|---|---|
| `00_mimicking_portfolio_diagnostics_theme_basket_implemented.ipynb` | 純化テーマ、個別銘柄coefficient replica、テーマバスケットL/S replicaの推定・比較・保存 |
| `01_binary_tsfm_12m_theme_basket_ls.ipynb` | Binary TSFM 12Mの主戦略DとA～D比較 |
| `02_vol_scaled_tsfm_theme_basket_ls.ipynb` | Vol-scaled TSFMの主戦略DとA～D比較 |
| `theme_basket_mimicking.py` | 00の共通複製エンジン |
| `theme_basket_tsfm.py` | 01・02の共通戦略エンジン |
| `run_theme_basket_tsfm_pipeline.py` | 3ノートブック相当のコマンドライン実行 |
| `test_theme_basket_tsfm.py` | end-to-endテスト |
| `theme_basket_replicated_tsfm_requirements.md` | 実装要件定義書 |
| `requirements.txt` | Python依存パッケージ |
| `theme_factor_momentum_outputs/` | 実行済み合成サンプルの出力 |

3本のノートブックは実行済みであり、セル出力も保存されている。

## 3. 実行順序

実データを使う場合は、パッケージ直下の `data/theme_factor_inputs.pkl` に入力pickleを配置するか、各ノートブックの `DATA_PATH` を変更する。

```text
00_mimicking_portfolio_diagnostics_theme_basket_implemented.ipynb
    ↓
01_binary_tsfm_12m_theme_basket_ls.ipynb
02_vol_scaled_tsfm_theme_basket_ls.ipynb
```

01・02の `replication_data_mode="auto"` は、00の保存済み出力が入力fingerprintと一致すればそれを読み込み、一致する出力がなければ00を再計算する。

コマンドラインでは以下を実行する。

```bash
python run_theme_basket_tsfm_pipeline.py \
  --input-pickle data/theme_factor_inputs.pkl \
  --output-dir theme_factor_momentum_outputs \
  --signals both
```

既存00出力のみを必ず利用する場合は、次を指定する。

```bash
python run_theme_basket_tsfm_pipeline.py \
  --input-pickle data/theme_factor_inputs.pkl \
  --output-dir theme_factor_momentum_outputs \
  --replication-data-mode load_00_outputs
```

## 4. 入力データ契約

pickleは最低限次を含む。

```python
{
    "stock_returns": pd.DataFrame,  # return_date × stock_id
    "barra_exposures_by_date": dict[pd.Timestamp, pd.DataFrame],
    "theme_exposures_by_date": dict[pd.Timestamp, pd.DataFrame],
    "theme_basket_weights_by_date": dict[pd.Timestamp, pd.DataFrame],
}
```

各point-in-time行列の形式は次のとおり。

- Barra: `stock_id × barra_factor`
- テーマ定義: `stock_id × target_theme`
- 売買可能テーマバスケット: `stock_id × base_basket`

本番では次を設定し、因子定義ウェイトを売買可能バスケットへ暗黙に転用しないことを推奨する。

```python
replication_cfg.basket_fallback_to_theme_exposures = False
```

実データpickleがない場合、配布ノートブックは動作確認用として72カ月・100銘柄・10テーマの合成データを生成する。この件数設定は実データが存在する場合には使用されない。

## 5. A～D比較

| ID | シグナル系列 | 実装手段 | 分析目的 |
|---|---|---|---|
| A | 純化テーマリターン | 個別銘柄coefficient L/S | 従来方式の基準 |
| B | 純化テーマリターン | テーマバスケットL/S | 実装手段だけを変更 |
| C | バスケット複製リターン | 個別銘柄coefficient L/S | シグナル系列だけを変更 |
| D | バスケット複製リターン | テーマバスケットL/S | 本実装の主戦略 |

比較指標は共通の有効月に揃えて算出する。AとCの実装リターンには、純化回帰係数ではなく保存済みの個別銘柄coefficient-replicated factor returnを使用するため、個別銘柄経路との恒等式も数値精度内で成立する。

## 6. スケール、売買、コスト

既定設定は次のとおり。

```python
strategy_scale_mode = "lookthrough_stock_gross"
target_lookthrough_stock_gross = 1.0
execution_model = "basket_instrument"
basket_transaction_cost_bps_one_way = 10.0
stock_transaction_cost_bps_one_way = 10.0
```

したがって、現行01・02との比較に合わせてルックスルー個別銘柄グロスを1へ揃える一方、主戦略Dの取引コストはテーマバスケット商品のターンオーバーに課す。

テーマバスケット商品自体のグロスを1へ揃える実務分析では、次を使用する。

```python
strategy_cfg.strategy_scale_mode = "basket_instrument_gross"
strategy_cfg.target_basket_instrument_gross = 1.0
```

個別銘柄まで展開して売買する場合は次を使用する。

```python
strategy_cfg.execution_model = "lookthrough_stock"
```

## 7. 品質フィルター

主戦略では、シグナル日時点で次を満たすテーマだけを利用する。

- シグナル形成期間が完備している
- `H_t` が存在する
- solver statusが許容されている
- 対象テーマエクスポージャー誤差が閾値以内
- 中立化エクスポージャーが閾値以内
- 過去の複製リターンcoverageが閾値以上
- 設定時は条件数が上限以内

除外理由は `signal_diagnostics` に保存する。solver failureやcoverage不足を0リターンとして扱わない。

## 8. 出力

00は次の主要データを保存する。

```text
purified_theme_returns.csv
stock_coefficient_replicated_theme_returns.csv
basket_ls_replicated_theme_returns.csv
raw_theme_basket_returns.csv
basket_weights_long.parquet または CSV fallback
basket_lookthrough_stock_weights_long.parquet または CSV fallback
stock_coefficient_weights_long.parquet または CSV fallback
tradable_basket_constituent_weights_long.parquet または CSV fallback
basket_mimicking_diagnostics.csv
basket_basis_rank_diagnostics.csv
save_manifest.json
```

01・02はそれぞれ次を保存する。

```text
strategy_returns.csv
factor_weights.csv
scaled_factor_weights.csv
performance_metrics.csv
signal_diagnostics.parquet または CSV fallback
strategy_basket_weights_long.parquet または CSV fallback
strategy_lookthrough_stock_weights_long.parquet または CSV fallback
factor_contributions.parquet または CSV fallback
basket_contributions.parquet または CSV fallback
strategy_replication_diagnostics.parquet または CSV fallback
turnover_decomposition.parquet または CSV fallback
comparison_grid_metrics.csv
comparison_common_sample_metrics.csv
comparison_grid_returns.csv
comparison_effects.csv
validation_checks.csv
config.json
input_manifest.json
save_manifest.json
figures/
```

Parquet engineを利用できない環境では自動的にCSVへフォールバックする。実際のファイル名は各 `save_manifest.json` に記録される。

## 9. 実行済みサンプルの検証結果

合成サンプルにおける受入結果は次のとおり。

- 00の数値受入チェック: 全件成功
- Binary TSFMの戦略受入チェック: 9件中9件成功
- Vol-scaled TSFMの戦略受入チェック: 9件中9件成功
- BinaryのA～D共通サンプル: 46カ月
- Vol-scaledのA～D共通サンプル: 46カ月
- Binary主戦略Dの最大リターン恒等式誤差: 約 `7.1e-17`
- Vol-scaled主戦略Dの最大リターン恒等式誤差: 約 `7.8e-17`
- pytest: 3件中3件成功

合成データの投資成績は実装確認用であり、実データに対する期待収益を示すものではない。

## 10. テスト

```bash
pytest -q
```

テストは次を確認する。

- 00出力の保存・再読込契約
- BinaryとVol-scaledの旧シグナル式との一致
- no-look-ahead
- 列ラベル順序不変性
- A～Dの全方式が生成されること
- factor、basket、look-throughのリターン恒等式
- ルックスルーグロス目標
- 初回ターンオーバー定義
- 取引コスト式
