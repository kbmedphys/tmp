# Project Rules: p05_aqr

このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。
このプロジェクトの Prefer explicit python path は 
- envs/rl/.venv/bin/python

---
## Source of truth
- refs/*ipynb        : 参考プログラム
- *.ipynb            : single source of execution & inspection

## 目的
- 参考プログラムはテーマETFローテーション戦略である
- この戦略をPPO強化学習に拡張する

---

## 注意
- 特徴量は t までの情報で計算し、t+1 のリターン予測に使う
- 週次リバランスなら「週末で決めたwを翌営業日から適用」など実装上の時点整合を厳密化
- 実装は１つのipynbファイルで完結させること