# 日本株テーマバスケット戦略 Jupyter Notebook

## 同梱ファイル

- `theme_basket_strategy_notebook.ipynb`  
  各実行レベルを個別セルに分けたJupyter Notebookです。

- `theme_basket_strategy.py`  
  Notebookから読み込むヘルパーモジュールです。Notebookと同じフォルダに置いてください。

## Notebookの構成

1. Imports
2. パス設定
3. サンプルデータ生成
4. 共通ロード
5. Level 1: MVP — テーマ価格時系列のみ
6. Level 2: Factor-adjusted — テーマ価格 + ファクターリターン
7. Level 3: Coherence-gated — 構成銘柄 + 個別株価格/リターン
8. Level 4: Full overlay — ニュース、ガバナンス/PBR、回転率crowding
9. 各レベルの結果比較
10. NAVプロット
11. 最終ウェイト・シグナル確認

## 初回動作確認

Notebook内の `USE_SAMPLE_DATA = True` のまま、上から順に実行してください。サンプルデータが自動生成され、全レベルを実行できます。

## 実データで実行する場合

Notebookの「1. パス設定」セルで以下を変更します。

```python
USE_SAMPLE_DATA = False
PATH_THEME_CSV = BASE_DIR / "theme_prices.csv"
PATH_FACTOR_CSV = BASE_DIR / "factor_returns.csv"
PATH_CONSTITUENTS_CSV = BASE_DIR / "constituents.csv"
PATH_STOCK_CSV = BASE_DIR / "stock_prices.csv"
PATH_NEWS_CSV = BASE_DIR / "news_score.csv"
PATH_GOVERNANCE_CSV = BASE_DIR / "governance_score.csv"
PATH_TURNOVER_CSV = BASE_DIR / "theme_turnover.csv"
```

最低限 `PATH_THEME_CSV` があれば Level 1 は実行できます。

## 注意

- `factor_returns.csv` は価格ではなくリターン系列を入れてください。
- `constituents.csv` の `theme` はテーマ価格CSVのカラム名と一致させてください。
- `constituents.csv` の `ticker` は個別株価格CSVのカラム名と一致させてください。
- 大量の個別株を内部でrolling residualizationすると重くなるため、実務では個別株残差リターンを事前計算し、Notebook側では `residualize_stocks=False` のまま使うことを推奨します。
