"""Theme basket strategy helper module.

Implements a research-oriented version of:
Coherence-Gated Narrative Momentum with Governance/PBR Catalyst Overlay.

Dependencies: pandas, numpy.
"""
from __future__ import annotations

import json
import math
import os
from dataclasses import asdict, dataclass
from typing import Dict, Literal, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd

InputKind = Literal["price", "return", "auto"]
Mode = Literal["long_only", "long_short"]


@dataclass
class StrategyConfig:
    theme_input_kind: InputKind = "auto"
    stock_input_kind: InputKind = "auto"

    residualize_themes: bool = True
    residualize_stocks: bool = True
    rolling_beta_window: int = 252
    rolling_beta_min_obs: int = 126
    ridge_lambda: float = 1e-4

    mom_lookbacks: Tuple[int, int, int] = (252, 126, 63)
    mom_weights: Tuple[float, float, float] = (0.50, 0.30, 0.20)
    mom_skip: int = 21
    mom_vol_floor: float = 1e-4

    use_coherence_gate: bool = True
    coherence_window: int = 126
    coherence_min_names: int = 8
    coherence_min_effective_names: float = 5.0
    coherence_apc_threshold: float = 0.0
    coherence_score_threshold: Optional[float] = None
    apc_weight: float = 0.65
    eigenshare_weight: float = 0.35

    use_news: bool = True
    use_governance: bool = True
    use_leadlag: bool = False
    use_valuation: bool = False
    use_crowding: bool = True

    w_momentum: float = 0.45
    w_news: float = 0.20
    w_governance: float = 0.20
    w_leadlag: float = 0.10
    w_valuation: float = 0.05
    w_crowding_penalty: float = 0.25

    mode: Mode = "long_only"
    rebalance: str = "ME"
    top_n: Optional[int] = None
    bottom_n: Optional[int] = None
    long_quantile: float = 0.20
    short_quantile: float = 0.20
    max_theme_weight: float = 0.15
    min_abs_score: float = 0.0
    gross_exposure: float = 1.0
    net_exposure: float = 1.0

    cost_bps_per_turnover: float = 5.0
    annualization: int = 252
    min_theme_obs: int = 126
    fill_missing_returns: bool = False

    def normalized_mom_weights(self) -> np.ndarray:
        w = np.asarray(self.mom_weights, dtype=float)
        if not np.isfinite(w).all() or w.sum() == 0:
            raise ValueError("mom_weights must be finite and have non-zero sum")
        return w / w.sum()


def _infer_date_col(columns: Sequence[str]) -> str:
    for c in ["date", "Date", "DATE", "datetime", "timestamp", "Timestamp"]:
        if c in columns:
            return c
    return columns[0]


def read_matrix_csv(path: str, date_col: Optional[str] = None, value_col: Optional[str] = None, key_col: Optional[str] = None) -> pd.DataFrame:
    """Read wide or long time-series CSV into date-indexed matrix."""
    df = pd.read_csv(path)
    if df.empty:
        raise ValueError(f"Empty CSV: {path}")
    date_col = date_col or _infer_date_col(list(df.columns))
    if date_col not in df.columns:
        raise ValueError(f"date_col={date_col} not found in {path}")
    cols_lower = {str(c).lower(): c for c in df.columns}
    if key_col is None:
        for c in ["theme", "ticker", "symbol", "ric", "factor", "name"]:
            if c in cols_lower:
                key_col = cols_lower[c]
                break
    if value_col is None:
        for c in ["value", "price", "px", "return", "ret", "score", "weight"]:
            if c in cols_lower:
                value_col = cols_lower[c]
                break
    df[date_col] = pd.to_datetime(df[date_col])
    if key_col is not None and value_col is not None and key_col in df.columns and value_col in df.columns:
        out = df.pivot_table(index=date_col, columns=key_col, values=value_col, aggfunc="last")
        out = out.sort_index()
        out.columns = out.columns.astype(str)
        return out.apply(pd.to_numeric, errors="coerce")
    out = df.set_index(date_col).sort_index()
    out = out.loc[:, ~out.columns.astype(str).str.lower().isin(["unnamed: 0"])]
    out.columns = out.columns.astype(str)
    return out.apply(pd.to_numeric, errors="coerce")


def read_constituents_csv(path: str) -> pd.DataFrame:
    """Read PIT constituents. Required: theme, ticker/ric/symbol, weight."""
    df = pd.read_csv(path)
    cols = {str(c).lower(): c for c in df.columns}
    theme_col = cols.get("theme")
    ticker_col = cols.get("ticker") or cols.get("ric") or cols.get("symbol")
    weight_col = cols.get("weight") or cols.get("wgt")
    date_col = cols.get("date") or cols.get("effective_date")
    if theme_col is None or ticker_col is None or weight_col is None:
        raise ValueError("constituents_csv requires theme, ticker/ric/symbol, weight")
    out = pd.DataFrame({
        "date": pd.to_datetime(df[date_col]) if date_col else pd.Timestamp("1900-01-01"),
        "theme": df[theme_col].astype(str),
        "ticker": df[ticker_col].astype(str),
        "weight": pd.to_numeric(df[weight_col], errors="coerce"),
    })
    out["purity"] = pd.to_numeric(df[cols["purity"]], errors="coerce") if "purity" in cols else 1.0
    out["liquidity_adj"] = pd.to_numeric(df[cols["liquidity_adj"]], errors="coerce") if "liquidity_adj" in cols else 1.0
    out = out.dropna(subset=["date", "theme", "ticker", "weight"])
    out["weight"] = out["weight"].clip(lower=0)
    out["purity"] = out["purity"].fillna(1.0).clip(lower=0)
    out["liquidity_adj"] = out["liquidity_adj"].fillna(1.0).clip(lower=0)
    return out.sort_values(["theme", "date", "ticker"]).reset_index(drop=True)


def prices_to_returns(data: pd.DataFrame, kind: InputKind = "auto") -> pd.DataFrame:
    x = data.copy().sort_index().replace([np.inf, -np.inf], np.nan)
    if kind == "auto":
        med_abs = np.nanmedian(np.abs(x.to_numpy(dtype=float)))
        kind = "price" if med_abs > 2 else "return"
    if kind == "price":
        return x.pct_change(fill_method=None).replace([np.inf, -np.inf], np.nan)
    if kind == "return":
        return x
    raise ValueError("kind must be price, return, or auto")


def zscore_cross_sectional(x: pd.DataFrame, winsor: float = 5.0) -> pd.DataFrame:
    mu = x.mean(axis=1, skipna=True)
    sd = x.std(axis=1, skipna=True, ddof=0).replace(0.0, np.nan)
    z = x.sub(mu, axis=0).div(sd, axis=0)
    if winsor is not None:
        z = z.clip(-winsor, winsor)
    return z


def rolling_residualize(returns: pd.DataFrame, factors: Optional[pd.DataFrame], window: int = 252, min_obs: int = 126, ridge_lambda: float = 1e-4) -> pd.DataFrame:
    """One-step rolling residualization. Beta at t is estimated with data <= t-1."""
    y = returns.copy().sort_index().replace([np.inf, -np.inf], np.nan)
    if factors is None or factors.empty:
        return y
    X = factors.copy().sort_index().replace([np.inf, -np.inf], np.nan)
    idx = y.index.intersection(X.index)
    y = y.loc[idx]
    X = X.loc[idx]
    Xfull = np.column_stack([np.ones(len(idx)), X.to_numpy(dtype=float)])
    ymat = y.to_numpy(dtype=float)
    out = np.full_like(ymat, np.nan, dtype=float)
    k = Xfull.shape[1]
    ridge = np.eye(k) * ridge_lambda
    ridge[0, 0] = 0.0
    for t in range(len(idx)):
        start, end = max(0, t - window), t
        if end - start < min_obs:
            continue
        Xw_all = Xfull[start:end]
        Xt = Xfull[t]
        if not np.isfinite(Xt).all():
            continue
        finite_X = np.isfinite(Xw_all).all(axis=1)
        for j in range(ymat.shape[1]):
            yw_all = ymat[start:end, j]
            mask = finite_X & np.isfinite(yw_all)
            if mask.sum() < min_obs or not np.isfinite(ymat[t, j]):
                continue
            Xw = Xw_all[mask]
            yw = yw_all[mask]
            try:
                beta = np.linalg.solve(Xw.T @ Xw + ridge, Xw.T @ yw)
            except np.linalg.LinAlgError:
                beta = np.linalg.pinv(Xw.T @ Xw + ridge) @ Xw.T @ yw
            out[t, j] = ymat[t, j] - float(Xt @ beta)
    return pd.DataFrame(out, index=idx, columns=y.columns)


def rolling_momentum(returns: pd.DataFrame, lookbacks=(252,126,63), weights=(0.5,0.3,0.2), skip=21, vol_floor=1e-4) -> pd.DataFrame:
    ret = returns.copy().sort_index()
    w = np.asarray(weights, dtype=float)
    w = w / w.sum()
    raw = pd.DataFrame(0.0, index=ret.index, columns=ret.columns)
    for lb, ww in zip(lookbacks, w):
        shifted = ret.shift(skip)
        cum = shifted.rolling(lb, min_periods=max(20, lb // 2)).sum()
        vol = shifted.rolling(lb, min_periods=max(20, lb // 2)).std(ddof=0).replace(0, np.nan)
        raw = raw + ww * (cum / vol.clip(lower=vol_floor))
    return zscore_cross_sectional(raw)


def return_acceleration_crowding(returns: pd.DataFrame, short: int = 21, medium: int = 63) -> pd.DataFrame:
    r_short = returns.rolling(short, min_periods=max(5, short // 2)).sum()
    r_med_lag = returns.shift(short).rolling(medium, min_periods=max(10, medium // 2)).sum()
    return zscore_cross_sectional(r_short - r_med_lag)


def rolling_theme_turnover_crowding(turnover: pd.DataFrame, window: int = 60) -> pd.DataFrame:
    x = np.log1p(turnover.replace([np.inf, -np.inf], np.nan).clip(lower=0))
    surpr = x - x.rolling(window, min_periods=max(10, window // 2)).mean()
    return zscore_cross_sectional(surpr)


def make_rebalance_dates(index: pd.DatetimeIndex, rule: str = "ME") -> pd.DatetimeIndex:
    s = pd.Series(np.arange(len(index)), index=index)
    try:
        vals = s.resample(rule).last().dropna().astype(int).values
    except ValueError:
        if rule == "ME":
            vals = s.resample("M").last().dropna().astype(int).values
        elif rule == "M":
            vals = s.resample("ME").last().dropna().astype(int).values
        else:
            raise
    return pd.DatetimeIndex(index[vals])


def effective_n(weights: Union[pd.Series, np.ndarray]) -> float:
    w = np.asarray(weights, dtype=float)
    w = w[np.isfinite(w)]
    if w.size == 0 or w.sum() <= 0:
        return np.nan
    w = w / w.sum()
    return float(1.0 / np.sum(w ** 2))


def _latest_constituents_for_date(constituents: pd.DataFrame, dt: pd.Timestamp) -> Dict[str, pd.DataFrame]:
    c = constituents[constituents["date"] <= dt]
    out = {}
    if c.empty:
        return out
    for theme, g in c.groupby("theme"):
        gg = g[g["date"] == g["date"].max()].copy()
        gg = gg[gg["weight"] > 0]
        if gg.empty:
            continue
        adj = gg["weight"] * gg["purity"].fillna(1) * gg["liquidity_adj"].fillna(1)
        if adj.sum() <= 0:
            continue
        gg["adj_weight"] = adj / adj.sum()
        out[str(theme)] = gg
    return out


def compute_coherence_features(residual_stock_returns: pd.DataFrame, constituents: pd.DataFrame, theme_columns: Sequence[str], signal_dates: Sequence[pd.Timestamp], window=126, min_names=8, min_effective_names=5.0):
    stock_ret = residual_stock_returns.sort_index()
    dates = pd.DatetimeIndex(signal_dates)
    themes = list(map(str, theme_columns))
    apc = pd.DataFrame(np.nan, index=dates, columns=themes)
    eig = pd.DataFrame(np.nan, index=dates, columns=themes)
    eff = pd.DataFrame(np.nan, index=dates, columns=themes)
    gate = pd.DataFrame(False, index=dates, columns=themes)
    for dt in dates:
        prev = stock_ret.index[stock_ret.index <= dt]
        if len(prev) == 0:
            continue
        dtx = prev[-1]
        loc = stock_ret.index.get_loc(dtx)
        if not isinstance(loc, (int, np.integer)):
            loc = int(np.asarray(loc).ravel()[-1])
        win = stock_ret.iloc[max(0, loc - window + 1):loc + 1]
        latest = _latest_constituents_for_date(constituents, dt)
        for theme in themes:
            gg = latest.get(theme)
            if gg is None:
                continue
            tickers = [t for t in gg["ticker"].astype(str).tolist() if t in win.columns]
            if len(tickers) < min_names:
                continue
            w = gg.set_index("ticker").loc[tickers, "adj_weight"]
            en = effective_n(w.values)
            eff.loc[dt, theme] = en
            if not np.isfinite(en) or en < min_effective_names:
                continue
            sub = win[tickers].dropna(axis=1, thresh=max(20, window // 2))
            if sub.shape[1] < min_names:
                continue
            corr = sub.corr(min_periods=max(20, window // 2)).to_numpy(dtype=float)
            iu = np.triu_indices_from(corr, k=1)
            pc = corr[iu]
            pc = pc[np.isfinite(pc)]
            if len(pc) == 0:
                continue
            apc.loc[dt, theme] = float(np.mean(pc))
            cmat = np.nan_to_num(corr, nan=0.0, posinf=0.0, neginf=0.0)
            np.fill_diagonal(cmat, 1.0)
            try:
                vals = np.clip(np.linalg.eigvalsh(cmat), 0, None)
                eig.loc[dt, theme] = float(vals[-1] / vals.sum()) if vals.sum() > 0 else np.nan
            except np.linalg.LinAlgError:
                pass
            gate.loc[dt, theme] = True
    return apc, eig, eff, gate


def align_feature_matrix(feature: Optional[pd.DataFrame], index: pd.Index, columns: Sequence[str], fill_value=0.0) -> pd.DataFrame:
    if feature is None or feature.empty:
        return pd.DataFrame(fill_value, index=index, columns=columns, dtype=float)
    return feature.sort_index().reindex(index).ffill().reindex(columns=columns).fillna(fill_value).astype(float)


def cap_and_normalize_long(w: pd.Series, max_weight: float, gross: float = 1.0) -> pd.Series:
    x = w.clip(lower=0).replace([np.inf, -np.inf], np.nan).fillna(0).astype(float)
    if x.sum() <= 0:
        return x
    x = x / x.sum() * gross
    cap = max_weight * gross if max_weight and max_weight <= 1 else max_weight
    if not cap or cap <= 0:
        return x
    for _ in range(20):
        over = x > cap
        if not over.any():
            break
        excess = float((x[over] - cap).sum())
        x[over] = cap
        under = ~over
        if x[under].sum() <= 0 or excess <= 1e-12:
            break
        x[under] += x[under] / x[under].sum() * excess
    return x / x.sum() * gross if x.sum() > 0 else x


def construct_theme_weights(scores: pd.DataFrame, config: StrategyConfig, gates: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    s = scores.replace([np.inf, -np.inf], np.nan).copy()
    if gates is not None:
        s = s.where(gates.reindex_like(s).fillna(False))
    weights = pd.DataFrame(0.0, index=s.index, columns=s.columns)
    n_cols = len(s.columns)
    for dt, row in s.iterrows():
        row = row.dropna()
        if row.empty:
            continue
        row = row[row.abs() >= config.min_abs_score]
        if config.mode == "long_only":
            r = row[row > 0]
            if r.empty:
                continue
            q = config.top_n if config.top_n is not None else max(1, int(math.ceil(n_cols * config.long_quantile)))
            sel = r.nlargest(q)
            weights.loc[dt, sel.index] = cap_and_normalize_long(sel, config.max_theme_weight, config.gross_exposure)
        else:
            ql = config.top_n if config.top_n is not None else max(1, int(math.ceil(n_cols * config.long_quantile)))
            qs = config.bottom_n if config.bottom_n is not None else max(1, int(math.ceil(n_cols * config.short_quantile)))
            longs = row[row > 0].nlargest(ql)
            shorts = row[row < 0].nsmallest(qs)
            if not longs.empty:
                wl = cap_and_normalize_long(longs, config.max_theme_weight, config.gross_exposure / 2)
                weights.loc[dt, wl.index] = wl
            if not shorts.empty:
                ws = cap_and_normalize_long(-shorts, config.max_theme_weight, config.gross_exposure / 2)
                weights.loc[dt, ws.index] = -ws
    return weights


def backtest_theme_weights(theme_returns: pd.DataFrame, weights_daily: pd.DataFrame, cost_bps_per_turnover: float = 5.0):
    ret = theme_returns.reindex_like(weights_daily).fillna(0)
    wlag = weights_daily.shift(1).fillna(0)
    gross = (wlag * ret).sum(axis=1)
    turnover = weights_daily.diff().abs().sum(axis=1).fillna(weights_daily.abs().sum(axis=1))
    cost = turnover * cost_bps_per_turnover / 10000.0
    net = gross - cost
    details = pd.DataFrame({"gross_return": gross, "turnover": turnover, "cost": cost, "net_return": net, "gross_exposure": weights_daily.abs().sum(axis=1), "net_exposure": weights_daily.sum(axis=1)})
    return net, details


def performance_metrics(returns: pd.Series, annualization: int = 252) -> pd.Series:
    r = returns.dropna().astype(float)
    if r.empty:
        return pd.Series(dtype=float)
    nav = (1 + r).cumprod()
    dd = nav / nav.cummax() - 1
    vol = r.std(ddof=0) * math.sqrt(annualization)
    ann_ret = nav.iloc[-1] ** (annualization / max(1, len(r))) - 1
    downside = r[r < 0].std(ddof=0) * math.sqrt(annualization)
    return pd.Series({
        "ann_return": ann_ret,
        "ann_vol": vol,
        "sharpe": ann_ret / vol if vol > 0 else np.nan,
        "sortino": ann_ret / downside if downside > 0 else np.nan,
        "max_drawdown": dd.min(),
        "calmar": ann_ret / abs(dd.min()) if dd.min() < 0 else np.nan,
        "hit_rate_daily": (r > 0).mean(),
        "avg_daily_return": r.mean(),
        "daily_vol": r.std(ddof=0),
        "skew": r.skew(),
        "kurtosis": r.kurtosis(),
        "n_obs": len(r),
        "final_nav": nav.iloc[-1],
    })


class ThemeBasketStrategy:
    def __init__(self, theme_data: pd.DataFrame, config: Optional[StrategyConfig] = None, factor_returns: Optional[pd.DataFrame] = None, constituents: Optional[pd.DataFrame] = None, stock_data: Optional[pd.DataFrame] = None, news_score: Optional[pd.DataFrame] = None, governance_score: Optional[pd.DataFrame] = None, leadlag_score: Optional[pd.DataFrame] = None, valuation_score: Optional[pd.DataFrame] = None, turnover_data: Optional[pd.DataFrame] = None):
        self.config = config or StrategyConfig()
        self.theme_raw = theme_data.copy().sort_index()
        self.factor_returns = factor_returns.copy().sort_index() if factor_returns is not None else None
        self.constituents = constituents
        self.stock_raw = stock_data.copy().sort_index() if stock_data is not None else None
        self.news_score = news_score
        self.governance_score = governance_score
        self.leadlag_score = leadlag_score
        self.valuation_score = valuation_score
        self.turnover_data = turnover_data
        self.results = {}

    def prepare_returns(self):
        cfg = self.config
        theme_returns = prices_to_returns(self.theme_raw, cfg.theme_input_kind)
        valid = theme_returns.columns[theme_returns.notna().sum() >= cfg.min_theme_obs]
        theme_returns = theme_returns[valid]
        if cfg.fill_missing_returns:
            theme_returns = theme_returns.fillna(0)
        stock_returns = None
        if self.stock_raw is not None:
            stock_returns = prices_to_returns(self.stock_raw, cfg.stock_input_kind)
            if cfg.fill_missing_returns:
                stock_returns = stock_returns.fillna(0)
        self.results["theme_returns"] = theme_returns
        if stock_returns is not None:
            self.results["stock_returns"] = stock_returns
        return theme_returns, stock_returns

    def compute(self):
        cfg = self.config
        theme_returns, stock_returns = self.prepare_returns()
        idx, cols = theme_returns.index, list(theme_returns.columns)
        factors = self.factor_returns.reindex(idx).astype(float) if self.factor_returns is not None else None

        if cfg.residualize_themes and factors is not None and not factors.empty:
            theme_resid = rolling_residualize(theme_returns, factors, cfg.rolling_beta_window, cfg.rolling_beta_min_obs, cfg.ridge_lambda)
        else:
            theme_resid = theme_returns.copy()
        self.results["theme_residual_returns"] = theme_resid
        mom = rolling_momentum(theme_resid, cfg.mom_lookbacks, cfg.normalized_mom_weights(), cfg.mom_skip, cfg.mom_vol_floor)
        self.results["momentum_score"] = mom

        coherence_gate = pd.DataFrame(True, index=idx, columns=cols)
        coherence_score = pd.DataFrame(0.0, index=idx, columns=cols)
        apc_full = pd.DataFrame(np.nan, index=idx, columns=cols)
        eig_full = pd.DataFrame(np.nan, index=idx, columns=cols)
        eff_full = pd.DataFrame(np.nan, index=idx, columns=cols)

        if cfg.use_coherence_gate and self.constituents is not None and stock_returns is not None:
            stock_factors = self.factor_returns.reindex(stock_returns.index).astype(float) if self.factor_returns is not None else None
            if cfg.residualize_stocks and stock_factors is not None and not stock_factors.empty:
                stock_resid = rolling_residualize(stock_returns, stock_factors, cfg.rolling_beta_window, cfg.rolling_beta_min_obs, cfg.ridge_lambda)
            else:
                stock_resid = stock_returns.copy()
            self.results["stock_residual_returns"] = stock_resid
            rebal_dates = make_rebalance_dates(idx, cfg.rebalance)
            apc, eig, eff, gate_rebal = compute_coherence_features(stock_resid, self.constituents, cols, rebal_dates, cfg.coherence_window, cfg.coherence_min_names, cfg.coherence_min_effective_names)
            apc_full = apc.reindex(idx).ffill()
            eig_full = eig.reindex(idx).ffill()
            eff_full = eff.reindex(idx).ffill()
            coherence_score = (cfg.apc_weight * zscore_cross_sectional(apc_full) + cfg.eigenshare_weight * zscore_cross_sectional(eig_full)).fillna(0)
            hard_gate = (apc_full > cfg.coherence_apc_threshold) & (eff_full >= cfg.coherence_min_effective_names)
            if cfg.coherence_score_threshold is not None:
                hard_gate &= coherence_score >= cfg.coherence_score_threshold
            coherence_gate = hard_gate.fillna(False)
        elif cfg.use_coherence_gate:
            self.results["warning_coherence"] = pd.Series(["Coherence gate requested but constituents and/or stock_data were not supplied. Using all-True gate."])

        self.results["coherence_apc"] = apc_full
        self.results["coherence_eigenshare"] = eig_full
        self.results["coherence_effective_n"] = eff_full
        self.results["coherence_score"] = coherence_score
        self.results["coherence_gate"] = coherence_gate

        news = align_feature_matrix(self.news_score, idx, cols, 0.0)
        gov = align_feature_matrix(self.governance_score, idx, cols, 0.0)
        leadlag = align_feature_matrix(self.leadlag_score, idx, cols, 0.0)
        valuation = align_feature_matrix(self.valuation_score, idx, cols, 0.0)
        crowd = return_acceleration_crowding(theme_returns)
        if self.turnover_data is not None:
            turn = align_feature_matrix(self.turnover_data, idx, cols, np.nan)
            crowd = zscore_cross_sectional(0.5 * crowd + 0.5 * rolling_theme_turnover_crowding(turn))
        crowd = crowd.fillna(0)
        self.results["news_score"] = news
        self.results["governance_score"] = gov
        self.results["leadlag_score"] = leadlag
        self.results["valuation_score"] = valuation
        self.results["crowding_score"] = crowd

        score = cfg.w_momentum * mom.fillna(0)
        if cfg.use_news:
            score += cfg.w_news * zscore_cross_sectional(news).fillna(0)
        if cfg.use_governance:
            score += cfg.w_governance * zscore_cross_sectional(gov).fillna(0)
        if cfg.use_leadlag:
            score += cfg.w_leadlag * zscore_cross_sectional(leadlag).fillna(0)
        if cfg.use_valuation:
            score += cfg.w_valuation * zscore_cross_sectional(valuation).fillna(0)
        if cfg.use_crowding:
            short_ret = theme_returns.rolling(10, min_periods=5).sum()
            break_mask = (short_ret < 0).astype(float)
            score -= cfg.w_crowding_penalty * crowd * (0.5 + 0.5 * break_mask)

        score_gated = score.where(coherence_gate)
        self.results["final_score"] = score
        self.results["final_score_gated"] = score_gated

        rebal_dates = make_rebalance_dates(idx, cfg.rebalance)
        w_rebal = construct_theme_weights(score_gated.reindex(rebal_dates), cfg, gates=coherence_gate.reindex(rebal_dates).fillna(False))
        w_daily = w_rebal.reindex(idx).ffill().fillna(0)
        strat_ret, details = backtest_theme_weights(theme_returns, w_daily, cfg.cost_bps_per_turnover)
        metrics = performance_metrics(strat_ret, cfg.annualization)
        self.results["theme_weights_rebalance"] = w_rebal
        self.results["theme_weights_daily"] = w_daily
        self.results["strategy_returns"] = strat_ret
        self.results["backtest_details"] = details
        self.results["metrics"] = metrics
        return self.results

    def save_results(self, output_dir: str):
        os.makedirs(output_dir, exist_ok=True)
        for name, obj in self.results.items():
            path = os.path.join(output_dir, f"{name}.csv")
            if isinstance(obj, pd.DataFrame):
                obj.to_csv(path, index=True)
            elif isinstance(obj, pd.Series):
                obj.to_csv(path, header=True)
        with open(os.path.join(output_dir, "config.json"), "w", encoding="utf-8") as f:
            json.dump(asdict(self.config), f, ensure_ascii=False, indent=2)
