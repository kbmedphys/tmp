# Combined Factor Momentum Notebooks

## 目的

この一式は、既存因子と、既存因子で純化したテーマ因子を同じ統合ファクター・ユニバースとして扱い、ファクター・モメンタムに基づいて投資対象因子を決定し、最終的に個別銘柄ロングショートの mimicking portfolio で複製する実装です。

実装済みノートブックは以下です。

| ファイル | 内容 |
|---|---|
| `00_combined_factor_mimicking_diagnostics.ipynb` | 統合ファクター行列、テーマ純化、mimicking portfolio、複製可能ファクターリターンを診断する確認用ノートブック。 |
| `01_binary_combined_factor_tsfm_12m.ipynb` | 既存因子 + 純化テーマ因子に対する12カ月Binary TSFM。過去12カ月リターンが正の因子をロング、負の因子をショート。 |
| `02_vol_scaled_combined_factor_tsfm_12m.ipynb` | 12カ月TSFMの方向を保ちつつ、因子別ボラティリティでウェイトを調整する実務版。 |

各ノートブックは単体で実行できるよう、共通関数をすべて内包しています。外部 `.py` への依存はありません。

## 文献対応

- Ehsani and Linnainmaa, *Factor Momentum and the Momentum Factor*: time-series factor momentum は、過去1年リターンが正のファクターをロング、負のファクターをショートし、月次リバランスする戦略。個別株モメンタムはファクター・モメンタムから伝播する、という立場。
- Gupta and Kelly, *Factor Momentum Everywhere*: 多数の特徴量ベース因子について、因子自身の過去リターンを使ったTSFMを構築。ボラティリティ標準化と±2クリップの連続スケーリング式を提示。

## 実行モード

デフォルトでは `use_synthetic_data=True` で、構造確認用の合成データを生成します。実データで使う場合は、各ノートブックの設定セルで以下を変更してください。

```python
cfg = CombinedFactorConfig(
    use_synthetic_data=False,
    ...
)
```

そのうえで、ノートブックと同じディレクトリの `./data/combined_factor_inputs.pkl` に、以下の辞書を保存してください。

```python
{
    "stock_returns": stock_returns,
    "existing_factor_exposures": existing_factor_exposures,
    "theme_basket_weights": theme_basket_weights,
    "factor_metadata": factor_metadata,
    "cash_returns": cash_returns,
}
```

## 入力スキーマ

### `stock_returns`

`DataFrame`。index は日付、columns は `security_id`。日次でも月次でも可です。日次の場合はノートブック内で月次複利リターンに変換します。

### `existing_factor_exposures`

以下のいずれかです。

1. `{date: DataFrame(index=security_id, columns=factor_id)}` の辞書。
2. long形式DataFrame。列は `date`, `security_id`, `factor_id`, `exposure`。
3. long/wide形式DataFrame。列は `date`, `security_id`, 既存因子列。

ノートブック内で各月の横断面を標準化し、L2ノルムを揃えます。

### `theme_basket_weights`

`DataFrame`。必須列は以下です。

- `theme_id`
- `security_id`
- `weight`
- `effective_date`

`knowledge_date` または `available_date` があれば point-in-time 利用可能日として使います。ない場合は `effective_date` を `knowledge_date` とみなします。

### `factor_metadata`

任意ですが、実運用では必須推奨です。

| 列 | 内容 |
|---|---|
| `factor_id` | 既存因子ID。`existing_factor_exposures` の列名と一致させる。 |
| `factor_type` | 通常は `existing`。 |
| `role` | `investable_signal`, `purification_basis`, `risk_control_only`, `excluded` のいずれか。 |
| `is_momentum_related` | `MOM12`, `INDMOM`, `STR` など、個別株モメンタムとの機械的関係を持つ因子なら `True`。 |

デフォルトでは `exclude_momentum_related_from_signal=True` のため、momentum関連因子は投資対象から外し、`include_excluded_momentum_as_control=True` ならcontrol exposureとして中立化します。

## 実装の主要式

テーマ純化:

\[
A_t = [\mathbf{1}, E_t, C_t]\Theta_t + Z_t
\]

統合ファクター:

\[
F_t=[E_t,Z_t]
\]

mimicking portfolio:

\[
m_{h,t}'F_t=e_h',\quad m_{h,t}'\mathbf{1}=0,\quad m_{h,t}'C_t=0
\]

複製可能ファクターリターン:

\[
y^{rep}_{h,t+1}=m_{h,t}'r_{t+1}
\]

Binary TSFM:

\[
M^{12}_{h,t}=\prod_{s=t-11}^{t}(1+y^{rep}_{h,s})-1,
\quad
s_{h,t}=\operatorname{sign}(M^{12}_{h,t})
\]

Vol-scaled TSFM:

\[
\tilde w^F_{h,t}=\frac{s_{h,t}}{\hat\sigma_{h,t}}
\]

最終個別銘柄ウェイト:

\[
w^{stock}_t=M_t w^F_t
\]

## 各ノートブックの目視確認ポイント

各ノートブックは、処理ステップごとに以下を表示します。

- 入力データの概要とサンプル
- factor metadata と role の確認
- 複製可能ファクターリターン
- 横断回帰係数型ファクターリターンとの比較
- 既存因子、control exposure、生テーマ、純化テーマのサンプル
- テーマ純化R2と残留exposure
- 統合ファクター行列のrank、条件数、相関
- mimicking portfolio の制約診断
- `M_t'F_t` 露出行列
- 最新TSFMシグナル
- existing-only / theme-only / combined-factor-equal / combined-block-equal の比較
- gross/net return、turnover、取引コスト
- 既存因子由来P&Lとテーマ因子由来P&Lの分解
- 最新ファクターウェイトと最新個別銘柄ウェイト

## 注意

合成データで表示されるパフォーマンスは検算用であり、投資判断には使えません。実データでは、point-in-time性、欠損処理、銘柄の売買可能性、空売り制約、流動性、取引コスト、マーケットインパクトを必ず別途確認してください。
