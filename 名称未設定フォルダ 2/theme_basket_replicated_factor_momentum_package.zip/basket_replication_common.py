from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple
import math
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Markdown

pd.set_option('display.max_columns', 160)
pd.set_option('display.width', 260)
pd.set_option('display.float_format', lambda x: f'{x:,.6f}')


@dataclass
class BasketReplicationConfig:
    """テーマバスケット・リターン複製版の設定。"""
    use_synthetic_data: bool = True
    seed: int = 123
    start_month: str = '2016-01-31'
    end_month: str = '2024-12-31'
    n_baskets: int = 12
    n_existing_factors: int = 7
    data_dir: Path = Path('./data')
    output_dir: Path = Path('./outputs/basket_replicated_factor_momentum')

    # 文献の識別に合わせ、Momentum/Short-term reversal等は主シグナルから外し、純化基準には残す。
    exclude_momentum_related_from_signal: bool = True
    include_excluded_momentum_as_purification_basis: bool = True

    replication_lookback_months: int = 36
    min_replication_history_months: int = 24
    ridge_alpha: float = 1e-3

    formation_months: int = 12
    skip_recent_months: int = 0
    min_signal_history_months: int = 12
    volatility_lookback_months: int = 36
    factor_gross_target: float = 1.0
    basket_gross_target: Optional[float] = None
    transaction_cost_bps_one_way: float = 5.0

    # factor_equal: 全ファクターで等グロス / block_equal: existing と purified theme に等グロス
    weighting_mode: str = 'factor_equal'

    def __post_init__(self):
        self.data_dir = Path(self.data_dir)
        self.output_dir = Path(self.output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)


def display_step(title: str, obj: Any = None, n: int = 6):
    display(Markdown(f'### {title}'))
    if obj is None:
        return
    if isinstance(obj, pd.DataFrame):
        display(obj.head(n))
        if len(obj) > n:
            display(Markdown('末尾:'))
            display(obj.tail(n))
    elif isinstance(obj, pd.Series):
        display(obj.head(n))
        if len(obj) > n:
            display(Markdown('末尾:'))
            display(obj.tail(n))
    else:
        display(obj)


def month_end_index(start: str, end: str) -> pd.DatetimeIndex:
    try:
        return pd.date_range(start=start, end=end, freq='ME')
    except ValueError:
        return pd.date_range(start=start, end=end, freq='M')


def to_month_end_index(idx: Sequence[Any]) -> pd.DatetimeIndex:
    return pd.DatetimeIndex(pd.to_datetime(idx)).tz_localize(None).to_period('M').to_timestamp('M')


def to_monthly_returns(ret: pd.DataFrame) -> pd.DataFrame:
    out = ret.copy()
    if not isinstance(out.index, pd.DatetimeIndex):
        date_col = 'date' if 'date' in out.columns else out.columns[0]
        out[date_col] = pd.to_datetime(out[date_col])
        out = out.set_index(date_col)
    out.index = pd.DatetimeIndex(pd.to_datetime(out.index)).tz_localize(None)
    out = out.apply(pd.to_numeric, errors='coerce')
    try:
        out_m = (1.0 + out).resample('ME').prod(min_count=1) - 1.0
    except ValueError:
        out_m = (1.0 + out).resample('M').prod(min_count=1) - 1.0
    out_m.index = to_month_end_index(out_m.index)
    out_m.columns = [str(c) for c in out_m.columns]
    return out_m.sort_index()


def infer_existing_factor_metadata(factor_ids: Sequence[str]) -> pd.DataFrame:
    rows = []
    for fid in factor_ids:
        up = str(fid).upper()
        is_mom = any(k in up for k in ['MOM', 'INDMOM', 'REVERSAL', 'STR', '52W'])
        rows.append({
            'factor_id': str(fid),
            'factor_type': 'existing',
            'role': 'investable_signal',
            'is_momentum_related': bool(is_mom),
        })
    return pd.DataFrame(rows)


def effective_factor_metadata(data: Mapping[str, Any], cfg: BasketReplicationConfig) -> pd.DataFrame:
    meta = data.get('factor_metadata')
    if meta is None or len(meta) == 0:
        meta = infer_existing_factor_metadata(data['existing_factor_returns'].columns)
    else:
        meta = meta.copy()
    meta['factor_id'] = meta['factor_id'].astype(str)
    if 'factor_type' not in meta.columns:
        meta['factor_type'] = 'existing'
    if 'role' not in meta.columns:
        meta['role'] = 'investable_signal'
    if 'is_momentum_related' not in meta.columns:
        meta['is_momentum_related'] = meta['factor_id'].str.upper().str.contains('MOM|INDMOM|REVERSAL|STR|52W')
    meta['is_momentum_related'] = meta['is_momentum_related'].astype(bool)
    meta['excluded_from_signal'] = False
    if cfg.exclude_momentum_related_from_signal:
        meta.loc[meta['is_momentum_related'], 'excluded_from_signal'] = True
    meta['effective_role'] = meta['role']
    mask = meta['excluded_from_signal'] & (meta['role'] == 'investable_signal')
    if cfg.include_excluded_momentum_as_purification_basis:
        meta.loc[mask, 'effective_role'] = 'purification_basis'
    else:
        meta.loc[mask, 'effective_role'] = 'excluded'
    return meta


def make_synthetic_data(cfg: BasketReplicationConfig) -> Dict[str, Any]:
    rng = np.random.default_rng(cfg.seed)
    months = month_end_index(cfg.start_month, cfg.end_month)
    basket_ids = [f'BASKET_{i:02d}' for i in range(1, cfg.n_baskets + 1)]
    all_factor_ids = ['SIZE', 'VALUE', 'QUALITY', 'LOWVOL', 'PROFIT', 'MOM12', 'INDMOM'][:cfg.n_existing_factors]
    # 既存因子メタデータ。MOM/INDMOMはデフォルトでシグナルから外し、純化基準として使う。
    factor_metadata = infer_existing_factor_metadata(all_factor_ids)
    # Latent common components generate tradable basket returns.
    n = len(months)
    p = 4
    latent = np.zeros((n, p))
    for t in range(n):
        if t == 0:
            latent[t] = rng.normal(scale=0.035, size=p)
        else:
            latent[t] = 0.20 * latent[t-1] + rng.normal(loc=0.001, scale=0.030, size=p)
    loadings = rng.normal(size=(cfg.n_baskets, p))
    # Cluster baskets to create realistic collinearity.
    for k in range(cfg.n_baskets):
        loadings[k, k % p] += 1.5
    idio = rng.normal(loc=0.002, scale=0.030, size=(n, cfg.n_baskets))
    B = latent @ loadings.T + idio
    theme_basket_returns = pd.DataFrame(np.clip(B, -0.50, 0.80), index=months, columns=basket_ids)

    # Existing factors are replicable, but imperfectly, by the baskets.
    coeff = rng.normal(scale=0.35, size=(cfg.n_baskets, len(all_factor_ids)))
    for j in range(len(all_factor_ids)):
        coeff[:, j] += rng.normal(scale=0.25, size=cfg.n_baskets)
        coeff[:, j] /= max(np.sum(np.abs(coeff[:, j])), 1e-12)
    factor_noise = rng.normal(loc=0.0005, scale=0.018, size=(n, len(all_factor_ids)))
    # Add persistence to target factor residuals.
    for t in range(1, n):
        factor_noise[t] += 0.15 * factor_noise[t-1]
    F = theme_basket_returns.to_numpy() @ coeff + factor_noise
    existing_factor_returns = pd.DataFrame(np.clip(F, -0.50, 0.80), index=months, columns=all_factor_ids)
    theme_metadata = pd.DataFrame({
        'basket_id': basket_ids,
        'theme_group': [f'GROUP_{(i % 4) + 1}' for i in range(cfg.n_baskets)],
        'tradable': True,
        'shortable': True,
    })
    return {
        'theme_basket_returns': theme_basket_returns,
        'existing_factor_returns': existing_factor_returns,
        'factor_metadata': factor_metadata,
        'theme_metadata': theme_metadata,
        'meta': {'mode': 'synthetic', 'n_months': n, 'n_baskets': cfg.n_baskets, 'n_existing_factors': len(all_factor_ids)},
    }


def load_real_data(cfg: BasketReplicationConfig) -> Dict[str, Any]:
    path = cfg.data_dir / 'basket_replication_inputs.pkl'
    if not path.exists():
        raise FileNotFoundError(f'{path} not found. Set use_synthetic_data=True or provide input pickle described in README.')
    obj = pd.read_pickle(path)
    required = ['theme_basket_returns', 'existing_factor_returns']
    missing = [k for k in required if k not in obj]
    if missing:
        raise KeyError(f'basket_replication_inputs.pkl is missing required keys: {missing}')
    theme_basket_returns = to_monthly_returns(obj['theme_basket_returns'])
    existing_factor_returns = to_monthly_returns(obj['existing_factor_returns'])
    common_idx = theme_basket_returns.index.intersection(existing_factor_returns.index)
    theme_basket_returns = theme_basket_returns.loc[common_idx].sort_index()
    existing_factor_returns = existing_factor_returns.loc[common_idx].sort_index()
    factor_metadata = obj.get('factor_metadata', infer_existing_factor_metadata(existing_factor_returns.columns))
    theme_metadata = obj.get('theme_metadata', pd.DataFrame({'basket_id': theme_basket_returns.columns, 'tradable': True, 'shortable': True}))
    return {
        'theme_basket_returns': theme_basket_returns,
        'existing_factor_returns': existing_factor_returns,
        'factor_metadata': factor_metadata,
        'theme_metadata': theme_metadata,
        'meta': {'mode': 'real', 'path': str(path), 'n_months': len(common_idx), 'n_baskets': theme_basket_returns.shape[1], 'n_existing_factors': existing_factor_returns.shape[1]},
    }


def load_or_make_data(cfg: BasketReplicationConfig) -> Dict[str, Any]:
    return make_synthetic_data(cfg) if cfg.use_synthetic_data else load_real_data(cfg)


def ridge_regression_coefficients(Y: pd.DataFrame, X: pd.DataFrame, ridge: float = 1e-3, add_intercept: bool = True) -> Tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.DataFrame]:
    """Y = intercept + X B + error. Returns B, intercept, fitted, diagnostics."""
    common = Y.index.intersection(X.index)
    Yc = Y.loc[common].astype(float).dropna(how='all')
    Xc = X.loc[Yc.index].astype(float)
    valid = Yc.notna().all(axis=1) & Xc.notna().all(axis=1)
    Yc = Yc.loc[valid]
    Xc = Xc.loc[valid]
    if len(Yc) < max(3, Xc.shape[1] + 1):
        raise ValueError('Insufficient rows for ridge regression')
    if add_intercept:
        Xd = pd.concat([pd.Series(1.0, index=Xc.index, name='INTERCEPT'), Xc], axis=1)
    else:
        Xd = Xc.copy()
    Xmat = Xd.to_numpy(dtype=float)
    Ymat = Yc.to_numpy(dtype=float)
    reg = ridge * np.eye(Xmat.shape[1])
    if add_intercept:
        reg[0, 0] = 0.0
    beta_all = np.linalg.pinv(Xmat.T @ Xmat + reg) @ Xmat.T @ Ymat
    fitted = pd.DataFrame(Xmat @ beta_all, index=Yc.index, columns=Yc.columns)
    if add_intercept:
        intercept = pd.Series(beta_all[0], index=Yc.columns, name='intercept')
        coef = pd.DataFrame(beta_all[1:], index=Xc.columns, columns=Yc.columns)
    else:
        intercept = pd.Series(0.0, index=Yc.columns, name='intercept')
        coef = pd.DataFrame(beta_all, index=Xc.columns, columns=Yc.columns)
    rows = []
    for col in Yc.columns:
        y = Yc[col]
        yh = fitted[col]
        sst = float(((y - y.mean()) ** 2).sum())
        sse = float(((y - yh) ** 2).sum())
        r2 = np.nan if sst <= 0 else 1.0 - sse / sst
        corr = y.corr(yh) if y.std(ddof=1) > 0 and yh.std(ddof=1) > 0 else np.nan
        te = float((y - yh).std(ddof=1)) if len(y) > 1 else np.nan
        rows.append({'target': col, 'n_obs': len(y), 'r2': r2, 'corr': corr, 'tracking_error': te, 'target_vol': float(y.std(ddof=1)), 'replicated_vol': float(yh.std(ddof=1))})
    diag = pd.DataFrame(rows).set_index('target')
    return coef, intercept, fitted, diag


def training_window(frame: pd.DataFrame, asof: pd.Timestamp, cfg: BasketReplicationConfig, lookback: Optional[int] = None) -> pd.DataFrame:
    lb = lookback or cfg.replication_lookback_months
    hist = frame.loc[frame.index <= pd.Timestamp(asof)].tail(lb)
    return hist


def tradable_baskets(data: Mapping[str, Any]) -> list[str]:
    B = data['theme_basket_returns']
    meta = data.get('theme_metadata')
    if meta is None or 'basket_id' not in meta.columns:
        return list(B.columns)
    m = meta.copy()
    if 'tradable' not in m.columns:
        m['tradable'] = True
    ids = m.loc[m['tradable'].astype(bool), 'basket_id'].astype(str).tolist()
    return [c for c in B.columns if c in ids]


def factor_id_sets(data: Mapping[str, Any], cfg: BasketReplicationConfig) -> Tuple[list[str], list[str], pd.DataFrame]:
    meta = effective_factor_metadata(data, cfg)
    all_existing = [c for c in data['existing_factor_returns'].columns if c in meta['factor_id'].values]
    signal_ids = meta.loc[(meta['effective_role'] == 'investable_signal') & (~meta['excluded_from_signal']), 'factor_id'].astype(str).tolist()
    purification_ids = meta.loc[meta['effective_role'].isin(['investable_signal', 'purification_basis', 'risk_control_only']), 'factor_id'].astype(str).tolist()
    signal_ids = [c for c in signal_ids if c in data['existing_factor_returns'].columns]
    purification_ids = [c for c in purification_ids if c in data['existing_factor_returns'].columns]
    if not purification_ids:
        purification_ids = all_existing
    return signal_ids, purification_ids, meta


def fit_existing_factor_replicators(data: Mapping[str, Any], cfg: BasketReplicationConfig, asof: pd.Timestamp) -> Dict[str, Any]:
    B_all = data['theme_basket_returns'][tradable_baskets(data)].sort_index()
    F_all = data['existing_factor_returns'].sort_index()
    signal_ids, purification_ids, meta = factor_id_sets(data, cfg)
    target_ids = sorted(set(signal_ids).union(purification_ids), key=lambda x: list(F_all.columns).index(x))
    B_train = training_window(B_all, asof, cfg)
    F_train = F_all.loc[B_train.index, target_ids]
    if len(B_train) < cfg.min_replication_history_months:
        raise ValueError(f'Insufficient replication history as of {asof}: {len(B_train)} < {cfg.min_replication_history_months}')
    coef, intercept, fitted, diag = ridge_regression_coefficients(F_train, B_train, ridge=cfg.ridge_alpha, add_intercept=True)
    # coefficient matrix: basket x existing factor
    diag['factor_role'] = diag.index.map(lambda x: meta.set_index('factor_id').loc[x, 'effective_role'] if x in meta.set_index('factor_id').index else 'unknown')
    diag['is_signal_factor'] = diag.index.isin(signal_ids)
    return {
        'asof': pd.Timestamp(asof),
        'basket_returns_train': B_train,
        'existing_returns_train': F_train,
        'existing_coefficients': coef,
        'existing_intercepts': intercept,
        'existing_fitted_train': fitted,
        'existing_replication_diagnostics': diag,
        'existing_signal_ids': signal_ids,
        'existing_purification_ids': purification_ids,
        'factor_metadata_effective': meta,
    }


def fit_purified_theme_replicators(data: Mapping[str, Any], cfg: BasketReplicationConfig, existing_fit: Mapping[str, Any]) -> Dict[str, Any]:
    B_train = existing_fit['basket_returns_train']
    existing_ids = existing_fit['existing_purification_ids']
    C_existing = existing_fit['existing_coefficients'][existing_ids]  # basket x existing
    Y_existing_rep = B_train @ C_existing
    Y_existing_rep.columns = [f'REP_EXISTING__{c}' for c in Y_existing_rep.columns]
    # Regress raw tradable basket returns on replicated existing factors; construct tradable residual coefficients.
    beta, intercept, fitted, diag = ridge_regression_coefficients(B_train, Y_existing_rep, ridge=cfg.ridge_alpha, add_intercept=True)
    # beta: replicated existing factor x raw basket. Convert to basket coefficients.
    # raw basket k coefficient vector e_k minus existing basket-coef matrix times beta[:, k].
    I = pd.DataFrame(np.eye(B_train.shape[1]), index=B_train.columns, columns=B_train.columns)
    beta_unprefixed = beta.copy()
    beta_unprefixed.index = [idx.replace('REP_EXISTING__', '') for idx in beta_unprefixed.index]
    pure_coeff = I - C_existing @ beta_unprefixed
    pure_coeff.columns = [f'THEME_PURE__{c}' for c in pure_coeff.columns]
    tradable_pure_train = B_train @ pure_coeff
    # Diagnostics based on residual after intercept and replicated existing exposures.
    corr_rows = []
    for col in tradable_pure_train.columns:
        raw_col = col.replace('THEME_PURE__', '')
        z = tradable_pure_train[col]
        max_corr = Y_existing_rep.corrwith(z).abs().max() if Y_existing_rep.shape[1] else np.nan
        corr_rows.append({'theme_factor': col, 'raw_basket_id': raw_col, 'ann_vol_tradable_pure': z.std(ddof=1) * math.sqrt(12), 'max_abs_corr_with_replicated_existing': max_corr})
    pure_diag = pd.DataFrame(corr_rows).set_index('theme_factor')
    # align R2 diagnostics from regression of raw basket return on existing replicated factors.
    diag.index = [f'THEME_PURE__{c}' for c in diag.index]
    pure_diag = pure_diag.join(diag.add_prefix('raw_theme_on_existing_'))
    return {
        'replicated_existing_train': Y_existing_rep,
        'theme_purification_beta': beta,
        'theme_purification_intercept': intercept,
        'theme_purification_fitted_train': fitted,
        'pure_theme_coefficients': pure_coeff,
        'tradable_pure_theme_returns_train': tradable_pure_train,
        'theme_purification_diagnostics': pure_diag,
    }


def build_basket_replicated_factor_snapshot(data: Mapping[str, Any], cfg: BasketReplicationConfig, asof: pd.Timestamp) -> Dict[str, Any]:
    existing_fit = fit_existing_factor_replicators(data, cfg, asof)
    theme_fit = fit_purified_theme_replicators(data, cfg, existing_fit)
    signal_existing = existing_fit['existing_signal_ids']
    existing_coeff_signal = existing_fit['existing_coefficients'][signal_existing].copy()
    existing_coeff_signal.columns = [f'EXISTING_REP__{c}' for c in existing_coeff_signal.columns]
    pure_coeff = theme_fit['pure_theme_coefficients'].copy()
    combined_coeff = pd.concat([existing_coeff_signal, pure_coeff], axis=1).fillna(0.0)
    # Optional basket gross target at factor-composition level is not applied; only final portfolio can be scaled.
    B_all = data['theme_basket_returns'][combined_coeff.index].sort_index()
    combined_returns_history = B_all.loc[B_all.index <= pd.Timestamp(asof)] @ combined_coeff
    rows = []
    for c in combined_coeff.columns:
        ftype = 'existing_replicated' if c.startswith('EXISTING_REP__') else 'theme_purified_replicated'
        source = c.replace('EXISTING_REP__', '').replace('THEME_PURE__', '')
        rows.append({'factor_id': c, 'factor_type': ftype, 'source_id': source})
    combined_meta = pd.DataFrame(rows).set_index('factor_id')
    corr = combined_returns_history.tail(cfg.replication_lookback_months).corr()
    rank_coeff = np.linalg.matrix_rank(combined_coeff.to_numpy())
    svals = np.linalg.svd(combined_coeff.to_numpy(), compute_uv=False)
    cond_coeff = float(svals[0] / svals[-1]) if len(svals) and svals[-1] > 1e-12 else np.inf
    snapshot_diag = pd.Series({
        'asof': pd.Timestamp(asof),
        'n_baskets': combined_coeff.shape[0],
        'n_existing_signal_factors': existing_coeff_signal.shape[1],
        'n_pure_theme_factors': pure_coeff.shape[1],
        'n_combined_factors': combined_coeff.shape[1],
        'rank_combined_coefficients': rank_coeff,
        'condition_number_combined_coefficients': cond_coeff,
    })
    return {
        'asof': pd.Timestamp(asof),
        **existing_fit,
        **theme_fit,
        'combined_coefficients': combined_coeff,
        'combined_factor_returns_history': combined_returns_history,
        'combined_factor_metadata': combined_meta,
        'combined_factor_correlation': corr,
        'snapshot_diagnostics': snapshot_diag,
    }


def compute_oos_replication_panel(data: Mapping[str, Any], cfg: BasketReplicationConfig) -> Dict[str, Any]:
    B = data['theme_basket_returns'][tradable_baskets(data)].sort_index()
    Ftarget = data['existing_factor_returns'].sort_index()
    months = B.index.intersection(Ftarget.index).sort_values()
    existing_rep_rows = []
    existing_target_rows = []
    combined_rows = []
    diag_rows = []
    snapshots = {}
    for i in range(max(cfg.min_replication_history_months - 1, 0), len(months) - 1):
        asof = pd.Timestamp(months[i])
        hold = pd.Timestamp(months[i + 1])
        try:
            snap = build_basket_replicated_factor_snapshot(data, cfg, asof)
            coeff_all_existing = snap['existing_coefficients']
            rep_existing_next = B.loc[hold, coeff_all_existing.index] @ coeff_all_existing
            target_next = Ftarget.loc[hold, rep_existing_next.index]
            combined_next = B.loc[hold, snap['combined_coefficients'].index] @ snap['combined_coefficients']
            erow = {'holding_month': hold, 'asof': asof}; erow.update(rep_existing_next.to_dict()); existing_rep_rows.append(erow)
            trow = {'holding_month': hold, 'asof': asof}; trow.update(target_next.to_dict()); existing_target_rows.append(trow)
            crow = {'holding_month': hold, 'asof': asof}; crow.update(combined_next.to_dict()); combined_rows.append(crow)
            snapshots[asof] = snap
            diag_rows.append({
                'asof': asof,
                'holding_month': hold,
                'n_baskets': snap['snapshot_diagnostics']['n_baskets'],
                'n_combined_factors': snap['snapshot_diagnostics']['n_combined_factors'],
                'rank_combined_coefficients': snap['snapshot_diagnostics']['rank_combined_coefficients'],
                'condition_number_combined_coefficients': snap['snapshot_diagnostics']['condition_number_combined_coefficients'],
                'median_existing_replication_r2_in_sample': snap['existing_replication_diagnostics']['r2'].median(),
                'min_existing_replication_r2_in_sample': snap['existing_replication_diagnostics']['r2'].min(),
                'median_theme_purification_r2_in_sample': snap['theme_purification_diagnostics']['raw_theme_on_existing_r2'].median(),
                'max_abs_pure_theme_corr_with_existing': snap['theme_purification_diagnostics']['max_abs_corr_with_replicated_existing'].max(),
            })
        except Exception as exc:
            warnings.warn(f'Skipped {asof.date()} -> {hold.date()}: {type(exc).__name__}: {exc}')
            continue
    def rows_to_df(rows):
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows).set_index('holding_month').sort_index()
        return df.drop(columns='asof', errors='ignore')
    return {
        'existing_replicated_returns': rows_to_df(existing_rep_rows),
        'existing_target_returns': rows_to_df(existing_target_rows),
        'combined_factor_returns': rows_to_df(combined_rows),
        'diagnostics': pd.DataFrame(diag_rows).set_index('asof').sort_index() if diag_rows else pd.DataFrame(),
        'snapshots': snapshots,
    }


def replication_quality(replicated: pd.DataFrame, target: pd.DataFrame) -> pd.DataFrame:
    common_idx = replicated.index.intersection(target.index)
    common_cols = replicated.columns.intersection(target.columns)
    rows = []
    for c in common_cols:
        y = target.loc[common_idx, c].dropna()
        x = replicated.loc[y.index, c].dropna()
        idx = y.index.intersection(x.index)
        y = y.loc[idx]
        x = x.loc[idx]
        if len(idx) < 3:
            rows.append({'factor_id': c, 'n': len(idx)})
            continue
        beta = np.cov(x, y, ddof=1)[0, 1] / np.var(x, ddof=1) if np.var(x, ddof=1) > 0 else np.nan
        alpha = y.mean() - beta * x.mean() if np.isfinite(beta) else np.nan
        resid = y - (alpha + beta * x)
        r2 = 1.0 - float(((y - x) ** 2).sum()) / float(((y - y.mean()) ** 2).sum()) if ((y - y.mean()) ** 2).sum() > 0 else np.nan
        rows.append({
            'factor_id': c,
            'n': len(idx),
            'corr': y.corr(x),
            'tracking_error_direct': (y - x).std(ddof=1),
            'direct_r2_vs_target_mean': r2,
            'regression_beta_target_on_rep': beta,
            'regression_alpha_monthly': alpha,
            'regression_residual_te': resid.std(ddof=1),
            'target_ann_vol': y.std(ddof=1) * math.sqrt(12),
            'replicated_ann_vol': x.std(ddof=1) * math.sqrt(12),
        })
    return pd.DataFrame(rows).set_index('factor_id')


def formation_window(factor_returns: pd.DataFrame, asof: pd.Timestamp, cfg: BasketReplicationConfig, formation_months: Optional[int] = None) -> pd.DataFrame:
    j = formation_months or cfg.formation_months
    hist = factor_returns.loc[factor_returns.index <= pd.Timestamp(asof)]
    if cfg.skip_recent_months > 0:
        hist = hist.iloc[:-cfg.skip_recent_months]
    return hist.tail(j)


def normalize_factor_weights(raw: pd.Series, meta: pd.DataFrame, cfg: BasketReplicationConfig, weighting_mode: Optional[str] = None) -> pd.Series:
    mode = weighting_mode or cfg.weighting_mode
    raw = raw.replace([np.inf, -np.inf], np.nan).dropna().astype(float)
    out = pd.Series(0.0, index=meta.index, dtype=float)
    raw = raw.reindex(meta.index).dropna()
    if raw.abs().sum() <= 0:
        return out
    if mode == 'factor_equal':
        out.loc[raw.index] = raw / raw.abs().sum() * cfg.factor_gross_target
    elif mode == 'block_equal':
        blocks = meta.loc[raw.index, 'factor_type'].fillna('other')
        block_values = sorted(blocks.unique())
        block_gross = cfg.factor_gross_target / max(len(block_values), 1)
        for b in block_values:
            idx = raw.index[blocks == b]
            gross = raw.loc[idx].abs().sum()
            if gross > 0:
                out.loc[idx] = raw.loc[idx] / gross * block_gross
    else:
        raise ValueError(f'Unknown weighting_mode: {mode}')
    return out


def compute_tsfm_signal(factor_returns: pd.DataFrame, meta: pd.DataFrame, cfg: BasketReplicationConfig, asof: pd.Timestamp, mode: str = 'binary', formation_months: Optional[int] = None, allowed_factor_types: Optional[Sequence[str]] = None, weighting_mode: Optional[str] = None) -> Tuple[pd.Series, pd.DataFrame]:
    j = formation_months or cfg.formation_months
    window = formation_window(factor_returns, asof, cfg, formation_months=j)
    min_count = max(1, int(math.ceil(j * 0.6)))
    formation = (1.0 + window).prod(min_count=min_count) - 1.0
    vol_hist = factor_returns.loc[factor_returns.index <= pd.Timestamp(asof)].tail(cfg.volatility_lookback_months)
    ann_vol = vol_hist.std(ddof=1).replace(0.0, np.nan) * math.sqrt(12)
    base_meta = meta.copy()
    if allowed_factor_types is not None:
        base_meta = base_meta.loc[base_meta['factor_type'].isin(set(allowed_factor_types))]
    valid = base_meta.index.intersection(formation.dropna().index)
    signal = np.sign(formation.reindex(valid)).replace(0.0, np.nan)
    if mode == 'binary':
        raw = signal
    elif mode == 'vol_scaled':
        raw = signal / ann_vol.reindex(valid)
    else:
        raise ValueError(f'Unknown mode: {mode}')
    weights = normalize_factor_weights(raw, base_meta.loc[valid], cfg, weighting_mode=weighting_mode)
    full = pd.Series(0.0, index=meta.index, dtype=float)
    full.loc[weights.index] = weights
    table = pd.DataFrame({
        'factor_type': meta['factor_type'],
        'source_id': meta.get('source_id', pd.Series(index=meta.index, dtype=object)),
        'formation_return': formation.reindex(meta.index),
        'signal': signal.reindex(meta.index),
        'ann_vol': ann_vol.reindex(meta.index),
        'raw_weight_before_normalization': raw.reindex(meta.index),
        'factor_weight': full,
    })
    table['long_short'] = np.where(table['factor_weight'] > 0, 'long', np.where(table['factor_weight'] < 0, 'short', 'flat'))
    return full, table


def next_month(index: pd.DatetimeIndex, asof: pd.Timestamp) -> Optional[pd.Timestamp]:
    idx = pd.DatetimeIndex(index).sort_values()
    pos = idx.searchsorted(pd.Timestamp(asof), side='right')
    if pos >= len(idx):
        return None
    return pd.Timestamp(idx[pos])


def scale_basket_weights(w: pd.Series, cfg: BasketReplicationConfig) -> pd.Series:
    if cfg.basket_gross_target is None:
        return w
    gross = w.abs().sum()
    if gross > 0:
        return w / gross * cfg.basket_gross_target
    return w


def run_basket_replicated_strategy(data: Mapping[str, Any], cfg: BasketReplicationConfig, mode: str = 'binary', weighting_mode: str = 'factor_equal', allowed_factor_types: Optional[Sequence[str]] = None, strategy_name: str = 'basket_replicated_tsfm') -> Dict[str, Any]:
    B = data['theme_basket_returns'][tradable_baskets(data)].sort_index()
    months = pd.DatetimeIndex(B.index).sort_values()
    rows = []
    factor_weight_rows = []
    basket_weight_rows = []
    signal_tables = {}
    snapshots = {}
    prev_wb = pd.Series(0.0, index=B.columns)
    for i in range(max(cfg.min_replication_history_months - 1, 0), len(months) - 1):
        asof = pd.Timestamp(months[i])
        hold = pd.Timestamp(months[i + 1])
        try:
            snap = build_basket_replicated_factor_snapshot(data, cfg, asof)
            hist = snap['combined_factor_returns_history']
            if len(hist.dropna(how='all')) < max(cfg.min_signal_history_months, cfg.formation_months):
                continue
            meta = snap['combined_factor_metadata']
            fw, sig_table = compute_tsfm_signal(hist, meta, cfg, asof, mode=mode, formation_months=cfg.formation_months, allowed_factor_types=allowed_factor_types, weighting_mode=weighting_mode)
            coeff = snap['combined_coefficients']
            fw = fw.reindex(coeff.columns).fillna(0.0)
            if fw.abs().sum() <= 0:
                continue
            wb = coeff @ fw
            wb = scale_basket_weights(wb.reindex(B.columns).fillna(0.0), cfg)
            r_next = B.loc[hold].fillna(0.0)
            gross_ret = float(r_next @ wb)
            turnover = float((wb - prev_wb).abs().sum() / 2.0)
            cost = turnover * cfg.transaction_cost_bps_one_way / 10000.0
            net_ret = gross_ret - cost
            existing_cols = [c for c in coeff.columns if c.startswith('EXISTING_REP__')]
            theme_cols = [c for c in coeff.columns if c.startswith('THEME_PURE__')]
            wb_existing = (coeff[existing_cols] @ fw.reindex(existing_cols).fillna(0.0)).reindex(B.columns).fillna(0.0) if existing_cols else pd.Series(0.0, index=B.columns)
            wb_theme = (coeff[theme_cols] @ fw.reindex(theme_cols).fillna(0.0)).reindex(B.columns).fillna(0.0) if theme_cols else pd.Series(0.0, index=B.columns)
            # If final basket weights were scaled, scale the contributions as well.
            if cfg.basket_gross_target is not None:
                base = wb_existing + wb_theme
                gross_base = base.abs().sum()
                gross_wb = wb.abs().sum()
                if gross_base > 0:
                    wb_existing = wb_existing * (gross_wb / gross_base)
                    wb_theme = wb_theme * (gross_wb / gross_base)
            ret_existing = float(r_next @ wb_existing)
            ret_theme = float(r_next @ wb_theme)
            combined_next = r_next.reindex(coeff.index) @ coeff
            factor_space_ret = float(fw @ combined_next.reindex(fw.index).fillna(0.0))
            rows.append({
                'holding_month': hold,
                'asof': asof,
                'strategy': strategy_name,
                'mode': mode,
                'weighting_mode': weighting_mode,
                'gross_return': gross_ret,
                'net_return': net_ret,
                'factor_space_return': factor_space_ret,
                'existing_factor_pnl': ret_existing,
                'pure_theme_factor_pnl': ret_theme,
                'turnover': turnover,
                'transaction_cost': cost,
                'basket_gross': float(wb.abs().sum()),
                'basket_net': float(wb.sum()),
                'n_long_baskets': int((wb > 1e-12).sum()),
                'n_short_baskets': int((wb < -1e-12).sum()),
                'factor_gross': float(fw.abs().sum()),
                'existing_factor_gross': float(fw.reindex(existing_cols).abs().sum()) if existing_cols else 0.0,
                'pure_theme_factor_gross': float(fw.reindex(theme_cols).abs().sum()) if theme_cols else 0.0,
                'n_long_factors': int((fw > 1e-12).sum()),
                'n_short_factors': int((fw < -1e-12).sum()),
                'median_existing_replication_r2_in_sample': snap['existing_replication_diagnostics']['r2'].median(),
                'max_abs_pure_theme_corr_with_existing': snap['theme_purification_diagnostics']['max_abs_corr_with_replicated_existing'].max(),
            })
            factor_weight_rows.append(fw.rename(asof))
            basket_weight_rows.append(wb.rename(asof))
            signal_tables[asof] = sig_table
            snapshots[asof] = snap
            prev_wb = wb
        except Exception as exc:
            warnings.warn(f'Strategy skipped {asof.date()} -> {hold.date()}: {type(exc).__name__}: {exc}')
            continue
    rets = pd.DataFrame(rows).set_index('holding_month').sort_index() if rows else pd.DataFrame()
    return {
        'returns': rets,
        'factor_weights': pd.DataFrame(factor_weight_rows).sort_index() if factor_weight_rows else pd.DataFrame(),
        'basket_weights': pd.DataFrame(basket_weight_rows).sort_index() if basket_weight_rows else pd.DataFrame(),
        'signal_tables': signal_tables,
        'snapshots': snapshots,
    }


def run_strategy_comparison(data: Mapping[str, Any], cfg: BasketReplicationConfig, mode: str = 'binary') -> Dict[str, Any]:
    configs = {
        'combined_factor_equal': {'allowed_factor_types': None, 'weighting_mode': 'factor_equal'},
        'combined_block_equal': {'allowed_factor_types': None, 'weighting_mode': 'block_equal'},
        'existing_only': {'allowed_factor_types': ['existing_replicated'], 'weighting_mode': 'factor_equal'},
        'pure_theme_only': {'allowed_factor_types': ['theme_purified_replicated'], 'weighting_mode': 'factor_equal'},
    }
    results = {}
    for name, params in configs.items():
        results[name] = run_basket_replicated_strategy(data, cfg, mode=mode, weighting_mode=params['weighting_mode'], allowed_factor_types=params['allowed_factor_types'], strategy_name=f'{mode}_{name}')
    return results


def simple_performance_stats(returns: pd.DataFrame | pd.Series, periods_per_year: int = 12) -> pd.DataFrame:
    if isinstance(returns, pd.Series):
        returns = returns.to_frame(returns.name or 'return')
    rows = []
    for col in returns.columns:
        r = returns[col].dropna().astype(float)
        n = len(r)
        if n == 0:
            rows.append({'series': col, 'n': 0})
            continue
        ann_ret = r.mean() * periods_per_year
        ann_vol = r.std(ddof=1) * math.sqrt(periods_per_year) if n > 1 else np.nan
        sharpe = ann_ret / ann_vol if ann_vol and ann_vol > 0 else np.nan
        tval = r.mean() / (r.std(ddof=1) / math.sqrt(n)) if n > 1 and r.std(ddof=1) > 0 else np.nan
        wealth = (1.0 + r).cumprod()
        dd = wealth / wealth.cummax() - 1.0
        rows.append({'series': col, 'n': n, 'ann_return': ann_ret, 'ann_vol': ann_vol, 'sharpe': sharpe, 'mean_t_value': tval, 'max_drawdown': dd.min(), 'hit_rate': (r > 0).mean()})
    return pd.DataFrame(rows).set_index('series')


def factor_return_diagnostics(factor_returns: pd.DataFrame, meta: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    rows = []
    for c in factor_returns.columns:
        r = factor_returns[c].dropna().astype(float)
        ar1 = r.autocorr(lag=1) if len(r) > 2 else np.nan
        vol = r.std(ddof=1) * math.sqrt(12) if len(r) > 1 else np.nan
        sharpe = (r.mean() * 12) / vol if vol and vol > 0 else np.nan
        rows.append({'factor_id': c, 'n_months': len(r), 'mean_monthly': r.mean(), 'ann_vol': vol, 'sharpe': sharpe, 'ar1': ar1})
    out = pd.DataFrame(rows).set_index('factor_id')
    if meta is not None and len(meta):
        out = meta[['factor_type']].join(out, how='right')
    return out


def collect_comparison_returns(results: Mapping[str, Mapping[str, Any]], return_col: str = 'net_return') -> pd.DataFrame:
    frames = []
    for name, res in results.items():
        r = res.get('returns', pd.DataFrame())
        if not r.empty and return_col in r.columns:
            frames.append(r[return_col].rename(name))
    return pd.concat(frames, axis=1).sort_index() if frames else pd.DataFrame()


def plot_cumulative_returns(return_frame: pd.DataFrame, title: str):
    if return_frame.empty:
        print('No returns to plot.')
        return
    wealth = (1.0 + return_frame.fillna(0.0)).cumprod()
    ax = wealth.plot(figsize=(10, 4), title=title)
    ax.set_ylabel('Growth of 1')
    ax.grid(True, alpha=0.3)
    plt.show()


def plot_weight_heatmap(weights: pd.DataFrame, title: str):
    if weights.empty:
        print('No weights to plot.')
        return
    fig, ax = plt.subplots(figsize=(11, max(3, 0.25 * weights.shape[1])))
    im = ax.imshow(weights.T.to_numpy(), aspect='auto')
    ax.set_title(title)
    ax.set_yticks(range(weights.shape[1]))
    ax.set_yticklabels(weights.columns)
    step = max(1, len(weights.index) // 8)
    ax.set_xticks(range(0, len(weights.index), step))
    
    labels = []
    for d in weights.index[::step]:
        try:
            labels.append(pd.Timestamp(d).strftime('%Y-%m'))
        except Exception:
            labels.append(str(d))
    ax.set_xticklabels(labels, rotation=45, ha='right')
    fig.colorbar(im, ax=ax, label='weight')
    plt.tight_layout()
    plt.show()


def save_outputs(result: Mapping[str, Any], cfg: BasketReplicationConfig, slug: str, extra: Optional[Mapping[str, Any]] = None):
    cfg.output_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for key in ['returns', 'factor_weights', 'basket_weights']:
        if key in result and isinstance(result[key], pd.DataFrame) and not result[key].empty:
            p = cfg.output_dir / f'{slug}_{key}.csv'
            result[key].to_csv(p)
            paths.append(p)
    if extra:
        for name, obj in extra.items():
            if isinstance(obj, pd.DataFrame) and not obj.empty:
                p = cfg.output_dir / f'{slug}_{name}.csv'
                obj.to_csv(p)
                paths.append(p)
    print('Saved:')
    for p in paths:
        print(' -', p)
