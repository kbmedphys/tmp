
# Theme-basket Replicated Factor Momentum Notebooks

この一式は、既存因子と純化テーマ因子を個別銘柄ではなくテーマバスケット・リターンで複製し、文献に基づく factor momentum 戦略をテーマバスケットのロングショートで実装するためのノートブックです。

## ファイル

- `00_theme_basket_return_replication_diagnostics.ipynb`: 既存因子のテーマバスケット複製、純化テーマ因子の構築、OOS複製精度を確認。
- `01_binary_basket_replicated_combined_factor_tsfm_12m.ipynb`: 12カ月 Binary TSFM。
- `02_vol_scaled_basket_replicated_combined_factor_tsfm_12m.ipynb`: 12カ月 Vol-scaled TSFM。

## 実データ入力

`use_synthetic_data=False` に変更し、`./data/basket_replication_inputs.pkl` に以下を保存してください。

```python
{
    "theme_basket_returns": theme_basket_returns,
    "existing_factor_returns": existing_factor_returns,
    "factor_metadata": factor_metadata,
    "theme_metadata": theme_metadata,
}
```

`theme_basket_returns` と `existing_factor_returns` は、日次または月次のリターンDataFrameです。日次の場合は月次複利に変換します。

## 実装の中心式

既存因子のテーマバスケット複製:

$$ f_{m,t}=\alpha_m+b_m'R^B_t+\varepsilon_{m,t}. $$

純化テーマ因子:

$$ R^{B_k}_t=\alpha_k+\beta_k'\hat F_t+z_{k,t}. $$

取引可能な純化テーマ因子:

$$ z^{tradable}_{k,t}=R^{B_k}_t-\beta_k'\hat F_t. $$

TSFM:

$$ w^F_{h,t}\propto \operatorname{sign}\left(\prod_{s=t-11}^{t}(1+Y^{rep}_{h,s})-1\right). $$

最終テーマバスケットウェイト:

$$ w^B_t=C_t w^F_t. $$

## 注意

この実装は、文献の「ファクター自身のリターンをタイミングする」趣旨に沿いますが、売買単位をテーマバスケットに制限するため、既存因子の完全複製は保証されません。必ず `00` の OOS replication quality、tracking error、rolling R²を確認してください。
