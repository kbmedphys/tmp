# Frazzini (2006) レビュー: The Disposition Effect and Underreaction to News

## 1. 文献情報と再現目的

- 対象論文: Andrea Frazzini, "The Disposition Effect and Underreaction to News", The Journal of Finance, Vol. LXI, No. 4, August 2006.
- 原本PDF: `docs/sources/The Disposition Effect and Underreaction to news - Frazzini.pdf`
- Phase Aの目的: 再現実装に必要な仕様を整理する。実装は行わない。
- Phase Bの基本単位: この論文1本に対して1つの `.ipynb` で完結させる。

この論文は、投資家が含み損を抱えた銘柄を売りにくく、含み益を抱えた銘柄を売りやすいという disposition effect が、企業ニュースへの価格反応を妨げ、ニュース後のリターン予測可能性を生むという仮説を検証する。特に、ニュースの符号と既存株主の含み損益の符号が同じとき、過小反応が強くなるという非対称な予測が中心である。

## 2. 中心仮説

### 2.1 Disposition effect

Disposition effect は「投資家が損失を抱えたポジションを保有し続け、利益を抱えたポジションを実現しやすい傾向」である。論文は Shefrin and Statman (1985) と Odean (1998) 以降の証拠を踏まえ、プロの投資家にもこの傾向が残ると位置づけている。

### 2.2 Underreaction仮説

論文の Hypothesis UR は次の内容である。

- 現在の株主の多くが含み損を抱えている銘柄では、悪いニュースへの価格下落が不十分になり、その後も負のドリフトが続く。
- 現在の株主の多くが含み益を抱えている銘柄では、良いニュースへの価格上昇が不十分になり、その後も正のドリフトが続く。
- ニュースの符号を固定したとき、capital gains overhang がニュース後リターンを予測する。

直感は、含み損銘柄では既存株主が売りを控えるため悪いニュースが価格へ十分に反映されにくく、含み益銘柄では既存株主の利益確定売りが良いニュースへの価格上昇を抑える、というものである。したがって「良いニュースかつ含み益」「悪いニュースかつ含み損」の組み合わせでドリフトが最大になる。

参照箇所: pp. 2022-2023, 2028-2030。

## 3. 中心変数

### 3.1 Reference price

株式ごとに、現在の株主が保有している株式の取得価格を加重平均した参照価格を作る。

```text
RP_t = phi^{-1} * sum_{n=0}^{t} V_{t,t-n} * P_{t-n}
phi = sum_{n=0}^{t} V_{t,t-n}
```

- `P_t`: 月末 `t` の株価。
- `V_{t,t-n}`: `t-n` 時点で購入され、時点 `t` でも元の購入者に保有されている株数。
- `phi`: 正規化定数。

部分売却がある場合、論文の主仕様では FIFO を仮定し、売却株数を古い取得ロットから順に対応させる。脚注では LIFO、HIFO、最後の取引価格、最後の買付価格、過去売買価格の平均を使っても主要結果は変わらないとされるが、再現の主仕様は FIFO とする。

参照箇所: pp. 2022-2023, Table I。

### 3.2 Capital gains overhang

中心的な予測変数は capital gains overhang である。

```text
g_t = (P_t - RP_t) / P_t
```

- `g_t > 0`: 現在価格が参照価格を上回る。既存株主は平均的に含み益。
- `g_t < 0`: 現在価格が参照価格を下回る。既存株主は平均的に含み損。

Table Iでは、1980-2002年の平均的なカバレッジは CRSP銘柄数ベースで72.7%、時価総額ベースで84.4%である。小型・低流動性銘柄は mutual fund holdings が乏しいため、overhang が欠損しやすい。

参照箇所: pp. 2023-2025, Table I。

### 3.3 Residual overhang

Raw overhang は過去リターン、サイズ、売買回転率と相関するため、頑健性および主表の一部では residual overhang も使う。

実装仕様:

- 各月のクロスセクションで raw overhang を説明変数群に回帰する。
- 残差を residual overhang として使う。
- Table V/VIの説明では、説明変数は過去12か月リターン、過去36か月リターン、過去12か月平均 turnover、前月末時価総額の対数。
- Table II model 2に近づける場合は、NASDAQ dummy と turnover の相互作用、過去リターンと turnover の相互作用も含める。

Phase Bでは、まず Table V/VI caption に明示された簡潔な residual overhang を実装し、必要に応じて Table II model 2仕様へ拡張する。

参照箇所: pp. 2025-2026, 2029, Table II, Table V, Table VI。

## 4. データ仕様

### 4.1 主要データ

- 株式リターン・会計データ: CRSP/COMPUSTAT merged database、1980年1月から2002年12月。
- Mutual fund holdings: Thomson Financial CDA/Spectrum Mutual Funds database、1980年1月から2002年12月。処理後データには1980年1月から2003年12月の四半期末保有が含まれるが、主要分析期間は1980-2002年。
- Quotes and trades: NYSE TAQ、1993-2002年。取引費用推定に使う。
- Analysts' recommendations: I/B/E/S、1993-2002年。Appendixの analyst revisions 検証に使う。
- Fama-French factors and risk-free rate: Ken French data library。月次 FF3 alpha 推定に使う。

参照箇所: pp. 2023-2024, 2030, 2035-2036, 2041-2044。

### 4.2 Holdingsデータの時点

Thomson holdings には以下の2種類の日付がある。

- `RDATE`: ファンドポートフォリオのスナップショット日。
- `FDATE`: Thomson が割り当てた vintage date。通常、提出の対応四半期末。

論文では、保有情報は file date から30日遅れで公開情報になると仮定する。Phase Bでは、保有情報は `available_date = FDATE + 30 calendar days` 以降にしか使わない。月次シグナルに落とす場合、形成月初時点で `available_date` が過ぎている最新保有情報だけを使う。

参照箇所: p. 2024。

### 4.3 Holdingsデータのフィルタ

論文は、CRSPへマージした後、誤報告・収集エラーと思われる観測を欠損にする。

1. ファンドのある銘柄保有株数が、その日の当該銘柄発行済株式数を超える。
2. ファンドのある銘柄保有価値が、CDA上のファンド総資産を超える。
3. 発行済株式数がゼロ。
4. Thomson のファンド総資産と CRSP価格からの含意価値が100%超乖離。

株式分割は調整する。売買価格の代理変数として report date の株価を使う。

参照箇所: p. 2024。

## 5. Mutual fundsにおけるdisposition effectの確認

Table IIIは mutual funds について、実現益比率 `PGR` と実現損比率 `PLR` を比較する。

- `PGR`: 実現益 / (実現益 + 含み益)
- `PLR`: 実現損 / (実現損 + 含み損)

全体では `PGR - PLR` が約3%で、統計的に強い。前年リターンの低いファンドでは差が約8%、t-statistic 25.5で、負けているファンドほど損失実現を避ける傾向が強い。

この部分は主戦略の再現に必須ではないが、論文のメカニズム確認としてレビューに含める。Phase Bで完全再現を狙う場合は、最初にポートフォリオ戦略を再現し、その後に Table III を追加検証とする。

参照箇所: pp. 2027-2028, Table III。

## 6. ニュース変数とポートフォリオ構築

### 6.1 Earnings news

主検証では、決算発表日の周辺リターンをニュース代理変数にする。

```text
earnings_news_i = sum of market-model abnormal returns from event day -2 to event day +1
```

- 対象は各月時点で利用可能な「直近の決算発表」。
- event day -2 から +1 までを累積する理由は、情報漏れ、事前発表、低頻度取引銘柄の遅延反応を考慮するため。
- ニュースは昇順に並べ、下位20%を bad news、上位20%を good news とする。

参照箇所: pp. 2029-2031, Table IV。

### 6.2 月次形成タイミング

各暦月の初めに、以下の情報だけで銘柄をソートする。

- 利用可能な直近決算ニュースの累積異常リターン。
- 前月末時点の capital gains overhang。

ここで重要なのは、保有データの30日公開遅れを反映したうえで、形成月初に観測可能な overhang だけを使うことである。前月末 `g_t` を使う場合でも、その算出に必要な holdings が形成時点で未公開なら使わない。

参照箇所: pp. 2029-2030。

### 6.3 25ポートフォリオ

各月、earnings news と overhang を独立に5分位へ分ける。

- News quintile 1: bad news。
- News quintile 5: good news。
- Overhang quintile 1: 最も負、つまり大きな含み損。
- Overhang quintile 5: 最も正、つまり大きな含み益。

交差により 5 x 5 = 25 ポートフォリオを作る。各ポートフォリオ内は等ウェイト。論文は比較可能性のため等ウェイトを主仕様とし、価値加重でも同様の結果と述べる。

参照箇所: p. 2029。

### 6.4 Rolling portfolio

論文は Jegadeesh and Titman (1993) 型の calendar-time rolling portfolio を使う。

実装仕様:

- 毎月、新しいシグナルに基づく sleeve を形成する。
- holding period `H` か月の戦略では、各 sleeve を `H` か月保有する。
- 各月の戦略リターンは、その月にアクティブな sleeve の等ウェイト平均とする。
- 各 sleeve 内の銘柄は月次で等ウェイトへリバランスする。
- 主結果のベンチマークは `H = 3` か月。Table IV/V/VIは `H = 1, 2, 3` を中心に、Table V/VIIIでは `H = 6, 12` も報告する。

論文は calendar-time regression によりイベント株のクロス相関問題を緩和する設計である。

参照箇所: pp. 2029-2030, 2038-2039。

## 7. 主要戦略

### 7.1 PEAD baseline

Baseline PEAD strategy は、overhang を使わず earnings news だけで作る。

- Long: good news quintile 5。
- Short: bad news quintile 1。
- H=3の FF3 alpha は月次 1.242%、t-statistic 10.78。

これは通常の post-earnings announcement drift がサンプルで存在することの確認である。

参照箇所: pp. 2030-2031, Table IV。

### 7.2 Overhang spread

論文の最大利益戦略。

- Long: good news かつ overhang quintile 5、つまり大きな含み益。
- Short: bad news かつ overhang quintile 1、つまり大きな含み損。

H=3の主結果:

- Raw overhang: L/S alpha 2.433% per month、t-statistic 6.60。
- Residual overhang: L/S alpha 2.201% per month、t-statistic 6.56。

Long leg と short leg の両側で、ニュースと含み損益の符号が同じである。論文の仮説では、この組み合わせでニュース反応が最も遅くなる。

参照箇所: pp. 2030-2032, Table V。

### 7.3 Negative overhang spread

反対極の戦略。

- Long: good news かつ overhang quintile 1、つまり大きな含み損。
- Short: bad news かつ overhang quintile 5、つまり大きな含み益。

H=3の主結果:

- Raw overhang: L/S alpha 0.092% per month、t-statistic 0.28。
- Residual overhang: L/S alpha -0.160% per month、t-statistic -0.54。

ニュースと含み損益の符号が一致しないため、強いドリフトは出ない。これは単なるPEADや流動性ではなく、符号付きの disposition effect と整合的である。

参照箇所: pp. 2030-2032, Table V。

### 7.4 Overhang quintile別の単調性

Table VIでは、`j = 1, ..., 5` について次の long-short portfolio を作る。

```text
portfolio j:
  long  = good news stocks in overhang quintile j
  short = bad news stocks in overhang quintile 6 - j
```

- `j = 5`: overhang spread。
- `j = 1`: negative overhang spread。

H=3では、raw overhang の portfolio 5 alpha は 2.433%、portfolio 1 alpha は 0.092%、差は 2.341%、t-statistic 3.64。residual overhang でも差は 2.361%、t-statistic 4.16。overhang spread が大きいほど将来 alpha が大きくなる。

参照箇所: pp. 2031-2034, Table VI。

## 8. Alpha推定

月次リターン系列に対して Fama-French 3 factor regression を行う。

```text
R_{p,t} - R_{f,t}
  = alpha
  + beta_mkt * MKT_t
  + beta_smb * SMB_t
  + beta_hml * HML_t
  + epsilon_t
```

- 目的変数: rolling strategy の月次超過リターン。
- 説明変数: 同月の FF3 factors。
- alpha は月次パーセントで報告。

Table VIIでは H=3の overhang spread について、long-short の factor loading は統計的に強くなく、alpha は 2.433%である。これは、標準的なFF3リスクでは説明しにくいことを示す。

参照箇所: pp. 2030, 2034-2035, Table VII。

## 9. 取引費用とサイズ

論文は、TAQを使って effective spread と commission を推定し、overhang spread の実行可能性を検証する。

主な仕様:

- TAQの各銘柄について、各月にランダムな1取引日を選ぶ。
- 取引価格と bid-ask midpoint の絶対乖離の2倍を effective spread とする。
- Lee and Ready (1991) 型の price/tick test で buyer/seller initiated を推定する。
- commission は CIGNA financial services の discount brokerage schedule を使う。
- TAQは1993-2002年のみなので、その期間の平均費用を1980-1992年にも妥当な近似として使う。
- split-adjusted price が前月末 $3 未満の銘柄は除外する。
- サイズ別検証はNYSEブレークポイントで5分位。

Table VIIIの主要結果:

- 全銘柄、H=3: FF3 alpha 2.447%、取引費用控除後 net alpha 0.885%。
- 全銘柄、H=6: FF3 alpha 1.922%、取引費用控除後 net alpha 1.062%。
- 最小サイズ分位ではH=3の net alpha がほぼゼロだが、中型以上では費用控除後も有意な部分が多い。

Phase Bの主再現では取引費用なしの Table IV-VI を優先し、取引費用は拡張検証とする。

参照箇所: pp. 2035-2038, Table VIII。

## 10. Appendixの代替仕様と再現優先度

### 10.1 優先度A: residual overhang

Raw overhang の代替として residual overhang を使う。主表 Table V/VI に含まれるため、主再現の一部として扱う。

期待結果:

- H=3 overhang spread alpha 2.201%。
- H=3 negative residual overhang spread alpha -0.160%。

参照箇所: pp. 2029-2032, Table V, Table VI。

### 10.2 優先度B: SUEによるニュース代理変数

Standardized unexpected earnings を使う。

```text
SUE_t = (e_t - e_{t-4}) / sigma
```

- `e_t`: 月 `t` 時点で利用可能な直近四半期EPS。
- `e_{t-4}`: 4四半期前EPS。
- `sigma`: 過去8四半期の unexpected earnings `e_t - e_{t-4}` の標準偏差。

Table A1 Panel Gでは、H=3の overhang spread alpha が 1.738%、negative overhang spread alpha が 0.339%。event-day return 代理変数より小さいが、符号付き overhang の予測と整合的である。

参照箇所: pp. 2041, 2043, Table A1。

### 10.3 優先度B: analyst recommendation revisions

I/B/E/S Recommendations Detail を使い、アナリスト推奨変更をニュースイベントにする。

- I/B/E/S rating code: 1 strong buy から 5 sell。
- 各アナリスト・銘柄について、直近記録からの rating change を計算する。
- 少なくとも1件の revision が起きた取引日をイベント日とする。
- ニュース代理変数は revision event 周辺の market-model cumulative abnormal return。
- サンプル期間は1993年1月から2002年12月。

Table A1 Panel Hでは、H=3の overhang spread alpha が 2.761%、negative overhang spread alpha が -0.811%。決算に限らず、企業固有ニュース一般でも同じ非対称性が出る。

参照箇所: pp. 2043-2044, Table A1。

### 10.4 優先度C: turnover-based reference price

Mutual fund holdings がない期間にも使える代替として、Grinblatt and Han (2005) 型の turnover-based overhang を使う。

```text
Vhat_{t,t-n} = TO_{t-n} * product_{tau=1}^{n-1} (1 - TO_{t-n+tau})
RP_t = phi^{-1} * sum_{n=0}^{t} Vhat_{t,t-n} * P_{t-n}
```

- `TO_t`: 月 `t` の turnover。
- `Vhat_{t,t-n}`: `t-n` に取引され、その後 `t` まで再取引されない確率に対応する重み。
- 直近月の turnover が高ければ、参照価格は直近価格へ寄る。
- 過去のある月の turnover が高く、その後の turnover が低ければ、その月の価格が参照価格へ強く反映される。

Table A1:

- 1963-1979年: overhang spread alpha 2.547%、negative overhang spread alpha 0.012%。
- 1980-2003年: overhang spread alpha 1.920%、negative overhang spread alpha 0.440%。

Holdingsベースよりノイズが大きいが、out-of-sample evidence として有用である。

参照箇所: pp. 2041-2042, Table A1。

### 10.5 優先度C: mutual fund ownership / index funds

Mutual fund holdings が全株主の代表かどうかを検証する。

- Mutual fund ownership の中央値で高低に分割しても、overhang spread は大きく残る。
- Index funds と ETFs の holdings だけで overhang を作ると、overhang spread と negative overhang spread の差はほぼ消える。

Table A1:

- Low mutual fund ownership: overhang spread alpha 2.435%。
- High mutual fund ownership: overhang spread alpha 2.284%。
- Only index funds: overhang spread alpha 0.641%、negative overhang spread alpha 0.599%。

これは、単なる holdings coverage ではなく、disposition-prone managers の含み損益が重要であるという解釈を支える。

参照箇所: pp. 2040-2041, Table A1。

### 10.6 優先度C: characteristics-adjusted returns

サイズ、book-to-market、過去12か月リターンに基づく 5 x 5 x 5 の characteristic portfolio を作り、event stock に対して同じセルの非イベント銘柄をマッチさせる。

- NYSE breakpoint と conditional sort を使う。
- マッチ銘柄は、各 characteristic の距離順位を合算して最小のものを選ぶ。
- マッチは次イベントまたは delisting まで維持する。
- マッチが delisting または earnings announcement により使えなくなったら、次順位の銘柄へ置き換える。
- この手順は look-ahead bias を避けるための設計である。

Table A1 Panel Fでは、overhang spread alpha が 1.851%、negative overhang spread alpha が -0.025%。

参照箇所: pp. 2042-2043, Table A1。

## 11. Phase B実装でのリーク防止仕様

このプロジェクトのルールに従い、特徴量は `t` までの情報で計算し、`t+1` 以降のリターン予測に使う。Frazzini再現では特に以下を固定する。

### 11.1 データ利用可能日の管理

- Holdings は `FDATE + 30 calendar days` 以降のみ使用可能。
- 決算ニュースの event-window return は event day +1 の市場データが利用可能になってから使用可能。
- 月初形成時点で未確定・未公開の holdings、earnings announcement、return は使わない。
- 前月末時価総額、前月末価格、過去リターン、過去turnoverは、形成月初に確定しているものだけを使う。

### 11.2 月次リバランス

- 各月の第1営業日の寄り前に、直前営業日までに観測可能な情報だけでウェイトを決定する。
- 決定したウェイトは当月の第1営業日から適用する。月末シグナルとして実装する場合も、月末時点で決めたウェイトは翌営業日以降のリターンにだけ適用する。
- 各月の sleeve 内は等ウェイトへリバランスする。
- Holding period `H` の重複ポートフォリオでは、同じ月にアクティブな `H` 個の sleeve を等ウェイトで平均する。

### 11.3 リターン計算

- Delisting return を含める。CRSPを使う場合、通常月は `RET`、上場廃止月は `RET_TOTAL = (1 + RET) * (1 + DLRET) - 1` を使う。`RET` が欠損で `DLRET` のみ利用可能なら `RET_TOTAL = DLRET` とし、両方欠損ならその月の銘柄リターンを欠損扱いにする。
- Short leg は bad news 側のポートフォリオリターンを差し引く。
- Long-short return は long leg return minus short leg return。
- FF3 alpha は月次超過リターンで推定する。

### 11.4 Universeと欠損

- Overhang が欠損する銘柄は overhang sort から除外する。
- PEAD baseline は利用可能な earnings news を持つ全銘柄で構築する。
- overhang sort は各月の利用可能銘柄内で5分位を作る。
- 価格や発行済株式数が異常な銘柄は、論文の holdings filter と CRSP標準処理に従って除外する。

## 12. Phase Bの実装順序案

1. データ読み込みとID整備
   - CRSP/COMPUSTAT、holdings、earnings announcement、FF factors を月次パネルへ整備する。
   - CUSIPとPERMNOの対応、split adjustment、delisting return を明示する。

2. Holdingsベースの `RP_t` と `g_t` 作成
   - holdings の available date を反映する。
   - FIFO mental book により、保有ロットを取得価格へ対応させる。
   - Table I相当の summary statistics で符号・分布・カバレッジを確認する。

3. Earnings news 作成
   - market model abnormal return を event day -2 から +1 で累積する。
   - 各月・銘柄について、形成時点で利用可能な直近イベントを紐づける。

4. Portfolio formation
   - news 5分位、overhang 5分位を独立ソートで作る。
   - PEAD baseline、overhang spread、negative overhang spread、portfolio `j` を構築する。

5. Rolling returnsとFF3 alpha
   - `H = 1, 2, 3` をまず実装する。
   - 主結果は `H = 3`。
   - Table IV-VII相当の alpha と t-statistic を出す。

6. Robustness
   - residual overhang を追加する。
   - 余力があれば SUE、analyst revisions、turnover-based overhang、取引費用を追加する。

## 13. 主要再現ターゲット

最初のnotebookでは以下を最低限の成功基準とする。

- Table I相当: overhang の平均、中央値、標準偏差、P20/P80、カバレッジ。
- Table IV相当: PEAD baseline の long-short alpha。
- Table V相当: overhang spread と negative overhang spread の alpha。
- Table VI相当: overhang quintile別 long-short alpha と `5 - 1` 差。
- Table VII相当: H=3の FF3 alpha と factor loading。

数値の完全一致はデータベンダー版、IDリンク、delisting処理、決算日データの差で難しい可能性がある。再現の第一目標は、ニュースと overhang の符号が一致するポートフォリオで alpha が大きく、negative overhang spread では有意性が弱いという非対称パターンを再現することである。

## 14. 抽出・確認メモ

- PDFは30ページ。
- `pdfplumber` で本文と数式定義を抽出した。
- 表V、表VI、表VIIIは `pdfplumber` では横向き表が逆順に崩れたため、`pypdf` 抽出とページ画像で表Vを確認して数値を補正した。
- 追加依存は導入していない。使用環境は `/Users/kencharoff/workspace/envs/base/.venv/bin/python`。
