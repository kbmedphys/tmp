# 純化テーマファクター複製：テーマバスケット＋東証33業種指数

## 1. 実装概要

既存の `theme_basket_mimicking.py` を変更せず、拡張モジュール
`theme_plus_industry_mimicking.py` を追加した。

実装は、各純化テーマについて次の系列を同一のreturn date・themeで生成し、比較する。

1. `purified`：純化テーマファクターリターン
2. `stock_coefficient`：個別銘柄 coefficient replica
3. `theme_only`：テーマバスケットL/S replica
4. `industry_only`：東証33業種指数バスケットL/S replica
5. `theme_plus_industry`：テーマバスケット＋33業種指数バスケットL/S replica
6. `theme_plus_industry_published`：5の業種脚を公表業種指数リターンへ置換した系列

個別銘柄ターゲットを \(m^*_{k,t}\)、テーマバスケットを \(P_t\)、
業種バスケットを \(S_t\)、結合基底を \(W_t=[P_t,S_t]\) とし、対象テーマごとに

\[
\min_x (W_tx-m^*_{k,t})'\Sigma_t(W_tx-m^*_{k,t})
\]

subject to

\[
A_t'W_tx=0,\qquad z_{k,t}'W_tx=1
\]

を解く。`A_t` は純化推定時と同一の中立化行列、`z_{k,t}` は対象純化テーマの
エクスポージャーである。

combined問題にはテーマ単独解を業種ウェイト0として埋め込めるため、純粋な
ex-ante tracking lossがテーマ単独より悪化した場合は、テーマ単独解へ戻す
非悪化ガードを実装している。

## 2. 成果物

| ファイル | 内容 |
|---|---|
| `theme_basket_mimicking.py` | 既存の純化・個別銘柄・テーマバスケット実装 |
| `theme_plus_industry_mimicking.py` | 33業種拡張本体 |
| `run_theme_plus_tse33_replication.py` | 本番・合成データ共通CLI |
| `example_theme_plus_tse33_config.json` | 本番向けConfig例 |
| `01_theme_plus_tse33_replication_implemented_executed.ipynb` | 実行済み診断ノートブック |
| `test_theme_plus_industry_mimicking.py` | 単体・統合テスト |
| `theme_plus_tse33_replication_requirements.md` | 定式化・要件定義 |

## 3. 本番入力スキーマ

pickleは、既存入力に以下を追加する。

### 3.1 既存必須入力

```python
{
    "stock_returns": pd.DataFrame,                 # return date × security
    "barra_exposures_by_date": dict[date, pd.DataFrame],
    "theme_exposures_by_date": dict[date, pd.DataFrame],
    "theme_basket_weights_by_date": dict[date, pd.DataFrame],
}
```

- `stock_returns` は、原則として配当・分割調整済みの個別銘柄トータルリターン。
- 各スナップショットDataFrameの行IDは `stock_returns.columns` と一致させる。
- `theme_basket_weights_by_date` は stock × tradeable theme basket。
- 本番Configでは `basket_fallback_to_theme_exposures=False` とする。

### 3.2 33業種構成ウェイト：スナップショット形式

```python
{
    "industry_basket_weights_by_date": {
        pd.Timestamp("2025-01-31"): pd.DataFrame(...),  # stock × 33 industry
        ...
    }
}
```

各列は1つの業種指数、各列合計は原則1、構成ウェイトは原則非負とする。
辞書キーは、そのスナップショットが利用可能であることを保証できる日付にする。

point-in-time監査を強化する場合は、次も渡す。

```python
{
    "industry_basket_metadata_by_date": {
        pd.Timestamp("2025-01-31"): {
            "effective_date": pd.Timestamp("2025-01-31"),
            "knowledge_date": pd.Timestamp("2025-01-31"),
            "point_in_time_ok": True,
            "source": "vendor/source name"
        },
        ...
    }
}
```

`effective_date` または `knowledge_date` がexposure dateを超える場合、処理を停止する。

### 3.3 33業種構成履歴：long形式

スナップショットを直接用意しない場合は、次のDataFrameを渡せる。

```python
{
    "industry_constituents_long": pd.DataFrame({
        "security_id": ...,
        "industry_code": ...,
        "weight": ...,
        "effective_date": ...,
        "knowledge_date": ...,
    })
}
```

任意列として `industry_name`, `weight_type`, `source`, `version` を保持できる。
`build_industry_weight_snapshots_from_long` は、各exposure dateについて

```text
effective_date <= exposure_date
knowledge_date <= exposure_date
```

を満たす最新の、業種単位で整合した一つの配信バージョンを選択する。
同一業種・同一スナップショット内に重複銘柄がある場合はエラーにする。

### 3.4 業種指数時系列

リターンを直接渡す場合：

```python
{
    "industry_index_returns": pd.DataFrame  # return date × 33 industry
}
```

指数値を渡す場合：

```python
{
    "industry_index_levels": pd.DataFrame   # date × 33 industry
}
```

後者では `industry_index_input_kind="levels"` とする。列IDは構成ウェイトの業種列IDと
一致させる。配当込み／配当なしの定義は、個別銘柄リターンの定義と揃える。

### 3.5 リスクモデル入力（任意）

フルファクター共分散を使う場合：

```python
{
    "factor_covariances_by_date": dict[date, pd.DataFrame],
    "risk_factor_exposures_by_date": dict[date, pd.DataFrame],
    "specific_variances_by_date": dict[date, pd.Series],
}
```

`risk_factor_exposures_by_date` がなければ、`barra_exposures_by_date` を使用する。
`TrackingRiskOperator` は \(XFX'+D\) を演算子として適用するため、銘柄数×銘柄数の
共分散行列を明示的に構築しない。

`augmented_tracking_risk_model="auto"` の優先順位は次のとおり。

1. factor covariance＋specific variance
2. shrinkage sample covariance
3. diagonal variance proxy

## 4. 実行方法

### CLI：本番データ

```bash
python run_theme_plus_tse33_replication.py \
  --input-pickle data/theme_factor_inputs_with_tse33.pkl \
  --config-json example_theme_plus_tse33_config.json \
  --output-dir theme_plus_tse33_outputs \
  --strict-acceptance
```

### CLI：合成33業種テスト

```bash
python run_theme_plus_tse33_replication.py \
  --synthetic \
  --config-json example_theme_plus_tse33_config.json \
  --output-dir theme_plus_tse33_outputs_synthetic \
  --strict-acceptance
```

合成実行では、`n_stocks >= n_industries * industry_min_constituents` を満たす必要がある。

### Python API

```python
import theme_plus_industry_mimicking as aug

cfg = aug.Config(
    input_pickle="data/theme_factor_inputs_with_tse33.pkl",
    use_synthetic_if_missing=False,
    basket_fallback_to_theme_exposures=False,
    industry_expected_count=33,
    augmented_tracking_risk_model="auto",
)

data = aug.load_or_generate_augmented_inputs(cfg)
purified, _ = aug.estimate_theme_returns(data, cfg)
stock_rep, _ = aug.stock_replicated_theme_returns(
    data, cfg, purified, mode="coefficient", return_diagnostics=True
)
replicated, artifacts = aug.augmented_replicated_theme_returns(data, cfg, purified)
comparison = aug.compare_basis_extensions(purified, stock_rep, replicated, cfg)
self_tests = aug.run_augmented_basis_self_tests(cfg)
acceptance = aug.build_augmented_acceptance_checks(
    cfg, purified, stock_rep, artifacts, self_tests
)
```

各時点のcombined基底ウェイトを直接取得する場合：

```python
base_weights, lookthrough_stock_weights, diagnostics = (
    aug.construct_augmented_mimicking_portfolios(
        data,
        cfg,
        date=pd.Timestamp("2025-01-31"),
        basis_mode="theme_plus_industry",
    )
)
```

`base_weights` の行は `THEME::<id>` と `INDUSTRY::<id>`、列は複製対象テーマである。
正値がロング、負値がショートである。

## 5. 主な実装機能

- 33業種のpoint-in-time構成スナップショット生成・検証
- テーマ／業種／combined基底の共通API
- 同一中立化制約・対象テーマエクスポージャー制約
- equality-constrained PSD QPのSVD／null-space解法
- 冗長制約、rank deficiency、条件数の診断
- hard解不可能時の明示的soft-penalty fallback
- combined ex-ante TE非悪化ガード
- factor covarianceをN×N行列化しないリスク演算子
- 構成銘柄ルックスルーと公表業種指数のリターン照合
- baseウェイト、ルックスルー個別銘柄ウェイト、turnover、gross/netの診断
- realized TE、RMSE、相関、alpha/beta、rolling指標
- paired squared-loss差のHAC統計量とmoving-block bootstrap
- CSV、Parquet、図表、Config、manifestの保存

## 6. 出力ファイル

主要ファイルは次のとおり。

```text
purified_theme_returns.csv
stock_coefficient_replicated_theme_returns.csv
theme_only_replicated_theme_returns.csv
industry_only_replicated_theme_returns.csv
combined_replicated_theme_returns.csv
combined_published_index_replicated_theme_returns.csv

augmented_mimicking_diagnostics.csv
basis_extension_rank_diagnostics.csv
combined_base_weights_long.parquet
industry_basket_weights_long.parquet
industry_index_returns_reconstructed.csv
industry_index_reconciliation.csv
basis_return_identity_checks.csv

basis_extension_metrics_by_theme.csv
basis_extension_metrics_aggregate.csv
basis_extension_te_reduction_by_theme.csv
basis_extension_paired_loss_tests.csv
basis_extension_rolling_metrics.parquet
basis_extension_coverage.csv

basis_extension_acceptance_checks.csv
basis_extension_self_tests.csv
basis_extension_config.json
output_manifest.json
run_summary.json
```

## 7. 受入検証

実行済みノートブックは、60か月、198銘柄、14テーマ、33業種、factor covariance方式の
合成データで検証した。合成データは業種方向がテーマ単独残差を説明するように設計された
検証用データであり、実データの改善幅を予測するものではない。

| チェック | 実測値 | 許容値 |
|---|---:|---:|
| 純化リターンと個別銘柄coefficient replicaの最大誤差 | `7.50e-10` | `1.00e-7` |
| 基底経由と個別銘柄ルックスルー経由の最大恒等式誤差 | `3.33e-16` | `1.00e-10` |
| hard解の最大中立化残差 | `8.86e-14` | `1.00e-7` |
| hard解の対象テーマエクスポージャー誤差 | `4.44e-15` | `1.00e-7` |
| combined ex-ante TE非悪化率 | `100%` | `100%` |
| 公表／再構築業種指数リターンの最大差 | `2.08e-17` | `1.00e-8` |
| solver・rank・共線性self-test | `5/5` | `5/5` |

この合成例では、combinedのtheme-only対比realized annualized TE削減率の中央値は
`68.46%`、改善したテーマ比率は`100%`であった。改善幅は入力基底の構造に依存するため、
本番判断は実データのウォークフォワード結果で行う。

## 8. テスト

```bash
pytest -q test_theme_plus_industry_mimicking.py
```

テスト対象には次を含む。

- 33業種・列和・非負性の入力検証
- combined ex-ante TE非悪化
- 基底／ルックスルーリターン恒等式
- 公表／再構築業種指数照合
- factor risk operator
- effective/knowledge dateのpoint-in-time選択
- 将来情報メタデータの拒否
- 一つの整合した構成バージョンの選択
- 既存純化・個別銘柄実装との後方互換性
- 全出力ファイル保存

## 9. 適用上の注意

この実装の主系列は、構成銘柄をルックスルーした理論バスケットのコスト前リターンである。
公表業種指数を使う系列は指数データとのbasisを評価するためのもので、ETF、TRS、先物、
借株、マーケットインパクト等の実取引コストを自動的には含まない。

本番採用時は、次を別途評価する。

- 業種指数またはカスタムバスケットの実際の取引手段
- ショート可否・借株コスト
- 配当・源泉税・コーポレートアクション
- リバランス時点と公表指数のウェイトドリフト
- turnover・bid/ask・マーケットインパクト
- リスクモデル推定誤差
- common-sampleのout-of-sample TEとコスト後TE
