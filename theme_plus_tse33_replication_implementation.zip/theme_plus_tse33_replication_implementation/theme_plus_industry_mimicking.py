from __future__ import annotations

import json
import math
import pickle
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

import numpy as np
import pandas as pd

import theme_basket_mimicking as base

# Re-export the stable stock/theme-factor implementation so that production users
# can switch imports without rewriting the existing pipeline.
ExposureSnapshot = base.ExposureSnapshot
BasketReplicationArtifacts = base.BasketReplicationArtifacts
add_barra_intercept = base.add_barra_intercept
residualize_df = base.residualize_df
normalize_l2 = base.normalize_l2
prior_stock_momentum = base.prior_stock_momentum
exposure_snapshot_for_date = base.exposure_snapshot_for_date
snapshot_for_date = base.snapshot_for_date
estimate_theme_returns = base.estimate_theme_returns
construct_stock_mimicking_portfolios = base.construct_stock_mimicking_portfolios
stock_replicated_theme_returns = base.stock_replicated_theme_returns
coefficient_replicated_theme_returns = base.coefficient_replicated_theme_returns
construct_basket_mimicking_portfolios = base.construct_basket_mimicking_portfolios
basket_replicated_theme_returns = base.basket_replicated_theme_returns
compare_replication_methods = base.compare_replication_methods


@dataclass
class Config(base.Config):
    """Configuration for theme + industry-basket replication.

    The parent fields retain the original theme-basket implementation.  The
    fields below are used only by the augmented-basis API in this module.
    """

    # Production-safe overrides of the legacy demo defaults.
    use_synthetic_if_missing: bool = False
    basket_fallback_to_theme_exposures: bool = False

    # Synthetic / expected industry universe
    n_industries: int = 33
    synthetic_industry_weight_drift: float = 0.01
    synthetic_published_index_noise: float = 0.0

    # Point-in-time industry constituent weights
    industry_basket_weights_key: str = "industry_basket_weights_by_date"
    industry_basket_metadata_key: str = "industry_basket_metadata_by_date"
    industry_constituents_long_key: str = "industry_constituents_long"
    industry_validate_metadata_dates: bool = True
    industry_require_metadata_dates: bool = False
    industry_expected_count: int = 33
    industry_require_expected_count: bool = True
    industry_allow_asof_snapshot: bool = True
    industry_require_long_only_base: bool = True
    industry_column_sum_target: float = 1.0
    industry_min_constituents: int = 2
    industry_prefix: str = "INDUSTRY::"
    theme_prefix: str = "THEME::"

    # Published index returns / levels
    industry_index_returns_key: str = "industry_index_returns"
    industry_index_levels_key: str = "industry_index_levels"
    industry_index_input_kind: str = "returns"  # returns / levels / auto
    industry_index_reconciliation_tolerance: float = 1e-8
    use_published_industry_returns: bool = True

    # Augmented basis and solver
    augmented_basis_mode: str = "theme_plus_industry"
    augmented_solver_mode: str = "lexicographic_tracking"
    augmented_enforce_neutrality: bool = True
    augmented_enforce_target_exposure: bool = True
    augmented_target_exposure: float = 1.0
    augmented_fallback_mode: str = "soft_penalty"  # soft_penalty / skip
    augmented_soft_constraint_penalty: float = 1e6
    augmented_constraint_tolerance: float = 1e-7
    augmented_rank_tolerance: float = 1e-10
    augmented_identity_tolerance: float = 1e-10
    augmented_nonworsening_tolerance: float = 1e-10
    augmented_enforce_nonworsening: bool = True
    augmented_condition_number_warning: float = 1e12

    # Pure tracking-risk model.  auto prefers a supplied factor covariance,
    # then a shrinkage covariance, then the original diagonal variance proxy.
    augmented_tracking_risk_model: str = "auto"  # auto / factor_covariance / sample_shrinkage / diagonal_variance / unit
    factor_covariances_key: str = "factor_covariances_by_date"
    risk_factor_exposures_key: str = "risk_factor_exposures_by_date"
    sample_covariance_lookback_months: int = 60
    sample_covariance_min_months: int = 24
    sample_covariance_shrinkage: float = 0.25
    sample_covariance_include_exposure_month: bool = True

    # Exact-secondary tie breaker among equal-TE solutions.  These are not put
    # into the primary TE objective, preserving feasible-set non-worsening.
    secondary_theme_l2_penalty: float = 1.0
    secondary_industry_l2_penalty: float = 1.0
    secondary_turnover_l2_penalty: float = 0.0

    # Evaluation
    paired_loss_hac_lags: int = 3
    paired_loss_bootstrap_samples: int = 500
    paired_loss_block_length: int = 6
    bootstrap_seed: int = 271828

    # Avoid pathological BLAS oversubscription in long walk-forward loops.
    linear_algebra_threads: int | None = 1

    # Persistence
    save_industry_constituent_weights: bool = True
    save_augmented_lookthrough_stock_weights: bool = False


@dataclass
class TrackingRiskOperator:
    stocks: pd.Index
    source: str
    kind: str
    diagonal: np.ndarray | None = None
    factor_exposures: np.ndarray | None = None
    factor_covariance: np.ndarray | None = None
    covariance: np.ndarray | None = None
    metadata: dict[str, Any] | None = None

    def apply(self, x: np.ndarray | pd.DataFrame | pd.Series) -> np.ndarray:
        arr = np.asarray(x, dtype=float)
        vector = arr.ndim == 1
        if vector:
            arr = arr[:, None]
        if arr.shape[0] != len(self.stocks):
            raise ValueError(
                f"Risk operator expected {len(self.stocks)} rows but received {arr.shape[0]}"
            )
        if self.kind == "diagonal":
            out = self.diagonal[:, None] * arr
        elif self.kind == "factor":
            out = self.diagonal[:, None] * arr
            out = out + self.factor_exposures @ (
                self.factor_covariance @ (self.factor_exposures.T @ arr)
            )
        elif self.kind == "matrix":
            out = self.covariance @ arr
        else:
            raise ValueError(f"Unknown risk operator kind: {self.kind}")
        return out[:, 0] if vector else out

    def gram(self, b: np.ndarray) -> np.ndarray:
        return np.asarray(b, dtype=float).T @ self.apply(np.asarray(b, dtype=float))

    def cross(self, b: np.ndarray, m: np.ndarray) -> np.ndarray:
        return np.asarray(b, dtype=float).T @ self.apply(np.asarray(m, dtype=float))

    def quadratic_columns(self, x: np.ndarray) -> np.ndarray:
        arr = np.asarray(x, dtype=float)
        if arr.ndim == 1:
            arr = arr[:, None]
        return np.sum(arr * self.apply(arr), axis=0)


@dataclass
class PortfolioConstruction:
    mode: str
    base_weights: pd.DataFrame
    lookthrough_weights: pd.DataFrame
    diagnostics: pd.DataFrame
    basis_diagnostics: pd.DataFrame
    basis_matrix: pd.DataFrame
    basis_metadata: pd.DataFrame
    stock_target_weights: pd.DataFrame
    neutralization_exposures: pd.DataFrame
    purified_theme_exposures: pd.DataFrame
    risk_source: str


@dataclass
class AugmentedReplicationArtifacts:
    replicated_returns: dict[str, pd.DataFrame]
    diagnostics: pd.DataFrame
    basis_diagnostics: pd.DataFrame
    base_weights_long: pd.DataFrame
    lookthrough_stock_weights_long: pd.DataFrame
    industry_constituent_weights_long: pd.DataFrame
    raw_basis_returns: pd.DataFrame
    industry_index_returns_reconstructed: pd.DataFrame
    industry_index_reconciliation: pd.DataFrame
    identity_checks: pd.DataFrame
    input_schema_checks: pd.DataFrame


def _timestamp_dict(values: Mapping[Any, Any]) -> dict[pd.Timestamp, Any]:
    return {pd.Timestamp(k): v.copy() if hasattr(v, "copy") else v for k, v in values.items()}


def _asof_dict_value(
    values: Mapping[pd.Timestamp, Any],
    date: pd.Timestamp,
    allow_asof: bool,
) -> tuple[Any, pd.Timestamp]:
    date = pd.Timestamp(date)
    if date in values:
        return values[date], date
    if not allow_asof:
        raise KeyError(f"No exact point-in-time snapshot on {date.date()}")
    eligible = [pd.Timestamp(k) for k in values if pd.Timestamp(k) <= date]
    if not eligible:
        raise KeyError(f"No point-in-time snapshot on or before {date.date()}")
    selected = max(eligible)
    return values[selected], selected


def _ensure_datetime_index(df: pd.DataFrame | pd.Series) -> pd.DataFrame | pd.Series:
    out = df.copy()
    out.index = pd.to_datetime(out.index)
    return out.sort_index()


def build_industry_weight_snapshots_from_long(
    constituents: pd.DataFrame,
    exposure_dates: Iterable[pd.Timestamp],
    *,
    security_col: str = "security_id",
    industry_col: str = "industry_code",
    weight_col: str = "weight",
    effective_col: str = "effective_date",
    knowledge_col: str = "knowledge_date",
    return_metadata: bool = False,
) -> dict[pd.Timestamp, pd.DataFrame] | tuple[
    dict[pd.Timestamp, pd.DataFrame], dict[pd.Timestamp, dict[str, Any]]
]:
    """Convert point-in-time long constituent history into stock × industry snapshots.

    For each exposure date and industry, the latest effective snapshot whose
    effective and knowledge dates are both no later than the exposure date is
    selected.  The input is assumed to contain a complete industry snapshot for
    each (industry, effective_date) pair.
    """
    required = {security_col, industry_col, weight_col, effective_col, knowledge_col}
    missing = required.difference(constituents.columns)
    if missing:
        raise KeyError(f"Industry constituent history is missing columns: {sorted(missing)}")
    x = constituents.copy()
    x[effective_col] = pd.to_datetime(x[effective_col])
    x[knowledge_col] = pd.to_datetime(x[knowledge_col])
    x[weight_col] = pd.to_numeric(x[weight_col], errors="coerce")
    if x[weight_col].isna().any():
        raise ValueError("Industry constituent history contains non-numeric weights")

    snapshots: dict[pd.Timestamp, pd.DataFrame] = {}
    metadata_by_date: dict[pd.Timestamp, dict[str, Any]] = {}
    for date in sorted(pd.Timestamp(d) for d in exposure_dates):
        eligible = x[(x[effective_col] <= date) & (x[knowledge_col] <= date)]
        if eligible.empty:
            continue
        latest = eligible.groupby(industry_col, observed=True)[effective_col].max()
        selected = eligible.merge(
            latest.rename("_selected_effective"),
            left_on=industry_col,
            right_index=True,
            how="inner",
        )
        selected = selected[selected[effective_col].eq(selected["_selected_effective"])]
        # Select one coherent dissemination version per industry/effective date.
        # Choosing the latest knowledge date per security can inadvertently mix
        # multiple versions of the same index snapshot.
        latest_knowledge = selected.groupby(industry_col, observed=True)[
            knowledge_col
        ].transform("max")
        selected = selected[selected[knowledge_col].eq(latest_knowledge)]
        duplicate_keys = selected.duplicated([industry_col, security_col], keep=False)
        if duplicate_keys.any():
            duplicated = selected.loc[duplicate_keys, [industry_col, security_col]]
            raise ValueError(
                "Industry constituent history contains duplicate securities within "
                f"a selected snapshot: {duplicated.head().to_dict('records')}"
            )
        pivot = selected.pivot_table(
            index=security_col,
            columns=industry_col,
            values=weight_col,
            aggfunc="last",
            fill_value=0.0,
        )
        snapshots[date] = pivot.astype(float)
        selected_dates = (
            selected.groupby(industry_col, observed=True)[[effective_col, knowledge_col]]
            .first()
            .sort_index()
        )
        metadata_by_date[date] = {
            "effective_date": pd.Timestamp(selected_dates[effective_col].max()),
            "knowledge_date": pd.Timestamp(selected_dates[knowledge_col].max()),
            "point_in_time_ok": bool(
                selected_dates[effective_col].le(date).all()
                and selected_dates[knowledge_col].le(date).all()
            ),
            "industry_snapshot_dates": {
                str(industry): {
                    "effective_date": pd.Timestamp(row[effective_col]),
                    "knowledge_date": pd.Timestamp(row[knowledge_col]),
                }
                for industry, row in selected_dates.iterrows()
            },
            "source": "industry_constituents_long",
        }
    return (snapshots, metadata_by_date) if return_metadata else snapshots


def _balanced_industry_groups(stocks: pd.Index, n_industries: int, rng: np.random.Generator) -> list[np.ndarray]:
    order = rng.permutation(len(stocks))
    return [np.asarray(g, dtype=int) for g in np.array_split(order, n_industries)]


def generate_synthetic_augmented_inputs(cfg: Config) -> dict:
    """Generate a complete synthetic input including 33 point-in-time industries.

    Published industry returns are exactly reconstructed from prior-month
    constituent weights unless ``synthetic_published_index_noise`` is positive.
    """
    if cfg.n_stocks < cfg.n_industries * cfg.industry_min_constituents:
        raise ValueError(
            "Synthetic n_stocks must be at least n_industries * industry_min_constituents"
        )
    data = base.generate_synthetic_inputs(cfg)
    rng = np.random.default_rng(cfg.random_seed + 104729)
    dates = data["stock_returns"].index
    stocks = data["stock_returns"].columns
    industries = [f"TSE33_{j:02d}" for j in range(1, cfg.n_industries + 1)]
    groups = _balanced_industry_groups(stocks, cfg.n_industries, rng)

    base_weights = np.zeros((len(stocks), cfg.n_industries), dtype=float)
    for j, idx in enumerate(groups):
        w = rng.lognormal(mean=0.0, sigma=0.45, size=len(idx))
        base_weights[idx, j] = w / w.sum()

    industry_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    industry_metadata_by_date: dict[pd.Timestamp, dict[str, Any]] = {}
    membership_by_date: dict[pd.Timestamp, pd.Series] = {}
    long_rows: list[pd.DataFrame] = []
    current = base_weights.copy()
    for date in dates:
        current = current * rng.lognormal(
            mean=0.0,
            sigma=cfg.synthetic_industry_weight_drift,
            size=current.shape,
        )
        current = current / np.maximum(current.sum(axis=0, keepdims=True), 1e-15)
        frame = pd.DataFrame(current.copy(), index=stocks, columns=industries)
        industry_by_date[pd.Timestamp(date)] = frame
        industry_metadata_by_date[pd.Timestamp(date)] = {
            "effective_date": pd.Timestamp(date),
            "knowledge_date": pd.Timestamp(date),
            "point_in_time_ok": True,
            "source": "synthetic",
        }
        membership = pd.Series(
            [industries[int(np.argmax(current[i]))] for i in range(len(stocks))],
            index=stocks,
            name="industry_code",
        )
        membership_by_date[pd.Timestamp(date)] = membership
        nz = frame.stack().rename("weight").reset_index()
        nz.columns = ["security_id", "industry_code", "weight"]
        nz = nz[nz["weight"].abs() > 0]
        nz.insert(0, "knowledge_date", pd.Timestamp(date))
        nz.insert(1, "effective_date", pd.Timestamp(date))
        nz["industry_name"] = nz["industry_code"]
        nz["weight_type"] = "synthetic_free_float_market_cap"
        nz["source"] = "synthetic"
        nz["version"] = "v1"
        long_rows.append(nz)

    stock_returns = data["stock_returns"]
    reconstructed_rows = []
    for i, return_date in enumerate(dates):
        if i == 0:
            reconstructed_rows.append(pd.Series(np.nan, index=industries, name=return_date))
            continue
        exposure_date = dates[i - 1]
        s = industry_by_date[pd.Timestamp(exposure_date)]
        values = s.T @ stock_returns.loc[return_date].reindex(s.index).fillna(0.0)
        reconstructed_rows.append(pd.Series(values, index=industries, name=return_date))
    published = pd.DataFrame(reconstructed_rows).sort_index()
    if cfg.synthetic_published_index_noise > 0:
        published = published + rng.normal(
            0.0,
            cfg.synthetic_published_index_noise,
            size=published.shape,
        )
    levels = 100.0 * (1.0 + published.fillna(0.0)).cumprod()

    # Supply a simple factor covariance and specific variance so production-like
    # factor-risk mode can be exercised by tests when requested.
    factor_cov_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    specific_var_by_date: dict[pd.Timestamp, pd.Series] = {}
    for date, b in data["barra_exposures_by_date"].items():
        scale = np.linspace(0.008, 0.015, b.shape[1]) ** 2
        factor_cov_by_date[pd.Timestamp(date)] = pd.DataFrame(
            np.diag(scale), index=b.columns, columns=b.columns
        )
        specific_var_by_date[pd.Timestamp(date)] = pd.Series(
            (0.030 + 0.010 * rng.random(len(b.index))) ** 2,
            index=b.index,
            name="specific_variance",
        )

    data[cfg.industry_basket_weights_key] = industry_by_date
    data[cfg.industry_basket_metadata_key] = industry_metadata_by_date
    data[cfg.industry_index_returns_key] = published
    data[cfg.industry_index_levels_key] = levels
    data[cfg.industry_constituents_long_key] = pd.concat(long_rows, ignore_index=True)
    data["industry_membership_by_date"] = membership_by_date
    data[cfg.factor_covariances_key] = factor_cov_by_date
    data[cfg.risk_factor_exposures_key] = _timestamp_dict(data["barra_exposures_by_date"])
    data["specific_variances_by_date"] = specific_var_by_date
    data.setdefault("metadata", {}).update(
        {
            "source": "synthetic_augmented",
            "industry_count": cfg.n_industries,
            "industry_index_return_definition": "prior-month constituent-weight lookthrough",
        }
    )
    return data


def prepare_industry_index_returns(data: dict, cfg: Config) -> pd.DataFrame:
    kind = cfg.industry_index_input_kind
    if kind not in {"returns", "levels", "auto"}:
        raise ValueError("industry_index_input_kind must be 'returns', 'levels', or 'auto'")
    if kind in {"returns", "auto"} and cfg.industry_index_returns_key in data:
        out = data[cfg.industry_index_returns_key]
        if not isinstance(out, pd.DataFrame):
            raise TypeError(f"{cfg.industry_index_returns_key} must be a DataFrame")
        out = _ensure_datetime_index(out.astype(float))
        out.columns = out.columns.map(str)
        return out
    if kind in {"levels", "auto"} and cfg.industry_index_levels_key in data:
        levels = data[cfg.industry_index_levels_key]
        if not isinstance(levels, pd.DataFrame):
            raise TypeError(f"{cfg.industry_index_levels_key} must be a DataFrame")
        levels = _ensure_datetime_index(levels.astype(float))
        levels.columns = levels.columns.map(str)
        return levels.pct_change(fill_method=None)
    raise KeyError(
        f"No industry index returns/levels found under {cfg.industry_index_returns_key!r} "
        f"or {cfg.industry_index_levels_key!r}"
    )


def load_or_generate_augmented_inputs(cfg: Config) -> dict:
    path = Path(cfg.input_pickle)
    if path.exists():
        data = base.load_or_generate_inputs(cfg)
        if cfg.industry_basket_weights_key not in data:
            if cfg.industry_constituents_long_key not in data:
                raise KeyError(
                    f"Production input must contain {cfg.industry_basket_weights_key!r} or "
                    f"{cfg.industry_constituents_long_key!r}"
                )
            snapshots, snapshot_metadata = build_industry_weight_snapshots_from_long(
                data[cfg.industry_constituents_long_key],
                data["stock_returns"].index,
                return_metadata=True,
            )
            data[cfg.industry_basket_weights_key] = snapshots
            data[cfg.industry_basket_metadata_key] = snapshot_metadata
        data[cfg.industry_basket_weights_key] = _timestamp_dict(
            data[cfg.industry_basket_weights_key]
        )
        if cfg.industry_basket_metadata_key in data and isinstance(
            data[cfg.industry_basket_metadata_key], Mapping
        ):
            data[cfg.industry_basket_metadata_key] = _timestamp_dict(
                data[cfg.industry_basket_metadata_key]
            )
        for key in [cfg.factor_covariances_key, cfg.risk_factor_exposures_key]:
            if key in data and isinstance(data[key], Mapping):
                data[key] = _timestamp_dict(data[key])
        if cfg.industry_index_returns_key in data:
            data[cfg.industry_index_returns_key] = _ensure_datetime_index(
                data[cfg.industry_index_returns_key]
            )
        if cfg.industry_index_levels_key in data:
            data[cfg.industry_index_levels_key] = _ensure_datetime_index(
                data[cfg.industry_index_levels_key]
            )
        return data
    if not cfg.use_synthetic_if_missing:
        raise FileNotFoundError(f"Input pickle not found: {path}")
    return generate_synthetic_augmented_inputs(cfg)


def validate_augmented_input_schema(data: dict, cfg: Config) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []

    def add(name: str, passed: bool, detail: str, value: Any = None) -> None:
        rows.append({"check": name, "passed": bool(passed), "value": value, "detail": detail})

    required = [
        "stock_returns",
        "barra_exposures_by_date",
        "theme_exposures_by_date",
        cfg.theme_basket_weights_key,
        cfg.industry_basket_weights_key,
    ]
    for key in required:
        add(f"required_key::{key}", key in data, f"Required input key {key!r}")
    try:
        ir = prepare_industry_index_returns(data, cfg)
        add("industry_index_time_series", not ir.empty, "Industry return or level series is available", ir.shape)
    except Exception as exc:
        add("industry_index_time_series", False, f"{type(exc).__name__}: {exc}")

    if cfg.industry_basket_weights_key in data:
        values = data[cfg.industry_basket_weights_key]
        add(
            "industry_weights_mapping",
            isinstance(values, Mapping) and len(values) > 0,
            "Point-in-time stock × industry snapshots",
            len(values) if isinstance(values, Mapping) else None,
        )
        if isinstance(values, Mapping) and len(values):
            sample_date = min(pd.Timestamp(k) for k in values)
            frame = values[sample_date]
            add(
                "industry_snapshot_dataframe",
                isinstance(frame, pd.DataFrame),
                f"Sample snapshot on {sample_date.date()}",
                getattr(frame, "shape", None),
            )
            if isinstance(frame, pd.DataFrame):
                add(
                    "industry_count_sample",
                    (not cfg.industry_require_expected_count)
                    or frame.shape[1] == cfg.industry_expected_count,
                    f"Expected {cfg.industry_expected_count} industry columns",
                    frame.shape[1],
                )
                sums = frame.fillna(0.0).sum(axis=0)
                add(
                    "industry_positive_column_sums",
                    bool((sums > 0).all()),
                    "All industry baskets have positive constituent-weight sums",
                    float(sums.min()) if len(sums) else np.nan,
                )
    metadata_values = data.get(cfg.industry_basket_metadata_key)
    if metadata_values is not None:
        is_mapping = isinstance(metadata_values, Mapping) and len(metadata_values) > 0
        add(
            "industry_metadata_mapping",
            is_mapping,
            "Optional effective/knowledge-date metadata for point-in-time validation",
            len(metadata_values) if isinstance(metadata_values, Mapping) else None,
        )
        if is_mapping:
            future_flags = []
            for key, value in metadata_values.items():
                if not isinstance(value, Mapping):
                    future_flags.append(True)
                    continue
                exposure_date = pd.Timestamp(key)
                future_flags.append(
                    any(
                        field in value
                        and pd.notna(value[field])
                        and pd.Timestamp(value[field]) > exposure_date
                        for field in ["effective_date", "knowledge_date"]
                    )
                    or value.get("point_in_time_ok") is False
                )
            add(
                "industry_metadata_point_in_time",
                not any(future_flags),
                "No effective/knowledge date exceeds its exposure snapshot date",
                int(sum(future_flags)),
            )
    elif cfg.industry_require_metadata_dates:
        add(
            "industry_metadata_mapping",
            False,
            f"Required key {cfg.industry_basket_metadata_key!r} is unavailable",
        )
    return pd.DataFrame(rows)


def prepare_industry_basket_weights(
    data: dict,
    date: pd.Timestamp,
    stock_index: pd.Index,
    cfg: Config,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    date = pd.Timestamp(date)
    by_date = data.get(cfg.industry_basket_weights_key)
    if by_date is None:
        raise KeyError(f"{cfg.industry_basket_weights_key} is unavailable")
    raw, snapshot_date = _asof_dict_value(by_date, date, cfg.industry_allow_asof_snapshot)
    if not isinstance(raw, pd.DataFrame):
        raise TypeError(f"Industry weights on {snapshot_date.date()} must be a DataFrame")
    if snapshot_date > date:
        raise AssertionError("Future industry snapshot selected")
    if raw.columns.has_duplicates:
        raise ValueError(f"Duplicate industry columns on {snapshot_date.date()}")
    raw = raw.copy()
    raw.columns = raw.columns.map(str)
    n_input_industries = raw.shape[1]
    if cfg.industry_require_expected_count and n_input_industries != cfg.industry_expected_count:
        raise ValueError(
            f"Expected {cfg.industry_expected_count} industry baskets on {date.date()}, "
            f"received {n_input_industries}"
        )
    aligned = raw.reindex(index=stock_index)
    n_input_nan = int(aligned.isna().sum().sum())
    s = aligned.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    if cfg.industry_require_long_only_base and (s < -cfg.augmented_rank_tolerance).any().any():
        bad = (s < -cfg.augmented_rank_tolerance).sum(axis=0)
        raise ValueError(f"Industry base baskets contain negative weights: {bad[bad > 0].to_dict()}")
    sums_before = s.sum(axis=0)
    if (~np.isfinite(sums_before) | (sums_before <= cfg.augmented_rank_tolerance)).any():
        bad = sums_before[(~np.isfinite(sums_before)) | (sums_before <= cfg.augmented_rank_tolerance)]
        raise ValueError(f"Industry baskets with non-positive sums: {bad.index.tolist()}")
    s = s.divide(sums_before, axis=1) * cfg.industry_column_sum_target
    metadata: dict[str, Any] = {}
    metadata_by_date = data.get(cfg.industry_basket_metadata_key)
    if metadata_by_date is not None:
        if not isinstance(metadata_by_date, Mapping):
            raise TypeError(f"{cfg.industry_basket_metadata_key} must be a mapping")
        try:
            meta_raw, meta_snapshot_date = _asof_dict_value(
                metadata_by_date, snapshot_date, True
            )
            metadata = dict(meta_raw) if isinstance(meta_raw, Mapping) else {}
            metadata["metadata_snapshot_date"] = meta_snapshot_date
        except Exception:
            if cfg.industry_require_metadata_dates:
                raise
    elif cfg.industry_require_metadata_dates:
        raise KeyError(f"{cfg.industry_basket_metadata_key} is unavailable")

    if cfg.industry_validate_metadata_dates and metadata:
        for field in ["effective_date", "knowledge_date"]:
            if field in metadata and pd.notna(metadata[field]):
                value = pd.Timestamp(metadata[field])
                if value > date:
                    raise AssertionError(
                        f"Industry {field} {value.date()} exceeds exposure date {date.date()}"
                    )
        if metadata.get("point_in_time_ok") is False:
            raise AssertionError("Industry snapshot metadata marks point_in_time_ok=False")

    count = (s.abs() > cfg.augmented_rank_tolerance).sum(axis=0)
    if (count < cfg.industry_min_constituents).any():
        bad = count[count < cfg.industry_min_constituents]
        raise ValueError(
            f"Industry baskets below industry_min_constituents={cfg.industry_min_constituents}: "
            f"{bad.to_dict()}"
        )
    summary = pd.DataFrame(
        {
            "column_sum_before": sums_before,
            "column_sum_after": s.sum(axis=0),
            "n_constituents": count,
            "max_weight": s.max(axis=0),
            "min_weight": s.min(axis=0),
            "hhi": (s**2).sum(axis=0),
        }
    )
    summary.index.name = "industry_id"
    return s, {
        "requested_date": date,
        "snapshot_date": snapshot_date,
        "n_input_nan_filled_as_zero": n_input_nan,
        "n_stocks": s.shape[0],
        "n_industries": s.shape[1],
        "metadata": metadata,
        "point_in_time_ok": bool(snapshot_date <= date)
        and metadata.get("point_in_time_ok", True),
        "input_summary": summary,
    }


def build_replication_basis(
    data: dict,
    date: pd.Timestamp,
    stock_index: pd.Index,
    theme_columns: pd.Index,
    cfg: Config,
    basis_mode: str,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    valid = {"theme_only", "industry_only", "theme_plus_industry"}
    if basis_mode not in valid:
        raise ValueError(f"basis_mode must be one of {sorted(valid)}")

    components: list[pd.DataFrame] = []
    meta_rows: list[dict[str, Any]] = []
    diagnostics: dict[str, Any] = {"date": pd.Timestamp(date), "basis_mode": basis_mode}

    if basis_mode in {"theme_only", "theme_plus_industry"}:
        p_raw, pdiag = base.prepare_theme_basket_weights(
            data, date, stock_index=stock_index, theme_columns=theme_columns, cfg=cfg
        )
        p = p_raw.copy()
        p.columns = [f"{cfg.theme_prefix}{c}" for c in p_raw.columns]
        components.append(p)
        for raw_id, base_id in zip(p_raw.columns, p.columns):
            meta_rows.append(
                {
                    "base_portfolio": base_id,
                    "raw_id": str(raw_id),
                    "basis_group": "theme",
                    "input_source": pdiag["source"],
                    "snapshot_date": pd.Timestamp(date),
                }
            )
        diagnostics["theme_input"] = pdiag
        diagnostics["theme_matrix"] = p_raw

    if basis_mode in {"industry_only", "theme_plus_industry"}:
        s_raw, sdiag = prepare_industry_basket_weights(data, date, stock_index, cfg)
        s = s_raw.copy()
        s.columns = [f"{cfg.industry_prefix}{c}" for c in s_raw.columns]
        components.append(s)
        for raw_id, base_id in zip(s_raw.columns, s.columns):
            meta_rows.append(
                {
                    "base_portfolio": base_id,
                    "raw_id": str(raw_id),
                    "basis_group": "industry",
                    "input_source": cfg.industry_basket_weights_key,
                    "snapshot_date": sdiag["snapshot_date"],
                }
            )
        diagnostics["industry_input"] = sdiag
        diagnostics["industry_matrix"] = s_raw

    b = pd.concat(components, axis=1).astype(float)
    if b.columns.has_duplicates:
        raise ValueError("Prefixed replication-basis columns are not unique")
    metadata = pd.DataFrame(meta_rows).set_index("base_portfolio").loc[b.columns]
    metadata.index.name = "base_portfolio"
    diagnostics["n_base_portfolios"] = b.shape[1]
    diagnostics["basis_metadata"] = metadata
    return b, metadata, diagnostics


def _nearest_psd(a: np.ndarray, floor: float = 0.0) -> np.ndarray:
    a = 0.5 * (np.asarray(a, dtype=float) + np.asarray(a, dtype=float).T)
    values, vectors = np.linalg.eigh(a)
    values = np.maximum(values, floor)
    return (vectors * values) @ vectors.T


def build_tracking_risk_operator(
    data: dict,
    date: pd.Timestamp,
    stocks: pd.Index,
    cfg: Config,
) -> TrackingRiskOperator:
    date = pd.Timestamp(date)
    requested = cfg.augmented_tracking_risk_model
    valid = {"auto", "factor_covariance", "sample_shrinkage", "diagonal_variance", "unit"}
    if requested not in valid:
        raise ValueError(f"augmented_tracking_risk_model must be one of {sorted(valid)}")

    def factor_operator() -> TrackingRiskOperator:
        cov_by_date = data.get(cfg.factor_covariances_key)
        if cov_by_date is None:
            raise KeyError(cfg.factor_covariances_key)
        cov_raw, cov_date = _asof_dict_value(cov_by_date, date, True)
        if not isinstance(cov_raw, pd.DataFrame):
            raise TypeError("Factor covariance snapshot must be a DataFrame")
        exposure_by_date = data.get(cfg.risk_factor_exposures_key) or data.get(
            "barra_exposures_by_date"
        )
        if exposure_by_date is None:
            raise KeyError(cfg.risk_factor_exposures_key)
        x_raw, exposure_date = _asof_dict_value(exposure_by_date, date, True)
        if not isinstance(x_raw, pd.DataFrame):
            raise TypeError("Risk-factor exposure snapshot must be a DataFrame")
        factors = x_raw.columns.intersection(cov_raw.index).intersection(cov_raw.columns)
        if len(factors) == 0:
            raise ValueError("Risk exposures and factor covariance have no common factors")
        x = x_raw.reindex(index=stocks, columns=factors).astype(float)
        if x.isna().any().any():
            raise ValueError("Risk-factor exposure snapshot has missing values after alignment")
        f = cov_raw.loc[factors, factors].astype(float).to_numpy()
        f = _nearest_psd(f, floor=0.0)
        d, d_source = base.diagonal_specific_variance(data, date, stocks, cfg)
        return TrackingRiskOperator(
            stocks=stocks,
            source=f"factor_covariance:{cfg.factor_covariances_key}+{d_source}",
            kind="factor",
            diagonal=d.to_numpy(),
            factor_exposures=x.to_numpy(),
            factor_covariance=f,
            metadata={
                "factor_covariance_date": cov_date,
                "factor_exposure_date": exposure_date,
                "n_factors": len(factors),
                "factor_names": list(map(str, factors)),
            },
        )

    def sample_operator() -> TrackingRiskOperator:
        returns = data["stock_returns"].reindex(columns=stocks)
        loc = returns.index.get_loc(date)
        end = loc + 1 if cfg.sample_covariance_include_exposure_month else loc
        start = max(0, end - cfg.sample_covariance_lookback_months)
        hist = returns.iloc[start:end].astype(float)
        if len(hist) < cfg.sample_covariance_min_months:
            raise ValueError(
                f"Only {len(hist)} months available for sample covariance; "
                f"minimum is {cfg.sample_covariance_min_months}"
            )
        centered = hist - hist.mean(axis=0)
        centered = centered.fillna(0.0)
        denom = max(1, len(centered) - 1)
        sample = centered.to_numpy().T @ centered.to_numpy() / denom
        diag = np.diag(np.diag(sample))
        shrink = float(np.clip(cfg.sample_covariance_shrinkage, 0.0, 1.0))
        sigma = (1.0 - shrink) * sample + shrink * diag
        positive_diag = np.diag(sigma)
        fallback = float(np.nanmedian(positive_diag[positive_diag > 0])) if np.any(positive_diag > 0) else 1.0
        sigma = sigma + np.diag(np.maximum(0.0, 1e-12 * fallback - np.diag(sigma)))
        sigma = _nearest_psd(sigma, floor=0.0)
        return TrackingRiskOperator(
            stocks=stocks,
            source="sample_shrinkage_covariance",
            kind="matrix",
            covariance=sigma,
            metadata={"n_history_months": len(hist), "shrinkage": shrink},
        )

    def diagonal_operator() -> TrackingRiskOperator:
        d, source = base.diagonal_specific_variance(data, date, stocks, cfg)
        return TrackingRiskOperator(
            stocks=stocks,
            source=source,
            kind="diagonal",
            diagonal=d.to_numpy(),
            metadata={},
        )

    if requested == "factor_covariance":
        return factor_operator()
    if requested == "sample_shrinkage":
        return sample_operator()
    if requested == "diagonal_variance":
        return diagonal_operator()
    if requested == "unit":
        return TrackingRiskOperator(
            stocks=stocks,
            source="unit_variance",
            kind="diagonal",
            diagonal=np.ones(len(stocks)),
            metadata={},
        )

    failures: list[str] = []
    for builder in [factor_operator, sample_operator, diagonal_operator]:
        try:
            op = builder()
            op.metadata = dict(op.metadata or {}, auto_fallback_failures=failures)
            return op
        except Exception as exc:
            failures.append(f"{builder.__name__}:{type(exc).__name__}:{exc}")
    raise RuntimeError("Unable to build a tracking-risk operator: " + " | ".join(failures))


def _condition_number(a: np.ndarray, rtol: float) -> float:
    a = np.asarray(a, dtype=float)
    if a.size == 0:
        return np.nan
    s = np.linalg.svd(a, compute_uv=False)
    if len(s) == 0 or s[0] == 0:
        return np.inf
    tol = rtol * max(a.shape) * s[0]
    keep = s[s > tol]
    if len(keep) == 0:
        return np.inf
    if len(keep) < min(a.shape):
        return np.inf
    return float(keep[0] / keep[-1])


def _solve_lexicographic_equality_qp(
    q: np.ndarray,
    c: np.ndarray,
    g: np.ndarray,
    d: np.ndarray,
    cfg: Config,
    secondary_metric: np.ndarray | None = None,
    secondary_reference: np.ndarray | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Solve a PSD equality-constrained QP, then tie-break on flat directions.

    Stage 1 minimizes ``0.5 x'Qx - c'x`` exactly on the feasible affine set.
    Stage 2 changes the solution only along directions that are both constraint
    preserving and flat for the Stage-1 Hessian, so the primary tracking loss is
    unchanged up to numerical precision.
    """
    q = 0.5 * (np.asarray(q, dtype=float) + np.asarray(q, dtype=float).T)
    c = np.asarray(c, dtype=float).reshape(-1)
    g = np.asarray(g, dtype=float)
    d = np.asarray(d, dtype=float).reshape(-1)
    n = q.shape[0]
    if g.ndim != 2 or g.shape[1] != n or len(d) != g.shape[0]:
        raise ValueError("Invalid equality-constraint dimensions")

    if g.shape[0]:
        x_particular = np.linalg.pinv(g, rcond=cfg.pinv_rcond) @ d
        feasibility = float(np.max(np.abs(g @ x_particular - d)))
        v, rank_g, singular_g, _ = base._nullspace(g, cfg.augmented_rank_tolerance)
    else:
        x_particular = np.zeros(n)
        feasibility = 0.0
        v = np.eye(n)
        rank_g = 0
        singular_g = np.array([], dtype=float)
    if feasibility > cfg.augmented_constraint_tolerance:
        raise ValueError(f"infeasible_equalities:{feasibility:.3e}")

    if v.shape[1]:
        h = 0.5 * (v.T @ q @ v + (v.T @ q @ v).T)
        rhs = v.T @ (c - q @ x_particular)
        y = np.linalg.pinv(h, rcond=cfg.pinv_rcond) @ rhs
        x_primary = x_particular + v @ y
        projected_gradient = float(np.max(np.abs(v.T @ (q @ x_primary - c))))
        flat, rank_h, singular_h, _ = base._nullspace(h, cfg.augmented_rank_tolerance)
        u = v @ flat
    else:
        h = np.zeros((0, 0))
        x_primary = x_particular
        projected_gradient = 0.0
        rank_h = 0
        singular_h = np.array([], dtype=float)
        u = np.zeros((n, 0))

    primary_obj = 0.5 * float(x_primary @ q @ x_primary) - float(c @ x_primary)
    x = x_primary.copy()
    secondary_applied = False
    secondary_obj = np.nan
    if u.shape[1] and secondary_metric is not None:
        r = 0.5 * (
            np.asarray(secondary_metric, dtype=float)
            + np.asarray(secondary_metric, dtype=float).T
        )
        ref = (
            np.zeros(n)
            if secondary_reference is None
            else np.asarray(secondary_reference, dtype=float).reshape(-1)
        )
        hu = 0.5 * (u.T @ r @ u + (u.T @ r @ u).T)
        br = u.T @ r @ (ref - x_primary)
        a = np.linalg.pinv(hu, rcond=cfg.pinv_rcond) @ br
        candidate = x_primary + u @ a
        candidate_obj = 0.5 * float(candidate @ q @ candidate) - float(c @ candidate)
        candidate_resid = (
            float(np.max(np.abs(g @ candidate - d))) if g.shape[0] else 0.0
        )
        obj_tol = cfg.augmented_nonworsening_tolerance * max(1.0, abs(primary_obj))
        if (
            np.isfinite(candidate).all()
            and candidate_resid <= cfg.augmented_constraint_tolerance
            and candidate_obj <= primary_obj + obj_tol
        ):
            x = candidate
            secondary_applied = True
            secondary_obj = 0.5 * float((x - ref) @ r @ (x - ref))

    constraint_resid = float(np.max(np.abs(g @ x - d))) if g.shape[0] else 0.0
    final_obj = 0.5 * float(x @ q @ x) - float(c @ x)
    cond_h = _condition_number(h, cfg.augmented_rank_tolerance) if h.size else np.nan
    status = "hard_solved"
    if (not np.isfinite(cond_h)) or cond_h > cfg.augmented_condition_number_warning:
        status = "hard_solved_condition_warning"
    return x, {
        "solver_status": status,
        "applied_mode": "lexicographic_tracking",
        "constraint_rank": rank_g,
        "n_constraints": g.shape[0],
        "feasible_dimension": int(v.shape[1]),
        "primary_hessian_rank": rank_h,
        "primary_flat_dimension": int(u.shape[1]),
        "constraint_feasibility_residual": feasibility,
        "constraint_residual": constraint_resid,
        "projected_gradient_residual": projected_gradient,
        "condition_number_reduced_hessian": cond_h,
        "primary_objective": primary_obj,
        "final_primary_objective": final_obj,
        "secondary_tiebreaker_applied": secondary_applied,
        "secondary_objective": secondary_obj,
        "min_constraint_singular_value": float(singular_g[-1]) if len(singular_g) else np.nan,
        "min_reduced_hessian_singular_value": float(singular_h[-1]) if len(singular_h) else np.nan,
    }


def _solve_soft_penalty_qp(
    q: np.ndarray,
    c: np.ndarray,
    g: np.ndarray,
    d: np.ndarray,
    cfg: Config,
    secondary_metric: np.ndarray | None,
    reason: str,
) -> tuple[np.ndarray, dict[str, Any]]:
    q = 0.5 * (q + q.T)
    metric = np.eye(q.shape[0]) if secondary_metric is None else secondary_metric
    penalty = cfg.augmented_soft_constraint_penalty
    qs = q + penalty * (g.T @ g) + 1e-12 * metric
    cs = c + penalty * (g.T @ d)
    x = np.linalg.pinv(qs, rcond=cfg.pinv_rcond) @ cs
    resid = float(np.max(np.abs(g @ x - d))) if g.shape[0] else 0.0
    return x, {
        "solver_status": f"soft_fallback:{reason}",
        "applied_mode": "soft_penalty",
        "constraint_rank": base._svd_rank(g, cfg.augmented_rank_tolerance)[0],
        "n_constraints": g.shape[0],
        "feasible_dimension": np.nan,
        "primary_hessian_rank": base._svd_rank(q, cfg.augmented_rank_tolerance)[0],
        "primary_flat_dimension": np.nan,
        "constraint_feasibility_residual": resid,
        "constraint_residual": resid,
        "projected_gradient_residual": np.nan,
        "condition_number_reduced_hessian": _condition_number(qs, cfg.augmented_rank_tolerance),
        "primary_objective": 0.5 * float(x @ q @ x) - float(c @ x),
        "final_primary_objective": 0.5 * float(x @ q @ x) - float(c @ x),
        "secondary_tiebreaker_applied": False,
        "secondary_objective": np.nan,
        "min_constraint_singular_value": np.nan,
        "min_reduced_hessian_singular_value": np.nan,
    }


def _solve_augmented_qp(
    q: np.ndarray,
    c: np.ndarray,
    g: np.ndarray,
    d: np.ndarray,
    cfg: Config,
    secondary_metric: np.ndarray,
    secondary_reference: np.ndarray | None,
) -> tuple[np.ndarray, dict[str, Any]]:
    try:
        return _solve_lexicographic_equality_qp(
            q,
            c,
            g,
            d,
            cfg,
            secondary_metric=secondary_metric,
            secondary_reference=secondary_reference,
        )
    except Exception as exc:
        if cfg.augmented_fallback_mode == "skip":
            raise
        if cfg.augmented_fallback_mode != "soft_penalty":
            raise ValueError("augmented_fallback_mode must be 'soft_penalty' or 'skip'")
        return _solve_soft_penalty_qp(
            q,
            c,
            g,
            d,
            cfg,
            secondary_metric,
            reason=f"{type(exc).__name__}:{exc}",
        )


def _neutrality_matrix(
    a: pd.DataFrame,
    b: pd.DataFrame,
    cfg: Config,
) -> tuple[np.ndarray, list[str]]:
    rows = []
    names = []
    if cfg.augmented_enforce_neutrality:
        rows.append(a.to_numpy().T @ b.to_numpy())
        names.extend(map(str, a.columns))
    if not cfg.include_intercept_in_barra:
        rows.append(np.ones((1, b.shape[0])) @ b.to_numpy())
        names.append("DOLLAR_NET")
    f = np.vstack(rows) if rows else np.zeros((0, b.shape[1]))
    return f, names


def augmented_basis_diagnostics(
    b: pd.DataFrame,
    metadata: pd.DataFrame,
    a: pd.DataFrame,
    z: pd.DataFrame,
    cfg: Config,
    mode: str,
) -> tuple[dict[str, Any], np.ndarray]:
    f, _ = _neutrality_matrix(a, b, cfg)
    neutral_coeff, rank_f, singular_f, tol_f = base._nullspace(
        f, cfg.augmented_rank_tolerance
    )
    neutral_stock = b.to_numpy() @ neutral_coeff
    rank_b, singular_b, tol_b = base._svd_rank(b.to_numpy(), cfg.augmented_rank_tolerance)
    rank_neutral_stock, singular_ns, tol_ns = base._svd_rank(
        neutral_stock, cfg.augmented_rank_tolerance
    )
    target_map = z.to_numpy().T @ neutral_stock
    rank_target, singular_t, tol_t = base._svd_rank(
        target_map, cfg.augmented_rank_tolerance
    )
    diag = {
        "basis_mode": mode,
        "n_stocks": b.shape[0],
        "n_base_portfolios": b.shape[1],
        "n_theme_bases": int(metadata["basis_group"].eq("theme").sum()),
        "n_industry_bases": int(metadata["basis_group"].eq("industry").sum()),
        "rank_basis_matrix": rank_b,
        "rank_neutrality_on_basis": rank_f,
        "neutral_coefficient_dimension": int(neutral_coeff.shape[1]),
        "rank_neutral_stock_span": rank_neutral_stock,
        "rank_target_exposure_in_neutral_span": rank_target,
        "condition_number_basis_matrix": _condition_number(
            b.to_numpy(), cfg.augmented_rank_tolerance
        ),
        "condition_number_neutrality_on_basis": _condition_number(
            f, cfg.augmented_rank_tolerance
        ),
        "rank_tolerance_basis": tol_b,
        "rank_tolerance_neutrality": tol_f,
        "rank_tolerance_neutral_stock_span": tol_ns,
        "rank_tolerance_target_map": tol_t,
        "min_singular_value_basis": float(singular_b[-1]) if len(singular_b) else np.nan,
        "min_singular_value_neutrality": float(singular_f[-1]) if len(singular_f) else np.nan,
        "min_singular_value_neutral_stock_span": float(singular_ns[-1]) if len(singular_ns) else np.nan,
        "min_singular_value_target_map": float(singular_t[-1]) if len(singular_t) else np.nan,
    }
    return diag, neutral_stock


def _secondary_metric(metadata: pd.DataFrame, cfg: Config) -> np.ndarray:
    penalties = np.where(
        metadata["basis_group"].eq("industry").to_numpy(),
        cfg.secondary_industry_l2_penalty,
        cfg.secondary_theme_l2_penalty,
    ).astype(float)
    penalties = np.maximum(penalties, 1e-15)
    return np.diag(penalties)


def _solve_given_basis(
    *,
    date: pd.Timestamp,
    mode: str,
    b: pd.DataFrame,
    metadata: pd.DataFrame,
    a: pd.DataFrame,
    z: pd.DataFrame,
    m_stock: pd.DataFrame,
    risk: TrackingRiskOperator,
    cfg: Config,
    previous_base_weights: pd.DataFrame | None = None,
) -> PortfolioConstruction:
    bv = b.to_numpy()
    zv = z.to_numpy()
    mv = m_stock.to_numpy()
    q = 0.5 * (risk.gram(bv) + risk.gram(bv).T)
    c_all = risk.cross(bv, mv)
    m_quad = risk.quadratic_columns(mv)
    f, neutrality_names = _neutrality_matrix(a, b, cfg)
    target_on_basis = zv.T @ bv
    secondary = _secondary_metric(metadata, cfg)
    basis_diag, _ = augmented_basis_diagnostics(b, metadata, a, z, cfg, mode)
    basis_diag.update(
        {
            "exposure_date": pd.Timestamp(date),
            "risk_model_source": risk.source,
            "n_neutrality_constraints_input": len(neutrality_names),
        }
    )

    x_df = pd.DataFrame(index=b.columns, columns=z.columns, dtype=float)
    rows: list[dict[str, Any]] = []
    for k, theme in enumerate(z.columns):
        g_rows = []
        d_rows = []
        if f.shape[0]:
            g_rows.append(f)
            d_rows.extend([0.0] * f.shape[0])
        target_row = target_on_basis[k]
        if cfg.augmented_enforce_target_exposure:
            g_rows.append(target_row.reshape(1, -1))
            d_rows.append(cfg.augmented_target_exposure)
        g = np.vstack(g_rows) if g_rows else np.zeros((0, b.shape[1]))
        d = np.asarray(d_rows, dtype=float)
        previous = None
        if previous_base_weights is not None and theme in previous_base_weights.columns:
            previous = previous_base_weights[theme].reindex(b.index).fillna(0.0).to_numpy()
        try:
            x, solver = _solve_augmented_qp(
                q,
                c_all[:, k],
                g,
                d,
                cfg,
                secondary_metric=secondary,
                secondary_reference=previous,
            )
        except Exception as exc:
            x = np.full(b.shape[1], np.nan)
            solver = {
                "solver_status": f"skipped:{type(exc).__name__}:{exc}",
                "applied_mode": "skip",
                "constraint_residual": np.nan,
                "constraint_feasibility_residual": np.nan,
                "condition_number_reduced_hessian": np.nan,
                "primary_objective": np.nan,
                "final_primary_objective": np.nan,
                "secondary_tiebreaker_applied": False,
            }
        x_df[theme] = x
        if not np.isfinite(x).all():
            rows.append(
                {
                    "exposure_date": pd.Timestamp(date),
                    "target_theme": theme,
                    "basis_mode": mode,
                    **basis_diag,
                    **solver,
                }
            )
            continue

        m = bv @ x
        diff = m - mv[:, k]
        te2 = float(diff @ risk.apply(diff))
        te2 = max(0.0, te2)
        target_variance = float(m_quad[k])
        neutral_exp = a.to_numpy().T @ m
        theme_exp = zv.T @ m
        off_theme = np.delete(theme_exp, k)
        theme_mask = metadata["basis_group"].eq("theme").to_numpy()
        industry_mask = metadata["basis_group"].eq("industry").to_numpy()
        denom = float(np.linalg.norm(m) * np.linalg.norm(mv[:, k]))
        row = {
            "exposure_date": pd.Timestamp(date),
            "target_theme": theme,
            "basis_mode": mode,
            **basis_diag,
            **solver,
            "max_abs_neutralization_exposure": float(np.max(np.abs(neutral_exp))) if len(neutral_exp) else 0.0,
            "target_theme_exposure": float(theme_exp[k]),
            "target_theme_exposure_error": float(theme_exp[k] - cfg.augmented_target_exposure),
            "off_target_theme_exposure_l1": float(np.abs(off_theme).sum()),
            "off_target_theme_exposure_l2": float(np.linalg.norm(off_theme)),
            "base_gross": float(np.abs(x).sum()),
            "base_net": float(x.sum()),
            "theme_base_gross": float(np.abs(x[theme_mask]).sum()),
            "theme_base_net": float(x[theme_mask].sum()),
            "industry_base_gross": float(np.abs(x[industry_mask]).sum()),
            "industry_base_net": float(x[industry_mask].sum()),
            "max_abs_base_weight": float(np.max(np.abs(x))),
            "max_abs_industry_weight": float(np.max(np.abs(x[industry_mask]))) if industry_mask.any() else 0.0,
            "n_long_bases": int((x > cfg.augmented_rank_tolerance).sum()),
            "n_short_bases": int((x < -cfg.augmented_rank_tolerance).sum()),
            "n_long_industries": int((x[industry_mask] > cfg.augmented_rank_tolerance).sum()),
            "n_short_industries": int((x[industry_mask] < -cfg.augmented_rank_tolerance).sum()),
            "lookthrough_stock_gross": float(np.abs(m).sum()),
            "lookthrough_stock_net": float(m.sum()),
            "ex_ante_tracking_error_squared": te2,
            "ex_ante_tracking_error": math.sqrt(te2),
            "stock_target_ex_ante_variance": target_variance,
            "fraction_target_risk_unexplained": np.nan if target_variance <= 0 else te2 / target_variance,
            "cosine_similarity_to_stock_target": np.nan if denom <= 0 else float(m @ mv[:, k] / denom),
        }
        rows.append(row)

    lookthrough = b @ x_df
    return PortfolioConstruction(
        mode=mode,
        base_weights=x_df,
        lookthrough_weights=lookthrough,
        diagnostics=pd.DataFrame(rows),
        basis_diagnostics=pd.DataFrame([basis_diag]),
        basis_matrix=b,
        basis_metadata=metadata,
        stock_target_weights=m_stock,
        neutralization_exposures=a,
        purified_theme_exposures=z,
        risk_source=risk.source,
    )


def _cross_basis_rank_diagnostics(
    constructions: Mapping[str, PortfolioConstruction],
    cfg: Config,
    date: pd.Timestamp,
) -> pd.DataFrame:
    rows = []
    neutral_spans: dict[str, np.ndarray] = {}
    for mode, result in constructions.items():
        diag, neutral_stock = augmented_basis_diagnostics(
            result.basis_matrix,
            result.basis_metadata,
            result.neutralization_exposures,
            result.purified_theme_exposures,
            cfg,
            mode,
        )
        neutral_spans[mode] = neutral_stock
        rows.append({"exposure_date": pd.Timestamp(date), **diag})

    by_mode = {r["basis_mode"]: r for r in rows}
    if "theme_only" in by_mode and "theme_plus_industry" in by_mode:
        theme_rank = by_mode["theme_only"]["rank_neutral_stock_span"]
        combined_rank = by_mode["theme_plus_industry"]["rank_neutral_stock_span"]
        gain = int(max(0, combined_rank - theme_rank))
        for row in rows:
            row["theme_neutral_stock_span_rank"] = theme_rank
            row["combined_neutral_stock_span_rank"] = combined_rank
            row["incremental_feasible_rank"] = gain
        try:
            from scipy.linalg import orth, subspace_angles

            u = orth(neutral_spans["theme_only"])
            v = orth(neutral_spans["theme_plus_industry"])
            if u.shape[1] and v.shape[1]:
                angles = subspace_angles(u, v)
                max_angle = float(np.max(angles))
                min_angle = float(np.min(angles))
            else:
                max_angle = min_angle = np.nan
        except Exception:
            max_angle = min_angle = np.nan
        for row in rows:
            row["principal_angle_min_radians"] = min_angle
            row["principal_angle_max_radians"] = max_angle
    return pd.DataFrame(rows)


def _replace_combined_with_embedded_theme(
    combined: PortfolioConstruction,
    theme: PortfolioConstruction,
    risk: TrackingRiskOperator,
    cfg: Config,
) -> PortfolioConstruction:
    x = combined.base_weights.copy()
    m = combined.lookthrough_weights.copy()
    diag = combined.diagnostics.copy().set_index("target_theme", drop=False)
    theme_diag = theme.diagnostics.set_index("target_theme", drop=False)
    theme_cols = [c for c in combined.base_weights.index if str(c).startswith(cfg.theme_prefix)]
    industry_cols = [c for c in combined.base_weights.index if str(c).startswith(cfg.industry_prefix)]
    for target in x.columns:
        if target not in theme.base_weights.columns or target not in theme_diag.index:
            continue
        base_te2 = theme_diag.loc[target, "ex_ante_tracking_error_squared"]
        comb_te2 = diag.loc[target, "ex_ante_tracking_error_squared"] if target in diag.index else np.nan
        needs_fallback = not np.isfinite(comb_te2) or (
            comb_te2 > base_te2 + cfg.augmented_nonworsening_tolerance * max(1.0, abs(base_te2))
        )
        if not needs_fallback:
            diag.loc[target, "nonworsening_fallback_applied"] = False
            continue
        x.loc[:, target] = 0.0
        x.loc[theme_cols, target] = theme.base_weights[target].reindex(theme_cols).fillna(0.0)
        x.loc[industry_cols, target] = 0.0
        m[target] = combined.basis_matrix @ x[target]
        diff = m[target].to_numpy() - combined.stock_target_weights[target].to_numpy()
        te2 = max(0.0, float(diff @ risk.apply(diff)))
        diag.loc[target, "ex_ante_tracking_error_squared"] = te2
        diag.loc[target, "ex_ante_tracking_error"] = math.sqrt(te2)
        diag.loc[target, "solver_status"] = "embedded_theme_only_nonworsening_fallback"
        diag.loc[target, "nonworsening_fallback_applied"] = True
        diag.loc[target, "industry_base_gross"] = 0.0
        diag.loc[target, "industry_base_net"] = 0.0
        diag.loc[target, "max_abs_industry_weight"] = 0.0
        diag.loc[target, "n_long_industries"] = 0
        diag.loc[target, "n_short_industries"] = 0
    diag = diag.reset_index(drop=True)
    return PortfolioConstruction(
        mode=combined.mode,
        base_weights=x,
        lookthrough_weights=m,
        diagnostics=diag,
        basis_diagnostics=combined.basis_diagnostics,
        basis_matrix=combined.basis_matrix,
        basis_metadata=combined.basis_metadata,
        stock_target_weights=combined.stock_target_weights,
        neutralization_exposures=combined.neutralization_exposures,
        purified_theme_exposures=combined.purified_theme_exposures,
        risk_source=combined.risk_source,
    )


def construct_all_basis_mimicking_portfolios(
    data: dict,
    cfg: Config,
    date: pd.Timestamp,
    momentum_neutral: bool = False,
    previous_base_weights: Mapping[str, pd.DataFrame] | None = None,
) -> tuple[dict[str, PortfolioConstruction], pd.DataFrame, TrackingRiskOperator]:
    date = pd.Timestamp(date)
    m_stock, stock_diag = base.construct_stock_mimicking_portfolios(
        data, cfg, date, momentum_neutral=momentum_neutral, mode="coefficient"
    )
    snap = stock_diag["snapshot"]
    a = snap.neutralization_exposures.loc[m_stock.index]
    z = snap.purified_theme_exposures.loc[m_stock.index, m_stock.columns]
    risk = build_tracking_risk_operator(data, date, m_stock.index, cfg)
    previous_base_weights = previous_base_weights or {}

    constructions: dict[str, PortfolioConstruction] = {}
    for mode in ["theme_only", "industry_only", "theme_plus_industry"]:
        b, metadata, _ = build_replication_basis(
            data,
            date,
            stock_index=m_stock.index,
            theme_columns=m_stock.columns,
            cfg=cfg,
            basis_mode=mode,
        )
        constructions[mode] = _solve_given_basis(
            date=date,
            mode=mode,
            b=b,
            metadata=metadata,
            a=a,
            z=z,
            m_stock=m_stock,
            risk=risk,
            cfg=cfg,
            previous_base_weights=previous_base_weights.get(mode),
        )

    if cfg.augmented_enforce_nonworsening:
        constructions["theme_plus_industry"] = _replace_combined_with_embedded_theme(
            constructions["theme_plus_industry"],
            constructions["theme_only"],
            risk,
            cfg,
        )

    theme_diag = constructions["theme_only"].diagnostics.set_index("target_theme")
    combined_diag = constructions["theme_plus_industry"].diagnostics.set_index("target_theme")
    common = theme_diag.index.intersection(combined_diag.index)
    reduction = theme_diag.loc[common, "ex_ante_tracking_error_squared"] - combined_diag.loc[
        common, "ex_ante_tracking_error_squared"
    ]
    ratio = reduction.divide(
        theme_diag.loc[common, "ex_ante_tracking_error_squared"].replace(0.0, np.nan)
    )
    cdiag = constructions["theme_plus_industry"].diagnostics.copy().set_index("target_theme")
    cdiag.loc[common, "ex_ante_te2_reduction_vs_theme_only"] = reduction
    cdiag.loc[common, "ex_ante_te2_reduction_ratio_vs_theme_only"] = ratio
    cdiag.loc[common, "nonworsening_check_passed"] = (
        combined_diag.loc[common, "ex_ante_tracking_error_squared"]
        <= theme_diag.loc[common, "ex_ante_tracking_error_squared"]
        + cfg.augmented_nonworsening_tolerance
        * np.maximum(
            1.0,
            theme_diag.loc[common, "ex_ante_tracking_error_squared"].abs(),
        )
    )
    constructions["theme_plus_industry"].diagnostics = cdiag.reset_index()
    rank_diag = _cross_basis_rank_diagnostics(constructions, cfg, date)
    return constructions, rank_diag, risk


def construct_augmented_mimicking_portfolios(
    data: dict,
    cfg: Config,
    date: pd.Timestamp,
    basis_mode: str = "theme_plus_industry",
    momentum_neutral: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    constructions, rank_diag, risk = construct_all_basis_mimicking_portfolios(
        data, cfg, date, momentum_neutral=momentum_neutral
    )
    if basis_mode not in constructions:
        raise ValueError(f"Unknown basis_mode: {basis_mode}")
    result = constructions[basis_mode]
    return result.base_weights, result.lookthrough_weights, {
        "per_theme": result.diagnostics,
        "basis": result.basis_diagnostics,
        "basis_extension_rank": rank_diag,
        "basis_matrix": result.basis_matrix,
        "basis_metadata": result.basis_metadata,
        "stock_target_weights": result.stock_target_weights,
        "risk_operator": risk,
    }


def _portfolio_coverage(weights: pd.DataFrame, missing_mask: pd.Series) -> pd.Series:
    return base._portfolio_return_coverage(weights, missing_mask)


def _basis_turnover(current: pd.DataFrame, previous: pd.DataFrame | None) -> pd.Series:
    if previous is None:
        return pd.Series(np.nan, index=current.columns)
    idx = previous.index.union(current.index)
    cols = previous.columns.union(current.columns)
    aligned_current = current.reindex(index=idx, columns=cols, fill_value=0.0)
    aligned_previous = previous.reindex(index=idx, columns=cols, fill_value=0.0)
    return 0.5 * (aligned_current - aligned_previous).abs().sum(axis=0).reindex(current.columns)


def _published_industry_basis_returns(
    published: pd.DataFrame,
    return_date: pd.Timestamp,
    metadata: pd.DataFrame,
    cfg: Config,
) -> pd.Series:
    row = published.loc[return_date] if return_date in published.index else pd.Series(dtype=float)
    values = {}
    for base_id, info in metadata.iterrows():
        if info["basis_group"] == "industry":
            values[base_id] = row.get(info["raw_id"], np.nan)
    return pd.Series(values, dtype=float)


def _augmented_replicated_theme_returns_impl(
    data: dict,
    cfg: Config,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool = False,
) -> tuple[dict[str, pd.DataFrame], AugmentedReplicationArtifacts]:
    published = prepare_industry_index_returns(data, cfg)
    result_rows: dict[str, list[pd.Series]] = {
        "theme_only": [],
        "industry_only": [],
        "theme_plus_industry": [],
        "industry_only_published": [],
        "theme_plus_industry_published": [],
    }
    diag_frames: list[pd.DataFrame] = []
    rank_frames: list[pd.DataFrame] = []
    weight_frames: list[pd.DataFrame] = []
    lookthrough_frames: list[pd.DataFrame] = []
    constituent_frames: list[pd.DataFrame] = []
    raw_basis_rows: list[pd.Series] = []
    recon_rows: list[pd.Series] = []
    recon_long_rows: list[dict[str, Any]] = []
    identity_rows: list[dict[str, Any]] = []
    previous: dict[str, pd.DataFrame] = {}
    previous_lookthrough: dict[str, pd.DataFrame] = {}

    dates = data["stock_returns"].index
    for return_date in theme_returns.index:
        if return_date not in dates:
            continue
        pos = dates.get_loc(return_date)
        if pos == 0:
            continue
        exposure_date = dates[pos - 1]
        try:
            constructions, rank_diag, risk = construct_all_basis_mimicking_portfolios(
                data,
                cfg,
                exposure_date,
                momentum_neutral=momentum_neutral,
                previous_base_weights=previous,
            )
            any_result = constructions["theme_plus_industry"]
            r, rdiag = base._return_vector_with_policy(
                data, return_date, any_result.lookthrough_weights.index, cfg
            )
            rank_diag = rank_diag.copy()
            rank_diag["return_date"] = return_date
            rank_frames.append(rank_diag)

            # Constituent-level industry reconciliation is common to all modes.
            s_raw, sdiag = prepare_industry_basket_weights(
                data, exposure_date, any_result.lookthrough_weights.index, cfg
            )
            reconstructed_industry = pd.Series(
                s_raw.T @ r,
                index=s_raw.columns,
                name=return_date,
            )
            recon_rows.append(reconstructed_industry)
            published_row = (
                published.loc[return_date].reindex(s_raw.columns)
                if return_date in published.index
                else pd.Series(np.nan, index=s_raw.columns)
            )
            industry_coverage = _portfolio_coverage(s_raw, rdiag["missing_mask"])
            for industry in s_raw.columns:
                recon_long_rows.append(
                    {
                        "return_date": return_date,
                        "exposure_date": exposure_date,
                        "industry_id": industry,
                        "industry_snapshot_date": sdiag["snapshot_date"],
                        "reconstructed_return": reconstructed_industry[industry],
                        "published_return": published_row.get(industry, np.nan),
                        "reconciliation_error": published_row.get(industry, np.nan)
                        - reconstructed_industry[industry],
                        "constituent_return_coverage": industry_coverage[industry],
                    }
                )
            if cfg.save_industry_constituent_weights:
                c_long = s_raw.stack().rename("constituent_weight").reset_index()
                c_long.columns = ["security_id", "industry_id", "constituent_weight"]
                c_long = c_long[c_long["constituent_weight"].abs() > 0]
                c_long.insert(0, "exposure_date", exposure_date)
                c_long.insert(1, "return_date", return_date)
                c_long.insert(2, "industry_snapshot_date", sdiag["snapshot_date"])
                constituent_frames.append(c_long)

            for mode, construction in constructions.items():
                b = construction.basis_matrix
                x = construction.base_weights
                m = construction.lookthrough_weights
                raw = pd.Series(b.T @ r, index=b.columns)
                theoretical = pd.Series(x.T @ raw, index=x.columns, name=return_date)
                via_stock = pd.Series(m.T @ r, index=m.columns, name=return_date)
                identity_error = float((theoretical - via_stock).abs().max())
                identity_rows.append(
                    {
                        "return_date": return_date,
                        "exposure_date": exposure_date,
                        "basis_mode": mode,
                        "identity_error": identity_error,
                        "passed": identity_error <= cfg.augmented_identity_tolerance,
                    }
                )
                if identity_error > cfg.augmented_identity_tolerance:
                    raise AssertionError(
                        f"{mode} basis/lookthrough identity error {identity_error:.3e} "
                        f"on {return_date.date()}"
                    )
                coverage = _portfolio_coverage(m, rdiag["missing_mask"])
                if cfg.missing_return_policy == "coverage_threshold":
                    theoretical = theoretical.where(coverage >= cfg.basket_min_return_coverage)
                result_rows[mode].append(theoretical)

                basis_published = raw.copy()
                pub_industry = _published_industry_basis_returns(
                    published, return_date, construction.basis_metadata, cfg
                )
                if len(pub_industry):
                    basis_published.loc[pub_industry.index] = pub_industry
                if mode in {"industry_only", "theme_plus_industry"}:
                    pub_rep = pd.Series(
                        x.T @ basis_published,
                        index=x.columns,
                        name=return_date,
                    )
                    if cfg.missing_return_policy == "coverage_threshold":
                        pub_rep = pub_rep.where(coverage >= cfg.basket_min_return_coverage)
                    result_rows[f"{mode}_published"].append(pub_rep)
                else:
                    pub_rep = pd.Series(np.nan, index=x.columns, name=return_date)

                diag = construction.diagnostics.copy()
                diag["return_date"] = return_date
                diag["stock_return_coverage"] = rdiag["stock_return_coverage"]
                diag["n_missing_stock_returns"] = rdiag["n_missing_stock_returns"]
                diag["lookthrough_return_coverage"] = diag["target_theme"].map(coverage)
                diag["identity_error"] = identity_error
                diag["base_weight_turnover"] = diag["target_theme"].map(
                    _basis_turnover(x, previous.get(mode))
                )
                diag["lookthrough_stock_turnover"] = diag["target_theme"].map(
                    _basis_turnover(m, previous_lookthrough.get(mode))
                )
                diag["published_replication_shortfall"] = diag["target_theme"].map(
                    (pub_rep - theoretical) if mode in {"industry_only", "theme_plus_industry"} else pd.Series(dtype=float)
                )
                diag_frames.append(diag)

                w_long = x.rename_axis(index="base_portfolio", columns="target_theme").stack().rename("weight").reset_index()
                w_long.insert(0, "exposure_date", exposure_date)
                w_long.insert(1, "return_date", return_date)
                w_long.insert(2, "basis_mode", mode)
                w_long = w_long.merge(
                    construction.basis_metadata.reset_index(), on="base_portfolio", how="left"
                )
                w_long["long_short_side"] = np.where(
                    w_long["weight"] > cfg.augmented_rank_tolerance,
                    "long",
                    np.where(w_long["weight"] < -cfg.augmented_rank_tolerance, "short", "zero"),
                )
                weight_frames.append(w_long)

                if cfg.save_augmented_lookthrough_stock_weights:
                    m_long = m.rename_axis(index="security_id", columns="target_theme").stack().rename("weight").reset_index()
                    m_long.insert(0, "exposure_date", exposure_date)
                    m_long.insert(1, "return_date", return_date)
                    m_long.insert(2, "basis_mode", mode)
                    lookthrough_frames.append(m_long)

                raw_named = raw.copy()
                raw_named.index = pd.MultiIndex.from_product(
                    [[mode], raw_named.index], names=["basis_mode", "base_portfolio"]
                )
                raw_basis_rows.append(pd.Series(raw_named, name=return_date))
                previous[mode] = x.copy()
                previous_lookthrough[mode] = m.copy()
        except Exception as exc:
            diag_frames.append(
                pd.DataFrame(
                    [
                        {
                            "return_date": return_date,
                            "exposure_date": exposure_date,
                            "basis_mode": None,
                            "target_theme": None,
                            "solver_status": f"skipped:{type(exc).__name__}",
                            "return_status": str(exc),
                        }
                    ]
                )
            )

    returns = {
        key: pd.DataFrame(rows).sort_index() if rows else pd.DataFrame()
        for key, rows in result_rows.items()
    }
    reconstructed = pd.DataFrame(recon_rows).sort_index() if recon_rows else pd.DataFrame()
    raw_basis = pd.DataFrame(raw_basis_rows).sort_index() if raw_basis_rows else pd.DataFrame()
    artifacts = AugmentedReplicationArtifacts(
        replicated_returns=returns,
        diagnostics=pd.concat(diag_frames, ignore_index=True) if diag_frames else pd.DataFrame(),
        basis_diagnostics=pd.concat(rank_frames, ignore_index=True) if rank_frames else pd.DataFrame(),
        base_weights_long=pd.concat(weight_frames, ignore_index=True) if weight_frames else pd.DataFrame(),
        lookthrough_stock_weights_long=pd.concat(lookthrough_frames, ignore_index=True) if lookthrough_frames else pd.DataFrame(),
        industry_constituent_weights_long=pd.concat(constituent_frames, ignore_index=True) if constituent_frames else pd.DataFrame(),
        raw_basis_returns=raw_basis,
        industry_index_returns_reconstructed=reconstructed,
        industry_index_reconciliation=pd.DataFrame(recon_long_rows),
        identity_checks=pd.DataFrame(identity_rows),
        input_schema_checks=validate_augmented_input_schema(data, cfg),
    )
    return returns, artifacts


def augmented_replicated_theme_returns(
    data: dict,
    cfg: Config,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool = False,
) -> tuple[dict[str, pd.DataFrame], AugmentedReplicationArtifacts]:
    """Run the full walk-forward replication under a bounded BLAS thread pool."""
    if cfg.linear_algebra_threads is None:
        return _augmented_replicated_theme_returns_impl(
            data, cfg, theme_returns, momentum_neutral=momentum_neutral
        )
    try:
        from threadpoolctl import threadpool_limits
    except Exception:
        return _augmented_replicated_theme_returns_impl(
            data, cfg, theme_returns, momentum_neutral=momentum_neutral
        )
    with threadpool_limits(limits=max(1, int(cfg.linear_algebra_threads)), user_api="blas"):
        return _augmented_replicated_theme_returns_impl(
            data, cfg, theme_returns, momentum_neutral=momentum_neutral
        )


def _pair_metrics(target: pd.Series, replica: pd.Series, annualization: int) -> dict[str, Any]:
    return base._pair_metrics(target, replica, annualization)


def _moving_block_bootstrap_mean(
    values: np.ndarray,
    samples: int,
    block_length: int,
    seed: int,
) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    n = len(values)
    if n == 0 or samples <= 0:
        return np.nan, np.nan
    block = max(1, min(int(block_length), n))
    rng = np.random.default_rng(seed)
    starts = np.arange(n)
    means = np.empty(samples)
    n_blocks = int(math.ceil(n / block))
    for i in range(samples):
        chosen = rng.choice(starts, size=n_blocks, replace=True)
        draw = np.concatenate(
            [values[(np.arange(start, start + block) % n)] for start in chosen]
        )[:n]
        means[i] = draw.mean()
    return float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def _paired_loss_test(
    purified: pd.Series,
    baseline: pd.Series,
    candidate: pd.Series,
    cfg: Config,
    seed_offset: int,
) -> dict[str, Any]:
    frame = pd.concat(
        {"purified": purified, "baseline": baseline, "candidate": candidate}, axis=1
    ).dropna()
    if frame.empty:
        return {"n_obs": 0}
    e_base = frame["baseline"] - frame["purified"]
    e_cand = frame["candidate"] - frame["purified"]
    improvement = e_base**2 - e_cand**2
    out: dict[str, Any] = {
        "n_obs": len(frame),
        "mean_squared_error_improvement": float(improvement.mean()),
        "baseline_mse": float(np.mean(e_base**2)),
        "candidate_mse": float(np.mean(e_cand**2)),
        "fraction_months_improved": float((improvement > 0).mean()),
    }
    if len(frame) >= max(5, cfg.paired_loss_hac_lags + 2):
        try:
            import statsmodels.api as sm

            fit = sm.OLS(improvement.to_numpy(), np.ones((len(improvement), 1))).fit(
                cov_type="HAC", cov_kwds={"maxlags": cfg.paired_loss_hac_lags}
            )
            out.update(
                {
                    "hac_standard_error": float(fit.bse[0]),
                    "hac_t_stat": float(fit.tvalues[0]),
                    "hac_p_value": float(fit.pvalues[0]),
                }
            )
        except Exception as exc:
            out.update(
                {
                    "hac_standard_error": np.nan,
                    "hac_t_stat": np.nan,
                    "hac_p_value": np.nan,
                    "hac_error": f"{type(exc).__name__}:{exc}",
                }
            )
    lo, hi = _moving_block_bootstrap_mean(
        improvement.to_numpy(),
        cfg.paired_loss_bootstrap_samples,
        cfg.paired_loss_block_length,
        cfg.bootstrap_seed + seed_offset,
    )
    out["block_bootstrap_ci_low"] = lo
    out["block_bootstrap_ci_high"] = hi
    return out


def compare_basis_extensions(
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    replicated_returns: Mapping[str, pd.DataFrame],
    cfg: Config,
) -> dict[str, pd.DataFrame | dict[str, pd.DataFrame]]:
    frames: dict[str, pd.DataFrame] = {
        "purified": purified.sort_index(),
        "stock_coefficient": stock_rep.sort_index(),
    }
    for key, value in replicated_returns.items():
        if value is not None and not value.empty:
            frames[key] = value.sort_index()
    all_dates = pd.Index([])
    all_themes = pd.Index([])
    for frame in frames.values():
        all_dates = all_dates.union(frame.index)
        all_themes = all_themes.union(frame.columns)
    all_dates = all_dates.sort_values()
    aligned = {
        name: frame.reindex(index=all_dates, columns=all_themes)
        for name, frame in frames.items()
    }

    metrics_rows = []
    rolling_rows = []
    for name, frame in aligned.items():
        if name == "purified":
            continue
        for theme in all_themes:
            metrics_rows.append(
                {
                    "target_series": "purified",
                    "replica_series": name,
                    "theme": theme,
                    **_pair_metrics(aligned["purified"][theme], frame[theme], cfg.annualization),
                }
            )
            pair = pd.concat(
                {"target": aligned["purified"][theme], "replica": frame[theme]}, axis=1
            )
            corr = pair["target"].rolling(cfg.comparison_rolling_months).corr(pair["replica"])
            te = (pair["replica"] - pair["target"]).rolling(
                cfg.comparison_rolling_months
            ).std(ddof=1)
            rolling_rows.append(
                pd.DataFrame(
                    {
                        "date": all_dates,
                        "replica_series": name,
                        "theme": theme,
                        "rolling_correlation": corr.to_numpy(),
                        "rolling_tracking_error_monthly": te.to_numpy(),
                        "rolling_tracking_error_annualized": te.to_numpy()
                        * math.sqrt(cfg.annualization),
                    }
                )
            )
    metrics = pd.DataFrame(metrics_rows)
    numeric = metrics.select_dtypes(include=[np.number]).columns.tolist()
    aggregate = (
        metrics.groupby("replica_series", dropna=False)[numeric]
        .agg(["mean", "median"])
        .reset_index()
    )
    aggregate.columns = [
        "_".join([str(x) for x in col if str(x)]) if isinstance(col, tuple) else str(col)
        for col in aggregate.columns
    ]

    te_rows = []
    test_rows = []
    candidates = [
        x
        for x in ["theme_plus_industry", "theme_plus_industry_published"]
        if x in aligned and "theme_only" in aligned
    ]
    for c_idx, candidate_name in enumerate(candidates):
        for t_idx, theme in enumerate(all_themes):
            pair = pd.concat(
                {
                    "purified": aligned["purified"][theme],
                    "theme_only": aligned["theme_only"][theme],
                    "candidate": aligned[candidate_name][theme],
                },
                axis=1,
            ).dropna()
            if pair.empty:
                continue
            e_theme = pair["theme_only"] - pair["purified"]
            e_candidate = pair["candidate"] - pair["purified"]
            te_theme = float(e_theme.std(ddof=1) * math.sqrt(cfg.annualization))
            te_candidate = float(e_candidate.std(ddof=1) * math.sqrt(cfg.annualization))
            te_rows.append(
                {
                    "candidate_series": candidate_name,
                    "theme": theme,
                    "n_obs": len(pair),
                    "theme_only_te_annualized": te_theme,
                    "candidate_te_annualized": te_candidate,
                    "te_reduction_absolute": te_theme - te_candidate,
                    "te_reduction_ratio": np.nan if te_theme == 0 else 1.0 - te_candidate / te_theme,
                    "theme_only_rmse": float(np.sqrt(np.mean(e_theme**2))),
                    "candidate_rmse": float(np.sqrt(np.mean(e_candidate**2))),
                }
            )
            test_rows.append(
                {
                    "candidate_series": candidate_name,
                    "theme": theme,
                    **_paired_loss_test(
                        pair["purified"],
                        pair["theme_only"],
                        pair["candidate"],
                        cfg,
                        seed_offset=1000 * c_idx + t_idx,
                    ),
                }
            )

    returns_long = (
        pd.concat(aligned, names=["series", "date"])
        .rename_axis(index=["series", "date"], columns="theme")
        .stack(future_stack=True)
        .rename("return")
        .reset_index()
    )
    coverage_rows = []
    for name, frame in aligned.items():
        for theme in all_themes:
            coverage_rows.append(
                {
                    "series": name,
                    "theme": theme,
                    "n_available": int(frame[theme].notna().sum()),
                    "n_periods": len(frame),
                    "coverage_ratio": float(frame[theme].notna().mean()) if len(frame) else np.nan,
                }
            )
    return {
        "aligned_returns": aligned,
        "metrics_by_theme": metrics,
        "metrics_aggregate": aggregate,
        "te_reduction_by_theme": pd.DataFrame(te_rows),
        "paired_loss_tests": pd.DataFrame(test_rows),
        "rolling_metrics": pd.concat(rolling_rows, ignore_index=True) if rolling_rows else pd.DataFrame(),
        "coverage": pd.DataFrame(coverage_rows),
        "returns_long": returns_long,
    }


def run_augmented_basis_self_tests(cfg: Config) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    local = Config(**asdict(cfg))
    local.augmented_fallback_mode = "skip"
    local.augmented_enforce_target_exposure = False
    local.augmented_enforce_neutrality = False
    q_metric = np.eye(1)

    def solve(b: np.ndarray, m: np.ndarray) -> tuple[np.ndarray, float]:
        q = b.T @ b
        c = b.T @ m
        x, _ = _solve_lexicographic_equality_qp(
            q,
            c,
            np.zeros((0, b.shape[1])),
            np.zeros(0),
            local,
            secondary_metric=np.eye(b.shape[1]),
        )
        residual = b @ x - m
        return x, float(residual @ residual)

    # 1. Incremental industry direction completes the target span.
    m = np.array([1.0, -1.0])
    p = np.array([[1.0], [1.0]])
    s = np.array([[1.0], [-1.0]])
    _, te_t = solve(p, m)
    _, te_c = solve(np.column_stack([p, s]), m)
    rows.append(
        {
            "test": "industry_completes_target_span",
            "passed": te_c < 1e-12 and te_c <= te_t,
            "theme_te2": te_t,
            "combined_te2": te_c,
        }
    )

    # 2. Redundant industry column cannot improve the projection.
    m = np.array([1.0, 0.0])
    p = np.array([[1.0], [1.0]])
    _, te_t = solve(p, m)
    _, te_c = solve(np.column_stack([p, 2.0 * p]), m)
    rows.append(
        {
            "test": "redundant_industry_no_change",
            "passed": abs(te_t - te_c) < 1e-10,
            "theme_te2": te_t,
            "combined_te2": te_c,
        }
    )

    # 3. Rank gain orthogonal to an already exact target leaves TE at zero.
    m = np.array([1.0, 0.0, 0.0])
    p = np.array([[1.0], [0.0], [0.0]])
    s = np.array([[0.0], [1.0], [0.0]])
    _, te_t = solve(p, m)
    _, te_c = solve(np.column_stack([p, s]), m)
    rows.append(
        {
            "test": "rank_gain_orthogonal_residual_no_change",
            "passed": te_t < 1e-12 and te_c < 1e-12,
            "theme_te2": te_t,
            "combined_te2": te_c,
        }
    )

    # 4. Partial alignment gives a strict but incomplete reduction.
    m = np.array([1.0, 1.0, 1.0])
    p = np.array([[1.0], [0.0], [0.0]])
    s = np.array([[0.0], [1.0], [0.0]])
    _, te_t = solve(p, m)
    _, te_c = solve(np.column_stack([p, s]), m)
    rows.append(
        {
            "test": "partial_industry_alignment",
            "passed": 0 < te_c < te_t,
            "theme_te2": te_t,
            "combined_te2": te_c,
        }
    )

    # 5. Redundant hard constraints are handled by SVD/pseudoinverse.
    q = np.eye(2)
    c = np.array([1.0, -1.0])
    g = np.array([[1.0, 1.0], [2.0, 2.0]])
    d = np.array([0.0, 0.0])
    x, diag = _solve_lexicographic_equality_qp(
        q, c, g, d, local, secondary_metric=np.eye(2)
    )
    rows.append(
        {
            "test": "redundant_constraint_svd",
            "passed": abs(x.sum()) < local.augmented_constraint_tolerance
            and diag["constraint_rank"] == 1,
            "theme_te2": np.nan,
            "combined_te2": np.nan,
        }
    )
    return pd.DataFrame(rows)


def build_augmented_acceptance_checks(
    cfg: Config,
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    artifacts: AugmentedReplicationArtifacts,
    self_tests: pd.DataFrame,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []

    def add(check: str, value: Any, tolerance: Any, passed: bool, detail: str = "") -> None:
        rows.append(
            {
                "check": check,
                "value": value,
                "tolerance": tolerance,
                "passed": bool(passed),
                "detail": detail,
            }
        )

    p, s = purified.align(stock_rep, join="inner", axis=0)
    p, s = p.align(s, join="inner", axis=1)
    stock_error = float((p - s).abs().max().max()) if not p.empty else np.nan
    add(
        "stock_coefficient_replication",
        stock_error,
        cfg.stock_replication_tolerance,
        np.isfinite(stock_error) and stock_error <= cfg.stock_replication_tolerance,
    )

    identity = artifacts.identity_checks["identity_error"].max() if not artifacts.identity_checks.empty else np.nan
    add(
        "basis_lookthrough_return_identity",
        identity,
        cfg.augmented_identity_tolerance,
        np.isfinite(identity) and identity <= cfg.augmented_identity_tolerance,
    )

    hard = artifacts.diagnostics[
        artifacts.diagnostics.get("solver_status", pd.Series(dtype=str)).astype(str).str.startswith("hard_solved")
    ]
    neutrality = hard["max_abs_neutralization_exposure"].max() if len(hard) else np.nan
    target = hard["target_theme_exposure_error"].abs().max() if len(hard) else np.nan
    add(
        "hard_neutrality_constraints",
        neutrality,
        cfg.augmented_constraint_tolerance,
        np.isfinite(neutrality) and neutrality <= cfg.augmented_constraint_tolerance,
    )
    add(
        "hard_target_exposure_constraints",
        target,
        cfg.augmented_constraint_tolerance,
        np.isfinite(target) and target <= cfg.augmented_constraint_tolerance,
    )

    combined = artifacts.diagnostics[
        artifacts.diagnostics.get("basis_mode", pd.Series(dtype=str)).eq("theme_plus_industry")
    ]
    nonworse = combined.get("nonworsening_check_passed", pd.Series(dtype=bool)).dropna()
    add(
        "combined_exante_te_nonworsening",
        float(nonworse.mean()) if len(nonworse) else np.nan,
        1.0,
        len(nonworse) > 0 and bool(nonworse.all()),
    )

    rank = artifacts.basis_diagnostics
    industry_counts = rank.loc[
        rank["basis_mode"].eq("theme_plus_industry"), "n_industry_bases"
    ] if not rank.empty else pd.Series(dtype=float)
    add(
        "expected_industry_count",
        float(industry_counts.min()) if len(industry_counts) else np.nan,
        cfg.industry_expected_count,
        len(industry_counts) > 0
        and (not cfg.industry_require_expected_count or bool((industry_counts == cfg.industry_expected_count).all())),
    )

    recon = artifacts.industry_index_reconciliation
    recon_error = recon["reconciliation_error"].abs().max() if not recon.empty else np.nan
    add(
        "published_index_reconciliation",
        recon_error,
        cfg.industry_index_reconciliation_tolerance,
        np.isfinite(recon_error) and recon_error <= cfg.industry_index_reconciliation_tolerance,
        "Synthetic data are exact unless synthetic_published_index_noise is non-zero.",
    )

    point_in_time = True
    if not recon.empty:
        point_in_time = bool(
            (pd.to_datetime(recon["industry_snapshot_date"]) <= pd.to_datetime(recon["exposure_date"])).all()
            and (pd.to_datetime(recon["exposure_date"]) < pd.to_datetime(recon["return_date"])).all()
        )
    add("point_in_time_alignment", int(point_in_time), 1, point_in_time)

    self_pass = bool(self_tests["passed"].all()) if len(self_tests) else False
    add(
        "augmented_basis_self_tests",
        int(self_tests["passed"].sum()) if len(self_tests) else 0,
        len(self_tests),
        self_pass,
    )
    return pd.DataFrame(rows)


def _safe_to_parquet(df: pd.DataFrame, path: Path) -> dict[str, str]:
    try:
        df.to_parquet(path, index=False)
        return {"path": str(path), "format": "parquet", "status": "ok"}
    except Exception as exc:
        fallback = path.with_suffix(".csv")
        df.to_csv(fallback, index=False)
        return {
            "path": str(fallback),
            "format": "csv_fallback",
            "status": f"{type(exc).__name__}:{exc}",
        }


def save_augmented_replication_outputs(
    out_dir: Path,
    cfg: Config,
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    artifacts: AugmentedReplicationArtifacts,
    comparison: Mapping[str, Any],
    acceptance_checks: pd.DataFrame,
    self_tests: pd.DataFrame,
) -> dict[str, Any]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    purified.to_csv(out / "purified_theme_returns.csv")
    stock_rep.to_csv(out / "stock_coefficient_replicated_theme_returns.csv")
    for name, frame in artifacts.replicated_returns.items():
        if frame.empty:
            continue
        filename = {
            "theme_only": "theme_only_replicated_theme_returns.csv",
            "industry_only": "industry_only_replicated_theme_returns.csv",
            "theme_plus_industry": "combined_replicated_theme_returns.csv",
            "industry_only_published": "industry_only_published_index_replicated_theme_returns.csv",
            "theme_plus_industry_published": "combined_published_index_replicated_theme_returns.csv",
        }.get(name, f"{name}.csv")
        frame.to_csv(out / filename)

    artifacts.diagnostics.to_csv(out / "augmented_mimicking_diagnostics.csv", index=False)
    artifacts.basis_diagnostics.to_csv(out / "basis_extension_rank_diagnostics.csv", index=False)
    artifacts.industry_index_returns_reconstructed.to_csv(
        out / "industry_index_returns_reconstructed.csv"
    )
    artifacts.industry_index_reconciliation.to_csv(
        out / "industry_index_reconciliation.csv", index=False
    )
    artifacts.identity_checks.to_csv(out / "basis_return_identity_checks.csv", index=False)
    artifacts.input_schema_checks.to_csv(out / "augmented_input_schema_checks.csv", index=False)
    comparison["metrics_by_theme"].to_csv(out / "basis_extension_metrics_by_theme.csv", index=False)
    comparison["metrics_aggregate"].to_csv(out / "basis_extension_metrics_aggregate.csv", index=False)
    comparison["te_reduction_by_theme"].to_csv(out / "basis_extension_te_reduction_by_theme.csv", index=False)
    comparison["paired_loss_tests"].to_csv(out / "basis_extension_paired_loss_tests.csv", index=False)
    comparison["coverage"].to_csv(out / "basis_extension_coverage.csv", index=False)
    acceptance_checks.to_csv(out / "basis_extension_acceptance_checks.csv", index=False)
    self_tests.to_csv(out / "basis_extension_self_tests.csv", index=False)

    manifest: dict[str, Any] = {}
    manifest["combined_base_weights_long"] = _safe_to_parquet(
        artifacts.base_weights_long, out / "combined_base_weights_long.parquet"
    )
    manifest["basis_extension_returns_long"] = _safe_to_parquet(
        comparison["returns_long"], out / "basis_extension_returns_long.parquet"
    )
    manifest["basis_extension_rolling_metrics"] = _safe_to_parquet(
        comparison["rolling_metrics"], out / "basis_extension_rolling_metrics.parquet"
    )
    if cfg.save_industry_constituent_weights and not artifacts.industry_constituent_weights_long.empty:
        manifest["industry_basket_weights_long"] = _safe_to_parquet(
            artifacts.industry_constituent_weights_long,
            out / "industry_basket_weights_long.parquet",
        )
    if cfg.save_augmented_lookthrough_stock_weights and not artifacts.lookthrough_stock_weights_long.empty:
        manifest["combined_lookthrough_stock_weights_long"] = _safe_to_parquet(
            artifacts.lookthrough_stock_weights_long,
            out / "combined_lookthrough_stock_weights_long.parquet",
        )
    # Raw basis returns have a MultiIndex column and are easier to preserve as CSV.
    artifacts.raw_basis_returns.to_csv(out / "raw_replication_basis_returns.csv")

    with open(out / "basis_extension_config.json", "w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, indent=2, ensure_ascii=False, default=str)
    with open(out / "output_manifest.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    return manifest


def save_augmented_replication_figures(
    out_dir: Path,
    comparison: Mapping[str, Any],
    artifacts: AugmentedReplicationArtifacts,
) -> list[str]:
    import matplotlib.pyplot as plt

    figure_dir = Path(out_dir) / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    te = comparison["te_reduction_by_theme"]
    if not te.empty:
        for candidate, group in te.groupby("candidate_series"):
            g = group.sort_values("te_reduction_ratio")
            fig, ax = plt.subplots(figsize=(9, 4.5))
            ax.bar(g["theme"].astype(str), g["te_reduction_ratio"])
            ax.axhline(0.0, linewidth=0.8)
            ax.set_title(f"Realized TE reduction versus theme-only: {candidate}")
            ax.set_ylabel("1 - TE(candidate) / TE(theme-only)")
            ax.tick_params(axis="x", rotation=90)
            fig.tight_layout()
            path = figure_dir / f"te_reduction_{candidate}.png"
            fig.savefig(path, dpi=160, bbox_inches="tight")
            plt.close(fig)
            written.append(str(path))

    rank = artifacts.basis_diagnostics
    if not rank.empty:
        pivot = rank.pivot_table(
            index="return_date",
            columns="basis_mode",
            values="rank_neutral_stock_span",
            aggfunc="first",
        )
        fig, ax = plt.subplots(figsize=(9, 4))
        pivot.plot(ax=ax)
        ax.set_title("Neutral feasible stock-span rank by basis")
        ax.set_ylabel("Rank")
        fig.tight_layout()
        path = figure_dir / "neutral_feasible_rank_by_basis.png"
        fig.savefig(path, dpi=160, bbox_inches="tight")
        plt.close(fig)
        written.append(str(path))

    recon = artifacts.industry_index_reconciliation
    if not recon.empty:
        monthly = recon.groupby("return_date")["reconciliation_error"].apply(
            lambda x: float(np.sqrt(np.nanmean(np.asarray(x, dtype=float) ** 2)))
        )
        fig, ax = plt.subplots(figsize=(9, 3.5))
        monthly.plot(ax=ax)
        ax.set_title("Industry-index reconstruction RMSE")
        ax.set_ylabel("RMSE")
        fig.tight_layout()
        path = figure_dir / "industry_index_reconstruction_rmse.png"
        fig.savefig(path, dpi=160, bbox_inches="tight")
        plt.close(fig)
        written.append(str(path))
    return written


__all__ = [
    "Config",
    "TrackingRiskOperator",
    "PortfolioConstruction",
    "AugmentedReplicationArtifacts",
    "generate_synthetic_augmented_inputs",
    "load_or_generate_augmented_inputs",
    "validate_augmented_input_schema",
    "build_industry_weight_snapshots_from_long",
    "prepare_industry_index_returns",
    "prepare_industry_basket_weights",
    "build_replication_basis",
    "build_tracking_risk_operator",
    "augmented_basis_diagnostics",
    "construct_augmented_mimicking_portfolios",
    "construct_all_basis_mimicking_portfolios",
    "augmented_replicated_theme_returns",
    "compare_basis_extensions",
    "run_augmented_basis_self_tests",
    "build_augmented_acceptance_checks",
    "save_augmented_replication_outputs",
    "save_augmented_replication_figures",
    "estimate_theme_returns",
    "stock_replicated_theme_returns",
]
