#!/usr/bin/env python3
"""Run purified-theme replication with theme baskets and TSE 33-sector baskets.

The input pickle is expected to contain the legacy theme-factor inputs plus
point-in-time industry constituent weights and industry index returns/levels.
See THEME_PLUS_TSE33_IMPLEMENTATION_README.md for the canonical schema.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

import theme_plus_industry_mimicking as aug


def _json_default(value: Any) -> Any:
    if isinstance(value, (pd.Timestamp, np.datetime64)):
        return str(pd.Timestamp(value))
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(f"Cannot serialize {type(value).__name__}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Replicate purified theme-factor returns with theme baskets, "
            "TSE 33-sector baskets, and their combined long-short basis."
        )
    )
    parser.add_argument("--input-pickle", type=Path, help="Production input pickle")
    parser.add_argument(
        "--config-json",
        type=Path,
        help="Optional JSON object overriding Config fields",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("theme_plus_tse33_outputs"),
        help="Output directory",
    )
    parser.add_argument(
        "--synthetic",
        action="store_true",
        help="Run the built-in 33-industry synthetic validation dataset",
    )
    parser.add_argument(
        "--risk-model",
        choices=[
            "auto",
            "factor_covariance",
            "sample_shrinkage",
            "diagonal_variance",
            "unit",
        ],
        help="Tracking-risk model override",
    )
    parser.add_argument(
        "--momentum-neutral",
        action="store_true",
        help="Include prior stock momentum in the neutralization matrix",
    )
    parser.add_argument(
        "--bootstrap-samples",
        type=int,
        help="Moving-block bootstrap sample count for paired loss tests",
    )
    parser.add_argument(
        "--no-figures",
        action="store_true",
        help="Do not save diagnostic figures",
    )
    parser.add_argument(
        "--strict-acceptance",
        action="store_true",
        help="Return a non-zero status if any acceptance check fails",
    )
    return parser.parse_args()


def load_config(args: argparse.Namespace) -> aug.Config:
    values: dict[str, Any] = {}
    if args.config_json:
        with args.config_json.open("r", encoding="utf-8") as f:
            values = json.load(f)
        if not isinstance(values, dict):
            raise TypeError("--config-json must contain a JSON object")
    cfg = aug.Config(**values)
    if args.input_pickle is not None:
        cfg.input_pickle = str(args.input_pickle)
    if args.risk_model is not None:
        cfg.augmented_tracking_risk_model = args.risk_model
    if args.bootstrap_samples is not None:
        cfg.paired_loss_bootstrap_samples = args.bootstrap_samples
    cfg.use_synthetic_if_missing = bool(args.synthetic)
    cfg.basket_fallback_to_theme_exposures = False
    cfg.industry_require_expected_count = True
    return cfg


def main() -> int:
    args = parse_args()
    cfg = load_config(args)
    out_dir = args.output_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.synthetic:
        data = aug.generate_synthetic_augmented_inputs(cfg)
    else:
        if not Path(cfg.input_pickle).exists():
            raise FileNotFoundError(
                f"Production input pickle not found: {cfg.input_pickle}. "
                "Use --synthetic only for the validation run."
            )
        data = aug.load_or_generate_augmented_inputs(cfg)

    input_checks = aug.validate_augmented_input_schema(data, cfg)
    if not input_checks["passed"].all():
        failed = input_checks.loc[~input_checks["passed"]]
        raise ValueError("Input schema checks failed:\n" + failed.to_string(index=False))

    purified, purification_diagnostics = aug.estimate_theme_returns(
        data, cfg, momentum_neutral=args.momentum_neutral
    )
    stock_rep, stock_diagnostics = aug.stock_replicated_theme_returns(
        data,
        cfg,
        purified,
        momentum_neutral=args.momentum_neutral,
        mode="coefficient",
        return_diagnostics=True,
    )
    replicated, artifacts = aug.augmented_replicated_theme_returns(
        data,
        cfg,
        purified,
        momentum_neutral=args.momentum_neutral,
    )
    comparison = aug.compare_basis_extensions(purified, stock_rep, replicated, cfg)
    self_tests = aug.run_augmented_basis_self_tests(cfg)
    acceptance = aug.build_augmented_acceptance_checks(
        cfg, purified, stock_rep, artifacts, self_tests
    )
    manifest = aug.save_augmented_replication_outputs(
        out_dir,
        cfg,
        purified,
        stock_rep,
        artifacts,
        comparison,
        acceptance,
        self_tests,
    )
    figure_paths = []
    if not args.no_figures:
        figure_paths = aug.save_augmented_replication_figures(
            out_dir, comparison, artifacts
        )

    # Keep the legacy diagnostics available without forcing them into the main
    # comparison files.
    if isinstance(purification_diagnostics, pd.DataFrame):
        purification_diagnostics.to_csv(
            out_dir / "purification_diagnostics.csv", index=False
        )
    if isinstance(stock_diagnostics, pd.DataFrame):
        stock_diagnostics.to_csv(
            out_dir / "stock_coefficient_replication_diagnostics.csv", index=False
        )

    te = comparison["te_reduction_by_theme"]
    te_summary: dict[str, Any] = {}
    if not te.empty:
        for candidate, group in te.groupby("candidate_series"):
            te_summary[str(candidate)] = {
                "n_themes": int(group["theme"].nunique()),
                "median_te_reduction_ratio": float(group["te_reduction_ratio"].median()),
                "mean_te_reduction_ratio": float(group["te_reduction_ratio"].mean()),
                "share_themes_with_positive_te_reduction": float(
                    group["te_reduction_ratio"].gt(0).mean()
                ),
            }

    combined_diag = artifacts.diagnostics[
        artifacts.diagnostics.get("basis_mode", pd.Series(dtype=str)).eq(
            "theme_plus_industry"
        )
    ]
    summary = {
        "config": asdict(cfg),
        "n_return_dates": int(len(purified)),
        "n_themes": int(purified.shape[1]),
        "n_industries_expected": int(cfg.industry_expected_count),
        "all_input_checks_passed": bool(input_checks["passed"].all()),
        "all_self_tests_passed": bool(self_tests["passed"].all()),
        "all_acceptance_checks_passed": bool(acceptance["passed"].all()),
        "combined_nonworsening_pass_rate": float(
            combined_diag.get("nonworsening_check_passed", pd.Series(dtype=float)).mean()
        ),
        "max_basis_lookthrough_identity_error": float(
            artifacts.identity_checks["identity_error"].max()
        ),
        "max_industry_index_reconciliation_error": float(
            artifacts.industry_index_reconciliation["reconciliation_error"].abs().max()
        ),
        "te_reduction_summary": te_summary,
        "output_manifest": manifest,
        "figures": figure_paths,
    }
    with (out_dir / "run_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False, default=_json_default)

    print(json.dumps(summary, indent=2, ensure_ascii=False, default=_json_default))
    if args.strict_acceptance and not summary["all_acceptance_checks_passed"]:
        return 2
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise
