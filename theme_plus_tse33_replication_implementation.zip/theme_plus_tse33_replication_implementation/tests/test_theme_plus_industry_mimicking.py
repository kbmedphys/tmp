from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

import theme_basket_mimicking as legacy
import theme_plus_industry_mimicking as aug


@pytest.fixture(scope="module")
def synthetic_run():
    cfg = aug.Config(
        n_months=18,
        n_stocks=132,
        n_themes=14,
        n_industries=33,
        industry_expected_count=33,
        industry_min_constituents=2,
        augmented_tracking_risk_model="diagonal_variance",
        paired_loss_bootstrap_samples=20,
        paired_loss_block_length=3,
        comparison_rolling_months=6,
        save_industry_constituent_weights=True,
        save_augmented_lookthrough_stock_weights=False,
    )
    data = aug.generate_synthetic_augmented_inputs(cfg)
    purified, _ = aug.estimate_theme_returns(data, cfg)
    stock, _ = aug.stock_replicated_theme_returns(
        data,
        cfg,
        purified,
        mode="coefficient",
        return_diagnostics=True,
    )
    replicated, artifacts = aug.augmented_replicated_theme_returns(
        data, cfg, purified
    )
    comparison = aug.compare_basis_extensions(purified, stock, replicated, cfg)
    self_tests = aug.run_augmented_basis_self_tests(cfg)
    acceptance = aug.build_augmented_acceptance_checks(
        cfg, purified, stock, artifacts, self_tests
    )
    return cfg, data, purified, stock, replicated, artifacts, comparison, self_tests, acceptance


def test_synthetic_schema_and_33_industries(synthetic_run):
    cfg, data, *_ = synthetic_run
    checks = aug.validate_augmented_input_schema(data, cfg)
    assert checks["passed"].all(), checks.to_string()
    sample = next(iter(data[cfg.industry_basket_weights_key].values()))
    assert sample.shape[1] == 33
    np.testing.assert_allclose(sample.sum(axis=0).to_numpy(), 1.0, atol=1e-12)
    assert (sample >= 0).all().all()


def test_one_date_combined_basis_nonworsening(synthetic_run):
    cfg, data, purified, *_ = synthetic_run
    return_date = purified.index[5]
    pos = data["stock_returns"].index.get_loc(return_date)
    exposure_date = data["stock_returns"].index[pos - 1]
    constructions, rank_diag, risk = aug.construct_all_basis_mimicking_portfolios(
        data, cfg, exposure_date
    )
    assert set(constructions) == {
        "theme_only",
        "industry_only",
        "theme_plus_industry",
    }
    theme = constructions["theme_only"].diagnostics.set_index("target_theme")
    combined = constructions["theme_plus_industry"].diagnostics.set_index("target_theme")
    assert (
        combined["ex_ante_tracking_error_squared"]
        <= theme["ex_ante_tracking_error_squared"]
        + cfg.augmented_nonworsening_tolerance
    ).all()
    assert (combined["nonworsening_check_passed"] == True).all()  # noqa: E712
    assert rank_diag.loc[
        rank_diag["basis_mode"].eq("theme_plus_industry"), "n_industry_bases"
    ].iloc[0] == 33
    assert risk.source


def test_return_identity_and_index_reconciliation(synthetic_run):
    cfg, data, purified, stock, replicated, artifacts, *_ = synthetic_run
    assert all(not frame.empty for frame in replicated.values())
    assert artifacts.identity_checks["passed"].all()
    assert artifacts.identity_checks["identity_error"].max() <= cfg.augmented_identity_tolerance
    assert (
        artifacts.industry_index_reconciliation["reconciliation_error"].abs().max()
        <= cfg.industry_index_reconciliation_tolerance
    )
    assert (
        pd.to_datetime(artifacts.industry_index_reconciliation["industry_snapshot_date"])
        <= pd.to_datetime(artifacts.industry_index_reconciliation["exposure_date"])
    ).all()
    assert (
        pd.to_datetime(artifacts.industry_index_reconciliation["exposure_date"])
        < pd.to_datetime(artifacts.industry_index_reconciliation["return_date"])
    ).all()


def test_comparison_and_acceptance(synthetic_run):
    *_, comparison, self_tests, acceptance = synthetic_run
    assert not comparison["te_reduction_by_theme"].empty
    assert set(comparison["te_reduction_by_theme"]["candidate_series"].unique()) == {
        "theme_plus_industry",
        "theme_plus_industry_published",
    }
    assert self_tests["passed"].all(), self_tests.to_string()
    assert acceptance["passed"].all(), acceptance.to_string()


def test_factor_risk_operator(synthetic_run):
    cfg, data, purified, *_ = synthetic_run
    factor_cfg = aug.Config(**asdict(cfg))
    factor_cfg.augmented_tracking_risk_model = "factor_covariance"
    return_date = purified.index[3]
    pos = data["stock_returns"].index.get_loc(return_date)
    exposure_date = data["stock_returns"].index[pos - 1]
    stock_target, diag = legacy.construct_stock_mimicking_portfolios(
        data, factor_cfg, exposure_date, mode="coefficient"
    )
    op = aug.build_tracking_risk_operator(
        data, exposure_date, stock_target.index, factor_cfg
    )
    assert op.kind == "factor"
    x = np.eye(len(stock_target.index), 2)
    q = x.T @ op.apply(x)
    assert np.all(np.linalg.eigvalsh(0.5 * (q + q.T)) >= -1e-12)


def test_long_constituent_history_is_point_in_time():
    history = pd.DataFrame(
        {
            "security_id": ["A", "B", "A", "B"],
            "industry_code": ["I1", "I1", "I1", "I1"],
            "weight": [0.6, 0.4, 0.3, 0.7],
            "effective_date": [
                "2020-01-01",
                "2020-01-01",
                "2020-02-01",
                "2020-02-01",
            ],
            "knowledge_date": [
                "2020-01-01",
                "2020-01-01",
                "2020-02-05",
                "2020-02-05",
            ],
        }
    )
    snaps = aug.build_industry_weight_snapshots_from_long(
        history, [pd.Timestamp("2020-01-31"), pd.Timestamp("2020-02-29")]
    )
    assert np.isclose(snaps[pd.Timestamp("2020-01-31")].loc["A", "I1"], 0.6)
    assert np.isclose(snaps[pd.Timestamp("2020-02-29")].loc["A", "I1"], 0.3)


def test_legacy_stock_factor_estimation_is_unchanged(synthetic_run):
    cfg, data, *_ = synthetic_run
    legacy_returns, _ = legacy.estimate_theme_returns(data, cfg)
    augmented_alias_returns, _ = aug.estimate_theme_returns(data, cfg)
    pd.testing.assert_frame_equal(legacy_returns, augmented_alias_returns)


def test_save_outputs(tmp_path: Path, synthetic_run):
    cfg, data, purified, stock, replicated, artifacts, comparison, self_tests, acceptance = synthetic_run
    manifest = aug.save_augmented_replication_outputs(
        tmp_path,
        cfg,
        purified,
        stock,
        artifacts,
        comparison,
        acceptance,
        self_tests,
    )
    required = [
        "combined_replicated_theme_returns.csv",
        "combined_published_index_replicated_theme_returns.csv",
        "basis_extension_rank_diagnostics.csv",
        "industry_index_reconciliation.csv",
        "basis_extension_acceptance_checks.csv",
        "basis_extension_config.json",
    ]
    for name in required:
        assert (tmp_path / name).exists(), name
    assert manifest["combined_base_weights_long"]["status"] == "ok"


def test_production_safe_defaults():
    cfg = aug.Config()
    assert cfg.use_synthetic_if_missing is False
    assert cfg.basket_fallback_to_theme_exposures is False
    assert cfg.industry_require_expected_count is True


def test_industry_metadata_blocks_lookahead(synthetic_run):
    cfg, data, *_ = synthetic_run
    date = data["stock_returns"].index[3]
    broken = dict(data)
    broken[cfg.industry_basket_metadata_key] = dict(
        data[cfg.industry_basket_metadata_key]
    )
    broken[cfg.industry_basket_metadata_key][date] = {
        "effective_date": date,
        "knowledge_date": date + pd.offsets.MonthEnd(1),
        "point_in_time_ok": False,
    }
    with pytest.raises(AssertionError):
        aug.prepare_industry_basket_weights(
            broken,
            date,
            data["stock_returns"].columns,
            cfg,
        )


def test_long_history_selects_one_coherent_version():
    history = pd.DataFrame(
        {
            "security_id": ["A", "B", "A", "B"],
            "industry_code": ["I1", "I1", "I1", "I1"],
            "weight": [0.6, 0.4, 0.2, 0.8],
            "effective_date": ["2020-01-01"] * 4,
            "knowledge_date": [
                "2020-01-01",
                "2020-01-01",
                "2020-01-05",
                "2020-01-05",
            ],
        }
    )
    snapshots, metadata = aug.build_industry_weight_snapshots_from_long(
        history,
        [pd.Timestamp("2020-01-31")],
        return_metadata=True,
    )
    snapshot = snapshots[pd.Timestamp("2020-01-31")]
    np.testing.assert_allclose(snapshot["I1"].reindex(["A", "B"]), [0.2, 0.8])
    assert metadata[pd.Timestamp("2020-01-31")]["knowledge_date"] == pd.Timestamp(
        "2020-01-05"
    )
