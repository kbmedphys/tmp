# Quick start

## 合成33業種で動作確認

```bash
python run_theme_plus_tse33_replication.py \
  --synthetic \
  --config-json example_theme_plus_tse33_config.json \
  --output-dir outputs_synthetic \
  --strict-acceptance
```

`example_theme_plus_tse33_config.json` は本番向けの入力パスを含むため、合成実行で
規模を小さくする場合は `n_months`, `n_stocks`, `n_themes` をJSONへ追加する。
`n_stocks >= 33 * industry_min_constituents` が必要である。

## 本番データ

```bash
python run_theme_plus_tse33_replication.py \
  --input-pickle data/theme_factor_inputs_with_tse33.pkl \
  --config-json example_theme_plus_tse33_config.json \
  --output-dir outputs_production \
  --strict-acceptance
```

入力キーと日付規約は `README.md` を参照する。
