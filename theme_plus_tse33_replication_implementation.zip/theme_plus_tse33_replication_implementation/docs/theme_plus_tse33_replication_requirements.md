# テーマバスケット＋東証33業種指数による純化テーマファクター複製

## 定式化・実装要件定義書

**対象実装**: `theme_basket_mimicking.py` および実行済み診断ノートブック  
**目的**: 純化テーマファクターリターンを、テーマバスケットだけでなく東証33業種指数等の業種バスケットも用いたロング・ショートで複製し、テーマバスケット単独の場合よりトラッキングエラーを低減できるかを検証する。

---

## 1. 結論

テーマバスケットに業種指数を追加すると、**理論上の表現空間が拡張するため、同一の中立化制約・対象テーマ尺度・損失関数の下では、最小化された ex-ante トラッキング損失は悪化せず、弱く改善する**。

ただし、改善が厳密に正となるためには、追加した業種指数が次の双方を満たす必要がある。

1. テーマバスケットだけでは作れなかった、中立化制約内の独立なポートフォリオ方向を追加する。
2. その追加方向が、テーマバスケット複製ポートフォリオと個別銘柄 coefficient replica の残差に対して、リスク加重内積で非ゼロの説明力を持つ。

したがって、33本追加しただけでは改善は保証されない。特に、純化テーマが業種中立であり、テーマバスケット単独の残差が主として同一業種内の個別銘柄差で構成される場合、粗い業種指数の追加効果は小さい。一方、テーマバスケットの業種偏り、Barra/スタイル中立化のためのヘッジ不足、またはテーマ間重複に起因する残差が大きい場合には、業種指数が有効なヘッジ基底となり得る。

**実現した out-of-sample TE の改善は保証されない。** リスクモデル誤差、指数構成ウェイトの時点整合性、指数と実際の取引手段のトラッキング差、売買コスト、資金調達・ショートコスト、ターンオーバー、リッジ正則化等が影響するためである。このため、以下を分けて評価する。

- 理論・診断系列: 構成銘柄ルックスルー、コスト前、純粋なTE最小化
- 投資可能系列: 実行可能なETF、TRS、カスタムバスケット等のリターンとコストを反映

---

## 2. 現行実装との対応

現行実装は、各純化テーマについて個別銘柄 coefficient replica を目的ポートフォリオとし、テーマバスケット行列の張る空間へ制約付きリスク射影している。

現行記号を次のように置く。

| 記号 | 次元 | 定義 |
|---|---:|---|
| \(N\) |  | 有効個別銘柄数 |
| \(K\) |  | テーマバスケット数 |
| \(A_t\) | \(N\times Q\) | 純化に用いた中立化エクスポージャー。切片、Barra、任意のモメンタム等 |
| \(Z_t\) | \(N\times K_f\) | 純化済みテーマエクスポージャー |
| \(P_t\) | \(N\times K\) | テーマバスケット構成ウェイト |
| \(m^{\mathrm{stock}}_{k,t}\) | \(N\times1\) | テーマ \(k\) の個別銘柄 coefficient replica |
| \(h_{k,t}\) | \(K\times1\) | テーマバスケット配分 |

現行のルックスルー複製ポートフォリオは

\[
 m^{T}_{k,t}=P_t h_{k,t}
\]

であり、複製リターンは

\[
 \widetilde g^{T}_{k,t+1}
 =h_{k,t}'P_t'r_{t+1}
 ={m^{T}_{k,t}}'r_{t+1}
\]

である。

実行済み合成データでは、テーマバスケット14本に対して中立化制約のバスケット上ランクが7、したがって中立部分空間の次元が7となっている。テーマバスケット単独では14テーマ全体を独立に張れない構造であり、追加基底を検討する合理性がある。

---

## 3. 業種指数を加えた拡張基底

東証33業種指数等の構成銘柄ウェイトを

\[
 S_t\in\mathbb{R}^{N\times J},\qquad J=33
\]

とする。テーマバスケットと業種バスケットを連結した売買基底を

\[
 B_t=[P_t\;S_t]
 \in\mathbb{R}^{N\times(K+J)}
\]

と定義する。

テーマ \(k\) を複製する配分を

\[
 x_{k,t}
 =\begin{bmatrix}h_{k,t}\\ s_{k,t}\end{bmatrix},
\]

とする。ここで、\(h_{k,t}\) はテーマバスケット配分、\(s_{k,t}\) は業種指数配分である。

ルックスルー個別銘柄ウェイトと複製リターンは

\[
 m^{T+I}_{k,t}=B_t x_{k,t}=P_t h_{k,t}+S_t s_{k,t},
\]

\[
 \widetilde g^{T+I}_{k,t+1}
 =x_{k,t}'B_t'r_{t+1}
 =h_{k,t}'P_t'r_{t+1}+s_{k,t}'S_t'r_{t+1}
 ={m^{T+I}_{k,t}}'r_{t+1}.
\]

`T` は theme、`I` は industry を表す。

---

## 4. 主定式化: 個別銘柄 coefficient replica への制約付きリスク射影

### 4.1 複製対象

純化テーマリターンの単位を保つため、目的ポートフォリオは現行どおり個別銘柄 coefficient replica とする。

\[
 g^{\mathrm{pur}}_{k,t+1}
 ={m^{\mathrm{stock}}_{k,t}}'r_{t+1}.
\]

したがって、複製誤差は

\[
 e_{k,t+1}(x)
 =g^{\mathrm{pur}}_{k,t+1}-\widetilde g^{T+I}_{k,t+1}
 =(m^{\mathrm{stock}}_{k,t}-B_tx)'r_{t+1}.
\]

### 4.2 ex-ante トラッキング損失

時点 \(t\) で利用可能な個別銘柄リターン共分散推定値を \(\Sigma_t\succeq0\) とすると、条件付き二乗TEは

\[
 L_{k,t}(x)
 =(B_tx-m^{\mathrm{stock}}_{k,t})'
 \Sigma_t
 (B_tx-m^{\mathrm{stock}}_{k,t}).
\]

月次 ex-ante TE は

\[
 \mathrm{TE}^{\mathrm{ex\ ante}}_{k,t}(x)=\sqrt{L_{k,t}(x)}.
\]

リスクモデルは次の優先順位とする。

1. フルファクターリスクモデル
   \[
   \Sigma_t=X^{R}_tF_t{X^{R}_t}'+D_t
   \]
2. shrinkage を施した標本共分散または低ランク＋対角モデル
3. 現行互換の対角specific variance / trailing stock variance
4. 単位行列はテスト用途に限定

フル \(N\times N\) 行列を明示生成せず、\(B_t'\Sigma_tB_t\) と \(B_t'\Sigma_tm^{\mathrm{stock}}\) をファクター形式で計算できるAPIを用意する。

### 4.3 hard 制約

主比較では、純化テーマを構築したときと同一の中立化行列を用いる。

\[
 A_t'B_tx_{k,t}=0,
\]

\[
 z_{k,t}'B_tx_{k,t}=1.
\]

ここで \(z_{k,t}\) は \(Z_t\) のテーマ \(k\) 列である。必要に応じて対象テーマ尺度を \(c_k\) とし、右辺を \(c_k\) に変更できるが、デフォルトは1とする。

重要な原則は次のとおりである。

- 純化対象で業種中立化を行っていない場合、複製側だけに業種中立制約を追加しない。
- 純化対象で業種中立化を行った場合は、その同一業種ダミーを \(A_t\) に含める。
- 33業種ダミーと切片は完全または近似的に冗長になるため、SVD/QRにより実効ランクを判定する。代替として切片＋32業種ダミーを用いる。

### 4.4 二次計画形式

正則化行列を \(R_t\succeq0\) とすると、目的関数は

\[
 \min_x\quad
 \frac12(B_tx-m)'\Sigma_t(B_tx-m)
 +\frac12x'R_tx
\]

subject to

\[
 G_{k,t}x=d,
\]

\[
 G_{k,t}=
 \begin{bmatrix}
 A_t'B_t\\
 z_{k,t}'B_t
 \end{bmatrix},
 \qquad
 d=\begin{bmatrix}0\\1\end{bmatrix}.
\]

展開すると

\[
 Q_t=B_t'\Sigma_tB_t+R_t,
 \qquad
 c_{k,t}=B_t'\Sigma_tm^{\mathrm{stock}}_{k,t},
\]

\[
 \min_x\quad\frac12x'Q_tx-c_{k,t}'x.
\]

等式制約のみの診断モードでは、冗長制約を除去後、次のKKT系を解く。

\[
 \begin{bmatrix}
 Q_t&G_{k,t}'\\
 G_{k,t}&0
 \end{bmatrix}
 \begin{bmatrix}x\\\nu\end{bmatrix}
 =
 \begin{bmatrix}c_{k,t}\\d\end{bmatrix}.
\]

または、\(A_t'B_t\) のnull space上に変数を落としてから解く。現行実装との整合性から、null-space＋SVD方式を推奨する。

---

## 5. 業種追加でTEが弱く改善する条件

### 5.1 feasible set の包含

テーマバスケット単独の実現可能集合を

\[
 \mathcal F^T_{k,t}
 =\{P_th:\ A_t'P_th=0,\ z_{k,t}'P_th=1\}
\]

とする。テーマ＋業種の集合は

\[
 \mathcal F^{T+I}_{k,t}
 =\{B_tx:\ A_t'B_tx=0,\ z_{k,t}'B_tx=1\}.
\]

業種ウェイトをゼロにすれば \(x=[h;0]\) となるため、同一制約下では

\[
 \mathcal F^T_{k,t}\subseteq\mathcal F^{T+I}_{k,t}.
\]

したがって、純粋なリスク加重距離の最小値は

\[
 L^{*,T+I}_{k,t}
 \le
 L^{*,T}_{k,t}.
\]

これは、業種指数を追加したモデルの**モデル上の最小TEが悪化しない**ことを意味する。

### 5.2 この性質が失われるケース

次の場合、raw TE の非悪化は自動では保証されない。

- 業種ウェイトを必ず非ゼロにする。
- combinedモデルだけに厳しい総グロス、銘柄上限、グループ上限を課す。
- combinedモデルだけに異なる中立化制約を課す。
- TE、リッジ、ターンオーバー、取引コストを単一目的で加重和にし、TE以外とのトレードオフを許す。
- テーマ単独解 \([h^T;0]\) を候補として保持しない。

### 5.3 推奨する二段階最適化

TE非悪化を実装上保証するため、診断モードはlexicographicにする。

**Stage 1: 純粋TE最小化**

\[
 L^*_{k,t}=\min_{x\in\mathcal F^{T+I}_{k,t}}L_{k,t}(x).
\]

**Stage 2: 同等TE内で安定解を選択**

\[
 \min_x\quad
 x'R_tx+
 \lambda_{\Delta}\|x-x_{k,t-1}\|_2^2
\]

subject to

\[
 x\in\mathcal F^{T+I}_{k,t},
\]

\[
 L_{k,t}(x)\le L^*_{k,t}+\varepsilon_{TE}.
\]

これにより、リッジやターンオーバー抑制を入れても、許容範囲を超えてTEを犠牲にしない。

簡易実装では、combined解と埋め込みテーマ単独解 \([h^{T};0]\) の双方を評価し、予測TEが小さい方を採用する。

---

## 6. 厳密なTE改善条件

テーマ単独最適解を \(m^{T,*}_{k,t}\)、その残差を

\[
 e^T_{k,t}=m^{\mathrm{stock}}_{k,t}-m^{T,*}_{k,t}
\]

とする。

対象テーマ尺度と中立化を保つ局所方向を定義する。

\[
 N^T_{k,t}
 =\operatorname{Null}
 \left(
 \begin{bmatrix}
 A_t'P_t\\z_{k,t}'P_t
 \end{bmatrix}
 \right),
 \qquad
 V^T_{k,t}=P_tN^T_{k,t},
\]

\[
 N^{T+I}_{k,t}
 =\operatorname{Null}
 \left(
 \begin{bmatrix}
 A_t'B_t\\z_{k,t}'B_t
 \end{bmatrix}
 \right),
 \qquad
 V^{T+I}_{k,t}=B_tN^{T+I}_{k,t}.
\]

\(V^{T+I}\) から \(V^T\) のリスク加重射影を除いた追加方向を \(V^\Delta\) とする。

\[
 V^\Delta
 =\left(I-\Pi^{\Sigma}_{V^T}\right)V^{T+I}.
\]

数値的に独立な列だけをSVDで残す。このとき、業種追加による理論的な二乗TE削減は

\[
 \Delta \mathrm{TE}^2_{k,t}
 =
 {e^T_{k,t}}'\Sigma_tV^\Delta
 \left({V^\Delta}'\Sigma_tV^\Delta\right)^+
 {V^\Delta}'\Sigma_te^T_{k,t}
 \ge0.
\]

厳密な改善条件は

\[
 \operatorname{rank}(V^\Delta)>0
\]

かつ

\[
 {V^\Delta}'\Sigma_te^T_{k,t}\ne0
\]

である。

したがって、実装前診断として次を算出できる。

- `incremental_feasible_rank`
- `residual_industry_alignment_norm`
- `max_exante_te2_reduction`
- `max_exante_te_reduction_ratio`

最後の比率は

\[
 \rho^{\mathrm{potential}}_{k,t}
 =\frac{\Delta \mathrm{TE}^2_{k,t}}
 {\mathrm{TE}^{2,T}_{k,t}}
\]

とする。これは実現TEではなく、当該リスクモデルの下での改善上限・説明力診断である。

---

## 7. ランクと表現力の診断

### 7.1 中立部分空間

テーマ単独の中立係数空間次元は

\[
 d^T_t=K-\operatorname{rank}(A_t'P_t).
\]

combined基底では

\[
 d^{T+I}_t=K+J-\operatorname{rank}(A_t'[P_t,S_t]).
\]

ただし、係数空間の次元だけでなく、個別銘柄空間上の実効ランクを計測する。

\[
 r^T_t=\operatorname{rank}(P_tN^T_{A,t}),
\]

\[
 r^{T+I}_t=\operatorname{rank}(B_tN^{T+I}_{A,t}),
\]

ここで \(N_{A}\) は中立化制約だけのnull-spaceである。

### 7.2 必須診断

各 exposure date について次を保存する。

| 指標 | 定義・用途 |
|---|---|
| `rank_theme_basis` | \(\operatorname{rank}(P_t)\) |
| `rank_industry_basis` | \(\operatorname{rank}(S_t)\) |
| `rank_combined_basis` | \(\operatorname{rank}([P_t,S_t])\) |
| `neutral_rank_theme` | \(\operatorname{rank}(P_tN_A^T)\) |
| `neutral_rank_combined` | \(\operatorname{rank}(B_tN_A^{T+I})\) |
| `incremental_neutral_rank` | combined−themeの実効増分 |
| `target_tangent_rank_theme` | 対象テーマ尺度も固定した接空間ランク |
| `target_tangent_rank_combined` | 同上 |
| `principal_angles_theme_industry` | テーマ・業種部分空間の重複度 |
| `min_incremental_singular_value` | 追加方向の数値安定性 |
| `condition_number_combined_basis` | 多重共線性診断 |
| `target_strength_in_neutral_space` | 対象テーマ尺度制約の実現可能性 |

33業種指数は業種間で構成銘柄が原則分離するため素の列ランクは高くなりやすいが、テーマバスケットとの結合後、中立化制約下でどれだけ新しい方向が残るかが重要である。

---

## 8. 業種中立化に関する設計原則

業種指数を追加することと、対象ファクターを業種中立化することは別の意思決定である。

### 8.1 主比較

主比較では、純化テーマリターンの推定に利用した \(A_t\) をそのまま複製制約に用いる。

- 元の純化テーマがスタイル中立のみ: 複製もスタイル中立のみ
- 元の純化テーマがスタイル＋業種中立: 複製もスタイル＋業種中立

これにより「同じファクターを、売買基底だけ変えて複製する」という比較が成立する。

### 8.2 感応度分析

補足として次の2ケースを比較する。

1. `original_neutralization`: 現行定義を維持
2. `industry_neutralized_target`: 純化テーマ自体を33業種に対して追加残差化して再推定

後者は別の目的変数であり、主結果と混同しない。出力ファイル名、系列名、Config hashを分離する。

### 8.3 33業種ダミーと切片

全銘柄が必ず1業種に所属するユニバースでは

\[
 \mathbf1=\sum_{j=1}^{33}d_j
\]

となるため、切片＋33ダミーは線形従属する。次のいずれかを採用する。

- 切片＋32業種ダミー
- 33業種ダミーのみ
- 切片＋33業種ダミーを入力し、SVDで冗長行を除去

現行実装のSVD/null-space方式を一般化するため、3番目を推奨する。

---

## 9. データ要件

### 9.1 必須入力: 業種バスケット構成ウェイト

新規キーを追加する。

```python
"industry_basket_weights_by_date": dict[pd.Timestamp, pd.DataFrame]
```

各DataFrameの仕様:

- 行: 個別銘柄ID
- 列: 33業種指数ID
- 値: exposure date時点の指数構成ウェイト
- 列和: 原則1
- 要素: 原則0以上
- ベース: 浮動株調整後時価総額ウェイト等、採用指数の公式定義に一致
- 日付: point-in-timeで、実効日と情報入手日を管理

推奨するlong形式の原票:

| 列 | 型 | 内容 |
|---|---|---|
| `knowledge_date` | datetime | 当時利用可能になった日 |
| `effective_date` | datetime | 指数算出に適用される日 |
| `industry_code` | string | 33業種コード |
| `industry_name` | string | 業種名 |
| `security_id` | string | 個別銘柄ID |
| `weight` | float | 指数内ウェイト |
| `weight_type` | string | free-float market-cap等 |
| `source` | string | データソース |
| `version` | string | スナップショット版 |

月末リバランスでは

\[
 \text{knowledge\_date}\le t,
 \qquad
 \text{effective\_date}\le t
\]

を満たす最新スナップショットだけを使用する。

### 9.2 指数リターン

任意だが強く推奨する。

```python
"industry_index_returns": pd.DataFrame  # date × industry
```

リターン定義は個別銘柄リターンと一致させる。

- 個別銘柄が配当込みなら、業種指数も配当込み
- 個別銘柄が価格リターンなら、業種指数も配当なし
- 通貨、税、源泉、corporate action、終値時刻を揃える

構成ウェイトから再構築したリターンと公表指数リターンの差を

\[
 \delta^{\mathrm{index}}_{j,t+1}
 =r^{\mathrm{published}}_{j,t+1}
 -S_{j,t}'r_{t+1}
\]

として保存し、指数算出・データ整合性を検証する。

### 9.3 実取引リターン

投資可能評価用に、任意の実行手段を別キーで持つ。

```python
"industry_tradeable_returns": pd.DataFrame
"industry_tradeable_metadata": pd.DataFrame
```

メタデータ例:

- `instrument_type`: ETF / future / TRS / custom_basket
- `instrument_id`
- `underlying_industry`
- `currency`
- `fee_bps`
- `financing_bps`
- `borrow_bps`
- `bid_ask_bps`
- `availability_start`
- `availability_end`
- `shortable`

理論指数と取引手段を同一系列として扱わない。

### 9.4 ID・列名

テーマと業種で名称衝突を防ぐ。

```text
THEME::<theme_id>
INDUSTRY::<industry_code>
```

`basis_metadata` を作成し、各列に `group`, `source`, `is_tradeable`, `return_kind` を付与する。

---

## 10. 基底構築APIの一般化

現行の `prepare_theme_basket_weights` は、列が複製対象テーマと一致することを前提としている。これを任意の売買基底に一般化する。

### 10.1 新規関数

```python
def prepare_industry_basket_weights(
    data: dict,
    date: pd.Timestamp,
    stock_index: pd.Index,
    cfg: Config,
) -> tuple[pd.DataFrame, dict]:
    """Return point-in-time stock × industry weight matrix S_t."""
```

```python
def build_replication_basis(
    data: dict,
    date: pd.Timestamp,
    stock_index: pd.Index,
    target_theme_columns: pd.Index,
    cfg: Config,
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Return B_t=[P_t,S_t], basis_metadata, and input diagnostics."""
```

```python
def augmented_basis_diagnostics(
    P: pd.DataFrame,
    S: pd.DataFrame,
    A: pd.DataFrame,
    Z: pd.DataFrame,
    risk_model,
    cfg: Config,
) -> dict:
    """Return rank, null-space, principal-angle, and incremental-span diagnostics."""
```

```python
def construct_augmented_mimicking_portfolios(
    data: dict,
    cfg: Config,
    date: pd.Timestamp,
    momentum_neutral: bool = False,
    stock_target_mode: str = "coefficient",
    basis_mode: str = "theme_plus_industry",
    optimization_mode: str = "lexicographic_tracking",
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Return X_base, M_lookthrough=B@X, diagnostics."""
```

返却値:

- `X_base`: base portfolio × target purified theme
- `M_lookthrough`: stock × target purified theme
- `diagnostics`: 共通診断、テーマ別診断、グループ別ウェイト、solver status

```python
def augmented_replicated_theme_returns(
    data: dict,
    cfg: Config,
    purified_theme_returns: pd.DataFrame,
    basis_mode: str,
) -> tuple[pd.DataFrame, object]:
    """Generate walk-forward replicated returns and artifacts."""
```

```python
def compare_basis_extensions(
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    theme_only_rep: pd.DataFrame,
    industry_only_rep: pd.DataFrame,
    combined_rep: pd.DataFrame,
    diagnostics: pd.DataFrame,
    cfg: Config,
) -> dict:
    """Compare all series on strictly common samples."""
```

### 10.2 後方互換

現行関数はwrapperとして残す。

```python
construct_basket_mimicking_portfolios(...)
```

は内部的に

```python
construct_augmented_mimicking_portfolios(
    ...,
    basis_mode="theme_only",
)
```

を呼び出す。業種機能を無効にした場合、現行出力と数値一致することを受入条件にする。

---

## 11. 最適化モード

### 11.1 `diagnostic_tracking`

目的: 基底の表現力を純粋に比較する。

- hard neutrality
- hard target exposure = 1
- グロス1への再正規化なし
- 取引コストなし
- 業種利用強制なし
- TEを第一目的
- min-normまたはlexicographic安定化
- テーマ単独解をcombined feasible candidateとして保持

主たる理論比較にはこのモードを用いる。

### 11.2 `investable_tracking`

目的: 実取引可能性を反映する。

追加制約例:

\[
 \|h\|_1\le G_T,
 \qquad
 \|s\|_1\le G_I,
\]

\[
 |h_i|\le u^T_i,
 \qquad
 |s_j|\le u^I_j,
\]

\[
 s_j=0\quad\text{if industry instrument }j\text{ is not shortable}.
\]

目的関数例:

\[
 \min_x
 L_{k,t}(x)
 +\lambda_{TC}\widehat{TC}_t(x,x_{t-1})
 +\lambda_2x'R_tx.
\]

ただし、ここではraw TE非悪化を保証しない。次を別々に出力する。

- ex-ante gross TE
- realized gross TE
- realized net TE
- transaction/financing/borrow cost
- implementation shortfall

### 11.3 `rolling_return_regression`（補助）

構成銘柄ルックスルーが利用できず、指数リターンだけを用いる場合の補助モード。

\[
 \min_x
 \sum_{\tau=t-L+1}^{t}
 \omega_{\tau}
 \left(g^{\mathrm{pur}}_{k,\tau}-x'r^{B}_{\tau}\right)^2
 +\lambda x'R_tx.
\]

必ず時点 \(t\) 以前だけで推定し、\(t+1\) をout-of-sampleにする。ただし、この方式では個別銘柄レベルの中立化制約や対象テーマエクスポージャーを厳密に検証できないため、主方式にはしない。

---

## 12. Config追加要件

```python
# Basis selection
replication_basis_mode: str = "theme_plus_industry"
use_industry_baskets: bool = True
industry_basket_weights_key: str = "industry_basket_weights_by_date"
industry_index_returns_key: str = "industry_index_returns"
industry_tradeable_returns_key: str = "industry_tradeable_returns"
industry_expected_count: int = 33
basis_column_prefixes: bool = True

# Input validation
industry_require_nonnegative_base_weights: bool = True
industry_normalize_columns: bool = True
industry_min_constituents: int = 1
industry_min_weight_coverage: float = 0.98
industry_min_return_coverage: float = 0.98
industry_return_kind: str = "total_return"
industry_require_point_in_time: bool = True

# Optimization
augmented_optimization_mode: str = "lexicographic_tracking"
enforce_nonworsening_exante_te: bool = True
exante_te_selection_tolerance: float = 1e-12
lexicographic_te_tolerance: float = 1e-10
basis_ridge_alpha_theme: float = 1e-6
basis_ridge_alpha_industry: float = 1e-6
basis_turnover_penalty_theme: float = 0.0
basis_turnover_penalty_industry: float = 0.0

# Investable constraints
industry_gross_cap: float | None = None
industry_max_abs_weight: float | None = None
theme_gross_cap: float | None = None
combined_gross_cap: float | None = None
require_nonzero_industry_weight: bool = False

# Risk model
tracking_risk_model: str = "factor_covariance"
tracking_risk_fallback: str = "diagonal_variance"
risk_model_psd_floor: float = 1e-10

# Neutralization sensitivity
run_industry_neutralized_sensitivity: bool = False
industry_dummy_encoding: str = "all_with_svd"

# Output
save_industry_weights: bool = True
save_combined_lookthrough_weights: bool = False
save_incremental_span_diagnostics: bool = True
save_index_reconciliation: bool = True
```

`require_nonzero_industry_weight` のデフォルトは必ず `False` とする。これが `True` だと、テーマ単独 feasible set の包含が崩れ、TE非悪化の理論保証がなくなる。

---

## 13. 比較対象系列

テーマごとに次の5系列を生成する。

| 系列ID | 内容 | 位置づけ |
|---|---|---|
| `purified` | 純化テーマファクターリターン | 複製対象 |
| `stock_coefficient` | 個別銘柄 coefficient replica | 数値整合性基準 |
| `theme_only` | テーマバスケットL/S | 現行方式 |
| `industry_only` | 業種指数L/S | coarse proxy診断 |
| `theme_plus_industry` | テーマ＋業種L/S | 新主方式 |

`industry_only` は対象テーマ尺度制約が実現不能な場合がある。その場合は `infeasible` を明示し、soft解を主比較に混ぜない。

投資可能データがある場合は、追加で

- `theme_plus_industry_theoretical`
- `theme_plus_industry_tradeable_gross`
- `theme_plus_industry_tradeable_net`

を分ける。

---

## 14. 評価指標

### 14.1 realized 複製精度

テーマ \(k\) について

\[
 e^{M}_{k,t}=g^{\mathrm{pur}}_{k,t}-\widetilde g^{M}_{k,t},
\]

\(M\in\{T,I,T+I\}\) とする。

必須指標:

- Pearson correlation
- Spearman correlation
- beta, alpha, \(R^2\)
- bias = \(E[e]\)
- tracking error = \(\operatorname{sd}(e)\)
- annualized TE = \(\sqrt{12}\operatorname{sd}(e)\)
- RMSE = \(\sqrt{E[e^2]}\)
- MAE
- sign hit rate
- volatility ratio
- maximum cumulative arithmetic deviation
- 36か月rolling correlation
- 36か月rolling TE
- 有効月数・共通サンプルcoverage

TEとRMSEを混同しない。平均誤差がある場合、RMSEはTEより大きくなる。

### 14.2 TE改善指標

\[
 \Delta\mathrm{TE}_{k}
 =\mathrm{TE}^{T}_{k}-\mathrm{TE}^{T+I}_{k},
\]

\[
 \mathrm{TE\ Reduction\ Ratio}_{k}
 =1-\frac{\mathrm{TE}^{T+I}_{k}}
 {\mathrm{TE}^{T}_{k}},
\]

\[
 \mathrm{MSE\ Reduction\ Ratio}_{k}
 =1-\frac{E[(e^{T+I}_{k})^2]}
 {E[(e^{T}_{k})^2]}.
\]

ex-anteについても同じ指標を算出する。

### 14.3 paired loss test

各月の二乗誤差差を

\[
 d_{k,t}=(e^T_{k,t})^2-(e^{T+I}_{k,t})^2
\]

とする。\(E[d]>0\) ならcombinedのMSEが小さい。

次を出力する。

- 平均 \(d\)
- Newey-West/HAC t値
- moving-block bootstrap 95%信頼区間
- combinedが勝つ月の比率

テーマ数が多い場合は、テーマ横断の多重検定補正を補足出力する。

### 14.4 ポートフォリオ診断

- theme gross/net
- industry gross/net
- combined gross/net
- industry share of total gross
- 最大絶対業種ウェイト
- 上位ロング・ショート業種
- theme turnover / industry turnover
- look-through stock turnover
- target exposure error
- max neutralization exposure
- off-target theme exposure
- ex-ante TE to stock target
- cosine similarity to stock target
- KKT condition number
- solver/fallback status

---

## 15. 事前スクリーニング

全期間バックテスト前に、各月・各テーマで次を計算する。

1. テーマ単独最適解 \(m^{T,*}\)
2. 残差 \(e^T=m^{\mathrm{stock}}-m^{T,*}\)
3. 制約内の業種増分方向 \(V^\Delta\)
4. 理論的最大二乗TE削減 \(\Delta\mathrm{TE}^2\)
5. 増分ランク、条件数、残差alignment

集計表:

```text
exposure_date
 target_theme
 theme_only_exante_te
 combined_exante_te_lower_bound
 incremental_feasible_rank
 residual_industry_alignment_norm
 max_exante_te2_reduction
 max_exante_te_reduction_ratio
 numerical_status
```

次の場合は改善期待が低いと判定する。

- `incremental_feasible_rank == 0`
- `residual_industry_alignment_norm` が許容値以下
- 改善上限がテーマ単独TEの1%未満
- 条件数が閾値を超え、改善が数値不安定

ただし閾値は分析目的のflagであり、ハードな除外基準にはしない。

---

## 16. point-in-time・指数整合性要件

東証業種別指数は、TOPIX構成銘柄を33業種へ分類する体系であり、業種見直し等に伴う構成変更があり得る。実装では次を必須とする。

- 現在の業種所属を過去へ遡及適用しない。
- exposure date時点で有効な業種分類と指数ウェイトを用いる。
- knowledge dateを超えて将来公表データを利用しない。
- 新規上場、上場廃止、業種変更、TOPIX構成変更を時点整合的に反映する。
- 月中変更がある場合、厳密指数複製では日次ウェイトまたは日次指数リターンを使用する。
- 月末固定ウェイト近似を使う場合は、公表指数との差を reconciliation error として保存する。

月次の単純な \(S_t'r_{t+1}\) は、月中の構成変更・corporate action・日次複利を厳密には再現しない可能性がある。そのため、理論ルックスルー系列と公表指数系列を照合する。

---

## 17. 欠損処理

テーマ、業種、個別銘柄の全方式で同一方針を適用する。

- リターン欠損を無条件に0としない。
- ウェイトカバレッジをグループ別に計測する。
- coverage未達の場合は当該月・系列をNaNまたはinvalidとする。
- 欠損部分を再正規化した場合は、その有無とスケールを記録する。
- 公表指数リターンがある場合、構成銘柄欠損時の投資可能系列は公表指数を優先できるが、ルックスルー恒等式系列とは分ける。

必須列:

- `theme_return_coverage`
- `industry_return_coverage`
- `lookthrough_stock_return_coverage`
- `n_missing_stocks`
- `missing_weight_theme`
- `missing_weight_industry`
- `return_status`

---

## 18. 出力要件

既存出力に次を追加する。

```text
industry_basket_weights_long.parquet
combined_base_weights_long.parquet
combined_lookthrough_stock_weights_long.parquet          # optional
industry_index_returns_reconstructed.csv
industry_index_reconciliation.csv
industry_only_replicated_theme_returns.csv
combined_replicated_theme_returns.csv
combined_tradeable_replicated_theme_returns.csv          # optional
basis_extension_rank_diagnostics.csv
incremental_industry_span_diagnostics.csv
basis_extension_metrics_by_theme.csv
basis_extension_metrics_aggregate.csv
basis_extension_paired_loss_tests.csv
basis_extension_rolling_metrics.parquet
basis_extension_config.json
basis_extension_acceptance_checks.csv
```

`combined_base_weights_long.parquet` の列:

```text
exposure_date
return_date
target_theme
base_portfolio
basis_group          # theme / industry
weight
long_short_side
solver_status
```

---

## 19. ノートブック構成

既存Step 2を次のように拡張する。

### 2A. 純化テーマとstock coefficient replica

既存処理を維持し、完全複製の基準を確認する。

### 2B. テーマバスケット単独

現行方式を再実行する。

### 2C. 業種指数単独

表現力と実現可能性を診断する。主採用方式ではない。

### 2D. テーマ＋業種combined

新規最適化を実行する。

### 2E. feasible-set・ランク・増分方向診断

- rank比較
- principal angles
- residual alignment
- ex-ante TE改善上限

### 2F. 5系列比較

共通サンプルで比較する。

### 2G. 投資可能性

実取引リターン・コスト・ターンオーバーを反映する。

### 2H. 受入チェック

すべての数値恒等式・非悪化条件・point-in-time条件を表示する。

---

## 20. 受入基準

### 20.1 後方互換

- `use_industry_baskets=False` で現行テーマ単独出力と数値一致する。
- 現行ファイル名とAPIを破壊しない。

### 20.2 feasible-set包含

テーマ単独解 \(h^T\) に対し

\[
 x_0=[h^T;0]
\]

がcombinedの制約を満たすことを毎月検証する。

```text
embedded_theme_solution_constraint_error <= 1e-8
```

### 20.3 ex-ante TE非悪化

`diagnostic_tracking` では

\[
 L^{*,T+I}_{k,t}
 \le L^{*,T}_{k,t}+\varepsilon
\]

を全有効月・全テーマで満たす。

違反時はsolver/numerical failureとし、combined結果を採用しない。

### 20.4 リターン恒等式

\[
 x_{k,t}'(B_t'r_{t+1})
 =(B_tx_{k,t})'r_{t+1}
\]

が

```text
identity_error <= 1e-10
```

を満たす。

### 20.5 hard制約

```text
max_abs_neutralization_exposure <= 1e-6
target_theme_exposure_error <= 1e-6
```

### 20.6 ランク・共線性

- rank deficientな業種またはテーマ列をSVDで処理できる。
- 切片＋33業種ダミーの冗長性でsolverが失敗しない。
- 追加ランク0の場合、combinedはテーマ単独と同等のTEを返す。

### 20.7 合成テスト

次のケースを用意する。

1. 業種基底がテーマ単独残差を完全に張る: combined TEが数値誤差内で0になる。
2. 業種基底がテーマ空間に完全包含: combinedとtheme-onlyが一致する。
3. 業種増分方向はあるが残差と直交: ランクは増えるがTEは改善しない。
4. 業種方向が残差と部分的に整合: 理論式と実測TE削減が一致する。
5. 33業種＋切片の冗長制約: SVDで正常解。
6. 業種列欠損・空業種: flagまたはskip。
7. 将来の業種分類を過去へ適用するテストを検知。
8. コストを入れるとnet TEが悪化し得ることを正しく表示。

### 20.8 公表指数照合

構成ウェイト再構築リターンと公表指数リターンの差を保存し、閾値超過時に警告する。閾値はデータ頻度・return conventionに応じConfig化する。

---

## 21. 推奨実装順序

1. `prepare_theme_basket_weights` を一般化し、任意基底を受けるデータ構造へ変更
2. `prepare_industry_basket_weights` を実装
3. `build_replication_basis` で `P`, `S`, `B`, metadataを生成
4. 現行 `basket_basis_diagnostics` をcombined対応へ一般化
5. pure TE Stage 1とlexicographic Stage 2を実装
6. theme-only / industry-only / combinedを同じ関数で生成
7. feasible-set包含とex-ante TE非悪化チェックを追加
8. 5系列比較・paired loss testを追加
9. 公表指数reconciliationを追加
10. 投資可能モードとコストを追加
11. 合成テスト、後方互換テスト、point-in-timeテストを実行

---

## 22. 推奨デフォルト

| 論点 | 推奨値 |
|---|---|
| 主複製対象 | 個別銘柄 coefficient replica |
| 業種入力 | point-in-time構成ウェイトのルックスルー |
| 主基底 | theme + industry |
| 主目的 | ex-ante TEのlexicographic最小化 |
| 中立化 | 純化テーマ推定時と同一の \(A_t\) |
| 対象テーマ尺度 | hardで1 |
| 業種利用強制 | しない |
| グロス正規化 | 主比較ではしない |
| リスク | フルファクター共分散、対角をfallback |
| 正則化 | TE許容範囲内のStage 2 |
| 取引コスト | 主比較から分離 |
| 公表指数 | reconciliationおよび投資可能系列に利用 |
| 比較の主判定 | combined vs theme-onlyの共通サンプル realized TE |
| 統計検定 | paired squared-error差のHAC＋block bootstrap |

---

## 23. 最終的な判断基準

業種指数追加を有効と判断するには、少なくとも次を満たすことを推奨する。

1. 大半の月で `incremental_feasible_rank > 0`
2. ex-ante TEが非悪化し、テーマ横断中央値で有意に低下
3. out-of-sample realized TEまたはRMSEが共通サンプルで低下
4. paired loss差の信頼区間が実務上有意な改善を示す
5. 業種ウェイト・グロス・ターンオーバーが安定
6. 公表指数または実取引手段とのreconciliation差が許容範囲
7. 取引コスト後でも改善が残る、または改善とコストのトレードオフが明確

したがって、実装判断は「33業種を追加したから改善する」ではなく、**追加された制約内部分空間が、テーマ単独複製の残差リスクをどれだけ説明し、その効果がout-of-sampleかつコスト後に残るか**に基づく。

---

## 24. 参照する指数仕様上の留意点

東証業種別株価指数は、TOPIX構成銘柄を証券コード協議会の33業種へ分類して構成し、浮動株ベースの時価総額加重方式を採る。配当なし・配当込み系列が存在し、業種分類見直しに伴う構成変更があり得る。実装では、利用するリターン系列、構成ウェイト、実効日を明示し、個別銘柄リターンの定義と一致させること。

