# Thematic Megatrend Estimation & ETF Allocation — SPEC (Notebook-per-Method)

## 0. Scope / Goal
本プロジェクトは、テーマETF投資における「メガトレンド（テーマ強弱）」推定を、以下6系統の方法論に対応する実装モジュールとして整備し、
各手法を **独立したノートブックで単体検証（完走）**できるようにする。  
加えて統合版として `00_pipeline_demo.ipynb` で end-to-end パイプラインも完走させる。

対応ソース（番号は実装モジュール番号と対応）：
1) MSCI Thematic Select（テーマ選択＋フォールバック）  
2) Trend Scanning（López de Prado文脈）  
3) Flow diagnostics（価格圧力→反転：LP-IRF）  
4) Flow-sorted portfolios（需要ショック因子）  
5) Unexpected flows（フロー分解→残差で予測）  
6) Crowding（混雑度スコア＋overlay）

---

## 1. Hard Rules (must comply)

### 1.1 Workspace rules
- 作業開始前に `~/workspace/AGENTS.md` を必ず読み、そのルールを最優先で守ること。
- 変更は incremental。大規模リファクタ禁止。
- 依存追加は禁止（必要なら提案のみして停止）。`pip install` 禁止。
- 成果物は必ず `outputs/` 配下に保存。説明は日本語。

### 1.2 Leak-free convention (must comply)
- シグナルは「t日終値まで」で計算して良い。
- ポジション適用は必ず「t+1営業日から」：`weights_applied = weights.shift(1)` を標準。
- 月次リバランスでも同様（“月末決定→翌営業日から適用”）。

---

## 2. Fixed Project Layout (paths are fixed)

```
projects/<project_name>/
  AGENTS.md
  SPEC.md
  README.md

  config/
    config.example.yaml

  src/
    __init__.py
    config.py

    utils/
      __init__.py
      calendar.py
      stats.py
      io.py
      validation.py

    signals/
      __init__.py
      theme_selection_msci.py
      trend_scanning.py
      flow_diagnostics.py
      flow_sorted_factor.py
      unexpected_flow.py

    risk/
      __init__.py
      crowding.py

    backtest/
      __init__.py
      engine.py

  notebooks/
    00_pipeline_demo.ipynb
    01_msci_theme_select.ipynb
    02_trend_scanning.ipynb
    03_flow_diagnostics_irf.ipynb
    04_flow_sorted_portfolios.ipynb
    05_unexpected_flow.ipynb
    06_crowding_overlay.ipynb

  outputs/
    logs/
    signals/
    weights/
    diagnostics/
    figures/
```

---

## 3. Notebook Contract (most important)

### 3.1 Each notebook must be runnable standalone
各ノートブック（01〜06）は **単体で先頭から完走**すること。

各ノートブック共通の必須要件：
- `config/config.example.yaml` を読み込む（パス固定）
- `data.mode="synthetic"` を前提に、対象手法に必要な synthetic データを生成
- 対象手法を実行し、**規約通りの outputs ファイルを生成**
- 簡易な検証セル（shape/欠損/整合性）を必ず含む
- リーク回避が絡む場合は `shift(1)` を明示し検証する

### 3.2 Pipeline notebook
`00_pipeline_demo.ipynb` は統合ノートとして残し、
01〜06で作った関数を組み合わせて end-to-end を完走させる。

---

## 4. Output Naming Convention (fixed)
すべて `outputs/` 配下に固定で保存する。

### 4.1 Common logs
- `outputs/logs/qa_checklist.txt`（必須：全ノートで追記してよい）
- `outputs/logs/run_metadata.json`（任意）

### 4.2 Method-specific outputs (fixed)

#### (1) MSCI theme select (01)
- `outputs/signals/01_theme_rank.parquet`
- `outputs/weights/01_theme_weights_raw.parquet`
- `outputs/diagnostics/01_theme_selection_debug.csv`
- `outputs/figures/01_theme_rank.png`（任意だが推奨）

#### (2) Trend scanning (02)
- `outputs/signals/02_trend_scanning.parquet`
- `outputs/diagnostics/02_trend_scanning_sample.csv`
- `outputs/figures/02_trend_scan_tval_horizon.png`

#### (3) Flow diagnostics (03)
- `outputs/signals/03_flow_pressure_score.parquet`
- `outputs/diagnostics/03_flow_irf.csv`
- `outputs/figures/03_flow_irf.png`（任意だが推奨）

#### (4) Flow-sorted portfolios (04)
- `outputs/diagnostics/04_flow_sorted_summary.csv`
- `outputs/signals/04_bucket_returns.parquet`
- `outputs/signals/04_ls_return.parquet`
- `outputs/figures/04_flow_sorted_ls.png`

#### (5) Unexpected flow (05)
- `outputs/signals/05_pred_flow.parquet`
- `outputs/signals/05_unexpected_flow.parquet`
- `outputs/diagnostics/05_unexpected_flow_report.csv`

#### (6) Crowding overlay (06)
- `outputs/signals/06_crowding_components.parquet`
- `outputs/signals/06_crowding_score.parquet`
- `outputs/weights/06_overlay_weights.parquet`
- `outputs/diagnostics/06_crowding_components.csv`
- `outputs/figures/06_crowding_timeseries.png`

### 4.3 Pipeline outputs (00)
- `outputs/weights/00_theme_weights_raw.parquet`
- `outputs/weights/00_theme_weights_overlay.parquet`
- `outputs/weights/00_portfolio_weights_applied.parquet`
- `outputs/diagnostics/00_metrics.csv`
- `outputs/figures/00_equity_curve.png`

NOTE:
- 旧SPECで指定していた出力名（theme_rank.parquet等）は、手法分割に合わせて “01_..”〜“06_..” プレフィックスに固定する。

---

## 5. Config (fixed format)
`config/config.example.yaml` を必ず用意し、全ノートはこれを読む。

### 5.1 Example: config/config.example.yaml

```yaml
project:
  name: "pXXX_megatrend_theme_etf"
  seed: 42

data:
  mode: "synthetic"     # "synthetic" | "local_csv"
  local_prices_csv: ""  # mode=local_csv のときに使用（任意）
  date_start: "2010-01-01"
  date_end: "2025-12-31"
  assets:
    theme_ids: ["TH1","TH2","TH3","TH4","TH5","TH6"]

calendar:
  rebalance: "M"        # "M"=月末, "Q"=四半期末
  trading_lag_days: 1

msci_theme_select:
  top_k: 4
  stale_months: 4
  fallback:
    window_days: 63
    use_risk_adj_mom: true

trend_scanning:
  lookback_min: 20
  lookback_max: 252
  step: 5
  use_log: true

flow_diagnostics:
  flow_window_days: 63
  irf_horizons: 20
  nw_lags: 5

flow_sorted_factor:
  q: 5
  weighting: "ew"
  lag_days: 1

unexpected_flow:
  model: "ols"
  standardize: true
  horizon_days: 1

crowding:
  window_days: 252
  components: ["reversal","correlation","volatility"]
  overlay:
    cap_quantile: 0.9
    scale: 0.5

backtest:
  cost_bps: 0.0
```

---

## 6. Module Specs (functions are fixed)

### 6.1 src/utils (common)

#### calendar.py
- `month_end_dates(dates: pd.DatetimeIndex) -> pd.DatetimeIndex`
- `quarter_end_dates(dates: pd.DatetimeIndex) -> pd.DatetimeIndex`

#### stats.py
- `zscore_cs(df: pd.DataFrame) -> pd.DataFrame`
- `winsorize(df: pd.DataFrame, p: float=0.01) -> pd.DataFrame`
- `spearman_ic(x: pd.Series, y: pd.Series) -> float`

#### io.py
- `save_parquet(df_or_ser, path: str)`
- `save_csv(df, path: str)`
- `save_figure(fig, path: str)`

#### validation.py
- `assert_weights_sum_to_one(weights: pd.DataFrame, tol=1e-6)`
- `assert_no_lookahead(weights: pd.DataFrame, returns: pd.DataFrame, lag: int)`

---

### 6.2 (1) MSCI theme selection
File: `src/signals/theme_selection_msci.py`

Functions:
1) `compute_theme_rank(theme_scores, theme_index_returns, rebalance_dates, top_k, stale_months, window_days) -> (selected_themes, theme_weights, debug_df)`
- stale判定：テーマ別に最終スコア日が `t - stale_months` より古ければ stale
- staleが多い場合：フォールバック（ret_3m / vol_3m）でランキング
- `theme_weights`：上位Kテーマに 1/K、それ以外0。リバランス日で更新し ffill。

2) `compute_composite_return(theme_index_returns, theme_weights, lag=1) -> pd.Series`
- `weights_applied = theme_weights.shift(lag)`
- 合成リターン：`(weights_applied * theme_index_returns).sum(axis=1)`

Diagnostics:
- `outputs/diagnostics/01_theme_selection_debug.csv` に
  - `date, used_score_or_fallback, stale_count, selected_themes...` を出力

---

### 6.3 (2) Trend Scanning
File: `src/signals/trend_scanning.py`

Function:
- `trend_scanning(prices: pd.Series, lookback_min=20, lookback_max=252, step=5, use_log=True) -> pd.DataFrame`

Output columns (fixed):
- `tval`（符号付き）
- `horizon`（最適ホライズン）
- `slope`
- `label`（sign(slope)）
- `t1`（index + horizon）

NOTE:
- 過去窓のみ（未来参照禁止）。リーク回避。

Diagnostics:
- `outputs/diagnostics/02_trend_scanning_sample.csv`（代表銘柄1本）

---

### 6.4 (3) Flow Diagnostics (LP-IRF)
File: `src/signals/flow_diagnostics.py`

Functions:
1) `compute_flow_pressure_score(flow: pd.Series, window=63, z=True) -> pd.Series`
- rollingで平均/標準偏差、z化（z=True）

2) `local_projection_irf(returns: pd.Series, shock: pd.Series, horizons: range, nw_lags=5) -> pd.DataFrame`
- `h=1..H` に対して：
  - `y_{t,h} = sum_{j=1..h} returns_{t+j}`
  - 回帰：`y_{t,h} = a_h + b_h * shock_t + e`
- 返す表：`h, beta, tstat, nobs`

Diagnostics:
- `outputs/diagnostics/03_flow_irf.csv`

---

### 6.5 (4) Flow-sorted portfolios
File: `src/signals/flow_sorted_factor.py`

Function:
- `build_flow_sorted_portfolios(returns, flow, rebalance_dates, q=5, weighting="ew", lag=1) -> dict`

Outputs (dict keys fixed):
- `bucket_returns: pd.DataFrame`（bucket x 日次）
- `ls_return: pd.Series`
- `turnover: pd.Series`
- `bucket_membership: dict`

Diagnostics:
- `outputs/diagnostics/04_flow_sorted_summary.csv`
- `outputs/figures/04_flow_sorted_ls.png`

---

### 6.6 (5) Unexpected flow decomposition
File: `src/signals/unexpected_flow.py`

Functions:
1) `decompose_flow(flow: pd.DataFrame, features_dict: dict[str, pd.DataFrame], model="ols", standardize=True) -> (pred_flow, unexpected_flow, info)`
- OLS固定（依存追加禁止）
- 日次ごとのクロスセクション回帰（実装容易、安定）
  - `Flow_{i,t} = beta_t' X_{i,t} + eps_{i,t}`
- `unexpected_flow = eps`（残差）

2) `predict_returns_with_unexpected_flow(returns, unexpected_flow, horizon=1, method="cs_regression") -> report_df`
- `r_{i,t+h} ~ unexpected_flow_{i,t}`
- IC（Spearman）も併記

Diagnostics:
- `outputs/diagnostics/05_unexpected_flow_report.csv`

---

### 6.7 (6) Crowding + overlay
File: `src/risk/crowding.py`

Functions:
1) `compute_crowding_components(prices, calendar, window=252, optional_data=None) -> pd.DataFrame`

Minimum required components (must implement):
- `reversal`：例）伸びすぎ指標（12Mと1Mの差など）
- `correlation`：例）ローリング相関の平均（群平均との差）
- `volatility`：例）ローリングボラ（3Mなど）

Optional components:
- `valuation`, `short_interest`（欠損時は除外）

2) `aggregate_crowding(components_df, method="mean", handle_missing="renormalize") -> crowding_score`
- componentをz化し、欠損componentは除外して平均（重み再正規化）

3) `apply_crowding_overlay(base_weights, crowding_score, cap_quantile=0.9, scale=0.5) -> adjusted_weights`
- crowding上位10%を `weight *= (1-scale)` に抑制
- 最後に正規化してsum=1

Diagnostics:
- `outputs/diagnostics/06_crowding_components.csv`
- `outputs/figures/06_crowding_timeseries.png`

---

## 7. Backtest (simple, fixed)
File: `src/backtest/engine.py`

Functions:
1) `backtest_daily(returns: pd.DataFrame, weights: pd.DataFrame, cost_bps=0.0, lag=1) -> pd.Series`
- `weights_applied = weights.shift(lag)`
- ポートリターン：`(weights_applied * returns).sum(axis=1)`
- コスト：`turnover = 0.5 * abs(weights_applied.diff()).sum(axis=1)`（定義固定）
- `net_ret = port_ret - turnover * cost_bps * 1e-4`

2) `compute_metrics(ret: pd.Series) -> pd.Series`
- CAGR, Vol, Sharpe(年率), MaxDD

Diagnostics:
- `outputs/diagnostics/00_metrics.csv`
- `outputs/figures/00_equity_curve.png`

---

## 8. Notebook Requirements (must pass)
File: `notebooks/00_pipeline_demo.ipynb`

Must:
1) `config/config.example.yaml` を読み込む（パス固定）
2) mode="synthetic" でデータ生成し、全モジュールを実行
3) theme selection → overlay → final weights
4) backtest → metrics → figures/diagnostics を保存
5) Leak-free validationセル：
   - `weights_applied = weights.shift(1)` を明示
   - `assert_no_lookahead(...)` を呼び出し
6) Notebookは先頭から完走する

---

## 9. QA Checklist (must write)
`outputs/logs/qa_checklist.txt` に各ノートブック実行時に追記：
- workspace AGENTS.md を読んだ（パス）
- 依存追加なし
- notebook(XX)が先頭から完走
- outputs規約名でファイルが生成
- shift(1) が必要な場合に適用されている
- sum(weights)=1（該当ノートのみ）

END.
