from __future__ import annotations

import numpy as np
import pandas as pd


def zscore_cs(df: pd.DataFrame) -> pd.DataFrame:
    row_mean = df.mean(axis=1)
    row_std = df.std(axis=1, ddof=0).replace(0, np.nan)
    out = df.sub(row_mean, axis=0).div(row_std, axis=0)
    return out.replace([np.inf, -np.inf], np.nan)


def winsorize(df: pd.DataFrame, p: float = 0.01) -> pd.DataFrame:
    if not 0 <= p < 0.5:
        raise ValueError("p must satisfy 0 <= p < 0.5")

    def _clip_row(row: pd.Series) -> pd.Series:
        lo = row.quantile(p)
        hi = row.quantile(1 - p)
        return row.clip(lo, hi)

    return df.apply(_clip_row, axis=1)


def spearman_ic(x: pd.Series, y: pd.Series) -> float:
    aligned = pd.concat([x, y], axis=1).dropna()
    if len(aligned) < 2:
        return float("nan")
    xr = aligned.iloc[:, 0].rank()
    yr = aligned.iloc[:, 1].rank()
    return float(xr.corr(yr))
