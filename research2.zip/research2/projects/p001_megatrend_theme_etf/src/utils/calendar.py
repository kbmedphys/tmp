from __future__ import annotations

import pandas as pd


def month_end_dates(dates: pd.DatetimeIndex) -> pd.DatetimeIndex:
    if not isinstance(dates, pd.DatetimeIndex):
        dates = pd.DatetimeIndex(dates)
    if len(dates) == 0:
        return pd.DatetimeIndex([])
    s = pd.Series(dates, index=dates)
    result = s.groupby(dates.to_period("M")).max().values
    return pd.DatetimeIndex(result)


def quarter_end_dates(dates: pd.DatetimeIndex) -> pd.DatetimeIndex:
    if not isinstance(dates, pd.DatetimeIndex):
        dates = pd.DatetimeIndex(dates)
    if len(dates) == 0:
        return pd.DatetimeIndex([])
    s = pd.Series(dates, index=dates)
    result = s.groupby(dates.to_period("Q")).max().values
    return pd.DatetimeIndex(result)
