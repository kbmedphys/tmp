from __future__ import annotations

import numpy as np
import pandas as pd


def assert_weights_sum_to_one(weights: pd.DataFrame, tol: float = 1e-6):
    row_sum = weights.sum(axis=1)
    mask = weights.notna().any(axis=1)
    bad = (row_sum[mask] - 1.0).abs() > tol
    if bad.any():
        sample = row_sum[mask][bad].head(5)
        raise AssertionError(f"sum(weights)!=1 rows={bad.sum()}, sample={sample.to_dict()}")


def assert_no_lookahead(weights: pd.DataFrame, returns: pd.DataFrame, lag: int):
    if lag < 1:
        raise AssertionError("lag must be >= 1")
    common_idx = weights.index.intersection(returns.index)
    if len(common_idx) <= lag:
        return
    w = weights.loc[common_idx].copy()
    applied = w.shift(lag)
    lhs = applied.iloc[lag:].fillna(0.0).to_numpy()
    rhs = w.iloc[:-lag].fillna(0.0).to_numpy()
    if lhs.shape != rhs.shape or not np.allclose(lhs, rhs, atol=1e-12):
        raise AssertionError("weights.shift(lag) の整合性に失敗しました")
