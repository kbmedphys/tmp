from __future__ import annotations

from pathlib import Path

import pandas as pd


def _ensure_parent(path: str | Path) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def save_parquet(df_or_ser, path: str):
    p = _ensure_parent(path)
    if isinstance(df_or_ser, pd.Series):
        df_or_ser = df_or_ser.to_frame(name=df_or_ser.name or "value")
    df_or_ser.to_parquet(p)


def save_csv(df: pd.DataFrame, path: str):
    p = _ensure_parent(path)
    df.to_csv(p, index=True)


def save_figure(fig, path: str):
    p = _ensure_parent(path)
    fig.savefig(p, bbox_inches="tight")
