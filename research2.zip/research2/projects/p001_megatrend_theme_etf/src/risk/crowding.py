from __future__ import annotations

import numpy as np
import pandas as pd

from src.utils.stats import zscore_cs


def _rolling_corr_mean(returns: pd.DataFrame, window: int = 63) -> pd.DataFrame:
    out = pd.DataFrame(index=returns.index, columns=returns.columns, dtype=float)
    for i in range(window - 1, len(returns)):
        sub = returns.iloc[i - window + 1 : i + 1]
        corr = sub.corr()
        for c in returns.columns:
            others = corr.loc[c].drop(index=c, errors="ignore")
            out.iat[i, out.columns.get_loc(c)] = others.mean() if len(others) > 0 else np.nan
    return out


def compute_crowding_components(
    prices: pd.DataFrame,
    calendar,
    window: int = 252,
    optional_data=None,
) -> pd.DataFrame:
    del calendar  # インターフェース維持のため受け取りのみ
    _ = optional_data
    prices = prices.astype(float)
    returns = prices.pct_change()

    ret_12m = (1.0 + returns).rolling(window=window, min_periods=max(20, window // 4)).apply(np.prod, raw=True) - 1.0
    ret_1m = (1.0 + returns).rolling(window=21, min_periods=10).apply(np.prod, raw=True) - 1.0
    reversal = ret_12m - ret_1m

    correlation = _rolling_corr_mean(returns, window=63)
    volatility = returns.rolling(window=63, min_periods=20).std(ddof=0) * np.sqrt(252.0)

    comp = pd.concat(
        {
            "reversal": reversal,
            "correlation": correlation,
            "volatility": volatility,
        },
        axis=1,
    )
    return comp


def aggregate_crowding(
    components_df: pd.DataFrame,
    method: str = "mean",
    handle_missing: str = "renormalize",
):
    if method != "mean":
        raise ValueError("Only method='mean' is supported.")
    if handle_missing != "renormalize":
        raise ValueError("Only handle_missing='renormalize' is supported.")
    if not isinstance(components_df.columns, pd.MultiIndex):
        raise ValueError("components_df columns must be MultiIndex: (component, asset)")

    components = components_df.columns.get_level_values(0).unique().tolist()
    z_components = []
    for comp in components:
        z_components.append(zscore_cs(components_df[comp]))
    z_stack = pd.concat({c: z for c, z in zip(components, z_components)}, axis=1)
    score = z_stack.T.groupby(level=1).mean().T
    return score


def apply_crowding_overlay(
    base_weights: pd.DataFrame,
    crowding_score: pd.DataFrame,
    cap_quantile: float = 0.9,
    scale: float = 0.5,
) -> pd.DataFrame:
    score = crowding_score.reindex(index=base_weights.index, columns=base_weights.columns)
    out = base_weights.copy().astype(float)

    for d in out.index:
        row_w = out.loc[d].copy()
        row_s = score.loc[d]
        valid = row_s.dropna()
        if len(valid) == 0:
            s = row_w.sum()
            out.loc[d] = row_w / s if s > 0 else row_w
            continue

        thresh = valid.quantile(cap_quantile)
        mask = row_s >= thresh
        row_w.loc[mask] = row_w.loc[mask] * (1.0 - scale)
        row_w = row_w.clip(lower=0.0)
        s = row_w.sum()
        if s > 0:
            row_w = row_w / s
        out.loc[d] = row_w

    return out
