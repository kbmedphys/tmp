from __future__ import annotations

import numpy as np
import pandas as pd

try:
    import statsmodels.api as sm
except Exception:  # pragma: no cover
    sm = None


def compute_flow_pressure_score(flow: pd.Series, window: int = 63, z: bool = True) -> pd.Series:
    flow = flow.astype(float)
    mu = flow.rolling(window=window, min_periods=max(5, window // 3)).mean()
    if not z:
        out = flow - mu
        out.name = "flow_pressure_score"
        return out
    sigma = flow.rolling(window=window, min_periods=max(5, window // 3)).std(ddof=0)
    score = (flow - mu) / sigma.replace(0, np.nan)
    score.name = "flow_pressure_score"
    return score


def _local_projection_target(returns: pd.Series, h: int) -> pd.Series:
    arr = returns.values.astype(float)
    n = len(arr)
    y = np.full(n, np.nan, dtype=float)
    for t in range(0, n - h):
        y[t] = np.nansum(arr[t + 1 : t + h + 1])
    return pd.Series(y, index=returns.index)


def _fit_ols_with_hac(y: pd.Series, x: pd.Series, nw_lags: int) -> tuple[float, float, int]:
    df = pd.concat([y, x], axis=1).dropna()
    if len(df) < 10:
        return np.nan, np.nan, int(len(df))

    if sm is not None:
        yv = df.iloc[:, 0]
        xv = sm.add_constant(df.iloc[:, 1], has_constant="add")
        fit = sm.OLS(yv, xv).fit(cov_type="HAC", cov_kwds={"maxlags": nw_lags})
        beta = float(fit.params.iloc[1])
        tstat = float(fit.tvalues.iloc[1])
        return beta, tstat, int(fit.nobs)

    # Fallback: simple OLS t-stat
    xv = df.iloc[:, 1].values.astype(float)
    yv = df.iloc[:, 0].values.astype(float)
    x_mean = xv.mean()
    y_mean = yv.mean()
    xx = np.sum((xv - x_mean) ** 2)
    if xx == 0:
        return np.nan, np.nan, len(df)
    beta = np.sum((xv - x_mean) * (yv - y_mean)) / xx
    alpha = y_mean - beta * x_mean
    resid = yv - (alpha + beta * xv)
    dof = len(df) - 2
    if dof <= 0:
        return float(beta), np.nan, len(df)
    se = np.sqrt((resid @ resid) / dof / xx)
    tstat = float(beta / se) if se > 0 else np.nan
    return float(beta), tstat, len(df)


def local_projection_irf(
    returns: pd.Series,
    shock: pd.Series,
    horizons: range,
    nw_lags: int = 5,
) -> pd.DataFrame:
    ret = returns.astype(float)
    shk = shock.astype(float).reindex(ret.index)
    rows: list[dict] = []

    for h in horizons:
        y_h = _local_projection_target(ret, int(h))
        beta, tstat, nobs = _fit_ols_with_hac(y_h, shk, nw_lags=nw_lags)
        rows.append({"h": int(h), "beta": beta, "tstat": tstat, "nobs": nobs})

    return pd.DataFrame(rows)
