from __future__ import annotations

import numpy as np
import pandas as pd


def _latest_score_on_or_before(theme_scores: pd.DataFrame, date: pd.Timestamp) -> tuple[pd.Series, pd.Series]:
    hist = theme_scores.loc[:date]
    if hist.empty:
        return pd.Series(index=theme_scores.columns, dtype=float), pd.Series(index=theme_scores.columns, dtype="datetime64[ns]")
    latest_values = hist.ffill().iloc[-1]
    latest_dates = pd.Series(index=theme_scores.columns, dtype="datetime64[ns]")
    for col in theme_scores.columns:
        last_idx = hist[col].dropna().index
        latest_dates[col] = last_idx[-1] if len(last_idx) > 0 else pd.NaT
    return latest_values, latest_dates


def _fallback_rank(returns_hist: pd.DataFrame, top_k: int) -> list[str]:
    if returns_hist.empty:
        return list(returns_hist.columns[:top_k])
    mom = (1.0 + returns_hist).prod() - 1.0
    vol = returns_hist.std(ddof=0).replace(0, np.nan)
    score = mom / vol
    score = score.replace([np.inf, -np.inf], np.nan).fillna(-np.inf)
    return score.sort_values(ascending=False).index[:top_k].tolist()


def compute_theme_rank(
    theme_scores: pd.DataFrame,
    theme_index_returns: pd.DataFrame,
    rebalance_dates: pd.DatetimeIndex,
    top_k: int,
    stale_months: int,
    window_days: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    cols = list(theme_index_returns.columns)
    theme_scores = theme_scores.reindex(columns=cols)
    theme_index_returns = theme_index_returns.reindex(columns=cols)

    rebalance_dates = pd.DatetimeIndex([d for d in rebalance_dates if d in theme_index_returns.index])
    w_rebal = pd.DataFrame(0.0, index=rebalance_dates, columns=cols)

    selected_rows: list[dict] = []
    debug_rows: list[dict] = []

    for date in rebalance_dates:
        latest_values, latest_dates = _latest_score_on_or_before(theme_scores, date)
        stale_limit = date - pd.DateOffset(months=stale_months)
        stale_mask = latest_dates.isna() | (latest_dates < stale_limit)
        stale_count = int(stale_mask.sum())

        valid_scores = latest_values.where(~stale_mask)
        valid_scores = valid_scores.dropna()

        if len(valid_scores) >= top_k:
            selected = valid_scores.sort_values(ascending=False).index[:top_k].tolist()
            used_fallback = False
        else:
            hist = theme_index_returns.loc[:date].tail(window_days)
            selected = _fallback_rank(hist, top_k)
            used_fallback = True

        if len(selected) > 0:
            w_rebal.loc[date, selected] = 1.0 / len(selected)

        selected_row = {"date": date}
        debug_row = {
            "date": date,
            "used_score_or_fallback": "fallback" if used_fallback else "score",
            "stale_count": stale_count,
        }
        for i in range(top_k):
            value = selected[i] if i < len(selected) else None
            selected_row[f"selected_{i + 1}"] = value
            debug_row[f"selected_{i + 1}"] = value
        selected_rows.append(selected_row)
        debug_rows.append(debug_row)

    selected_themes = pd.DataFrame(selected_rows).set_index("date") if selected_rows else pd.DataFrame()
    debug_df = pd.DataFrame(debug_rows)
    theme_weights = w_rebal.reindex(theme_index_returns.index).ffill().fillna(0.0)
    return selected_themes, theme_weights, debug_df


def compute_composite_return(theme_index_returns: pd.DataFrame, theme_weights: pd.DataFrame, lag: int = 1) -> pd.Series:
    weights_applied = theme_weights.shift(lag).reindex(theme_index_returns.index).fillna(0.0)
    out = (weights_applied * theme_index_returns).sum(axis=1)
    out.name = "composite_return"
    return out
