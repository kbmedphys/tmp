from __future__ import annotations

import numpy as np
import pandas as pd

from src.utils.stats import spearman_ic


def _cross_section_ols(y: pd.Series, x_df: pd.DataFrame) -> tuple[pd.Series, pd.Series, dict]:
    df = pd.concat([y.rename("y"), x_df], axis=1).dropna()
    if len(df) < x_df.shape[1] + 2:
        nan_pred = pd.Series(np.nan, index=y.index)
        nan_eps = pd.Series(np.nan, index=y.index)
        return nan_pred, nan_eps, {"nobs": len(df), "r2": np.nan}

    yv = df["y"].values.astype(float)
    xv = df.drop(columns=["y"]).values.astype(float)
    xv = np.column_stack([np.ones(len(xv)), xv])
    beta, *_ = np.linalg.lstsq(xv, yv, rcond=None)
    y_hat = xv @ beta
    resid = yv - y_hat

    pred = pd.Series(np.nan, index=y.index, dtype=float)
    eps = pd.Series(np.nan, index=y.index, dtype=float)
    pred.loc[df.index] = y_hat
    eps.loc[df.index] = resid

    sse = float(np.sum(resid**2))
    sst = float(np.sum((yv - yv.mean()) ** 2))
    r2 = 1.0 - sse / sst if sst > 0 else np.nan
    return pred, eps, {"nobs": len(df), "r2": r2}


def decompose_flow(
    flow: pd.DataFrame,
    features_dict: dict[str, pd.DataFrame],
    model: str = "ols",
    standardize: bool = True,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if model.lower() != "ols":
        raise ValueError("Only model='ols' is supported.")

    flow = flow.astype(float)
    dates = flow.index
    assets = flow.columns

    pred_flow = pd.DataFrame(index=dates, columns=assets, dtype=float)
    unexpected_flow = pd.DataFrame(index=dates, columns=assets, dtype=float)
    info_rows: list[dict] = []

    for d in dates:
        y = flow.loc[d]
        feature_cols = {}
        for name, feat in features_dict.items():
            feature_cols[name] = feat.reindex(index=dates, columns=assets).loc[d]
        x_df = pd.DataFrame(feature_cols, index=assets)

        if standardize:
            mu = x_df.mean(axis=0)
            sd = x_df.std(axis=0, ddof=0).replace(0, np.nan)
            x_df = x_df.sub(mu, axis=1).div(sd, axis=1)

        pred, eps, info = _cross_section_ols(y, x_df)
        pred_flow.loc[d] = pred
        unexpected_flow.loc[d] = eps
        info_rows.append({"date": d, "nobs": info["nobs"], "r2": info["r2"]})

    info_df = pd.DataFrame(info_rows).set_index("date")
    return pred_flow, unexpected_flow, info_df


def predict_returns_with_unexpected_flow(
    returns: pd.DataFrame,
    unexpected_flow: pd.DataFrame,
    horizon: int = 1,
    method: str = "cs_regression",
) -> pd.DataFrame:
    if method != "cs_regression":
        raise ValueError("Only method='cs_regression' is supported.")

    ret_fwd = returns.shift(-horizon)
    rows: list[dict] = []

    for d in unexpected_flow.index:
        if d not in ret_fwd.index:
            continue
        x = unexpected_flow.loc[d]
        y = ret_fwd.loc[d]
        df = pd.concat([x.rename("x"), y.rename("y")], axis=1).dropna()
        if len(df) < 3:
            rows.append({"date": d, "beta": np.nan, "ic": np.nan, "nobs": int(len(df)), "r2": np.nan})
            continue

        xv = df["x"].values.astype(float)
        yv = df["y"].values.astype(float)
        x_mat = np.column_stack([np.ones(len(xv)), xv])
        beta_hat, *_ = np.linalg.lstsq(x_mat, yv, rcond=None)
        y_hat = x_mat @ beta_hat
        resid = yv - y_hat
        sse = float(np.sum(resid**2))
        sst = float(np.sum((yv - yv.mean()) ** 2))
        r2 = 1.0 - sse / sst if sst > 0 else np.nan
        ic = spearman_ic(df["x"], df["y"])

        rows.append(
            {
                "date": d,
                "beta": float(beta_hat[1]),
                "ic": float(ic) if not np.isnan(ic) else np.nan,
                "nobs": int(len(df)),
                "r2": r2,
            }
        )

    report = pd.DataFrame(rows).set_index("date")
    return report
