from __future__ import annotations

import numpy as np
import pandas as pd


def _ols_slope_tstat(y: np.ndarray) -> tuple[float, float]:
    n = len(y)
    if n < 3:
        return np.nan, np.nan
    x = np.arange(n, dtype=float)
    x_c = x - x.mean()
    y_c = y - y.mean()
    ssx = float(np.dot(x_c, x_c))
    if ssx == 0:
        return np.nan, np.nan
    slope = float(np.dot(x_c, y_c) / ssx)
    resid = y - (y.mean() + slope * x_c)
    dof = n - 2
    if dof <= 0:
        return slope, np.nan
    sigma2 = float(np.dot(resid, resid) / dof)
    se = np.sqrt(sigma2 / ssx) if sigma2 >= 0 else np.nan
    if se == 0 or np.isnan(se):
        return slope, np.nan
    tval = slope / se
    return slope, float(tval)


def trend_scanning(
    prices: pd.Series,
    lookback_min: int = 20,
    lookback_max: int = 252,
    step: int = 5,
    use_log: bool = True,
) -> pd.DataFrame:
    s = prices.astype(float).copy()
    if use_log:
        s = np.log(s.clip(lower=1e-12))
    idx = s.index
    values = s.values

    rows: list[dict] = []
    n = len(s)
    horizons = list(range(lookback_min, lookback_max + 1, step))

    for i in range(n):
        best = {"abs_t": -np.inf, "tval": np.nan, "horizon": np.nan, "slope": np.nan}
        for h in horizons:
            start = i - h + 1
            if start < 0:
                continue
            y = values[start : i + 1]
            if np.isnan(y).any():
                continue
            slope, tval = _ols_slope_tstat(y)
            if np.isnan(tval):
                continue
            if abs(tval) > best["abs_t"]:
                best = {"abs_t": abs(tval), "tval": float(tval), "horizon": int(h), "slope": float(slope)}

        horizon = best["horizon"]
        t1 = pd.NaT
        if not np.isnan(horizon):
            j = i + int(horizon)
            if j < n:
                t1 = idx[j]

        slope = best["slope"]
        label = np.sign(slope) if not np.isnan(slope) else np.nan
        rows.append(
            {
                "date": idx[i],
                "tval": best["tval"],
                "horizon": horizon,
                "slope": slope,
                "label": label,
                "t1": t1,
            }
        )

    out = pd.DataFrame(rows).set_index("date")
    return out
