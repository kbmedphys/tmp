from __future__ import annotations

import numpy as np
import pandas as pd


def _assign_bucket(values: pd.Series, q: int) -> pd.Series:
    v = values.dropna()
    if len(v) == 0:
        return pd.Series(index=values.index, dtype=float)
    rank = v.rank(method="first")
    try:
        bucket = pd.qcut(rank, q=q, labels=False, duplicates="drop") + 1
    except ValueError:
        bucket = pd.Series(np.nan, index=v.index)
    out = pd.Series(np.nan, index=values.index)
    out.loc[v.index] = bucket.astype(float)
    return out


def build_flow_sorted_portfolios(
    returns: pd.DataFrame,
    flow: pd.DataFrame,
    rebalance_dates: pd.DatetimeIndex,
    q: int = 5,
    weighting: str = "ew",
    lag: int = 1,
) -> dict:
    if weighting != "ew":
        raise ValueError("Only weighting='ew' is supported.")

    returns = returns.astype(float)
    flow = flow.reindex(index=returns.index, columns=returns.columns).astype(float)
    rebalance_dates = pd.DatetimeIndex([d for d in rebalance_dates if d in returns.index])
    assets = returns.columns.tolist()

    bucket_rebal_weights = {
        b: pd.DataFrame(0.0, index=rebalance_dates, columns=assets) for b in range(1, q + 1)
    }
    bucket_membership: dict[str, dict[str, list[str]]] = {}

    for d in rebalance_dates:
        row_flow = flow.loc[d]
        bucket = _assign_bucket(row_flow, q=q)
        date_membership: dict[str, list[str]] = {}
        for b in range(1, q + 1):
            members = bucket.index[bucket == float(b)].tolist()
            date_membership[f"Q{b}"] = members
            if len(members) > 0:
                bucket_rebal_weights[b].loc[d, members] = 1.0 / len(members)
        bucket_membership[str(d.date())] = date_membership

    bucket_returns = pd.DataFrame(index=returns.index)
    daily_bucket_weights: dict[int, pd.DataFrame] = {}
    for b in range(1, q + 1):
        w_daily = bucket_rebal_weights[b].reindex(returns.index).ffill().fillna(0.0)
        daily_bucket_weights[b] = w_daily
        bucket_returns[f"Q{b}"] = (w_daily.shift(lag).fillna(0.0) * returns).sum(axis=1)

    ls_return = bucket_returns[f"Q{q}"] - bucket_returns["Q1"]
    ls_return.name = "ls_return"

    ls_weights = 0.5 * daily_bucket_weights[q] - 0.5 * daily_bucket_weights[1]
    turnover = 0.5 * ls_weights.shift(lag).diff().abs().sum(axis=1).fillna(0.0)
    turnover.name = "turnover"

    return {
        "bucket_returns": bucket_returns,
        "ls_return": ls_return,
        "turnover": turnover,
        "bucket_membership": bucket_membership,
    }
