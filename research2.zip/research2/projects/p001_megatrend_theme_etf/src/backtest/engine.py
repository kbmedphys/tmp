from __future__ import annotations

import numpy as np
import pandas as pd


def backtest_daily(
    returns: pd.DataFrame,
    weights: pd.DataFrame,
    cost_bps: float = 0.0,
    lag: int = 1,
) -> pd.Series:
    ret = returns.astype(float)
    w = weights.reindex(index=ret.index, columns=ret.columns).astype(float)
    weights_applied = w.shift(lag).fillna(0.0)
    port_ret = (weights_applied * ret).sum(axis=1)
    turnover = 0.5 * weights_applied.diff().abs().sum(axis=1).fillna(0.0)
    net_ret = port_ret - turnover * cost_bps * 1e-4
    net_ret.name = "portfolio_return"
    return net_ret


def compute_metrics(ret: pd.Series) -> pd.Series:
    r = ret.dropna()
    if len(r) == 0:
        return pd.Series({"CAGR": np.nan, "Vol": np.nan, "Sharpe": np.nan, "MaxDD": np.nan})

    ann = 252.0
    equity = (1.0 + r).cumprod()
    years = len(r) / ann
    cagr = equity.iloc[-1] ** (1.0 / years) - 1.0 if years > 0 else np.nan
    vol = r.std(ddof=0) * np.sqrt(ann)
    sharpe = (r.mean() / r.std(ddof=0)) * np.sqrt(ann) if r.std(ddof=0) > 0 else np.nan
    maxdd = (equity / equity.cummax() - 1.0).min()
    return pd.Series({"CAGR": cagr, "Vol": vol, "Sharpe": sharpe, "MaxDD": maxdd})
