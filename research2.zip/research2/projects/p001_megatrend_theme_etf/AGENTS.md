# Project Rules

## 実装方針
- 実装は incremental に進める。
- 既存の legacy データや他プロジェクトファイルを編集しない。
- 依存追加が必要な場合は `uv add` のみを使用する。

## 実行方針
- 各 notebook は先頭セルから単体完走可能に保つ。
- 外部データ取得（Web/API）は行わない。
- `config/config.example.yaml` を共通設定として利用する。

## リーク回避
- シグナルは t 時点情報のみで計算する。
- ポジション適用は必ず `weights.shift(1)` を使う。
- 月次/四半期リバランスでも同様に翌営業日適用とする。

## 出力方針
- すべての成果物は `outputs/` 配下へ保存する。
- 規約ファイル名（01〜06, 00）を厳守する。
- 実行結果は `outputs/logs/qa_checklist.txt` に追記する。
