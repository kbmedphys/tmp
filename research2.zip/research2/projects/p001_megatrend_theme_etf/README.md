# p001_megatrend_theme_etf

## 目的
`SPEC.md` の Notebook-per-Method 要件に従い、`01`〜`06` を単体完走し、`00_pipeline_demo.ipynb` で統合パイプラインを完走する。

## 共通ルール
- 全ノートブックは `config/config.example.yaml` を読み込む。
- データは `data.mode=synthetic` で生成する（外部データ取得なし）。
- 成果物はすべて `outputs/` 配下に固定ファイル名で保存する。
- リーク回避としてポジション適用は `weights.shift(1)` を使用する。

## Notebook一覧（目的 / 入出力）
- `notebooks/01_msci_theme_select.ipynb`
  - 目的: MSCIテーマ選択 + stale/fallback ロジック検証
  - 主出力: `outputs/signals/01_theme_rank.parquet`, `outputs/weights/01_theme_weights_raw.parquet`, `outputs/diagnostics/01_theme_selection_debug.csv`
- `notebooks/02_trend_scanning.ipynb`
  - 目的: Trend Scanning の `tval/horizon/slope/label/t1` 検証
  - 主出力: `outputs/signals/02_trend_scanning.parquet`, `outputs/diagnostics/02_trend_scanning_sample.csv`, `outputs/figures/02_trend_scan_tval_horizon.png`
- `notebooks/03_flow_diagnostics_irf.ipynb`
  - 目的: Flow pressure score と LP-IRF 検証
  - 主出力: `outputs/signals/03_flow_pressure_score.parquet`, `outputs/diagnostics/03_flow_irf.csv`
- `notebooks/04_flow_sorted_portfolios.ipynb`
  - 目的: Flow-sorted bucket/LS リターン検証
  - 主出力: `outputs/diagnostics/04_flow_sorted_summary.csv`, `outputs/signals/04_bucket_returns.parquet`, `outputs/signals/04_ls_return.parquet`
- `notebooks/05_unexpected_flow.ipynb`
  - 目的: Flow分解（pred/unexpected）と予測レポート検証
  - 主出力: `outputs/signals/05_pred_flow.parquet`, `outputs/signals/05_unexpected_flow.parquet`, `outputs/diagnostics/05_unexpected_flow_report.csv`
- `notebooks/06_crowding_overlay.ipynb`
  - 目的: crowding component/score と overlay 重み検証
  - 主出力: `outputs/signals/06_crowding_components.parquet`, `outputs/signals/06_crowding_score.parquet`, `outputs/weights/06_overlay_weights.parquet`
- `notebooks/00_pipeline_demo.ipynb`
  - 目的: 1〜6を統合した end-to-end（選択→overlay→backtest）
  - 主出力: `outputs/weights/00_theme_weights_raw.parquet`, `outputs/weights/00_theme_weights_overlay.parquet`, `outputs/weights/00_portfolio_weights_applied.parquet`, `outputs/diagnostics/00_metrics.csv`

## 実行手順
1. `notebooks/01_msci_theme_select.ipynb`
2. `notebooks/02_trend_scanning.ipynb`
3. `notebooks/03_flow_diagnostics_irf.ipynb`
4. `notebooks/04_flow_sorted_portfolios.ipynb`
5. `notebooks/05_unexpected_flow.ipynb`
6. `notebooks/06_crowding_overlay.ipynb`
7. `notebooks/00_pipeline_demo.ipynb`

## QAログ
- 各ノートブック完走時に `outputs/logs/qa_checklist.txt` へ以下を追記する。
- `Notebook名`
- `OK/NG`
- `生成ファイル確認`
