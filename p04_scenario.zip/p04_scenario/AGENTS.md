# Project Rules: p04_scenario

このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。
このプロジェクトの Prefer explicit python path は 
- envs/rl/.venv/rl/python

---

## Source of truth
- refs/*.ipynb : 参考プログラム
- *.ipynb            : single source of execution & inspection
  
---

## 0. 目的
本プロジェクトは参考プログラムをベースに拡張実装を行う。
### 参考プログラム
- refs/12.ipynb
  
---

## 1. 進め方
- 人工的な100シナリオ分の学習データを用いてトレーニングし、別の100シナリオ分のデータを用いてテストできるよう実装

## 2. 注意
- 特徴量は t までの情報で計算し、t+1 のリターン予測に使う
- 月次リバランスなら「月末で決めたwを翌営業日から適用」など実装上の時点整合を厳密化
- 実装は１つのipynbファイルで完結させること