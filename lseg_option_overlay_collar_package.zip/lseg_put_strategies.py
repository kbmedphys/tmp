"""
LSEG IV-surface based rolling long put overlay and delta-replicated long put strategy.

This module is designed for historical backtests where the IV surface is obtained from
LSEG Data Library / IPA Volatility Surfaces.  It does not require lseg-data to be
installed unless you call the LSEG fetch functions.

Core accounting convention:
- Long put overlay: premium is paid from the cash account and the option is carried as an asset.
- Delta-replicated put: uses a financed overlay account, so the initial synthetic put value is
  offset by a financing liability and the hedged NAV starts equal to the unhedged NAV.
"""
from __future__ import annotations

import json
import math
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Basic math and Black-Scholes-Merton
# -----------------------------------------------------------------------------

SQRT_2PI = math.sqrt(2.0 * math.pi)


def norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / SQRT_2PI


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def to_decimal_vol(vol: Union[float, int, str, None]) -> float:
    """Convert LSEG-style vol to decimal. If value looks like percent, divide by 100."""
    if vol is None:
        return np.nan
    try:
        x = float(vol)
    except Exception:
        return np.nan
    if not np.isfinite(x) or x <= 0:
        return np.nan
    # LSEG surface examples commonly return values like 22.5 for 22.5%.
    return x / 100.0 if x > 3.0 else x


def bsm_put(
    spot: float,
    strike: float,
    tau: float,
    rate: float = 0.0,
    div_yield: float = 0.0,
    vol: float = 0.20,
) -> Dict[str, float]:
    """European put price and greeks under Black-Scholes-Merton.

    Parameters are scalar. tau is in years; vol is decimal, e.g. 0.20.
    Greeks are per one option unit on one underlying unit.
    Theta is per year.
    Vega is price change per 1.00 vol point; divide by 100 for per vol bp/percent point.
    """
    S = float(spot)
    K = float(strike)
    T = max(float(tau), 0.0)
    r = float(rate)
    q = float(div_yield)
    sigma = max(float(vol), 1e-12)

    if S <= 0 or K <= 0:
        raise ValueError("spot and strike must be positive")

    if T <= 1e-10:
        intrinsic = max(K - S, 0.0)
        # Expiry delta convention: -1 if ITM, 0 if OTM, -0.5 at ATM.
        if S < K:
            delta = -1.0
        elif S > K:
            delta = 0.0
        else:
            delta = -0.5
        return {
            "price": intrinsic,
            "delta": delta,
            "gamma": 0.0,
            "vega": 0.0,
            "theta": 0.0,
            "d1": np.nan,
            "d2": np.nan,
        }

    sqrtT = math.sqrt(T)
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma * sigma) * T) / (sigma * sqrtT)
    d2 = d1 - sigma * sqrtT

    Nd1_neg = norm_cdf(-d1)
    Nd2_neg = norm_cdf(-d2)
    disc_r = math.exp(-r * T)
    disc_q = math.exp(-q * T)

    price = K * disc_r * Nd2_neg - S * disc_q * Nd1_neg
    delta = disc_q * (norm_cdf(d1) - 1.0)
    gamma = disc_q * norm_pdf(d1) / (S * sigma * sqrtT)
    vega = S * disc_q * norm_pdf(d1) * sqrtT
    # BSM theta for put, per year.
    theta = (
        -S * disc_q * norm_pdf(d1) * sigma / (2.0 * sqrtT)
        + q * S * disc_q * Nd1_neg
        - r * K * disc_r * Nd2_neg
    )

    return {
        "price": float(price),
        "delta": float(delta),
        "gamma": float(gamma),
        "vega": float(vega),
        "theta": float(theta),
        "d1": float(d1),
        "d2": float(d2),
    }


# -----------------------------------------------------------------------------
# Surface representation and interpolation
# -----------------------------------------------------------------------------


def tenor_to_years(value: Union[str, float, int]) -> float:
    """Parse common tenor strings to years. Examples: 1W, 3M, 1Y, 0.25."""
    if isinstance(value, (int, float)) and np.isfinite(float(value)):
        return float(value)
    s = str(value).strip().upper()
    if not s:
        return np.nan
    try:
        return float(s)
    except Exception:
        pass
    unit = s[-1]
    try:
        num = float(s[:-1])
    except Exception:
        return np.nan
    if unit == "D":
        return num / 365.25
    if unit == "W":
        return 7.0 * num / 365.25
    if unit == "M":
        return num / 12.0
    if unit == "Y":
        return num
    return np.nan


def axis_value_to_tau(axis_value: object, valuation_date: Union[str, pd.Timestamp]) -> Tuple[float, Optional[pd.Timestamp]]:
    """Convert LSEG matrix row label to tau-years and optionally expiry date.

    Row labels can be expiry dates like '2026-03-20' or tenor strings like '3M'.
    """
    val_date = pd.Timestamp(valuation_date).normalize()
    # Try date parsing first, but avoid interpreting small numeric tenors as dates.
    s = str(axis_value)
    if any(ch in s for ch in ["-", "/"]):
        try:
            expiry = pd.Timestamp(pd.to_datetime(axis_value)).normalize()
            tau = max((expiry - val_date).days / 365.25, 1.0 / 365.25)
            return tau, expiry
        except Exception:
            pass
    tau = tenor_to_years(axis_value)
    return tau, None


@dataclass
class IVSurface:
    """Volatility surface on tau-years × moneyness grid.

    grid values must be decimal vols. Index is tau in years. Columns are moneyness values.
    """

    valuation_date: pd.Timestamp
    grid: pd.DataFrame
    underlying_ric: str = ""
    surface_tag: str = ""
    expiry_by_tau: Optional[Dict[float, str]] = None
    raw: Optional[dict] = None

    def __post_init__(self) -> None:
        self.valuation_date = pd.Timestamp(self.valuation_date).normalize()
        g = self.grid.copy()
        g.index = [float(x) for x in g.index]
        g.columns = [float(x) for x in g.columns]
        g = g.sort_index().sort_index(axis=1)
        try:
            g = g.map(to_decimal_vol)
        except AttributeError:
            g = g.applymap(to_decimal_vol)
        self.grid = g
        if self.expiry_by_tau is None:
            self.expiry_by_tau = {}

    @property
    def min_tau(self) -> float:
        return float(np.nanmin(self.grid.index.values))

    @property
    def max_tau(self) -> float:
        return float(np.nanmax(self.grid.index.values))

    @property
    def min_moneyness(self) -> float:
        return float(np.nanmin(self.grid.columns.values))

    @property
    def max_moneyness(self) -> float:
        return float(np.nanmax(self.grid.columns.values))

    def select_tau(self, target_tau: float) -> float:
        taus = np.array(self.grid.index.values, dtype=float)
        if len(taus) == 0:
            raise ValueError("surface grid has no maturities")
        return float(taus[np.argmin(np.abs(taus - target_tau))])

    def interpolate_iv(self, moneyness: float, tau: float, clamp: bool = True) -> float:
        """Bilinear interpolation with total variance interpolation across tenor.

        Moneyness interpolation is linear in vol on each maturity row. Tenor interpolation
        is linear in total variance w = sigma^2 * tau.
        """
        if self.grid.empty:
            raise ValueError("empty IV surface")

        m = float(moneyness)
        t = max(float(tau), 1.0 / 365.25)

        m_cols = np.array(self.grid.columns, dtype=float)
        t_rows = np.array(self.grid.index, dtype=float)

        if clamp:
            m = min(max(m, float(m_cols.min())), float(m_cols.max()))
            t = min(max(t, float(t_rows.min())), float(t_rows.max()))
        else:
            if m < m_cols.min() or m > m_cols.max() or t < t_rows.min() or t > t_rows.max():
                raise ValueError("requested point outside surface grid")

        def interp_m(row_values: np.ndarray) -> float:
            mask = np.isfinite(row_values)
            if mask.sum() < 2:
                if mask.sum() == 1:
                    return float(row_values[mask][0])
                return np.nan
            return float(np.interp(m, m_cols[mask], row_values[mask]))

        # Locate surrounding tenors.
        if t <= t_rows[0]:
            vol = interp_m(self.grid.iloc[0].values.astype(float))
            return float(vol)
        if t >= t_rows[-1]:
            vol = interp_m(self.grid.iloc[-1].values.astype(float))
            return float(vol)

        hi_idx = int(np.searchsorted(t_rows, t, side="right"))
        lo_idx = hi_idx - 1
        t0 = float(t_rows[lo_idx])
        t1 = float(t_rows[hi_idx])
        v0 = interp_m(self.grid.iloc[lo_idx].values.astype(float))
        v1 = interp_m(self.grid.iloc[hi_idx].values.astype(float))
        if not np.isfinite(v0) or not np.isfinite(v1):
            return float(np.nan)
        w0 = v0 * v0 * t0
        w1 = v1 * v1 * t1
        weight = (t - t0) / (t1 - t0) if t1 > t0 else 0.0
        wt = (1.0 - weight) * w0 + weight * w1
        return float(math.sqrt(max(wt / t, 0.0)))

    def to_csv(self, path: Union[str, Path]) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.grid.to_csv(path)
        meta = {
            "valuation_date": str(self.valuation_date.date()),
            "underlying_ric": self.underlying_ric,
            "surface_tag": self.surface_tag,
            "expiry_by_tau": self.expiry_by_tau or {},
        }
        path.with_suffix(".json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

    @staticmethod
    def from_csv(path: Union[str, Path]) -> "IVSurface":
        path = Path(path)
        grid = pd.read_csv(path, index_col=0)
        meta_path = path.with_suffix(".json")
        if meta_path.exists():
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        else:
            meta = {}
        return IVSurface(
            valuation_date=pd.Timestamp(meta.get("valuation_date", "1970-01-01")),
            grid=grid,
            underlying_ric=meta.get("underlying_ric", ""),
            surface_tag=meta.get("surface_tag", ""),
            expiry_by_tau=meta.get("expiry_by_tau", {}),
        )


def parse_lseg_surface_matrix(
    surface_matrix: list,
    valuation_date: Union[str, pd.Timestamp],
    underlying_ric: str = "",
    surface_tag: str = "",
    raw: Optional[dict] = None,
) -> IVSurface:
    """Parse LSEG IPA Matrix response into IVSurface.

    Expected matrix structure:
        [[None, m1, m2, ...], [expiry_or_tenor_1, vol_11, vol_12, ...], ...]
    """
    if not surface_matrix or len(surface_matrix) < 2:
        raise ValueError("surface matrix is empty or malformed")
    header = surface_matrix[0]
    moneyness = [float(x) for x in header[1:]]
    rows = []
    taus = []
    expiry_by_tau: Dict[float, str] = {}
    for row in surface_matrix[1:]:
        if len(row) < 2:
            continue
        tau, expiry = axis_value_to_tau(row[0], valuation_date)
        if not np.isfinite(tau) or tau <= 0:
            continue
        values = [to_decimal_vol(x) for x in row[1:]]
        if len(values) != len(moneyness):
            continue
        rows.append(values)
        taus.append(float(tau))
        if expiry is not None:
            expiry_by_tau[float(tau)] = str(expiry.date())
    grid = pd.DataFrame(rows, index=taus, columns=moneyness)
    grid = grid.groupby(level=0).mean().sort_index().sort_index(axis=1)
    return IVSurface(
        valuation_date=pd.Timestamp(valuation_date),
        grid=grid,
        underlying_ric=underlying_ric,
        surface_tag=surface_tag,
        expiry_by_tau=expiry_by_tau,
        raw=raw,
    )


def parse_lseg_surface_response(
    raw_response: dict,
    valuation_date: Union[str, pd.Timestamp],
    surface_tag: Optional[str] = None,
    underlying_ric: str = "",
) -> IVSurface:
    data = raw_response.get("data", [])
    if not data:
        raise ValueError("LSEG surface response does not contain data")
    item = None
    if surface_tag is not None:
        for obj in data:
            if obj.get("surfaceTag") == surface_tag:
                item = obj
                break
    if item is None:
        item = data[0]
    matrix = item.get("surface")
    if matrix is None:
        raise ValueError("LSEG surface response item does not contain 'surface'")
    return parse_lseg_surface_matrix(
        matrix,
        valuation_date=valuation_date,
        underlying_ric=underlying_ric,
        surface_tag=item.get("surfaceTag", surface_tag or underlying_ric),
        raw=raw_response,
    )


def surface_cache_path(cache_dir: Union[str, Path], underlying_ric: str, valuation_date: Union[str, pd.Timestamp]) -> Path:
    safe_ric = str(underlying_ric).replace("/", "_").replace(".", "dot").replace("=", "eq")
    d = pd.Timestamp(valuation_date).strftime("%Y%m%d")
    return Path(cache_dir) / f"{safe_ric}_{d}.csv"


# -----------------------------------------------------------------------------
# LSEG data functions. Optional dependency on lseg-data.
# -----------------------------------------------------------------------------


def open_lseg_session() -> object:
    """Open a default LSEG session.

    In a Workspace desktop setup, this is usually enough. Platform sessions with app keys
    can be configured by the user before calling the fetch functions.
    """
    import lseg.data as ld  # type: ignore

    ld.open_session()
    return ld


def close_lseg_session() -> None:
    import lseg.data as ld  # type: ignore

    ld.close_session()


def fetch_lseg_price_history(
    rics: Sequence[str],
    start: Union[str, pd.Timestamp],
    end: Union[str, pd.Timestamp],
    field_candidates: Sequence[str] = ("TRDPRC_1", "CF_CLOSE", "OFF_CLOSE", "SETTLE", "MID_PRICE"),
    interval: str = "daily",
) -> pd.DataFrame:
    """Fetch daily price history from LSEG, trying several common close fields.

    Returns a DataFrame indexed by date with columns equal to RICs.
    """
    import lseg.data as ld  # type: ignore

    last_err = None
    for field in field_candidates:
        try:
            raw = ld.get_history(
                universe=list(rics),
                fields=[field],
                start=str(pd.Timestamp(start).date()),
                end=str(pd.Timestamp(end).date()),
                interval=interval,
            )
            px = normalize_lseg_history_prices(raw, list(rics), field)
            if not px.empty and px.notna().sum().sum() > 0:
                return px
        except Exception as exc:  # pragma: no cover - depends on LSEG entitlements
            last_err = exc
            continue
    raise RuntimeError(f"Could not fetch price history with candidate fields. Last error: {last_err}")


def normalize_lseg_history_prices(raw: pd.DataFrame, rics: Sequence[str], field: str) -> pd.DataFrame:
    """Coerce common ld.get_history output shapes into a price DataFrame."""
    df = raw.copy()
    if df.empty:
        return df
    df.index = pd.to_datetime(df.index)
    out = pd.DataFrame(index=df.index)
    if isinstance(df.columns, pd.MultiIndex):
        # Try level 0 as RIC, then level 1 as RIC.
        for ric in rics:
            series = None
            if ric in df.columns.get_level_values(0):
                sub = df.xs(ric, level=0, axis=1)
                series = sub.iloc[:, 0]
            elif ric in df.columns.get_level_values(1):
                sub = df.xs(ric, level=1, axis=1)
                series = sub.iloc[:, 0]
            if series is not None:
                out[ric] = pd.to_numeric(series, errors="coerce")
    else:
        if len(rics) == 1 and len(df.columns) >= 1:
            out[rics[0]] = pd.to_numeric(df.iloc[:, 0], errors="coerce")
        else:
            for ric in rics:
                if ric in df.columns:
                    out[ric] = pd.to_numeric(df[ric], errors="coerce")
                elif field in df.columns and len(rics) == 1:
                    out[ric] = pd.to_numeric(df[field], errors="coerce")
    return out.sort_index().dropna(how="all")


def fetch_lseg_iv_surface_endpoint(
    underlying_ric: str,
    valuation_date: Union[str, pd.Timestamp],
    surface_tag: Optional[str] = None,
    x_axis: str = "Date",
    y_axis: str = "Moneyness",
    input_volatility_type: str = "Implied",
    price_side: str = "Mid",
    volatility_model: str = "SVI",
    layout_format: str = "Matrix",
    outputs: Sequence[str] = ("Data", "ForwardCurve", "MoneynessStrike"),
) -> IVSurface:
    """Fetch one ETI IV surface from LSEG IPA endpoint and parse into IVSurface.

    Requires an open LSEG session and entitlements for IPA volatility surfaces.
    """
    from lseg.data.delivery import endpoint_request  # type: ignore

    endpoint_url = "https://api.refinitiv.com/data/quantitative-analytics-curves-and-surfaces/v1/surfaces"
    calc_date = pd.Timestamp(valuation_date).strftime("%Y-%m-%d")
    tag = surface_tag or str(underlying_ric).replace(".", "").replace("=", "")
    request_body = {
        "universe": [
            {
                "surfaceTag": tag,
                "underlyingType": "Eti",
                "underlyingDefinition": {"instrumentCode": underlying_ric},
                "surfaceParameters": {
                    "inputVolatilityType": input_volatility_type,
                    "timeStamp": "Default",
                    "priceSide": price_side,
                    "volatilityModel": volatility_model,
                    "xAxis": x_axis,
                    "yAxis": y_axis,
                    "calculationDate": calc_date,
                },
                "surfaceLayout": {"format": layout_format},
            }
        ],
        "outputs": list(outputs),
    }
    request_definition = endpoint_request.Definition(
        method=endpoint_request.RequestMethod.POST,
        url=endpoint_url,
        body_parameters=request_body,
    )
    response = request_definition.get_data()
    raw = response.data.raw
    return parse_lseg_surface_response(raw, valuation_date=valuation_date, surface_tag=tag, underlying_ric=underlying_ric)


def get_or_fetch_surface(
    underlying_ric: str,
    valuation_date: Union[str, pd.Timestamp],
    cache_dir: Union[str, Path] = "iv_surface_cache",
    force: bool = False,
    **fetch_kwargs,
) -> IVSurface:
    path = surface_cache_path(cache_dir, underlying_ric, valuation_date)
    if path.exists() and not force:
        return IVSurface.from_csv(path)
    surf = fetch_lseg_iv_surface_endpoint(underlying_ric, valuation_date, **fetch_kwargs)
    surf.to_csv(path)
    return surf


def build_surface_cache(
    dates: Iterable[Union[str, pd.Timestamp]],
    underlying_ric: str,
    cache_dir: Union[str, Path] = "iv_surface_cache",
    force: bool = False,
    sleep_seconds: float = 0.10,
    **fetch_kwargs,
) -> Dict[pd.Timestamp, IVSurface]:
    """Fetch/cache daily IV surfaces. Returns dict keyed by normalized date."""
    surfaces: Dict[pd.Timestamp, IVSurface] = {}
    for d in dates:
        dt = pd.Timestamp(d).normalize()
        try:
            surf = get_or_fetch_surface(underlying_ric, dt, cache_dir=cache_dir, force=force, **fetch_kwargs)
            surfaces[dt] = surf
        except Exception as exc:  # pragma: no cover - depends on LSEG service
            print(f"[WARN] surface unavailable for {dt.date()}: {exc}")
        if sleep_seconds > 0:
            time.sleep(sleep_seconds)
    return surfaces


def load_surface_cache(
    dates: Iterable[Union[str, pd.Timestamp]],
    underlying_ric: str,
    cache_dir: Union[str, Path] = "iv_surface_cache",
    allow_previous: bool = True,
) -> Dict[pd.Timestamp, IVSurface]:
    """Load cached surfaces, optionally carrying forward the most recent available surface."""
    surfaces: Dict[pd.Timestamp, IVSurface] = {}
    last: Optional[IVSurface] = None
    for d in dates:
        dt = pd.Timestamp(d).normalize()
        path = surface_cache_path(cache_dir, underlying_ric, dt)
        if path.exists():
            last = IVSurface.from_csv(path)
            # Use requested date for valuation date in carried cache only if same date.
            last.valuation_date = dt
            surfaces[dt] = last
        elif allow_previous and last is not None:
            surfaces[dt] = last
    return surfaces


# -----------------------------------------------------------------------------
# Portfolio and beta helpers
# -----------------------------------------------------------------------------


def build_portfolio_nav(prices: pd.DataFrame, weights: Dict[str, float], initial_nav: float = 100.0) -> pd.Series:
    px = prices.copy().ffill().dropna(how="all")
    w = pd.Series(weights, dtype=float).reindex(px.columns).fillna(0.0)
    if abs(w.sum()) < 1e-12:
        raise ValueError("portfolio weights sum to zero")
    w = w / w.sum()
    rets = px.pct_change().fillna(0.0)
    port_rets = (rets * w).sum(axis=1)
    nav = initial_nav * (1.0 + port_rets).cumprod()
    nav.name = "portfolio_nav"
    return nav


def compute_rolling_beta(
    portfolio_nav: pd.Series,
    underlying_spot: pd.Series,
    lookback: int = 252,
    beta_floor: float = 0.0,
    beta_cap: float = 2.0,
) -> pd.Series:
    pr = portfolio_nav.pct_change()
    sr = underlying_spot.pct_change()
    cov = pr.rolling(lookback, min_periods=max(20, lookback // 4)).cov(sr)
    var = sr.rolling(lookback, min_periods=max(20, lookback // 4)).var()
    beta = cov / var
    beta = beta.replace([np.inf, -np.inf], np.nan).fillna(1.0).clip(beta_floor, beta_cap)
    beta.name = "rolling_beta"
    return beta


def constant_rate_series(index: pd.Index, value: float) -> pd.Series:
    return pd.Series(float(value), index=pd.to_datetime(index))


def align_inputs(
    portfolio_nav: pd.Series,
    underlying_spot: pd.Series,
    beta: Optional[pd.Series] = None,
) -> pd.DataFrame:
    df = pd.DataFrame({
        "B": portfolio_nav.astype(float),
        "S": underlying_spot.astype(float),
    }).dropna()
    if beta is not None:
        df["beta"] = beta.reindex(df.index).ffill().fillna(1.0)
    else:
        df["beta"] = 1.0
    return df


# -----------------------------------------------------------------------------
# Strategy configs and result containers
# -----------------------------------------------------------------------------

@dataclass
class PutStrategyConfig:
    target_moneyness: float = 0.95
    target_maturity_years: float = 0.25
    roll_days_before_expiry: int = 21
    hedge_ratio: float = 1.0
    notional_mode: str = "spot"  # spot or strike
    use_beta_notional: bool = True
    rate: float = 0.02
    dividend_yield: float = 0.00
    cash_rate: float = 0.02
    funding_rate: float = 0.02
    borrow_rate: float = 0.00
    option_tc_bps: float = 0.0
    underlying_tc_bps: float = 0.0
    short_cap_multiple_nav: Optional[float] = 2.0
    iv_clamp: bool = True
    tau_basis_days: float = 365.25


@dataclass
class OptionState:
    active: bool = False
    n: float = 0.0
    strike: float = np.nan
    expiry_date: Optional[pd.Timestamp] = None
    entry_date: Optional[pd.Timestamp] = None
    entry_iv: float = np.nan
    entry_price: float = np.nan
    entry_delta: float = np.nan


@dataclass
class ReplicationState:
    active: bool = False
    n: float = 0.0
    strike: float = np.nan
    expiry_date: Optional[pd.Timestamp] = None
    entry_date: Optional[pd.Timestamp] = None
    entry_iv: float = np.nan
    entry_price: float = np.nan
    Q: float = 0.0  # underlying units; negative for put replication
    A: float = 0.0  # cash account backing the synthetic sleeve
    F: float = 0.0  # financing liability; negative at inception
    realized_overlay_pnl: float = 0.0


# -----------------------------------------------------------------------------
# Strategy internals
# -----------------------------------------------------------------------------


def remaining_tau(current_date: pd.Timestamp, expiry_date: Optional[pd.Timestamp], basis_days: float = 365.25) -> float:
    if expiry_date is None:
        return 0.0
    return max((pd.Timestamp(expiry_date).normalize() - pd.Timestamp(current_date).normalize()).days / basis_days, 0.0)


def remaining_business_days(current_date: pd.Timestamp, expiry_date: Optional[pd.Timestamp]) -> int:
    if expiry_date is None:
        return 0
    start = pd.Timestamp(current_date).normalize().date()
    end = pd.Timestamp(expiry_date).normalize().date()
    if end <= start:
        return 0
    return int(np.busday_count(start, end))


def choose_new_option(
    date: pd.Timestamp,
    B: float,
    S: float,
    beta: float,
    surface: IVSurface,
    cfg: PutStrategyConfig,
) -> Tuple[OptionState, Dict[str, float]]:
    strike = cfg.target_moneyness * S
    expiry_date = pd.Timestamp(date).normalize() + pd.Timedelta(days=int(round(cfg.target_maturity_years * cfg.tau_basis_days)))
    tau = remaining_tau(date, expiry_date, cfg.tau_basis_days)
    mny = strike / S
    iv = surface.interpolate_iv(mny, tau, clamp=cfg.iv_clamp)
    greeks = bsm_put(S, strike, tau, cfg.rate, cfg.dividend_yield, iv)

    hedge_notional = cfg.hedge_ratio * (beta if cfg.use_beta_notional else 1.0) * B
    if cfg.notional_mode.lower() == "strike":
        n = hedge_notional / strike
    else:
        n = hedge_notional / S

    state = OptionState(
        active=True,
        n=float(n),
        strike=float(strike),
        expiry_date=expiry_date,
        entry_date=pd.Timestamp(date).normalize(),
        entry_iv=float(iv),
        entry_price=float(greeks["price"]),
        entry_delta=float(greeks["delta"]),
    )
    return state, greeks


def value_option_state(
    state: OptionState,
    date: pd.Timestamp,
    S: float,
    surface: IVSurface,
    cfg: PutStrategyConfig,
    vol_override: Optional[float] = None,
) -> Dict[str, float]:
    tau = remaining_tau(date, state.expiry_date, cfg.tau_basis_days)
    if tau <= 1e-10:
        iv = state.entry_iv if np.isfinite(state.entry_iv) else 0.20
    else:
        mny = state.strike / S
        iv = float(vol_override) if vol_override is not None else surface.interpolate_iv(mny, tau, clamp=cfg.iv_clamp)
    greeks = bsm_put(S, state.strike, tau, cfg.rate, cfg.dividend_yield, iv)
    greeks.update({"tau": tau, "iv": iv, "moneyness": state.strike / S})
    return greeks


def should_roll(state: OptionState, date: pd.Timestamp, cfg: PutStrategyConfig) -> bool:
    if not state.active or state.expiry_date is None:
        return True
    return remaining_business_days(date, state.expiry_date) <= cfg.roll_days_before_expiry


# -----------------------------------------------------------------------------
# Long put overlay
# -----------------------------------------------------------------------------


def backtest_long_put_overlay(
    portfolio_nav: pd.Series,
    underlying_spot: pd.Series,
    surfaces: Dict[pd.Timestamp, IVSurface],
    cfg: PutStrategyConfig,
    beta: Optional[pd.Series] = None,
) -> pd.DataFrame:
    """Backtest rolling long put overlay using daily IV-surface MTM.

    The option premium is funded from an overlay cash account. Hedged NAV is:
        portfolio NAV + option cash + option MTM
    At inception, cash decreases by premium and option asset increases by the same amount.
    """
    df = align_inputs(portfolio_nav, underlying_spot, beta)
    dates = list(df.index)
    state = OptionState()
    cash = 0.0
    rows = []
    prev_date: Optional[pd.Timestamp] = None

    for date in dates:
        date = pd.Timestamp(date).normalize()
        if date not in surfaces:
            # Use previous surface if the dict was built with carry-forward; otherwise skip.
            continue
        surf = surfaces[date]
        B = float(df.loc[date, "B"])
        S = float(df.loc[date, "S"])
        beta_t = float(df.loc[date, "beta"])

        # Cash accrual from previous date to current date.
        if prev_date is not None:
            dt = max((date - prev_date).days / cfg.tau_basis_days, 0.0)
            cash *= (1.0 + cfg.cash_rate * dt)

        roll_flag = False
        premium_paid = 0.0
        premium_received = 0.0
        option_tc = 0.0

        # Value existing option, then roll if needed.
        if state.active:
            old_val = value_option_state(state, date, S, surf, cfg)
            if should_roll(state, date, cfg):
                premium_received = state.n * old_val["price"]
                sell_tc = abs(premium_received) * cfg.option_tc_bps / 10000.0
                cash += premium_received - sell_tc
                option_tc += sell_tc
                state = OptionState()
                roll_flag = True

        if not state.active:
            state, entry_val = choose_new_option(date, B, S, beta_t, surf, cfg)
            premium_paid = state.n * entry_val["price"]
            buy_tc = abs(premium_paid) * cfg.option_tc_bps / 10000.0
            cash -= premium_paid + buy_tc
            option_tc += buy_tc
            roll_flag = True

        val = value_option_state(state, date, S, surf, cfg)
        option_mtm = state.n * val["price"]
        hedged_nav = B + cash + option_mtm

        rows.append({
            "date": date,
            "portfolio_nav": B,
            "underlying_spot": S,
            "beta": beta_t,
            "hedged_nav": hedged_nav,
            "overlay_cash": cash,
            "option_mtm": option_mtm,
            "option_price": val["price"],
            "option_units": state.n,
            "strike": state.strike,
            "expiry_date": state.expiry_date,
            "tau": val["tau"],
            "moneyness": val["moneyness"],
            "iv": val["iv"],
            "delta": val["delta"],
            "gamma": val["gamma"],
            "vega": val["vega"],
            "theta": val["theta"],
            "cash_plus_option": cash + option_mtm,
            "relative_payoff": hedged_nav / B - 1.0 if B != 0 else np.nan,
            "roll_flag": roll_flag,
            "premium_paid": premium_paid,
            "premium_received": premium_received,
            "option_transaction_cost": option_tc,
        })
        prev_date = date

    out = pd.DataFrame(rows).set_index("date")
    out["strategy_return"] = out["hedged_nav"].pct_change().fillna(0.0)
    out["base_return"] = out["portfolio_nav"].pct_change().fillna(0.0)
    out["excess_return"] = out["strategy_return"] - out["base_return"]
    return out


# -----------------------------------------------------------------------------
# Delta-replicated long put
# -----------------------------------------------------------------------------


def choose_new_replication_state(
    date: pd.Timestamp,
    B: float,
    S: float,
    beta: float,
    surface: IVSurface,
    cfg: PutStrategyConfig,
    delta_vol_mode: str = "time_varying",
    constant_delta_vol: float = 0.20,
) -> Tuple[ReplicationState, Dict[str, float]]:
    opt_state, market_val = choose_new_option(date, B, S, beta, surface, cfg)
    if delta_vol_mode == "fixed_entry":
        delta_vol = opt_state.entry_iv
    elif delta_vol_mode == "constant":
        delta_vol = constant_delta_vol
    else:
        delta_vol = market_val["iv"] if "iv" in market_val else opt_state.entry_iv
    # choose_new_option returns greeks without iv/tau keys, so recompute with explicit tau/vol.
    tau = remaining_tau(date, opt_state.expiry_date, cfg.tau_basis_days)
    greeks = bsm_put(S, opt_state.strike, tau, cfg.rate, cfg.dividend_yield, delta_vol)
    P_market = market_val["price"]
    Q = opt_state.n * greeks["delta"]
    if cfg.short_cap_multiple_nav is not None:
        short_cap_units = cfg.short_cap_multiple_nav * B / S
        Q = max(Q, -short_cap_units)
    A = opt_state.n * P_market - Q * S
    F = -opt_state.n * P_market
    state = ReplicationState(
        active=True,
        n=opt_state.n,
        strike=opt_state.strike,
        expiry_date=opt_state.expiry_date,
        entry_date=opt_state.entry_date,
        entry_iv=opt_state.entry_iv,
        entry_price=opt_state.entry_price,
        Q=float(Q),
        A=float(A),
        F=float(F),
        realized_overlay_pnl=0.0,
    )
    return state, greeks


def replication_target_delta(
    state: ReplicationState,
    date: pd.Timestamp,
    S: float,
    surface: IVSurface,
    cfg: PutStrategyConfig,
    delta_vol_mode: str,
    constant_delta_vol: float,
) -> Dict[str, float]:
    tau = remaining_tau(date, state.expiry_date, cfg.tau_basis_days)
    if delta_vol_mode == "fixed_entry":
        iv = state.entry_iv
    elif delta_vol_mode == "constant":
        iv = constant_delta_vol
    else:
        iv = surface.interpolate_iv(state.strike / S, tau, clamp=cfg.iv_clamp) if tau > 0 else state.entry_iv
    greeks = bsm_put(S, state.strike, tau, cfg.rate, cfg.dividend_yield, iv)
    greeks.update({"tau": tau, "iv_for_delta": iv, "moneyness": state.strike / S})
    return greeks


def backtest_delta_replicated_put(
    portfolio_nav: pd.Series,
    underlying_spot: pd.Series,
    surfaces: Dict[pd.Timestamp, IVSurface],
    cfg: PutStrategyConfig,
    beta: Optional[pd.Series] = None,
    delta_vol_mode: str = "time_varying",
    constant_delta_vol: float = 0.20,
) -> pd.DataFrame:
    """Backtest a financed delta-replicated long put strategy.

    It does not hold the option. It holds Q units of the underlying and A cash, plus a
    financing liability F that offsets the initial synthetic put value. Hedged NAV is:
        portfolio NAV + realized_overlay_pnl + Q*S + A + F
    """
    df = align_inputs(portfolio_nav, underlying_spot, beta)
    dates = list(df.index)
    state = ReplicationState()
    rows = []
    prev_date: Optional[pd.Timestamp] = None

    for date in dates:
        date = pd.Timestamp(date).normalize()
        if date not in surfaces:
            continue
        surf = surfaces[date]
        B = float(df.loc[date, "B"])
        S = float(df.loc[date, "S"])
        beta_t = float(df.loc[date, "beta"])

        if prev_date is not None and state.active:
            dt = max((date - prev_date).days / cfg.tau_basis_days, 0.0)
            # Cash accrues; financing liability accrues; short borrow/dividend costs reduce A.
            state.A *= (1.0 + cfg.cash_rate * dt)
            state.F *= (1.0 + cfg.funding_rate * dt)
            short_notional = max(-state.Q, 0.0) * S
            state.A -= short_notional * (cfg.borrow_rate + cfg.dividend_yield) * dt

        roll_flag = False
        underlying_tc = 0.0
        closed_overlay_pnl = 0.0

        # Roll if needed. Close old synthetic sleeve at current spot.
        active_as_option = OptionState(
            active=state.active,
            n=state.n,
            strike=state.strike,
            expiry_date=state.expiry_date,
            entry_date=state.entry_date,
            entry_iv=state.entry_iv,
            entry_price=state.entry_price,
        )
        if state.active and should_roll(active_as_option, date, cfg):
            close_trade_tc = abs(state.Q * S) * cfg.underlying_tc_bps / 10000.0
            X_close = state.Q * S + state.A - close_trade_tc
            closed_overlay_pnl = X_close + state.F
            realized = state.realized_overlay_pnl + closed_overlay_pnl
            state = ReplicationState(realized_overlay_pnl=realized)
            underlying_tc += close_trade_tc
            roll_flag = True

        if not state.active:
            realized = state.realized_overlay_pnl
            state, entry_delta_val = choose_new_replication_state(
                date, B, S, beta_t, surf, cfg,
                delta_vol_mode=delta_vol_mode,
                constant_delta_vol=constant_delta_vol,
            )
            state.realized_overlay_pnl = realized
            open_trade_tc = abs(state.Q * S) * cfg.underlying_tc_bps / 10000.0
            state.A -= open_trade_tc
            underlying_tc += open_trade_tc
            roll_flag = True

        # Market put value for diagnostic replication error.
        opt_state = OptionState(
            active=True,
            n=state.n,
            strike=state.strike,
            expiry_date=state.expiry_date,
            entry_date=state.entry_date,
            entry_iv=state.entry_iv,
            entry_price=state.entry_price,
        )
        market_val = value_option_state(opt_state, date, S, surf, cfg)
        target = replication_target_delta(
            state, date, S, surf, cfg,
            delta_vol_mode=delta_vol_mode,
            constant_delta_vol=constant_delta_vol,
        )
        Q_target = state.n * target["delta"]
        if cfg.short_cap_multiple_nav is not None:
            short_cap_units = cfg.short_cap_multiple_nav * B / S
            Q_target = max(Q_target, -short_cap_units)
        dQ = Q_target - state.Q
        trade_tc = abs(dQ * S) * cfg.underlying_tc_bps / 10000.0
        state.A -= dQ * S + trade_tc
        underlying_tc += trade_tc
        state.Q = float(Q_target)

        X = state.Q * S + state.A
        overlay_value = state.realized_overlay_pnl + X + state.F
        hedged_nav = B + overlay_value
        market_put_mtm = state.n * market_val["price"]
        replication_error = X - market_put_mtm

        rows.append({
            "date": date,
            "portfolio_nav": B,
            "underlying_spot": S,
            "beta": beta_t,
            "hedged_nav": hedged_nav,
            "overlay_value": overlay_value,
            "realized_overlay_pnl": state.realized_overlay_pnl,
            "synthetic_sleeve_value": X,
            "financing_liability": state.F,
            "cash_A": state.A,
            "underlying_units_Q": state.Q,
            "underlying_notional_QS": state.Q * S,
            "market_put_mtm": market_put_mtm,
            "replication_error": replication_error,
            "option_units": state.n,
            "strike": state.strike,
            "expiry_date": state.expiry_date,
            "tau": market_val["tau"],
            "moneyness": market_val["moneyness"],
            "market_iv": market_val["iv"],
            "iv_for_delta": target["iv_for_delta"],
            "market_put_price": market_val["price"],
            "target_delta": target["delta"],
            "market_delta": market_val["delta"],
            "market_gamma": market_val["gamma"],
            "market_vega": market_val["vega"],
            "market_theta": market_val["theta"],
            "relative_payoff": hedged_nav / B - 1.0 if B != 0 else np.nan,
            "roll_flag": roll_flag,
            "closed_overlay_pnl": closed_overlay_pnl,
            "underlying_transaction_cost": underlying_tc,
        })
        prev_date = date

    out = pd.DataFrame(rows).set_index("date")
    out["strategy_return"] = out["hedged_nav"].pct_change().fillna(0.0)
    out["base_return"] = out["portfolio_nav"].pct_change().fillna(0.0)
    out["excess_return"] = out["strategy_return"] - out["base_return"]
    return out


# -----------------------------------------------------------------------------
# Drawdown episode and metrics
# -----------------------------------------------------------------------------


def extract_drawdown_episodes(nav: pd.Series, min_loss: float = 0.02, require_recovery: bool = False) -> pd.DataFrame:
    """Extract non-overlapping drawdown episodes from an unhedged NAV series.

    Episode starts at a high-water mark, trough is minimum before recovery, and recovery is
    first date NAV reaches previous peak. If require_recovery=False, an unrecovered final
    drawdown is included with recovery_date = last date.
    """
    s = nav.dropna().astype(float)
    dates = list(s.index)
    episodes = []
    i = 0
    n = len(s)
    while i < n - 1:
        peak_idx = i
        peak_val = s.iloc[peak_idx]
        # Move to next new high-water mark while no drawdown.
        if s.iloc[i + 1] >= peak_val:
            i += 1
            continue
        # We are entering a drawdown from peak_idx.
        j = i + 1
        trough_idx = j
        trough_val = s.iloc[j]
        recovery_idx = None
        while j < n:
            val = s.iloc[j]
            if val < trough_val:
                trough_val = val
                trough_idx = j
            if val >= peak_val:
                recovery_idx = j
                break
            j += 1
        if recovery_idx is None:
            if require_recovery:
                break
            recovery_idx = n - 1
        loss = 1.0 - trough_val / peak_val
        if loss >= min_loss:
            episodes.append({
                "episode_id": len(episodes) + 1,
                "peak_date": dates[peak_idx],
                "trough_date": dates[trough_idx],
                "recovery_date": dates[recovery_idx],
                "loss": loss,
                "pt_duration_days": int(np.busday_count(pd.Timestamp(dates[peak_idx]).date(), pd.Timestamp(dates[trough_idx]).date())),
                "pr_duration_days": int(np.busday_count(pd.Timestamp(dates[peak_idx]).date(), pd.Timestamp(dates[recovery_idx]).date())),
                "recovered": bool(s.iloc[recovery_idx] >= peak_val),
            })
        i = recovery_idx if recovery_idx > peak_idx else peak_idx + 1
    return pd.DataFrame(episodes)


def episode_payoff_table(
    base_nav: pd.Series,
    strategy_navs: Dict[str, pd.Series],
    episodes: pd.DataFrame,
) -> pd.DataFrame:
    rows = []
    base = base_nav.dropna()
    for _, ep in episodes.iterrows():
        p = pd.Timestamp(ep["peak_date"])
        q = pd.Timestamp(ep["trough_date"])
        r = pd.Timestamp(ep["recovery_date"])
        if p not in base.index or q not in base.index or r not in base.index:
            continue
        Bp, Bq, Br = float(base.loc[p]), float(base.loc[q]), float(base.loc[r])
        base_trough_ret = Bq / Bp - 1.0
        base_recovery_ret = Br / Bp - 1.0
        for name, nav in strategy_navs.items():
            s = nav.dropna()
            if p not in s.index or q not in s.index or r not in s.index:
                continue
            Vp, Vq, Vr = float(s.loc[p]), float(s.loc[q]), float(s.loc[r])
            strat_trough_ret = Vq / Vp - 1.0
            strat_recovery_ret = Vr / Vp - 1.0
            rows.append({
                "episode_id": ep["episode_id"],
                "strategy": name,
                "peak_date": p,
                "trough_date": q,
                "recovery_date": r,
                "loss": ep["loss"],
                "pt_duration_days": ep["pt_duration_days"],
                "pr_duration_days": ep["pr_duration_days"],
                "base_trough_return": base_trough_ret,
                "strategy_trough_return": strat_trough_ret,
                "trough_payoff": strat_trough_ret - base_trough_ret,
                "base_recovery_return": base_recovery_ret,
                "strategy_recovery_return": strat_recovery_ret,
                "recovery_payoff": strat_recovery_ret - base_recovery_ret,
            })
    return pd.DataFrame(rows)


def performance_summary(nav_df: pd.DataFrame, periods_per_year: int = 252) -> pd.DataFrame:
    rows = []
    for col in nav_df.columns:
        s = nav_df[col].dropna()
        if len(s) < 2:
            continue
        r = s.pct_change().dropna()
        years = len(r) / periods_per_year
        cagr = (s.iloc[-1] / s.iloc[0]) ** (1.0 / years) - 1.0 if years > 0 else np.nan
        vol = r.std() * math.sqrt(periods_per_year)
        sharpe = r.mean() / r.std() * math.sqrt(periods_per_year) if r.std() > 0 else np.nan
        dd = s / s.cummax() - 1.0
        rows.append({
            "strategy": col,
            "start_nav": s.iloc[0],
            "end_nav": s.iloc[-1],
            "CAGR": cagr,
            "AnnVol": vol,
            "Sharpe": sharpe,
            "MaxDD": dd.min(),
            "Worst1D": r.min(),
        })
    return pd.DataFrame(rows).set_index("strategy")
