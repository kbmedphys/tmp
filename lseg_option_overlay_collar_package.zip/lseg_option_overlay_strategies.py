"""
General LSEG IV-surface option overlay engine.

Adds long put, collar, delta-replicated long put, and delta-replicated collar support
on top of the helper functions in lseg_put_strategies.py.

Key design choices
------------------
1. The option overlay engine is leg based:
       OptionLegConfig -> OptionLegState -> daily leg-level and strategy-level outputs.
2. Long/short option overlay accounting uses a cash account:
       hedged NAV = base NAV + option cash + signed option MTM.
   Premium cash flows are booked in cash; option MTM is booked as an asset/liability.
3. Delta-replicated overlays do not hold options. They use the option portfolio's net
   Black-Scholes delta to trade the underlying and cash with a financing account.
4. IV interpolation supports PCHIP smile interpolation on total variance and linear
   total-variance interpolation across tenor.
5. The module is intentionally dependency-light. scipy is used for PCHIP when available;
   otherwise the code falls back to linear interpolation.

This module does not require lseg-data unless you call fetch functions from
lseg_put_strategies.py.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd

try:  # Optional; fallback to linear interpolation if unavailable.
    from scipy.interpolate import PchipInterpolator  # type: ignore
    SCIPY_AVAILABLE = True
except Exception:  # pragma: no cover
    PchipInterpolator = None  # type: ignore
    SCIPY_AVAILABLE = False

from lseg_put_strategies import (  # noqa: F401
    IVSurface,
    build_portfolio_nav,
    build_surface_cache,
    close_lseg_session,
    compute_rolling_beta,
    extract_drawdown_episodes,
    fetch_lseg_iv_surface_endpoint,
    fetch_lseg_price_history,
    get_or_fetch_surface,
    load_surface_cache,
    norm_cdf,
    norm_pdf,
    open_lseg_session,
    performance_summary,
)


# -----------------------------------------------------------------------------
# Black-Scholes-Merton for calls and puts
# -----------------------------------------------------------------------------


def bsm_option(
    option_type: str,
    spot: float,
    strike: float,
    tau: float,
    rate: float = 0.0,
    div_yield: float = 0.0,
    vol: float = 0.20,
) -> Dict[str, float]:
    """European option price and greeks under Black-Scholes-Merton.

    Parameters
    ----------
    option_type:
        "put" or "call".
    spot, strike:
        Positive prices.
    tau:
        Time to expiry in years.
    rate, div_yield:
        Continuously compounded risk-free and dividend yields.
    vol:
        Decimal volatility, e.g. 0.20.

    Returns
    -------
    dict with price, delta, gamma, vega, theta, d1, d2.
    Vega is per 1.00 volatility point; multiply by 0.01 for one vol point.
    Theta is per year.
    """
    opt = option_type.lower().strip()
    if opt not in {"put", "call"}:
        raise ValueError("option_type must be 'put' or 'call'")

    S = float(spot)
    K = float(strike)
    T = max(float(tau), 0.0)
    r = float(rate)
    q = float(div_yield)
    sigma = max(float(vol), 1e-12)

    if S <= 0 or K <= 0:
        raise ValueError("spot and strike must be positive")

    if T <= 1e-10:
        if opt == "put":
            intrinsic = max(K - S, 0.0)
            delta = -1.0 if S < K else (0.0 if S > K else -0.5)
        else:
            intrinsic = max(S - K, 0.0)
            delta = 1.0 if S > K else (0.0 if S < K else 0.5)
        return {
            "price": float(intrinsic),
            "delta": float(delta),
            "gamma": 0.0,
            "vega": 0.0,
            "theta": 0.0,
            "d1": np.nan,
            "d2": np.nan,
        }

    sqrtT = math.sqrt(T)
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma * sigma) * T) / (sigma * sqrtT)
    d2 = d1 - sigma * sqrtT
    disc_r = math.exp(-r * T)
    disc_q = math.exp(-q * T)
    phi_d1 = norm_pdf(d1)

    if opt == "call":
        price = S * disc_q * norm_cdf(d1) - K * disc_r * norm_cdf(d2)
        delta = disc_q * norm_cdf(d1)
        theta = (
            -S * disc_q * phi_d1 * sigma / (2.0 * sqrtT)
            - r * K * disc_r * norm_cdf(d2)
            + q * S * disc_q * norm_cdf(d1)
        )
    else:
        price = K * disc_r * norm_cdf(-d2) - S * disc_q * norm_cdf(-d1)
        delta = disc_q * (norm_cdf(d1) - 1.0)
        theta = (
            -S * disc_q * phi_d1 * sigma / (2.0 * sqrtT)
            + q * S * disc_q * norm_cdf(-d1)
            - r * K * disc_r * norm_cdf(-d2)
        )

    gamma = disc_q * phi_d1 / (S * sigma * sqrtT)
    vega = S * disc_q * phi_d1 * sqrtT

    return {
        "price": float(price),
        "delta": float(delta),
        "gamma": float(gamma),
        "vega": float(vega),
        "theta": float(theta),
        "d1": float(d1),
        "d2": float(d2),
    }


# -----------------------------------------------------------------------------
# Surface interpolation
# -----------------------------------------------------------------------------


@dataclass
class IVInterpolationConfig:
    """Configuration for IV surface interpolation.

    The source LSEG surface is typically a tau x moneyness grid.  The grid moneyness
    can be interpreted as spot moneyness or forward moneyness via surface_moneyness_type.
    """

    coordinate: str = "log_forward_moneyness"  # log_forward_moneyness, forward_moneyness, spot_moneyness, log_spot_moneyness
    surface_moneyness_type: str = "forward"  # forward or spot
    smile_method: str = "pchip"  # pchip or linear
    tenor_method: str = "total_variance"  # total_variance only for now
    extrapolation: str = "clamp"  # clamp or error
    min_iv: float = 1e-4
    max_iv: float = 5.0
    stale_surface_days: int = 5


@dataclass
class IVResult:
    iv: float
    iv_pct: float
    method: str
    coordinate: str
    target_coord: float
    target_tau: float
    bracketing_tenors: Tuple[float, float]
    extrapolated: bool
    stale_surface: bool
    warnings: List[str] = field(default_factory=list)


@dataclass
class SurfaceSnapshot:
    """Thin wrapper around IVSurface with improved interpolation."""

    surface: IVSurface
    interpolation_config: IVInterpolationConfig = field(default_factory=IVInterpolationConfig)

    def interpolate_iv(
        self,
        spot: float,
        strike: float,
        tau: float,
        rate: float = 0.0,
        div_yield: float = 0.0,
        valuation_date: Optional[pd.Timestamp] = None,
    ) -> IVResult:
        return interpolate_surface_iv(
            self.surface,
            spot=spot,
            strike=strike,
            tau=tau,
            rate=rate,
            div_yield=div_yield,
            cfg=self.interpolation_config,
            valuation_date=valuation_date,
        )


class SurfaceProvider:
    """Base interface for surface providers."""

    def get_surface(self, date: Union[str, pd.Timestamp], underlying: str = "") -> SurfaceSnapshot:
        raise NotImplementedError


class DictSurfaceProvider(SurfaceProvider):
    """Surface provider backed by a dictionary of IVSurface objects."""

    def __init__(
        self,
        surfaces: Dict[pd.Timestamp, IVSurface],
        interpolation_config: Optional[IVInterpolationConfig] = None,
        allow_previous: bool = True,
    ) -> None:
        self.surfaces = {pd.Timestamp(k).normalize(): v for k, v in surfaces.items()}
        self.interpolation_config = interpolation_config or IVInterpolationConfig()
        self.allow_previous = allow_previous
        self._sorted_dates = sorted(self.surfaces.keys())

    def get_surface(self, date: Union[str, pd.Timestamp], underlying: str = "") -> SurfaceSnapshot:
        dt = pd.Timestamp(date).normalize()
        if dt in self.surfaces:
            return SurfaceSnapshot(self.surfaces[dt], self.interpolation_config)
        if not self.allow_previous:
            raise KeyError(f"No IV surface for {dt.date()}")
        prev = [d for d in self._sorted_dates if d <= dt]
        if not prev:
            raise KeyError(f"No current or previous IV surface for {dt.date()}")
        return SurfaceSnapshot(self.surfaces[prev[-1]], self.interpolation_config)


def _dedupe_sorted_xy(x: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    mask = np.isfinite(x) & np.isfinite(y)
    x = np.asarray(x[mask], dtype=float)
    y = np.asarray(y[mask], dtype=float)
    if len(x) == 0:
        return x, y
    order = np.argsort(x)
    x = x[order]
    y = y[order]
    # Aggregate duplicate x by mean y.
    ux, inv = np.unique(x, return_inverse=True)
    if len(ux) != len(x):
        yy = np.zeros(len(ux))
        cc = np.zeros(len(ux))
        for i, j in enumerate(inv):
            yy[j] += y[i]
            cc[j] += 1.0
        y = yy / np.maximum(cc, 1.0)
        x = ux
    return x, y


def _target_coord(
    spot: float,
    strike: float,
    tau: float,
    rate: float,
    div_yield: float,
    cfg: IVInterpolationConfig,
) -> float:
    mode = cfg.coordinate.lower()
    S = float(spot)
    K = float(strike)
    F = S * math.exp((float(rate) - float(div_yield)) * max(float(tau), 0.0))
    if mode == "spot_moneyness":
        return K / S
    if mode == "log_spot_moneyness":
        return math.log(K / S)
    if mode == "forward_moneyness":
        return K / F
    if mode == "log_forward_moneyness":
        return math.log(K / F)
    raise ValueError(f"Unknown coordinate mode: {cfg.coordinate}")


def _grid_coords_for_tau(
    moneyness_grid: np.ndarray,
    tau_row: float,
    rate: float,
    div_yield: float,
    cfg: IVInterpolationConfig,
) -> np.ndarray:
    """Transform grid moneyness values to the configured interpolation coordinate.

    If surface_moneyness_type='spot', grid values are K/S.
    If surface_moneyness_type='forward', grid values are K/F(tau_row).
    """
    m = np.asarray(moneyness_grid, dtype=float)
    surf_type = cfg.surface_moneyness_type.lower()
    mode = cfg.coordinate.lower()
    forward_factor = math.exp((float(rate) - float(div_yield)) * max(float(tau_row), 0.0))

    if surf_type.startswith("spot"):
        spot_m = m
        fwd_m = m / forward_factor
    elif surf_type.startswith("fwd") or surf_type.startswith("forward"):
        fwd_m = m
        spot_m = m * forward_factor
    else:
        raise ValueError("surface_moneyness_type must be 'spot' or 'forward'")

    if mode == "spot_moneyness":
        return spot_m
    if mode == "log_spot_moneyness":
        return np.log(np.maximum(spot_m, 1e-12))
    if mode == "forward_moneyness":
        return fwd_m
    if mode == "log_forward_moneyness":
        return np.log(np.maximum(fwd_m, 1e-12))
    raise ValueError(f"Unknown coordinate mode: {cfg.coordinate}")


def _interp_smile(x: np.ndarray, y: np.ndarray, x0: float, method: str, extrapolation: str) -> Tuple[float, bool, List[str]]:
    warnings: List[str] = []
    x, y = _dedupe_sorted_xy(x, y)
    if len(x) == 0:
        return np.nan, False, ["empty smile after filtering"]
    if len(x) == 1:
        return float(y[0]), True, ["single point smile; using only available value"]

    extrapolated = False
    x_eval = float(x0)
    if x_eval < x[0] or x_eval > x[-1]:
        extrapolated = True
        warnings.append("target coordinate outside smile grid")
        if extrapolation == "error":
            raise ValueError("target coordinate outside smile grid")
        x_eval = min(max(x_eval, x[0]), x[-1])

    if method.lower() == "pchip" and SCIPY_AVAILABLE and len(x) >= 3:
        interpolator = PchipInterpolator(x, y, extrapolate=False)
        val = float(interpolator(x_eval))
        return val, extrapolated, warnings
    if method.lower() == "pchip" and not SCIPY_AVAILABLE:
        warnings.append("scipy not available; fell back to linear interpolation")
    val = float(np.interp(x_eval, x, y))
    return val, extrapolated, warnings


def interpolate_surface_iv(
    surface: IVSurface,
    spot: float,
    strike: float,
    tau: float,
    rate: float = 0.0,
    div_yield: float = 0.0,
    cfg: Optional[IVInterpolationConfig] = None,
    valuation_date: Optional[pd.Timestamp] = None,
) -> IVResult:
    """Interpolate an IV surface at (strike, tau) using PCHIP + total variance.

    The tenor interpolation is done in total variance.  Smile interpolation is done on
    total variance as well.  Surface values are assumed decimal IVs as stored by IVSurface.
    """
    cfg = cfg or IVInterpolationConfig()
    grid = surface.grid.copy()
    if grid.empty:
        raise ValueError("empty IV surface")

    taus_all = np.asarray(grid.index, dtype=float)
    cols = np.asarray(grid.columns, dtype=float)
    target_tau = max(float(tau), 1.0 / 365.25)
    extrapolated = False
    warnings: List[str] = []

    if valuation_date is not None:
        age_days = abs((pd.Timestamp(valuation_date).normalize() - surface.valuation_date).days)
        stale = age_days > cfg.stale_surface_days
    else:
        stale = False

    # Clamp or reject tenor.
    if target_tau < taus_all.min() or target_tau > taus_all.max():
        extrapolated = True
        warnings.append("target tenor outside surface grid")
        if cfg.extrapolation == "error":
            raise ValueError("target tenor outside surface grid")
        target_tau_eval = min(max(target_tau, float(taus_all.min())), float(taus_all.max()))
    else:
        target_tau_eval = target_tau

    target_x = _target_coord(spot, strike, target_tau_eval, rate, div_yield, cfg)

    def smile_total_variance_at_tau(tau_row: float) -> Tuple[float, bool, List[str]]:
        # Select exact row by nearest tau because tau_row comes from grid.
        idx = int(np.argmin(np.abs(taus_all - tau_row)))
        vol_row = np.asarray(grid.iloc[idx], dtype=float)
        vol_row = np.clip(vol_row, cfg.min_iv, cfg.max_iv)
        w_row = vol_row * vol_row * max(float(taus_all[idx]), 1e-12)
        x_grid = _grid_coords_for_tau(cols, float(taus_all[idx]), rate, div_yield, cfg)
        val, ext, warn = _interp_smile(x_grid, w_row, target_x, cfg.smile_method, cfg.extrapolation)
        return val, ext, warn

    # Locate bracketing tenors.
    if target_tau_eval <= taus_all[0]:
        tau0 = tau1 = float(taus_all[0])
        w, ext, warn = smile_total_variance_at_tau(tau0)
        extrapolated = extrapolated or ext
        warnings.extend(warn)
    elif target_tau_eval >= taus_all[-1]:
        tau0 = tau1 = float(taus_all[-1])
        w, ext, warn = smile_total_variance_at_tau(tau0)
        extrapolated = extrapolated or ext
        warnings.extend(warn)
    else:
        hi = int(np.searchsorted(taus_all, target_tau_eval, side="right"))
        lo = hi - 1
        tau0 = float(taus_all[lo])
        tau1 = float(taus_all[hi])
        w0, ext0, warn0 = smile_total_variance_at_tau(tau0)
        w1, ext1, warn1 = smile_total_variance_at_tau(tau1)
        extrapolated = extrapolated or ext0 or ext1
        warnings.extend(warn0)
        warnings.extend(warn1)
        if not np.isfinite(w0) or not np.isfinite(w1):
            w = np.nan
        else:
            weight = (target_tau_eval - tau0) / (tau1 - tau0) if tau1 > tau0 else 0.0
            w = (1.0 - weight) * w0 + weight * w1

    if not np.isfinite(w):
        iv = np.nan
    else:
        iv = math.sqrt(max(w / target_tau_eval, 0.0))
        iv = min(max(iv, cfg.min_iv), cfg.max_iv)

    return IVResult(
        iv=float(iv),
        iv_pct=float(iv * 100.0),
        method=f"{cfg.smile_method}_smile_{cfg.tenor_method}_tenor",
        coordinate=cfg.coordinate,
        target_coord=float(target_x),
        target_tau=float(target_tau),
        bracketing_tenors=(float(tau0), float(tau1)),
        extrapolated=bool(extrapolated),
        stale_surface=bool(stale),
        warnings=list(dict.fromkeys(warnings)),
    )


# -----------------------------------------------------------------------------
# Option leg and overlay configuration
# -----------------------------------------------------------------------------


@dataclass
class OverlayConfig:
    target_maturity_years: float = 0.25
    roll_days_before_expiry: int = 21
    hedge_ratio: float = 1.0
    notional_mode: str = "spot"  # spot or strike
    use_beta_notional: bool = True
    rate: float = 0.02
    dividend_yield: float = 0.00
    cash_rate: float = 0.02
    funding_rate: float = 0.02
    borrow_rate: float = 0.00
    option_tc_bps: float = 0.0
    underlying_tc_bps: float = 0.0
    short_cap_multiple_nav: Optional[float] = 2.0
    tau_basis_days: float = 365.25
    pricing_side: str = "Mid"
    strategy_id: str = "OptionOverlay"


@dataclass
class OptionLegConfig:
    leg_id: str
    option_type: str  # put or call
    position_side: str  # long or short
    target_moneyness: float
    quantity_multiplier: float = 1.0
    strike_rule: str = "fixed_moneyness"  # future: delta_based, zero_cost

    @property
    def sign(self) -> float:
        side = self.position_side.lower().strip()
        if side == "long":
            return 1.0
        if side == "short":
            return -1.0
        raise ValueError("position_side must be 'long' or 'short'")


@dataclass
class OptionLegState:
    config: OptionLegConfig
    active: bool = False
    quantity: float = 0.0
    strike: float = np.nan
    expiry_date: Optional[pd.Timestamp] = None
    entry_date: Optional[pd.Timestamp] = None
    entry_iv: float = np.nan
    entry_price: float = np.nan
    entry_delta: float = np.nan


@dataclass
class LegValuation:
    leg_id: str
    option_type: str
    position_side: str
    sign: float
    quantity: float
    strike: float
    expiry_date: Optional[pd.Timestamp]
    tau: float
    moneyness: float
    forward_moneyness: float
    log_forward_moneyness: float
    iv: float
    iv_pct: float
    iv_method: str
    iv_extrapolated: bool
    stale_surface: bool
    price: float
    delta: float
    gamma: float
    vega: float
    theta: float
    leg_mtm: float
    delta_units: float
    gamma_dollar: float
    vega01: float
    theta_day: float
    warnings: str = ""


# -----------------------------------------------------------------------------
# Leg helpers
# -----------------------------------------------------------------------------


def long_put_leg(moneyness: float = 0.95, leg_id: str = "long_put") -> OptionLegConfig:
    return OptionLegConfig(leg_id=leg_id, option_type="put", position_side="long", target_moneyness=moneyness)


def short_call_leg(moneyness: float = 1.05, leg_id: str = "short_call") -> OptionLegConfig:
    return OptionLegConfig(leg_id=leg_id, option_type="call", position_side="short", target_moneyness=moneyness)


def fixed_moneyness_collar_legs(
    put_moneyness: float = 0.95,
    call_moneyness: float = 1.05,
) -> List[OptionLegConfig]:
    return [long_put_leg(put_moneyness), short_call_leg(call_moneyness)]


def align_inputs(portfolio_nav: pd.Series, underlying_spot: pd.Series, beta: Optional[pd.Series] = None) -> pd.DataFrame:
    df = pd.DataFrame({"B": portfolio_nav.astype(float), "S": underlying_spot.astype(float)}).dropna()
    if beta is None:
        df["beta"] = 1.0
    else:
        df["beta"] = beta.reindex(df.index).ffill().fillna(1.0).astype(float)
    return df


def remaining_tau(current_date: pd.Timestamp, expiry_date: Optional[pd.Timestamp], basis_days: float = 365.25) -> float:
    if expiry_date is None:
        return 0.0
    return max((pd.Timestamp(expiry_date).normalize() - pd.Timestamp(current_date).normalize()).days / basis_days, 0.0)


def remaining_business_days(current_date: pd.Timestamp, expiry_date: Optional[pd.Timestamp]) -> int:
    if expiry_date is None:
        return 0
    start = pd.Timestamp(current_date).normalize().date()
    end = pd.Timestamp(expiry_date).normalize().date()
    if end <= start:
        return 0
    return int(np.busday_count(start, end))


def should_roll_leg(state: OptionLegState, date: pd.Timestamp, cfg: OverlayConfig) -> bool:
    if not state.active or state.expiry_date is None:
        return True
    return remaining_business_days(date, state.expiry_date) <= cfg.roll_days_before_expiry


def should_roll_any(states: Sequence[OptionLegState], date: pd.Timestamp, cfg: OverlayConfig) -> bool:
    return any(should_roll_leg(s, date, cfg) for s in states)


def _expiry_from_target(date: pd.Timestamp, cfg: OverlayConfig) -> pd.Timestamp:
    return pd.Timestamp(date).normalize() + pd.Timedelta(days=int(round(cfg.target_maturity_years * cfg.tau_basis_days)))


def _hedge_notional(B: float, beta: float, cfg: OverlayConfig) -> float:
    beta_adj = beta if cfg.use_beta_notional else 1.0
    return float(cfg.hedge_ratio * beta_adj * B)


def _leg_quantity(B: float, S: float, K: float, beta: float, leg_cfg: OptionLegConfig, cfg: OverlayConfig) -> float:
    H = _hedge_notional(B, beta, cfg) * leg_cfg.quantity_multiplier
    if cfg.notional_mode.lower() == "strike":
        return float(H / K)
    return float(H / S)


def create_leg_state(
    leg_cfg: OptionLegConfig,
    date: pd.Timestamp,
    B: float,
    S: float,
    beta: float,
    surface_snapshot: SurfaceSnapshot,
    cfg: OverlayConfig,
) -> Tuple[OptionLegState, LegValuation]:
    if leg_cfg.strike_rule != "fixed_moneyness":
        raise NotImplementedError("Only fixed_moneyness strike_rule is implemented in this version")
    K = leg_cfg.target_moneyness * S
    expiry = _expiry_from_target(date, cfg)
    tau = remaining_tau(date, expiry, cfg.tau_basis_days)
    iv_result = surface_snapshot.interpolate_iv(S, K, tau, cfg.rate, cfg.dividend_yield, valuation_date=date)
    greeks = bsm_option(leg_cfg.option_type, S, K, tau, cfg.rate, cfg.dividend_yield, iv_result.iv)
    qty = _leg_quantity(B, S, K, beta, leg_cfg, cfg)
    state = OptionLegState(
        config=leg_cfg,
        active=True,
        quantity=qty,
        strike=K,
        expiry_date=expiry,
        entry_date=pd.Timestamp(date).normalize(),
        entry_iv=iv_result.iv,
        entry_price=greeks["price"],
        entry_delta=greeks["delta"],
    )
    val = value_leg_state(state, date, S, surface_snapshot, cfg)
    return state, val


def value_leg_state(
    state: OptionLegState,
    date: pd.Timestamp,
    S: float,
    surface_snapshot: SurfaceSnapshot,
    cfg: OverlayConfig,
    vol_override: Optional[float] = None,
) -> LegValuation:
    tau = remaining_tau(date, state.expiry_date, cfg.tau_basis_days)
    K = float(state.strike)
    if vol_override is None:
        iv_res = surface_snapshot.interpolate_iv(S, K, tau, cfg.rate, cfg.dividend_yield, valuation_date=date)
        iv = iv_res.iv
        iv_pct = iv_res.iv_pct
        method = iv_res.method
        extrapolated = iv_res.extrapolated
        stale = iv_res.stale_surface
        warnings = "; ".join(iv_res.warnings)
    else:
        iv = float(vol_override)
        iv_pct = iv * 100.0
        method = "vol_override"
        extrapolated = False
        stale = False
        warnings = ""
    greeks = bsm_option(state.config.option_type, S, K, tau, cfg.rate, cfg.dividend_yield, iv)
    sign = state.config.sign
    qty = float(state.quantity)
    price = float(greeks["price"])
    F = S * math.exp((cfg.rate - cfg.dividend_yield) * max(tau, 0.0))
    fwd_m = K / F if F > 0 else np.nan
    log_fwd_m = math.log(fwd_m) if fwd_m > 0 else np.nan
    delta_units = sign * qty * greeks["delta"]
    gamma_dollar = sign * qty * greeks["gamma"] * S * S
    vega01 = sign * qty * greeks["vega"] * 0.01
    theta_day = sign * qty * greeks["theta"] / 252.0
    return LegValuation(
        leg_id=state.config.leg_id,
        option_type=state.config.option_type,
        position_side=state.config.position_side,
        sign=sign,
        quantity=qty,
        strike=K,
        expiry_date=state.expiry_date,
        tau=tau,
        moneyness=K / S,
        forward_moneyness=fwd_m,
        log_forward_moneyness=log_fwd_m,
        iv=iv,
        iv_pct=iv_pct,
        iv_method=method,
        iv_extrapolated=extrapolated,
        stale_surface=stale,
        price=price,
        delta=float(greeks["delta"]),
        gamma=float(greeks["gamma"]),
        vega=float(greeks["vega"]),
        theta=float(greeks["theta"]),
        leg_mtm=sign * qty * price,
        delta_units=delta_units,
        gamma_dollar=gamma_dollar,
        vega01=vega01,
        theta_day=theta_day,
        warnings=warnings,
    )


def valuation_to_leg_row(
    val: LegValuation,
    date: pd.Timestamp,
    strategy_id: str,
    B: float,
    S: float,
    hedged_nav: float,
    premium_cf: float = 0.0,
    roll_flag: bool = False,
    trade_flag: str = "hold",
) -> Dict[str, object]:
    denom = hedged_nav if abs(hedged_nav) > 1e-12 else np.nan
    return {
        "date": date,
        "strategy_id": strategy_id,
        "leg_id": val.leg_id,
        "option_type": val.option_type,
        "position_side": val.position_side,
        "sign": val.sign,
        "underlying_spot": S,
        "base_nav": B,
        "strike": val.strike,
        "expiry_date": val.expiry_date,
        "tau": val.tau,
        "moneyness": val.moneyness,
        "forward_moneyness": val.forward_moneyness,
        "log_forward_moneyness": val.log_forward_moneyness,
        "iv": val.iv,
        "iv_pct": val.iv_pct,
        "iv_method": val.iv_method,
        "iv_extrapolated": val.iv_extrapolated,
        "stale_surface": val.stale_surface,
        "price": val.price,
        "delta": val.delta,
        "gamma": val.gamma,
        "vega": val.vega,
        "theta": val.theta,
        "quantity": val.quantity,
        "leg_mtm": val.leg_mtm,
        "leg_delta_units": val.delta_units,
        "leg_gamma_dollar": val.gamma_dollar,
        "leg_vega01": val.vega01,
        "leg_theta_day": val.theta_day,
        "premium_cf": premium_cf,
        "roll_flag": roll_flag,
        "trade_flag": trade_flag,
        "mv_weight": val.leg_mtm / denom,
        "notional_weight": val.sign * val.quantity * S / denom,
        "delta_weight": val.delta_units * S / denom,
        "gamma_weight": val.gamma_dollar / denom,
        "vega01_weight": val.vega01 / denom,
        "theta_weight": val.theta_day / denom,
        "warnings": val.warnings,
    }


# -----------------------------------------------------------------------------
# Actual option overlay engine: long put and collar
# -----------------------------------------------------------------------------


def backtest_option_overlay(
    portfolio_nav: pd.Series,
    underlying_spot: pd.Series,
    surfaces: Union[Dict[pd.Timestamp, IVSurface], SurfaceProvider],
    cfg: OverlayConfig,
    leg_configs: Sequence[OptionLegConfig],
    beta: Optional[pd.Series] = None,
    strategy_id: Optional[str] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Backtest a rolling option overlay with arbitrary long/short call/put legs.

    Returns
    -------
    strategy_df, leg_df
    """
    strategy_id = strategy_id or cfg.strategy_id
    provider = surfaces if isinstance(surfaces, SurfaceProvider) else DictSurfaceProvider(surfaces)
    df = align_inputs(portfolio_nav, underlying_spot, beta)
    states: List[OptionLegState] = []
    cash = 0.0
    strategy_rows: List[Dict[str, object]] = []
    leg_rows: List[Dict[str, object]] = []
    prev_date: Optional[pd.Timestamp] = None

    for idx, row in df.iterrows():
        date = pd.Timestamp(idx).normalize()
        try:
            snap = provider.get_surface(date)
        except Exception as exc:
            # Skip dates without any surface.
            continue
        B = float(row["B"])
        S = float(row["S"])
        beta_t = float(row["beta"])

        if prev_date is not None:
            dt = max((date - prev_date).days / cfg.tau_basis_days, 0.0)
            cash *= (1.0 + cfg.cash_rate * dt)

        roll_flag = False
        option_tc = 0.0
        gross_premium_paid = 0.0
        gross_premium_received = 0.0
        net_premium_cf = 0.0
        trade_flag = "hold"

        # Roll all legs together if any leg is within the roll window.
        if states and should_roll_any(states, date, cfg):
            old_vals = [value_leg_state(s, date, S, snap, cfg) for s in states]
            close_mtm = sum(v.leg_mtm for v in old_vals)
            close_tc = sum(abs(v.quantity * v.price) for v in old_vals) * cfg.option_tc_bps / 10000.0
            cash += close_mtm - close_tc
            option_tc += close_tc
            # Close cash-flow is +leg_mtm; positive for selling long options, negative for buying back shorts.
            net_premium_cf += close_mtm
            states = []
            roll_flag = True
            trade_flag = "roll"

        if not states:
            states = []
            open_vals: List[LegValuation] = []
            for lc in leg_configs:
                st, val = create_leg_state(lc, date, B, S, beta_t, snap, cfg)
                states.append(st)
                open_vals.append(val)
            open_mtm = sum(v.leg_mtm for v in open_vals)
            open_tc = sum(abs(v.quantity * v.price) for v in open_vals) * cfg.option_tc_bps / 10000.0
            cash -= open_mtm + open_tc
            option_tc += open_tc
            net_premium_cf -= open_mtm
            gross_premium_paid += sum(v.quantity * v.price for v in open_vals if v.sign > 0)
            gross_premium_received += sum(v.quantity * v.price for v in open_vals if v.sign < 0)
            roll_flag = True
            trade_flag = "open" if trade_flag == "hold" else "roll"

        vals = [value_leg_state(s, date, S, snap, cfg) for s in states]
        option_mtm_total = sum(v.leg_mtm for v in vals)
        overlay_value = cash + option_mtm_total
        hedged_nav = B + overlay_value
        denom = hedged_nav if abs(hedged_nav) > 1e-12 else np.nan
        hedge_notional = _hedge_notional(B, beta_t, cfg)

        for val in vals:
            leg_rows.append(
                valuation_to_leg_row(
                    val, date=date, strategy_id=strategy_id, B=B, S=S, hedged_nav=hedged_nav,
                    premium_cf=net_premium_cf if len(vals) == 1 else 0.0,
                    roll_flag=roll_flag, trade_flag=trade_flag,
                )
            )

        strategy_rows.append({
            "date": date,
            "strategy_id": strategy_id,
            "base_nav": B,
            "underlying_spot": S,
            "beta": beta_t,
            "hedged_nav": hedged_nav,
            "overlay_value": overlay_value,
            "cash_account": cash,
            "option_mtm_total": option_mtm_total,
            "hedge_notional": hedge_notional,
            "gross_option_notional": sum(abs(v.quantity * S) for v in vals),
            "net_option_mtm_weight": option_mtm_total / denom,
            "overlay_value_weight": overlay_value / denom,
            "net_delta_units": sum(v.delta_units for v in vals),
            "net_delta_weight": sum(v.delta_units for v in vals) * S / denom,
            "net_gamma_weight": sum(v.gamma_dollar for v in vals) / denom,
            "net_vega01_weight": sum(v.vega01 for v in vals) / denom,
            "net_theta_weight": sum(v.theta_day for v in vals) / denom,
            "net_premium_cf": net_premium_cf,
            "gross_premium_paid": gross_premium_paid,
            "gross_premium_received": gross_premium_received,
            "option_transaction_cost": option_tc,
            "roll_flag": roll_flag,
            "num_legs": len(vals),
        })
        prev_date = date

    strategy_df = pd.DataFrame(strategy_rows)
    if not strategy_df.empty:
        strategy_df = strategy_df.set_index("date")
        strategy_df["hedged_return"] = strategy_df["hedged_nav"].pct_change().fillna(0.0)
        strategy_df["base_return"] = strategy_df["base_nav"].pct_change().fillna(0.0)
        strategy_df["overlay_pnl"] = strategy_df["overlay_value"].diff().fillna(0.0)
        strategy_df["overlay_contribution_return"] = strategy_df["overlay_pnl"] / strategy_df["base_nav"].shift(1)
        strategy_df["overlay_notional_return"] = strategy_df["overlay_pnl"] / strategy_df["hedge_notional"].shift(1)
        strategy_df["excess_return"] = strategy_df["hedged_return"] - strategy_df["base_return"]
        strategy_df[["overlay_contribution_return", "overlay_notional_return"]] = strategy_df[
            ["overlay_contribution_return", "overlay_notional_return"]
        ].replace([np.inf, -np.inf], np.nan).fillna(0.0)

    leg_df = pd.DataFrame(leg_rows)
    if not leg_df.empty:
        leg_df = leg_df.set_index("date")
        leg_df["leg_mtm_pnl"] = leg_df.groupby(["strategy_id", "leg_id"])["leg_mtm"].diff().fillna(0.0)
    return strategy_df, leg_df


# -----------------------------------------------------------------------------
# Delta-replicated option overlay engine
# -----------------------------------------------------------------------------


def _accrue_financing(F: float, dt: float, cfg: OverlayConfig) -> float:
    if F >= 0:
        return F * (1.0 + cfg.cash_rate * dt)
    return F * (1.0 + cfg.funding_rate * dt)


def _delta_vol_for_leg(
    state: OptionLegState,
    date: pd.Timestamp,
    S: float,
    snap: SurfaceSnapshot,
    cfg: OverlayConfig,
    delta_vol_mode: str,
    constant_delta_vol: float,
) -> float:
    if delta_vol_mode == "fixed_entry":
        return float(state.entry_iv)
    if delta_vol_mode == "constant":
        return float(constant_delta_vol)
    # time_varying
    tau = remaining_tau(date, state.expiry_date, cfg.tau_basis_days)
    return snap.interpolate_iv(S, state.strike, tau, cfg.rate, cfg.dividend_yield, valuation_date=date).iv


def value_leg_for_delta_target(
    state: OptionLegState,
    date: pd.Timestamp,
    S: float,
    snap: SurfaceSnapshot,
    cfg: OverlayConfig,
    delta_vol_mode: str,
    constant_delta_vol: float,
) -> LegValuation:
    vol = _delta_vol_for_leg(state, date, S, snap, cfg, delta_vol_mode, constant_delta_vol)
    return value_leg_state(state, date, S, snap, cfg, vol_override=vol)


def _initialize_replication_accounts(
    vals_for_market: Sequence[LegValuation],
    vals_for_delta: Sequence[LegValuation],
    S: float,
    B: float,
    cfg: OverlayConfig,
) -> Tuple[float, float, float, float]:
    """Return Q, A, F, open_trade_tc for a new synthetic option portfolio."""
    option_portfolio_value = float(sum(v.leg_mtm for v in vals_for_market))
    Q = float(sum(v.delta_units for v in vals_for_delta))
    if cfg.short_cap_multiple_nav is not None:
        short_cap_units = cfg.short_cap_multiple_nav * B / S
        Q = max(Q, -short_cap_units)
    A = option_portfolio_value - Q * S
    F = -option_portfolio_value
    open_tc = abs(Q * S) * cfg.underlying_tc_bps / 10000.0
    A -= open_tc
    return Q, A, F, open_tc


def backtest_delta_replicated_overlay(
    portfolio_nav: pd.Series,
    underlying_spot: pd.Series,
    surfaces: Union[Dict[pd.Timestamp, IVSurface], SurfaceProvider],
    cfg: OverlayConfig,
    leg_configs: Sequence[OptionLegConfig],
    beta: Optional[pd.Series] = None,
    strategy_id: Optional[str] = None,
    delta_vol_mode: str = "time_varying",  # time_varying, fixed_entry, constant
    constant_delta_vol: float = 0.20,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Backtest a delta-replicated option overlay.

    The strategy does not hold options.  It computes the theoretical option portfolio's
    net delta and trades the underlying + cash to replicate that delta.

    Returns
    -------
    strategy_df, leg_df
    """
    strategy_id = strategy_id or f"DeltaRep_{cfg.strategy_id}"
    provider = surfaces if isinstance(surfaces, SurfaceProvider) else DictSurfaceProvider(surfaces)
    df = align_inputs(portfolio_nav, underlying_spot, beta)
    states: List[OptionLegState] = []
    Q = 0.0
    A = 0.0
    F = 0.0
    realized_overlay_pnl = 0.0
    strategy_rows: List[Dict[str, object]] = []
    leg_rows: List[Dict[str, object]] = []
    prev_date: Optional[pd.Timestamp] = None

    for idx, row in df.iterrows():
        date = pd.Timestamp(idx).normalize()
        try:
            snap = provider.get_surface(date)
        except Exception:
            continue
        B = float(row["B"])
        S = float(row["S"])
        beta_t = float(row["beta"])

        if prev_date is not None and states:
            dt = max((date - prev_date).days / cfg.tau_basis_days, 0.0)
            A *= (1.0 + cfg.cash_rate * dt)
            F = _accrue_financing(F, dt, cfg)
            short_notional = max(-Q, 0.0) * S
            A -= short_notional * (cfg.borrow_rate + cfg.dividend_yield) * dt

        roll_flag = False
        underlying_tc = 0.0
        closed_overlay_pnl = 0.0
        trade_flag = "hold"

        if states and should_roll_any(states, date, cfg):
            close_tc = abs(Q * S) * cfg.underlying_tc_bps / 10000.0
            X_close = Q * S + A - close_tc
            closed_overlay_pnl = X_close + F
            realized_overlay_pnl += closed_overlay_pnl
            Q, A, F = 0.0, 0.0, 0.0
            states = []
            underlying_tc += close_tc
            roll_flag = True
            trade_flag = "roll"

        if not states:
            states = []
            vals_market: List[LegValuation] = []
            vals_delta: List[LegValuation] = []
            for lc in leg_configs:
                st, val_mkt = create_leg_state(lc, date, B, S, beta_t, snap, cfg)
                states.append(st)
                vals_market.append(val_mkt)
                vals_delta.append(value_leg_for_delta_target(st, date, S, snap, cfg, delta_vol_mode, constant_delta_vol))
            Q, A, F, open_tc = _initialize_replication_accounts(vals_market, vals_delta, S, B, cfg)
            underlying_tc += open_tc
            roll_flag = True
            trade_flag = "open" if trade_flag == "hold" else "roll"

        vals_market = [value_leg_state(st, date, S, snap, cfg) for st in states]
        vals_delta = [value_leg_for_delta_target(st, date, S, snap, cfg, delta_vol_mode, constant_delta_vol) for st in states]
        Q_target = float(sum(v.delta_units for v in vals_delta))
        if cfg.short_cap_multiple_nav is not None:
            short_cap_units = cfg.short_cap_multiple_nav * B / S
            Q_target = max(Q_target, -short_cap_units)
        dQ = Q_target - Q
        trade_tc = abs(dQ * S) * cfg.underlying_tc_bps / 10000.0
        A -= dQ * S + trade_tc
        underlying_tc += trade_tc
        Q = Q_target

        theoretical_option_value = float(sum(v.leg_mtm for v in vals_market))
        synthetic_sleeve_value = Q * S + A
        replication_error = synthetic_sleeve_value - theoretical_option_value
        overlay_value = realized_overlay_pnl + synthetic_sleeve_value + F
        hedged_nav = B + overlay_value
        denom = hedged_nav if abs(hedged_nav) > 1e-12 else np.nan
        hedge_notional = _hedge_notional(B, beta_t, cfg)

        for val_m, val_d in zip(vals_market, vals_delta):
            row_dict = valuation_to_leg_row(
                val_m, date=date, strategy_id=strategy_id, B=B, S=S, hedged_nav=hedged_nav,
                premium_cf=0.0, roll_flag=roll_flag, trade_flag=trade_flag,
            )
            row_dict.update({
                "delta_vol_mode": delta_vol_mode,
                "delta_iv": val_d.iv,
                "target_delta": val_d.delta,
                "target_delta_units": val_d.delta_units,
                "target_delta_weight": val_d.delta_units * S / denom,
            })
            leg_rows.append(row_dict)

        strategy_rows.append({
            "date": date,
            "strategy_id": strategy_id,
            "base_nav": B,
            "underlying_spot": S,
            "beta": beta_t,
            "hedged_nav": hedged_nav,
            "overlay_value": overlay_value,
            "realized_overlay_pnl": realized_overlay_pnl,
            "synthetic_sleeve_value": synthetic_sleeve_value,
            "financing_account": F,
            "rep_cash_account": A,
            "rep_underlying_units": Q,
            "rep_underlying_notional": Q * S,
            "replication_error": replication_error,
            "theoretical_option_value": theoretical_option_value,
            "hedge_notional": hedge_notional,
            "rep_underlying_weight": Q * S / denom,
            "rep_cash_weight": A / denom,
            "rep_financing_weight": F / denom,
            "rep_synthetic_option_value_weight": synthetic_sleeve_value / denom,
            "rep_overlay_value_weight": overlay_value / denom,
            "net_target_delta_units": Q_target,
            "net_target_delta_weight": Q_target * S / denom,
            "net_market_delta_units": sum(v.delta_units for v in vals_market),
            "net_market_delta_weight": sum(v.delta_units for v in vals_market) * S / denom,
            "net_gamma_weight": sum(v.gamma_dollar for v in vals_market) / denom,
            "net_vega01_weight": sum(v.vega01 for v in vals_market) / denom,
            "net_theta_weight": sum(v.theta_day for v in vals_market) / denom,
            "underlying_turnover_notional": abs(dQ * S),
            "underlying_transaction_cost": underlying_tc,
            "closed_overlay_pnl": closed_overlay_pnl,
            "delta_vol_mode": delta_vol_mode,
            "roll_flag": roll_flag,
            "num_legs": len(vals_market),
        })
        prev_date = date

    strategy_df = pd.DataFrame(strategy_rows)
    if not strategy_df.empty:
        strategy_df = strategy_df.set_index("date")
        strategy_df["hedged_return"] = strategy_df["hedged_nav"].pct_change().fillna(0.0)
        strategy_df["base_return"] = strategy_df["base_nav"].pct_change().fillna(0.0)
        strategy_df["overlay_pnl"] = strategy_df["overlay_value"].diff().fillna(0.0)
        strategy_df["overlay_contribution_return"] = strategy_df["overlay_pnl"] / strategy_df["base_nav"].shift(1)
        strategy_df["overlay_notional_return"] = strategy_df["overlay_pnl"] / strategy_df["hedge_notional"].shift(1)
        strategy_df["excess_return"] = strategy_df["hedged_return"] - strategy_df["base_return"]
        strategy_df[["overlay_contribution_return", "overlay_notional_return"]] = strategy_df[
            ["overlay_contribution_return", "overlay_notional_return"]
        ].replace([np.inf, -np.inf], np.nan).fillna(0.0)

    leg_df = pd.DataFrame(leg_rows)
    if not leg_df.empty:
        leg_df = leg_df.set_index("date")
        leg_df["leg_mtm_pnl"] = leg_df.groupby(["strategy_id", "leg_id"])["leg_mtm"].diff().fillna(0.0)
    return strategy_df, leg_df


# -----------------------------------------------------------------------------
# Episode payoff and convenience wrappers
# -----------------------------------------------------------------------------


def episode_payoff_table_multi(
    base_nav: pd.Series,
    strategy_navs: Dict[str, pd.Series],
    episodes: pd.DataFrame,
) -> pd.DataFrame:
    rows = []
    base = base_nav.dropna()
    for _, ep in episodes.iterrows():
        p = pd.Timestamp(ep["peak_date"])
        q = pd.Timestamp(ep["trough_date"])
        r = pd.Timestamp(ep["recovery_date"])
        if p not in base.index or q not in base.index or r not in base.index:
            continue
        Bp, Bq, Br = float(base.loc[p]), float(base.loc[q]), float(base.loc[r])
        base_trough_ret = Bq / Bp - 1.0
        base_recovery_ret = Br / Bp - 1.0
        for name, nav in strategy_navs.items():
            s = nav.dropna()
            if p not in s.index or q not in s.index or r not in s.index:
                continue
            Vp, Vq, Vr = float(s.loc[p]), float(s.loc[q]), float(s.loc[r])
            strat_trough_ret = Vq / Vp - 1.0
            strat_recovery_ret = Vr / Vp - 1.0
            rows.append({
                "episode_id": ep["episode_id"],
                "strategy": name,
                "peak_date": p,
                "trough_date": q,
                "recovery_date": r,
                "loss": ep["loss"],
                "pt_duration_days": ep["pt_duration_days"],
                "pr_duration_days": ep["pr_duration_days"],
                "base_trough_return": base_trough_ret,
                "strategy_trough_return": strat_trough_ret,
                "trough_payoff": strat_trough_ret - base_trough_ret,
                "base_recovery_return": base_recovery_ret,
                "strategy_recovery_return": strat_recovery_ret,
                "recovery_payoff": strat_recovery_ret - base_recovery_ret,
            })
    return pd.DataFrame(rows)


def make_nav_comparison(base_nav: pd.Series, strategy_dfs: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    out = pd.DataFrame({"Unhedged": base_nav})
    for name, df in strategy_dfs.items():
        if not df.empty and "hedged_nav" in df.columns:
            out[name] = df["hedged_nav"]
    return out.dropna(how="all")


def make_overlay_return_panel(strategy_dfs: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    cols = {}
    for name, df in strategy_dfs.items():
        if df.empty:
            continue
        if "overlay_contribution_return" in df.columns:
            cols[(name, "contribution")] = df["overlay_contribution_return"]
        if "overlay_notional_return" in df.columns:
            cols[(name, "notional")] = df["overlay_notional_return"]
    if not cols:
        return pd.DataFrame()
    out = pd.concat(cols, axis=1)
    out.columns = pd.MultiIndex.from_tuples(out.columns, names=["strategy", "return_type"])
    return out


def make_strategy_weight_panel(strategy_dfs: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    fields = [
        "net_delta_weight",
        "net_gamma_weight",
        "net_vega01_weight",
        "net_theta_weight",
        "overlay_value_weight",
        "net_option_mtm_weight",
        "rep_underlying_weight",
        "rep_cash_weight",
        "rep_financing_weight",
    ]
    cols = {}
    for name, df in strategy_dfs.items():
        if df.empty:
            continue
        for f in fields:
            if f in df.columns:
                cols[(name, f)] = df[f]
    if not cols:
        return pd.DataFrame()
    out = pd.concat(cols, axis=1)
    out.columns = pd.MultiIndex.from_tuples(out.columns, names=["strategy", "weight_type"])
    return out


# -----------------------------------------------------------------------------
# Synthetic surface helpers for tests and demos
# -----------------------------------------------------------------------------


def make_synthetic_surface(
    valuation_date: Union[str, pd.Timestamp],
    base_iv: float = 0.20,
    skew: float = 0.10,
    term_slope: float = 0.02,
    underlying_ric: str = "SYNTH",
) -> IVSurface:
    """Create a simple tau x moneyness IV surface for local testing."""
    taus = np.array([1/12, 0.25, 0.5, 1.0], dtype=float)
    moneyness = np.array([0.80, 0.90, 0.95, 1.00, 1.05, 1.10, 1.20], dtype=float)
    rows = []
    for T in taus:
        vols = []
        for m in moneyness:
            # Higher vol for downside strikes; mild term slope.
            vol = base_iv + skew * max(1.0 - m, 0.0) + term_slope * math.sqrt(T)
            vols.append(vol)
        rows.append(vols)
    grid = pd.DataFrame(rows, index=taus, columns=moneyness)
    return IVSurface(pd.Timestamp(valuation_date), grid=grid, underlying_ric=underlying_ric)
