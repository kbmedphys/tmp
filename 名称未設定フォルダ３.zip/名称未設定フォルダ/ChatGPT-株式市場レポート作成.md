# 株式市場レポート作成

**User:** Anonymous  
**Created:** 6/22/2026 4:57:00  
**Updated:** 6/22/2026 6:02:17  
**Exported:** 6/22/2026 6:02:49  
**Link:** [https://chatgpt.com/c/6a38420b-c978-83ee-8af3-30dce3e38586](https://chatgpt.com/c/6a38420b-c978-83ee-8af3-30dce3e38586)  

## Response:
2026/6/22 4:57:01

6月15日〜19日を先週として、日米欧の主要指数、企業材料、証券各社の見方を日次で整理し、今週の注目日程まで5分用原稿にまとめます。

先週は中東リスク後退と原油安、AI・半導体株が支えとなる一方、日銀・FRBのタカ派姿勢が重しでした。今週は原油、米PCE、Micron決算、日銀「主な意見」を重点確認します。

> **マーケットレポートの準備**
>
> ユーザーのリクエストに基づいて、株式や企業報告などの現在の市場の動向を追います。"先週一週間"というのは2026年6月15日月曜日から6月19日金曜日までと思われます。これに基づいて、日々の主要なイベントとインデックスの反応をカバーします。
>
> **広範囲で検索**
>
> ウェブで広く検索し、結果を絞り込みます。最大で4つのクエリを使用し、日付範囲や公式情報を優先して調査します。
>
> **日経225とTOPIXの公式データ検索**
>
> [Japan's Nikkei Closes Above 70000 for First Time](https://www.barrons.com/livecoverage/stock-market-news-today-061826/card/japan-s-nikkei-closes-above-70000-for-first-time-axOE0tJ1e5aU6095ZY1i)
> [Japan's Nikkei retreats from record high as AI rally sparks caution](https://www.reuters.com/world/asia-pacific/japans-nikkei-hits-record-high-chip-related-shares-jump-2026-05-27/)
> [Japan's Nikkei tops 70000 for first time, bonds drop after ...](https://www.reutersconnect.com/item/japans-nikkei-tops-70000-for-first-time-bonds-drop-after-boj-hikes-as-expected/dGFnOnJldXRlcnMuY29tLDIwMjY6bmV3c21sX1ZBOTM5NjE2MDYyMDI2UlAx)
> [JUNE (雑誌)](https://ja.wikipedia.org/wiki/JUNE_%28%E9%9B%91%E8%AA%8C%29)
> [Reuters reports that #Japan's Nikkei share average ...](https://www.instagram.com/p/DYv1hqRGd6M/)
> [JUNE（ジューン） | CHARACTER](https://si-vis.live/character/june.html)
> [Japan Stock Market Index (JP225) - Quote - Chart](https://tradingeconomics.com/japan/stock-market)
> [2026](https://www.jpx.co.jp/english/derivatives/rules/last-trading-day/tvdivq0000004gz8-att/2026_indexfutures_options_1_e.xlsx)
> [JUNE](https://june-official.com/)
> [JUNE | ソニーミュージックオフィシャルサイト](https://www.sonymusic.co.jp/artist/JUNE/)
> [JUNE](https://www.stardust.co.jp/talent/sdr/june/)
> [June](https://www.youtube.com/channel/UCVN0FO3W5ekwjUB2gOICIyA)
> [Nikkei 225 (^N225) Historical Data](https://finance.yahoo.com/quote/%5EN225/history/)
> [ジューンブライドとは？ 「6月に結婚すると幸せになれる」意味や ...](https://wedding.mynavi.jp/premium/contents/wedding_style_dictionary/junebride/)
> [Sanae Takaichi win pushes Japan's stock market to record high](https://www.thetimes.com/business/economics/article/takaichi-landslide-sends-japan-stock-market-record-high-nikkei-yen-77jgszfp6)
> [Obscure Japanese stock measure widens on global hunt for AI winners](https://www.ft.com/content/f9bffe4e-30ca-44a5-ab2f-0ed85fbf00a7)
>
> **正確なデータの検索**
>
> 2026年の未来のデータがあるけど、現在の日付も2026年なので、ウェブ上にはシミュレートされた結果がいくつかあるかもしれません。具体的な情報が必要です。日本国内やアメリカの情報を日々調べ、Yahooのような信頼できる履歴データを探します。
>
> **特定の日付のウォール街閉場データ検索**
>
> [Wall Street rallies, Dow ends with record on US-Iran deal, oil price slide](https://www.reuters.com/business/wall-st-futures-advance-over-1-markets-cheer-iran-deal-2026-06-15/)
> [JUNE (雑誌)](https://ja.wikipedia.org/wiki/JUNE_%28%E9%9B%91%E8%AA%8C%29)
> [JUNE（ジューン） | CHARACTER](https://si-vis.live/character/june.html)
> [JUNE](https://june-official.com/)
> [JUNE | ソニーミュージックオフィシャルサイト](https://www.sonymusic.co.jp/artist/JUNE/)
> [JUNE](https://www.stardust.co.jp/talent/sdr/june/)
> [June](https://en.wikipedia.org/wiki/June)
> [Nasdaq and S&P 500 slip while Dow hits record high](https://jp.reuters.com/video/watch/idRW963016062026RP1/)
> [June](https://www.youtube.com/channel/UCVN0FO3W5ekwjUB2gOICIyA)
>
> **米国祝日と日本市場の取引データ**
>
> 2026年6月19日（金曜日）は米国祝日（ジュンティーンス）で、市場は休場でした。日本の取引は金曜日もあるので、月曜日から木曜日の米国市場データを調べ、正確なデータを得るためにReutersやYahoo、JPX公式のヒストリカルCSVを検索します。
>
> **Searching for June 2026 Japanese equity market closes**
>
> [2026](https://www.jpx.co.jp/english/derivatives/rules/last-trading-day/tvdivq0000004gz8-att/2026_indexfutures_options_1_e.xlsx)
> [Nikkei Average Closes above 71000 for 1st Time](https://www.nippon.com/en/news/yjj2026061800897/)
> [Japan's stock market reached a new milestone ...](https://www.instagram.com/p/DZo9N2HDr8M/)
> [Japan Stock Market Index (JP225) - Quote - Chart](https://tradingeconomics.com/japan/stock-market)
> [Nikkei surges over 5% after US-Iran deal to end war](https://mainichi.jp/english/articles/20260615/p2g/00m/0bu/010000c)
> [Japanese stocks surged to historic highs as the Nikkei ...](https://www.facebook.com/NipponTVNews24Japan/posts/japanese-stocks-surged-to-historic-highs-as-the-nikkei-stock-average-briefly-cro/1701094661378727/)
> [The Full Story of the Historic 3100 Yen Surge Driven by ...](https://note.com/hirokimiyano/n/n9180f22dbe9d?hl=en)
> [BOJ hikes as expected, taper pause ahead](https://investinglive.com/news/investinglive-asia-pacific-fx-news-wrap-boj-hikes-as-expected-taper-pause-ahead-20260616/)
> [TOPIX (.TOPIX) News Flow - moomoo](https://www.moomoo.com/index/.TOPIX-JP/news?chain_id=Name1K9-3FXPhg.1ktj3o0&global_content=%7B%22promote_id%22%3A13764%2C%22sub_promote_id%22%3A39%2C%22f%22%3A%22www.moomoo.com%2Fus%2Fhans%2Flearn%2Fdetail-what-is-short-selling-77252-221082025%22%7D)
> [Japan's Nikkei retreats from record high as AI rally sparks ...](https://www.reuters.com/world/asia-pacific/japans-nikkei-hits-record-high-chip-related-shares-jump-2026-05-27/)
> [Stock price chart | Tokai Carbon Co., Ltd.](https://www.tokaicarbon.co.jp/en/ir/chart.html)
> [Asian Markets Mixed: Nikkei Hits Record High After BOJ ...](https://www.indexbox.io/blog/asian-markets-mixed-nikkei-hits-record-high-after-boj-rate-hike-asx-flat-on-rba-hold/)
> [Bank of Japan Monetary Policy Meeting (June 2026)](https://www.daiwa-am.co.jp/english/market-outlook/20260617_01.pdf)
> [Bank of Japan Raises Rates to 1% Amid Inflation Concerns and ...](https://www.vibetrader.com/news/8dee0d50-25d5-4e4b-9a86-368eec750d0c)
> [Japan's Nikkei scales record peak on Mideast, AI optimism](https://www.thestandard.com.hk/finance/article/333339/Japans-Nikkei-scales-record-peak-on-Mideast-AI-optimism)
> [Nikkei Average Stock Price Reaches 70000 Level for First Time](https://alphai.io/news/article/06-16/77844fbed42d199e/nikkei-average-stock-price-reaches-70000-level-for-first-time)
>
> **金融ツールによる指数データ検索**
>
>
> **日本市場のティッカー確認**
>
> 引き続き、N225（ニッケイ）やJPNといったティッカーを使って日本市場を確認します。特に、.N225が適切なティッカーかどうか、また金融情報としてサポートされているかを確認します。
>
> **金融ティッカーN225に関する検索**
>
>
> **Searching Nikkei historical data for exact daily closes**
>
> [Nikkei Average Closes above 71,000 for 1st Time | Nippon.com](https://www.nippon.com/en/news/yjj2026061800897/)
>
> **月曜日の終値調査**
>
> 正確な月曜日の終値は69,317.50（69,404.50から87.00差し引いた値）と推測されます。これを確認するため、さらに直接検索を行います。
>
> **検索: 日経、TOPIXの関連データ**
>
> [Nikkei Average Marks Record Closing High above 69000](https://www.nippon.com/en/news/yjj2026061500259/)
> [日経平均大引け：前日比196.57円高の71250.06円(フィスコ)](https://finance.yahoo.co.jp/news/detail/85902920c94ecf440ddb503d1cc02ceb4e24eb89)
> [Nikkei average closes above 69000 for the first time](https://www.japantimes.co.jp/business/2026/06/15/markets/nikkei-surge-69000-iran-deal/)
> [Historical Data (Nikkei 225)](https://indexes.nikkei.co.jp/en/nkave/archives/data)
> [Asia closing levels - 19/6/26 - NIKKEI](https://x.com/truemagic68/status/2068205817690550734)
> [Nikkei 225 Nears 70000, Funds Continue to Flow into AI ...](https://note.com/youpapa_7777/n/nc7603d45d86b?hl=en)
> [Asian Stocks - 17-06-26](https://armenpress.am/en/article/1253335)
> [マーケット情報／株式指数／チャート（1年）](https://www.wam.abic.co.jp/ap02/indxstokchart1y.do?_biz_fg_linktype=direct&_biz_id_index=1102&_com_id_company=C130157&_com_id_product=1)
> [Nikkei ends at record high near 70000 as crude oil prices ...](https://mainichi.jp/english/articles/20260617/p2g/00m/0bu/027000c)
> [Shares mixed and oil trades below $80 on optimism over ...](https://japantoday.com/category/business/shares-are-mixed-and-oil-trades-below-80-on-optimism-over-interim-us-iran-war-deal)
> [日経平均大引け：前日比196.57円高の71250.06円 | 企業情報 ...](https://web.fisco.jp/platform/market-news/0009340020260619032)
> [Nikkei Closes at New Record High](https://qna.org.qa/en/News-Area/News/2026-6/17/nikkei-closes-at-new-record-high)
> [#Markets | Japan's benchmark Nikkei 225 index crossed ...](https://www.instagram.com/p/DZorVUoCZVh/)
> [Nikkei 225 Surges, Closes Just Shy of ¥70000 as ...](https://finance.biggo.com/news/fef45f93-3184-41de-8753-de4c1ecf62a4)
> [マーケット情報 | 日本](https://www.nomura-am.co.jp/market/area_japan.html)
> [A monitor shows the Nikkei Stock Average (Nikkei 225) closing ...](https://www.alamy.com/a-monitor-shows-the-nikkei-stock-average-nikkei-225-closing-price-above-the-69000-yen-level-in-osaka-city-osaka-prefecture-japan-on-june-15-2026-the-nikkei-225-rose-sharply-for-the-third-consecutive-day-in-the-tokyo-stock-market-closing-at-6931750-yen-up-329746-yen-from-the-previous-trading-day-both-the-intraday-and-closing-prices-reached-new-all-time-highs-exceeding-69000-yen-for-the-first-time-the-increase-was-the-second-largest-in-history-the-yomiuri-shimbun-via-ap-images-image736762848.html)
> [Nikkei 225 (^N225) Historical Data](https://finance.yahoo.com/quote/%5EN225/history/)
> [Nikkei 225 Today](https://www.dealplexus.com/markets/nikkei-225-today)
>
> **TOPIX週次と米国市場データ確認**
>
> TOPIXの正確な値を求めます。6月12日の終値は3881.96、6月19日の終値4044.96、週間リターンは+4.20%。日経平均は+7.92%。S&P500は+0.93%だったが、月曜の終値が正確か再確認が必要。米国市場のデータも調査します。
>
> **Calculating weekly returns for TOPIX, S&P, and Dow**
>
> [Wall Street rallies, Dow ends with record on US-Iran deal, oil price slide | Reuters](https://www.reuters.com/business/wall-st-futures-advance-over-1-markets-cheer-iran-deal-2026-06-15/)
>
> **確認するべき今週の重要なイベント**
>
> 6月22日（月）は日本のPMI速報？通常23日か24日に発表。米国のPCEとGDP第三回推定、6月25日に予定。日本のBOJ会議結果の公開はおそらく6月24日で、米国のFedの発言のスケジュールも確認が必要。
>
> **今週の市場動向と注意点**
>
> 6月25日までには、Micron、Nike、FedEx、Carnival、Walgreensの決算予定。また、6月29-30は半期末。一方、月末のポジショニングも影響を与えるかもしれません。欧州や中国の市場も考慮しつつ、日本と米国が主な焦点となります。
>
> **調査: 日本・米国株式市場と経済指標**
>
> [BOJ may raise interest rates twice by March, says ex-BOJ policymaker](https://www.reuters.com/world/asia-pacific/boj-may-raise-interest-rates-twice-by-march-says-ex-boj-policymaker-2026-06-19/)
> [日本 | 最新株式指数ニュース](https://jp.reuters.com/markets/world-indices/japan/)
> [Nikkei Stock Average Ends at Fresh Record High](https://www.nippon.com/en/news/yjj2026061900882/)
> [Statistics Bureau Home Page/Consumer Price Index Latest ...](https://www.stat.go.jp/english/data/cpi/1581-z.html)
> [Japan May core CPI rises 1.4% yr/yr By Reuters](https://www.investing.com/news/economic-indicators/japan-may-core-cpi-rises-14-yryr-4751166)
> [Jun 19, 2026 – 🔥 Japan May Core CPI YoY in focus! ...](https://www.facebook.com/ultimamarketsglobal/videos/jun-19-2026-japan-may-core-cpi-yoy-in-focusjapan-will-release-its-core-inflation/2254350001972327/)
> [A phase transition in monetary function explains expansion without inflation](https://arxiv.org/abs/2604.24035)
>
> **今週の主なイベントと経済カレンダー**
>
> 6月22日〜26日に関するイベントとデータの検索が必要です。特に、日銀の「意見概要」発表、アメリカのGDP第三四半期、耐久消費財、PCEなどの予定に注目。東京のCPIも確認。公式カレンダーを調べ、正確な日程を取得しましょう。
>
> **Browsing official release schedules for June 2026**
>
> [Monetary Policy Meetings : 日本銀行 Bank of Japan](https://www.boj.or.jp/en/mopo/mpmsche_minu/index.htm)
> [Release Schedule | U.S. Bureau of Economic Analysis (BEA)](https://www.bea.gov/news/schedule)
> [Economic Indicator Release Schedule: List View](https://www.census.gov/economic-indicators/calendar-listview.html)
> [Home Statistics Consumer Price Index Schedule of Release](https://www.stat.go.jp/english/data/cpi/1582.html)
>
> **企業の2026年6月期決算日を検索**
>
> [Micron Technology to Report Fiscal Third Quarter Results on ...](https://investors.micron.com/news-releases/news-release-details/micron-technology-report-fiscal-third-quarter-results-june-24)
> [Investor Relations | FedEx](https://investors.fedex.com/home/default.aspx)
> [NIKE, Inc. Announces Fourth Quarter Fiscal 2026 Earnings ...](https://investors.nike.com/investors/news-events-and-reports/investor-news/investor-news-details/2026/NIKE-Inc--Announces-Fourth-Quarter-Fiscal-2026-Earnings-and-Conference-Call/default.aspx)
>
> **S&PグローバルPMIの正確なカレンダー確認**
>
> S&PグローバルPMIのデータ発表予定日を正確に確認する必要があります。検索して、カレンダーを手に入れたら、その情報を元に更新を進めましょう。
>
> **Searching S&P Global PMI リリースカレンダー**
>
> [PMI Releases - pmi.spglobal.com](https://www.pmi.spglobal.com/Public/Release/PressReleases)
> ['Flash' PMI surveys show Eurozone woes, Asia rebounds ...](https://www.spglobal.com/marketintelligence/en/mi/research-analysis/23062014080000-Flash-PMI-surveys-show-Eurozone-woes-Asia-rebounds-and-US-factory-growth-hits-four-year-high.html)
> [Japan Manufacturing PMI](https://tradingeconomics.com/japan/manufacturing-pmi)
> [Japan Economic Calendar](https://www.mufgresearch.com/macro/japan-economic-calendar-week-of-june-1-to-5-2026/)
> [Report Release Date Calendar](https://www.ismworld.org/supply-management-news-and-reports/reports/rob-report-calendar/)
> [United States Services Purchasing Managers Index (PMI)](https://www.investing.com/economic-calendar/united-states-services-purchasing-managers-index-%28pmi%29-1062)
> [2026 U.S. Economic Calendar](https://www.guggenheiminvestments.com/services/advisor-resources/us-economic-calendar)
> [PMI Monthly Bulletin](https://cdn.ihsmarkit.com/www/pdf/0226/PMI_monthly_bulletin_2602.pdf)
> [Economic Calendar](https://bradescobank.com/wp-content/uploads/2026/06/economicCalendar-202605june.pdf)
> [Euro Area S&P Global Manufacturing PMI Flash](https://www.finlogix.com/calendar/ep/sp-global-manufacturing-pmi-flash)
> [PMI Report – June 2022 (updated).pdf](https://www.mta.org.uk/wp-content/uploads/2023/01/PMI-Report-June-2022-updated.pdf)
> [#Eurozone S&P Global Manufacturing PMI final May 2026 ...](https://x.com/forexanalytix/status/2061357234781597890)
> [Economic calendar: PMI reports and the US labor market in ...](https://www.xtb.com/int/market-analysis/news-and-research/economic-calendar-pmi-reports-and-the-us-labor-market-in-the-spotlight)
> [PMI Monthly Bulletin](https://spglobal.scene7.com/is/content/spglobalcom/6184216_6184223_0.1pdf)
> [US Final Manufacturing PMI](https://www.forexfactory.com/calendar/553-us-final-manufacturing-pmi)
> [Japan factory activity returns to growth after 11-month contraction, PMI shows](https://www.reuters.com/markets/asia/japan-factory-activity-returns-growth-after-11-month-contraction-pmi-shows-2025-06-23/)
> [UK output price inflation hits 4-year low, survey shows](https://www.ft.com/content/1c25576c-4ed8-492c-9943-e5307d55f0bb)
> [UK factories return to growth as PMIs show global slump easing - as it happened](https://www.theguardian.com/business/live/2020/jun/23/economic-activity-pmi-uk-eurozone-australia-covid-19-slump-eases-markets-business-live)
>
> **レポートと見通しをまとめる**
>
> まず、DaiwaやGoldman、JPMorgan、Reutersの調査レポートを集めて、各社の見通しを確認する必要があります。また、来週の東京市場についてReutersの記事から要点をまとめて、最終的な回答が正確になるようにします。
>
> **検索してレポートおよび市場見通しまとめ**
>
> [Micron's earnings are a must-watch market event - with profit growth approaching 1,000%](https://www.marketwatch.com/story/microns-earnings-are-a-must-watch-market-event-with-profit-growth-approaching-1-000-78ec4549)
> [Wall St Week Ahead Investors see Micron earnings as pulse check of AI rally momentum](https://www.reuters.com/business/finance/wall-st-week-ahead-investors-see-micron-earnings-pulse-check-ai-rally-momentum-2026-06-19/)
> [Micron Stock Faces Tough Earnings Test. What History Says Happens Next.](https://www.barrons.com/articles/micron-stock-price-earnings-4393444f)
> [Stock Market Week Ahead: Rebalancing And Technical Support](https://www.investors.com/research/investing-action-plan/stock-market-week-ahead-rebalancing-and-technical-support/)
> [Week Ahead for FX, Bonds: U.S. Inflation Data in Focus as Prospects of Fed Rate Hike Increase](https://www.wsj.com/economy/week-ahead-for-fx-bonds-u-s-inflation-data-in-focus-as-prospects-of-fed-rate-hike-increase-e2600d57)
> [Wall Street rebounds from Fed sell-off over interest rates, ends week on high note](https://nypost.com/2026/06/18/business/dow-jumps-250-points-as-wall-street-tries-to-recover-from-fed-sell-off-over-interest-rates-inflation-fears/)
> [もみ合い、米マイクロン決算でAI相場の基調を確認 くすぶる ...](https://jp.reuters.com/markets/japan/I7UX3DX6TRLQPN56RJASE4HZOA-2026-06-19/)
> [米国株週間見通し：利上げ警戒もAI相場がナスダック100下支え、マイクロン決算で31000視野も](https://www.ig.com/jp/news-and-trade-ideas/nasdaq-100-braces-for-micron-earnings-as-31000-level-eyed-260621)
> [来週（6/22～6/26）の日経平均株価の予想レンジは6万8800～7万7500円！｢7万1000円｣突破で過熱感が警戒される中、景気敏感株を見直す動きは出るか!?](https://diamond.jp/zai/articles/-/1069026)
> [Wall Street scrambles to lift Micron price targets ahead of ...](https://www.investing.com/news/stock-market-news/wall-street-scrambles-to-lift-micron-price-targets-ahead-of-earnings-4750052)
> [Everything Could Change for Micron Stock on June 24](https://finance.yahoo.com/markets/stocks/articles/everything-could-change-micron-stock-182200425.html)
> [もみ合い、米マイクロン決算でAI相場の基調を確認 くすぶる ...](https://x.com/ReutersJapan/status/2067878565354312013)
> [Micron Earnings Date & Event Calendar](https://www.wallstreethorizon.com/micron-earnings-calendar)
> [米雇用統計ショックで大幅続落となった日経平均株価の今後を ...](https://www.smd-am.co.jp/market/ichikawa/2026/06/irepo260608.pdf)
> [Micron Technology to Report Fiscal Third Quarter Results on ...](https://investors.micron.com/news-releases/news-release-details/micron-technology-report-fiscal-third-quarter-results-june-24)
>
> **ニュース記事の検索と要点整理**
>
> 日々の日本のReuters記事を確認したいので、15日から18日の間の企業の動向を取り上げた記事を検索してみます。NipponやReutersのページでデータが得られるので、それを開いて、必要な情報を引用して最終的な回答へ反映させます。
>
> **検索日付ごとの日本の企業動向記事**
>
> [今日の株式見通し＝続伸、7万円トライも 日銀会合は想定通り ...](https://jp.reuters.com/markets/japan/CHZEWMHRDNMSXNW7MYONXVCC5E-2026-06-15/)
> [2026年 年間カレンダー](https://micronix-jp.com/file-download/calendar/2026_jp.pdf)
> [2026夏アニメまとめ一覧｜来期7月放送開始 新作アニメ・再 ...](https://www.animatetimes.com/tag/details.php?id=5806)
> [2026年](https://ja.wikipedia.org/wiki/2026%E5%B9%B4)
> [2026年度 年間カレンダー](https://www.oitaplaza.jp/japanese/wp-content/uploads/2025/01/9d67720693aa8b2f08de379fbb72bccf.pdf)
> [2026年（令和8年）カレンダー(祝日・六曜・月齢)](https://www.benri.com/calendar/)
> [2026年は何があるの？ 予定される注目のトピックスを総覧！](https://yslappsmedia.chex.jp/column/2026-002/)
> [Amazon.co.jp: 2026](https://www.amazon.co.jp/2026/s?k=2026)
> [2026年5月にはどんなことが話題になった？ ネットの流行りを ...](https://webtan.impress.co.jp/e/2026/06/04/52742)
> [未来年表 : 分野検索 経済 2026年](https://seikatsusoken.jp/futuretimeline/search_category.php?category=6&year=2026)
>
> **火曜日と木曜日のReuters記事の検索**
>
> 火曜日と木曜日の日本のReuters記事をそれぞれ別々に検索して、適切な情報を見つけます。クエリがうまく一致しなかったので、再度別々に確認し、必要な情報を集めて最終的に反映させる予定です。
>
> **検索による火曜・木曜の日本経済情報**
>
> [今日の株式見通し＝反落、米ハイテク株安を嫌気 FOMC前の ...](https://jp.reuters.com/markets/japan/B5BSNVOVYJPPLODBCCDRJNI7NY-2026-06-16/)
>
> **週次リターンの計算**
>
> 週次リターンの計算が必要です。Nikkeiは66020.04から71250.06に、TOPIXは3881.96から4044.96に、Dowは51202.26から51564.70に、S&Pは7431.46から7500.58に、Nasdaqは25888.84から26517.93に変動しました。SOXについては必要ないかもしれません。計算して確認します。
>
> **計算週間リターン**
>
>
> **個別企業ニュースの確認**
>
> 金曜日の日本の企業ニュースを確認する必要があります。例えば、フジクラが通期予測を修正して、一転増益との報道があります（6月19日）。これをローカル企業の報告として含めるか検討します。正確な詳細と株価の動きを確認後、企業ニュースに追加する予定です。
>
> **Searching Fujikura's forecast revision and stock movement**
>
>
> **市況とリスク要因のまとめ**
>
> 木曜日、日本の半導体と中東の緩和報道で日経平均が1.64%上昇。金曜日、日経は小幅に上昇し、富士倉が業績予想を引き上げて大幅上昇。米国株は下落、FRBとBOJの金融引き締め、円のリスクが主要な焦点。USDJPYの161.27について、レートの参照が必要。
>
> **データと出典を簡潔に提示**
>
> ユーザーが日々のデータを求めているので、リスト形式で簡潔にまとめ、表と段落も併用します。財務の専門知識があるため、用語（例えば「SOX」、「タカ派」、「バリュー」）を使用しても問題なし。NikkeiやReutersでデータを確認し、出典を明記します。
>
> **簡潔にデータとレポートを整理**
>
> J.P.モルガンのNikkei目標やDaiwa AMのBOJに関するレポート、Reutersの週間予想レンジなどを追加。各社のレポートが示す通り、これらはコンセンサスではなく、特定の日付の見解であることを明記します。SMBC日興集計も取り入れつつ、現時点では余計かもしれません。
>
> **確認予定発表時間と情報**
>
> 6月25日にはGDPと耐久財受注の発表時間がありますが、それらは米東部時間で8:30ET、つまり日本時間で21:30JSTになります。また、MicronとFedExの発表も確認し、CPIやRussellの構成銘柄の変更が予定されているか調べます。正式なスケジュールを確認する必要があります。
>
> **Searching official FTSE Russell reconstitution schedule**
>
> [Russell Reconstitution](https://www.lseg.com/en/ftse-russell/russell-reconstitution)
> [2026年（令和8年）カレンダー(祝日・六曜・月齢)](https://www.benri.com/calendar/)
> [2026年 年間カレンダー](https://micronix-jp.com/file-download/calendar/2026_jp.pdf)
> [The 2026 Russell Reconstitution: Twice the Friction ...](https://www.cmegroup.com/articles/2026/the-2026-russell-reconstitution.html)
> [FTSE Russell to shake things up in upcoming reconstitution](https://www.investmentexecutive.com/news/industry/ftse-russell-to-shake-things-up-in-upcoming-reconstitution/)
> [2026年](https://ja.wikipedia.org/wiki/2026%E5%B9%B4)
> [Growth, Value or Both? What the 2026 Russell ...](https://www.morganstanley.com/im/en-us/individual-investor/insights/articles/russell-reconstitution.html)
> [2026年は何があるの？ 予定される注目のトピックスを総覧！](https://yslappsmedia.chex.jp/column/2026-002/)
> [FTSE Russell Begins June 2026 Semi-Annual ...](https://mondovisione.com/media-and-resources/news/ftse-russell-begins-june-2026-semi-annual-russell-us-indexes-reconstitution-2026526/)
> [Russell US Semi-Annual Reconstitution - Schedule Update](https://research.ftserussell.com/products/index-notices/home/getnotice/?id=2617649)
> [2026年度 年間カレンダー](https://www.oitaplaza.jp/japanese/wp-content/uploads/2025/01/9d67720693aa8b2f08de379fbb72bccf.pdf)
> [2026年6月](https://www.himekuricalendar.com/month-calendar)
> [it's the first under FTSE Russell's semi-annual schedule.](https://www.threads.com/%40cmegroup/post/DZfCvzjFFYZ/the-june-russell-reconstitution-close-is-routinely-one-of-the-highest-volume/)
> [Amazon.co.jp: 2026](https://www.amazon.co.jp/2026/s?k=2026)
> [Catherine Yoshimoto's Post](https://www.linkedin.com/posts/catherineyoshimoto_preliminary-russell-us-indexes-adds-and-deletes-activity-7463723675289133057-qwcf)
> [Institutional Trading Calendar](https://russellinvestments.com/content/ri/us/en/institutional-investor/solutions/customized-portfolio-solutions/transition-management/calendar.html)
> [未来年表 : 分野検索 経済 2026年](https://seikatsusoken.jp/futuretimeline/search_category.php?category=6&year=2026)
> [Alphabet, AMD Removed From Value Stock Status as Russell Reconstitutes Indexes](https://www.barrons.com/articles/alphabet-amd-apple-microsoft-amazon-russell-reconstitution-growth-value-529b91e5)
> [SpaceX set for fast entry into US, global indexes under new FTSE rules](https://www.reuters.com/legal/government/spacex-set-fast-entry-into-us-global-indexes-under-new-ftse-rules-2026-05-26/)
> [Russell Indexes Adjust For SpaceX IPO, Shifting Market Profile](https://www.investors.com/news/russell-indexes-adjust-for-spacex-ipo-shifting-market-profile/)
> [Reconstitution: Meaning, How it Works, Effect on Investors](https://www.investopedia.com/terms/r/reconstitution.asp)
>
> **最終報告の整備と確認**
>
> 最終的なレポートを作成するため、参照したすべてのソースが正確か、特に日付や市場レベルが妥当かを確認します。現在の日付は2026年6月21日で、先週は6月15日-19日です。会社の報告を含むテーブルを作成し、必要に応じて企業ニュースや重要な情報もカバーします。
>
> 思考時間: 9m 31s

## 発表用原稿〔約5分〕

先週、6月15日から19日の株式市場は、**米国・イラン情勢、日銀の追加利上げ、FRBのタカ派化、AI・半導体株への資金集中**という四つの材料で整理できます。週間では、日経平均が7.92％上昇して7万1,250円、TOPIXが4.20％上昇して4,044ポイントでした。米国は19日が休場だったため4営業日ですが、S&P500は0.93％、NASDAQは2.43％、ダウは0.71％上昇しました。日経平均がTOPIXを、NASDAQがダウを大きく上回っており、指数上昇の中心がAI・半導体関連に偏っていた点が特徴です。([Yahoo!ファイナンス](https://finance.yahoo.co.jp/quote/998407.O/history))

**15日月曜日**は、米国とイランの戦闘終結に向けた暫定合意を受け、原油価格が急落し、世界的にリスクオンとなりました。日経平均は4.99％高の6万9,317円、TOPIXは3.03％高の3,999ポイント。米国ではダウが0.92％高の5万1,671ドル、S&P500が1.65％高の7,554、NASDAQが3.07％高の2万6,683となりました。個別ではNVIDIAが3.5％、Micronが10.5％上昇する一方、FoxはRoku買収発表を受け16.8％下落しました。([Reuters Japan](https://jp.reuters.com/markets/japan/O3UHKFRAOVNUNJ63DU3EOAI7AU-2026-06-15/))

**16日火曜日**、日銀は政策金利を0.75％から1.00％へ引き上げました。1995年以来の水準ですが、追加利上げを急がないとの市場解釈から、日経平均は0.13％高の6万9,404円を維持しました。一方、TOPIXは0.21％安の3,991でした。米国では大型ハイテク株から金融・景気敏感株へのローテーションが起き、ダウは0.64％高の5万1,999ドルでしたが、S&P500は0.57％安、NASDAQは1.15％安となりました。([Reuters](https://www.reuters.com/world/asia-pacific/boj-raises-interest-rates-31-year-high-widely-expected-move-2026-06-16/))

**17日水曜日**、東京市場はAI・半導体株と景気敏感株に買いが入り、日経平均は0.72％高の6万9,902円、TOPIXは0.55％高の4,013でした。その後のFOMCでFRBは政策金利を3.50～3.75％に据え置きましたが、2026年末の政策金利予想中央値を3.4％から3.8％へ引き上げました。また、2026年のPCEインフレ予想を2.7％から3.6％へ、コアPCEを2.7％から3.3％へ大幅に上方修正しました。市場はこれを利上げ方向への転換と受け止め、ダウは0.98％、S&P500は1.21％、NASDAQは1.34％下落しました。([Reuters Japan](https://jp.reuters.com/markets/japan/XSDQYTD5JVMDHGAYHY5RY4OTXU-2026-06-17/))

**18日木曜日**は中東情勢への楽観と半導体株高が再び優勢となりました。日経平均は1.64％高の7万1,053円と、初めて7万1,000円台で終了しました。米国でもS&P500は1.08％高の7,500、NASDAQは1.91％高となり、半導体指数は6.4％上昇しました。Appleとの米国内半導体提携が報じられたIntelは10.6％上昇した一方、売上高見通しの上限を引き下げたAccentureは18％下落しており、AI関連でも企業間格差が大きくなっています。([Nippon](https://www.nippon.com/en/news/yjj2026061800897/))

**19日金曜日**、日経平均は7日続伸し、0.28％高の7万1,250円で終了しました。一時は7万1,952円まで上昇しましたが、TOPIXは0.57％安でした。半導体など指数寄与度の高い銘柄が上昇する一方、市場全体では利益確定売りが広がったことを示しています。米国市場はJuneteenthで休場、欧州株は小幅安でした。([Reuters Japan](https://jp.reuters.com/markets/japan/WN66FNHDLBOOTCAKKAINGRIBSU-2026-06-19/))

証券会社の見通しでは、Wells Fargoが2026年末のS&P500目標を7,300から7,950へ引き上げ、2026年EPS予想も315ドルから340ドルへ上方修正しました。一方、J.P. Morganが4月に設定した日経平均の年末目標7万円は既に上回っています。さらに、米国株ファンドには6月17日までの1週間で383億7,000万ドルが流入し、テクノロジー株ファンドへの流入は過去最高の214億6,000万ドルでした。したがって相場の基調は強いものの、ポジションと物色がAI・半導体に集中しているため、材料悪化時の反動も大きくなりやすい状況です。([Reuters](https://www.reuters.com/business/wells-fargo-raises-sp-500-target-stronger-earnings-outlook-2026-06-16/))

今週、6月22日から26日は、まず米国・イラン協議とホルムズ海峡の通航状況が最大の変数です。週末にはスイスで協議が行われる一方、イランが海峡を再び閉鎖したとの報道も出ています。原油が再上昇すれば、インフレ懸念と長期金利上昇を通じて、高PERの半導体株には逆風となります。経済・企業イベントでは、24日の日銀「主な意見」、25日早朝のMicron決算とFRBストレステスト、25日夜の米PCE物価指数が特に重要です。**中東情勢安定、PCE下振れ、Micronの強い見通し**がそろえば上値追い、逆に**海峡閉鎖長期化、PCE上振れ、Micronの慎重なガイダンス**となれば、先週上昇した半導体・日経平均主導株を中心に調整が起きやすいとみています。([Reuters](https://www.reuters.com/world/europe/no-fly-zone-iran-talks-disrupted-flights-zurich-airport-authorities-say-2026-06-21/?utm_source=chatgpt.com))

---

## 各日の指数水準

| 日付 | 日経平均 | TOPIX | ダウ | S&P500 | NASDAQ |
|---|---:|---:|---:|---:|---:|
| 6月15日 | 69,317.50（+4.99%） | 3,999.60（+3.03%） | 51,671.03（+0.92%） | 7,554.29（+1.65%） | 26,683.94（+3.07%） |
| 6月16日 | 69,404.50（+0.13%） | 3,991.14（-0.21%） | 51,999.67（+0.64%） | 7,511.35（-0.57%） | 26,376.34（-1.15%） |
| 6月17日 | 69,902.25（+0.72%） | 4,013.23（+0.55%） | 51,492.55（-0.98%） | 7,420.10（-1.21%） | 26,021.66（-1.34%） |
| 6月18日 | 71,053.49（+1.64%） | 4,068.18（+1.37%） | 51,564.70（+0.14%） | 7,500.58（+1.08%） | 26,517.93（+1.91%） |
| 6月19日 | 71,250.06（+0.28%） | 4,044.96（-0.57%） | 休場 | 休場 | 休場 |

日本株は終値系列、米国株は各日のReuters集計です。([Yahoo!ファイナンス](https://finance.yahoo.co.jp/quote/998407.O/history))

## 今週の重要日程〔日本時間〕

| 日時 | イベント | 株式市場への着眼点 |
|---|---|---|
| 6月22日（月） | 米・イラン協議、ホルムズ海峡関連報道 | 原油、インフレ期待、航空・海運・半導体株 |
| 6月23日（火）14:00 | 日銀「基調的なインフレ率を捕捉するための指標」 | 追加利上げ観測、銀行・不動産・円相場 |
| 6月24日（水）8:50 | 日銀「金融政策決定会合における主な意見」 | 1％利上げ後の次回利上げ時期 |
| 6月24日（水）23:00 | 米新築住宅販売 | 住宅需要と高金利の影響 |
| 6月25日（木）5:00 | FRB銀行ストレステスト結果 | 米大手銀行の資本還元余力 |
| 6月25日（木）5:30 | Micron決算説明会 | AIサーバー、HBM、メモリー需給の持続性 |
| 6月25日（木）21:30 | 米PCE物価、1～3月期GDP確報、耐久財受注 | FRB利上げ観測と米長期金利 |
| 6月26日（金）23:00 | ミシガン大学消費者態度指数・確報 | 消費者のインフレ期待 |

日程は日銀、FRB、BEA、米商務省、Micron、ミシガン大学の公表資料に基づきます。([情報処理推進機構](https://www.boj.or.jp/en/about/calendar/index.htm))

## 各社見通しの位置付け

| 機関 | 見通し | 現時点での解釈 |
|---|---|---|
| Wells Fargo | 2026年末S&P500＝7,950、EPS＝340ドル | 業績・半導体には強気。ただし最大のリスクをインフレとしている |
| J.P. Morgan | 2026年末日経平均＝70,000、TOPIX＝4,300 | 日経平均は既に目標を超過。今後はTOPIXへの物色拡大が必要 |
| 野村證券 | 夏場にインフレが上振れれば10月利上げ、遅くとも年内に追加利上げとの見方 | 24日の「主な意見」で前倒し観測が強まるかが焦点 |
| Citi | 暫定合意を前提に、2026年7～9月期Brent平均75ドルを予想 | 週末の海峡再閉鎖報道により、前提条件の不確実性が増している |

これらは各社の予測であり、実績値とは区別する必要があります。([Reuters](https://www.reuters.com/business/wells-fargo-raises-sp-500-target-stronger-earnings-outlook-2026-06-16/))

**結論としては、「上昇トレンドは維持されているが、地政学・インフレ・半導体の三つに依存した、集中度の高い相場」とまとめるのが適切です。**

- [Reuters](https://www.reuters.com/world/europe/no-fly-zone-iran-talks-disrupted-flights-zurich-airport-authorities-say-2026-06-21/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/asia-pacific/us-disputes-iranian-claims-about-closing-strait-hormuz-negotiators-head-2026-06-20/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/middle-east/iran-closes-strait-hormuz-over-ceasefire-violations-mehr-2026-06-20/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/asia-pacific/us-iran-reach-peace-deal-signing-set-friday-pakistan-says-2026-06-14/?utm_source=chatgpt.com)

---

**Sources:**

- [日経平均株価：時系列・推移 - Yahoo!ファイナンス](https://finance.yahoo.co.jp/quote/998407.O/history)
- [日経平均は大幅に3日続伸、最高値　米イラン和平合意でリスクオン | ロイター](https://jp.reuters.com/markets/japan/O3UHKFRAOVNUNJ63DU3EOAI7AU-2026-06-15/)
- [Bank of Japan raises rates to 31-year high, flags more to come | Reuters](https://www.reuters.com/world/asia-pacific/boj-raises-interest-rates-31-year-high-widely-expected-move-2026-06-16/)
- [Nikkei Average Closes above 71,000 for 1st Time | Nippon.com](https://www.nippon.com/en/news/yjj2026061800897/)
- [Release Schedule  : 日本銀行 Bank of Japan](https://www.boj.or.jp/en/about/calendar/index.htm)

## Response:
2026/6/22 5:09:57

中東情勢の「覚書」の内容と日付を確認し、6月20・21日の週末材料も時系列で追加して、前回原稿に差し込める形で整理します。

> **Browsing latest events and memorandums on Middle East**
>
> [Trump threatens Iran with fresh strikes as Vance leads peace talks in Switzerland](https://www.reuters.com/world/asia-pacific/us-disputes-iranian-claims-about-closing-strait-hormuz-negotiators-head-2026-06-20/)
> [US may charge 'Guardian Angel' toll in Strait of Hormuz, Trump says](https://www.thetimes.com/world/middle-east/article/strait-hormuz-closed-iran-us-deal-news-today-n9vp8dbnb)
> [Trump threatens Iran after JD Vance hails 'great progress' made in Switzerland talks - as it happened](https://www.theguardian.com/world/live/2026/jun/21/iran-us-israel-war-middle-east-lebanon-peace-talks-switzerland-vance-trump-strait-of-hormuz-latest-news-updates)
> [Vance Heads to Peace Talks, After Iran Says It Closed Strait of Hormuz](https://www.wsj.com/world/middle-east/fighting-flares-again-in-lebanon-despite-israel-hezbollah-ceasefire-4d0ffae8)
> [国内株式市場見通し：中東情勢正常化織り込む中で、AI一極 ...](https://kabutan.jp/news/marketnews/?b=n202606200100)
> [JUNE (雑誌)](https://ja.wikipedia.org/wiki/JUNE_%28%E9%9B%91%E8%AA%8C%29)
> [米国株式市場＝3日続伸、ダウ最高値 米イラン覚書合意と原油 ...](https://jp.reuters.com/markets/japan/PZQE3RWUTVO4FL4O2NLSMILQKE-2026-06-15/)
> [What the US-Iran deal means for the rest of the Middle East ...](https://www.atlanticcouncil.org/dispatches/what-the-us-iran-deal-means-for-the-rest-of-the-middle-east-and-beyond/)
> [JUNE（ジューン） | CHARACTER](https://si-vis.live/character/june.html)
> [Iran Update Special Report, June 16, 2026](https://understandingwar.org/research/middle-east/iran-update-special-report-june-16-2026/)
> [JUNE](https://june-official.com/)
> [What the Trump-Iran agreement says about Lebanon ...](https://www.aljazeera.com/news/2026/6/18/what-the-trump-iran-14-point-plan-says-about-lebanon-hormuz-and-uranium)
> [JUNE | ソニーミュージックオフィシャルサイト](https://www.sonymusic.co.jp/artist/JUNE/)
> [June](https://en.wikipedia.org/wiki/June)
> [2026年6月第3週号（2026年6月15日発行）](https://www.amova-am.com/files/market/watch/weekly-market.pdf)
> [JUNE](https://www.stardust.co.jp/talent/sdr/june/)
> [Iran Update Special Report, June 15, 2026 US and Iranian ...](https://www.facebook.com/InstitutefortheStudyofWar/posts/iran-update-special-report-june-15-2026us-and-iranian-sources-have-expressed-div/1445329820972624/)
>
> **調整中の中東情勢と日程確認**
>
> 6月14日か15日の覚書に関して、正確な日程確認が必要です。ユーザーが覚書について触れているため、6月14日に仮合意が発表された可能性があり、16日頃に署名がなされる予定かと推測。市場反応も含め、6月15日を重点に詳細を再構築します。
>
> **調査と確認：6月の覚書および関連イベント**
>
>
> **詳細な日程と更新の再確認**
>
> 6月20日、21日の最新情報を調査する必要がある。特に、6月19日の出来事を整理し、誤った前回の記述を修正したい。ユーザーが言及した「該当日」に合わせた内容を、新しい情報に基づいた正確な記述に更新する予定。
>
> **整理された報告と混乱の解決**
>
> 6月15日には、MOUがすでに署名されたとの報告がありましたが、他方で金曜日に署名予定との記述も見られ、詳細が異なっていました。6月19日の正式署名や、スイスでのセレモニーについても確認し、進展を明確にする必要があります。
>
> **Searching June 19 US-Iran memorandum signing details**
>
> [No-fly zone for Iran talks disrupted flights at Zurich airport, authorities say](https://www.reuters.com/world/europe/no-fly-zone-iran-talks-disrupted-flights-zurich-airport-authorities-say-2026-06-21/)
> [U.S. and Iran launch direct negotiations in Switzerland](https://www.axios.com/2026/06/20/vance-iran-talks-switzerland)
> [Iranian negotiators suspend talks with US in protest over Trump threats](https://www.theguardian.com/world/2026/jun/21/us-iran-talks-jd-vance-switzerland-strait-of-hormuz-lebanon)
> [JUNE (雑誌)](https://ja.wikipedia.org/wiki/JUNE_%28%E9%9B%91%E8%AA%8C%29)
> [JUNE（ジューン） | CHARACTER](https://si-vis.live/character/june.html)
> [トランプ大統領が覚書に署名 米中央軍がイランの港湾への海上封鎖解除を発表](https://news.tv-asahi.co.jp/news_international/articles/900193221.html)
> [JUNE](https://june-official.com/)
> [JUNE | ソニーミュージックオフィシャルサイト](https://www.sonymusic.co.jp/artist/JUNE/)
> [JUNE](https://www.stardust.co.jp/talent/sdr/june/)
> [June](https://www.youtube.com/channel/UCVN0FO3W5ekwjUB2gOICIyA)
> [情報BOX：米・イラン合意の覚書、14項目の全文](https://jp.reuters.com/world/us/4X644HTHRVM5NLSGJTLE5VQTBE-2026-06-18/)
>
> **最新情報の確認と混乱の解消**
>
> 現在の時刻は6月22日月曜日、5:10 JSTですが、システムが示す日時は誤って日曜日の6月21日です。最新のイベントについて調べる必要があり、会話が中断された可能性も。6月21日のヨーロッパとアメリカの最新状況を確認し、記事の矛盾も解決したいです。
>
> **Searching for latest June 21 Iran-US talks updates**
>
> [No-fly zone for Iran talks disrupted flights at Zurich airport, authorities say](https://www.reuters.com/world/europe/no-fly-zone-iran-talks-disrupted-flights-zurich-airport-authorities-say-2026-06-21/)
> [Iranian negotiators suspend talks with US in protest over Trump threats](https://www.theguardian.com/world/2026/jun/21/us-iran-talks-jd-vance-switzerland-strait-of-hormuz-lebanon)
> [Vance says US willing to 'fundamentally transform' Iran relationship ahead of peace deal negotiations in Switzerland](https://nypost.com/2026/06/21/us-news/vance-says-us-willing-to-fundamentally-transform-iran-relationship/)
> [JUNE (雑誌)](https://ja.wikipedia.org/wiki/JUNE_%28%E9%9B%91%E8%AA%8C%29)
> [JUNE（ジューン） | CHARACTER](https://si-vis.live/character/june.html)
> [JUNE](https://june-official.com/)
> [JUNE | ソニーミュージックオフィシャルサイト](https://www.sonymusic.co.jp/artist/JUNE/)
> [JUNE](https://www.stardust.co.jp/talent/sdr/june/)
> [June](https://www.youtube.com/channel/UCVN0FO3W5ekwjUB2gOICIyA)
> [June](https://en.wikipedia.org/wiki/June)
>
> **市場反応と週末イベントについての明確化**
>
> 月曜朝、週末のイベントには会談や再閉鎖が含まれていますが、現物指数にはまだ反映されていません。市場は現在閉じており、月曜のギャップリスクが考えられます。株式指数の反応を含む具体的な修正を進めます。
>
> **Revising report with MOU details and market context**
>
> [With Lebanon ceasefire set, Trump envoy heads to Switzerland for U.S.-Iran talks | Reuters](https://www.reuters.com/world/europe/us-iran-peace-talks-postponed-clouding-prospects-lasting-truce-2026-06-19/)
> [Iranian negotiators suspend talks with US in protest over Trump threats | Iran | The Guardian](https://www.theguardian.com/world/2026/jun/21/us-iran-talks-jd-vance-switzerland-strait-of-hormuz-lebanon)
>
> **報告の注意点と事実確認**
>
> ガーディアンの記事で停戦中断について触れられているが、最新のロイター記事では中断に言及されていないため、不確定情報による混乱を避けるべきです。 ユーザーが求めた事実に基づいた内容で、20日以降の出来事をしっかり反映させつつ、信用できる情報源を使います。
>
> **トピックまとめと市場反応**
>
> 21日、US-Iran初の対話がBürgenstockで行われ、進展があったとはいえ、主要な内容は核問題でなく、実行に焦点を当てた。ガーディアンではイラン代表団が会話を中断したと報じたが、ロイターは確認していないため、慎重に記述する必要がある。
>
> **修正箇所と報告更新**
>
> ユーザーはおそらく修正箇所を求めているため、変更された段落を提供するのが最適だろう。指摘された指数水準については、過去のレポートとの一致を伝えつつ、「差し替え箇所」として新しい内容を追加することで最適化を図るべきと思う。
>
> **修正履歴の記載と引用の注意点**
>
> 「覚書」の日時整理が重要で、内訳は以下の通りです：
> - 6月14/15日に枠組み発表、米国側が署名を主張。
> - 6月17日に両大統領がデジタル署名。
> - 6月18日に議会に提出、公開。
> - 6月19日に予定されていた会談はレバノンの情勢悪化で延期、停戦
>
> **まとめと修正提案**
>
> 文書とトランプの主張に関する矛盾が見られます。覚書に関する重要な市場感度が高い内容を簡潔にまとめると、例えばレバノン操作の停止や、安全な通行といった内容が含まれます。また公式署名の日時に関しては、報道による矛盾を調整した表現に修正するべきでしょう。
>
> 思考時間: 3m 26s

## 差し替え・追加用原稿

**15日月曜日**については、「正式署名を受けて」ではなく、**週末に米国とイランの暫定合意が伝わったことを受けて**と表現するのが正確です。市場はホルムズ海峡の再開と原油供給回復を織り込み、日米株が大幅高となりました。米国ではNASDAQが3.07％、S&P500が1.65％上昇し、Brent原油は4.76％安の83.17ドルまで下落しました。したがって、この日の株高は、覚書の詳細そのものよりも、**停戦・海峡再開によるインフレ圧力低下への期待**が主因でした。([Reuters](https://www.reuters.com/business/wall-st-futures-advance-over-1-markets-cheer-iran-deal-2026-06-15/?utm_source=chatgpt.com))

**17日水曜日**には、「米国とイラン・イスラム共和国との間のイスラマバード了解覚書」が正式に署名され、米政府が14項目の内容を公表しました。主な内容は、レバノンを含む全戦線での軍事行動終了、60日以内の最終合意交渉、米国によるイラン港湾封鎖の解除、イランによるホルムズ海峡の安全かつ無料の通航確保、イラン産原油への制裁適用除外、核兵器を開発しないとの確認などです。ただし、濃縮ウランの処分や恒久的な制裁解除といった核心部分は最終交渉に先送りされました。この日の米国株は覚書よりもFOMCのタカ派的内容に反応し、S&P500とNASDAQはそれぞれ1％を超えて下落しました。([Reuters Japan](https://jp.reuters.com/world/us/4X644HTHRVM5NLSGJTLE5VQTBE-2026-06-18/))

**18日木曜日**は、覚書署名による中東情勢の改善期待が下支えとなる一方、株式市場の直接的な上昇要因は半導体株でした。NASDAQは1.91％上昇し、フィラデルフィア半導体指数は6.4％高となりました。Brent原油は一時、開戦直後以来の安値圏まで下落しましたが、合意履行への疑念から終値では79.85ドルと小幅高でした。つまり市場は、覚書を全面的な和平ではなく、**供給正常化の可能性を高める暫定的な枠組み**として評価していました。([Reuters](https://www.reuters.com/business/wall-st-futures-bounce-back-us-iran-deal-optimism-balances-hawkish-fed-intel-up-2026-06-18/?utm_source=chatgpt.com))

**19日金曜日**には、覚書履行の具体的な動きとして、ホルムズ海峡の船舶交通に回復の兆しが見られました。18日には商船25隻が通過し、4月18日以来の多さとなったほか、19日には少なくとも4隻のタンカーが海峡に入り、日本企業保有のタンカーも覚書署名後初めて通過しました。ただし、紛争前の通常水準である1日約120隻には遠く、イラン側は船舶に通航許可を求めていました。Brent原油は週間で約8％下落しました。([Reuters Japan](https://jp.reuters.com/world/us/6SRDOB4SABNSBPBWYZIJMCP5ZE-2026-06-19/))

## 6月20日・21日の週末レビュー

**20日土曜日**には、覚書の履行を巡る不安が急速に再燃しました。イラン革命防衛隊は、イスラエルによるレバノン攻撃と、米国が覚書第1項の停戦義務を履行していないことを理由に、ホルムズ海峡の「再封鎖」を宣言しました。一方、米中央軍は同日に商船55隻が海峡を通過し、1,700万バレル以上の石油が輸送されたと発表しています。したがって、**イランの封鎖宣言と実際の船舶通航には乖離があり、完全封鎖が物理的に実現していたとは断定できません**。同日、停戦発効後もイスラエル軍がレバノンを攻撃し、レバノン側発表では20人が死亡しました。([Reuters Japan](https://jp.reuters.com/world/security/NNBZLCZ77VLMXF5AKRNCNWNH2E-2026-06-20/))

同日には、最終合意に向けた協議のため、イランのガリバフ国会議長やアラグチ外相らの代表団がスイスに到着し、バンス米副大統領も現地入りしました。協議には仲介国のパキスタンとカタールが参加しましたが、ホルムズ海峡とレバノン停戦の履行問題が、核問題に先立つ争点となりました。([Reuters Japan](https://jp.reuters.com/world/security/NNBZLCZ77VLMXF5AKRNCNWNH2E-2026-06-20/))

**21日日曜日**、米国とイランはスイスのビュルゲンシュトックで協議を実施しました。イラン側は、米国がレバノンでの停戦を保証できていないとして、協議を覚書の履行問題に限定し、核開発などの実質論は扱わない方針を示しました。バンス副大統領はレバノンでの敵対行為終了に向け一定の進展があったとしましたが、トランプ大統領は、イランがヒズボラを抑制しなければイランへの攻撃を再開すると警告しました。イランのタスニム通信は、これに反発したイラン代表団が協議会場を離れたと報じており、最終合意への明確な前進は確認されていません。([Reuters Japan](https://jp.reuters.com/world/security/QEAGN7OJ4ZOAHD34SYFVHKTP5I-2026-06-21/))

またイラン側は、①レバノン停戦の順守と、②イラン産原油の販売を認める米国の制裁適用除外が実施されるまで、ホルムズ海峡を再開しないとの条件を示しました。レバノンでは20日夕方以降、大規模攻撃が止まったとされていますが、イスラエルは南部レバノンの緩衝地帯から撤退せず、脅威に対する行動の自由を維持するとしています。停戦は維持されているものの、構造的な対立は解消していません。([Reuters](https://www.reuters.com/world/middle-east/irans-tasnim-news-agency-says-hormuz-will-not-reopen-until-lebanon-ceasefire-2026-06-21/))

## 見通し部分の修正版

週末の動きを踏まえると、今週の中東情勢については、先週末時点の「和平合意による供給正常化」という見方をやや後退させる必要があります。注目点は外交上の発言より、**実際のホルムズ海峡通航隻数、米国によるイラン産原油の制裁適用除外、レバノンでの停戦継続**の三つです。

海峡の実際の船舶交通が維持され、原油販売の適用除外が実施されれば、原油価格の上昇は限定的となり、株式市場への影響も抑えられる可能性があります。反対に、船舶の通航停止が確認される、またはレバノンで大規模攻撃が再開される場合は、原油高、インフレ期待の上昇、長期金利上昇を通じて、半導体など高バリュエーション株の調整要因となります。週末は日米の現物株式市場が休場だったため、これらのニュースに対する株価指数の反応は週明け市場で確認する必要があります。

**結論は、「先週は覚書への期待でリスクオンとなったが、週末には履行能力と当事者間の解釈の違いが露呈した。今週は覚書の存在ではなく、実際に履行されるかどうかが相場を左右する」とまとめると明確です。**

- [Reuters](https://www.reuters.com/world/asia-pacific/us-disputes-iranian-claims-about-closing-strait-hormuz-negotiators-head-2026-06-20/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/middle-east/irans-tasnim-news-agency-says-hormuz-will-not-reopen-until-lebanon-ceasefire-2026-06-21/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/middle-east/israeli-soldiers-lebanon-are-free-take-action-if-under-threat-israels-katz-says-2026-06-21/?utm_source=chatgpt.com)

---

**Sources:**

- [Wall Street rallies, Dow ends with record on US-Iran deal, oil price slide](https://www.reuters.com/business/wall-st-futures-advance-over-1-markets-cheer-iran-deal-2026-06-15/?utm_source=chatgpt.com)
- [情報BOX：米・イラン合意の覚書、14項目の全文 | ロイター](https://jp.reuters.com/world/us/4X644HTHRVM5NLSGJTLE5VQTBE-2026-06-18/)

## Response:
2026/6/22 5:17:32

前回内容を一本化し、6月15〜19日の各日と20・21日の週末動向、覚書、今週の注目材料を5分用原稿に再構成します。指数水準・時刻・数値は一次資料と主要報道で照合します。

覚書は合意公表、17日の正式署名・内容公開、20〜21日の履行不安再燃に分け、封鎖宣言と実際の通航状況の乖離も明示します。週末材料は現物株未反映のため、レビューと週明けリスクを切り分けます。

> **Searching current market and geopolitical updates**
>
>
> **考慮しつつ、ユーザーの求める情報を更新**
>
> レポートの更新が求められています。日々の出来事、週末の動向、今後のイベントをしっかり確認して、データに基づいた包括的な更新を目指すべきです。詳細な株価や企業ニュースを反映しつつ、必要な部分に引用を入れて進めます。
>
> **検索して東京市場の最新情報を確認**
>
>
> **広範囲に検索する必要がある**
>
> 次に進むために、より広い範囲で検索を行います。関連する情報を広く集めて、ユーザーに必要なデータをしっかり提供するために、情報の網羅性を高めます。
>
> **Nikkei indexの情報を検索中**
>
> [Japan's Nikkei Closes Above 70000 for First Time](https://www.barrons.com/livecoverage/stock-market-news-today-061826/card/japan-s-nikkei-closes-above-70000-for-first-time-axOE0tJ1e5aU6095ZY1i)
> [Japan's Nikkei tops 67000 on AI boost; SoftBank becomes ...](https://www.reuters.com/world/asia-pacific/japans-nikkei-tops-67000-first-time-ai-boost-softbank-becomes-japans-most-2026-06-01/)
> [Japan's Nikkei tops 70000 for first time, bonds drop after ...](https://www.reutersconnect.com/item/japans-nikkei-tops-70000-for-first-time-bonds-drop-after-boj-hikes-as-expected/dGFnOnJldXRlcnMuY29tLDIwMjY6bmV3c21sX1ZBOTM5NjE2MDYyMDI2UlAx)
> [June 15, 2026 Report: Nikkei 225 at 69317 Yen, a Record- ...](https://note.com/youpapa_7777/n/n1f31ee9560b3?hl=en)
> [Reuters](https://www.facebook.com/Reuters/)
> [Nikkei Stock Average Hits New Intraday High, Briefly ...](https://www.youtube.com/watch?v=qWt2eZD1hHA)
> [Reuters](https://en.wikipedia.org/wiki/Reuters)
> [Nikkei 225 breaks 70000 on hopes for peace and after rate ...](https://www.japantimes.co.jp/business/2026/06/16/markets/nikkei-70000-first-time-june/)
> [Japan's Nikkei closes at record high near 70000 on AI boost](https://www.arabnews.jp/en/business/article_172332/)
> [Reuters (@reuters) · London](https://www.instagram.com/reuters/?hl=en)
> [Japan's Nikkei to set record 69000 in 2027 as blistering ...](https://www.investing.com/news/stock-market-news/japans-nikkei-to-set-record-69000-in-2027-as-blistering-rally-outpaces-peers-reuters-poll-4711008)
> [Thomson Reuters: Purpose-built technology](https://www.thomsonreuters.com/en)
> [日経平均は小幅に4日続伸、最高値更新し一時7万円 日銀会合 ...](https://jp.reuters.com/markets/japan/L5UBWNKFL5N4HBFYBBHTAJQHUY-2026-06-16/)
> [Reuters (@Reuters) / Posts / X](https://x.com/Reuters)
>
> **報告書作成に向けての情報収集**
>
> 最終報告書のために、信頼できる過去の指数データや企業ニュースを整理して集める必要があります。まず、2026年6月15日から19日の週と、6月20日、21日の週末のデータを探します。Yahoo Financeや他の正式な情報源で確認して、正確な値をテーブルに整理します。
>
> **Searching historical index values and corporate news**
>
> [日経平均は大幅に3日続伸、最高値 米イラン和平合意でリスク ...](https://jp.reuters.com/markets/japan/O3UHKFRAOVNUNJ63DU3EOAI7AU-2026-06-15/)
> [2026年 年間カレンダー](https://micronix-jp.com/file-download/calendar/2026_jp.pdf)
> [2026夏アニメまとめ一覧｜来期7月放送開始 新作アニメ・再 ...](https://www.animatetimes.com/tag/details.php?id=5806)
> [2026年](https://ja.wikipedia.org/wiki/2026%E5%B9%B4)
> [2026年度 年間カレンダー](https://www.oitaplaza.jp/japanese/wp-content/uploads/2025/01/9d67720693aa8b2f08de379fbb72bccf.pdf)
> [2026年（令和8年）カレンダー(祝日・六曜・月齢)](https://www.benri.com/calendar/)
> [2026年は何があるの？ 予定される注目のトピックスを総覧！](https://yslappsmedia.chex.jp/column/2026-002/)
> [Amazon.co.jp: 2026](https://www.amazon.co.jp/2026/s?k=2026)
> [未来年表 : 分野検索 経済 2026年](https://seikatsusoken.jp/futuretimeline/search_category.php?category=6&year=2026)
> [今年のこよみ 令和 8年 2026](https://eco.mtk.nao.ac.jp/koyomi/cande/cal/calendar2026.pdf)
>
> **情報収集のためにReutersを確認**
>
> Reutersの日次ページを開いて、必要な詳細を確認することで、正確な情報を集める必要があります。具体的には、18ページに関する情報も検索してみます。
>
> **検索 Reuters の市場関連ページ**
>
> [日経平均は6日続伸、初の7万1000円 タカ派FOMCでもAI株 ...](https://jp.reuters.com/markets/japan/CVUMZLNGL5KRPDLO5OYN54KV4M-2026-06-18/)
>
> **アメリカの最新情報を検索**
>
> 次に進んで、アメリカの日次ページを正確に探す必要があります。記事のタイトルを活用し、Reutersの結果や他の信頼できる情報源を使用して、詳細なデータを集めます。
>
> **検索中の米国株式市場関連記事**
>
> [最新米国マーケットニュース](https://jp.reuters.com/markets/us/)
>
> **Reutersのアメリカ市場情報を確認**
>
> 面白い要約ですが、何も使われていないようですね。大丈夫です。次は、Reutersのアメリカ市場ページを開いて、記事リンクをクリックして詳細を確認する必要があります。それでは、アクセスしてみますね。
>
> **Reuters US市場ページを開いて記事リンクをクリック**
>
> [米国マーケット | 最新米国マーケットニュース | ロイター](https://jp.reuters.com/markets/us/)
>
> **記事リンクを確認する**
>
> アメリカの正確なデータを得るために、ページ内の記事リンクをクリックする必要があります。ID 90、87、67、そして67の記事をクリックして、詳細情報を確認していきますね。69番の記事が市場のまとめ情報かもしれませんので、そちらも確認します。
>
> **クリックしてデータ取得の実行**
>
> [米国株式市場＝3日続伸、ダウ最高値　米イラン覚書合意と原油安で | ロイター](https://jp.reuters.com/markets/japan/PZQE3RWUTVO4FL4O2NLSMILQKE-2026-06-15/)
>
> **確認するために詳細を探す**
>
> アメリカのイベントに関しては十分な情報がありますが、15-18日の正確な数字を確認する必要があります。前回のレポートにおそらく合っている数字がありますが、完璧を期すために、正確な終値やパーセンテージを確認しましょう。記事の後半に表があれば、それを使って確認します。
>
> **確認するためのダウ株30種の最新情報**
>
> [米国株式市場＝3日続伸、ダウ最高値　米イラン覚書合意と原油安で | ロイター](https://jp.reuters.com/markets/japan/PZQE3RWUTVO4FL4O2NLSMILQKE-2026-06-15/)
>
> **12日の情報の確認**
>
> 12日の終了値を確認する必要があるかもしれません。前回のデータが使えるかもしれませんが、念のため12日の終了値を検索して、正確な数字を確認しておきたいです。
>
> **Searching June 12, 2026 US stock market data**
>
> [SpaceX gets investment-grade ratings with stable outlook from top agencies](https://www.reuters.com/business/media-telecom/spacex-gets-investment-grade-ratings-with-stable-outlook-top-agencies-2026-06-18/)
> [米国株式市場＝続伸、スペースXがナスダック上場 米イラン ...](https://jp.reuters.com/markets/world-indices/JG2PS5NUZRMXZLJRCCBMSMPFTM-2026-06-12/)
> [JUNE (雑誌)](https://ja.wikipedia.org/wiki/JUNE_%28%E9%9B%91%E8%AA%8C%29)
> [JUNE（ジューン） | CHARACTER](https://si-vis.live/character/june.html)
> [JUNE](https://june-official.com/)
> [JUNE | ソニーミュージックオフィシャルサイト](https://www.sonymusic.co.jp/artist/JUNE/)
> [US markets mostly up as 2026 trading begins | REUTERS](https://www.youtube.com/watch?v=qAv7PfTafWI)
> [June](https://en.wikipedia.org/wiki/June)
>
> **確認する署名と合意のタイムライン**
>
> [US and Iran sign ceasefire agreement, details remain unclear | Reuters](https://www.reuters.com/world/asia-pacific/iran-us-agree-halt-war-reopen-hormuz-sending-oil-prices-tumbling-2026-06-15/)
>
> **確認すべき矛盾について**
>
> 6月15日の記事では「署名された覚書」とありますが、金曜日の正式な儀式も記載されています。6月20日の記事では「暫定合意が水曜日に署名された」とありますが、正式な署名は水曜日に行われたのでしょうか？6月17日の14項目暫定合意が署名されたという詳細を確認する必要がありそうです。
>
> **調べる：6月契約の矛盾と署名詳細**
>
> [White House sends text of interim US-Iran agreement to US Congress | Reuters](https://www.reuters.com/world/middle-east/white-house-sends-text-interim-us-iran-agreement-us-congress-2026-06-18/)
> [日経平均は6日続伸、初の7万1000円　タカ派ＦＯＭＣでもＡＩ株高継続 | ロイター](https://jp.reuters.com/markets/japan/CVUMZLNGL5KRPDLO5OYN54KV4M-2026-06-18/)
>
> **確認すべき厳密な日程**
>
> ユーザーからの更新リクエストに基づき、「今週の注目イベントや見通し」など、公式のスケジュールを確認する必要があります。各イベントの日程を再確認するため、BOJ、Fed、PCEなど、必要な情報を調べて、正式な発表や時間について検証します。
>
> **Searching official schedules for upcoming events**
>
> [2026年（令和8年）カレンダー(祝日・六曜・月齢)](https://www.benri.com/calendar/)
> [The Fed - 2026 Stress Test Scenarios](https://www.federalreserve.gov/publications/2026-stress-test-scenarios.htm)
> [Release Schedule | U.S. Bureau of Economic Analysis (BEA)](https://www.bea.gov/news/schedule)
> [Micron Technology to Report Fiscal Third Quarter Results on ...](https://investors.micron.com/news-releases/news-release-details/micron-technology-report-fiscal-third-quarter-results-june-24)
> [2026年 年間カレンダー](https://micronix-jp.com/file-download/calendar/2026_jp.pdf)
> [2026年](https://ja.wikipedia.org/wiki/2026%E5%B9%B4)
> [2026年は何があるの？ 予定される注目のトピックスを総覧！](https://yslappsmedia.chex.jp/column/2026-002/)
> [2026年度 年間カレンダー](https://www.oitaplaza.jp/japanese/wp-content/uploads/2025/01/9d67720693aa8b2f08de379fbb72bccf.pdf)
>
> **BOJの公式スケジュール再確認**
>
> 今の検索データを見てみたけれど、BOJの公式スケジュールはまだ確認できていないみたい。どうやらもう少し検索して、正式な情報を手に入れないといけないね。再度確認してみる。
>
> **Bank of Japanの2026年6月予定の検索**
>
> [Bank of Japan raises its key interest rate to a three-decade high of 1%, citing inflation](https://apnews.com/article/7646f3c0e0d30ef6c75925b5eecc9014)
> [Bank of Japan raises rates to 1% for first time since 1995](https://www.ft.com/content/1e887867-8533-423b-977c-c019759f7787)
> [Bank of Japan Lifts Rates to 31-Year High](https://www.wsj.com/economy/central-banking/bank-of-japan-lifts-rates-to-31-year-high-a19871eb)
> [BOJ flags risk of inflation overshoot, signals rate-hike intent](https://www.reuters.com/world/asia-pacific/boj-continue-raising-rates-with-eye-inflation-risk-deputy-governor-says-2026-06-19/)
> [Brent crude falls to three-month low below $80 as Iranian oil tankers 'resume shipping' - as it happened](https://www.theguardian.com/business/live/2026/jun/16/japan-hikes-interest-rates-inflation-iran-war-thames-water-rescue-nationalisation-latest-news-updates)
> [[PDF] Key Features of Japan's Final Demand-Intermediate Demand Price ...](https://www.boj.or.jp/en/research/brp/ron_2026/data/ron260406a.pdf)
> [Japan Interest Rate](https://tradingeconomics.com/japan/interest-rate)
> [Bank of Japan Meeting Calendar](https://www.mnimarkets.com/calendars/bank-of-japan-meeting-calendar)
> [Bank of Japan Meetings Explained | Everything you need](https://www.forex.com/en-sg/central-banks/bank-of-japan-meeting/)
> [BOJ signals possible June rate hike amid inflation risks ...](https://www.japantimes.co.jp/business/2026/05/12/economy/boj-april-summary-opinion-interest-rate/)
> [Japan BoJ Summary of Opinions](https://www.finlogix.com/calendar/jp/boj-summary-of-opinions)
> [Bank of Japan Decision in June?](https://polymarket.com/event/bank-of-japan-decision-in-june)
>
> **市場レポートの統合**
>
> ユーザーが求めるのは、各社のレポートやニュースの更新。ここでは、売り手からの報告書や資金の流れを迅速にまとめる必要があると感じます。時間が限られているので、簡潔に市場報告と関連するイベントを提供し、事実チェックも忘れずに行います。
>
> **Searching for sell-side reports and fund flows**
>
> [US equity fund inflows surge on Iran deal, tech draws record weekly investments](https://www.reuters.com/business/us-equity-fund-inflows-surge-iran-deal-tech-draws-record-weekly-investments-2026-06-19/)
>
> **進行中の整理と選定**
>
> ユーザーは「各社のレポート」を求めており、過去の内容に基づき、特定の機関の見解を選ぶ必要があります。Wells Fargo、JPMorgan、Nomuraのレポートを含めるといいかも。加えて、MicronやIntelなどの企業ニュースも簡潔にまとめて、5分間のスクリプトに組み込みます。
>
> **検索企業レポートと関連ニュース**
>
> [Trump says Apple to partner with Intel on US chip design, production](https://www.reuters.com/business/trump-says-apple-work-with-intel-manufacture-chips-us-2026-06-18/)
> [JUNE (雑誌)](https://ja.wikipedia.org/wiki/JUNE_%28%E9%9B%91%E8%AA%8C%29)
> [JUNE（ジューン） | CHARACTER](https://si-vis.live/character/june.html)
> [JUNE](https://june-official.com/)
> [JUNE | ソニーミュージックオフィシャルサイト](https://www.sonymusic.co.jp/artist/JUNE/)
> [June](https://en.wikipedia.org/wiki/June)
>
> **最終報告の準備**
>
> 現在の日付は2026年6月21日（日曜日）。ユーザーからの更新報告依頼に基づき、6月20日（土）-21日（日）を反映した最新の市場報告を含め、5分間の発表用スクリプトをまとめます。表を簡潔に入れつつ、必要な情報や引用を盛り込みます。
>
> 思考時間: 8m 52s

# 先週の株式市場レポート更新版  
**対象：2026年6月15日～21日／日本時間6月22日早朝時点**

> 21日に始まった米・イランのスイス協議は継続中で、妥結・決裂のいずれも確認されていません。20～21日のニュースは、19日の現物株終値には未反映です。([Reuters](https://www.reuters.com/world/europe/us-vp-vance-arrives-switzerland-peace-talks-with-iran-2026-06-21/?utm_source=chatgpt.com))

## 発表用原稿〔約5分〕

先週の株式市場は、**米国・イラン間の覚書を巡る和平期待、日銀の追加利上げ、FRBのタカ派化、AI・半導体株への資金集中**の四点で整理できます。

週間では、日経平均が7.92％上昇して7万1,250円、TOPIXが4.20％上昇して4,045ポイントでした。米国は19日がJuneteenthで休場だったため4営業日ですが、S&P500は0.93％、NASDAQは2.43％、ダウは0.71％上昇しました。日経平均がTOPIXを、NASDAQがダウを大きく上回っており、指数上昇がAI・半導体など一部の大型株に集中した一週間でした。([Reuters Japan](https://jp.reuters.com/markets/japan/WN66FNHDLBOOTCAKKAINGRIBSU-2026-06-19/?utm_source=chatgpt.com))

**15日月曜日**は、週末に米国・イラン間の暫定合意と覚書署名が公表され、ホルムズ海峡の再開と原油供給正常化への期待が一気に高まりました。Brent原油は4.8％下落し、インフレ懸念の後退から日経平均は4.99％高の6万9,317円、TOPIXは3.03％高となりました。米国でもダウが0.92％、S&P500が1.65％、NASDAQが3.07％上昇しました。半導体株が買われる一方、Rokuを220億ドルで買収すると発表したFoxは16.8％下落し、M&Aの価格妥当性が厳しく評価されました。([Reuters](https://www.reuters.com/world/middle-east/trump-vance-irans-parliament-speaker-signed-mou-2026-06-15/?utm_source=chatgpt.com))

**16日火曜日**、日銀は政策金利を0.75％から1.00％へ引き上げました。決定は7対1で、政策金利は1995年以来の水準となりました。ただし、追加利上げを急がないとの見方もあり、日経平均は0.13％高の6万9,405円を維持し、TOPIXは0.21％安でした。米国では前日の半導体株高に反動が出て、金融・資本財へのローテーションが進みました。ダウは0.64％高となる一方、S&P500は0.57％安、NASDAQは1.15％安、半導体指数は5.7％下落しました。([情報処理推進機構](https://www.boj.or.jp/en/mopo/mpmdeci/mpr_2026/k260616a.pdf?utm_source=chatgpt.com))

**17日水曜日**には、15日の覚書署名公表に続き、米国・イラン両大統領による停戦合意への署名が確認されました。覚書は、戦闘停止、ホルムズ海峡の商船通航、60日間の最終合意交渉を柱としています。一方、核問題、制裁解除、レバノン停戦の履行順序などは残されました。日本株は日経平均が0.72％、TOPIXが0.55％上昇しました。([Reuters](https://www.reuters.com/world/middle-east/g7-leaders-demand-ceasefire-lebanon-welcome-iran-deal-2026-06-17/?utm_source=chatgpt.com))

同日のFOMCは政策金利を3.50～3.75％に据え置きましたが、2026年末の政策金利予想中央値を3.4％から3.8％へ、PCEインフレ予想を2.7％から3.6％へ引き上げました。市場は「次の政策変更が利上げとなる可能性」を意識し、ダウは約0.98％、S&P500は1.21％、NASDAQは1.34％下落しました。中東の覚書よりも、FRBのタカ派化が株価を支配した一日でした。([連邦準備制度](https://www.federalreserve.gov/monetarypolicy/fomcprojtabl20260617.htm))

**18日木曜日**は、覚書による中東情勢改善への期待に加え、半導体株が急反発しました。日経平均は1.65％高の7万1,053円と、初めて7万1,000円台で終了しました。米国ではS&P500が1.08％、NASDAQが1.91％上昇し、半導体指数は6.4％高となりました。Appleとの米国内半導体協業が発表されたIntelは10.6％上昇しました。政策金利上昇への警戒は残ったものの、AI関連企業の業績期待が再び優勢となりました。([バロンズ](https://www.barrons.com/livecoverage/stock-market-news-today-061826/card/japan-s-nikkei-closes-above-70000-for-first-time-axOE0tJ1e5aU6095ZY1i?utm_source=chatgpt.com))

**19日金曜日**、日経平均は7日続伸して0.28％高の7万1,250円となり、一時は7万2,000円に接近しました。しかしTOPIXは0.57％安でした。半導体など日経平均への寄与度が高い少数銘柄が指数を押し上げる一方、銀行や内需株では利益確定売りが出ており、相場の裾野は狭くなっていました。米国株はJuneteenthで休場でした。([Reuters Japan](https://jp.reuters.com/markets/japan/WN66FNHDLBOOTCAKKAINGRIBSU-2026-06-19/?utm_source=chatgpt.com))

中東情勢では、同日に予定されていたスイスでの協議がいったん延期され、バンス副大統領の参加取りやめも伝えられました。これにより、覚書が実際に履行されるかという疑念が再び強まりました。([Reuters](https://www.reuters.com/world/asia-pacific/switzerland-says-us-iran-talks-planned-friday-are-off-2026-06-19/?utm_source=chatgpt.com))

**20日土曜日**には、イラン革命防衛隊が、レバノンでの停戦違反などを理由としてホルムズ海峡の再封鎖を宣言しました。一方、米中央軍は多数の船舶が実際には海峡を通航していると説明しました。したがって、政治・軍事上の「封鎖宣言」と、現実の船舶交通には乖離があり、現時点で物理的な完全封鎖とは断定できません。トランプ大統領は攻撃再開の可能性にも言及し、地政学的リスクが再び上昇しました。([Reuters](https://www.reuters.com/world/asia-pacific/trump-envoy-iranian-minister-head-switzerland-talks-2026-06-20/?utm_source=chatgpt.com))

**21日日曜日**、バンス副大統領がスイスに到着し、米国・イラン間の高官協議が始まりました。協議は数日間続く見込みです。イラン側に近い情報源は、レバノン停戦の履行と、イラン産原油を販売できる制裁適用除外が実施されるまで、海峡を再開しないとの条件を示しています。日本時間22日早朝時点では、最終合意や協議決裂は確認されていません。([Reuters](https://www.reuters.com/world/middle-east/irans-tasnim-news-agency-says-hormuz-will-not-reopen-until-lebanon-ceasefire-2026-06-21/?utm_source=chatgpt.com))

また国内では、政府が2040年までに17の戦略分野で約2.3兆ドル、円換算で約370兆円の官民投資を目標とする成長戦略を策定するとの報道がありました。正式発表されれば、AI・半導体、エネルギー、インフラ関連株への中期的な材料となります。([Reuters](https://www.reuters.com/world/asia-pacific/japan-target-23-trillion-public-private-investment-by-2040-nikkei-reports-2026-06-20/?utm_source=chatgpt.com))

証券会社の見通しでは、Wells Fargoが2026年末のS&P500目標を7,300から7,950へ、EPS予想を315ドルから340ドルへ引き上げました。Goldman Sachsも年末目標を8,000としています。一方、5月末のReuters調査における日経平均の2026年末予想中央値は6万2,800円で、現在値はこれを約13％上回っています。米国株の業績見通しは強いものの、日本株については上昇速度が従来の予想を大幅に上回っており、バリュエーションとポジションの過熱には注意が必要です。([Reuters](https://www.reuters.com/business/wells-fargo-raises-sp-500-target-stronger-earnings-outlook-2026-06-16/?utm_source=chatgpt.com))

今週は、第一に**ホルムズ海峡を実際に何隻の船舶が通航するか**、第二に**原油価格とタンカー保険料が再上昇するか**、第三に**レバノン停戦と制裁適用除外が履行されるか**が重要です。声明よりも実際の物流データを確認する必要があります。

金融政策では、24日の日銀「主な意見」と25日の米PCE物価指数が焦点です。企業面では25日早朝のMicron決算が、HBM、DRAM価格、AIサーバー需要の持続性を測る重要な材料となります。

結論として、先週は**覚書への期待、原油安、AI・半導体株高によるリスクオン**でした。しかし週末には、覚書の解釈と履行を巡る対立が表面化しました。今週は「覚書が存在するか」ではなく、**海峡の通航、停戦、制裁緩和が実際に履行されるか**が株式市場を左右します。相場の基調は強い一方、上昇が半導体株に集中しているため、中東情勢やインフレ指標が悪化した場合の反動も大きくなりやすい状況です。

---

## 各日の主要株価指数

| 日付 | 日経平均 | TOPIX | ダウ | S&P500 | NASDAQ |
|---|---:|---:|---:|---:|---:|
| 6月15日 | 69,317.50<br>**+4.99%** | 3,999.60<br>**+3.03%** | 51,671.03<br>**+0.92%** | 7,554.29<br>**+1.65%** | 26,683.94<br>**+3.07%** |
| 6月16日 | 69,404.50<br>**+0.13%** | 3,991.14<br>**-0.21%** | 51,999.67<br>**+0.64%** | 7,511.35<br>**-0.57%** | 26,376.34<br>**-1.15%** |
| 6月17日 | 69,902.25<br>**+0.72%** | 4,013.23<br>**+0.55%** | 51,492.55<br>**-0.98%** | 7,420.10<br>**-1.21%** | 26,021.66<br>**-1.34%** |
| 6月18日 | 71,053.49<br>**+1.65%** | 4,068.18<br>**+1.37%** | 51,564.70<br>**+0.14%** | 7,500.58<br>**+1.08%** | 26,517.93<br>**+1.91%** |
| 6月19日 | 71,250.06<br>**+0.28%** | 4,044.96<br>**-0.57%** | 休場 | 休場 | 休場 |
| **週間** | **+7.92%** | **+4.20%** | **+0.71%** | **+0.93%** | **+2.43%** |

日本株の終値は各日の東京市場、米国株の週間騰落率は6月12日終値から18日終値までで計算しています。([バロンズ](https://www.barrons.com/livecoverage/stock-market-news-today-061526/card/japan-s-nikkei-soars-to-record-high-D3iKYzXzlw6D6bdScC6Q?utm_source=chatgpt.com))  
米国株の終値はReutersおよびAPの公表値に基づきます。([The Washington Post](https://www.washingtonpost.com/business/2026/06/15/wall-street-stocks-dow-nasdaq/cb9f6f04-68f7-11f1-830e-133d20cadd28_story.html?utm_source=chatgpt.com))

## 今週の注目日程〔日本時間〕

| 日時 | イベント | 市場への着眼点 |
|---|---|---|
| 6月22～23日 | 米・イランのスイス協議 | ホルムズ海峡、レバノン停戦、原油制裁適用除外 |
| 6月23日 14:00 | 日銀・基調的インフレ指標 | 追加利上げ時期、銀行・不動産株、円金利 |
| 6月24日 8:50 | 日銀「金融政策決定会合における主な意見」 | 1％利上げ後の政策委員のスタンス |
| 6月25日 5:00 | FRB銀行ストレステスト結果 | 米大手銀行の資本余力、配当・自社株買い |
| 6月25日 5:30 | Micron 2026年度第3四半期決算 | HBM、DRAM価格、AI向け需要、設備投資 |
| 6月25日 21:30 | 米PCE物価・1～3月期GDP確報 | FRB利上げ観測、米長期金利、高PER株 |
| 今週中・報道ベース | 日本政府の新成長戦略 | AI・半導体、エネルギー、インフラ関連 |

日銀、FRB、Micron、BEAの公式日程に基づきます。([情報処理推進機構](https://www.boj.or.jp/en/about/calendar/index.htm?utm_source=chatgpt.com))

## 今週のシナリオ整理

**上振れシナリオ**は、ホルムズ海峡の実際の通航が継続し、原油制裁の適用除外とレバノン停戦が確認され、米PCEが落ち着き、Micronが強いガイダンスを示す場合です。この場合、半導体株を中心に最高値更新を試す可能性があります。

**下振れシナリオ**は、タンカーの実通航が止まり、原油・運賃・保険料が急上昇し、米PCEも上振れる場合です。インフレ期待と長期金利の上昇を通じて、先週上昇した半導体・AI関連株が最も大きな利益確定売りの対象となりやすいと考えられます。

**発表の締めの一文**は、次の表現が適切です。

> 「先週は覚書への期待を買う相場でしたが、今週は覚書が実際に履行されるかを確認する相場に移ります。」

- [Reuters](https://www.reuters.com/world/asia-pacific/us-disputes-iranian-claims-about-closing-strait-hormuz-negotiators-head-2026-06-20/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/europe/us-vp-vance-arrives-switzerland-peace-talks-with-iran-2026-06-21/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/middle-east/irans-tasnim-news-agency-says-hormuz-will-not-reopen-until-lebanon-ceasefire-2026-06-21/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/europe/switzerland-says-us-iran-talks-continue-brgenstock-declines-identify-2026-06-20/?utm_source=chatgpt.com)

---

**Sources:**

- [US VP Vance arrives in Switzerland for peace talks with Iran](https://www.reuters.com/world/europe/us-vp-vance-arrives-switzerland-peace-talks-with-iran-2026-06-21/?utm_source=chatgpt.com)
- [日経平均は7日続伸、半導体主導で一時最高値 TOPIXは反落](https://jp.reuters.com/markets/japan/WN66FNHDLBOOTCAKKAINGRIBSU-2026-06-19/?utm_source=chatgpt.com)
- [1 June 16, 2026 Bank of Japan Change in the Guideline ...](https://www.boj.or.jp/en/mopo/mpmdeci/mpr_2026/k260616a.pdf?utm_source=chatgpt.com)
- [The Fed - June 17, 2026: FOMC Projections materials, accessible version](https://www.federalreserve.gov/monetarypolicy/fomcprojtabl20260617.htm)
- [Japan's Nikkei Closes Above 70000 for First Time](https://www.barrons.com/livecoverage/stock-market-news-today-061826/card/japan-s-nikkei-closes-above-70000-for-first-time-axOE0tJ1e5aU6095ZY1i?utm_source=chatgpt.com)
- [How major US stock indexes fared Monday 6/15/2026](https://www.washingtonpost.com/business/2026/06/15/wall-street-stocks-dow-nasdaq/cb9f6f04-68f7-11f1-830e-133d20cadd28_story.html?utm_source=chatgpt.com)



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)