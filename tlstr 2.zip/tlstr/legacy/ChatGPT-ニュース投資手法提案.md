# ニュース投資手法提案

**User:** Anonymous  
**Created:** 5/7/2026 21:20:41  
**Updated:** 5/7/2026 22:12:38  
**Exported:** 5/7/2026 22:22:37  
**Link:** [https://chatgpt.com/c/69fc8324-737c-83aa-8b8d-799580b29d3d](https://chatgpt.com/c/69fc8324-737c-83aa-8b8d-799580b29d3d)  

## Response:
2026/5/7 21:20:41

> **ウェブ検索とPDF/Arxiv情報の取得**
>
> [www.fs.hub.hit-u.ac.jp](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf)
> [arxiv.org](https://arxiv.org/pdf/2010.15067)
>
> **PDF解析とarXiv ID検索**
>
> [Graph-based Topic Extraction from Vector Embeddings of ...](https://arxiv.org/abs/2010.15067)
> [Publications | Research groups](https://www.imperial.ac.uk/biomathematics-group/publications/?id=1182275&noscript=noscript&respub-t4-action=citation.html)
> [Fugu-MT 論文翻訳(概要): A Multiscale Geometric Method for ...](https://fugumt.com/fugumt/paper_check/2511.21741v1)
> [Machine Learning Oct 2020](https://www.arxiv.org/list/cs.LG/2020-10?show=2000&skip=2675)
> [Conrad D. Hougen](https://scholar.google.com/citations?hl=en&user=DDK5RxMAAAAJ)
> [au:Pazdernik_K in:cs - SciRate Search](https://scirate.com/search?q=au%3APazdernik_K+in%3Acs)
>
> **PDF内の用語検索**
>
> [www.fs.hub.hit-u.ac.jp](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf)
> [arxiv.org](https://arxiv.org/pdf/2010.15067)
>
> **PDF解析のためのスクリーンショット取得**
>
>
> **PDFファイルへのアクセスとダウンロード方法の検索**
>
> [[2511.21741] A Multiscale Geometric Method for Capturing Relational Topic Alignment](https://arxiv.org/abs/2511.21741)
>
> **HTMLクリックイベントの詳細確認**
>
>
> **Open ar5iv の安全性について調査**
>
>
> **検索モデルの特定に関する論文詳細**
>
> [www.fs.hub.hit-u.ac.jp](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf)
>
> **推論スコアを求めている**
>
> [www.fs.hub.hit-u.ac.jp](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf)
> [arxiv.org](https://arxiv.org/pdf/2010.15067)
>
> **検討中：LSEGデータの取り扱い**
>
> ユーザーからアプローチの質問あり、APIドキュメントではなくLSEGデータについて触れるべきかもしれません。データの正確性が知りたい場合、公式のLSEGの情報を参照する方が良いかも。ユーザーコンテキストを活用するか、公式ニュースを確認すべきか検討中です。
>
> **LSEGデータに関する公式情報検索**
>
> [LSEG Data Library for Python: News Pagination | Devportal](https://developers.lseg.com/en/article-catalog/article/lseg-data-library-for-python--news-pagination)
> [news.get_headlines - how to include column for RICS](https://community.developers.lseg.com/discussion/111085/news-get-headlines-how-to-include-column-for-rics)
> [LSEG Data Python Library](https://github.com/LSEG-API-Samples/Example.DataLibrary.Python/blob/lseg-data-examples/Tutorials/Python%20Quant%20Tutorials/01.%20Symbology.ipynb)
>
> **回答の構造とアプローチについて**
>
> LSEGの情報は公式なものを引用する必要がありそうですね。それに、アブストラクトを基にした回答が重要だと考えています。ユーザーに日本語で提供するため、さらに整然と分かりやすく構成し、各段落に引用を使いながらアプローチを詳細にまとめる必要があります。
>
> 思考時間: 38s

論文PDFの内容を確認し、3本を「ニュースの表現」「時系列トピック」「テーマ別投資シグナル」に分解して整理します。最後に、LSEG/Reutersニュースに対して実装しやすく、かつテーマバスケット投資に直結する設計へ落とします。

以下では、3本を「何をニュースから取り出すか」という観点で整理し、最後に **LSEG/Reutersニュース × 日本株テーマバスケット** に対する最良実装案を提示します。

## 1. 3論文の位置づけ

| 論文 | 中核手法 | ニュース投資への役割 | テーマバスケットでの使いどころ |
|---|---|---|---|
| FS-2022-J-001 | マルチレベル教師ありトピックモデル, MLSTM | ニュース・トピックが銘柄・業種・市場反応にどう効くかを教師ありで学習 | テーマ別に「どのニュース・トピックが将来リターン、売買代金、リスクに効くか」を推定 |
| arXiv:2010.15067 | 文書埋め込み + 類似度グラフ + Markov Stabilityクラスタリング | ラベルなしでニュース群から自然な話題クラスターを抽出 | テーマ名に出てこない新興トピック、メガトレンド、未定義ニュース群を検出 |
| arXiv:2511.21741 | Hellinger距離 + Ward階層クラスタリングによるマルチスケール・トピック整列 | 時間をまたいだトピックの継続・変形・希少トピックを追跡 | 「AI → 半導体 → 電力インフラ」のようなテーマ・ドリフトを時系列で追う |

結論から言うと、**単一手法ではなく、Graph-based Topic Extractionでニュース構造を作り、Multiscale Geometric Alignmentで時系列接続し、最後にMLSTM型の教師あり層で投資シグナル化する構成が最も実務向き**です。

---

## 2. 論文1：FS-2022-J-001 - MLSTMの要点

FS-2022-J-001は、ニュースを単純なポジティブ／ネガティブに縮約するのではなく、ニュースの潜在トピックを抽出し、そのトピックが複数銘柄の市場反応をどう説明するかを同時に学習するモデルです。論文では、記事に付与されたラベルを補助情報として使い、文書に割り当てられたトピックから複数の教師データを予測する構造を持ち、予測部分に銘柄間ランダム効果を導入する点が重要だと説明されています。([fs.hub.hit-u.ac.jp](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf))

モデルの骨格は、LDA/STM/sLDAの発展形です。文書ごとに潜在トピック分布を持ち、トピック分布はニュースに付与された外生ラベル、たとえば業種ダミーなどに依存します。一方、教師データ、論文では市場反応の代理変数として取引金額を用い、文書トピック比率からその教師データを予測します。([fs.hub.hit-u.ac.jp](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf))

テーマバスケット投資では、この構造を次のように置き換えるのが自然です。

| 論文上の変数 | テーマ投資での置き換え |
|---|---|
| 文書 $d$ | Reutersニュース記事 |
| ラベル $x_d$ | LSEGカテゴリ、言語、地域、テーマ辞書ヒット、構成銘柄業種、TRBC/GICS |
| グループ $j$ | 銘柄、テーマ、またはテーマ内の構成銘柄 |
| 教師データ $y_{d,j}$ | テーマバスケットの将来超過リターン、売買代金変化、出来高サプライズ、ボラティリティ、ドローダウン |
| トピック $k$ | 業績、政策、AI、半導体、金利、地政学、需給、規制、M&Aなどの潜在ニュース因子 |

特に重要なのは、**教師データを将来リターンだけにしないこと**です。ニュースの一次反応はリターンよりも売買代金・出来高・ボラティリティに出やすいため、最初は以下の3系列を教師データにするのがよいです。

$$
y^{ret}_{t,h,j} = r_{t+1:t+h,j} - r_{t+1:t+h,TOPIX}
$$

$$
y^{turnover}_{t,j}
= z\left(\log Turnover_{t:t+2,j} - MA_{20}(\log Turnover_{j})\right)
$$

$$
y^{risk}_{t,h,j}
= RV_{t+1:t+h,j}
$$

論文でも市場反応の代理として取引金額を使い、当日と前後を含む平均値をとり、市場全体の影響や過去平均との差を調整して標準化しています。テーマ投資でも、まずは **ニュース → テーマ別売買代金・出来高反応 → その後のリターン持続性** という順に設計する方が堅いです。([fs.hub.hit-u.ac.jp](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf))

---

## 3. 論文2：arXiv:2010.15067 - Graph-based Topic Extractionの要点

この論文は、ニュース記事をベクトル化し、文書間類似度からグラフを作り、Markov Stabilityというマルチスケール・コミュニティ検出で自然なトピッククラスターを抽出する手法です。あらかじめトピック数を固定せず、細かい話題から粗い話題まで複数解像度のクラスタを得られる点が強みです。([arXiv](https://arxiv.org/pdf/2010.15067))

具体的には、記事をTF-IDF、Doc2Vec、BERT、Sentence-BERTなどでベクトル化し、コサイン類似度を計算します。その後、完全な類似度行列をそのまま使うのではなく、MST-kNNでスパースな類似度グラフを構成します。MSTで全体の連結性を確保し、k近傍で局所的に似た記事同士をつなぐ、という設計です。([arXiv](https://arxiv.org/pdf/2010.15067))

この論文の実務上の重要点は、**「BERT/SBERTだけが常に最良ではない」**という点です。論文ではBERT系特徴量も評価していますが、教師なしクラスタリングでは、ファインチューニングされていないBERT埋め込みは必ずしも最適ではなく、Doc2VecやBoW/TF-IDF系が強い場合もあると述べています。([arXiv](https://arxiv.org/pdf/2010.15067))

テーマバスケット投資では、この手法を **テーマ分類の前段** に置くべきです。つまり、最初からニュースを既存テーマに押し込むのではなく、日次・週次でニュース記事群をクラスタリングし、そこから「今、自然発生しているニュース・トピック」を取り出します。

出力例は以下です。

| クラスタ | 上位語 | 代表ヘッドライン | 解釈 | 関連テーマ |
|---|---|---|---|---|
| C12 | AI, GPU, data center, electricity | データセンター電力需要 | AIインフラ | 半導体、電力設備、電線、空調 |
| C27 | BOJ, yield, regional banks | 金利上昇・銀行収益 | 金利正常化 | 地銀、保険、銀行 |
| C41 | battery, EV, China, subsidy | EV政策・価格競争 | EV供給過剰 | EV、電池、素材 |

この段階では、**投資判断ではなくニュース空間の地図を作る**のが目的です。

---

## 4. 論文3：arXiv:2511.21741 - Multiscale Geometric Topic Alignmentの要点

arXiv:2511.21741は、トピックの時間変化や希少トピックを捉えるために、テキスト情報と関係ネットワーク情報を統合し、Hellinger距離とWard法で階層的なトピック樹形図を作る手法です。著者らは、密なTransformer埋め込みだけでは希少トピックを見落としやすく、時間を通じた滑らかなトピック整列も難しいと問題提起しています。([arXiv](https://arxiv.org/abs/2511.21741))

この手法の投資応用上の価値は、**ある時点のクラスタリング結果を孤立して見ず、週次・月次でトピックがどう変形・接続・分岐しているかを追う**ことにあります。テーマ投資で重要なのは「今日AIニュースが多いか」だけではなく、「AIニュースが半導体、電力、データセンター、冷却、電線、建設、不動産へ波及しているか」です。

元論文では共著者ネットワークを使っていますが、テーマ投資では次のネットワークで代替できます。

| 元論文 | テーマ投資での代替 |
|---|---|
| co-author network | 共同言及銘柄ネットワーク |
| 文書トピック分布 | ニュースクラスタ別の語彙分布・テーマ分布 |
| 研究分野の時系列変化 | ニューステーマの週次・月次ドリフト |
| rare topic | 初期段階の新興テーマ、ニッチテーマ、未定義テーマ |

ここで使う距離は、文書・クラスタの確率分布に対して自然な **Hellinger距離** が適しています。

$$
H(p,q)
=
\frac{1}{\sqrt{2}}
\left\|
\sqrt{p} - \sqrt{q}
\right\|_2
$$

たとえば、週 $t$ のクラスタ $C_{t,a}$ と週 $t+1$ のクラスタ $C_{t+1,b}$ について、語彙分布、テーマ帰属分布、銘柄共起分布を作り、それらのHellinger距離を混合します。

$$
D(C_{t,a}, C_{t+1,b})
=
\alpha H(p^{word}_{t,a}, p^{word}_{t+1,b})
+
\beta H(p^{theme}_{t,a}, p^{theme}_{t+1,b})
+
\gamma H(p^{entity}_{t,a}, p^{entity}_{t+1,b})
$$

これにより、ニュース・トピックが「同じ話題として継続しているのか」「別テーマに波及したのか」「消滅したのか」「新しく発生したのか」を定量化できます。

---

## 5. LSEG/Reutersニュースに対する最良アプローチ

LSEG Data Library for Pythonでは、`ld.news.get_headlines` によりニュースクエリ、件数、開始・終了期間などを指定してヘッドラインをDataFrameで取得でき、`storyId` を使って本文を取得するワークフローが公式例で示されています。LSEGのニュース機能は価格、ファンダメンタル、ニュース等へ統一的にアクセスするData Libraryの一部です。([developers.lseg.com](https://developers.lseg.com/en/article-catalog/article/lseg-data-library-for-python--news-pagination?utm_source=chatgpt.com))

あなたの制約、つまり **RIC指定で大量取得するのは避けたい、Broadなニュースからテーマ全体を拾いたい** という前提では、以下の順序が最もよいです。

### 推奨パイプライン

```text
LSEG broad query
  ↓
ニュース正規化
  ↓
記事ベクトル化・語彙分布作成
  ↓
Graph-based topic extraction
  ↓
時系列 topic alignment
  ↓
テーマ帰属・テーマスコア化
  ↓
教師あり投資シグナル化
  ↓
テーマバスケット選択・リスク管理
```

### Step 1：Broad Queryでニュースを取得

RICベースではなく、以下のような広めのクエリ群を日次で回します。

| クエリ群 | 目的 |
|---|---|
| `Language:LEN AND Source:RTRS AND Topic:...` | 英語Reutersで広く取得 |
| 日本関連・日本企業関連 | 日本株テーマに関連するニュース取得 |
| Top News / sector pages | 市場で重要視されたニュース取得 |
| macro/policy/technology/energy/healthcare/finance keywords | テーマ横断ニュース取得 |
| `R:xxxx` は限定利用 | 代表銘柄・大型構成銘柄だけ補助的に使用 |

LSEGの公式サンプルでも、ニュースヘッドライン取得後に `storyId` で本文を取りに行く流れが示されています。したがって、最初はヘッドラインだけで広く取り、重要記事・重複排除後に本文を取得する二段階方式が現実的です。([developers.lseg.com](https://developers.lseg.com/en/article-catalog/article/getting-top-news-energy-headlines-and-stories-using-lseg-data-li?utm_source=chatgpt.com))

---

## 6. 特徴量設計：何をニュースから作るべきか

最終的にテーマごとに以下の特徴量を作ります。

| 特徴量 | 定義 | 投資上の意味 |
|---|---|---|
| Buzz | テーマ関連ニュース件数の異常値 | 注目度・資金流入候補 |
| Tone | FinBERT等による金融センチメント | 良い注目か悪い注目か |
| Breadth | 関連するクラスタ数・銘柄数・サブテーマ数 | テーマの広がり |
| Novelty | 過去クラスタからの距離 | 新規材料・構造変化 |
| Persistence | 同一トピックの継続週数 | 一過性かメガトレンドか |
| Drift | 近接テーマへの波及 | テーマの伝播・拡張 |
| Market reaction | 売買代金・出来高・ボラ反応 | 市場が反応しているか |
| Return follow-through | その後の超過リターン | 投資シグナルとして有効か |

重要なのは、**Buzz単独では買いシグナルにしない**ことです。ニュース件数の増加は、好材料だけでなく悪材料・不祥事・規制・地政学リスクでも発生します。したがって、最低限以下のように分解します。

$$
ThemeScore_{j,t}
=
w_1 Buzz_{j,t}
+
w_2 Tone_{j,t}
+
w_3 Breadth_{j,t}
+
w_4 Persistence_{j,t}
+
w_5 Novelty_{j,t}
+
w_6 MarketReaction_{j,t}
$$

さらに投資シグナルは、テーマスコアそのものではなく、将来リターンとの関係をウォークフォワードで推定します。

$$
\hat{r}_{j,t+1:t+h}
=
f(
Buzz_{j,t},
Tone_{j,t},
Breadth_{j,t},
Novelty_{j,t},
Persistence_{j,t},
Drift_{j,t},
MarketReaction_{j,t}
)
$$

---

## 7. 3論文を統合した最良設計

私なら、最初から完全なMLSTMを実装するのではなく、以下の3層構造にします。

## Layer A：Graph-based News Topic Map

目的は、Reutersニュースから自然発生している話題群を抽出することです。

処理は以下です。

```text
ニュース本文・見出し
→ TF-IDF / SBERT / Doc2Vec embedding
→ cosine similarity
→ MST-kNN graph
→ Markov Stability or Leiden/Louvain multi-resolution clustering
→ topic cluster
```

論文2のMarkov Stabilityを厳密実装するのはやや重いため、初期実装では **MST-kNN + Leidenのresolution sweep** で代替してよいです。論文の思想である「トピック数を固定しない」「複数解像度で見る」は維持できます。

## Layer B：Multiscale Topic Alignment

目的は、週次・月次でニューストピックの変化を追うことです。

```text
週次クラスタ
→ 語彙分布
→ テーマ帰属分布
→ 銘柄・業種共起分布
→ Hellinger distance
→ Ward linkage
→ topic lineage / dendrogram
```

ここで、以下の指標を作ります。

| 指標 | 意味 |
|---|---|
| `topic_birth` | 新規トピック発生 |
| `topic_persistence` | 継続トピック |
| `topic_split` | 既存トピックの分岐 |
| `topic_merge` | 複数トピックの統合 |
| `theme_drift` | あるテーマから別テーマへの波及 |
| `rare_topic_score` | 小さいが急浮上している話題 |

この層が、いわゆる「メガトレンドの時系列推移」を見るための中核です。

## Layer C：MLSTM-inspired Supervised Investment Layer

目的は、ニューストピックを投資シグナルに変換することです。

完全なベイズMLSTMではなく、初期実装では以下のような近似で十分です。

```text
topic exposure per theme
+ news features
+ market reaction features
→ ElasticNet / Ridge / LightGBM / hierarchical regression
→ expected excess return / turnover reaction / risk score
```

テーマ $j$ の特徴量は次のように作ります。

$$
X_{j,t}
=
[
Buzz_{j,t},
Tone_{j,t},
Breadth_{j,t},
Novelty_{j,t},
Persistence_{j,t},
Drift_{j,t},
TopicExposure_{j,t,1:K},
TurnoverShock_{j,t}
]
$$

目的変数は、短期・中期で分けます。

| 目的変数 | ホライズン | 用途 |
|---|---:|---|
| 翌週超過リターン | 5営業日 | 短期ニュース反応 |
| 翌月超過リターン | 20営業日 | テーマ選択 |
| 売買代金ショック | 0〜2営業日 | 市場注目度 |
| 実現ボラ | 5〜20営業日 | リスク制御 |
| 最大下落 | 20営業日 | 悪材料ニュース回避 |

---

## 8. テーマバスケット選択ルール

最初の実装では、複雑な最適化よりも以下がよいです。

### ニューススコア

$$
S_{j,t}
=
z(\hat{r}_{j,t})
+
0.5z(Persistence_{j,t})
+
0.5z(Breadth_{j,t})
-
0.5z(Risk_{j,t})
$$

### 除外条件

| 条件 | 理由 |
|---|---|
| Buzz急増かつTone大幅マイナス | 不祥事・規制・事故の可能性 |
| Novelty高いがPersistence低い | 一過性ニュースの可能性 |
| MarketReactionなし | 市場が無視している可能性 |
| テーマ内Breadthが低い | 1銘柄だけの材料でテーマ性が弱い |

### ポートフォリオ

```text
毎週金曜にシグナル生成
翌営業日に執行
スコア上位Nテーマを等ウェイト
テーマ内は既定ウェイトまたは等ウェイト
TOPIX beta / market beta を必要に応じて中立化
手数料・売買回転を控除
```

---

## 9. 実装上の推奨順序

### Phase 1：ニュース取得・正規化

まずは `headline`, `storyId`, `versionCreated`, `source`, `language`, `query_name`, `retrieved_at_utc`, `body` を標準化します。過去の問題として `timestamp_utc` が欠損する場合があるため、`versionCreated → retrieved_at_utc → ingestion_time` の優先順位で時刻を作るのがよいです。

### Phase 2：ニュースクラスタリング

最初は以下の2本立てで十分です。

| 方法 | 用途 |
|---|---|
| TF-IDF + NMF/LDA | 解釈性・軽量性 |
| SBERT + kNN graph + Leiden | 意味類似・言い換え対応 |

論文2・論文3の示唆を踏まえると、Transformer埋め込みだけに寄せず、**TF-IDF系の解釈可能な語彙分布を必ず残す**べきです。([arXiv](https://arxiv.org/pdf/2010.15067))

### Phase 3：テーマ帰属

テーマ定義文とニュースの単純コサイン類似だけではなく、以下の合成スコアにします。

$$
A_{d,j}
=
0.35 Sim(article, theme\_profile_j)
+
0.25 Sim(cluster, theme\_profile_j)
+
0.20 EntityOverlap(d,j)
+
0.10 KeywordHit(d,j)
+
0.10 Sector/TRBCOverlap(d,j)
$$

これにより、テーマ名そのものが記事に出ない場合でも、クラスタ全体の文脈からテーマに帰属できます。

### Phase 4：時系列整列

週次でクラスタを作り、Hellinger距離で前週クラスタと対応づけます。これにより、テーマスコアの時系列推移を「単なる件数」ではなく、「同じ話題の継続・拡張・分岐」として表現できます。

### Phase 5：投資シグナル検証

最後に、テーマ別の将来リターン・売買代金・リスクとの関係をウォークフォワードで検証します。

検証単位は以下です。

| 検証 | 内容 |
|---|---|
| IC | ニューススコアと翌週・翌月リターンの順位相関 |
| Quintile spread | 上位テーマ - 下位テーマ |
| Event study | トピック急浮上後の累積超過リターン |
| Turnover reaction | ニュース後に売買代金が増えたか |
| Persistence test | 継続トピックほどリターンが持続するか |
| Drift test | 波及テーマが後追いで上がるか |

---

## 10. 最終提案：採用すべき構成

最も推奨する構成は以下です。

```text
1. LSEG broad Reuters news取得
2. ヘッドライン・本文・時刻・query_nameを正規化
3. TF-IDF + SBERTの両方で記事特徴量を作成
4. kNN類似度グラフを作成
5. Leiden / Markov Stability型のmulti-resolution clustering
6. 各クラスタを語彙・代表記事・関連テーマで解釈
7. 週次クラスタ間をHellinger距離 + Ward法で接続
8. テーマごとにBuzz/Tone/Breadth/Novelty/Persistence/Driftを算出
9. テーマ別将来リターン・売買代金・リスクを教師データにして学習
10. 上位テーマを選択し、リスク・β・売買回転を制御して投資
```

この構成の利点は、3論文の強みを分業できることです。

| 役割 | 採用手法 |
|---|---|
| ニュース空間の発見 | arXiv:2010.15067型のグラフ・クラスタリング |
| メガトレンドの時系列追跡 | arXiv:2511.21741型のHellinger/Ward整列 |
| 投資シグナル化 | FS-2022-J-001型の教師あり・階層モデル |
| 実装容易性 | 初期はMLSTM完全実装ではなく、Ridge/ElasticNet/LightGBMで近似 |
| 解釈性 | TF-IDF語彙、代表記事、テーマ帰属、トピック系譜を保存 |

実務実装としては、**最初から完全なベイズMLSTMを作るより、Graph Topic → Topic Alignment → Supervised Signalの順に段階実装するのが最良**です。これなら、ニュースの盛り上がり、メガトレンド、テーマ間波及、そして実際の投資有効性を一貫して検証できます。

---

**Sources:**

- [](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf)
- [](https://arxiv.org/pdf/2010.15067)
- [LSEG Data Library for Python: News Pagination | Devportal](https://developers.lseg.com/en/article-catalog/article/lseg-data-library-for-python--news-pagination?utm_source=chatgpt.com)

## Response:
2026/5/7 21:32:09

> **Web検索とPDF参照による指示書作成**
>
> [ニュースを用いた金融市場分析のための マルチレベル教師 ...](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf)
> [Graph-based Topic Extraction from Vector Embeddings of Text Documents: Application to a Corpus of News Articles](https://arxiv.org/abs/2010.15067)
> [[2511.21741] A Multiscale Geometric Method for ... - ar5iv - arXiv](https://ar5iv.labs.arxiv.org/html/2511.21741)
> [Available CRAN Packages by Date of Publication](https://ftp.yz.yamagata-u.ac.jp/pub/cran/web/packages/available_packages_by_date.html)
> [Graph-based Topic Extraction from Vector Embeddings of Text ...](https://www.researchgate.net/publication/344945083_Graph-based_Topic_Extraction_from_Vector_Embeddings_of_Text_Documents_Application_to_a_Corpus_of_News_Articles)
> [Fugu-MT 論文翻訳(概要): A Multiscale Geometric Method for ...](https://fugumt.com/fugumt/paper_check/2511.21741v1)
> [Modeling of Improved Sine Cosine Algorithm with Optimal ...](https://www.mdpi.com/2079-9292/12/19/4130)
> [Available CRAN Packages by Date of Publication](https://brieger.esalq.usp.br/CRAN/web/packages/available_packages_by_date.html)
> [au:Pazdernik_K in:cs - SciRate Search](https://scirate.com/search?q=au%3APazdernik_K+in%3Acs)
> [Advanced Intelligent Computing Technology and Applications](https://link.springer.com/content/pdf/10.1007/978-981-95-0020-8.pdf)
> [Advanced Methods for Time Series Forecasting](https://mdpi-res.com/bookfiles/book/12489/Advanced_Methods_for_Time_Series_Forecasting.pdf?v=1774460781)
> [Compression de données et apprentissage en profondeur ...](https://theses.hal.science/tel-03636343v1/file/these_A_AZAR_Joseph_2020.pdf)
> [ICLR 2025 - Bird's-eye views of conference proceedings](https://www.confviews.com/iclr2025/)
> [机器学习2025_3_19](https://www.arxivdaily.com/thread/65378)
>
> **検索：LSEGデータライブラリの公式情報**
>
> [Getting Top News Energy Headlines and Stories using ...](https://developers.lseg.com/en/article-catalog/article/getting-top-news-energy-headlines-and-stories-using-lseg-data-li)
> [ld_access_news.py](https://github.com/LSEG-API-Samples/Example.DataLibrary.Python.RequestsComparison/blob/main/src/ld_access_news.py)
> [Adding story text to output using Python API](https://community.developers.lseg.com/discussion/132800/adding-story-text-to-output-using-python-api)
>
> 思考時間: 13s

採用手法は「研究として筋がよい」だけでなく、LSEGニュース、既存テーマ定義、日本株テーマバスケット、Codex実装のしやすさを優先して絞り込みます。論文の役割分担を確認したうえで、貼り付け可能な実装指示書としてまとめます。

## 最良の採用手法：**Topic Lineage Supervised Theme Rotation**

3論文をすべて同じ重みで実装するのではなく、以下のように役割分担させるのが最良です。

```text
LSEG/Reutersニュース
→ Broad queryで取得
→ ニュースクラスタを教師なし抽出
→ 週次でトピックの継続・分岐・波及を追跡
→ 既存テーマへ多ラベル帰属
→ テーマ別ニュース特徴量を作成
→ 将来リターン・売買代金・リスクへの教師あり変換
→ テーマバスケットを選択
```

採用すべき中核は、次の3層です。

| 層 | 採用手法 | 参照論文 | 目的 |
|---|---|---|---|
| Layer A | **Graph-based Topic Extraction** | arXiv:2010.15067 | Reutersニュースから自然発生している話題群を抽出 |
| Layer B | **Hellinger距離 + Ward法によるTopic Lineage** | arXiv:2511.21741 | 週次トピックの継続・分岐・波及・新興化を追跡 |
| Layer C | **MLSTM-inspired supervised layer** | FS-2022-J-001 | ニュース特徴量をテーマ別リターン・売買代金・リスクへ変換 |

arXiv:2010.15067は、文書ベクトルから類似度グラフを作り、マルチスケールなグラフ分割でニュース記事群の自然なトピックを抽出する枠組みです。トピック数を事前固定しない点が、テーマ名に直接出てこないニュースを拾ううえで重要です。([arXiv](https://arxiv.org/abs/2010.15067?utm_source=chatgpt.com))

arXiv:2511.21741は、Hellinger距離とWard linkageで階層的なトピック構造を作り、希少トピックや時間方向のトピックドリフトを捉える手法です。テーマ投資では「AIニュースが半導体、電力、空調、電線、建設へ波及する」といったメガトレンドの伝播を追う層として使います。([arXiv](https://arxiv.org/abs/2511.21741?utm_source=chatgpt.com))

FS-2022-J-001は、ニュースの潜在トピックを市場反応と結びつけるマルチレベル教師ありトピックモデルです。投資実装では完全なベイズMLSTMを最初から作るのではなく、テーマ別ニュース特徴量から将来リターン・売買代金・リスクを予測する教師あり層として近似するのが現実的です。([fs.hub.hit-u.ac.jp](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf?utm_source=chatgpt.com))

LSEG Data Libraryでは `ld.news.get_headlines` によりニュースクエリ、期間、件数を指定してニュースヘッドラインをDataFrameで取得でき、`storyId` を使って `ld.news.get_story` で本文を取得するワークフローが示されています。したがって、最初はBroad queryでヘッドラインを広く取得し、重複除去・重要度フィルタ後に本文取得する設計が適します。([developers.lseg.com](https://developers.lseg.com/en/article-catalog/article/lseg-data-library-for-python--news-pagination?utm_source=chatgpt.com))

---

# 1. 採用手法の設計

## 1.1 手法名

**Topic Lineage Supervised Theme Rotation**

略称：`TLSTR`

目的は、ニュースから単純なセンチメントを取ることではありません。  
目的は、以下の4つをテーマごとに定量化することです。

1. **どのニュース・トピックが盛り上がっているか**
2. **そのトピックが一過性か、継続的なメガトレンドか**
3. **そのトピックがどのテーマバスケットに波及しているか**
4. **そのニュース状態が将来リターン・売買代金・リスクに効くか**

---

## 1.2 最終的な投資シグナル

テーマ $j$、週 $t$ に対して、以下の特徴量を作ります。

$$
X_{j,t}
=
[
Buzz_{j,t},
Tone_{j,t},
Breadth_{j,t},
Novelty_{j,t},
Persistence_{j,t},
DriftIn_{j,t},
DriftOut_{j,t},
TopicExposure_{j,t,1:K},
MarketReaction_{j,t}
]
$$

これを使って、テーマの将来超過リターンを予測します。

$$
\hat{r}_{j,t+1:t+h}
=
f(X_{j,t})
$$

目的変数はTOPIXまたは等ウェイト全テーマに対する超過リターンにします。

$$
y_{j,t,h}
=
r_{j,t+1:t+h}
-
r^{bench}_{t+1:t+h}
$$

初期実装では、モデル $f$ は以下で十分です。

| 優先度 | モデル | 理由 |
|---:|---|---|
| 1 | Ridge / ElasticNet | 小標本・多重共線性に強く、解釈しやすい |
| 2 | LightGBM | 非線形性・交互作用を見る |
| 3 | Hierarchical Bayesian / MLSTM本格実装 | 研究拡張フェーズ |

最初からMLSTM完全実装に行かない方がよいです。理由は、LSEGニュース、日本株テーマ、テーマ定義、マーケットデータの整備だけで十分に複雑だからです。まずは **MLSTMの思想を、教師ありテーマ反応モデルとして実装する** のが正解です。

---

# 2. ニュース処理の具体設計

## 2.1 LSEGニュース取得

RIC指定は補助に留め、基本はBroad queryで取得します。

推奨クエリ単位は以下です。

| query_name | 目的 |
|---|---|
| `japan_broad_en` | 日本関連の英語Reutersニュース |
| `japan_market_en` | 日本株・市場ニュース |
| `macro_policy_en` | 金利、日銀、財政、政策 |
| `technology_en` | AI、半導体、データセンター、ソフトウェア |
| `energy_infra_en` | 電力、再エネ、原発、インフラ |
| `healthcare_en` | 医薬、医療機器、バイオ |
| `financials_en` | 銀行、保険、証券 |
| `consumer_en` | 小売、旅行、インバウンド、消費 |
| `materials_industrials_en` | 素材、機械、建設、設備投資 |

最初はBroad queryで十分です。RIC指定は、以下に限定します。

- テーマ内の超大型代表銘柄
- ニュース件数が少なすぎるテーマ
- Broad queryで取り漏れが多いテーマ
- Event study用の検証サンプル

---

## 2.2 ニュース正規化

LSEGから取得したDataFrameは、最低限以下の列に正規化します。

| 列 | 内容 |
|---|---|
| `news_id` | storyIdまたは一意ID |
| `timestamp_utc` | versionCreated優先、なければretrieved_at |
| `date` | 日次集計用 |
| `week` | 週次集計用 |
| `query_name` | 取得クエリ名 |
| `headline` | 見出し |
| `body` | 本文 |
| `text` | headline + body |
| `source` | Reuters等 |
| `language` | LEN等 |
| `story_id` | LSEG storyId |
| `retrieved_at_utc` | 取得時刻 |

`timestamp_utc` が欠損するケースを前提に、優先順位は次にします。

```text
versionCreated
→ firstCreated
→ retrieved_at_utc
→ ingestion_time
```

---

# 3. Topic Lineage の作り方

## 3.1 週次ニュースクラスタリング

週次でニュース集合 $\mathcal{D}_t$ を作り、以下を実行します。

```text
1. text cleaning
2. TF-IDFベクトル作成
3. SBERTベクトル作成
4. cosine similarity
5. kNN graph構築
6. Leidenクラスタリングをresolution sweep
7. 各クラスタの代表記事・上位語・サイズを保存
```

論文2はMarkov Stabilityを使いますが、Codex実装ではまず **Leidenのresolution sweep** で近似します。  
理由は、Pythonで安定実装しやすく、マルチスケールクラスタリングという本質を保てるからです。

---

## 3.2 Topic Lineage

週 $t$ のクラスタ $C_{t,a}$ と週 $t+1$ のクラスタ $C_{t+1,b}$ の距離を計算します。

$$
D(C_{t,a}, C_{t+1,b})
=
\alpha H(p^{word}_{t,a}, p^{word}_{t+1,b})
+
\beta H(p^{theme}_{t,a}, p^{theme}_{t+1,b})
+
\gamma H(p^{entity}_{t,a}, p^{entity}_{t+1,b})
$$

ここで、

- $p^{word}$：TF-IDFまたはc-TF-IDFから作る語彙分布
- $p^{theme}$：テーマ帰属確率分布
- $p^{entity}$：銘柄名、業種、キーワード共起分布
- $H(\cdot,\cdot)$：Hellinger距離

Hellinger距離は以下です。

$$
H(p,q)
=
\frac{1}{\sqrt{2}}
\left\|
\sqrt{p} - \sqrt{q}
\right\|_2
$$

この距離に基づき、前週からの最近傍クラスタを対応づけます。

出力する状態は以下です。

| 状態 | 判定 |
|---|---|
| `birth` | 前週に近いクラスタがない |
| `continue` | 前週クラスタと近い |
| `split` | 1つの前週クラスタが複数に分岐 |
| `merge` | 複数の前週クラスタが1つに統合 |
| `death` | 次週に対応クラスタがない |
| `drift` | 語彙は変化したがテーマ分布が近い、またはその逆 |

---

# 4. テーマ帰属

記事単位・クラスタ単位の両方でテーマ帰属を行います。

テーマ $j$ への記事 $d$ の帰属スコアは以下です。

$$
A_{d,j}
=
0.35 Sim(e_d, e_j)
+
0.25 Sim(e_{cluster(d)}, e_j)
+
0.15 KeywordHit_{d,j}
+
0.15 EntityOverlap_{d,j}
+
0.10 SectorOverlap_{d,j}
$$

| 項目 | 内容 |
|---|---|
| `Sim(e_d, e_j)` | 記事本文とテーマプロファイルのSBERT類似度 |
| `Sim(e_cluster, e_j)` | クラスタ代表文書とテーマプロファイルの類似度 |
| `KeywordHit` | テーマ辞書・ドライバー語彙の一致 |
| `EntityOverlap` | 構成銘柄名、略称、関連語の一致 |
| `SectorOverlap` | GICS/TRBC/業種の重なり |

ポイントは、**記事単体の類似度だけでテーマに割り当てない**ことです。  
記事単体では曖昧でも、クラスタ全体で見ると明確に「AIインフラ」「地銀」「防衛」「電力設備」などに対応することがあります。

---

# 5. テーマ別ニュース特徴量

週次で、テーマ $j$ に以下を作ります。

| 特徴量 | 定義 |
|---|---|
| `buzz` | テーマ帰属ニュース件数のz-score |
| `tone` | FinBERT等の平均センチメント |
| `tone_pos_share` | positive記事比率 |
| `tone_neg_share` | negative記事比率 |
| `breadth_cluster` | 関連クラスタ数 |
| `breadth_entity` | 関連銘柄・業種数 |
| `novelty` | 過去N週クラスタとの平均距離 |
| `persistence` | 対応topic lineageの継続週数 |
| `drift_in` | 他テーマ由来トピックが流入した強さ |
| `drift_out` | 自テーマ由来トピックが他テーマへ波及した強さ |
| `rare_topic_score` | 小規模だが急増しているクラスタへの露出 |
| `market_reaction` | 売買代金・出来高ショック |
| `risk_reaction` | 実現ボラ・下方リスク反応 |

---

# 6. 投資ルール

## 6.1 予測対象

まずは以下を予測します。

| 目的変数 | horizon |
|---|---:|
| 翌週テーマ超過リターン | 5営業日 |
| 翌月テーマ超過リターン | 20営業日 |
| 翌週売買代金ショック | 5営業日 |
| 翌月実現ボラ | 20営業日 |

初期の売買シグナルは、翌月超過リターン予測を中心にします。

$$
score_{j,t}
=
z(\hat{r}_{j,t,20d})
+
0.3z(persistence_{j,t})
+
0.2z(breadth_{j,t})
-
0.3z(\hat{risk}_{j,t,20d})
-
0.2z(turnover\_cost_{j,t})
$$

---

## 6.2 ポートフォリオ構築

```text
頻度：週次
シグナル生成：金曜引け後
執行：翌営業日
対象：投資可能なテーマバスケット
選択：score上位Nテーマ
テーマ内：所与ウェイト、なければ等ウェイト
テーマ間：等ウェイトまたはスコア比例
制約：最大テーマウェイト、最大銘柄ウェイト、売買回転制約
ヘッジ：必要に応じてTOPIX betaまたはEQW betaを中立化
```

推奨初期設定は以下です。

| パラメータ | 値 |
|---|---:|
| rebalance | `W-FRI` |
| execution_lag | 1営業日 |
| top_n_themes | 4 |
| max_theme_weight | 35% |
| max_single_stock_weight | 10% |
| transaction_cost | 10 bps |
| slippage | 1 bp |
| beta_neutral | option |
| train_start | データ開始から |
| oos_start | 2021-01-01など |

---

# 7. Codex実装指示書

以下をそのままCodexに貼り付けてください。

```markdown
# Codex実装指示書：Topic Lineage Supervised Theme Rotation

## 0. 最重要ルール

このプロジェクトでは、LSEG/Reutersニュースを用いて、日本株テーマバスケットの投資シグナルを作成する。

最初に必ず `workspace/AGENTS.md` を読み、すべて遵守すること。
このプロジェクトの `AGENTS.md` がある場合は、`workspace/AGENTS.md` に次ぐ優先度で遵守すること。

実装ルール：
- Python環境は `envs/base/.venv/bin/python` を優先する。
- 依存関係は勝手に追加しない。
- 追加が必要な場合は、まず不足パッケージと理由を `docs/notes/dependency_request.md` に記録する。
- `pip install` を直接実行しない。
- `uv` 管理環境を前提とする。
- 既存ファイルを破壊的に変更しない。
- `legacy/` がある場合は参照専用。編集禁止。
- 出力はすべて `outputs/` 以下に保存する。
- 実行・検証の中心は `main.ipynb` とする。
- まずは研究再現性を重視し、過度に複雑なモデルを実装しない。

## 1. 目的

LSEG Data Library for Pythonで取得されるReutersニュースを使い、テーマバスケットごとのニュース由来シグナルを作成する。

採用手法は `Topic Lineage Supervised Theme Rotation` とする。

目的は以下：
1. Broad queryで取得したニュースから自然発生トピックを抽出する。
2. 週次でトピックの継続・分岐・波及・新規発生を追跡する。
3. 既存テーマ定義へニュースを多ラベル帰属させる。
4. テーマ別に Buzz, Tone, Breadth, Novelty, Persistence, Drift を作る。
5. これらを使ってテーマ別将来超過リターン・売買代金・リスクを予測する。
6. 上位テーマを選択し、簡易バックテストを行う。

## 2. 実装フェーズ

### Phase 1: データ仕様と入出力整備

以下の入力ファイルを想定する。

```text
data/
  raw/
    lseg_news_headlines.parquet
    lseg_news_stories.parquet
    theme_master.csv
    theme_constituents.csv
    theme_returns.csv
    market_returns.csv
  interim/
  processed/
outputs/
docs/
  notes/
main.ipynb
```

入力ファイルが存在しない場合でも、サンプルデータで動くようにすること。
ただし、LSEG接続コードは実運用用関数として分離し、実行時にLSEGセッションがない場合はスキップできるようにする。

必要な標準列：

ニュース：
- `news_id`
- `story_id`
- `timestamp_utc`
- `date`
- `week`
- `query_name`
- `headline`
- `body`
- `text`
- `source`
- `language`
- `retrieved_at_utc`

テーママスター：
- `theme_id`
- `theme_name_en`
- `theme_name_jp`
- `description_en`
- `description_jp`

テーマ構成銘柄：
- `theme_id`
- `ticker`
- `ric`
- `company_name_en`
- `company_name_jp`
- `weight`
- `gics_sector`
- `gics_industry`
- `trbc_industry`
- `description_en`

テーマリターン：
- index: date
- columns: theme_id

マーケットリターン：
- index: date
- columns: benchmark returns, e.g. `TOPIX`, `EQW_THEME`

### Phase 2: LSEGニュース取得関数

`src/theme_news/lseg_io.py` を作成する。

関数：
- `get_lseg_headlines(query: str, start: str, end: str, count: int) -> pd.DataFrame`
- `get_lseg_story(story_id: str) -> str`
- `fetch_broad_news(query_config: dict, start: str, end: str) -> pd.DataFrame`

要件：
- `lseg.data` がimportできない場合でもエラーで停止せず、警告を出す。
- `story_id` がある場合のみ本文取得する。
- 本文取得は大量実行しすぎないよう、`max_stories_per_query` を設ける。
- 取得結果は `data/raw/` にparquet保存する。
- 実行済みデータがある場合は再取得しないオプションを持つ。

想定クエリ名：
- `japan_broad_en`
- `japan_market_en`
- `macro_policy_en`
- `technology_en`
- `energy_infra_en`
- `healthcare_en`
- `financials_en`
- `consumer_en`
- `materials_industrials_en`

### Phase 3: ニュース正規化

`src/theme_news/preprocess.py` を作成する。

関数：
- `normalize_news_df(df: pd.DataFrame) -> pd.DataFrame`
- `clean_text(text: str) -> str`
- `deduplicate_news(df: pd.DataFrame) -> pd.DataFrame`
- `make_week_col(df: pd.DataFrame, week_anchor: str = "W-FRI") -> pd.DataFrame`

要件：
- timestampは以下の優先順で作る。
  1. `versionCreated`
  2. `firstCreated`
  3. `timestamp_utc`
  4. `retrieved_at_utc`
  5. 実行時刻
- timezone aware / naive の混在で落ちないようにUTCへ統一する。
- `datetime64[us, utc]` と `datetime64[ns]` のmergeエラーを避ける。
- `headline`, `body` から `text` を作る。
- 同一またはほぼ同一headlineは重複除去する。
- `outputs/tables/news_summary.csv` を出力する。

### Phase 4: テーマプロファイル作成

`src/theme_news/theme_profile.py` を作成する。

関数：
- `build_theme_profiles(theme_master, theme_constituents) -> pd.DataFrame`
- `make_theme_text(row) -> str`
- `build_theme_keywords(theme_master, theme_constituents) -> dict`

テーマプロファイルには以下を含める。
- テーマ名
- テーマ説明
- 構成銘柄名
- 構成銘柄の事業説明
- GICS/TRBC業種
- 人手辞書があればそれも統合

出力：
- `data/processed/theme_profiles.parquet`
- `outputs/tables/theme_profiles_preview.csv`

### Phase 5: ニュースベクトル化

`src/theme_news/embedding.py` を作成する。

関数：
- `fit_tfidf(texts, max_features=20000, min_df=3, max_df=0.8)`
- `transform_tfidf(vectorizer, texts)`
- `load_sentence_transformer(model_path_or_name=None)`
- `embed_texts_sbert(texts, model, batch_size=64)`
- `safe_embed_texts(texts, method="tfidf+sbert")`

要件：
- SBERTが使えない場合でもTF-IDFのみで動作する。
- SentenceTransformerのローカルモデルパスを指定できる。
- 初期モデル候補は `paraphrase-multilingual-MiniLM-L12-v2` だが、ハードコードしすぎない。
- ベクトルは `data/interim/` に保存する。
- メモリを食いすぎないようにfloat32化する。

### Phase 6: Graph-based Topic Extraction

`src/theme_news/topic_graph.py` を作成する。

関数：
- `build_knn_graph(embeddings, k=10, metric="cosine")`
- `cluster_graph_leiden(graph, resolutions=[0.5,1.0,1.5,2.0])`
- `extract_weekly_topics(news_df, embeddings, week_col="week")`
- `summarize_topics(news_df, labels, tfidf_matrix, vectorizer)`

要件：
- 論文のMarkov Stabilityを完全実装する必要はない。
- 初期実装ではkNN graph + Leiden/Louvainのresolution sweepでよい。
- `igraph` や `leidenalg` がない場合は、`sklearn.cluster` の `AgglomerativeClustering` または `KMeans` にフォールバックする。
- 各週・各resolution・各clusterについて以下を保存する。
  - `week`
  - `resolution`
  - `topic_id`
  - `n_articles`
  - `top_terms`
  - `representative_headlines`
  - `article_ids`

出力：
- `data/processed/weekly_topics.parquet`
- `outputs/tables/topic_summary.csv`

### Phase 7: テーマ帰属

`src/theme_news/theme_assignment.py` を作成する。

関数：
- `compute_article_theme_similarity(article_embeddings, theme_embeddings)`
- `compute_cluster_theme_similarity(cluster_embeddings, theme_embeddings)`
- `compute_keyword_hit(news_text, theme_keywords)`
- `assign_news_to_themes(...)`
- `assign_topics_to_themes(...)`

テーマ帰属スコア：

A_dj =
0.35 * article_theme_similarity
+ 0.25 * cluster_theme_similarity
+ 0.15 * keyword_hit
+ 0.15 * entity_overlap
+ 0.10 * sector_overlap

要件：
- 多ラベル帰属とする。
- 閾値 `assignment_threshold` を設定する。
- 上位 `top_m_themes_per_article` も保存する。
- 帰属できない記事は `unassigned` として保持する。
- 未分類記事も後で新興トピック検出に使えるよう捨てない。

出力：
- `data/processed/news_theme_assignment.parquet`
- `data/processed/topic_theme_assignment.parquet`
- `outputs/tables/theme_assignment_summary.csv`

### Phase 8: Topic Lineage

`src/theme_news/topic_lineage.py` を作成する。

関数：
- `hellinger_distance(p, q)`
- `make_word_distribution(topic, vectorizer)`
- `make_theme_distribution(topic_theme_assignment)`
- `make_entity_distribution(topic_articles)`
- `compute_topic_distance_matrix(topics_t, topics_t1)`
- `link_topics_over_time(weekly_topics, threshold=0.55)`
- `classify_lineage_events(linked_topics)`

距離定義：

D =
alpha * H(word_distribution_t, word_distribution_t1)
+ beta * H(theme_distribution_t, theme_distribution_t1)
+ gamma * H(entity_distribution_t, entity_distribution_t1)

初期値：
- alpha = 0.50
- beta = 0.35
- gamma = 0.15

イベント分類：
- `birth`
- `continue`
- `split`
- `merge`
- `death`
- `drift`

出力：
- `data/processed/topic_lineage.parquet`
- `outputs/tables/topic_lineage_events.csv`
- `outputs/figures/topic_lineage_network.png`

### Phase 9: テーマ別ニュース特徴量

`src/theme_news/features.py` を作成する。

関数：
- `make_theme_weekly_features(news_df, assignment_df, lineage_df, market_data)`
- `compute_buzz`
- `compute_tone`
- `compute_breadth`
- `compute_novelty`
- `compute_persistence`
- `compute_drift`
- `compute_market_reaction`

特徴量：
- `buzz_z`
- `article_count`
- `assigned_article_count`
- `tone_mean`
- `tone_pos_share`
- `tone_neg_share`
- `breadth_topic`
- `breadth_entity`
- `novelty`
- `persistence`
- `drift_in`
- `drift_out`
- `rare_topic_score`
- `turnover_shock`
- `volume_shock`
- `realized_vol`

Toneについて：
- FinBERTが使える場合はFinBERT。
- 使えない場合は、辞書またはTextBlob等の簡易スコアでフォールバック。
- Toneは必須ではなく、欠損時は他特徴量だけで進める。

出力：
- `data/processed/theme_weekly_features.parquet`
- `outputs/tables/theme_weekly_features_preview.csv`

### Phase 10: 教師あり投資シグナル

`src/theme_news/signal_model.py` を作成する。

関数：
- `make_forward_returns(theme_returns, horizons=[5,20])`
- `make_supervised_dataset(features, forward_returns, benchmark_returns)`
- `fit_walkforward_model(X, y, model_type="ridge", train_min_weeks=52)`
- `predict_walkforward(...)`
- `make_theme_scores(predictions, features)`

目的変数：
- `fwd_excess_ret_5d`
- `fwd_excess_ret_20d`
- `fwd_realized_vol_20d`
- `fwd_drawdown_20d`

モデル：
- Ridge
- ElasticNet
- LightGBMがあればオプション
- LightGBMがなければsklearnのみで完結

リーク防止：
- 週tのニュース特徴量は、t週終了時点までのニュースのみから作る。
- 目的変数はt+1以降。
- walk-forwardで学習する。
- future dataを使って標準化しない。
- scalerは各学習window内でfitし、test時にtransformする。

出力：
- `data/processed/theme_predictions.parquet`
- `data/processed/theme_scores.parquet`
- `outputs/tables/model_ic_summary.csv`

### Phase 11: バックテスト

`src/theme_news/backtest.py` を作成する。

関数：
- `select_top_themes(scores, top_n=4)`
- `build_theme_portfolio_weights(selected_themes, method="equal")`
- `apply_execution_lag(weights, lag_days=1)`
- `run_backtest(theme_returns, weights, cost_bps=10, slippage_bps=1)`
- `compute_performance_metrics(returns)`
- `compute_turnover(weights)`

初期ルール：
- 毎週金曜にスコア生成。
- 翌営業日に執行。
- 上位4テーマを等ウェイト。
- テーマ内の銘柄ウェイトは既存テーマ定義を使う。
- テーマリターンがすでに与えられている場合は、まずテーマリターンベースで検証する。
- 後続フェーズで銘柄レベルウェイトに展開する。

評価指標：
- CAGR
- AnnVol
- Sharpe
- MaxDD
- Skew
- Kurtosis
- Monthly VaR 5%
- Monthly CVaR 5%
- Turnover
- Hit ratio
- IC
- Rank IC
- Quintile spread

出力：
- `outputs/tables/performance_summary.csv`
- `outputs/tables/turnover_summary.csv`
- `outputs/figures/nav_strategy_vs_benchmark.png`
- `outputs/figures/theme_weights.png`
- `outputs/figures/theme_scores_timeseries.png`

### Phase 12: main.ipynb

`main.ipynb` を作成または更新する。

Notebook構成：
1. 設定
2. 入力データ確認
3. LSEGニュース取得または既存データ読み込み
4. ニュース正規化
5. テーマプロファイル作成
6. ベクトル化
7. 週次トピック抽出
8. テーマ帰属
9. Topic Lineage作成
10. テーマ別ニュース特徴量作成
11. 教師ありモデル
12. テーマスコア作成
13. バックテスト
14. 図表出力
15. 結果サマリー

Notebook内では各ステップのDataFrame head, shape, 欠損率, 主要図表を表示する。

## 3. 設定ファイル

`config.yaml` を作成する。

含める項目：

```yaml
project:
  name: topic_lineage_supervised_theme_rotation

paths:
  raw: data/raw
  interim: data/interim
  processed: data/processed
  outputs: outputs

news:
  week_anchor: W-FRI
  max_stories_per_query: 500
  language: LEN
  source: RTRS
  dedup_headline_similarity: 0.95

embedding:
  use_sbert: true
  sbert_model_path: null
  tfidf_max_features: 20000
  tfidf_min_df: 3
  tfidf_max_df: 0.8

topic_graph:
  k_neighbors: 10
  resolutions: [0.5, 1.0, 1.5, 2.0]
  fallback_cluster_method: agglomerative

theme_assignment:
  assignment_threshold: 0.35
  top_m_themes_per_article: 3
  weights:
    article_similarity: 0.35
    cluster_similarity: 0.25
    keyword_hit: 0.15
    entity_overlap: 0.15
    sector_overlap: 0.10

topic_lineage:
  alpha_word: 0.50
  beta_theme: 0.35
  gamma_entity: 0.15
  link_threshold: 0.55

signal_model:
  horizons: [5, 20]
  model_type: ridge
  train_min_weeks: 52
  rebalance: W-FRI
  execution_lag_days: 1

portfolio:
  top_n_themes: 4
  weighting: equal
  cost_bps: 10
  slippage_bps: 1
  benchmark: EQW_THEME
```

## 4. 期待成果物

最終的に以下を作成する。

```text
src/theme_news/
  __init__.py
  config.py
  lseg_io.py
  preprocess.py
  theme_profile.py
  embedding.py
  topic_graph.py
  theme_assignment.py
  topic_lineage.py
  features.py
  signal_model.py
  backtest.py
  reporting.py

docs/notes/
  00_doc_index.md
  10_method_summary.md
  20_assumptions.md
  30_implementation_plan.md
  dependency_request.md

main.ipynb
config.yaml

outputs/
  tables/
  figures/
  logs/
```

## 5. 実装上の注意

- 最初から完全なMLSTMやベイズ推定は実装しない。
- FS-2022-J-001の思想は、ニューストピックを市場反応へ教師ありで写像する層として実装する。
- arXiv:2010.15067の思想は、ニュースから自然なトピックを抽出する層として実装する。
- arXiv:2511.21741の思想は、週次トピックの継続・分岐・波及を追跡する層として実装する。
- RIC指定ニュース取得に依存しすぎない。
- Broad queryでニュースを取得し、テーマ帰属は後段で行う。
- 未分類ニュースは捨てず、新興トピック検出に使う。
- トピッククラスタ、テーマ帰属、テーマスコアはすべて中間ファイルとして保存する。
- 後から検証できるように、代表headlineとtop_termsを必ず保存する。
- すべてのモデルはwalk-forwardで推定し、未来情報を使わない。
- 週次シグナル、日次リターンのバックテストにする。

## 6. 検証すべき仮説

以下の仮説を検証できるように図表・テーブルを出力する。

1. Buzzが高いテーマは翌月リターンが高いか。
2. Buzz単独より、ToneやPersistenceを加えた方がICが改善するか。
3. 新規トピックより、継続トピックの方がリターン持続性が高いか。
4. 他テーマからDrift-inしたテーマは後追いで上昇するか。
5. Rare topic scoreが高いテーマは、初期段階のテーマ相場を捕捉できるか。
6. 売買代金ショックを伴うニューステーマは、伴わないテーマより有効か。
7. ニューススコア上位テーマのロング戦略はEQWテーマを上回るか。
8. β中立化によりSharpeとMaxDDが改善するか。

## 7. 最初に実装するMVP

まずは以下のMVPを完成させる。

MVP対象：
- 既存のニュースparquetを読み込む
- ニュース正規化
- TF-IDFベクトル化
- 週次クラスタリング
- テーマプロファイル作成
- 記事・クラスタのテーマ帰属
- Buzz, Breadth, Novelty, Persistenceの作成
- Ridgeによる翌月テーマ超過リターン予測
- 上位4テーマ等ウェイトバックテスト
- 図表保存

MVPでは以下はオプション：
- SBERT
- FinBERT
- LSEG live fetch
- Leiden
- LightGBM
- 銘柄レベルポートフォリオ展開
- 本格MLSTM

## 8. 完了条件

以下がすべて満たされたら完了。

- `main.ipynb` が上から順に実行できる。
- サンプルデータまたは既存データで最後まで動く。
- `outputs/tables/performance_summary.csv` が作成される。
- `outputs/figures/nav_strategy_vs_benchmark.png` が作成される。
- `outputs/figures/theme_scores_timeseries.png` が作成される。
- `outputs/tables/topic_summary.csv` が作成される。
- `outputs/tables/topic_lineage_events.csv` が作成される。
- 未来情報リークがないことをノートブック内で説明している。
- 実装上の仮定は `docs/notes/20_assumptions.md` に記録されている。
```

---

# 8. 実装方針の要点

今回の最良案は、**ニュースをいきなりテーマへ分類する手法ではありません**。  
まずニュース空間そのものからトピックを発見し、そのトピックが時間とともにどう動くかを追い、最後に既存テーマバスケットへ写像します。

この順序にする理由は明確です。

```text
悪い設計：
ニュース → テーマ定義との類似度 → テーマスコア

良い設計：
ニュース → 自然発生トピック → 時系列トピック系譜 → テーマ帰属 → 投資シグナル
```

テーマ名や構成銘柄だけに依存すると、「AI」「データセンター」「電力」「空調」「電線」「建設」のようなテーマ間波及を見落とします。今回の設計では、そこを `Topic Lineage` として明示的に扱います。

最初のMVPは、**TF-IDF + 週次クラスタリング + Hellinger Topic Lineage + Ridge予測 + 上位4テーマ等ウェイト** で十分です。SBERT、FinBERT、Leiden、LightGBM、MLSTM本格実装は、その後の拡張で問題ありません。

---

**Sources:**

- [Graph-based Topic Extraction from Vector Embeddings of Text Documents: Application to a Corpus of News Articles](https://arxiv.org/abs/2010.15067?utm_source=chatgpt.com)
- [ニュースを用いた金融市場分析のための マルチレベル教師 ...](https://www.fs.hub.hit-u.ac.jp/inc/files/staff-research/workingpaper/FS-2022-J-001.pdf?utm_source=chatgpt.com)
- [LSEG Data Library for Python: News Pagination | Devportal](https://developers.lseg.com/en/article-catalog/article/lseg-data-library-for-python--news-pagination?utm_source=chatgpt.com)

## Response:
2026/5/7 21:43:47

以下では、**Layer A：Graph-based Topic Extraction** と **Layer B：Topic Lineage / Topic Alignment** までを、Codex実装を前提に、データ構造・処理順序・数式・出力物まで再現可能な粒度で整理します。

---

# 全体像：Layer A/B の役割

```text
LSEG/Reutersニュース
  ↓
ニュース正規化
  ↓
Layer A:
  週次ニュース空間から自然発生トピックを抽出
  ↓
Layer B:
  週次トピックを時間方向につなぎ、継続・分岐・波及を判定
  ↓
後段:
  テーマ帰属、ニュース特徴量、投資シグナルへ
```

Layer A/B の目的は、**ニュースをいきなり既存テーマへ分類しないこと**です。

最初にニュース空間そのものから「今、市場で自然に発生している話題」を抽出し、その話題が週次でどう変化しているかを追います。  
そのうえで、後段で既存テーマバスケットに写像します。

---

# Layer A：Graph-based Topic Extraction

## 1. Layer A の目的

Layer A の目的は、Reutersニュース群から、事前にテーマ数やトピック名を決めずに、自然発生しているニュース・トピックを抽出することです。

たとえば、ある週のニュースから以下のようなクラスタを作ります。

| topic_id | top_terms | representative_headlines | 解釈 |
|---|---|---|---|
| 2026W10_T03 | AI, data center, power, chip | データセンター投資拡大、電力需要増 | AIインフラ |
| 2026W10_T07 | BOJ, yield, banks, margins | 日銀利上げ観測、銀行株上昇 | 金利正常化・銀行 |
| 2026W10_T11 | defense, missile, budget | 防衛予算拡大 | 防衛関連 |
| 2026W10_T18 | drug, obesity, approval | 肥満薬・医薬承認 | 医薬・ヘルスケア |

ここで重要なのは、トピック名を最初から与えないことです。  
あくまでニュース同士の近さからクラスタを作り、あとで人間またはLLMが解釈できるように、代表ヘッドライン・上位語・記事一覧を保存します。

---

# 2. Layer A の入力

Layer A の入力は、正規化済みニュースDataFrameです。

## 2.1 必須列

```text
news_df
  news_id
  story_id
  timestamp_utc
  date
  week
  query_name
  headline
  body
  text
  source
  language
```

`text` は基本的に以下です。

```python
text = headline + "\n" + body
```

本文がない場合は、headlineのみで処理します。

---

## 2.2 週次処理単位

ニュースは日次で取得されますが、Layer A のクラスタリングはまず週次で行うのがよいです。

理由は以下です。

| 粒度 | 問題 |
|---|---|
| 日次 | ニュース件数が少なく、クラスタが不安定 |
| 週次 | ある程度の件数があり、投資リバランスと整合的 |
| 月次 | 反応が遅くなり、ニュース投資として鈍い |

推奨は以下です。

```yaml
week_anchor: W-FRI
```

つまり、金曜締めの週次ニュース集合を作ります。

```text
week t のニュース集合 D_t
= 前週土曜〜当週金曜までのReutersニュース
```

---

# 3. Layer A の処理フロー

Layer A は以下の順序で処理します。

```text
1. ニューステキストのクリーニング
2. TF-IDF表現を作る
3. SBERT表現を作る, 任意
4. 文書間類似度を計算
5. kNNグラフを作る
6. クラスタリングする
7. 各クラスタを要約する
8. 週次トピックテーブルを保存する
```

---

# 4. Step A1：ニューステキストのクリーニング

## 4.1 目的

LSEG/Reuters本文には、重複表現、更新ラベル、余計な改行、短すぎる本文などが混じります。  
クラスタリング前に最低限の正規化をします。

## 4.2 処理内容

```text
- HTMLタグ除去
- 連続空白・改行の圧縮
- 全角・半角の軽い正規化
- headline/bodyの欠損補完
- 極端に短いtextを除外
- 同一headlineの重複除去
- Reuters update記事の重複を軽くまとめる
```

## 4.3 出力

```text
clean_text
text_length
is_valid_text
```

---

# 5. Step A2：TF-IDF表現

## 5.1 なぜTF-IDFを残すか

SBERTなどの埋め込みだけに頼ると、クラスタの解釈が難しくなります。  
一方、TF-IDFは上位語を出しやすく、トピック要約・Hellinger距離・c-TF-IDFに使えます。

そのため、**TF-IDFは必須**です。

## 5.2 文書単位のTF-IDF

各週 $t$ のニュース集合を

$$
\mathcal{D}_t = \{d_1, d_2, ..., d_{N_t}\}
$$

とします。

文書 $d_i$ のTF-IDFベクトルを

$$
x_i^{tfidf} \in \mathbb{R}^{V}
$$

とします。

ここで $V$ は語彙数です。

## 5.3 推奨パラメータ

```yaml
tfidf:
  max_features: 20000
  min_df: 3
  max_df: 0.80
  ngram_range: [1, 2]
  stop_words: english
```

Reuters英語ニュースを中心にするなら、まず英語stop wordsで十分です。  
日本語ニュースも混ぜる場合は、別途日本語形態素処理が必要になるため、最初のMVPでは英語Reutersに絞る方が堅いです。

---

# 6. Step A3：SBERT表現, 任意だが推奨

## 6.1 目的

TF-IDFは語彙一致には強いですが、言い換えや意味的類似には弱いです。

たとえば以下はTF-IDFでは離れやすいですが、意味的には近いです。

```text
data center electricity demand
power grid strain from AI servers
energy infrastructure bottleneck for cloud computing
```

このような意味類似を拾うためにSBERT埋め込みを使います。

## 6.2 文書埋め込み

記事 $d_i$ のSBERT埋め込みを

$$
x_i^{sbert} \in \mathbb{R}^{m}
$$

とします。

## 6.3 実装方針

初期MVPでは以下にします。

```text
SBERTが使える場合:
  TF-IDF + SBERTの両方を作る

SBERTが使えない場合:
  TF-IDFのみで続行
```

Codex実装では、ローカルモデルパスを指定可能にします。

```yaml
embedding:
  use_sbert: true
  sbert_model_path: data/model/paraphrase-multilingual-MiniLM-L12-v2
```

---

# 7. Step A4：文書間類似度

## 7.1 類似度の基本

記事 $i, j$ の類似度はコサイン類似度で計算します。

$$
sim(i,j)
=
\frac{x_i^\top x_j}{\|x_i\|\|x_j\|}
$$

TF-IDF類似度とSBERT類似度の両方がある場合、合成します。

$$
sim(i,j)
=
\lambda sim^{sbert}(i,j)
+
(1-\lambda) sim^{tfidf}(i,j)
$$

推奨初期値は以下です。

$$
\lambda = 0.6
$$

つまり、意味類似をやや重視しつつ、語彙一致も残します。

## 7.2 なぜ完全な類似度行列を使わないか

ニュース件数が多い場合、全記事ペアの類似度行列は重いです。

また、低い類似度のエッジまで残すと、ニュース空間が過度につながり、トピックがぼやけます。

そのため、次のStepで **kNNグラフ** に変換します。

---

# 8. Step A5：kNNグラフ構築

## 8.1 グラフの定義

各記事をノードとします。

```text
node = news article
edge = 類似している記事ペア
edge weight = cosine similarity
```

週 $t$ のグラフを

$$
G_t = (V_t, E_t)
$$

とします。

- $V_t$：週 $t$ の記事集合
- $E_t$：類似記事間のエッジ

## 8.2 kNNエッジ

各記事について、最も類似度が高い上位 $k$ 件の記事にエッジを張ります。

推奨値：

```yaml
k_neighbors: 10
```

記事数が少ない週は、以下のように調整します。

$$
k_t = \min(10, \max(2, \lfloor \sqrt{N_t} \rfloor))
$$

## 8.3 MSTを加えるか

論文ベースでは、kNNだけだとグラフが分断されるため、MST, Minimum Spanning Tree, を加えて連結性を確保する設計が有効です。

ただし、実装初期では以下でよいです。

```text
MVP:
  kNN graphのみ

拡張:
  MST + kNN graph
```

MSTを加える場合は、距離を

$$
dist(i,j) = 1 - sim(i,j)
$$

として、最小全域木を作ります。

最終エッジは以下です。

$$
E_t = E_t^{kNN} \cup E_t^{MST}
$$

---

# 9. Step A6：グラフクラスタリング

## 9.1 目的

kNNグラフをコミュニティ検出し、ニュース・トピックを抽出します。

```text
記事ノード群
→ 類似度グラフ
→ コミュニティ
→ ニュース・トピック
```

## 9.2 推奨アルゴリズム

理想は以下です。

```text
Leiden clustering with resolution sweep
```

ただし、依存関係が重い場合があるため、Codex実装ではフォールバックを用意します。

| 優先順位 | 手法 | 備考 |
|---:|---|---|
| 1 | Leiden | 最も推奨 |
| 2 | Louvain | Leidenがない場合 |
| 3 | AgglomerativeClustering | グラフ系ライブラリがない場合 |
| 4 | KMeans | 最後のフォールバック |

## 9.3 resolution sweep

単一の粒度でクラスタリングすると、粗すぎる・細かすぎる問題が出ます。

そのため、複数のresolutionでクラスタを作ります。

```yaml
resolutions: [0.5, 1.0, 1.5, 2.0]
```

解釈は以下です。

| resolution | 意味 |
|---:|---|
| 0.5 | 粗い大テーマ |
| 1.0 | 標準 |
| 1.5 | やや細かいサブテーマ |
| 2.0 | 細かいイベント・ニュース群 |

MVPでは `resolution=1.0` を主系列にして、他のresolutionは補助的に保存します。

---

# 10. Step A7：トピック要約

クラスタリングで得た各トピックについて、以下を作ります。

## 10.1 基本情報

```text
week
resolution
topic_id
n_articles
article_ids
```

## 10.2 代表ヘッドライン

代表記事は、クラスタ中心に近い記事を選びます。

クラスタ $C$ の中心ベクトルを

$$
\bar{x}_C = \frac{1}{|C|}\sum_{i \in C} x_i
$$

とします。

代表記事は以下です。

$$
i^* = \arg\max_{i \in C} sim(x_i, \bar{x}_C)
$$

上位3〜5件を保存します。

```text
representative_headlines
```

## 10.3 上位語

TF-IDFまたはc-TF-IDFでクラスタの上位語を作ります。

クラスタ $C$ の語彙分布を

$$
p_C(w)
=
\frac{\sum_{d \in C} tfidf(d,w)}
{\sum_{w'}\sum_{d \in C} tfidf(d,w')}
$$

とし、上位語を取ります。

```text
top_terms
```

---

# 11. Layer A の出力

Layer A の主要出力は `weekly_topics.parquet` です。

## 11.1 weekly_topics

```text
weekly_topics
  week
  resolution
  topic_id
  global_topic_id
  n_articles
  article_ids
  top_terms
  representative_headlines
  centroid_vector_path
  word_distribution_path
```

## 11.2 article_topic_assignment

```text
article_topic_assignment
  news_id
  week
  resolution
  topic_id
  topic_weight
```

MVPでは、各記事は1クラスタに属するハードアサインでよいです。

拡張では、複数クラスタへのsoft assignmentも可能です。

---

# Layer B：Topic Lineage / Topic Alignment

# 12. Layer B の目的

Layer B の目的は、Layer Aで週ごとに抽出されたトピックを時間方向につなぐことです。

Layer Aだけでは、各週のクラスタは独立です。

```text
Week 1:
  T1: AI半導体
  T2: 日銀利上げ
  T3: 防衛

Week 2:
  T1: データセンター電力
  T2: 銀行利ざや
  T3: 防衛予算
```

これだけでは、Week 1 の「AI半導体」と Week 2 の「データセンター電力」が同じメガトレンドの延長か、別トピックか判断できません。

Layer Bでは、週次クラスタ同士の距離を測り、以下を判定します。

```text
continue: 継続
birth: 新規発生
death: 消滅
split: 分岐
merge: 統合
drift: 変質・波及
```

---

# 13. Layer B の入力

Layer B の入力は、Layer A の出力です。

```text
weekly_topics
article_topic_assignment
news_df
tfidf_matrix
theme_profiles, optional
entity dictionaries, optional
```

ただし、Layer Bを完全にテーマ非依存にしたい場合は、最初は `word_distribution` だけでつなげます。

推奨は以下です。

```text
MVP:
  word_distribution のHellinger距離

拡張:
  word_distribution
  + theme_distribution
  + entity_distribution
```

---

# 14. Step B1：トピック分布を作る

各トピック $C_{t,a}$ に対して、以下の分布を作ります。

## 14.1 語彙分布

$$
p^{word}_{t,a}(w)
=
\frac{\sum_{d \in C_{t,a}} tfidf(d,w)}
{\sum_{w'}\sum_{d \in C_{t,a}} tfidf(d,w')}
$$

これは、トピックがどの語彙で構成されているかを表します。

例：

```text
Topic: AIインフラ
p_word:
  ai: 0.08
  data_center: 0.07
  chip: 0.05
  power: 0.05
  cloud: 0.04
```

## 14.2 テーマ分布, 後段連携

テーマ帰属が既に計算されている場合、トピックごとのテーマ分布を作れます。

$$
p^{theme}_{t,a}(j)
=
\frac{\sum_{d \in C_{t,a}} A_{d,j}}
{\sum_{j'}\sum_{d \in C_{t,a}} A_{d,j'}}
$$

ここで $A_{d,j}$ は記事 $d$ のテーマ $j$ への帰属スコアです。

例：

```text
Topic: データセンター電力
p_theme:
  AI: 0.35
  半導体: 0.25
  電力設備: 0.20
  建設: 0.10
  不動産: 0.10
```

## 14.3 エンティティ分布

記事から銘柄名、企業名、業種語、主要ドライバー語を抽出し、トピック内の出現分布を作ります。

$$
p^{entity}_{t,a}(e)
=
\frac{count(e, C_{t,a})}
{\sum_{e'}count(e', C_{t,a})}
$$

例：

```text
p_entity:
  Nvidia: 0.10
  TSMC: 0.08
  Tokyo Electron: 0.06
  data center: 0.05
  power grid: 0.05
```

日本株テーマバスケットでは、銘柄RICをニュース取得に使わなくても、本文中に出てくる企業名・業種名・製品名をエンティティ分布として使えます。

---

# 15. Step B2：トピック間距離

週 $t$ のトピック $C_{t,a}$ と、週 $t+1$ のトピック $C_{t+1,b}$ の距離を計算します。

## 15.1 Hellinger距離

確率分布 $p, q$ に対するHellinger距離は以下です。

$$
H(p,q)
=
\frac{1}{\sqrt{2}}
\sqrt{
\sum_i
\left(
\sqrt{p_i} - \sqrt{q_i}
\right)^2
}
$$

値域はおおむね以下です。

| Hellinger距離 | 解釈 |
|---:|---|
| 0に近い | ほぼ同じ分布 |
| 0.2〜0.4 | かなり近い |
| 0.4〜0.6 | 関連ありだが変化あり |
| 0.6以上 | 別トピックの可能性が高い |

## 15.2 合成距離

最終的なトピック距離は以下です。

$$
D(C_{t,a}, C_{t+1,b})
=
\alpha H(p^{word}_{t,a}, p^{word}_{t+1,b})
+
\beta H(p^{theme}_{t,a}, p^{theme}_{t+1,b})
+
\gamma H(p^{entity}_{t,a}, p^{entity}_{t+1,b})
$$

初期値：

$$
\alpha=0.50,\quad
\beta=0.35,\quad
\gamma=0.15
$$

MVPではテーマ帰属やエンティティ抽出が未整備でもよいので、以下にします。

$$
D(C_{t,a}, C_{t+1,b})
=
H(p^{word}_{t,a}, p^{word}_{t+1,b})
$$

---

# 16. Step B3：週次トピックの対応づけ

## 16.1 最近傍リンク

各トピック $C_{t,a}$ について、翌週の最も近いトピックを探します。

$$
b^*
=
\arg\min_b
D(C_{t,a}, C_{t+1,b})
$$

距離が閾値以下ならリンクします。

$$
D(C_{t,a}, C_{t+1,b^*}) \le \tau
$$

推奨初期値：

$$
\tau = 0.55
$$

## 16.2 双方向チェック

単純な最近傍だけだと誤リンクが出るので、可能なら双方向最近傍を使います。

```text
C_t,a の最近傍が C_t+1,b
かつ
C_t+1,b の最近傍が C_t,a
なら strong link
```

一方向のみなら weak link とします。

出力：

```text
link_strength = strong / weak
distance
similarity = 1 - distance
```

---

# 17. Step B4：イベント分類

トピック間リンクから、以下のイベントを判定します。

## 17.1 continue

前週トピックと翌週トピックが1対1で近い場合。

```text
C_t,a → C_t+1,b
```

判定：

```text
out_degree(C_t,a) = 1
in_degree(C_t+1,b) = 1
distance <= threshold
```

意味：

```text
同じニュース・トピックが継続
```

例：

```text
Week 1: 日銀利上げ観測
Week 2: 銀行利ざや改善
```

---

## 17.2 birth

翌週トピックに、前週からの近いリンクがない場合。

```text
∅ → C_t+1,b
```

意味：

```text
新しいニュース・トピックの発生
```

投資上は、初期テーマ相場候補です。

ただし、birth単独では一過性ノイズも多いので、後続週でpersistenceが伸びるか確認します。

---

## 17.3 death

前週トピックが、翌週に近いリンクを持たない場合。

```text
C_t,a → ∅
```

意味：

```text
ニュース・トピックの消滅
```

テーマスコアでは、Buzz低下、Persistence低下として反映します。

---

## 17.4 split

1つの前週トピックが、翌週の複数トピックに近い場合。

```text
C_t,a → C_t+1,b1
      → C_t+1,b2
```

意味：

```text
メガトレンドがサブテーマに分岐
```

例：

```text
Week 1: AI投資
Week 2: 半導体
Week 2: データセンター電力
Week 2: 空調設備
```

投資上は非常に重要です。  
テーマの波及が発生している可能性があります。

---

## 17.5 merge

複数の前週トピックが、翌週の1つのトピックに統合される場合。

```text
C_t,a1 → C_t+1,b
C_t,a2 → C_t+1,b
```

意味：

```text
複数のニュース軸が1つの大テーマに収束
```

例：

```text
Week 1: 円安
Week 1: インバウンド
Week 2: 訪日消費関連
```

---

## 17.6 drift

語彙分布は変化しているが、テーマ分布やエンティティ分布が近い場合、またはその逆です。

例：

```text
Week 1: AI半導体
Week 2: データセンター電力
```

語彙は変わるが、背景にある需要ドライバーは同じです。

投資上は、**テーマ間波及** として扱います。

---

# 18. Step B5：lineage_id の付与

継続リンクをたどり、同一系譜に `lineage_id` を付与します。

```text
lineage_id = L0001
  2026W01_T03: AI capex
  2026W02_T05: data center buildout
  2026W03_T02: power grid bottleneck
  2026W04_T09: cooling equipment
```

この `lineage_id` により、ニュース・トレンドの寿命を測れます。

## 18.1 persistence

トピック系譜の継続週数です。

$$
Persistence_{L,t}
=
\text{number of consecutive weeks in lineage } L
$$

テーマ $j$ のpersistenceは、テーマが帰属するlineageの加重平均にします。

$$
Persistence_{j,t}
=
\sum_L
Exposure_{j,L,t}
\cdot
Persistence_{L,t}
$$

---

# 19. Step B6：Topic Lineage から作る指標

Layer B の出力は、後段のテーマ特徴量に使います。

## 19.1 novelty

新しさです。  
過去 $N$ 週のトピックとの最小距離で測ります。

$$
Novelty(C_{t,a})
=
\min_{s<t, b}
D(C_{t,a}, C_{s,b})
$$

値が高いほど新しい話題です。

```text
高novelty:
  今まであまり出ていなかった新規トピック

低novelty:
  既存トピックの継続
```

## 19.2 persistence

lineageの継続週数です。

```text
高persistence:
  継続的に報道されているメガトレンド候補

低persistence:
  一過性イベント候補
```

## 19.3 drift_in

他テーマと関連していたトピックが、あるテーマに流入してきた強さです。

例：

```text
AI → 電力設備
AI → 空調
AI → 建設
```

テーマ $j$ へのdrift_inは、前週の主テーマが $j$ ではなく、今週のテーマ分布で $j$ の比率が上がったlineageの合計です。

$$
DriftIn_{j,t}
=
\sum_L
\max(
0,
p^{theme}_{L,t}(j)
-
p^{theme}_{L,t-1}(j)
)
\cdot
1[
\arg\max p^{theme}_{L,t-1} \neq j
]
$$

## 19.4 drift_out

自テーマのトピックが他テーマへ波及した強さです。

$$
DriftOut_{j,t}
=
\sum_L
\max(
0,
p^{theme}_{L,t-1}(j)
-
p^{theme}_{L,t}(j)
)
\cdot
1[
\arg\max p^{theme}_{L,t-1} = j
]
$$

解釈には注意が必要です。  
`drift_out` は必ずしも悪い意味ではありません。テーマが他領域へ波及している可能性もあります。  
ただし、投資対象テーマの純度が下がる場合もあります。

## 19.5 rare_topic_score

小さいが急に増えているクラスタを捉えます。

$$
RareScore(C_{t,a})
=
z(\Delta n_{articles})
-
z(n_{articles})
+
Novelty(C_{t,a})
$$

直感的には、

```text
過去には小さかった
今週急に出てきた
既存トピックから遠い
```

ものを高く評価します。

---

# 20. Layer B の出力

## 20.1 topic_lineage.parquet

```text
topic_lineage
  week
  topic_id
  global_topic_id
  lineage_id
  prev_topic_id
  next_topic_id
  link_distance
  link_similarity
  link_strength
  event_type
  persistence
  novelty
  split_flag
  merge_flag
  drift_flag
```

## 20.2 topic_links.parquet

```text
topic_links
  from_week
  from_topic_id
  to_week
  to_topic_id
  distance_word
  distance_theme
  distance_entity
  distance_total
  link_type
```

## 20.3 lineage_summary.csv

```text
lineage_summary
  lineage_id
  start_week
  end_week
  n_weeks
  max_articles
  total_articles
  dominant_terms
  dominant_themes
  representative_headlines
  event_sequence
```

## 20.4 図表

```text
outputs/figures/topic_lineage_network.png
outputs/figures/topic_birth_death_counts.png
outputs/figures/topic_persistence_distribution.png
outputs/figures/rare_topic_score_timeseries.png
```

---

# Layer A/B を合わせた処理イメージ

## 21. 全体フロー

```text
正規化済みニュース
  ↓
週ごとに分割
  ↓
各週でTF-IDF / SBERT表現を作成
  ↓
文書間類似度を計算
  ↓
kNNグラフを作成
  ↓
Leiden/Louvain/代替手法でクラスタリング
  ↓
各クラスタのtop_terms, 代表headline, article_idsを保存
  ↓
クラスタごとに語彙分布を作成
  ↓
隣接週クラスタ間のHellinger距離を計算
  ↓
最近傍リンクで週次トピックを接続
  ↓
continue / birth / death / split / merge / driftを判定
  ↓
lineage_idを付与
  ↓
novelty, persistence, drift, rare_topic_scoreを作成
```

---

# 22. Codex実装での推奨MVP

最初からすべて実装しない方がよいです。  
Layer A/Bだけなら、MVPは以下で十分です。

```text
MVP Layer A:
  - normalize_news_df
  - TF-IDF
  - cosine similarity
  - AgglomerativeClustering or KMeans fallback
  - topic_summary作成

MVP Layer B:
  - topic word distribution
  - Hellinger distance
  - adjacent-week nearest neighbor link
  - continue / birth / death判定
  - persistence / novelty作成
```

その後に拡張します。

```text
拡張1:
  SBERT embedding

拡張2:
  kNN graph + Leiden

拡張3:
  split / merge / drift判定

拡張4:
  theme_distribution / entity_distributionを距離に追加

拡張5:
  lineage network可視化
```

---

# 23. Codex向けの実装単位

Layer A/Bだけに絞るなら、Codexには以下のファイルを作らせるのがよいです。

```text
src/theme_news/
  preprocess.py
  embedding.py
  topic_graph.py
  topic_lineage.py
  reporting.py

main.ipynb
config.yaml
```

## topic_graph.py

主な関数：

```python
fit_tfidf_texts()
make_document_embeddings()
compute_similarity_matrix()
build_knn_graph()
cluster_weekly_news()
summarize_topic_clusters()
extract_weekly_topics()
```

## topic_lineage.py

主な関数：

```python
hellinger_distance()
make_topic_word_distribution()
compute_adjacent_week_topic_distances()
link_topics_over_time()
classify_lineage_events()
assign_lineage_ids()
compute_topic_novelty()
compute_topic_persistence()
```

## reporting.py

主な関数：

```python
plot_topic_counts()
plot_topic_lineage_network()
plot_persistence_distribution()
save_topic_summary_tables()
```

---

# 24. 設計上の重要な注意点

## 24.1 トピックIDは週ごとに独立

`topic_id = 3` が複数週に存在しても、同じトピックとは限りません。

したがって、必ず以下を分けます。

```text
topic_id:
  週内のクラスタID

global_topic_id:
  week + topic_id の一意ID

lineage_id:
  時間方向に接続されたトピック系列ID
```

例：

```text
topic_id = 3
global_topic_id = 2026-03-06_T003
lineage_id = L00012
```

---

## 24.2 クラスタリングは毎週独立に行う

全期間まとめてクラスタリングすると、将来情報が混じります。  
投資に使うなら、週 $t$ のトピック抽出は、週 $t$ までのニュースだけで行うべきです。

ただしMVPでは、TF-IDF vectorizerのfitだけは全期間で行うとリークの議論が出ます。  
厳密には以下です。

```text
研究探索:
  全期間fitでも可。ただし投資検証では注意書き。

本番バックテスト:
  過去期間だけでTF-IDF fit。
  週次でtransform。
```

Layer A/Bの探索段階では、まず全期間fitで動かし、後でwalk-forward化すればよいです。

---

## 24.3 小さい週の扱い

ニュース件数が少ない週は、クラスタリングが不安定です。

推奨ルール：

```text
N_articles < 20:
  その週はクラスタリングせず、全体を1トピック扱い

20 <= N_articles < 50:
  クラスタ数を少なめに制限

N_articles >= 50:
  通常クラスタリング
```

---

## 24.4 重複ニュースの扱い

Reutersニュースは更新記事や類似ヘッドラインが多いため、重複除去が重要です。

```text
同一story_id
同一headline
高類似headline
UPDATE 1 / UPDATE 2 の重複
```

重複を残すと、Buzzやクラスタサイズが人工的に膨らみます。  
一方、更新回数自体が市場注目度を表す場合もあるため、完全削除ではなく以下の設計が望ましいです。

```text
dedup_text_for_clustering = 重複除去後
raw_count_for_attention = 重複込み件数
```

---

# 25. Layer A/B の最終成果物イメージ

最終的に、Layer A/Bだけで以下のような情報が得られます。

```text
Lineage L0008
期間:
  2026-01-10 〜 2026-02-28

初期トピック:
  AI半導体投資

変化:
  AI半導体
  → データセンター建設
  → 電力インフラ
  → 空調・電線・建設資材

dominant terms:
  ai, chip, data center, power, grid, cooling, cable

event sequence:
  birth → continue → split → drift → continue

投資上の解釈:
  AIテーマ単独ではなく、周辺インフラテーマへ波及している。
  後段では、半導体、電力設備、電線、建設、空調関連テーマのdrift_inを高める。
```

このように、Layer A/Bは単なるトピック分類ではなく、**ニュース・トレンドの発生、継続、分岐、波及を投資特徴量化するための基盤**です。

## Response:
2026/5/7 21:52:47

以下は、今回の前提に合わせて再構築した **Codex実装指示書** です。  
そのままCodexに貼り付けることを想定しています。

---

# Codex実装指示書：Layer A/B Notebook-only 実装

```markdown
# Codex実装指示書：Topic Lineage News Analysis - Layer A/B Notebook-only Implementation

## 0. 最重要ルール

このプロジェクトでは、LSEG/Reutersニュースを用いたテーマバスケット投資の前処理基盤として、まず Layer A と Layer B を実装する。

将来的には Layer C, すなわちニュース特徴量をテーマ別リターン・売買代金・リスクへ写像する教師あり投資シグナル層を実装する予定である。ただし今回の実装対象は Layer A/B までとする。

最初に必ず `workspace/AGENTS.md` を読み、すべて遵守すること。
プロジェクト内に `AGENTS.md` がある場合は、`workspace/AGENTS.md` に次ぐ優先度で遵守すること。

実装ルール：
- 実装は `.py` ファイルに分割しない。
- 関数・クラス・設定・実行処理はすべてNotebook内に実装する。
- メイン実行ノートブックを `main.ipynb` とする。
- Layer A単体テスト用Notebookを `test_layer_a.ipynb` とする。
- Layer B単体テスト用Notebookを `test_layer_b.ipynb` とする。
- 必要に応じて `test_integration_ab.ipynb` を作成してよい。
- `.py` は作成しない。
- ただし `config.yaml`、`docs/`、`outputs/`、`data/` は作成してよい。
- 出力はすべて `outputs/` 以下に保存する。
- 依存関係は勝手に追加しない。
- 追加が必要な場合は、まず `docs/notes/dependency_request.md` に理由を記載する。
- `pip install` を直接実行しない。
- Python環境は `envs/base/.venv/bin/python` を優先する。
- 既存ファイルを破壊的に変更しない。
- `legacy/` がある場合は参照専用。編集禁止。
- 実装・説明・Notebook内Markdownは日本語で記述する。

## 1. プロジェクト目的

本プロジェクトの目的は、LSEG Data Libraryで取得したReutersニュースを対象に、テーマバスケット投資へ接続可能なニュース・トピック分析基盤を構築することである。

今回の対象は以下の2層である。

### Layer A: Graph-based Topic Extraction

ニュース記事群から、事前にテーマ名やトピック数を固定せず、自然発生しているニューストピックを抽出する。

主な処理：
- ニュース正規化
- 重複除去
- TF-IDFベクトル化
- 任意でSBERT埋め込み
- 類似度行列作成
- kNNグラフ構築
- クラスタリング
- トピック要約
- 代表headlineとtop termsの保存

### Layer B: Topic Lineage / Topic Alignment

Layer Aで週次に抽出されたトピックを時間方向につなぎ、トピックの継続・新規発生・消滅・分岐・統合・ドリフトを判定する。

主な処理：
- トピック語彙分布の作成
- Hellinger距離の計算
- 隣接週トピックの対応づけ
- lineage_idの付与
- novelty, persistence, rare_topic_score の作成
- split / merge / drift の判定
- topic lineage networkの可視化

## 2. 参照論文

以下の3論文を `docs/sources/` に配置し、Notebook内で参照できるようにする。

```text
docs/sources/
  FS-2022-J-001.pdf
  arxiv_2010_15067.pdf
  arxiv_2511_21741.pdf
```

各論文の役割：

### FS-2022-J-001.pdf

役割：
- 将来的なLayer Cの設計根拠。
- ニューストピックを市場反応に写像する教師ありモデルの参照。
- 今回はLayer A/Bの実装範囲外だが、後続拡張のために論文概要を `docs/notes/10_method_summary.md` に整理する。

### arxiv_2010_15067.pdf

役割：
- Layer Aの主参照。
- 文書ベクトル、類似度グラフ、マルチスケールクラスタリングによるニューストピック抽出の設計根拠。
- 厳密なMarkov Stabilityを最初から完全再現しなくてよい。
- 初期実装では、kNN graph + Leiden/Louvain、または依存関係なしの代替クラスタリングで近似する。

### arxiv_2511_21741.pdf

役割：
- Layer Bの主参照。
- Hellinger距離、Ward階層クラスタリング、マルチスケールなトピック整列の設計根拠。
- 今回は週次トピック間のHellinger距離によるalignmentを中心に実装する。

## 3. ディレクトリ構成

以下の構成を作成・維持する。

```text
project_root/
  AGENTS.md                         # ある場合のみ
  config.yaml

  main.ipynb                        # Layer A/B統合メインノートブック
  test_layer_a.ipynb                # Layer A単体テストNotebook
  test_layer_b.ipynb                # Layer B単体テストNotebook
  test_integration_ab.ipynb         # 任意、A/B統合テストNotebook

  docs/
    sources/
      FS-2022-J-001.pdf
      arxiv_2010_15067.pdf
      arxiv_2511_21741.pdf
    notes/
      00_doc_index.md
      10_method_summary.md
      20_assumptions.md
      30_implementation_plan.md
      40_layer_a_design.md
      50_layer_b_design.md
      90_future_layer_c_plan.md
      dependency_request.md

  data/
    raw/
      lseg_news_headlines.parquet
      lseg_news_stories.parquet
    interim/
    processed/

  outputs/
    tables/
    figures/
    logs/
    notebooks/
```

`.py` ファイルは作成しない。

## 4. Notebook構成

### 4.1 main.ipynb

`main.ipynb` は本プロジェクトのメインNotebookとする。  
Layer A/Bの全処理を上から順に実行できるようにする。

Notebook構成：

```text
0. タイトル・目的・参照論文
1. 設定読み込み
2. ライブラリimport
3. 入力データ確認
4. ニュース正規化
5. テキストクリーニング・重複除去
6. Layer A: 文書表現
7. Layer A: 類似度・グラフ構築
8. Layer A: 週次クラスタリング
9. Layer A: トピック要約
10. Layer B: トピック分布作成
11. Layer B: Hellinger距離計算
12. Layer B: 週次トピック接続
13. Layer B: lineage_id付与
14. Layer B: イベント分類
15. Layer B: novelty / persistence / rare_topic_score
16. 可視化
17. 出力保存
18. 結果サマリー
19. 今後のLayer C接続方針
```

### 4.2 test_layer_a.ipynb

Layer Aの単体テスト用Notebookとする。

目的：
- 小さいサンプルニュースで、Layer Aの各関数が動作することを確認する。
- TF-IDFのみで動くことを確認する。
- SBERTが使える場合はSBERT版も確認する。
- クラスタリング手法をconfigで切り替えられることを確認する。
- 出力 `weekly_topics` と `article_topic_assignment` の形式を検証する。

Notebook構成：

```text
1. サンプルニュース作成
2. config読み込み
3. clean_text確認
4. TF-IDF確認
5. 任意でSBERT確認
6. 類似度行列確認
7. クラスタリング確認
8. topic summary確認
9. assertベースの簡易テスト
```

### 4.3 test_layer_b.ipynb

Layer Bの単体テスト用Notebookとする。

目的：
- 人工的な週次トピックデータで、Hellinger距離とlineage接続が意図通り動くことを確認する。
- continue / birth / death / split / merge / drift の判定を確認する。
- novelty / persistence / rare_topic_score の計算を確認する。

Notebook構成：

```text
1. 人工weekly_topics作成
2. 人工word_distribution作成
3. Hellinger距離確認
4. 隣接週リンク確認
5. lineage_id確認
6. event_type確認
7. novelty / persistence確認
8. assertベースの簡易テスト
```

### 4.4 test_integration_ab.ipynb, 任意

Layer Aの出力をLayer Bへ渡す統合テスト用Notebookとする。

## 5. config.yaml設計

各Layerの拡張・採用手法はすべて `config.yaml` で制御できるようにする。

以下のような設定ファイルを作成する。

```yaml
project:
  name: topic_lineage_news_layer_ab
  description: "LSEG/Reutersニュースを対象にLayer A/BをNotebook-onlyで実装する"

paths:
  raw: data/raw
  interim: data/interim
  processed: data/processed
  outputs: outputs
  tables: outputs/tables
  figures: outputs/figures
  logs: outputs/logs
  docs: docs
  sources: docs/sources

papers:
  fs_2022_j_001: docs/sources/FS-2022-J-001.pdf
  graph_topic_2010_15067: docs/sources/arxiv_2010_15067.pdf
  topic_alignment_2511_21741: docs/sources/arxiv_2511_21741.pdf

run:
  random_state: 42
  save_outputs: true
  use_sample_data_if_missing: true
  verbose: true

news:
  week_anchor: W-FRI
  min_text_length: 30
  dedup:
    enable: true
    method: normalized_headline
    fuzzy_threshold: 0.95
    keep_update_count: true
  timestamp_priority:
    - versionCreated
    - firstCreated
    - timestamp_utc
    - retrieved_at_utc

layer_a:
  enable: true

  text:
    use_headline: true
    use_body: true
    lowercase: true
    remove_html: true
    remove_extra_spaces: true

  vectorizer:
    method: tfidf
    # options:
    #   tfidf
    #   sbert
    #   tfidf_sbert
    tfidf:
      max_features: 20000
      min_df: 3
      max_df: 0.80
      ngram_range: [1, 2]
      stop_words: english
    sbert:
      enable: false
      model_path: null
      batch_size: 64
      normalize_embeddings: true
    combine:
      sbert_weight: 0.60
      tfidf_weight: 0.40

  similarity:
    metric: cosine
    use_sparse: true

  graph:
    method: knn
    # options:
    #   none
    #   knn
    #   mst_knn
    k_neighbors: 10
    adaptive_k: true
    min_k: 2
    add_mst: false

  clustering:
    method: agglomerative
    # options:
    #   agglomerative
    #   kmeans
    #   louvain
    #   leiden
    #   hdbscan
    fallback_method: agglomerative
    min_articles_for_clustering: 20
    small_week_policy: single_topic
    resolutions: [0.5, 1.0, 1.5, 2.0]
    primary_resolution: 1.0
    agglomerative:
      distance_threshold: 0.65
      linkage: average
      n_clusters: null
    kmeans:
      n_clusters: auto
      min_clusters: 2
      max_clusters: 20

  topic_summary:
    top_n_terms: 15
    top_n_headlines: 5
    save_article_ids: true
    use_ctfidf: true

layer_b:
  enable: true

  distribution:
    primary: word
    # options:
    #   word
    #   word_theme
    #   word_theme_entity
    word:
      source: tfidf
      smoothing: 1.0e-12
    theme:
      enable: false
    entity:
      enable: false

  distance:
    method: hellinger
    alpha_word: 1.00
    beta_theme: 0.00
    gamma_entity: 0.00

  alignment:
    method: adjacent_nearest
    # options:
    #   adjacent_nearest
    #   mutual_nearest
    #   ward
    link_threshold: 0.55
    strong_link_requires_mutual: true
    allow_multiple_links: true
    max_links_per_topic: 3

  events:
    classify_continue: true
    classify_birth: true
    classify_death: true
    classify_split: true
    classify_merge: true
    classify_drift: true
    split_threshold: 0.60
    merge_threshold: 0.60
    drift_word_distance_min: 0.35
    drift_theme_distance_max: 0.35

  features:
    compute_novelty: true
    novelty_lookback_weeks: 12
    compute_persistence: true
    compute_rare_topic_score: true
    rare_topic_min_growth_z: 1.0

outputs:
  tables:
    news_summary: outputs/tables/news_summary.csv
    weekly_topics: outputs/tables/weekly_topics.csv
    article_topic_assignment: outputs/tables/article_topic_assignment.csv
    topic_links: outputs/tables/topic_links.csv
    topic_lineage: outputs/tables/topic_lineage.csv
    lineage_summary: outputs/tables/lineage_summary.csv
  parquet:
    clean_news: data/processed/clean_news.parquet
    weekly_topics: data/processed/weekly_topics.parquet
    article_topic_assignment: data/processed/article_topic_assignment.parquet
    topic_links: data/processed/topic_links.parquet
    topic_lineage: data/processed/topic_lineage.parquet
    lineage_summary: data/processed/lineage_summary.parquet
  figures:
    topic_count_by_week: outputs/figures/topic_count_by_week.png
    article_count_by_topic: outputs/figures/article_count_by_topic.png
    topic_lineage_network: outputs/figures/topic_lineage_network.png
    persistence_distribution: outputs/figures/persistence_distribution.png
    novelty_timeseries: outputs/figures/novelty_timeseries.png
```

## 6. Layer A 実装詳細

Layer AはNotebook内に以下の関数として実装する。

### 6.1 ニュース正規化関数

```python
def normalize_news_df(df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...
```

要件：
- LSEG由来の列揺れを吸収する。
- `timestamp_utc` をUTCに統一する。
- `date` と `week` を作る。
- `headline`, `body`, `text` を作る。
- 欠損headline/bodyがあっても落ちない。
- timezone aware / naive の混在で落ちない。

### 6.2 テキストクリーニング関数

```python
def clean_text(text: str, config: dict) -> str:
    ...
```

要件：
- HTML除去
- 改行・連続空白除去
- lowercase制御
- 短すぎるtextの除外

### 6.3 重複除去関数

```python
def deduplicate_news(df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...
```

要件：
- 同一 `story_id` の重複を除去。
- 正規化headlineベースで重複を除去。
- `raw_update_count` または `duplicate_count` を残す。
- クラスタリング用には重複除去後を使う。
- 後続のBuzz用途には重複込み件数も使えるよう、元件数を保持する。

### 6.4 TF-IDF作成関数

```python
def fit_tfidf(texts: list[str], config: dict):
    ...
```

```python
def transform_tfidf(vectorizer, texts: list[str]):
    ...
```

要件：
- `config["layer_a"]["vectorizer"]["tfidf"]` を読む。
- `max_features`, `min_df`, `max_df`, `ngram_range`, `stop_words` を反映。
- 空テキストや短文のみでも落ちない。

### 6.5 SBERT埋め込み関数

```python
def load_sbert_model(config: dict):
    ...
```

```python
def embed_texts_sbert(texts: list[str], model, config: dict) -> np.ndarray:
    ...
```

要件：
- `sentence_transformers` がない場合は警告を出してNoneを返す。
- `model_path` がnullの場合はデフォルトモデル名を使ってよいが、ネットワーク取得を前提にしない。
- ローカルモデルが存在しない場合はTF-IDFにフォールバックする。
- SBERTはMVP必須ではない。

### 6.6 類似度作成関数

```python
def compute_similarity_matrix(tfidf_matrix=None, sbert_embeddings=None, config=None):
    ...
```

要件：
- `tfidf`, `sbert`, `tfidf_sbert` をconfigで切り替える。
- cosine similarityを使う。
- `tfidf_sbert` の場合は重み付き平均。
- 大規模データではメモリに注意し、MVPでは週次単位で計算する。

### 6.7 kNNグラフ作成関数

```python
def build_knn_graph(similarity_matrix: np.ndarray, config: dict):
    ...
```

要件：
- 各記事から上位k件へedgeを張る。
- `adaptive_k` がtrueの場合、記事数に応じてkを調整する。
- `method=none` の場合はグラフを作らず、クラスタリングへ進む。
- `mst_knn` は拡張として実装する。難しければTODOとして残す。

### 6.8 週次クラスタリング関数

```python
def cluster_weekly_news(news_week_df: pd.DataFrame, tfidf_matrix_week, sbert_embeddings_week, config: dict):
    ...
```

要件：
- 週ごとに独立してクラスタリングする。
- 記事数が `min_articles_for_clustering` 未満なら `single_topic` とする。
- clustering methodはconfigで切り替える。
- 初期必須は `agglomerative` と `kmeans`。
- `louvain`, `leiden`, `hdbscan` は利用可能なら使い、なければfallbackする。
- `resolution sweep` はgraph系手法が使える場合に実装する。
- MVPではprimary結果を1つ返せばよいが、複数resolution結果も保存できる構造にする。

### 6.9 トピック要約関数

```python
def summarize_topics(news_week_df, labels, tfidf_matrix_week, vectorizer, config):
    ...
```

要件：
- topicごとに以下を作る。
  - week
  - topic_id
  - global_topic_id
  - n_articles
  - article_ids
  - top_terms
  - representative_headlines
  - mean_similarity_to_centroid
- top_termsはTF-IDFまたはc-TF-IDFで作る。
- representative_headlinesはクラスタ中心に近い記事を優先する。

### 6.10 Layer A 全体実行関数

```python
def run_layer_a(news_df: pd.DataFrame, config: dict):
    ...
```

返り値：
```python
weekly_topics: pd.DataFrame
article_topic_assignment: pd.DataFrame
layer_a_artifacts: dict
```

## 7. Layer B 実装詳細

Layer BもNotebook内に関数として実装する。

### 7.1 Hellinger距離

```python
def hellinger_distance(p: np.ndarray, q: np.ndarray, eps: float = 1e-12) -> float:
    ...
```

定義：

H(p, q) = 1 / sqrt(2) * ||sqrt(p) - sqrt(q)||_2

要件：
- p, q は非負に補正する。
- 合計が0の場合も落ちない。
- epsで平滑化する。
- 返り値は0以上1程度。

### 7.2 トピック語彙分布作成

```python
def make_topic_word_distributions(weekly_topics, article_topic_assignment, tfidf_matrix, vectorizer, config):
    ...
```

要件：
- 各topicについて、記事のTF-IDFを合計し、確率分布へ正規化する。
- 語彙が共通空間でそろうようにする。
- 出力はdictまたはDataFrameでよい。
- 後続の距離計算で使える形式にする。

### 7.3 隣接週トピック距離

```python
def compute_adjacent_topic_distances(weekly_topics, topic_distributions, config):
    ...
```

要件：
- week t と week t+1 の全topicペアについて距離を計算。
- 初期実装はword distributionのHellinger距離のみ。
- 将来拡張としてtheme/entity distanceを受け取れる設計にする。
- 出力は `topic_links_candidate` DataFrame。

出力列：
```text
from_week
from_topic_id
from_global_topic_id
to_week
to_topic_id
to_global_topic_id
distance_word
distance_theme
distance_entity
distance_total
```

### 7.4 トピックリンク

```python
def link_topics_over_time(distance_df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...
```

要件：
- `link_threshold` 以下のリンクを採用。
- `max_links_per_topic` を制御。
- `mutual_nearest` が有効な場合、双方向最近傍をstrong linkとする。
- 一方向リンクはweak linkとして保存する。
- split/merge判定に必要な複数リンクを残す。

出力：
```text
topic_links
  from_week
  from_global_topic_id
  to_week
  to_global_topic_id
  distance_total
  link_similarity
  link_strength
```

### 7.5 イベント分類

```python
def classify_lineage_events(weekly_topics, topic_links, config):
    ...
```

分類：
- continue
- birth
- death
- split
- merge
- drift

要件：
- 入次数・出次数でcontinue, split, mergeを判定。
- 前週リンクがなければbirth。
- 翌週リンクがなければdeath。
- driftは初期実装では簡易判定でよい。
- theme/entity distanceがない場合はdrift判定を弱めるかTODOにする。

### 7.6 lineage_id付与

```python
def assign_lineage_ids(weekly_topics, topic_links, event_df, config):
    ...
```

要件：
- continueリンクを中心に同一lineageを形成する。
- split/merge時は、主リンクを決めてlineage継続し、派生側に新lineageまたはbranch labelを付ける。
- 複雑なグラフ処理が難しければ、MVPでは貪欲法でよい。
- `lineage_id` は `L000001` のように付与する。

### 7.7 novelty計算

```python
def compute_topic_novelty(weekly_topics, topic_distributions, config):
    ...
```

定義：
- 過去N週のtopicとの最小距離。
- 値が高いほど新規性が高い。

```text
novelty(topic_t) = min distance to topics in lookback window
```

ただし直感的に「高いほどnoveltyが高い」ように、必要ならそのまま距離値を使う。

### 7.8 persistence計算

```python
def compute_topic_persistence(topic_lineage: pd.DataFrame, config: dict):
    ...
```

定義：
- 同一lineageが連続して観測された週数。
- 各topicに、そのlineageの継続週数を付与する。

### 7.9 rare_topic_score計算

```python
def compute_rare_topic_score(topic_lineage: pd.DataFrame, weekly_topics: pd.DataFrame, config: dict):
    ...
```

例：

rare_topic_score =
z(article_count_growth)
- z(article_count_level)
+ z(novelty)

要件：
- 小さいが急増しているtopicを高く評価する。
- article_countが極端に少ないtopicはノイズとして扱えるようにする。

### 7.10 Layer B 全体実行関数

```python
def run_layer_b(weekly_topics, article_topic_assignment, layer_a_artifacts, config):
    ...
```

返り値：
```python
topic_links: pd.DataFrame
topic_lineage: pd.DataFrame
lineage_summary: pd.DataFrame
layer_b_artifacts: dict
```

## 8. 可視化

Notebook内で以下の可視化を実装する。

### Layer A可視化

- 週別ニュース件数
- 週別トピック数
- トピックサイズ分布
- 上位トピックのtop terms一覧
- 代表headline一覧

### Layer B可視化

- topic lineage network
- birth/death/continue/split/merge件数推移
- persistence分布
- novelty時系列
- rare topic score上位トピック表
- lineageごとの代表headline推移

図表は `outputs/figures/` に保存する。

## 9. 出力ファイル

Notebook実行後、以下を保存する。

```text
data/processed/
  clean_news.parquet
  weekly_topics.parquet
  article_topic_assignment.parquet
  topic_links.parquet
  topic_lineage.parquet
  lineage_summary.parquet

outputs/tables/
  news_summary.csv
  weekly_topics.csv
  article_topic_assignment.csv
  topic_links.csv
  topic_lineage.csv
  lineage_summary.csv
  rare_topics_top.csv

outputs/figures/
  news_count_by_week.png
  topic_count_by_week.png
  topic_size_distribution.png
  topic_lineage_network.png
  lineage_event_counts.png
  persistence_distribution.png
  novelty_timeseries.png
  rare_topic_score_top.png
```

## 10. docs/notes に作成する文書

### 00_doc_index.md

内容：
- 参照論文一覧
- 各論文の役割
- 実装Notebook一覧
- 出力一覧

### 10_method_summary.md

内容：
- 3論文の要約
- Layer A/B/Cとの対応
- 今回実装範囲
- 今回実装しない範囲

### 20_assumptions.md

内容：
- LSEGニュース列の前提
- timestamp処理の前提
- 英語Reuters中心である前提
- RIC指定ニュース取得に依存しない前提
- TF-IDFを主軸にする理由
- SBERT/FinBERT/Leidenはオプション扱いである理由

### 30_implementation_plan.md

内容：
- 実装フェーズ
- Notebook構成
- テスト方針
- config制御方針

### 40_layer_a_design.md

内容：
- Layer Aの設計
- TF-IDF/SBERT
- 類似度
- kNN graph
- clustering
- topic summary

### 50_layer_b_design.md

内容：
- Layer Bの設計
- Hellinger距離
- topic link
- event classification
- lineage_id
- novelty/persistence/rare topic score

### 90_future_layer_c_plan.md

内容：
- 将来的なLayer C構想
- FS-2022-J-001との接続
- テーマ別ニュース特徴量
- 将来リターン・売買代金・リスクへの教師あり学習
- walk-forward検証方針

## 11. テストNotebookの要件

### test_layer_a.ipynb の完了条件

以下のassertを含める。

```python
assert len(clean_news) > 0
assert "week" in clean_news.columns
assert len(weekly_topics) > 0
assert "global_topic_id" in weekly_topics.columns
assert "top_terms" in weekly_topics.columns
assert "representative_headlines" in weekly_topics.columns
assert len(article_topic_assignment) > 0
assert article_topic_assignment["news_id"].notna().all()
```

### test_layer_b.ipynb の完了条件

以下のassertを含める。

```python
assert hellinger_distance(np.array([1, 0]), np.array([1, 0])) < 1e-8
assert hellinger_distance(np.array([1, 0]), np.array([0, 1])) > 0.9
assert len(topic_links) > 0
assert "lineage_id" in topic_lineage.columns
assert "event_type" in topic_lineage.columns
assert "persistence" in topic_lineage.columns
assert "novelty" in topic_lineage.columns
```

### main.ipynb の完了条件

以下を満たすこと。

- 上から順に実行できる。
- データがない場合はサンプルデータで最後まで動く。
- `.py` ファイルを作成しない。
- `config.yaml` で主要手法を切り替えられる。
- Layer A/Bの出力が `data/processed/` に保存される。
- 図表が `outputs/figures/` に保存される。
- docs/notes が作成される。
- Future Layer Cの接続方針がNotebook末尾に記載される。

## 12. 実装順序

以下の順に実装する。

### Step 1: プロジェクト構成確認

- `workspace/AGENTS.md` を読む。
- 必要ディレクトリを作成。
- 参照論文PDFが `docs/sources/` にあるか確認。
- なければ `docs/notes/00_doc_index.md` に不足ファイルとして記録する。
- PDFの本文解析は必須ではないが、存在確認と役割整理は行う。

### Step 2: config.yaml 作成

- 上記仕様に基づいて `config.yaml` を作成。
- Layer A/Bの手法切替が可能な形にする。

### Step 3: main.ipynb 骨格作成

- Markdownセルで目的・参照論文・Layer A/Bの概要を書く。
- config読み込み関数をNotebook内に実装。
- 必要ライブラリimport。
- サンプルデータ生成関数を実装。

### Step 4: Layer A 実装

- 正規化
- クリーニング
- 重複除去
- TF-IDF
- 任意SBERT
- 類似度
- clustering
- topic summary
- 出力保存

### Step 5: test_layer_a.ipynb 作成

- 小規模サンプルでLayer Aを検証。
- assertを含める。

### Step 6: Layer B 実装

- topic distribution
- Hellinger distance
- adjacent week distance
- topic links
- event classification
- lineage_id
- novelty/persistence/rare topic score
- 出力保存

### Step 7: test_layer_b.ipynb 作成

- 人工データでLayer Bを検証。
- assertを含める。

### Step 8: 統合確認

- main.ipynbを上から実行。
- outputsを確認。
- docs/notesを更新。

## 13. MVPと拡張の区別

### MVPで必須

- Notebook-only実装
- config.yaml制御
- TF-IDF
- AgglomerativeClusteringまたはKMeans
- Hellinger距離
- adjacent nearest topic alignment
- continue / birth / death
- novelty / persistence
- main.ipynb
- test_layer_a.ipynb
- test_layer_b.ipynb

### 拡張として実装

可能なら以下も実装する。

- SBERT埋め込み
- TF-IDF + SBERT合成類似度
- kNN graph
- MST + kNN graph
- Leiden/Louvain clustering
- resolution sweep
- split / merge
- drift判定
- rare_topic_score
- topic lineage network可視化

### 今回実装しない

- Layer Cの教師あり投資シグナル
- テーマ別将来リターン予測
- ポートフォリオバックテスト
- MLSTM完全実装
- 本格的なベイズ推定
- 銘柄レベル売買ウェイト構築

ただし、将来Layer Cに接続できるよう、Layer A/Bの出力スキーマは安定させる。

## 14. Layer C接続を見据えた出力スキーマ

将来Layer Cで使うため、以下の列は必ず残す。

### weekly_topics

```text
week
topic_id
global_topic_id
n_articles
article_ids
top_terms
representative_headlines
```

### topic_lineage

```text
week
topic_id
global_topic_id
lineage_id
event_type
persistence
novelty
rare_topic_score
link_distance
link_similarity
```

### article_topic_assignment

```text
news_id
week
global_topic_id
topic_weight
```

これらにより、将来以下を作れるようにする。

```text
テーマ別Buzz
テーマ別Breadth
テーマ別Novelty
テーマ別Persistence
テーマ別DriftIn / DriftOut
テーマ別RareTopicExposure
```

## 15. 注意点

- 今回は「研究開発用の探索Notebook」である。
- ただし、将来の投資バックテストでリークが問題にならないよう、時間軸を意識して実装する。
- 週次クラスタリングは各週独立で行う。
- 全期間TF-IDF fitは探索段階では許容するが、Notebook内に注意書きを入れる。
- 将来の厳密バックテストではwalk-forward TF-IDF fitに変更できる設計にする。
- 重複ニュースを完全に捨てるのではなく、クラスタリング用dedupデータと注目度計測用raw countを分ける。
- 記事本文がない場合でもheadlineだけで動作する。
- LSEG live fetchは今回必須ではない。既存parquet読み込みとサンプルデータ動作を優先する。
```

---

# 補足：今回の設計で特に重要な変更点

今回の指示書では、前回案から以下を明確に変更しています。

| 項目 | 変更後 |
|---|---|
| 実装形式 | `.py`なし、Notebook-only |
| メイン成果物 | `main.ipynb` |
| テスト | `test_layer_a.ipynb`, `test_layer_b.ipynb` |
| Layer C | 今回は実装しないが、将来接続を前提に出力スキーマ固定 |
| 論文 | `docs/sources/` にPDF配置 |
| 手法選択 | `config.yaml` で制御 |
| Layer A拡張 | TF-IDF, SBERT, kNN, MST-kNN, Leiden/Louvain, Agglomerative, KMeans |
| Layer B拡張 | Hellinger, adjacent nearest, mutual nearest, Ward, split/merge/drift, rare topic |
| 実務優先度 | まずTF-IDF + Agglomerative + Hellingerで安定動作 |

最初の実装では、**TF-IDF + AgglomerativeClustering + Hellinger alignment** を基準線にしてください。  
その後、configで **SBERT**, **kNN graph**, **Leiden/Louvain**, **split/merge/drift判定** を順に有効化して比較する設計が最も堅いです。

## Response:
2026/5/7 22:00:39

以下は、要件を反映して再構築した **Codex向け指示書の改訂版**です。  
ポイントは、Layer A/B を **初期実装ライン** と **完全版ライン** に明確に分け、まず初期実装を安定させ、その後に完全版を比較検証できる構成にすることです。

---

# Codex実装指示書：Layer A/B 段階実装版

```markdown
# Codex実装指示書：Topic Lineage News Analysis - Layer A/B Staged Notebook Implementation

## 0. 最重要ルール

このプロジェクトでは、LSEG/Reutersニュースを用いたテーマバスケット投資の前処理基盤として、Layer A と Layer B を実装する。

将来的には Layer C, すなわちニュース特徴量をテーマ別リターン・売買代金・リスクへ写像する教師あり投資シグナル層を実装する予定である。ただし今回の実装対象は Layer A/B までとする。

今回の実装では、Layer A/Bについて以下の2系統を段階的に実装する。

1. **初期実装ライン, baseline**
   - 実装安定性、解釈性、依存関係の少なさを優先する。
   - まずはこちらをメイン手法として完成させる。
   - Layer Cへ進む前の標準パイプライン候補とする。

2. **完全版ライン, full / research**
   - 参照論文の思想により忠実な拡張実装とする。
   - SBERT、kNN graph、MST-kNN、Leiden/Louvain、resolution sweep、Ward alignment、split/merge/drift判定などを含める。
   - 初期実装ラインと比較し、Layer Cへ進む際にどちらの出力を採用するか判断できるようにする。

最初に必ず `workspace/AGENTS.md` を読み、すべて遵守すること。
プロジェクト内に `AGENTS.md` がある場合は、`workspace/AGENTS.md` に次ぐ優先度で遵守すること。

実装ルール：
- `.py` ファイルは作成しない。
- 実装はすべてNotebook内に書く。
- メイン実行ノートブックは `main.ipynb` とする。
- Layer A単体テスト用Notebookは `test_layer_a.ipynb` とする。
- Layer B単体テスト用Notebookは `test_layer_b.ipynb` とする。
- 初期実装と完全版の比較用Notebookとして `test_layer_ab_methods.ipynb` を作成する。
- 必要に応じて `test_integration_ab.ipynb` を作成してよい。
- 関数、クラス、設定読み込み、実行処理はすべてNotebook内に実装する。
- `config.yaml`、`docs/`、`outputs/`、`data/` は作成してよい。
- 出力はすべて `outputs/` 以下に保存する。
- 依存関係は勝手に追加しない。
- 追加が必要な場合は、まず `docs/notes/dependency_request.md` に不足パッケージ、用途、代替案、導入優先度を記録する。
- `pip install` を直接実行しない。
- Python環境は `envs/base/.venv/bin/python` を優先する。
- 既存ファイルを破壊的に変更しない。
- `legacy/` がある場合は参照専用。編集禁止。
- 実装・説明・Notebook内Markdownは日本語で記述する。

---

## 1. プロジェクト目的

本プロジェクトの目的は、LSEG Data Libraryで取得したReutersニュースを対象に、テーマバスケット投資へ接続可能なニュース・トピック分析基盤を構築することである。

今回の対象は以下の2層である。

### Layer A: Graph-based Topic Extraction

ニュース記事群から、事前にテーマ名やトピック数を固定せず、自然発生しているニューストピックを抽出する。

### Layer B: Topic Lineage / Topic Alignment

Layer Aで週次に抽出されたトピックを時間方向につなぎ、トピックの継続・新規発生・消滅・分岐・統合・ドリフトを判定する。

今回の実装方針は以下である。

```text
Phase 1:
  初期実装ラインを完成させる。
  TF-IDF + Agglomerative/KMeans + Hellinger adjacent alignment を基準線とする。

Phase 2:
  完全版ラインを追加実装する。
  SBERT + kNN/MST-kNN graph + Leiden/Louvain + resolution sweep + Ward/mutual alignment を試す。

Phase 3:
  初期実装ラインと完全版ラインを同じ入力ニュースで比較する。
  安定性、解釈性、トピック一貫性、lineage品質、Layer C接続容易性を評価する。

Phase 4:
  Layer Cに進む際の推奨方針を `docs/notes/95_layer_c_handoff_decision.md` に整理する。
```

---

## 2. 参照論文

以下の3論文を `docs/sources/` に配置し、Notebook内で参照できるようにする。

```text
docs/sources/
  FS-2022-J-001.pdf
  arxiv_2010_15067.pdf
  arxiv_2511_21741.pdf
```

各論文の役割：

### FS-2022-J-001.pdf

- 将来的なLayer Cの設計根拠。
- ニューストピックを市場反応に写像する教師ありモデルの参照。
- 今回はLayer A/Bの実装範囲外。
- ただし、Layer Cへ渡すべき出力スキーマを定義するうえで参照する。

### arxiv_2010_15067.pdf

- Layer Aの主参照。
- 文書ベクトル、類似度グラフ、マルチスケールクラスタリングによるニューストピック抽出の設計根拠。
- 完全版では、文書埋め込み、kNN/MST-kNN graph、graph clustering、multi-resolution clusteringを可能な範囲で実装する。
- 初期実装では、TF-IDF + 距離ベースクラスタリングで近似する。

### arxiv_2511_21741.pdf

- Layer Bの主参照。
- Hellinger距離、Ward階層クラスタリング、マルチスケールなトピック整列の設計根拠。
- 初期実装では、Hellinger距離 + 隣接週最近傍リンクを実装する。
- 完全版では、Ward alignment、mutual nearest、split/merge/drift判定、マルチスケールlineageを実装する。

---

## 3. ディレクトリ構成

以下の構成を作成・維持する。

```text
project_root/
  AGENTS.md
  config.yaml

  main.ipynb
  test_layer_a.ipynb
  test_layer_b.ipynb
  test_layer_ab_methods.ipynb
  test_integration_ab.ipynb

  docs/
    sources/
      FS-2022-J-001.pdf
      arxiv_2010_15067.pdf
      arxiv_2511_21741.pdf
    notes/
      00_doc_index.md
      10_method_summary.md
      20_assumptions.md
      30_implementation_plan.md
      40_layer_a_design.md
      50_layer_b_design.md
      60_baseline_method_design.md
      70_full_method_design.md
      80_method_comparison_plan.md
      90_future_layer_c_plan.md
      95_layer_c_handoff_decision.md
      dependency_request.md

  data/
    raw/
      lseg_news_headlines.parquet
      lseg_news_stories.parquet
    interim/
    processed/

  outputs/
    tables/
    figures/
    logs/
    notebooks/
    baseline/
      tables/
      figures/
    full/
      tables/
      figures/
    comparison/
      tables/
      figures/
```

`.py` ファイルは作成しない。

---

## 4. 実装ラインの定義

## 4.1 初期実装ライン, baseline

初期実装ラインは、まず安定して動作させることを最優先する。

### Layer A baseline

採用手法：

```text
ニュース正規化
→ 重複除去
→ TF-IDF
→ cosine distance
→ AgglomerativeClustering または KMeans
→ topic summary
```

特徴：

- SBERTを使わない。
- graph clusteringを必須にしない。
- 外部依存を増やさない。
- TF-IDFのtop termsにより解釈性を確保する。
- クラスタリングは週次に独立して行う。
- 出力スキーマは完全版と共通にする。

baselineで必須のクラスタリング手法：

1. `agglomerative`
2. `kmeans`

デフォルトは `agglomerative` とする。

### Layer B baseline

採用手法：

```text
topic word distribution
→ Hellinger distance
→ adjacent-week nearest neighbor alignment
→ continue / birth / death 判定
→ lineage_id
→ novelty / persistence
```

特徴：

- theme distributionやentity distributionは使わない。
- word distributionのみでHellinger距離を計算する。
- split/merge/driftは最低限の簡易判定に留める。
- Layer Cへ渡すための基礎特徴量を安定生成する。

baselineで必須の出力：

- `weekly_topics`
- `article_topic_assignment`
- `topic_links`
- `topic_lineage`
- `lineage_summary`

---

## 4.2 完全版ライン, full / research

完全版ラインは、文献に近い発想を用いた研究用拡張である。

### Layer A full

採用候補：

```text
ニュース正規化
→ 重複除去
→ TF-IDF
→ SBERT embedding
→ TF-IDF/SBERT combined similarity
→ kNN graph または MST-kNN graph
→ Leiden / Louvain graph clustering
→ resolution sweep
→ multi-resolution topic summary
```

完全版で実装可能なら含める手法：

| 機能 | 優先度 | 備考 |
|---|---:|---|
| SBERT embedding | 高 | ローカルモデルがある場合のみ |
| TF-IDF + SBERT合成類似度 | 高 | configで重み制御 |
| kNN graph | 高 | sklearnで実装可能 |
| MST + kNN graph | 中 | scipy/networkxがある場合 |
| Louvain | 中 | 依存関係があれば |
| Leiden | 中 | 依存関係があれば |
| resolution sweep | 高 | graph clusteringがない場合もクラスタ数違いで近似 |
| c-TF-IDF topic summary | 高 | 解釈性向上 |
| HDBSCAN | 低 | 依存関係があれば |

完全版では、Markov Stabilityの完全再現は必須ではない。  
代わりに、**multi-resolution graph/community clustering** を実装し、文献の思想に沿った近似とする。

### Layer B full

採用候補：

```text
word distribution
+ optional theme distribution
+ optional entity distribution
→ mixed Hellinger distance
→ mutual nearest / Ward alignment
→ split / merge / drift 判定
→ lineage graph
→ novelty / persistence / rare_topic_score
→ lineage quality metrics
```

完全版で実装可能なら含める手法：

| 機能 | 優先度 | 備考 |
|---|---:|---|
| mixed Hellinger distance | 高 | word/theme/entityの重み付き距離 |
| mutual nearest alignment | 高 | 誤リンク抑制 |
| Ward alignment | 中 | scipyがあれば |
| split/merge判定 | 高 | 入次数・出次数で実装 |
| drift判定 | 中 | theme/entityがない場合はword変化のみ |
| rare_topic_score | 高 | 新興トピック検出 |
| lineage network可視化 | 中 | networkxがあれば |
| multi-resolution lineage | 中 | resolution別にlineage作成 |

完全版では、テーマ帰属やエンティティ抽出がまだ未実装でも動くようにする。  
その場合は `word distribution only` に自動フォールバックする。

---

## 5. config.yaml設計

初期実装ラインと完全版ラインを切り替えられるように、`config.yaml` は以下の構成にする。

```yaml
project:
  name: topic_lineage_news_layer_ab_staged
  description: "LSEG/Reutersニュースを対象にLayer A/Bをbaseline/fullの2系統でNotebook-only実装する"

paths:
  raw: data/raw
  interim: data/interim
  processed: data/processed
  outputs: outputs
  baseline_outputs: outputs/baseline
  full_outputs: outputs/full
  comparison_outputs: outputs/comparison
  tables: outputs/tables
  figures: outputs/figures
  docs: docs
  sources: docs/sources

papers:
  fs_2022_j_001: docs/sources/FS-2022-J-001.pdf
  graph_topic_2010_15067: docs/sources/arxiv_2010_15067.pdf
  topic_alignment_2511_21741: docs/sources/arxiv_2511_21741.pdf

run:
  mode: baseline
  # options:
  #   baseline
  #   full
  #   compare
  random_state: 42
  save_outputs: true
  use_sample_data_if_missing: true
  verbose: true

news:
  week_anchor: W-FRI
  min_text_length: 30
  timestamp_priority:
    - versionCreated
    - firstCreated
    - timestamp_utc
    - retrieved_at_utc
  dedup:
    enable: true
    method: normalized_headline
    fuzzy_threshold: 0.95
    keep_update_count: true

baseline:
  layer_a:
    vectorizer:
      method: tfidf
      tfidf:
        max_features: 20000
        min_df: 3
        max_df: 0.80
        ngram_range: [1, 2]
        stop_words: english
    similarity:
      metric: cosine
    clustering:
      method: agglomerative
      fallback_method: kmeans
      min_articles_for_clustering: 20
      small_week_policy: single_topic
      agglomerative:
        distance_threshold: 0.65
        linkage: average
        n_clusters: null
      kmeans:
        n_clusters: auto
        min_clusters: 2
        max_clusters: 12
    topic_summary:
      top_n_terms: 15
      top_n_headlines: 5
      use_ctfidf: true

  layer_b:
    distribution:
      primary: word
      smoothing: 1.0e-12
    distance:
      method: hellinger
      alpha_word: 1.00
      beta_theme: 0.00
      gamma_entity: 0.00
    alignment:
      method: adjacent_nearest
      link_threshold: 0.55
      max_links_per_topic: 1
      strong_link_requires_mutual: false
    events:
      classify_continue: true
      classify_birth: true
      classify_death: true
      classify_split: false
      classify_merge: false
      classify_drift: false
    features:
      compute_novelty: true
      novelty_lookback_weeks: 12
      compute_persistence: true
      compute_rare_topic_score: false

full:
  layer_a:
    vectorizer:
      method: tfidf_sbert
      # options:
      #   tfidf
      #   sbert
      #   tfidf_sbert
      tfidf:
        max_features: 30000
        min_df: 2
        max_df: 0.85
        ngram_range: [1, 2]
        stop_words: english
      sbert:
        enable: true
        model_path: data/model/paraphrase-multilingual-MiniLM-L12-v2
        batch_size: 64
        normalize_embeddings: true
        fallback_to_tfidf: true
      combine:
        sbert_weight: 0.60
        tfidf_weight: 0.40

    similarity:
      metric: cosine
      use_sparse: true

    graph:
      method: mst_knn
      # options:
      #   knn
      #   mst_knn
      k_neighbors: 10
      adaptive_k: true
      min_k: 2
      add_mst: true

    clustering:
      method: leiden
      # options:
      #   leiden
      #   louvain
      #   agglomerative
      #   kmeans
      #   hdbscan
      fallback_method: agglomerative
      min_articles_for_clustering: 20
      small_week_policy: single_topic
      resolutions: [0.5, 1.0, 1.5, 2.0]
      primary_resolution: 1.0
      agglomerative:
        distance_threshold: 0.65
        linkage: average
        n_clusters: null
      kmeans:
        n_clusters: auto
        min_clusters: 2
        max_clusters: 20

    topic_summary:
      top_n_terms: 20
      top_n_headlines: 7
      use_ctfidf: true
      save_multi_resolution: true

  layer_b:
    distribution:
      primary: word_theme_entity
      # options:
      #   word
      #   word_theme
      #   word_theme_entity
      word:
        source: tfidf
        smoothing: 1.0e-12
      theme:
        enable: false
        fallback_if_missing: true
      entity:
        enable: false
        fallback_if_missing: true

    distance:
      method: mixed_hellinger
      alpha_word: 0.50
      beta_theme: 0.35
      gamma_entity: 0.15
      fallback_to_word_only: true

    alignment:
      method: mutual_nearest
      # options:
      #   adjacent_nearest
      #   mutual_nearest
      #   ward
      link_threshold: 0.55
      strong_link_requires_mutual: true
      allow_multiple_links: true
      max_links_per_topic: 3

    events:
      classify_continue: true
      classify_birth: true
      classify_death: true
      classify_split: true
      classify_merge: true
      classify_drift: true
      split_threshold: 0.60
      merge_threshold: 0.60
      drift_word_distance_min: 0.35
      drift_theme_distance_max: 0.35

    features:
      compute_novelty: true
      novelty_lookback_weeks: 12
      compute_persistence: true
      compute_rare_topic_score: true
      rare_topic_min_growth_z: 1.0

comparison:
  metrics:
    topic_stability: true
    topic_size_balance: true
    lineage_coverage: true
    link_distance_summary: true
    event_distribution: true
    interpretability_score: true
  qualitative:
    save_top_lineages: true
    top_n_lineages: 20
    save_representative_headlines: true
```

---

## 6. main.ipynb の役割

`main.ipynb` は以下の3モードで動作させる。

```text
config["run"]["mode"] == "baseline":
  baselineのみ実行

config["run"]["mode"] == "full":
  fullのみ実行

config["run"]["mode"] == "compare":
  baselineとfullの両方を同じ入力で実行し、比較表を作成
```

Notebook構成：

```text
0. タイトル・目的・参照論文
1. config読み込み
2. ライブラリimport
3. 入力データ確認
4. サンプルデータ生成関数
5. 共通前処理
6. baseline Layer A 実行
7. baseline Layer B 実行
8. full Layer A 実行
9. full Layer B 実行
10. baseline/full比較
11. 出力保存
12. Layer C接続に向けた判断材料の整理
```

`mode=baseline` の場合は 6,7 を実行する。  
`mode=full` の場合は 8,9 を実行する。  
`mode=compare` の場合は 6〜10 をすべて実行する。

---

## 7. 共通前処理

baseline/fullで同じニュース入力を使うため、前処理は共通化する。

Notebook内に以下の関数を実装する。

```python
def load_config(path: str = "config.yaml") -> dict:
    ...

def ensure_directories(config: dict) -> None:
    ...

def check_reference_papers(config: dict) -> pd.DataFrame:
    ...

def load_or_create_news_data(config: dict) -> pd.DataFrame:
    ...

def normalize_news_df(df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...

def clean_text(text: str, config: dict) -> str:
    ...

def deduplicate_news(df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...
```

要件：

- LSEG由来の列揺れを吸収する。
- `timestamp_utc` をUTCに統一する。
- `date` と `week` を作る。
- `headline`, `body`, `text` を作る。
- 欠損headline/bodyがあっても落ちない。
- timezone aware / naive の混在で落ちない。
- 同一 `story_id` と正規化headlineで重複除去する。
- クラスタリング用には重複除去後データを使う。
- 将来のBuzz計測のため、`duplicate_count` または `raw_update_count` を保存する。

---

## 8. baseline Layer A 実装

baseline Layer Aでは、以下を必須実装する。

```text
TF-IDF
→ cosine distance
→ AgglomerativeClustering
→ fallback KMeans
→ topic summary
```

Notebook内に以下の関数を実装する。

```python
def fit_tfidf_baseline(texts: list[str], config: dict):
    ...

def compute_tfidf_similarity(tfidf_matrix):
    ...

def cluster_week_baseline(news_week_df, tfidf_matrix_week, config: dict):
    ...

def summarize_topics_baseline(news_week_df, labels, tfidf_matrix_week, vectorizer, config: dict):
    ...

def run_layer_a_baseline(news_df: pd.DataFrame, config: dict):
    ...
```

### 8.1 baseline Layer A の出力

```text
weekly_topics_baseline
article_topic_assignment_baseline
layer_a_artifacts_baseline
```

`weekly_topics_baseline` の必須列：

```text
method_name
week
resolution
topic_id
global_topic_id
n_articles
article_ids
top_terms
representative_headlines
mean_similarity_to_centroid
```

`method_name` は必ず `baseline` とする。

---

## 9. baseline Layer B 実装

baseline Layer Bでは、以下を必須実装する。

```text
word distribution
→ Hellinger distance
→ adjacent nearest link
→ continue / birth / death
→ lineage_id
→ novelty / persistence
```

Notebook内に以下の関数を実装する。

```python
def hellinger_distance(p: np.ndarray, q: np.ndarray, eps: float = 1e-12) -> float:
    ...

def make_topic_word_distributions(weekly_topics, article_topic_assignment, layer_a_artifacts, config):
    ...

def compute_adjacent_topic_distances_baseline(weekly_topics, topic_distributions, config):
    ...

def link_topics_baseline(distance_df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...

def classify_events_baseline(weekly_topics, topic_links, config: dict) -> pd.DataFrame:
    ...

def assign_lineage_ids_baseline(weekly_topics, topic_links, event_df, config: dict) -> pd.DataFrame:
    ...

def compute_novelty_baseline(topic_lineage, topic_distributions, config: dict) -> pd.DataFrame:
    ...

def compute_persistence_baseline(topic_lineage, config: dict) -> pd.DataFrame:
    ...

def run_layer_b_baseline(weekly_topics, article_topic_assignment, layer_a_artifacts, config):
    ...
```

### 9.1 baseline Layer B の出力

```text
topic_links_baseline
topic_lineage_baseline
lineage_summary_baseline
layer_b_artifacts_baseline
```

`topic_lineage_baseline` の必須列：

```text
method_name
week
topic_id
global_topic_id
lineage_id
event_type
prev_global_topic_id
next_global_topic_id
link_distance
link_similarity
persistence
novelty
rare_topic_score
```

`method_name` は必ず `baseline` とする。  
baselineでは `rare_topic_score` はNaNまたは簡易値でよい。

---

## 10. full Layer A 実装

full Layer Aでは、可能な範囲で以下を実装する。

```text
TF-IDF
+ optional SBERT
→ combined similarity
→ kNN / MST-kNN graph
→ Leiden / Louvain / fallback clustering
→ resolution sweep
→ c-TF-IDF topic summary
```

Notebook内に以下の関数を実装する。

```python
def load_sbert_model_full(config: dict):
    ...

def embed_texts_sbert_full(texts: list[str], model, config: dict) -> np.ndarray:
    ...

def compute_combined_similarity(tfidf_matrix, sbert_embeddings, config: dict):
    ...

def build_knn_graph_full(similarity_matrix: np.ndarray, config: dict):
    ...

def add_mst_edges_if_available(graph_or_edges, similarity_matrix: np.ndarray, config: dict):
    ...

def cluster_week_full(news_week_df, tfidf_matrix_week, sbert_embeddings_week, config: dict):
    ...

def summarize_topics_full(news_week_df, labels, tfidf_matrix_week, vectorizer, config: dict):
    ...

def run_layer_a_full(news_df: pd.DataFrame, config: dict):
    ...
```

要件：

- SBERTが使えない場合はTF-IDFのみにフォールバックする。
- Leiden/Louvainが使えない場合はAgglomerativeへフォールバックする。
- MST-kNNが使えない場合はkNNまたは距離ベースクラスタリングへフォールバックする。
- resolution sweepを実装する。graph系が使えない場合は、クラスタ数またはdistance_thresholdの複数設定で近似する。
- 完全版が一部失敗しても、baselineが壊れないようにする。

### 10.1 full Layer A の出力

```text
weekly_topics_full
article_topic_assignment_full
layer_a_artifacts_full
```

`weekly_topics_full` の必須列：

```text
method_name
week
resolution
topic_id
global_topic_id
n_articles
article_ids
top_terms
representative_headlines
mean_similarity_to_centroid
vectorizer_method
clustering_method
```

`method_name` は必ず `full` とする。

---

## 11. full Layer B 実装

full Layer Bでは、可能な範囲で以下を実装する。

```text
word distribution
+ optional theme distribution
+ optional entity distribution
→ mixed Hellinger distance
→ mutual nearest / Ward alignment
→ continue / birth / death / split / merge / drift
→ lineage_id
→ novelty / persistence / rare_topic_score
→ lineage network
```

Notebook内に以下の関数を実装する。

```python
def make_topic_distributions_full(weekly_topics, article_topic_assignment, layer_a_artifacts, config):
    ...

def compute_mixed_hellinger_distance(topic_dist_a, topic_dist_b, config: dict) -> dict:
    ...

def compute_adjacent_topic_distances_full(weekly_topics, topic_distributions, config: dict):
    ...

def link_topics_full(distance_df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...

def link_topics_ward_if_available(distance_df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...

def classify_events_full(weekly_topics, topic_links, config: dict) -> pd.DataFrame:
    ...

def assign_lineage_ids_full(weekly_topics, topic_links, event_df, config: dict) -> pd.DataFrame:
    ...

def compute_novelty_full(topic_lineage, topic_distributions, config: dict) -> pd.DataFrame:
    ...

def compute_persistence_full(topic_lineage, config: dict) -> pd.DataFrame:
    ...

def compute_rare_topic_score_full(topic_lineage, weekly_topics, config: dict) -> pd.DataFrame:
    ...

def run_layer_b_full(weekly_topics, article_topic_assignment, layer_a_artifacts, config):
    ...
```

要件：

- theme/entity distributionがない場合はword onlyにフォールバックする。
- mutual nearestを使い、strong/weak linkを区別する。
- split/mergeは入次数・出次数で判定する。
- driftは初期的には以下のどちらかで判定する。
  - word distanceは大きいがtheme/entity distanceは近い。
  - 前週と今週でtop termsが変化したが、lineageとして近い。
- Ward alignmentはscipyが使える場合のみ実装する。
- 実装困難な場合はTODOを残し、baselineへの影響は避ける。

### 11.1 full Layer B の出力

```text
topic_links_full
topic_lineage_full
lineage_summary_full
layer_b_artifacts_full
```

`topic_lineage_full` の必須列：

```text
method_name
week
topic_id
global_topic_id
lineage_id
event_type
prev_global_topic_id
next_global_topic_id
link_distance
link_similarity
link_strength
persistence
novelty
rare_topic_score
split_flag
merge_flag
drift_flag
```

`method_name` は必ず `full` とする。

---

## 12. baseline/full 比較実装

`mode=compare` の場合、同じ `clean_news` に対して baseline と full を両方実行し、比較表と図表を出力する。

Notebook内に以下の関数を実装する。

```python
def compare_layer_a_outputs(weekly_topics_baseline, weekly_topics_full, config):
    ...

def compare_layer_b_outputs(topic_lineage_baseline, topic_lineage_full, topic_links_baseline, topic_links_full, config):
    ...

def compute_method_quality_summary(...):
    ...

def save_method_comparison_outputs(...):
    ...
```

### 12.1 比較指標

Layer A比較：

| 指標 | 意味 |
|---|---|
| `n_topics_by_week` | 週別トピック数 |
| `avg_topic_size` | 平均クラスタサイズ |
| `topic_size_gini` | トピックサイズの偏り |
| `singleton_ratio` | 1記事クラスタ比率 |
| `top_terms_coverage` | top termsが空でない比率 |
| `representative_headline_coverage` | 代表headlineが存在する比率 |
| `topic_interpretability_proxy` | top terms/headlineの充実度による簡易スコア |

Layer B比較：

| 指標 | 意味 |
|---|---|
| `link_coverage` | トピックが前後週とリンクされる比率 |
| `avg_link_distance` | 平均リンク距離 |
| `strong_link_ratio` | strong link比率 |
| `birth_rate` | birth比率 |
| `death_rate` | death比率 |
| `continue_rate` | continue比率 |
| `split_merge_rate` | split/merge比率 |
| `avg_persistence` | 平均persistence |
| `high_persistence_lineage_count` | 長期lineage数 |
| `rare_topic_count` | rare topic数 |

### 12.2 qualitative比較

以下の表を保存する。

```text
outputs/comparison/tables/top_lineages_baseline.csv
outputs/comparison/tables/top_lineages_full.csv
outputs/comparison/tables/rare_topics_full.csv
outputs/comparison/tables/method_quality_summary.csv
```

各lineageについて以下を保存する。

```text
method_name
lineage_id
start_week
end_week
n_weeks
total_articles
dominant_terms
representative_headline_sequence
event_sequence
interpretation_note
```

`interpretation_note` は空欄でよい。後で人間が記入できるように列だけ作る。

---

## 13. テストNotebook

## 13.1 test_layer_a.ipynb

Layer Aのbaseline/fullを両方テストする。

テスト内容：

```text
1. 人工ニュースデータを作成
2. baseline Layer Aを実行
3. full Layer Aを実行
4. TF-IDFのみで動くことを確認
5. SBERTがない場合にfallbackすることを確認
6. clustering method切替を確認
7. 出力スキーマが共通であることを確認
```

必須assert：

```python
assert len(weekly_topics_baseline) > 0
assert len(article_topic_assignment_baseline) > 0
assert "global_topic_id" in weekly_topics_baseline.columns
assert "top_terms" in weekly_topics_baseline.columns
assert "representative_headlines" in weekly_topics_baseline.columns

assert len(weekly_topics_full) > 0
assert len(article_topic_assignment_full) > 0
assert set(["method_name", "week", "global_topic_id"]).issubset(weekly_topics_full.columns)
```

## 13.2 test_layer_b.ipynb

Layer Bのbaseline/fullを両方テストする。

テスト内容：

```text
1. 人工weekly_topicsを作成
2. 人工word_distributionを作成
3. baseline Layer Bを実行
4. full Layer Bを実行
5. Hellinger距離の基本性質を確認
6. continue/birth/death判定を確認
7. fullでsplit/merge/driftの簡易判定を確認
8. 出力スキーマが共通であることを確認
```

必須assert：

```python
assert hellinger_distance(np.array([1, 0]), np.array([1, 0])) < 1e-8
assert hellinger_distance(np.array([1, 0]), np.array([0, 1])) > 0.9

assert len(topic_lineage_baseline) > 0
assert "lineage_id" in topic_lineage_baseline.columns
assert "event_type" in topic_lineage_baseline.columns
assert "persistence" in topic_lineage_baseline.columns
assert "novelty" in topic_lineage_baseline.columns

assert len(topic_lineage_full) > 0
assert "lineage_id" in topic_lineage_full.columns
assert "event_type" in topic_lineage_full.columns
assert "rare_topic_score" in topic_lineage_full.columns
```

## 13.3 test_layer_ab_methods.ipynb

baseline/fullの比較専用Notebookとする。

目的：

- 同じニュースデータに対してbaseline/fullを実行する。
- 出力の安定性・解釈性・lineage品質を比較する。
- Layer Cに進む際にどちらを採用するか判断材料を作る。

必須出力：

```text
outputs/comparison/tables/method_quality_summary.csv
outputs/comparison/tables/top_lineages_baseline.csv
outputs/comparison/tables/top_lineages_full.csv
outputs/comparison/figures/topic_count_comparison.png
outputs/comparison/figures/link_coverage_comparison.png
outputs/comparison/figures/persistence_comparison.png
```

---

## 14. 出力ファイル

baseline出力：

```text
outputs/baseline/tables/
  weekly_topics.csv
  article_topic_assignment.csv
  topic_links.csv
  topic_lineage.csv
  lineage_summary.csv

outputs/baseline/figures/
  topic_count_by_week.png
  topic_size_distribution.png
  topic_lineage_network.png
  persistence_distribution.png
  novelty_timeseries.png
```

full出力：

```text
outputs/full/tables/
  weekly_topics.csv
  article_topic_assignment.csv
  topic_links.csv
  topic_lineage.csv
  lineage_summary.csv
  rare_topics_top.csv

outputs/full/figures/
  topic_count_by_week.png
  topic_size_distribution.png
  topic_lineage_network.png
  lineage_event_counts.png
  persistence_distribution.png
  novelty_timeseries.png
  rare_topic_score_top.png
```

共通processed出力：

```text
data/processed/
  clean_news.parquet
  weekly_topics_baseline.parquet
  article_topic_assignment_baseline.parquet
  topic_links_baseline.parquet
  topic_lineage_baseline.parquet
  lineage_summary_baseline.parquet
  weekly_topics_full.parquet
  article_topic_assignment_full.parquet
  topic_links_full.parquet
  topic_lineage_full.parquet
  lineage_summary_full.parquet
```

comparison出力：

```text
outputs/comparison/tables/
  method_quality_summary.csv
  layer_a_comparison.csv
  layer_b_comparison.csv
  top_lineages_baseline.csv
  top_lineages_full.csv
  rare_topics_full.csv

outputs/comparison/figures/
  topic_count_comparison.png
  link_coverage_comparison.png
  persistence_comparison.png
```

---

## 15. docs/notes に作成する文書

### 00_doc_index.md

- 参照論文一覧
- 各論文の役割
- Notebook一覧
- 出力一覧

### 10_method_summary.md

- 3論文の要約
- Layer A/B/Cとの対応
- 今回実装範囲
- 今回実装しない範囲

### 20_assumptions.md

- LSEGニュース列の前提
- timestamp処理の前提
- 英語Reuters中心である前提
- RIC指定ニュース取得に依存しない前提
- TF-IDFをbaselineにする理由
- SBERT/Leiden/Louvain等はfullラインで試験的に使う理由

### 30_implementation_plan.md

- baseline実装順序
- full実装順序
- 比較検証の順序
- Notebook構成

### 40_layer_a_design.md

- Layer Aの設計
- baseline Layer A
- full Layer A
- 文献との対応
- fallback方針

### 50_layer_b_design.md

- Layer Bの設計
- baseline Layer B
- full Layer B
- 文献との対応
- fallback方針

### 60_baseline_method_design.md

- 初期実装ラインの詳細
- 採用理由
- 利点
- 限界
- Layer C接続時の使い方

### 70_full_method_design.md

- 完全版ラインの詳細
- 採用理由
- 利点
- 限界
- 依存関係
- 失敗時のfallback

### 80_method_comparison_plan.md

- 比較指標
- 定量評価
- 定性評価
- Layer Cへ進む際の判断基準

### 90_future_layer_c_plan.md

- 将来的なLayer C構想
- FS-2022-J-001との接続
- テーマ別ニュース特徴量
- 将来リターン・売買代金・リスクへの教師あり学習
- walk-forward検証方針

### 95_layer_c_handoff_decision.md

初期状態ではテンプレートだけ作る。

内容：

```markdown
# Layer C Handoff Decision

## 1. 比較対象

- baseline Layer A/B
- full Layer A/B

## 2. 定量比較結果

後で `method_quality_summary.csv` の内容を転記する。

## 3. 定性評価

- 代表lineageの解釈可能性
- topic driftの自然さ
- rare topicの有用性
- 過剰分割・過剰統合の有無

## 4. Layer Cに渡す推奨出力

- baselineを使うか
- fullを使うか
- hybridにするか

## 5. 推奨理由

TBD

## 6. 残課題

TBD
```

---

## 16. 実装順序

### Step 1: プロジェクト構成確認

- `workspace/AGENTS.md` を読む。
- 必要ディレクトリを作成。
- 参照論文PDFが `docs/sources/` にあるか確認。
- 不足しているPDFがあれば `docs/notes/00_doc_index.md` に記録する。
- PDF本文の自動解析は必須ではないが、存在確認と役割整理は行う。

### Step 2: config.yaml 作成

- baseline/full/compareを切り替えられる構成にする。
- baselineをデフォルトにする。
- fullはオプションとして動かせるようにする。

### Step 3: main.ipynb 骨格作成

- Notebook冒頭で目的、参照論文、baseline/fullの違いを書く。
- config読み込み関数を実装。
- ディレクトリ作成関数を実装。
- サンプルニュース生成関数を実装。
- データがない場合も最後まで動くようにする。

### Step 4: baseline Layer A 実装

- TF-IDF
- Agglomerative
- KMeans fallback
- topic summary
- output保存

### Step 5: baseline Layer B 実装

- Hellinger
- adjacent nearest
- continue/birth/death
- lineage_id
- novelty/persistence
- output保存

### Step 6: baselineテスト

- `test_layer_a.ipynb`
- `test_layer_b.ipynb`
- baseline部分のassertを通す。

### Step 7: full Layer A 実装

- SBERT optional
- combined similarity
- kNN graph
- MST optional
- Leiden/Louvain optional
- fallback設計
- resolution sweep
- c-TF-IDF summary

### Step 8: full Layer B 実装

- mixed distance
- mutual nearest
- split/merge/drift
- rare_topic_score
- lineage network
- fallback設計

### Step 9: fullテスト

- `test_layer_a.ipynb`
- `test_layer_b.ipynb`
- full部分のassertを通す。
- 依存関係が不足する場合はfallbackで通す。

### Step 10: baseline/full比較

- `test_layer_ab_methods.ipynb` を作成。
- `mode=compare` で同じ入力データに対して両方実行。
- `method_quality_summary.csv` を作る。
- top lineagesを比較できるCSVを作る。

### Step 11: Layer C接続判断テンプレート作成

- `docs/notes/95_layer_c_handoff_decision.md` を作成。
- 比較結果を後で転記できる形にする。
- 現時点では結論を固定しない。

---

## 17. 採用判断基準

Layer Cへ進む際の採用判断は、単にfullが高度だから採用するのではなく、以下で判断する。

### baselineを採用すべき条件

- トピックが解釈しやすい。
- 代表headlineとtop termsが安定している。
- 過剰分割が少ない。
- lineageが自然に継続する。
- 出力が安定しており、Layer Cの特徴量化に使いやすい。
- fullが依存関係やパラメータ感応度で不安定。

### fullを採用すべき条件

- baselineでは拾えない言い換え・意味的類似を拾える。
- topic driftやsplit/mergeが自然に表現できる。
- rare topicが有用に見える。
- 長期lineageの解釈性が改善する。
- baselineよりlineage coverageやpersistence品質が明らかに良い。
- 依存関係・計算時間が実務上許容できる。

### hybridを採用すべき条件

- baselineの解釈性が高い。
- fullの意味類似・drift検出が有用。
- Layer Cにはbaseline topicを主系列として渡し、full由来のnovelty/drift/rare_topic_scoreだけを補助特徴量として使う方がよい。

Layer Cへ進む時点では、以下の3案を比較候補とする。

```text
Option 1:
  baseline Layer A/B のみを採用

Option 2:
  full Layer A/B のみを採用

Option 3:
  baseline topicを主系列とし、full lineage特徴量を補助特徴量として採用
```

---

## 18. 今回実装しないもの

以下は今回実装しない。

- Layer Cの教師あり投資シグナル
- テーマ別将来リターン予測
- ポートフォリオバックテスト
- MLSTM完全実装
- 本格的なベイズ推定
- 銘柄レベルウェイト構築
- LSEG live fetchの本格運用

ただし、将来Layer Cに接続できるよう、Layer A/Bの出力スキーマは安定させる。

---

## 19. 完了条件

以下が満たされたら今回の実装は完了。

- `main.ipynb` が上から順に実行できる。
- `config.yaml` の `run.mode=baseline` でbaselineが完走する。
- `config.yaml` の `run.mode=full` でfullが完走する。依存関係不足時はfallbackで完走する。
- `config.yaml` の `run.mode=compare` でbaseline/full比較が完走する。
- `.py` ファイルが作成されていない。
- `test_layer_a.ipynb` が実行できる。
- `test_layer_b.ipynb` が実行できる。
- `test_layer_ab_methods.ipynb` が実行できる。
- `outputs/baseline/` にbaseline出力が保存される。
- `outputs/full/` にfull出力が保存される。
- `outputs/comparison/` に比較結果が保存される。
- `docs/notes/` に設計文書が作成される。
- `docs/notes/95_layer_c_handoff_decision.md` が作成される。
- Layer Cに渡すための出力スキーマが維持されている。
```

---

## 使い方

この指示書をCodexに貼る前に、プロジェクト側では以下だけ準備してください。

```text
docs/sources/
  FS-2022-J-001.pdf
  arxiv_2010_15067.pdf
  arxiv_2511_21741.pdf
```

最初は `config.yaml` の `run.mode` を以下にしてください。

```yaml
run:
  mode: baseline
```

baselineが安定した後に、

```yaml
run:
  mode: full
```

最後に、

```yaml
run:
  mode: compare
```

で比較します。

最終的にLayer Cへ進む際は、`outputs/comparison/tables/method_quality_summary.csv` と `docs/notes/95_layer_c_handoff_decision.md` を見て、次のいずれかを選ぶ設計です。

```text
1. baselineを主系列にする
2. fullを主系列にする
3. baselineを主系列、fullを補助特徴量にする
```

私の推奨は、現時点では **3. baselineを主系列、fullを補助特徴量にする** です。  
理由は、Layer Cでは特徴量の安定性と解釈性が重要であり、full側は有用でもパラメータ感応度が高くなりやすいからです。

## Response:
2026/5/7 22:05:28

LSEG取得部分を「API呼び出し制御」「parquetキャッシュ」「Broad query設計」に組み込み、分析結果はファイル保存中心ではなくNotebook表示中心に組み替えます。Layer A/Bの可視化も、論文の発想に対応する形でbaseline/fullの両方に入れます。

以下は、追加要件を反映した **Codex向け指示書の再設計版**です。  
大きな変更点は次の4点です。

1. **分析結果は原則Notebook上に表示**し、CSV・画像を大量に保存しない。  
2. **LSEGニュース取得はparquetキャッシュ前提**にし、API再取得を避ける。  
3. **ニュース取得クエリ設計をconfig化**し、small / medium / large などで実行規模を制御する。  
4. Layer A/Bの可視化は、論文の発想に対応する形でNotebook内に表示する。

なお、LSEG Data Library for Pythonでは、ニュースヘッドライン取得に `ld.news.get_headlines()`、本文取得に `ld.news.get_story()` を使うサンプルが公式・サンプルNotebookで示されています。ヘッドライン取得結果が制限で切り詰められる場合があるため、取得期間の分割・ページネーション・parquetキャッシュを前提にします。([developers.lseg.com](https://developers.lseg.com/en/article-catalog/article/getting-top-news-energy-headlines-and-stories-using-lseg-data-li?utm_source=chatgpt.com))

---

# Codex実装指示書：Layer A/B 段階実装・Notebook表示・LSEG parquet cache版

```markdown
# Codex実装指示書：
# Topic Lineage News Analysis - Layer A/B Staged Notebook Implementation with LSEG Cache

## 0. 最重要ルール

このプロジェクトでは、LSEG/Reutersニュースを用いたテーマバスケット投資の前処理基盤として、Layer A と Layer B を実装する。

将来的には Layer C, すなわちニュース特徴量をテーマ別リターン・売買代金・リスクへ写像する教師あり投資シグナル層を実装する予定である。ただし今回の実装対象は Layer A/B までとする。

今回の実装では、Layer A/Bについて以下の2系統を段階的に実装する。

1. 初期実装ライン, baseline
   - 実装安定性、解釈性、依存関係の少なさを優先する。
   - 基本はこちらを主線として実装・ブラッシュアップする。
   - TF-IDF + Agglomerative/KMeans + Hellinger adjacent alignment を基準線とする。

2. 完全版ライン, full / research
   - 参照論文の思想により忠実な拡張実装とする。
   - SBERT, kNN graph, MST-kNN, Leiden/Louvain, resolution sweep, Ward/mutual alignment, split/merge/drift判定などを可能な範囲で含める。
   - 初期実装ラインと比較し、Layer Cへ進む際にどちらの出力を採用するか判断できるようにする。

最初に必ず `workspace/AGENTS.md` を読み、すべて遵守すること。
プロジェクト内に `AGENTS.md` がある場合は、`workspace/AGENTS.md` に次ぐ優先度で遵守すること。

実装ルール：
- `.py` ファイルは作成しない。
- 実装はすべてNotebook内に書く。
- メイン実行ノートブックは `main.ipynb` とする。
- Layer A単体テスト用Notebookは `test_layer_a.ipynb` とする。
- Layer B単体テスト用Notebookは `test_layer_b.ipynb` とする。
- baseline/full比較Notebookとして `test_layer_ab_methods.ipynb` を作成する。
- 関数、クラス、設定読み込み、実行処理はすべてNotebook内に実装する。
- `config.yaml`、`docs/`、`data/` は作成してよい。
- 出力CSVやPNGを原則として大量保存しない。
- 分析結果、表、プロットはNotebook上に表示する。
- 例外として、LSEGから取得したニュースデータは `data/raw/` にparquet形式で保存する。
- 例外として、正規化済みニュースや中間結果は再実行効率のため `data/processed/` または `data/interim/` にparquet保存してよい。
- 可視化結果は原則Notebook上に表示し、画像保存は行わない。必要な場合のみconfigで保存可能にする。
- 依存関係は勝手に追加しない。
- 追加が必要な場合は、まず `docs/notes/dependency_request.md` に不足パッケージ、用途、代替案、導入優先度を記録する。
- `pip install` を直接実行しない。
- Python環境は `envs/base/.venv/bin/python` を優先する。
- 既存ファイルを破壊的に変更しない。
- `legacy/` がある場合は参照専用。編集禁止。
- 実装・説明・Notebook内Markdownは日本語で記述する。

---

## 1. プロジェクト目的

本プロジェクトの目的は、LSEG Data Libraryで取得したReutersニュースを対象に、テーマバスケット投資へ接続可能なニュース・トピック分析基盤を構築することである。

今回の対象は以下の2層である。

### Layer A: Graph-based Topic Extraction

ニュース記事群から、事前にテーマ名やトピック数を固定せず、自然発生しているニューストピックを抽出する。

### Layer B: Topic Lineage / Topic Alignment

Layer Aで週次に抽出されたトピックを時間方向につなぎ、トピックの継続・新規発生・消滅・分岐・統合・ドリフトを判定する。

今回の実装方針は以下である。

```text
Phase 1:
  LSEGニュース取得・parquetキャッシュを実装する。
  取得規模はconfigで制御する。

Phase 2:
  baseline Layer A/Bを完成させる。
  Notebook上で表とプロットを確認しながらブラッシュアップする。

Phase 3:
  full Layer A/Bを追加実装する。
  論文に近い手法を参考実装としてテストする。

Phase 4:
  baseline/fullを比較する。
  最終的にLayer Cへ進む際、baseline / full / hybrid のどれを使うか判断する。
```

---

## 2. 参照論文

以下の3論文を `docs/sources/` に配置し、Notebook内で参照できるようにする。

```text
docs/sources/
  FS-2022-J-001.pdf
  arxiv_2010_15067.pdf
  arxiv_2511_21741.pdf
```

各論文の役割：

### FS-2022-J-001.pdf

- 将来的なLayer Cの設計根拠。
- ニューストピックを市場反応に写像する教師ありモデルの参照。
- 今回はLayer A/Bの実装範囲外。
- ただし、Layer Cへ渡すべき出力スキーマを定義するうえで参照する。

### arxiv_2010_15067.pdf

- Layer Aの主参照。
- 文書ベクトル、類似度グラフ、マルチスケールクラスタリングによるニューストピック抽出の設計根拠。
- baselineでは、TF-IDF + 距離ベースクラスタリングで近似する。
- fullでは、TF-IDF/SBERT, kNN/MST-kNN graph, Leiden/Louvain, resolution sweepを可能な範囲で実装する。

### arxiv_2511_21741.pdf

- Layer Bの主参照。
- Hellinger距離、Ward階層クラスタリング、マルチスケールなトピック整列の設計根拠。
- baselineでは、Hellinger距離 + 隣接週最近傍リンクを実装する。
- fullでは、mutual nearest, Ward alignment, split/merge/drift, rare topic scoreを実装する。

---

## 3. ディレクトリ構成

以下の構成を作成・維持する。

```text
project_root/
  AGENTS.md
  config.yaml

  main.ipynb
  test_layer_a.ipynb
  test_layer_b.ipynb
  test_layer_ab_methods.ipynb
  test_integration_ab.ipynb

  docs/
    sources/
      FS-2022-J-001.pdf
      arxiv_2010_15067.pdf
      arxiv_2511_21741.pdf
    notes/
      00_doc_index.md
      10_method_summary.md
      20_assumptions.md
      30_implementation_plan.md
      40_layer_a_design.md
      50_layer_b_design.md
      60_baseline_method_design.md
      70_full_method_design.md
      80_method_comparison_plan.md
      90_future_layer_c_plan.md
      95_layer_c_handoff_decision.md
      dependency_request.md

  data/
    raw/
      lseg_news_headlines_*.parquet
      lseg_news_stories_*.parquet
      lseg_news_combined_*.parquet
    interim/
    processed/

  notebooks_cache/
    optional/
```

`.py` ファイルは作成しない。

`outputs/` は原則使わない。  
ただし既存のAGENTS.mdがoutputs利用を求める場合でも、本プロジェクトではNotebook表示を優先し、保存が必要なデータは `data/` 配下に置く。

---

## 4. LSEGニュース取得設計

## 4.1 基本方針

LSEG Data Library for Pythonを使ってReutersニュースを取得する。

想定API：
- `ld.news.get_headlines(...)`
- `ld.news.get_story(story_id, format=ld.news.Format.TEXT)`

ただし、環境によってLSEGセッションや権限がない可能性があるため、以下を守る。

- `lseg.data` がimportできない場合は、警告を出してサンプルデータまたは既存parquetを使う。
- LSEGセッションが開けない場合もNotebook全体を止めない。
- API取得済みデータがparquetに存在する場合、デフォルトでは再取得しない。
- 再取得する場合のみ `config["lseg"]["force_refresh"] = true` とする。
- APIを繰り返し呼ばないよう、取得単位ごとにparquet cacheを作る。
- 大量本文取得を避けるため、headline取得とstory本文取得を分離する。
- `max_headlines_per_query`, `max_stories_per_query`, `date_chunk_days`, `query_scale` をconfigで制御する。

---

## 4.2 LSEG取得規模

configで以下の実行規模を切り替える。

```text
tiny:
  API接続テスト用。数日、少数query、少数headlineのみ。

small:
  開発用。1〜2週間、主要queryのみ、本文少数。

medium:
  研究用。数カ月、複数query、代表本文取得。

large:
  本格分析用。1年以上、全query、本文取得多め。

cache_only:
  APIを一切呼ばず、既存parquetのみ読む。
```

---

## 4.3 LSEGクエリ設計

RIC指定には依存しない。  
Broad queryを中心に設計する。

### 推奨query groups

以下を `config.yaml` に持たせる。

```yaml
lseg:
  enable_fetch: false
  force_refresh: false
  query_scale: small
  use_cached_if_available: true
  cache_dir: data/raw

  session:
    open_session: true
    config_name: null

  fetch:
    start_date: "2025-01-01"
    end_date: "2025-03-31"
    date_chunk_days: 7
    max_headlines_per_query: 100
    max_stories_per_query: 30
    fetch_stories: true
    story_format: text
    sleep_seconds: 0.2

  scales:
    tiny:
      start_date: "2025-01-01"
      end_date: "2025-01-07"
      query_names: ["japan_broad_en"]
      max_headlines_per_query: 20
      max_stories_per_query: 5
      date_chunk_days: 7
    small:
      start_date: "2025-01-01"
      end_date: "2025-01-31"
      query_names: ["japan_broad_en", "japan_market_en", "macro_policy_en", "technology_en"]
      max_headlines_per_query: 100
      max_stories_per_query: 30
      date_chunk_days: 7
    medium:
      start_date: "2024-07-01"
      end_date: "2025-03-31"
      query_names:
        - japan_broad_en
        - japan_market_en
        - macro_policy_en
        - technology_en
        - energy_infra_en
        - financials_en
        - healthcare_en
        - consumer_en
        - materials_industrials_en
      max_headlines_per_query: 250
      max_stories_per_query: 100
      date_chunk_days: 7
    large:
      start_date: "2022-01-01"
      end_date: "2025-03-31"
      query_names:
        - japan_broad_en
        - japan_market_en
        - macro_policy_en
        - technology_en
        - energy_infra_en
        - financials_en
        - healthcare_en
        - consumer_en
        - materials_industrials_en
        - geopolitics_supplychain_en
        - global_markets_en
      max_headlines_per_query: 500
      max_stories_per_query: 300
      date_chunk_days: 3

  queries:
    japan_broad_en:
      description: "Japan broad Reuters English news"
      query: 'Japan AND Language:LEN AND Source:RTRS'
    japan_market_en:
      description: "Japan equity and market news"
      query: '(Japan OR Tokyo OR TOPIX OR Nikkei) AND (stocks OR shares OR market OR earnings) AND Language:LEN AND Source:RTRS'
    macro_policy_en:
      description: "BOJ, rates, fiscal and policy"
      query: '(BOJ OR Bank of Japan OR yen OR inflation OR rates OR yield OR fiscal OR policy) AND Language:LEN AND Source:RTRS'
    technology_en:
      description: "AI, semiconductors, data center, software"
      query: '(AI OR artificial intelligence OR semiconductor OR chip OR data center OR cloud OR software) AND Language:LEN AND Source:RTRS'
    energy_infra_en:
      description: "Energy, power, grid, infrastructure"
      query: '(energy OR power OR electricity OR grid OR renewable OR nuclear OR infrastructure OR utility) AND Language:LEN AND Source:RTRS'
    financials_en:
      description: "Banks, insurers, brokers"
      query: '(bank OR banking OR insurer OR insurance OR brokerage OR securities OR lender) AND Language:LEN AND Source:RTRS'
    healthcare_en:
      description: "Healthcare, pharma, biotech, medical devices"
      query: '(healthcare OR pharma OR drug OR biotech OR medical OR hospital OR obesity) AND Language:LEN AND Source:RTRS'
    consumer_en:
      description: "Consumer, retail, tourism, inbound"
      query: '(consumer OR retail OR tourism OR travel OR inbound OR restaurant OR apparel) AND Language:LEN AND Source:RTRS'
    materials_industrials_en:
      description: "Materials, machinery, construction, capex"
      query: '(materials OR chemical OR steel OR machinery OR construction OR factory OR capex OR automation) AND Language:LEN AND Source:RTRS'
    geopolitics_supplychain_en:
      description: "Geopolitics and supply chain"
      query: '(geopolitics OR tariffs OR sanctions OR supply chain OR China OR Taiwan OR export controls) AND Language:LEN AND Source:RTRS'
    global_markets_en:
      description: "Global market risk and cross-asset"
      query: '(markets OR stocks OR bonds OR yields OR dollar OR oil OR gold) AND Language:LEN AND Source:RTRS'
```

注意：
- LSEG Newsの検索構文は環境・権限・サービス仕様により微調整が必要な場合がある。
- Query文字列はNotebook内で表示し、必要に応じてユーザーが修正できるようにする。
- 最初は `tiny` または `small` で動作確認し、`medium` 以上はキャッシュが効くことを確認してから使う。

---

## 4.4 LSEG取得関数

Notebook内に以下の関数を実装する。

```python
def resolve_lseg_scale_config(config: dict) -> dict:
    """
    lseg.query_scale に応じて start_date, end_date, query_names,
    max_headlines_per_query, max_stories_per_query, date_chunk_days を決定する。
    """

def build_date_chunks(start_date: str, end_date: str, chunk_days: int) -> list[tuple[str, str]]:
    """
    長期間取得を小さい期間に分割する。
    """

def make_lseg_cache_paths(config: dict, scale_cfg: dict) -> dict:
    """
    query_scale, start_date, end_date, query_namesから一意なparquet保存名を作る。
    """

def open_lseg_session_if_needed(config: dict):
    """
    lseg.dataをimportし、必要ならld.open_session()を試みる。
    失敗時は例外で止めず、Noneを返す。
    """

def fetch_lseg_headlines_for_query(ld, query_name: str, query: str, start: str, end: str, count: int) -> pd.DataFrame:
    """
    ld.news.get_headlines を使ってheadlineを取得する。
    取得に失敗した場合は空DataFrameを返し、エラーを表示する。
    """

def fetch_lseg_stories(ld, headlines_df: pd.DataFrame, max_stories: int, sleep_seconds: float) -> pd.DataFrame:
    """
    storyIdごとに ld.news.get_story を使って本文を取得する。
    取得件数はmax_storiesで制御する。
    """

def fetch_lseg_news_with_cache(config: dict) -> pd.DataFrame:
    """
    parquet cacheが存在し、force_refresh=falseならcacheを読む。
    cacheがなければLSEG APIから取得してparquet保存する。
    fetch_stories=trueなら本文も取得し、headlineと結合する。
    """

def load_cached_lseg_news(config: dict) -> pd.DataFrame:
    """
    cache_onlyモードまたはAPI不可時に既存parquetを読む。
    """
```

---

## 4.5 parquet保存ルール

LSEG APIで取得したニュースは必ずparquet保存する。

保存対象：

```text
data/raw/lseg_news_headlines_{scale}_{start}_{end}_{hash}.parquet
data/raw/lseg_news_stories_{scale}_{start}_{end}_{hash}.parquet
data/raw/lseg_news_combined_{scale}_{start}_{end}_{hash}.parquet
```

保存する列：

```text
query_name
query
chunk_start
chunk_end
storyId
story_id
versionCreated
firstCreated
sourceCode
source
headline
language
subjects
audiences
retrieved_at_utc
body
story_fetch_status
```

列名はLSEGの返却形式に合わせて柔軟に吸収する。

---

## 5. Notebook表示方針

本プロジェクトでは、分析結果は原則Notebook上で表示する。

### 保存するもの

保存してよいもの：

```text
data/raw/*.parquet
data/interim/*.parquet
data/processed/*.parquet
config.yaml
docs/notes/*.md
```

### 原則保存しないもの

原則保存しないもの：

```text
outputs/tables/*.csv
outputs/figures/*.png
```

### Notebookで表示するもの

- DataFrame summary
- top topics table
- representative headlines
- topic terms
- similarity heatmap
- topic size distribution
- topic count by week
- topic lineage graph
- birth/death/continue/split/merge count
- persistence distribution
- novelty trend
- rare topic ranking
- baseline/full comparison table

ただし、configで明示した場合のみCSV・PNG保存を許可する。

```yaml
notebook_display:
  display_tables: true
  display_plots: true
  save_tables: false
  save_figures: false
  max_display_rows: 30
  max_headlines_per_topic_display: 5
```

---

## 6. Layer A baseline

## 6.1 baseline Layer A 手法

baselineでは以下を採用する。

```text
clean news
→ TF-IDF
→ cosine distance
→ AgglomerativeClustering
→ KMeans fallback
→ topic summary
```

Notebook内に以下の関数を実装する。

```python
def fit_tfidf_baseline(texts: list[str], config: dict):
    ...

def compute_tfidf_similarity(tfidf_matrix):
    ...

def cluster_week_baseline(news_week_df, tfidf_matrix_week, config: dict):
    ...

def summarize_topics_baseline(news_week_df, labels, tfidf_matrix_week, vectorizer, config: dict):
    ...

def run_layer_a_baseline(news_df: pd.DataFrame, config: dict):
    ...
```

## 6.2 Layer A baseline 可視化

論文の「文書空間から自然発生トピックを抽出する」発想に対応し、Notebook上に以下を表示する。

```python
def display_layer_a_overview(weekly_topics, article_topic_assignment, clean_news, config):
    """
    表示内容：
    - 週別ニュース件数
    - 週別トピック数
    - トピックサイズ分布
    - 上位トピックのtop terms
    - 上位トピックの代表headline
    """

def plot_topic_count_by_week(weekly_topics):
    ...

def plot_topic_size_distribution(weekly_topics):
    ...

def display_top_topics(weekly_topics, top_n=20):
    ...

def display_topic_representative_headlines(weekly_topics, top_n_topics=10, max_headlines=5):
    ...

def plot_similarity_heatmap_for_week(similarity_matrix, news_week_df, labels, max_articles=80):
    """
    論文の類似度グラフ・文書空間の確認用。
    記事数が多い場合はサンプル表示する。
    """
```

---

## 7. Layer B baseline

## 7.1 baseline Layer B 手法

baselineでは以下を採用する。

```text
topic word distribution
→ Hellinger distance
→ adjacent-week nearest alignment
→ continue / birth / death
→ lineage_id
→ novelty / persistence
```

Notebook内に以下の関数を実装する。

```python
def hellinger_distance(p: np.ndarray, q: np.ndarray, eps: float = 1e-12) -> float:
    ...

def make_topic_word_distributions(weekly_topics, article_topic_assignment, layer_a_artifacts, config):
    ...

def compute_adjacent_topic_distances_baseline(weekly_topics, topic_distributions, config):
    ...

def link_topics_baseline(distance_df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...

def classify_events_baseline(weekly_topics, topic_links, config: dict) -> pd.DataFrame:
    ...

def assign_lineage_ids_baseline(weekly_topics, topic_links, event_df, config: dict) -> pd.DataFrame:
    ...

def compute_novelty_baseline(topic_lineage, topic_distributions, config: dict) -> pd.DataFrame:
    ...

def compute_persistence_baseline(topic_lineage, config: dict) -> pd.DataFrame:
    ...

def run_layer_b_baseline(weekly_topics, article_topic_assignment, layer_a_artifacts, config):
    ...
```

## 7.2 Layer B baseline 可視化

論文の「Hellinger距離によるトピック整列」「トピックの時間変化」に対応し、Notebook上に以下を表示する。

```python
def display_layer_b_overview(topic_links, topic_lineage, lineage_summary, config):
    """
    表示内容：
    - event_type件数
    - lineage_summary上位
    - persistence分布
    - novelty上位
    - 代表lineageのheadline推移
    """

def plot_topic_distance_heatmap(distance_df, from_week, to_week):
    """
    隣接週トピック間Hellinger距離のheatmap。
    """

def plot_lineage_event_counts(topic_lineage):
    """
    weekごとのbirth/continue/death/split/merge/drift件数。
    """

def plot_persistence_distribution(topic_lineage):
    ...

def plot_novelty_timeseries(topic_lineage):
    ...

def display_top_lineages(lineage_summary, top_n=15):
    ...

def display_lineage_headline_sequence(topic_lineage, weekly_topics, lineage_id):
    """
    あるlineageについて、週ごとのtop termsと代表headlineを表示する。
    """
```

---

## 8. Layer A full

## 8.1 full Layer A 手法

fullでは、文献に近い発想を参考実装する。

```text
clean news
→ TF-IDF
→ optional SBERT
→ combined similarity
→ kNN / MST-kNN graph
→ Leiden / Louvain / fallback clustering
→ resolution sweep
→ c-TF-IDF topic summary
```

Notebook内に以下の関数を実装する。

```python
def load_sbert_model_full(config: dict):
    ...

def embed_texts_sbert_full(texts: list[str], model, config: dict) -> np.ndarray:
    ...

def compute_combined_similarity(tfidf_matrix, sbert_embeddings, config: dict):
    ...

def build_knn_graph_full(similarity_matrix: np.ndarray, config: dict):
    ...

def add_mst_edges_if_available(edges, similarity_matrix: np.ndarray, config: dict):
    ...

def cluster_week_full(news_week_df, tfidf_matrix_week, sbert_embeddings_week, config: dict):
    ...

def summarize_topics_full(news_week_df, labels, tfidf_matrix_week, vectorizer, config: dict):
    ...

def run_layer_a_full(news_df: pd.DataFrame, config: dict):
    ...
```

要件：
- SBERTが使えない場合はTF-IDFのみにフォールバックする。
- Leiden/Louvainが使えない場合はAgglomerativeへフォールバックする。
- MST-kNNが使えない場合はkNNまたは距離ベースクラスタリングへフォールバックする。
- resolution sweepを実装する。
- 完全版が一部失敗してもbaselineが壊れないようにする。

## 8.2 full Layer A 可視化

論文のマルチスケール・グラフクラスタリングの発想に対応し、Notebook上に以下を表示する。

```python
def plot_resolution_topic_counts(weekly_topics_full):
    """
    resolutionごとのトピック数を表示する。
    """

def plot_graph_degree_distribution(graph_info):
    """
    kNN/MST-kNNグラフの次数分布を表示する。
    graphが作れた場合のみ。
    """

def plot_similarity_network_sample(news_week_df, similarity_matrix, labels, max_nodes=80):
    """
    類似度グラフのサンプル可視化。
    networkxがあれば使う。なければskip。
    """

def display_multi_resolution_topic_summary(weekly_topics_full, week=None):
    """
    resolutionごとのtop topic, top terms, representative headlinesを表示する。
    """
```

---

## 9. Layer B full

## 9.1 full Layer B 手法

fullでは、文献に近い発想を参考実装する。

```text
word distribution
+ optional theme distribution
+ optional entity distribution
→ mixed Hellinger distance
→ mutual nearest / Ward alignment
→ continue / birth / death / split / merge / drift
→ lineage_id
→ novelty / persistence / rare_topic_score
→ lineage graph
```

Notebook内に以下の関数を実装する。

```python
def make_topic_distributions_full(weekly_topics, article_topic_assignment, layer_a_artifacts, config):
    ...

def compute_mixed_hellinger_distance(topic_dist_a, topic_dist_b, config: dict) -> dict:
    ...

def compute_adjacent_topic_distances_full(weekly_topics, topic_distributions, config: dict):
    ...

def link_topics_full(distance_df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...

def link_topics_ward_if_available(distance_df: pd.DataFrame, config: dict) -> pd.DataFrame:
    ...

def classify_events_full(weekly_topics, topic_links, config: dict) -> pd.DataFrame:
    ...

def assign_lineage_ids_full(weekly_topics, topic_links, event_df, config: dict) -> pd.DataFrame:
    ...

def compute_novelty_full(topic_lineage, topic_distributions, config: dict) -> pd.DataFrame:
    ...

def compute_persistence_full(topic_lineage, config: dict) -> pd.DataFrame:
    ...

def compute_rare_topic_score_full(topic_lineage, weekly_topics, config: dict) -> pd.DataFrame:
    ...

def run_layer_b_full(weekly_topics, article_topic_assignment, layer_a_artifacts, config):
    ...
```

## 9.2 full Layer B 可視化

論文のHellinger/Ward/階層整列・希少トピック検出の発想に対応し、Notebook上に以下を表示する。

```python
def plot_ward_dendrogram_if_available(distance_df, week_pair, config):
    """
    Ward階層クラスタリングを使う場合のdendrogram。
    scipyがなければskip。
    """

def plot_lineage_network(topic_links, topic_lineage, max_nodes=120):
    """
    topic lineage graphを表示。
    networkxがなければ簡易表で代替。
    """

def display_split_merge_drift_examples(topic_lineage, weekly_topics, max_examples=10):
    """
    split/merge/drift候補の具体例をtop terms/headline付きで表示。
    """

def display_rare_topics(topic_lineage, weekly_topics, top_n=20):
    """
    rare_topic_score上位を表示する。
    """
```

---

## 10. baseline/full比較

`run.mode=compare` では、同じ `clean_news` に対してbaselineとfullを両方実行し、Notebook上で比較表示する。

保存は原則行わない。  
必要な場合だけconfigで比較結果parquetを `data/interim/` に保存する。

Notebook内に以下の関数を実装する。

```python
def compare_layer_a_outputs(weekly_topics_baseline, weekly_topics_full, config):
    ...

def compare_layer_b_outputs(topic_lineage_baseline, topic_lineage_full, topic_links_baseline, topic_links_full, config):
    ...

def display_method_quality_summary(layer_a_comparison, layer_b_comparison):
    ...

def plot_method_comparison_charts(layer_a_comparison, layer_b_comparison):
    ...
```

比較指標：

Layer A：
- 週別トピック数
- 平均トピックサイズ
- singleton ratio
- top_terms coverage
- representative_headline coverage
- topic interpretability proxy

Layer B：
- link coverage
- avg link distance
- strong link ratio
- birth / death / continue / split / merge / drift比率
- average persistence
- high persistence lineage count
- rare topic count

Notebook表示：

```text
1. baseline/full比較サマリーテーブル
2. 週別トピック数比較プロット
3. link coverage比較プロット
4. persistence分布比較
5. baselineの代表lineage一覧
6. fullの代表lineage一覧
7. Layer Cに渡す候補の暫定コメント欄
```

---

## 11. config.yaml 完整版

`config.yaml` は以下をベースに作成する。

```yaml
project:
  name: topic_lineage_news_layer_ab_staged_lseg_cache
  description: "LSEG/Reutersニュースを対象にLayer A/Bをbaseline/fullの2系統でNotebook-only実装する"

paths:
  raw: data/raw
  interim: data/interim
  processed: data/processed
  docs: docs
  sources: docs/sources

papers:
  fs_2022_j_001: docs/sources/FS-2022-J-001.pdf
  graph_topic_2010_15067: docs/sources/arxiv_2010_15067.pdf
  topic_alignment_2511_21741: docs/sources/arxiv_2511_21741.pdf

run:
  mode: baseline
  # options:
  #   baseline
  #   full
  #   compare
  random_state: 42
  use_sample_data_if_missing: true
  verbose: true

notebook_display:
  display_tables: true
  display_plots: true
  save_tables: false
  save_figures: false
  max_display_rows: 30
  max_headlines_per_topic_display: 5

lseg:
  enable_fetch: false
  force_refresh: false
  query_scale: small
  use_cached_if_available: true
  cache_only: false
  cache_dir: data/raw

  session:
    open_session: true
    config_name: null

  fetch:
    start_date: "2025-01-01"
    end_date: "2025-03-31"
    date_chunk_days: 7
    max_headlines_per_query: 100
    max_stories_per_query: 30
    fetch_stories: true
    story_format: text
    sleep_seconds: 0.2

  scales:
    tiny:
      start_date: "2025-01-01"
      end_date: "2025-01-07"
      query_names: ["japan_broad_en"]
      max_headlines_per_query: 20
      max_stories_per_query: 5
      date_chunk_days: 7
    small:
      start_date: "2025-01-01"
      end_date: "2025-01-31"
      query_names: ["japan_broad_en", "japan_market_en", "macro_policy_en", "technology_en"]
      max_headlines_per_query: 100
      max_stories_per_query: 30
      date_chunk_days: 7
    medium:
      start_date: "2024-07-01"
      end_date: "2025-03-31"
      query_names:
        - japan_broad_en
        - japan_market_en
        - macro_policy_en
        - technology_en
        - energy_infra_en
        - financials_en
        - healthcare_en
        - consumer_en
        - materials_industrials_en
      max_headlines_per_query: 250
      max_stories_per_query: 100
      date_chunk_days: 7
    large:
      start_date: "2022-01-01"
      end_date: "2025-03-31"
      query_names:
        - japan_broad_en
        - japan_market_en
        - macro_policy_en
        - technology_en
        - energy_infra_en
        - financials_en
        - healthcare_en
        - consumer_en
        - materials_industrials_en
        - geopolitics_supplychain_en
        - global_markets_en
      max_headlines_per_query: 500
      max_stories_per_query: 300
      date_chunk_days: 3

  queries:
    japan_broad_en:
      description: "Japan broad Reuters English news"
      query: 'Japan AND Language:LEN AND Source:RTRS'
    japan_market_en:
      description: "Japan equity and market news"
      query: '(Japan OR Tokyo OR TOPIX OR Nikkei) AND (stocks OR shares OR market OR earnings) AND Language:LEN AND Source:RTRS'
    macro_policy_en:
      description: "BOJ, rates, fiscal and policy"
      query: '(BOJ OR Bank of Japan OR yen OR inflation OR rates OR yield OR fiscal OR policy) AND Language:LEN AND Source:RTRS'
    technology_en:
      description: "AI, semiconductors, data center, software"
      query: '(AI OR artificial intelligence OR semiconductor OR chip OR data center OR cloud OR software) AND Language:LEN AND Source:RTRS'
    energy_infra_en:
      description: "Energy, power, grid, infrastructure"
      query: '(energy OR power OR electricity OR grid OR renewable OR nuclear OR infrastructure OR utility) AND Language:LEN AND Source:RTRS'
    financials_en:
      description: "Banks, insurers, brokers"
      query: '(bank OR banking OR insurer OR insurance OR brokerage OR securities OR lender) AND Language:LEN AND Source:RTRS'
    healthcare_en:
      description: "Healthcare, pharma, biotech, medical devices"
      query: '(healthcare OR pharma OR drug OR biotech OR medical OR hospital OR obesity) AND Language:LEN AND Source:RTRS'
    consumer_en:
      description: "Consumer, retail, tourism, inbound"
      query: '(consumer OR retail OR tourism OR travel OR inbound OR restaurant OR apparel) AND Language:LEN AND Source:RTRS'
    materials_industrials_en:
      description: "Materials, machinery, construction, capex"
      query: '(materials OR chemical OR steel OR machinery OR construction OR factory OR capex OR automation) AND Language:LEN AND Source:RTRS'
    geopolitics_supplychain_en:
      description: "Geopolitics and supply chain"
      query: '(geopolitics OR tariffs OR sanctions OR supply chain OR China OR Taiwan OR export controls) AND Language:LEN AND Source:RTRS'
    global_markets_en:
      description: "Global market risk and cross-asset"
      query: '(markets OR stocks OR bonds OR yields OR dollar OR oil OR gold) AND Language:LEN AND Source:RTRS'

news:
  week_anchor: W-FRI
  min_text_length: 30
  timestamp_priority:
    - versionCreated
    - firstCreated
    - timestamp_utc
    - retrieved_at_utc
  dedup:
    enable: true
    method: normalized_headline
    fuzzy_threshold: 0.95
    keep_update_count: true

baseline:
  layer_a:
    vectorizer:
      method: tfidf
      tfidf:
        max_features: 20000
        min_df: 3
        max_df: 0.80
        ngram_range: [1, 2]
        stop_words: english
    similarity:
      metric: cosine
    clustering:
      method: agglomerative
      fallback_method: kmeans
      min_articles_for_clustering: 20
      small_week_policy: single_topic
      agglomerative:
        distance_threshold: 0.65
        linkage: average
        n_clusters: null
      kmeans:
        n_clusters: auto
        min_clusters: 2
        max_clusters: 12
    topic_summary:
      top_n_terms: 15
      top_n_headlines: 5
      use_ctfidf: true

  layer_b:
    distribution:
      primary: word
      smoothing: 1.0e-12
    distance:
      method: hellinger
      alpha_word: 1.00
      beta_theme: 0.00
      gamma_entity: 0.00
    alignment:
      method: adjacent_nearest
      link_threshold: 0.55
      max_links_per_topic: 1
      strong_link_requires_mutual: false
    events:
      classify_continue: true
      classify_birth: true
      classify_death: true
      classify_split: false
      classify_merge: false
      classify_drift: false
    features:
      compute_novelty: true
      novelty_lookback_weeks: 12
      compute_persistence: true
      compute_rare_topic_score: false

full:
  layer_a:
    vectorizer:
      method: tfidf_sbert
      tfidf:
        max_features: 30000
        min_df: 2
        max_df: 0.85
        ngram_range: [1, 2]
        stop_words: english
      sbert:
        enable: true
        model_path: data/model/paraphrase-multilingual-MiniLM-L12-v2
        batch_size: 64
        normalize_embeddings: true
        fallback_to_tfidf: true
      combine:
        sbert_weight: 0.60
        tfidf_weight: 0.40

    similarity:
      metric: cosine
      use_sparse: true

    graph:
      method: mst_knn
      k_neighbors: 10
      adaptive_k: true
      min_k: 2
      add_mst: true

    clustering:
      method: leiden
      fallback_method: agglomerative
      min_articles_for_clustering: 20
      small_week_policy: single_topic
      resolutions: [0.5, 1.0, 1.5, 2.0]
      primary_resolution: 1.0
      agglomerative:
        distance_threshold: 0.65
        linkage: average
        n_clusters: null
      kmeans:
        n_clusters: auto
        min_clusters: 2
        max_clusters: 20

    topic_summary:
      top_n_terms: 20
      top_n_headlines: 7
      use_ctfidf: true
      save_multi_resolution: false

  layer_b:
    distribution:
      primary: word_theme_entity
      word:
        source: tfidf
        smoothing: 1.0e-12
      theme:
        enable: false
        fallback_if_missing: true
      entity:
        enable: false
        fallback_if_missing: true

    distance:
      method: mixed_hellinger
      alpha_word: 0.50
      beta_theme: 0.35
      gamma_entity: 0.15
      fallback_to_word_only: true

    alignment:
      method: mutual_nearest
      link_threshold: 0.55
      strong_link_requires_mutual: true
      allow_multiple_links: true
      max_links_per_topic: 3

    events:
      classify_continue: true
      classify_birth: true
      classify_death: true
      classify_split: true
      classify_merge: true
      classify_drift: true
      split_threshold: 0.60
      merge_threshold: 0.60
      drift_word_distance_min: 0.35
      drift_theme_distance_max: 0.35

    features:
      compute_novelty: true
      novelty_lookback_weeks: 12
      compute_persistence: true
      compute_rare_topic_score: true
      rare_topic_min_growth_z: 1.0

comparison:
  metrics:
    topic_stability: true
    topic_size_balance: true
    lineage_coverage: true
    link_distance_summary: true
    event_distribution: true
    interpretability_score: true
```

---

## 12. main.ipynb 構成

`main.ipynb` は以下の構成にする。

```text
0. タイトル・目的・参照論文
1. config読み込み
2. ライブラリimport
3. LSEG query設計の表示
4. LSEG parquet cache確認
5. LSEGニュース取得またはcache読み込み
6. ニュース正規化・重複除去
7. ニュース件数・取得状況の表示
8. baseline Layer A
9. baseline Layer A 可視化
10. baseline Layer B
11. baseline Layer B 可視化
12. full Layer A, optional
13. full Layer A 可視化
14. full Layer B, optional
15. full Layer B 可視化
16. baseline/full比較, optional
17. Layer C接続に向けた暫定判断
```

---

## 13. テストNotebook

### test_layer_a.ipynb

目的：
- LSEG cacheがなくてもサンプルニュースでLayer Aが動くことを確認。
- baseline/full両方を確認。
- 可視化関数がNotebook上で動くことを確認。

必須：
- DataFrame表示
- topic count plot
- topic size distribution
- top terms/headline display
- similarity heatmap

### test_layer_b.ipynb

目的：
- 人工topicでLayer Bが動くことを確認。
- baseline/full両方を確認。
- Hellinger距離とlineage可視化を確認。

必須：
- distance heatmap
- event count plot
- persistence distribution
- novelty plot
- lineage headline sequence表示

### test_layer_ab_methods.ipynb

目的：
- baseline/fullの比較表示。
- Layer Cに進む判断材料を作る。

必須：
- method quality summary table
- topic count comparison
- link coverage comparison
- persistence comparison
- representative lineage比較

---

## 14. Layer Cへの接続を見据えた出力

今回、CSVやPNGは原則保存しないが、Layer Cに渡すため以下のparquetは保存してよい。

```text
data/processed/clean_news.parquet
data/processed/weekly_topics_baseline.parquet
data/processed/article_topic_assignment_baseline.parquet
data/processed/topic_links_baseline.parquet
data/processed/topic_lineage_baseline.parquet
data/processed/lineage_summary_baseline.parquet

data/processed/weekly_topics_full.parquet
data/processed/article_topic_assignment_full.parquet
data/processed/topic_links_full.parquet
data/processed/topic_lineage_full.parquet
data/processed/lineage_summary_full.parquet
```

Layer Cで最低限必要になる列：

### weekly_topics

```text
method_name
week
resolution
topic_id
global_topic_id
n_articles
article_ids
top_terms
representative_headlines
```

### article_topic_assignment

```text
method_name
news_id
week
global_topic_id
topic_weight
```

### topic_lineage

```text
method_name
week
topic_id
global_topic_id
lineage_id
event_type
persistence
novelty
rare_topic_score
link_distance
link_similarity
```

---

## 15. 完了条件

以下が満たされたら今回の実装は完了。

- `main.ipynb` が上から順に実行できる。
- `config.yaml` の `run.mode=baseline` でbaselineが完走する。
- `config.yaml` の `run.mode=full` でfullが完走する。依存関係不足時はfallbackで完走する。
- `config.yaml` の `run.mode=compare` でbaseline/full比較がNotebook上に表示される。
- `.py` ファイルが作成されていない。
- LSEGニュース取得は `lseg.enable_fetch=true` の場合のみ実行される。
- parquet cacheがある場合はAPIを再実行しない。
- `lseg.query_scale` で取得規模を制御できる。
- LSEG APIが使えない場合も既存parquetまたはサンプルデータで動作する。
- Layer A/Bの表とプロットがNotebook上で表示される。
- CSVやPNGの保存は原則行われない。
- Layer Cに渡すためのparquet出力は `data/processed/` に保存される。
- `docs/notes/95_layer_c_handoff_decision.md` が作成される。
```

---

## 推奨する最初の実行設定

最初はAPIを叩かず、既存parquetまたはサンプルでNotebook動作を確認します。

```yaml
run:
  mode: baseline

lseg:
  enable_fetch: false
  cache_only: true
  query_scale: tiny
  use_cached_if_available: true
```

次にLSEG接続確認だけ行います。

```yaml
run:
  mode: baseline

lseg:
  enable_fetch: true
  force_refresh: false
  cache_only: false
  query_scale: tiny
```

baselineが安定したら、以下に進みます。

```yaml
run:
  mode: compare

lseg:
  enable_fetch: false
  cache_only: true
  query_scale: small
```

この設計なら、API課金・取得制限・再現性の問題を避けつつ、Notebook上でLayer A/Bの品質を目視検証できます。

---

**Sources:**

- [Getting Top News Energy Headlines and Stories using ...](https://developers.lseg.com/en/article-catalog/article/getting-top-news-energy-headlines-and-stories-using-lseg-data-li?utm_source=chatgpt.com)

## Response:
2026/5/7 22:10:57

> **Markdownファイルの作成を検討**
>
> Markdownファイルを作る必要があるみたい。Pythonを使って、.mdファイルで作る方がいいかも。Docx形式じゃなくて良いし、先ほどの最終内容を含めたファイルを作成する感じかな。最終リンクも含めるといいかもね。
>
> **生成するMarkdownファイル**
>
>
> 思考時間: 1m 22s

作成しました。こちらからダウンロードできます。

[Codex実装指示書 Markdown](sandbox:/mnt/data/codex_layer_ab_lseg_cache_instructions.md)



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)