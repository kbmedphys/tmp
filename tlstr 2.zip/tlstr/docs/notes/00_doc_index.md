# ドキュメント索引

本プロジェクトはReuters/LSEGニュースからLayer Aの自然発生トピック抽出と、Layer Bの時間方向トピック整列をNotebookだけで実装する。

- `10_method_summary.md`: 手法要約
- `20_assumptions.md`: 実装上の前提
- `30_implementation_plan.md`: 実装計画
- `40_layer_a_design.md`: Layer A設計
- `50_layer_b_design.md`: Layer B設計
- `60_baseline_method_design.md`: baseline設計
- `70_full_method_design.md`: full設計
- `80_method_comparison_plan.md`: 比較計画
- `90_future_layer_c_plan.md`: 将来のLayer C計画
- `95_layer_c_handoff_decision.md`: Layer Cへ渡す暫定判断
- `dependency_request.md`: 依存関係の追加・fallback記録
