# baseline/full比較計画

比較は同じ正規化ニュースを入力として行う。Layer Aでは週別トピック数、平均トピックサイズ、singleton ratio、top terms coverage、代表headline coverage、解釈性proxyを比較する。

Layer Bではlink coverage、平均link距離、strong link ratio、event_type分布、平均persistence、高persistence lineage数、rare topic数を比較する。
