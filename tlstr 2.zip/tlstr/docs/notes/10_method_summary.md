# 手法要約

Layer Aはニュース本文またはheadlineをTF-IDF/SBERTで文書ベクトル化し、文書間類似度から週次トピックを抽出する。baselineはTF-IDFと距離ベースクラスタリングを使い、fullはSBERT、kNN/MST-kNN graph、Leiden/Louvain、resolution sweepを利用可能な範囲で使う。

Layer Bは週次トピックの語彙分布をHellinger距離で比較し、隣接週のトピックを整列する。baselineは最近傍リンクでcontinue/birth/deathを判定し、fullはmutual nearest、Ward補助、split/merge/drift、rare topic scoreを追加する。
