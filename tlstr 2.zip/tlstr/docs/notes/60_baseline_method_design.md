# baseline設計

baselineは安定性、解釈性、依存の少なさを重視する。主な依存はpandas、numpy、scikit-learn、matplotlib、seabornである。

- Layer A: TF-IDF、cosine距離、AgglomerativeClustering、KMeans fallback
- Layer B: topic word distribution、Hellinger距離、隣接週最近傍alignment
- 出力: weekly_topics、article_topic_assignment、topic_links、topic_lineage、lineage_summary
