# 依存関係追加記録

## 追加済み

- `lseg-data`: LSEG Data Library for PythonをNotebookから利用するため。
- `python-louvain`: networkx graphに対するLouvain fallback clusteringのため。
- `igraph`: Leiden実行基盤のため。
- `leidenalg`: full Layer AのLeiden clusteringのため。

## fallback方針

依存がimportできない場合、Notebookは停止せず以下へfallbackする。

- LSEG未利用: 既存parquetまたはサンプルニュースを使う。
- Leiden/Louvain未利用: AgglomerativeClusteringを使う。
- SBERTモデル未配置: TF-IDF類似度だけを使う。
