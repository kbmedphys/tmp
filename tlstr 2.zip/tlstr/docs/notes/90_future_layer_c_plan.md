# 将来のLayer C計画

Layer CではLayer A/Bのニュース特徴量をテーマ別リターン、売買代金、リスク指標へ写像する教師あり投資シグナル層を構築する。今回のLayer A/B出力は、週次トピック、記事割当、lineage、novelty、persistence、rare topic scoreをLayer Cの特徴量候補として保存する。
