# full設計

fullは参照論文に近い実験ラインとして扱う。依存関係が不足する環境でもbaseline相当にfallbackしてNotebookを止めない。

- SBERTはローカルモデルパスが存在する場合に利用し、存在しない場合はTF-IDFのみで進める。
- Leiden/Louvainが利用できればgraph clusteringを行い、利用できなければAgglomerativeを使う。
- resolution sweepにより複数粒度のtopic countと代表トピックを比較する。
- Layer Bではmutual nearest、split/merge/drift、rare topic scoreを追加する。
