# 前提

- LSEG APIが使えない場合でも、既存parquetまたはNotebook内サンプルデータで処理を完走させる。
- 画像・CSVは原則保存せず、Notebook上で表示する。
- Layer C向けの最小parquetだけ `data/processed/` へ保存する。
- `legacy/` は参照専用で編集しない。
- `.py` ファイルはプロジェクト内に作成しない。
