# 実装計画

1. `config.yaml` とディレクトリ構成を作成する。
2. `main.ipynb` に共通関数、LSEG cache、ニュース正規化、Layer A/B baseline/full、比較表示を実装する。
3. 単体テストNotebookでサンプルデータによるLayer A/Bの表示を確認する。
4. 統合NotebookでLayer AからLayer B、processed parquet保存までを確認する。
5. `run.mode` をbaseline/full/compareに切り替えて `main.ipynb` を検証する。
