# CODEX_EXECUTION_PROMPT.md

以下をそのまま Codex に渡してください。

---

このプロジェクトでは、workspace/AGENTS.md が最優先です。最初に必ず読み、すべて遵守してください。
加えて、このプロジェクトでは以下を守ってください。

## 1. 実装目的

テーマバスケット投資のためのニュース駆動型メガトレンド推定パイプラインを実装してください。
テーマは業種テーマ、技術テーマ、政策テーマ、スタイルテーマ、バリュエーションテーマを含みます。
テーマ名との単純なキーワード一致ではなく、テーマを収益ドライバーの束として再定義し、ニュースからドライバーの強度・方向・新規性・継続性を推定し、テーマをランキングしてください。

## 2. 最重要要件

- 実装は notebooks/main.ipynb から end-to-end で再現可能にすること
- 実装の single source は src/<project_name>/ 配下に置くこと
- outputs/figures, outputs/tables, outputs/logs のみに成果物を保存すること
- leakage-free を厳守すること
- 初版は interpretability を優先し、過度に複雑化しないこと
- 中間成果物を parquet/csv/json として保存し、再計算を分割可能にすること
- 変更は incremental に行い、既存ファイルは破壊的変更を避けること

## 3. 最初に行うこと

1. SPEC.md を読む
2. README.md を作成または更新する
3. docs/notes/00_doc_index.md を作る
4. docs/notes/10_requirements.md を作る
5. docs/notes/20_assumptions.md を作る
6. docs/notes/30_plan.md を作る
7. 必要な src/<project_name>/ モジュールを作る
8. notebooks/main.ipynb を作る

## 4. 実装対象モジュール

以下のモジュールを作成してください。

- src/<project_name>/config.py
- src/<project_name>/schemas.py
- src/<project_name>/io.py
- src/<project_name>/theme_definition.py
- src/<project_name>/news_features.py
- src/<project_name>/topic_models.py
- src/<project_name>/event_mapping.py
- src/<project_name>/theme_aggregation.py
- src/<project_name>/calibration.py
- src/<project_name>/ranking.py
- src/<project_name>/backtest.py
- src/<project_name>/metrics.py
- src/<project_name>/reporting.py

## 5. 実装段階

### Stage 1: Theme Definition Reconstruction

以下を実装してください。

- themes_master, theme_holdings, company_master を読み込む
- theme_profile を構築する
- theme embedding を3種類作る
  - embedding_theme_desc
  - embedding_holdings_desc_weighted
  - embedding_combined
- theme_driver_library.json を生成する
- driver library は seed keywords と説明文から半自動生成し、人手修正可能なJSONにする

### Stage 2: News Structuring

以下を実装してください。

- news データの前処理
- clean_text の生成
- article embedding の生成
- entities 抽出
- event_type, polarity, intensity 推定
- novelty score の生成
- BERTopic-like pipeline の実装
- dynamic topic interface の雛形実装
- article-driver mapping の生成

### Stage 3: Driver-to-Theme Aggregation and Market Calibration

以下を実装してください。

- article-theme weight の計算
- daily theme features の生成
- target variable の生成
- rolling / expanding 学習
- ridge / lasso / elastic net による calibration
- calibration_predictions.parquet の保存

### Stage 4: Ranking and Backtest

以下を実装してください。

- structural_trend_score
- news_acceleration_score
- crowding_penalty
- stretch_penalty
- final ranking
- ranking history 保存
- backtest 実行
- metrics 集計
- figures / tables 保存

## 6. notebook の構成

notebooks/main.ipynb は以下順で構成してください。

1. config load
2. data load
3. theme profile construction
4. theme embedding construction
5. article preprocessing
6. article embedding generation
7. event extraction
8. topic modeling
9. driver mapping
10. article-to-theme mapping
11. daily theme feature aggregation
12. calibration
13. ranking
14. backtest
15. reporting

## 7. 初版スコープ

初版では以下を必須とします。

- theme embedding
- article embedding
- rule-based または軽量 classifier による event extraction
- BERTopic-like topic extraction
- novelty score
- driver mapping
- daily aggregation
- ridge / lasso calibration
- top N ranking backtest

以下は後回しでよいです。

- 厳密な D-ETM 再現
- options / flows / valuation 完全統合
- 本格 LLM structured extraction
- 高度な ensemble

## 8. 実装時の注意

- 将来データを使わないこと
- train/test split を厳密に守ること
- feature standardization は train window のみで fit すること
- まずは可読性・保守性を優先すること
- main.ipynb で再現できることを最重視すること
- figure/table/log のファイル名は予測可能な命名にすること

## 9. 必須出力

少なくとも以下を出力してください。

- outputs/tables/performance_summary.csv
- outputs/tables/ranking_history.csv
- outputs/tables/driver_scores_per_theme.csv
- outputs/tables/model_diagnostics.csv
- outputs/figures/cumulative_returns.png
- outputs/figures/theme_rank_heatmap.png
- outputs/figures/topic_drift_by_theme.png
- outputs/figures/driver_contribution_by_theme.png
- outputs/logs/run_config.json

## 10. 作業完了時に示すこと

- 実装したファイル一覧
- 主要な設計判断
- 未実装・近似した部分
- 実行手順
- 今後の拡張候補

---
