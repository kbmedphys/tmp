# thematic-driver

ニュース駆動でテーマバスケットの相対魅力度を推定する Phase 1 研究基盤です。  
実装は `src/thematic_driver` を single source とし、`notebooks/main.ipynb` から end-to-end で再現できます。

## 環境

- Python: `envs/nlp/.venv/bin/python`
- 依存管理: `uv`（`workspace/AGENTS.md` 準拠）
- 埋め込み: `SentenceTransformer`（`all-MiniLM-L6-v2`）必須

## ディレクトリ

- `docs/notes/`: 要件整理・前提・計画
- `src/thematic_driver/`: パイプライン実装
- `notebooks/main.ipynb`: 実行オーケストレーション
- `data/raw/`: 入力データ（最小サンプル同梱）
- `data/processed/`: 任意の中間データ
- `outputs/figures|tables|logs/`: 成果物

## 入力ファイル規約

`data/raw/` に以下を配置します（`.csv` または `.parquet`）。

- `themes_master`
- `theme_holdings`
- `company_master`
- `news`
- `prices`
- `theme_returns`（任意）

`theme_returns` が無い場合は `prices + theme_holdings` から計算します。

## 実行

1. 埋め込みモデルを事前取得（初回のみ）

```bash
envs/nlp/.venv/bin/python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('all-MiniLM-L6-v2')"
```

2. notebook 実行

```bash
envs/nlp/.venv/bin/python -m jupyter nbconvert --to notebook --execute notebooks/main.ipynb --output main.executed.ipynb
```

## 主要出力

- 中間成果物: `theme_profile.parquet` 〜 `backtest_weights.parquet`
- 必須テーブル:
  - `outputs/tables/performance_summary.csv`
  - `outputs/tables/ranking_history.csv`
  - `outputs/tables/driver_scores_per_theme.csv`
  - `outputs/tables/model_diagnostics.csv`
- 必須図:
  - `outputs/figures/cumulative_returns.png`
  - `outputs/figures/theme_rank_heatmap.png`
  - `outputs/figures/topic_drift_by_theme.png`
  - `outputs/figures/driver_contribution_by_theme.png`
- ログ:
  - `outputs/logs/run_config.json`

## Phase 1 の近似

- イベント抽出: ルールベース
- トピック抽出: BERTopic-like（埋め込み + KMeans + TF-IDF代表語）
- 校正: Ridge/Lasso/ElasticNet（rolling / expanding）
