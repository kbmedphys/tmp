# SPEC.md
# Theme Basket Investment via News-Driven Megatrend Inference

## 0. Document Control

- Project: news-driven-theme-rotation
- Version: 0.1.0
- Status: Draft
- Owner: User
- Priority: High

---

## 1. Objective

多様なテーマバスケットに対して、日々のニュースデータを分析し、
メガトレンドおよび短期加速を推定し、相対的に魅力的なテーマを順位付けする
研究・検証基盤を構築する。

ここでいうテーマは以下を含む。

- 業種テーマ
- 技術テーマ
- 政策テーマ
- スタイルテーマ
- バリュエーションテーマ

例:
- AI
- 半導体
- 再エネ
- 防衛
- 電力インフラ
- 低PBR
- 高配当
- バリュー
- 中小型
- 脱炭素

本プロジェクトでは、テーマ名への単純なキーワード一致を避け、
**テーマを収益ドライバーの束として再定義し、そのドライバーに関するニュースの強度・方向・新規性・継続性を計測する**
ことを中核に置く。

---

## 2. Research Question

### 2.1 Main Question

ニュースデータから、各テーマの将来の相対的魅力度を推定できるか。

### 2.2 Sub Questions

1. 曖昧なテーマ定義を、投資上意味のある表現へ再構成できるか
2. ニュースをテーマ名ではなく収益ドライバーに写像した方が有効か
3. 動的トピック遷移はメガトレンド推定に有効か
4. ニュース由来特徴は市場反応で校正した方が頑健か
5. ニュース強度だけでなく crowding / hype penalty を加えるべきか

---

## 3. Scope

### 3.1 In Scope

- テーマ定義の再構成
- 構成銘柄・ウェイト情報の利用
- ニュース記事の前処理
- 埋め込み生成
- article-level event / driver / topic 特徴量生成
- daily theme-level feature aggregation
- rolling / expanding calibration
- ranking and backtest
- 可視化とレポート

### 3.2 Out of Scope (Phase 1)

- 本番運用システム
- リアルタイム配信基盤
- 発注接続
- 厳密な D-ETM のフル再現
- 本格的マルチエージェントLLM基盤
- 高頻度データ利用

---

## 4. Design Principles

1. leakage free
2. modular
3. interpretable first
4. replaceable components
5. reproducible end-to-end from main.ipynb
6. all intermediate artifacts saved
7. robust to heterogeneous theme definitions

---

## 5. Conceptual Architecture

本プロジェクトは以下の4段階で構成する。

### Stage 1: Theme Definition Reconstruction
テーマ名を直接使わず、テーマ説明・構成銘柄・ウェイト・企業説明・補助属性から
テーマの投資上の実体を再構成する。

### Stage 2: News Structuring
ニュースをテーマへ直接当てるのではなく、
イベント、主体、トピック、ドライバー、方向、新規性へ写像する。

### Stage 3: Driver-to-Theme Aggregation and Market Calibration
ニュース特徴をテーマへ集約し、将来の相対リターンや市場反応で校正する。

### Stage 4: Ranking and Portfolio Construction
Structural trend、short-term acceleration、crowding、stretch を統合し、
テーマを順位付けしてバックテストする。

---

## 6. Stage 1 Requirements: Theme Definition Reconstruction

### 6.1 Goal

各テーマを以下のような構造化表現に変換する。

- theme_id
- theme_name
- theme_description
- holdings
- holding weights
- weighted business descriptions
- sector mix
- country mix
- style mix
- driver library

### 6.2 Required Inputs

#### themes_master
- theme_id
- theme_name
- theme_description

#### theme_holdings
- date
- theme_id
- ticker
- weight

#### company_master
- ticker
- company_name
- company_description
- sector
- country
- style_tags (optional)

### 6.3 Derived Objects

#### theme_profile
各テーマに対して以下を集約。

- weighted holding descriptions
- sector concentration
- country concentration
- style exposures

#### theme_embedding
少なくとも以下の3種類。

- embedding_theme_desc
- embedding_holdings_desc_weighted
- embedding_combined

#### theme_driver_library
各テーマに対し、収益ドライバー群を記述したJSON。

schema:

```json
{
  "theme_id": "T001",
  "theme_name": "AI Infrastructure",
  "drivers": [
    {
      "driver_name": "AI capex",
      "driver_group": "demand",
      "direction_if_positive": 1,
      "keywords_seed": ["capex", "GPU", "data center", "server"],
      "description": "Enterprise and hyperscaler spending on AI infrastructure",
      "linked_entities": ["NVDA", "AMD", "TSM"],
      "confidence": 0.8
    }
  ]
}
```

### 6.4 Notes

- テーマが「低PBR」のようなスタイルテーマであっても、ドライバーは構築すること
- ドライバーは seed keywords と説明文から半自動生成し、人手で修正可能な形式で保存すること
- テーマの見かけと実体が乖離する可能性があるため、説明文と保有構成の整合性も後で点検できる設計にすること

---

## 7. Stage 2 Requirements: News Structuring

### 7.1 Goal

各ニュース記事を、単なる文章ではなく、
投資判断に使える構造化特徴量へ変換する。

### 7.2 Required Inputs

#### news
- article_id
- timestamp
- source
- title
- body
- language
- url (optional)

### 7.3 Preprocessing

- title + body を統合
- html / boilerplate 除去
- duplicate article 除去
- near duplicate article 除去
- 極端に短い記事除外
- source quality スコア付与
- multilingual の場合は原文保持 + optional translation column

### 7.4 Article-Level Features

各記事について以下を生成。

- clean_text
- article_embedding
- entities
- event_type
- event_polarity
- event_intensity
- topic_id
- topic_probabilities (optional)
- novelty_score
- source_quality_score
- driver_match_scores
- article_length
- language

### 7.5 Event Types

最低限、以下カテゴリを用意。

- earnings
- guidance
- regulation
- subsidy
- tariff
- capex
- order / procurement
- M&A
- buyback
- dividend
- restructuring
- supply disruption
- outage
- geopolitics
- litigation
- product launch
- financing

### 7.6 Topic Modeling

初版では以下をサポートする。

#### A. BERTopic-like pipeline
- embedding
- optional dimension reduction
- clustering
- topic representation
- representative docs

#### B. Dynamic topic interface
- time-bucketed topic summaries
- topic centroid drift
- topic persistence
- topic transition indicators

### 7.7 Novelty

記事の新規性は、rolling window 内の類似記事に対する最大 cosine similarity を用いて定義する。

Example:

```python
novelty = 1 - max_similarity_to_recent_articles
```

### 7.8 Driver Mapping

各記事に対して、各ドライバーとの関連度スコアを出す。

推奨構成要素:

- embedding similarity
- seed keyword match
- linked entity overlap
- event-type consistency
- optional LLM structured mapping

---

## 8. Stage 3 Requirements: Driver-to-Theme Aggregation

### 8.1 Goal

記事ごとの構造化特徴をテーマごとの日次特徴量へ集約する。

### 8.2 Article-to-Theme Weight

各記事 i とテーマ k の関連度を以下で定義。

\[
w_{ik}
=
\alpha \cdot sim(e_i, z_k)
+
\beta \cdot sim(e_i, D_k)
+
\gamma \cdot overlap(entity_i, holdings_k)
\]

Where:
- \(e_i\): article embedding
- \(z_k\): theme embedding
- \(D_k\): driver representation of theme k

### 8.3 Daily Theme Features

各テーマ・各営業日について以下を作成。

- article_count
- distinct_source_count
- raw_news_intensity
- positive_intensity
- negative_intensity
- novelty_weighted_intensity
- driver_group_scores
- dominant_topic
- topic_concentration
- topic_drift
- entity_breadth
- source_quality_weighted_intensity

### 8.4 Output

- theme_daily_features.parquet

---

## 9. Stage 3b Requirements: Market Calibration

### 9.1 Goal

ニュース特徴量を、そのまま使うのではなく、
将来の相対リターンや市場反応に基づいて校正する。

### 9.2 Target Variables

各テーマについて少なくとも以下を作成可能にする。

- next_day_relative_return
- next_week_relative_return
- next_month_relative_return
- next_day_vol
- next_week_vol
- next_week_breadth

### 9.3 Relative Return Definition

relative_return は以下のいずれかを選択可能にする。

- universe cross-sectional mean 超過
- benchmark 超過
- equal-weight theme basket 超過

### 9.4 Models

最低限以下を実装。

- Ridge
- Lasso
- ElasticNet

optional:
- LightGBM
- XGBoost

### 9.5 Training Policy

- rolling window
- expanding window
- strict train / validation / test chronology
- no future information
- feature standardization fit only on train window

### 9.6 Outputs

- calibrated_score
- predicted_relative_return
- feature coefficients / importances
- model diagnostics
- model metadata

---

## 10. Stage 4 Requirements: Ranking

### 10.1 Goal

ニュースの量だけでなく、継続性、加速、過熱、織り込みを考慮した最終ランキングを作る。

### 10.2 Ranking Components

#### structural_trend_score
長期的なニュース・トピック・ドライバーの持続性。

候補:
- 60d / 120d / 250d smoothing
- topic persistence
- driver persistence
- low-noise trend strength

#### news_acceleration_score
足元の変化率と新規性を反映。

候補:
- 5d / 20d change
- novelty-weighted intensity surge
- driver-specific acceleration

#### crowding_penalty
過熱・混雑・hype を罰する。

候補:
- article burst
- price jump
- volume surge
- flow concentration
- IV / skew concentration (if available)

#### stretch_penalty
行き過ぎを罰する。

候補:
- realized vol spike
- short-term overextension
- valuation stretch (if available)

### 10.3 Final Score

\[
FinalScore_{k,t}
=
a \cdot StructuralTrend_{k,t}
+
b \cdot NewsAcceleration_{k,t}
-
c \cdot CrowdingPenalty_{k,t}
-
d \cdot StretchPenalty_{k,t}
\]

### 10.4 Normalization

- cross-sectional z-score
- optional robust z-score
- winsorization configurable

---

## 11. Backtest Requirements

### 11.1 Portfolio Rules

config で以下を切替可能にする。

- long top N equally weighted
- long top N cap-weighted by score
- long top N / underweight bottom N
- long-short top N vs bottom N
- top quantile vs bottom quantile

### 11.2 Rebalancing

- daily
- weekly
- monthly

### 11.3 Execution

- signal_date
- execution_date
- default 1-day lag
- costs included

### 11.4 Constraints

optional:
- max weight
- turnover cap
- sector neutrality
- country neutrality
- style neutrality

### 11.5 Metrics

必須:

- CAGR
- AnnVol
- Sharpe
- MaxDD
- Skew
- Kurtosis
- VaR_5%
- CVaR_5%
- Turnover
- Hit Ratio
- RankIC
- long leg return
- short leg return

---

## 12. File Structure

```text
project_root/
├─ AGENTS.md
├─ README.md
├─ SPEC.md
├─ docs/
│  ├─ sources/
│  └─ notes/
│     ├─ 00_doc_index.md
│     ├─ 10_requirements.md
│     ├─ 20_assumptions.md
│     └─ 30_plan.md
├─ data/
│  ├─ raw/
│  └─ processed/
├─ src/<project_name>/
│  ├─ config.py
│  ├─ schemas.py
│  ├─ io.py
│  ├─ theme_definition.py
│  ├─ news_features.py
│  ├─ topic_models.py
│  ├─ event_mapping.py
│  ├─ theme_aggregation.py
│  ├─ calibration.py
│  ├─ ranking.py
│  ├─ backtest.py
│  ├─ metrics.py
│  └─ reporting.py
├─ notebooks/
│  └─ main.ipynb
└─ outputs/
   ├─ figures/
   ├─ tables/
   └─ logs/
```

---

## 13. Notebook Requirements

`notebooks/main.ipynb` は以下順で end-to-end 実行可能にする。

1. config load
2. data load
3. theme profile construction
4. theme embedding construction
5. article preprocessing
6. article embedding generation
7. event extraction
8. topic modeling
9. driver mapping
10. article-to-theme mapping
11. daily theme feature aggregation
12. calibration
13. ranking
14. backtest
15. reporting

---

## 14. Config Requirements

最低限以下の config を持つこと。

```python
EMBEDDING_MODEL_NAME = "..."
THEME_DESC_WEIGHT = 0.4
HOLDINGS_DESC_WEIGHT = 0.6

ALPHA_THEME_SIM = 0.5
BETA_DRIVER_SIM = 0.3
GAMMA_ENTITY_OVERLAP = 0.2

NOVELTY_WINDOW_DAYS = 30
TOPIC_TIME_BUCKET = "W"

CALIBRATION_TARGET = "next_week_relative_return"
TRAINING_MODE = "rolling"
TRAIN_WINDOW_DAYS = 252 * 2
PRED_HORIZON_DAYS = 5

RANK_A = 1.0
RANK_B = 1.0
RANK_C = 1.0
RANK_D = 1.0

REBAL_FREQ = "W-FRI"
EXEC_LAG = 1
FEE_BPS = 10.0
SLIPPAGE_BPS = 1.0
```

---

## 15. Intermediate Outputs

必ず保存すること。

- theme_profile.parquet
- theme_embeddings.parquet
- theme_driver_library.json
- news_clean.parquet
- article_features.parquet
- article_driver_scores.parquet
- article_theme_scores.parquet
- theme_daily_features.parquet
- calibration_predictions.parquet
- ranking_history.parquet
- backtest_returns.parquet
- backtest_weights.parquet

---

## 16. Reporting Requirements

### Figures
- cumulative_returns.png
- rolling_sharpe.png
- rolling_ic.png
- theme_rank_heatmap.png
- topic_drift_by_theme.png
- driver_contribution_by_theme.png
- crowding_vs_future_return.png

### Tables
- performance_summary.csv
- ranking_history.csv
- top_articles_per_theme.csv
- driver_scores_per_theme.csv
- model_diagnostics.csv

---

## 17. Validation and Sanity Checks

以下を notebook 内で必ず確認すること。

1. future leakage がないか
2. train/test chronology が守られているか
3. article-theme score の上位記事が直感に反していないか
4. driver mapping が極端に偏っていないか
5. novelty score が duplicate burst を properly downweight しているか
6. ranking 上位テーマが news count だけで決まっていないか
7. crowding penalty 追加前後で性能と挙動がどう変わるか
8. topic drift が単なるノイズでないか

---

## 18. Phase Plan

### Phase 1
- theme embedding
- article embedding
- rule-based event extraction
- BERTopic-like topic extraction
- novelty score
- driver mapping
- daily aggregation
- ridge / lasso calibration
- ranking and backtest

### Phase 2
- stronger event classifier
- dynamic topic model enhancement
- options / flows / valuation overlay
- state-dependent calibration
- richer crowding / stretch signals

### Phase 3
- LLM-based structured event extraction
- adaptive driver library update
- advanced ensembling
- dashboardization

---

## 19. Success Criteria

初版成功条件:

1. end-to-end pipeline が main.ipynb で再現可能
2. 各テーマの daily feature が生成される
3. rolling calibration が leakage-free に動く
4. ranking history と backtest が出る
5. 記事→ドライバー→テーマの経路が解釈可能
6. 少なくとも単純 news count ranking より一貫した挙動を示す

---

## 20. Recommended Documentation Set

- docs/notes/00_doc_index.md:
  参照文献とURL一覧、実装上の要点整理
- docs/notes/10_requirements.md:
  本SPECから抽出した必須要件
- docs/notes/20_assumptions.md:
  データ制約、初版の近似、未実装項目
- docs/notes/30_plan.md:
  実装順序、検証手順、マイルストーン
