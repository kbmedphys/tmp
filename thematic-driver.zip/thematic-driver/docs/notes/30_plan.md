# 30_plan

## 実装順序

1. ドキュメント作成
- README と notes 4ファイルを作成し、要件・前提・検証項目を固定。

2. 基盤モジュール
- `config/schemas/io` を実装。
- 入力検証、I/O 抽象化、出力ディレクトリ管理を先に確定。

3. 特徴量モジュール
- `theme_definition/news_features/event_mapping/topic_models` を実装。

4. 集約・学習・順位
- `theme_aggregation/calibration/ranking/backtest/metrics` を実装。

5. レポート
- `reporting` で必須図表と CSV を生成。

6. notebook 統合
- 15ステップ順で orchestrate し、各ステップの成果物保存を実施。

7. スモーク検証
- サンプルデータで end-to-end 実行。
- 必須ファイルが揃うことを確認。

## マイルストーン

- M1: notes + 基盤モジュール完了
- M2: 特徴量・集約・校正完了
- M3: notebook 完了
- M4: E2E 実行と成果物確認
