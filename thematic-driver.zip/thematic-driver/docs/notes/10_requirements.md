# 10_requirements

## 必須要件（Phase 1）

1. end-to-end 実行
- `notebooks/main.ipynb` で config load から reporting まで再現可能。

2. モジュール構成
- `src/thematic_driver` に以下を作成する。
- `config.py`, `schemas.py`, `io.py`, `theme_definition.py`, `news_features.py`, `topic_models.py`, `event_mapping.py`, `theme_aggregation.py`, `calibration.py`, `ranking.py`, `backtest.py`, `metrics.py`, `reporting.py`。

3. 機能要件
- Theme Definition Reconstruction
- News Structuring
- Driver-to-Theme Aggregation
- Market Calibration（Ridge/Lasso/ElasticNet）
- Ranking and Top-N Backtest

4. 入力
- `themes_master`, `theme_holdings`, `company_master`, `news`, `prices`, optional `theme_returns`。

5. 出力
- 中間成果物（SPEC 15節）を保存。
- 必須図表・ログ（CODEX_EXECUTION_PROMPT 9節）を保存。

6. 品質要件
- leakage-free（時系列分割、標準化の train-only fit、未来参照禁止）。
- interpretability 優先。
- incremental 実装。

## notebook のセル順

1. config load
2. data load
3. theme profile construction
4. theme embedding construction
5. article preprocessing
6. article embedding generation
7. event extraction
8. topic modeling
9. driver mapping
10. article-to-theme mapping
11. daily theme feature aggregation
12. calibration
13. ranking
14. backtest
15. reporting
