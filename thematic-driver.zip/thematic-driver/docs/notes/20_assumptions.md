# 20_assumptions

## 前提

- パッケージ名は `thematic_driver`。
- 実行環境は `envs/nlp`。
- 埋め込みは `SentenceTransformer(all-MiniLM-L6-v2)` を必須とし、未取得時は明示エラー。
- 入力未配置でも E2E を確認できるよう、`data/raw` に最小サンプルを同梱。

## 初版の近似

- event extraction はルールベース辞書。
- BERTopic-like は `KMeans + TF-IDF top terms` で代替。
- dynamic topic は time-bucket summary と centroid drift の interface 提供まで。
- crowding/stretch は価格・記事量ベースの軽量 proxy。

## 非対応（Phase 1 では見送り）

- 厳密 D-ETM 再現。
- 本格 LLM structured extraction。
- options/flows/valuation の完全統合。
- 高度なアンサンブル最適化。

## データ前提

- `theme_holdings` は少なくとも銘柄ウェイトと日付を持つ。
- `prices` は `date,ticker,close` を持つ。
- `theme_returns` がある場合は `date,theme_id,theme_return` を持つ。

## リスク

- 埋め込みモデル未ダウンロード時は notebook が停止する。
- サンプルデータは検証用途であり、投資有効性は主張しない。
