# 00_doc_index

## 参照ドキュメント

1. `SPEC.md`
- Phase 1 の機能要件、入出力、保存成果物、検証項目の一次ソース。

2. `CODEX_EXECUTION_PROMPT.md`
- 実装順序（notes → src → notebook）と必須出力の実行指示。

3. `IMPLEMENTATION_INSTRUCTIONS.md`
- 運用手順、初版スコープの固定、実務上の失敗回避メモ。

4. `workspace/AGENTS.md`
- 環境制約（uv 管理、Python パス）と日本語説明ルール。

## 実装上の要点

- notebook は `src/thematic_driver` を呼ぶだけにして、ロジックは全て `src` に集約。
- 未来情報の混入を防ぐため、校正は日次で学習窓を切って逐次予測。
- `theme_returns` は optional。未提供時は `prices` と `theme_holdings` から生成。
- 中間成果物はすべて parquet/json/csv で保存し、再計算を分割可能にする。
- BERTopic 本体に依存せず、差し替え可能な topic interface を維持する。
