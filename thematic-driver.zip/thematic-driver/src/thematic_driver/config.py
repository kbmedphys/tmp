from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict


@dataclass
class Settings:
    project_name: str = "thematic_driver"
    embedding_model_name: str = "all-MiniLM-L6-v2"

    theme_desc_weight: float = 0.4
    holdings_desc_weight: float = 0.6

    alpha_theme_sim: float = 0.5
    beta_driver_sim: float = 0.3
    gamma_entity_overlap: float = 0.2

    novelty_window_days: int = 30
    topic_time_bucket: str = "W"

    calibration_target: str = "next_week_relative_return"
    training_mode: str = "rolling"
    train_window_days: int = 252 * 2
    pred_horizon_days: int = 5

    rank_a: float = 1.0
    rank_b: float = 1.0
    rank_c: float = 1.0
    rank_d: float = 1.0

    rebal_freq: str = "W-FRI"
    exec_lag: int = 1
    top_n: int = 3
    fee_bps: float = 10.0
    slippage_bps: float = 1.0

    random_seed: int = 42

    root_dir: Path = field(default_factory=lambda: Path(__file__).resolve().parents[2])

    @property
    def data_raw_dir(self) -> Path:
        return self.root_dir / "data" / "raw"

    @property
    def data_processed_dir(self) -> Path:
        return self.root_dir / "data" / "processed"

    @property
    def outputs_dir(self) -> Path:
        return self.root_dir / "outputs"

    @property
    def outputs_figures_dir(self) -> Path:
        return self.outputs_dir / "figures"

    @property
    def outputs_tables_dir(self) -> Path:
        return self.outputs_dir / "tables"

    @property
    def outputs_logs_dir(self) -> Path:
        return self.outputs_dir / "logs"

    def ensure_directories(self) -> None:
        for path in [
            self.data_raw_dir,
            self.data_processed_dir,
            self.outputs_dir,
            self.outputs_figures_dir,
            self.outputs_tables_dir,
            self.outputs_logs_dir,
        ]:
            path.mkdir(parents=True, exist_ok=True)

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["root_dir"] = str(self.root_dir)
        payload["data_raw_dir"] = str(self.data_raw_dir)
        payload["data_processed_dir"] = str(self.data_processed_dir)
        payload["outputs_dir"] = str(self.outputs_dir)
        payload["outputs_figures_dir"] = str(self.outputs_figures_dir)
        payload["outputs_tables_dir"] = str(self.outputs_tables_dir)
        payload["outputs_logs_dir"] = str(self.outputs_logs_dir)
        return payload


INPUT_TABLES = {
    "themes_master": False,
    "theme_holdings": False,
    "company_master": False,
    "news": False,
    "prices": False,
    "theme_returns": True,
}


def get_default_settings() -> Settings:
    settings = Settings()
    settings.ensure_directories()
    return settings
