from __future__ import annotations

import numpy as np
import pandas as pd

from .config import Settings


def _zscore(series: pd.Series) -> pd.Series:
    std = series.std(ddof=0)
    if std == 0 or pd.isna(std):
        return pd.Series(np.zeros(len(series)), index=series.index)
    return (series - series.mean()) / std


def build_ranking(
    theme_daily_features: pd.DataFrame,
    calibration_predictions: pd.DataFrame,
    theme_returns: pd.DataFrame,
    settings: Settings,
) -> pd.DataFrame:
    calib = (
        calibration_predictions.groupby(["date", "theme_id"], as_index=False)
        .agg(
            calibrated_score=("predicted_relative_return", "mean"),
            actual_relative_return=("actual_relative_return", "mean"),
        )
        if not calibration_predictions.empty
        else pd.DataFrame(columns=["date", "theme_id", "calibrated_score", "actual_relative_return"])
    )

    returns = theme_returns[["date", "theme_id", "theme_return"]].copy()

    df = theme_daily_features.merge(calib, on=["date", "theme_id"], how="left")
    df = df.merge(returns, on=["date", "theme_id"], how="left")
    df = df.sort_values(["theme_id", "date"]).reset_index(drop=True)

    df["structural_trend_score"] = (
        df.groupby("theme_id")["novelty_weighted_intensity"]
        .transform(lambda s: 0.6 * s.rolling(60, min_periods=5).mean() + 0.4 * s.rolling(120, min_periods=10).mean())
        .fillna(0.0)
    )
    short_mean = (
        df.groupby("theme_id")["raw_news_intensity"].transform(lambda s: s.rolling(5, min_periods=2).mean())
    )
    long_mean = (
        df.groupby("theme_id")["raw_news_intensity"].transform(lambda s: s.rolling(20, min_periods=5).mean())
    )
    df["news_acceleration_score"] = (short_mean - long_mean).fillna(0.0)

    article_burst = df.groupby("date")["article_count"].transform(_zscore)
    ret_mom = (
        df.groupby("theme_id")["theme_return"].transform(lambda s: s.rolling(5, min_periods=2).sum())
    ).fillna(0.0)
    ret_mom_xs = ret_mom.groupby(df["date"]).transform(_zscore)
    df["crowding_penalty"] = (0.7 * article_burst + 0.3 * ret_mom_xs).fillna(0.0)

    vol20 = (
        df.groupby("theme_id")["theme_return"].transform(lambda s: s.rolling(20, min_periods=5).std())
    ).fillna(0.0)
    vol20_xs = vol20.groupby(df["date"]).transform(_zscore)
    overext = (
        df.groupby("theme_id")["theme_return"].transform(lambda s: s.rolling(5, min_periods=2).sum())
    ).abs()
    overext_xs = overext.groupby(df["date"]).transform(_zscore)
    df["stretch_penalty"] = (0.6 * vol20_xs + 0.4 * overext_xs).fillna(0.0)

    for col in [
        "structural_trend_score",
        "news_acceleration_score",
        "crowding_penalty",
        "stretch_penalty",
        "calibrated_score",
    ]:
        df[f"{col}_z"] = df.groupby("date")[col].transform(_zscore).fillna(0.0)

    df["final_score"] = (
        settings.rank_a * df["structural_trend_score_z"]
        + settings.rank_b * df["news_acceleration_score_z"]
        - settings.rank_c * df["crowding_penalty_z"]
        - settings.rank_d * df["stretch_penalty_z"]
        + 0.7 * df["calibrated_score_z"]
    )

    df["rank"] = df.groupby("date")["final_score"].rank(ascending=False, method="dense")
    return df.sort_values(["date", "rank", "theme_id"]).reset_index(drop=True)
