from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Optional

import pandas as pd

from .config import INPUT_TABLES, Settings
from .schemas import SchemaError, validate_and_normalize_inputs


class InputNotFoundError(FileNotFoundError):
    pass


def _candidate_paths(base_dir: Path, stem: str) -> list[Path]:
    return [base_dir / f"{stem}.parquet", base_dir / f"{stem}.csv"]


def find_input_file(base_dir: Path, stem: str) -> Optional[Path]:
    for path in _candidate_paths(base_dir, stem):
        if path.exists():
            return path
    return None


def read_table(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    raise ValueError(f"未対応の拡張子です: {path}")


def load_input_tables(settings: Settings) -> Dict[str, pd.DataFrame]:
    frames: Dict[str, pd.DataFrame] = {}
    for table_name, is_optional in INPUT_TABLES.items():
        file_path = find_input_file(settings.data_raw_dir, table_name)
        if file_path is None:
            if is_optional:
                continue
            raise InputNotFoundError(
                f"入力ファイルが見つかりません: {table_name}.csv/.parquet in {settings.data_raw_dir}"
            )
        frames[table_name] = read_table(file_path)

    try:
        return validate_and_normalize_inputs(frames)
    except SchemaError:
        raise


def save_parquet(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)


def save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def save_json(payload: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fp:
        json.dump(payload, fp, ensure_ascii=False, indent=2)


def save_run_config(settings: Settings) -> Path:
    target = settings.outputs_logs_dir / "run_config.json"
    save_json(settings.to_dict(), target)
    return target
