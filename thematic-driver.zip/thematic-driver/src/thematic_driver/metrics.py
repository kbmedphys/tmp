from __future__ import annotations

import numpy as np
import pandas as pd


def _max_drawdown(cum_curve: pd.Series) -> float:
    running_max = cum_curve.cummax()
    dd = cum_curve / running_max - 1.0
    return float(dd.min())


def _safe_mean(values: pd.Series) -> float:
    values = values.dropna()
    return float(values.mean()) if len(values) else np.nan


def compute_performance_summary(
    backtest_returns: pd.DataFrame,
    ranking_history: pd.DataFrame,
) -> pd.DataFrame:
    if backtest_returns.empty:
        return pd.DataFrame()

    df = backtest_returns.copy().sort_values("date")
    ret = df["net_return"].fillna(0.0)

    ann_factor = 252.0
    total_periods = len(ret)
    years = total_periods / ann_factor if total_periods > 0 else np.nan
    cumulative = float((1.0 + ret).prod() - 1.0)
    cagr = float((1.0 + cumulative) ** (1.0 / years) - 1.0) if years and years > 0 else np.nan

    ann_vol = float(ret.std(ddof=0) * np.sqrt(ann_factor))
    sharpe = float((ret.mean() * ann_factor) / ann_vol) if ann_vol > 0 else np.nan

    cum_nav = (1.0 + ret).cumprod()
    max_dd = _max_drawdown(cum_nav)

    var_5 = float(ret.quantile(0.05))
    cvar_5 = float(ret[ret <= var_5].mean()) if (ret <= var_5).any() else var_5

    turnover = _safe_mean(df["turnover"]) if "turnover" in df else np.nan
    hit_ratio = float((ret > 0).mean())

    rank_ic_values = []
    if not ranking_history.empty and "actual_relative_return" in ranking_history:
        for _, day_group in ranking_history.groupby("date"):
            day_group = day_group.dropna(subset=["actual_relative_return", "final_score"])
            if day_group["theme_id"].nunique() < 2:
                continue
            corr = day_group["final_score"].corr(day_group["actual_relative_return"], method="spearman")
            if pd.notna(corr):
                rank_ic_values.append(float(corr))

    summary = {
        "CAGR": cagr,
        "AnnVol": ann_vol,
        "Sharpe": sharpe,
        "MaxDD": max_dd,
        "Skew": float(ret.skew()),
        "Kurtosis": float(ret.kurtosis()),
        "VaR_5%": var_5,
        "CVaR_5%": cvar_5,
        "Turnover": turnover,
        "Hit Ratio": hit_ratio,
        "RankIC": float(np.mean(rank_ic_values)) if rank_ic_values else np.nan,
        "long leg return": float(df["portfolio_return"].mean()) if "portfolio_return" in df else np.nan,
        "short leg return": 0.0,
    }

    return pd.DataFrame([summary])
