from __future__ import annotations

import hashlib
import html
import re
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

from .config import Settings
from .theme_definition import load_embedding_model


SOURCE_QUALITY_MAP = {
    "reuters": 0.95,
    "bloomberg": 0.95,
    "nikkei": 0.9,
    "ft": 0.9,
    "wsj": 0.9,
    "company_release": 0.75,
}


def _normalize_text(text: str) -> str:
    if text is None:
        return ""
    text = html.unescape(str(text))
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"https?://\S+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def preprocess_news(news: pd.DataFrame) -> pd.DataFrame:
    df = news.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["title"] = df["title"].fillna("")
    df["body"] = df["body"].fillna("")

    df["clean_text"] = (df["title"] + " " + df["body"]).map(_normalize_text)
    df["article_length"] = df["clean_text"].str.len()

    df = df[df["article_length"] >= 40].copy()
    df["fingerprint"] = df["clean_text"].map(lambda x: hashlib.md5(x.encode("utf-8")).hexdigest())
    df["dup_bucket"] = df["timestamp"].dt.normalize()
    df = df.drop_duplicates(subset=["dup_bucket", "fingerprint"], keep="first")

    df["near_fingerprint"] = df["clean_text"].str.lower().str[:180].map(
        lambda x: hashlib.md5(x.encode("utf-8")).hexdigest()
    )
    # 同日内の near-duplicate のみ除去し、時系列全体での再出現は残す。
    df["near_dup_bucket"] = df["timestamp"].dt.normalize()
    df = df.drop_duplicates(subset=["near_dup_bucket", "near_fingerprint"], keep="first")

    def source_score(source: str) -> float:
        key = str(source).strip().lower()
        return SOURCE_QUALITY_MAP.get(key, 0.6)

    df["source_quality_score"] = df["source"].map(source_score)
    df["date"] = df["timestamp"].dt.normalize()

    df = df.drop(columns=["fingerprint", "near_fingerprint", "dup_bucket", "near_dup_bucket"])
    return df.sort_values("timestamp").reset_index(drop=True)


def add_article_embeddings(news_clean: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    model = load_embedding_model(settings)
    vectors = model.encode(news_clean["clean_text"].tolist(), normalize_embeddings=True, show_progress_bar=False)

    df = news_clean.copy()
    df["article_embedding"] = [vec.tolist() for vec in vectors]
    return df


def _extract_ticker_entities(text: str, known_tickers: set[str]) -> set[str]:
    candidates = set(re.findall(r"\b[A-Z]{1,5}\b", text))
    return {token for token in candidates if token in known_tickers}


def _extract_name_entities(text_lower: str, name_to_ticker: dict[str, str]) -> set[str]:
    found: set[str] = set()
    for company_name, ticker in name_to_ticker.items():
        if company_name and company_name in text_lower:
            found.add(ticker)
    return found


def add_entities(
    article_df: pd.DataFrame,
    theme_holdings: pd.DataFrame,
    company_master: pd.DataFrame,
) -> pd.DataFrame:
    known_tickers = set(theme_holdings["ticker"].astype(str).unique().tolist())
    name_to_ticker = {
        str(row.company_name).lower(): str(row.ticker)
        for row in company_master[["ticker", "company_name"]].itertuples(index=False)
    }

    entities: list[list[str]] = []
    for row in article_df.itertuples(index=False):
        text = str(row.clean_text)
        text_lower = text.lower()
        found = _extract_ticker_entities(text, known_tickers)
        found |= _extract_name_entities(text_lower, name_to_ticker)
        entities.append(sorted(found))

    df = article_df.copy()
    df["entities"] = entities
    df["entity_count"] = df["entities"].map(len)
    return df


def _stack_embeddings(embeddings: Iterable[list[float]]) -> np.ndarray:
    rows = [np.asarray(v, dtype=float) for v in embeddings]
    if not rows:
        return np.zeros((0, 0), dtype=float)
    return np.vstack(rows)


def add_novelty(article_df: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    df = article_df.sort_values("timestamp").reset_index(drop=True).copy()
    emb = _stack_embeddings(df["article_embedding"])

    novelty_scores: list[float] = []
    timestamps = df["timestamp"].tolist()
    window = pd.Timedelta(days=settings.novelty_window_days)

    for i, ts in enumerate(timestamps):
        lookback_idx: list[int] = []
        for j in range(i):
            if timestamps[j] >= ts - window:
                lookback_idx.append(j)
        if not lookback_idx:
            novelty_scores.append(1.0)
            continue
        sims = cosine_similarity(emb[i : i + 1], emb[lookback_idx])[0]
        novelty = 1.0 - float(np.max(sims))
        novelty_scores.append(float(np.clip(novelty, 0.0, 1.0)))

    df["novelty_score"] = novelty_scores
    return df
