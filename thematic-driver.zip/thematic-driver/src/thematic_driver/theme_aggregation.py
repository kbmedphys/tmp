from __future__ import annotations

import json
from collections import defaultdict
from typing import Dict, Iterable, List

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

from .config import Settings
from .theme_definition import load_embedding_model


def _stack_embeddings(embeddings: Iterable[list[float]]) -> np.ndarray:
    rows = [np.asarray(v, dtype=float) for v in embeddings]
    if not rows:
        return np.zeros((0, 0), dtype=float)
    return np.vstack(rows)


def _ensure_list(value: object) -> list[str]:
    if isinstance(value, list):
        return [str(v) for v in value]
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            try:
                parsed = json.loads(stripped)
                if isinstance(parsed, list):
                    return [str(v) for v in parsed]
            except Exception:
                pass
        if ";" in stripped:
            return [v.strip() for v in stripped.split(";") if v.strip()]
        if stripped:
            return [stripped]
    return []


def _keyword_match_score(text: str, keywords: list[str]) -> float:
    if not keywords:
        return 0.0
    low = text.lower()
    hit = sum(kw.lower() in low for kw in keywords)
    return float(hit / len(keywords))


def _event_consistency(driver_group: str, event_type: str) -> float:
    event_type = str(event_type).lower()
    group = str(driver_group).lower()
    mapping = {
        "demand": {"earnings", "guidance", "capex", "order / procurement", "product launch"},
        "supply": {"supply disruption", "outage", "capex", "restructuring"},
        "policy": {"regulation", "subsidy", "tariff", "geopolitics", "litigation"},
        "valuation": {"buyback", "dividend", "financing"},
    }
    allowed = mapping.get(group, set())
    if not allowed:
        return 0.5
    return 1.0 if event_type in allowed else 0.2


def build_article_driver_scores(
    article_features: pd.DataFrame,
    driver_library_df: pd.DataFrame,
    settings: Settings,
) -> pd.DataFrame:
    if article_features.empty or driver_library_df.empty:
        return pd.DataFrame(
            columns=[
                "article_id",
                "date",
                "theme_id",
                "driver_name",
                "driver_group",
                "driver_score",
                "embedding_similarity",
                "keyword_match",
                "entity_overlap",
                "event_consistency",
            ]
        )

    model = load_embedding_model(settings)
    driver_text = (
        driver_library_df["description"].fillna("").astype(str)
        + " "
        + driver_library_df["keywords_seed"].map(lambda x: " ".join(_ensure_list(x)))
    ).tolist()
    driver_emb = model.encode(driver_text, normalize_embeddings=True, show_progress_bar=False)

    article_emb = _stack_embeddings(article_features["article_embedding"])
    sim_matrix = cosine_similarity(article_emb, np.asarray(driver_emb, dtype=float))

    rows: list[dict] = []
    for art_idx, art_row in enumerate(article_features.itertuples(index=False)):
        article_entities = set(_ensure_list(art_row.entities))
        for drv_idx, drv_row in enumerate(driver_library_df.itertuples(index=False)):
            keyword_match = _keyword_match_score(str(art_row.clean_text), _ensure_list(drv_row.keywords_seed))
            linked_entities = set(_ensure_list(drv_row.linked_entities))
            if linked_entities:
                entity_overlap = len(article_entities & linked_entities) / len(linked_entities)
            else:
                entity_overlap = 0.0
            event_consistency = _event_consistency(drv_row.driver_group, art_row.event_type)
            embed_sim = float(sim_matrix[art_idx, drv_idx])

            driver_score = (
                0.55 * embed_sim
                + 0.2 * keyword_match
                + 0.15 * entity_overlap
                + 0.1 * event_consistency
            )

            rows.append(
                {
                    "article_id": art_row.article_id,
                    "date": art_row.date,
                    "theme_id": drv_row.theme_id,
                    "driver_name": drv_row.driver_name,
                    "driver_group": drv_row.driver_group,
                    "driver_score": float(driver_score),
                    "embedding_similarity": embed_sim,
                    "keyword_match": float(keyword_match),
                    "entity_overlap": float(entity_overlap),
                    "event_consistency": float(event_consistency),
                }
            )

    return pd.DataFrame(rows)


def build_article_theme_scores(
    article_features: pd.DataFrame,
    theme_embeddings: pd.DataFrame,
    article_driver_scores: pd.DataFrame,
    theme_holdings: pd.DataFrame,
    settings: Settings,
) -> pd.DataFrame:
    if article_features.empty or theme_embeddings.empty:
        return pd.DataFrame()

    article_emb = _stack_embeddings(article_features["article_embedding"])
    theme_emb = _stack_embeddings(theme_embeddings["embedding_combined"])
    theme_sim = cosine_similarity(article_emb, theme_emb)

    theme_ids = theme_embeddings["theme_id"].tolist()
    driver_theme = (
        article_driver_scores.groupby(["article_id", "theme_id"], as_index=False)["driver_score"]
        .mean()
        .rename(columns={"driver_score": "driver_sim"})
    )
    driver_map = {(r.article_id, r.theme_id): float(r.driver_sim) for r in driver_theme.itertuples(index=False)}

    holdings_map: dict[str, set[str]] = (
        theme_holdings.groupby("theme_id")["ticker"].apply(lambda s: set(s.astype(str))).to_dict()
    )

    rows: list[dict] = []
    for i, art in enumerate(article_features.itertuples(index=False)):
        entities = set(_ensure_list(art.entities))
        for j, theme_id in enumerate(theme_ids):
            theme_tickers = holdings_map.get(theme_id, set())
            overlap = len(entities & theme_tickers) / len(theme_tickers) if theme_tickers else 0.0
            theme_component = float(theme_sim[i, j])
            driver_component = driver_map.get((art.article_id, theme_id), 0.0)
            theme_score = (
                settings.alpha_theme_sim * theme_component
                + settings.beta_driver_sim * driver_component
                + settings.gamma_entity_overlap * overlap
            )

            rows.append(
                {
                    "article_id": art.article_id,
                    "timestamp": art.timestamp,
                    "date": art.date,
                    "theme_id": theme_id,
                    "theme_score": float(theme_score),
                    "theme_sim": theme_component,
                    "driver_sim": driver_component,
                    "entity_overlap": float(overlap),
                }
            )

    return pd.DataFrame(rows)


def aggregate_theme_daily_features(
    article_theme_scores: pd.DataFrame,
    article_features: pd.DataFrame,
    article_driver_scores: pd.DataFrame,
) -> pd.DataFrame:
    if article_theme_scores.empty:
        return pd.DataFrame()

    article_cols = [
        "article_id",
        "date",
        "source",
        "event_polarity",
        "event_intensity",
        "novelty_score",
        "topic_id",
        "source_quality_score",
        "entities",
    ]
    merged = article_theme_scores.merge(article_features[article_cols], on=["article_id", "date"], how="left")

    driver_daily = (
        article_driver_scores.groupby(["date", "theme_id", "driver_group"], as_index=False)["driver_score"]
        .mean()
        .pivot(index=["date", "theme_id"], columns="driver_group", values="driver_score")
        .fillna(0.0)
        .reset_index()
    )
    driver_daily.columns = [
        col if isinstance(col, str) else col
        for col in driver_daily.columns
    ]
    for col in list(driver_daily.columns):
        if col not in {"date", "theme_id"}:
            driver_daily.rename(columns={col: f"driver_group_{col}"}, inplace=True)

    out_rows: list[dict] = []
    topic_distributions: dict[tuple[str, pd.Timestamp], dict[int, float]] = {}

    for (theme_id, date), group in merged.groupby(["theme_id", "date"]):
        weight = group["theme_score"].clip(lower=0.0)
        raw_news_intensity = float((weight * group["event_intensity"]).sum())
        pos_mask = group["event_polarity"] > 0
        neg_mask = group["event_polarity"] < 0

        topic_weight = defaultdict(float)
        for topic_id, w in zip(group["topic_id"].tolist(), weight.tolist()):
            if pd.isna(topic_id):
                continue
            topic_weight[int(topic_id)] += float(w)
        total_topic_w = sum(topic_weight.values())
        topic_share = {
            k: (v / total_topic_w if total_topic_w > 0 else 0.0) for k, v in topic_weight.items()
        }
        dominant_topic = max(topic_share.items(), key=lambda x: x[1])[0] if topic_share else -1
        topic_concentration = max(topic_share.values()) if topic_share else 0.0

        entities_set: set[str] = set()
        for entities in group["entities"].tolist():
            entities_set |= set(_ensure_list(entities))

        out_rows.append(
            {
                "theme_id": theme_id,
                "date": date,
                "article_count": int(group["article_id"].nunique()),
                "distinct_source_count": int(group["source"].nunique()),
                "raw_news_intensity": raw_news_intensity,
                "positive_intensity": float((weight[pos_mask] * group.loc[pos_mask, "event_intensity"]).sum()),
                "negative_intensity": float((weight[neg_mask] * group.loc[neg_mask, "event_intensity"]).sum()),
                "novelty_weighted_intensity": float(
                    (weight * group["event_intensity"] * group["novelty_score"]).sum()
                ),
                "dominant_topic": int(dominant_topic),
                "topic_concentration": float(topic_concentration),
                "entity_breadth": int(len(entities_set)),
                "source_quality_weighted_intensity": float(
                    (weight * group["source_quality_score"] * group["event_intensity"]).sum()
                ),
                "topic_distribution": json.dumps(topic_share, ensure_ascii=False),
            }
        )
        topic_distributions[(theme_id, pd.Timestamp(date))] = topic_share

    daily = pd.DataFrame(out_rows).sort_values(["theme_id", "date"]).reset_index(drop=True)
    daily = daily.merge(driver_daily, on=["date", "theme_id"], how="left").fillna(0.0)

    topic_drift_map: dict[tuple[str, pd.Timestamp], float] = {}
    for theme_id, grp in daily.groupby("theme_id"):
        grp = grp.sort_values("date")
        prev_date: pd.Timestamp | None = None
        for row in grp.itertuples(index=False):
            cur_date = pd.Timestamp(row.date)
            cur_key = (theme_id, cur_date)
            if prev_date is None:
                topic_drift_map[cur_key] = 0.0
                prev_date = cur_date
                continue
            prev_key = (theme_id, prev_date)
            cur_dist = topic_distributions.get(cur_key, {})
            prev_dist = topic_distributions.get(prev_key, {})
            all_topics = set(cur_dist) | set(prev_dist)
            if not all_topics:
                topic_drift_map[cur_key] = 0.0
            else:
                drift = 0.5 * sum(abs(cur_dist.get(k, 0.0) - prev_dist.get(k, 0.0)) for k in all_topics)
                topic_drift_map[cur_key] = float(drift)
            prev_date = cur_date

    daily["topic_drift"] = [topic_drift_map.get((r.theme_id, pd.Timestamp(r.date)), 0.0) for r in daily.itertuples(index=False)]
    return daily
