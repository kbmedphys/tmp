from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List

import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.preprocessing import normalize

from .config import Settings


STOP_WORDS = {
    "the",
    "and",
    "for",
    "with",
    "from",
    "that",
    "this",
    "into",
    "across",
    "their",
    "its",
    "are",
    "will",
    "about",
    "theme",
    "company",
    "companies",
}


DRIVER_TEMPLATE_MAP = {
    "ai": [
        {
            "driver_name": "AI infrastructure capex",
            "driver_group": "demand",
            "keywords_seed": ["ai", "gpu", "datacenter", "server", "capex"],
            "description": "Enterprise and hyperscaler spending for AI infrastructure.",
        },
        {
            "driver_name": "Model deployment productivity",
            "driver_group": "demand",
            "keywords_seed": ["model", "deployment", "automation", "inference"],
            "description": "Commercial adoption of AI workloads in production systems.",
        },
    ],
    "semiconductor": [
        {
            "driver_name": "Wafer demand cycle",
            "driver_group": "demand",
            "keywords_seed": ["wafer", "foundry", "chip", "order"],
            "description": "Upcycle and backlog dynamics in semiconductor demand.",
        },
        {
            "driver_name": "Supply chain constraints",
            "driver_group": "supply",
            "keywords_seed": ["capacity", "yield", "shortage", "equipment"],
            "description": "Supply-side bottlenecks affecting chip shipment and pricing.",
        },
    ],
    "renewable": [
        {
            "driver_name": "Clean energy deployment",
            "driver_group": "demand",
            "keywords_seed": ["solar", "wind", "battery", "deployment"],
            "description": "Installation growth and demand for clean power assets.",
        },
        {
            "driver_name": "Policy subsidy support",
            "driver_group": "policy",
            "keywords_seed": ["subsidy", "tax credit", "regulation", "incentive"],
            "description": "Policy support that improves renewable project economics.",
        },
    ],
    "defense": [
        {
            "driver_name": "Defense budget expansion",
            "driver_group": "policy",
            "keywords_seed": ["defense budget", "procurement", "contract"],
            "description": "Government spending trajectory for defense procurement.",
        },
        {
            "driver_name": "Geopolitical risk premium",
            "driver_group": "demand",
            "keywords_seed": ["geopolitics", "security", "conflict"],
            "description": "Security tension increasing demand for defense systems.",
        },
    ],
}


@dataclass
class DriverRecord:
    theme_id: str
    theme_name: str
    drivers: List[Dict[str, object]]


class EmbeddingModelError(RuntimeError):
    pass


def _json_compact(payload: object) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True)


def _weighted_mix_as_dict(group: pd.DataFrame, key_col: str) -> Dict[str, float]:
    weights = group.groupby(key_col, dropna=False)["weight"].sum()
    total = float(weights.sum())
    if total <= 0:
        return {}
    mix = {str(k): float(v / total) for k, v in weights.items() if pd.notna(k)}
    return dict(sorted(mix.items(), key=lambda item: item[1], reverse=True))


def _top_tokens(texts: Iterable[str], top_k: int = 8) -> list[str]:
    counter: Counter[str] = Counter()
    for text in texts:
        for token in re.findall(r"[a-zA-Z][a-zA-Z0-9\-]{2,}", str(text).lower()):
            if token not in STOP_WORDS:
                counter[token] += 1
    return [token for token, _ in counter.most_common(top_k)]


def _select_driver_templates(theme_name: str, theme_desc: str) -> list[dict]:
    text = f"{theme_name} {theme_desc}".lower()
    for key, templates in DRIVER_TEMPLATE_MAP.items():
        if key in text:
            return templates
    return [
        {
            "driver_name": "Fundamental demand trend",
            "driver_group": "demand",
            "keywords_seed": ["demand", "order", "growth"],
            "description": "Underlying demand trend for the theme constituents.",
        },
        {
            "driver_name": "Policy and macro sensitivity",
            "driver_group": "policy",
            "keywords_seed": ["regulation", "policy", "rate"],
            "description": "Policy and macro factors that affect the theme earnings path.",
        },
    ]


def load_embedding_model(settings: Settings) -> SentenceTransformer:
    try:
        return SentenceTransformer(settings.embedding_model_name, local_files_only=True)
    except Exception as exc:
        raise EmbeddingModelError(
            "SentenceTransformer model が見つかりません。"
            "事前に envs/nlp で all-MiniLM-L6-v2 をダウンロードしてください。"
        ) from exc


def build_theme_profile(
    themes_master: pd.DataFrame,
    theme_holdings: pd.DataFrame,
    company_master: pd.DataFrame,
) -> pd.DataFrame:
    holdings_enriched = theme_holdings.merge(company_master, on="ticker", how="left")
    holdings_enriched["weight"] = holdings_enriched["weight"].fillna(0.0)
    holdings_enriched["company_description"] = holdings_enriched["company_description"].fillna("")
    holdings_enriched["style_tags"] = holdings_enriched.get("style_tags", "")

    agg_rows: list[dict] = []
    for theme_id, group in holdings_enriched.groupby("theme_id"):
        top_holdings = group.sort_values("weight", ascending=False)
        weighted_desc = " ".join(
            f"[{row.ticker}:{row.weight:.3f}] {row.company_description}"
            for row in top_holdings.itertuples()
        )
        style_mix = _weighted_mix_as_dict(
            group.assign(style_tags=group["style_tags"].fillna("unknown")), "style_tags"
        )
        agg_rows.append(
            {
                "theme_id": theme_id,
                "weighted_holding_descriptions": weighted_desc,
                "sector_mix": _json_compact(_weighted_mix_as_dict(group, "sector")),
                "country_mix": _json_compact(_weighted_mix_as_dict(group, "country")),
                "style_mix": _json_compact(style_mix),
                "holdings_count": int(group["ticker"].nunique()),
                "linked_entities": _json_compact(top_holdings["ticker"].head(10).tolist()),
                "top_tokens": _json_compact(_top_tokens(group["company_description"].tolist(), top_k=12)),
            }
        )

    profiles = pd.DataFrame(agg_rows)
    profiles = themes_master.merge(profiles, on="theme_id", how="left")
    profiles["theme_description"] = profiles["theme_description"].fillna("")
    profiles["weighted_holding_descriptions"] = profiles["weighted_holding_descriptions"].fillna("")
    return profiles


def _encode_texts(model: SentenceTransformer, texts: list[str]) -> np.ndarray:
    if not texts:
        return np.zeros((0, 0), dtype=float)
    vectors = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
    return np.asarray(vectors, dtype=float)


def build_theme_embeddings(theme_profile: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    model = load_embedding_model(settings)
    desc_texts = theme_profile["theme_description"].astype(str).tolist()
    holdings_texts = theme_profile["weighted_holding_descriptions"].astype(str).tolist()

    desc_emb = _encode_texts(model, desc_texts)
    holdings_emb = _encode_texts(model, holdings_texts)
    combined = normalize(
        settings.theme_desc_weight * desc_emb + settings.holdings_desc_weight * holdings_emb,
        norm="l2",
    )

    output = theme_profile[["theme_id", "theme_name"]].copy()
    output["embedding_theme_desc"] = [row.tolist() for row in desc_emb]
    output["embedding_holdings_desc_weighted"] = [row.tolist() for row in holdings_emb]
    output["embedding_combined"] = [row.tolist() for row in combined]
    return output


def generate_theme_driver_library(
    theme_profile: pd.DataFrame,
    theme_holdings: pd.DataFrame,
    company_master: pd.DataFrame,
) -> list[dict]:
    holdings_enriched = theme_holdings.merge(company_master, on="ticker", how="left")
    out: list[dict] = []

    for row in theme_profile.itertuples():
        matched = holdings_enriched[holdings_enriched["theme_id"] == row.theme_id]
        linked_entities = (
            matched.sort_values("weight", ascending=False)["ticker"].dropna().head(5).tolist()
        )
        top_tokens = json.loads(row.top_tokens) if isinstance(row.top_tokens, str) and row.top_tokens else []
        templates = _select_driver_templates(row.theme_name, row.theme_description)

        drivers: list[dict] = []
        for idx, template in enumerate(templates, start=1):
            seed = list(dict.fromkeys(template["keywords_seed"] + top_tokens[:4]))
            drivers.append(
                {
                    "driver_name": template["driver_name"],
                    "driver_group": template["driver_group"],
                    "direction_if_positive": 1,
                    "keywords_seed": seed,
                    "description": template["description"],
                    "linked_entities": linked_entities,
                    "confidence": round(0.75 - (idx - 1) * 0.05, 2),
                }
            )

        out.append(
            {
                "theme_id": row.theme_id,
                "theme_name": row.theme_name,
                "drivers": drivers,
            }
        )
    return out


def save_driver_library(driver_library: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fp:
        json.dump(driver_library, fp, ensure_ascii=False, indent=2)


def driver_library_to_frame(driver_library: list[dict]) -> pd.DataFrame:
    rows: list[dict] = []
    for theme in driver_library:
        for driver in theme["drivers"]:
            rows.append(
                {
                    "theme_id": theme["theme_id"],
                    "theme_name": theme["theme_name"],
                    "driver_name": driver["driver_name"],
                    "driver_group": driver["driver_group"],
                    "direction_if_positive": driver.get("direction_if_positive", 1),
                    "keywords_seed": driver.get("keywords_seed", []),
                    "description": driver.get("description", ""),
                    "linked_entities": driver.get("linked_entities", []),
                    "confidence": driver.get("confidence", 0.5),
                }
            )
    return pd.DataFrame(rows)
