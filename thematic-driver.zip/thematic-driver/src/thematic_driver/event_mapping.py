from __future__ import annotations

import re

import numpy as np
import pandas as pd


EVENT_KEYWORDS = {
    "earnings": ["earnings", "results", "quarter", "eps"],
    "guidance": ["guidance", "outlook", "forecast"],
    "regulation": ["regulation", "regulator", "rule", "compliance"],
    "subsidy": ["subsidy", "tax credit", "incentive"],
    "tariff": ["tariff", "duty", "trade barrier"],
    "capex": ["capex", "capital spending", "investment"],
    "order / procurement": ["order", "procurement", "contract", "award"],
    "M&A": ["acquire", "merger", "buyout", "stake"],
    "buyback": ["buyback", "repurchase"],
    "dividend": ["dividend", "payout"],
    "restructuring": ["restructuring", "layoff", "reorganization"],
    "supply disruption": ["shortage", "disruption", "delay", "bottleneck"],
    "outage": ["outage", "shutdown", "blackout"],
    "geopolitics": ["geopolitic", "sanction", "conflict", "war"],
    "litigation": ["litigation", "lawsuit", "settlement", "court"],
    "product launch": ["launch", "release", "new product"],
    "financing": ["funding", "bond", "equity raise", "loan"],
}

POSITIVE_WORDS = {
    "beat",
    "strong",
    "upgraded",
    "growth",
    "improve",
    "surge",
    "record",
    "expand",
    "profit",
    "win",
}

NEGATIVE_WORDS = {
    "miss",
    "weak",
    "downgrade",
    "decline",
    "fall",
    "risk",
    "loss",
    "cut",
    "delay",
    "lawsuit",
}


def _match_event_type(text: str) -> str:
    low = text.lower()
    for event_type, keywords in EVENT_KEYWORDS.items():
        if any(keyword in low for keyword in keywords):
            return event_type
    return "other"


def _polarity_score(text: str) -> int:
    tokens = re.findall(r"[a-zA-Z][a-zA-Z\-]+", text.lower())
    pos = sum(token in POSITIVE_WORDS for token in tokens)
    neg = sum(token in NEGATIVE_WORDS for token in tokens)
    return int(pos - neg)


def _intensity(text: str, polarity_raw: int) -> float:
    low = text.lower()
    strong_terms = [
        "urgent",
        "major",
        "significant",
        "material",
        "record",
        "unexpected",
        "large",
        "sharp",
        "surge",
        "collapse",
    ]
    strong_hits = sum(term in low for term in strong_terms)
    numeric_hits = len(re.findall(r"\b\d+(?:\.\d+)?%?\b", text))

    score = 0.25 + 0.12 * strong_hits + 0.03 * min(numeric_hits, 8) + 0.05 * abs(polarity_raw)
    return float(np.clip(score, 0.1, 1.0))


def add_event_features(article_df: pd.DataFrame) -> pd.DataFrame:
    df = article_df.copy()
    df["event_type"] = df["clean_text"].map(_match_event_type)
    df["polarity_raw"] = df["clean_text"].map(_polarity_score)
    df["event_polarity"] = df["polarity_raw"].map(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
    df["event_intensity"] = [
        _intensity(text, pol)
        for text, pol in zip(df["clean_text"].tolist(), df["polarity_raw"].tolist())
    ]
    return df.drop(columns=["polarity_raw"])
