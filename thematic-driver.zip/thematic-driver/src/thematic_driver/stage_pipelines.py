from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from .backtest import run_backtest
from .calibration import build_calibration_targets, resolve_theme_returns, run_calibration
from .config import Settings
from .event_mapping import add_event_features
from .io import save_csv, save_parquet
from .metrics import compute_performance_summary
from .news_features import add_article_embeddings, add_entities, add_novelty, preprocess_news
from .ranking import build_ranking
from .theme_aggregation import (
    aggregate_theme_daily_features,
    build_article_driver_scores,
    build_article_theme_scores,
)
from .theme_definition import (
    build_theme_embeddings,
    build_theme_profile,
    driver_library_to_frame,
    generate_theme_driver_library,
    save_driver_library,
)
from .topic_models import fit_bertopic_like


def _as_path(path_like: str | Path) -> Path:
    path = Path(path_like)
    path.mkdir(parents=True, exist_ok=True)
    return path


def run_stage1_theme_representation(
    inputs: dict[str, pd.DataFrame],
    settings: Settings,
    out_dir: str | Path,
) -> dict[str, Any]:
    """Stage 1: テーマ再定義を実行し、成果物を保存して返す。"""
    stage_dir = _as_path(out_dir)

    theme_profile = build_theme_profile(
        inputs["themes_master"],
        inputs["theme_holdings"],
        inputs["company_master"],
    )
    theme_embeddings = build_theme_embeddings(theme_profile, settings)
    driver_library = generate_theme_driver_library(
        theme_profile,
        inputs["theme_holdings"],
        inputs["company_master"],
    )
    driver_library_df = driver_library_to_frame(driver_library)

    save_parquet(theme_profile, stage_dir / "theme_profile.parquet")
    save_parquet(theme_embeddings, stage_dir / "theme_embeddings.parquet")
    save_driver_library(driver_library, stage_dir / "theme_driver_library.json")
    save_parquet(driver_library_df, stage_dir / "driver_library_table.parquet")

    return {
        "stage_dir": stage_dir,
        "theme_profile": theme_profile,
        "theme_embeddings": theme_embeddings,
        "driver_library": driver_library,
        "driver_library_df": driver_library_df,
    }


def run_stage2_news_to_drivers(
    inputs: dict[str, pd.DataFrame],
    stage1_artifacts: dict[str, Any],
    settings: Settings,
    out_dir: str | Path,
) -> dict[str, Any]:
    """Stage 2: ニュース構造化とドライバー写像を実行する。"""
    stage_dir = _as_path(out_dir)

    news_clean = preprocess_news(inputs["news"])
    article_features = add_article_embeddings(news_clean, settings)
    article_features = add_entities(article_features, inputs["theme_holdings"], inputs["company_master"])
    article_features = add_novelty(article_features, settings)
    article_features = add_event_features(article_features)

    article_topics, topic_summary, topic_dynamic = fit_bertopic_like(article_features, settings)

    article_driver_scores = build_article_driver_scores(
        article_topics,
        stage1_artifacts["driver_library_df"],
        settings,
    )
    article_theme_scores = build_article_theme_scores(
        article_topics,
        stage1_artifacts["theme_embeddings"],
        article_driver_scores,
        inputs["theme_holdings"],
        settings,
    )
    theme_daily_features = aggregate_theme_daily_features(
        article_theme_scores,
        article_topics,
        article_driver_scores,
    )

    save_parquet(news_clean, stage_dir / "news_clean.parquet")
    save_parquet(article_topics, stage_dir / "article_features.parquet")
    save_parquet(topic_summary, stage_dir / "topic_summary.parquet")
    save_parquet(topic_dynamic, stage_dir / "topic_dynamic.parquet")
    save_parquet(article_driver_scores, stage_dir / "article_driver_scores.parquet")
    save_parquet(article_theme_scores, stage_dir / "article_theme_scores.parquet")
    save_parquet(theme_daily_features, stage_dir / "theme_daily_features.parquet")

    return {
        "stage_dir": stage_dir,
        "news_clean": news_clean,
        "article_features": article_topics,
        "topic_summary": topic_summary,
        "topic_dynamic": topic_dynamic,
        "article_driver_scores": article_driver_scores,
        "article_theme_scores": article_theme_scores,
        "theme_daily_features": theme_daily_features,
    }


def run_stage3_market_calibration(
    inputs: dict[str, pd.DataFrame],
    stage2_artifacts: dict[str, Any],
    settings: Settings,
    out_dir: str | Path,
) -> dict[str, Any]:
    """Stage 3: 市場校正を実行し、リーケージ検証用 trace を返す。"""
    stage_dir = _as_path(out_dir)

    has_theme_returns = "theme_returns" in inputs and not inputs["theme_returns"].empty
    theme_returns_source = "provided" if has_theme_returns else "derived_from_prices"

    theme_returns = resolve_theme_returns(
        inputs["prices"],
        inputs["theme_holdings"],
        inputs.get("theme_returns"),
    )
    targets = build_calibration_targets(theme_returns)

    (
        calibration_predictions,
        model_diagnostics,
        calibration_dataset,
        training_trace,
    ) = run_calibration(
        stage2_artifacts["theme_daily_features"],
        targets,
        settings,
        return_training_trace=True,
    )

    metadata = pd.DataFrame(
        [
            {
                "theme_returns_source": theme_returns_source,
                "n_theme_returns": int(len(theme_returns)),
                "n_targets": int(len(targets)),
                "n_predictions": int(len(calibration_predictions)),
            }
        ]
    )

    save_parquet(theme_returns, stage_dir / "theme_returns.parquet")
    save_parquet(targets, stage_dir / "calibration_targets.parquet")
    save_parquet(calibration_predictions, stage_dir / "calibration_predictions.parquet")
    save_parquet(calibration_dataset, stage_dir / "calibration_dataset.parquet")
    save_csv(model_diagnostics, stage_dir / "model_diagnostics.csv")
    save_csv(training_trace, stage_dir / "training_trace.csv")
    save_csv(metadata, stage_dir / "stage3_metadata.csv")

    return {
        "stage_dir": stage_dir,
        "theme_returns_source": theme_returns_source,
        "theme_returns": theme_returns,
        "targets": targets,
        "calibration_predictions": calibration_predictions,
        "model_diagnostics": model_diagnostics,
        "calibration_dataset": calibration_dataset,
        "training_trace": training_trace,
        "metadata": metadata,
    }


def run_stage4_theme_evaluation(
    stage2_artifacts: dict[str, Any],
    stage3_artifacts: dict[str, Any],
    settings: Settings,
    out_dir: str | Path,
) -> dict[str, Any]:
    """Stage 4: テーマ評価分解・ランキング・バックテストを実行する。"""
    stage_dir = _as_path(out_dir)

    ranking_history = build_ranking(
        stage2_artifacts["theme_daily_features"],
        stage3_artifacts["calibration_predictions"],
        stage3_artifacts["theme_returns"],
        settings,
    )
    backtest_returns, backtest_weights = run_backtest(
        ranking_history,
        stage3_artifacts["theme_returns"],
        settings,
    )
    performance_summary = compute_performance_summary(backtest_returns, ranking_history)

    save_parquet(ranking_history, stage_dir / "ranking_history.parquet")
    save_parquet(backtest_returns, stage_dir / "backtest_returns.parquet")
    save_parquet(backtest_weights, stage_dir / "backtest_weights.parquet")
    save_csv(performance_summary, stage_dir / "performance_summary.csv")

    return {
        "stage_dir": stage_dir,
        "ranking_history": ranking_history,
        "backtest_returns": backtest_returns,
        "backtest_weights": backtest_weights,
        "performance_summary": performance_summary,
    }
