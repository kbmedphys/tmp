from __future__ import annotations

import json
from typing import Tuple

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .config import Settings


def _stack_embeddings(embeddings: pd.Series) -> np.ndarray:
    arr = [np.asarray(v, dtype=float) for v in embeddings.tolist()]
    if not arr:
        return np.zeros((0, 0), dtype=float)
    return np.vstack(arr)


def _softmax(x: np.ndarray) -> np.ndarray:
    z = x - np.max(x, axis=1, keepdims=True)
    exp = np.exp(z)
    return exp / np.sum(exp, axis=1, keepdims=True)


def _top_terms_per_topic(texts: pd.Series, labels: np.ndarray, top_k: int = 8) -> dict[int, list[str]]:
    vectorizer = TfidfVectorizer(stop_words="english", min_df=1, max_df=0.9)
    matrix = vectorizer.fit_transform(texts)
    terms = np.asarray(vectorizer.get_feature_names_out())

    results: dict[int, list[str]] = {}
    for topic_id in sorted(set(labels.tolist())):
        idx = np.where(labels == topic_id)[0]
        if len(idx) == 0:
            results[int(topic_id)] = []
            continue
        scores = np.asarray(matrix[idx].mean(axis=0)).ravel()
        top_idx = np.argsort(scores)[::-1][:top_k]
        results[int(topic_id)] = terms[top_idx].tolist()
    return results


def fit_bertopic_like(
    article_df: pd.DataFrame,
    settings: Settings,
    n_topics: int = 8,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    df = article_df.copy()
    emb = _stack_embeddings(df["article_embedding"])

    if len(df) == 0:
        empty = pd.DataFrame(columns=["topic_id", "doc_count", "topic_keywords"])
        return df, empty, empty

    if len(df) == 1:
        df["topic_id"] = 0
        df["topic_probabilities"] = [json.dumps([1.0])]
    else:
        k = max(2, min(n_topics, len(df)))
        model = KMeans(n_clusters=k, random_state=settings.random_seed, n_init=10)
        labels = model.fit_predict(emb)
        distances = model.transform(emb)
        probs = _softmax(-distances)

        df["topic_id"] = labels
        df["topic_probabilities"] = [json.dumps(row.tolist()) for row in probs]

    top_terms = _top_terms_per_topic(df["clean_text"], df["topic_id"].to_numpy())
    topic_summary = (
        df.groupby("topic_id")
        .agg(doc_count=("article_id", "count"), representative_article=("article_id", "first"))
        .reset_index()
    )
    topic_summary["topic_keywords"] = topic_summary["topic_id"].map(
        lambda x: json.dumps(top_terms.get(int(x), []), ensure_ascii=False)
    )

    topic_dynamic = build_dynamic_topic_interface(df, settings)
    return df, topic_summary, topic_dynamic


def build_dynamic_topic_interface(article_topics: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    if article_topics.empty:
        return pd.DataFrame(columns=["bucket", "topic_id", "topic_share", "centroid_drift"])

    df = article_topics.copy()
    df["bucket"] = df["timestamp"].dt.to_period(settings.topic_time_bucket).dt.to_timestamp()

    emb = _stack_embeddings(df["article_embedding"])
    emb_df = pd.DataFrame({"idx": np.arange(len(df))})
    emb_df["embedding"] = [row for row in emb]
    emb_df["bucket"] = df["bucket"].values
    emb_df["topic_id"] = df["topic_id"].values

    counts = (
        df.groupby(["bucket", "topic_id"]).size().rename("doc_count").reset_index()
    )
    totals = df.groupby("bucket").size().rename("total_docs").reset_index()
    summary = counts.merge(totals, on="bucket", how="left")
    summary["topic_share"] = summary["doc_count"] / summary["total_docs"].replace(0, np.nan)

    centroids: dict[tuple[pd.Timestamp, int], np.ndarray] = {}
    for (bucket, topic_id), group in emb_df.groupby(["bucket", "topic_id"]):
        vectors = np.vstack(group["embedding"].tolist())
        centroids[(bucket, int(topic_id))] = vectors.mean(axis=0)

    drifts: list[float] = []
    for row in summary.itertuples(index=False):
        key = (row.bucket, int(row.topic_id))
        prev_bucket = row.bucket - pd.tseries.frequencies.to_offset(settings.topic_time_bucket)
        prev_key = (prev_bucket, int(row.topic_id))
        if prev_key not in centroids:
            drifts.append(0.0)
            continue
        cur = centroids[key].reshape(1, -1)
        prev = centroids[prev_key].reshape(1, -1)
        drift = 1.0 - float(cosine_similarity(cur, prev)[0, 0])
        drifts.append(max(drift, 0.0))

    summary["centroid_drift"] = drifts
    return summary[["bucket", "topic_id", "topic_share", "centroid_drift"]].sort_values(
        ["bucket", "topic_id"]
    )
