from __future__ import annotations

from typing import Dict, Iterable

import pandas as pd


REQUIRED_COLUMNS: Dict[str, Iterable[str]] = {
    "themes_master": ["theme_id", "theme_name", "theme_description"],
    "theme_holdings": ["date", "theme_id", "ticker", "weight"],
    "company_master": ["ticker", "company_name", "company_description", "sector", "country"],
    "news": ["article_id", "timestamp", "source", "title", "body", "language"],
    "prices": ["date", "ticker", "close"],
    "theme_returns": ["date", "theme_id", "theme_return"],
}

DATE_COLUMNS = {
    "theme_holdings": ["date"],
    "news": ["timestamp"],
    "prices": ["date"],
    "theme_returns": ["date"],
}


class SchemaError(ValueError):
    pass


def validate_required_columns(df: pd.DataFrame, table_name: str) -> None:
    required = set(REQUIRED_COLUMNS[table_name])
    missing = sorted(required - set(df.columns))
    if missing:
        raise SchemaError(
            f"{table_name} に必須列が不足しています: {missing}. "
            f"columns={list(df.columns)}"
        )


def coerce_dates(df: pd.DataFrame, table_name: str) -> pd.DataFrame:
    result = df.copy()
    for col in DATE_COLUMNS.get(table_name, []):
        result[col] = pd.to_datetime(result[col], utc=False, errors="coerce")
        if result[col].isna().any():
            bad_rows = result[result[col].isna()].index.tolist()[:5]
            raise SchemaError(
                f"{table_name}.{col} の日時変換に失敗しました. rows={bad_rows}"
            )
    return result


def validate_and_normalize_inputs(frames: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
    normalized: Dict[str, pd.DataFrame] = {}
    for name, df in frames.items():
        validate_required_columns(df, name)
        normalized[name] = coerce_dates(df, name)

    normalized["theme_holdings"]["weight"] = normalized["theme_holdings"]["weight"].astype(float)
    normalized["prices"]["close"] = normalized["prices"]["close"].astype(float)
    if "theme_returns" in normalized:
        normalized["theme_returns"]["theme_return"] = normalized["theme_returns"]["theme_return"].astype(float)

    return normalized
