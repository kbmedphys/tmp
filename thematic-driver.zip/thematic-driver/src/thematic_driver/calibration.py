from __future__ import annotations

import json
from typing import Dict, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import ElasticNet, Lasso, Ridge
from sklearn.metrics import mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .config import Settings


def resolve_theme_returns(
    prices: pd.DataFrame,
    theme_holdings: pd.DataFrame,
    theme_returns: pd.DataFrame | None = None,
) -> pd.DataFrame:
    if theme_returns is not None and not theme_returns.empty:
        out = theme_returns.copy()
        out["date"] = pd.to_datetime(out["date"]).dt.normalize()
        return out[["date", "theme_id", "theme_return"]].sort_values(["date", "theme_id"])

    px = prices.copy()
    px["date"] = pd.to_datetime(px["date"]).dt.normalize()
    px = px.sort_values(["ticker", "date"]).reset_index(drop=True)
    px["stock_return"] = px.groupby("ticker")["close"].pct_change()

    th = theme_holdings.copy()
    th["date"] = pd.to_datetime(th["date"]).dt.normalize()
    th = th.sort_values(["theme_id", "ticker", "date"]).reset_index(drop=True)

    weighted_rows: list[pd.DataFrame] = []
    for (theme_id, ticker), h_group in th.groupby(["theme_id", "ticker"]):
        p_group = px[px["ticker"] == ticker][["date", "ticker", "stock_return"]].sort_values("date")
        if p_group.empty:
            continue
        merged = pd.merge_asof(
            p_group,
            h_group[["date", "weight"]].sort_values("date"),
            on="date",
            direction="backward",
        )
        merged["theme_id"] = theme_id
        merged["weight"] = merged["weight"].fillna(0.0)
        weighted_rows.append(merged)

    if not weighted_rows:
        return pd.DataFrame(columns=["date", "theme_id", "theme_return"])

    weighted = pd.concat(weighted_rows, ignore_index=True)
    weighted = weighted.dropna(subset=["stock_return"])

    denom = weighted.groupby(["date", "theme_id"]) ["weight"].transform("sum").replace(0, np.nan)
    weighted["weight_norm"] = weighted["weight"] / denom
    weighted["weighted_return"] = weighted["weight_norm"] * weighted["stock_return"]

    out = (
        weighted.groupby(["date", "theme_id"], as_index=False)["weighted_return"]
        .sum()
        .rename(columns={"weighted_return": "theme_return"})
        .dropna()
        .sort_values(["date", "theme_id"])
    )
    return out


def _forward_cum_return(values: np.ndarray, horizon: int) -> np.ndarray:
    out = np.full(len(values), np.nan, dtype=float)
    for i in range(len(values)):
        end = i + horizon
        if end >= len(values):
            continue
        window = values[i + 1 : end + 1]
        if np.isnan(window).any():
            continue
        out[i] = float(np.prod(1.0 + window) - 1.0)
    return out


def build_calibration_targets(theme_returns: pd.DataFrame) -> pd.DataFrame:
    df = theme_returns.copy().sort_values(["theme_id", "date"]).reset_index(drop=True)

    for horizon, col in [(1, "next_day_relative_return"), (5, "next_week_relative_return"), (21, "next_month_relative_return")]:
        fwd_col = f"fwd_{horizon}"
        df[fwd_col] = (
            df.groupby("theme_id")["theme_return"]
            .transform(lambda s: _forward_cum_return(s.to_numpy(dtype=float), horizon))
        )
        mean_cross = df.groupby("date")[fwd_col].transform("mean")
        df[col] = df[fwd_col] - mean_cross

    df["next_day_vol"] = (
        df.groupby("theme_id")["theme_return"].transform(lambda s: s.rolling(5, min_periods=3).std().shift(-1))
    )
    df["next_week_vol"] = (
        df.groupby("theme_id")["theme_return"].transform(lambda s: s.rolling(20, min_periods=5).std().shift(-5))
    )
    df["next_week_breadth"] = (
        df.groupby("date")["theme_return"].transform(lambda s: (s > 0).mean()).shift(-5)
    )

    keep_cols = [
        "date",
        "theme_id",
        "theme_return",
        "next_day_relative_return",
        "next_week_relative_return",
        "next_month_relative_return",
        "next_day_vol",
        "next_week_vol",
        "next_week_breadth",
    ]
    return df[keep_cols]


def _get_models(settings: Settings) -> Dict[str, object]:
    random_state = settings.random_seed
    return {
        "ridge": Ridge(alpha=1.0),
        "lasso": Lasso(alpha=0.001, random_state=random_state, max_iter=5000),
        "elasticnet": ElasticNet(alpha=0.001, l1_ratio=0.5, random_state=random_state, max_iter=5000),
    }


def run_calibration(
    theme_daily_features: pd.DataFrame,
    targets: pd.DataFrame,
    settings: Settings,
    return_training_trace: bool = False,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame] | Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    dataset = theme_daily_features.merge(targets, on=["date", "theme_id"], how="left")

    excluded = {
        "theme_id",
        "date",
        "topic_distribution",
        "next_day_relative_return",
        "next_week_relative_return",
        "next_month_relative_return",
        "next_day_vol",
        "next_week_vol",
        "next_week_breadth",
        "dominant_topic",
    }
    feature_cols = [
        col
        for col in dataset.columns
        if col not in excluded and pd.api.types.is_numeric_dtype(dataset[col])
    ]
    dataset = dataset.sort_values("date").reset_index(drop=True)

    if not feature_cols:
        return pd.DataFrame(), pd.DataFrame(), dataset

    models = _get_models(settings)
    prediction_rows: list[dict] = []
    coef_rows: list[dict] = []
    training_trace_rows: list[dict] = []

    unique_dates = sorted(dataset["date"].dropna().unique().tolist())
    target_col = settings.calibration_target

    for pred_date in unique_dates:
        train = dataset[dataset["date"] < pred_date]
        if settings.training_mode == "rolling":
            start = pd.Timestamp(pred_date) - pd.Timedelta(days=settings.train_window_days)
            train = train[train["date"] >= start]

        train = train.dropna(subset=[target_col])
        pred_slice = dataset[dataset["date"] == pred_date]
        if train.empty or len(train) < max(30, len(feature_cols) * 2) or pred_slice.empty:
            continue

        training_trace_rows.append(
            {
                "pred_date": pd.Timestamp(pred_date),
                "train_start": pd.Timestamp(train["date"].min()),
                "train_end": pd.Timestamp(train["date"].max()),
                "n_train": int(len(train)),
            }
        )

        x_train = train[feature_cols].fillna(0.0)
        y_train = train[target_col].astype(float)
        x_pred = pred_slice[feature_cols].fillna(0.0)

        for model_name, model in models.items():
            pipe = Pipeline([("scaler", StandardScaler()), ("model", model)])
            pipe.fit(x_train, y_train)
            y_hat = pipe.predict(x_pred)

            final_model = pipe.named_steps["model"]
            if hasattr(final_model, "coef_"):
                coef_rows.append(
                    {
                        "date": pred_date,
                        "model_name": model_name,
                        "coef": json.dumps(
                            {feature_cols[i]: float(v) for i, v in enumerate(final_model.coef_)},
                            ensure_ascii=False,
                        ),
                    }
                )

            for row, pred in zip(pred_slice.itertuples(index=False), y_hat):
                prediction_rows.append(
                    {
                        "date": row.date,
                        "theme_id": row.theme_id,
                        "model_name": model_name,
                        "predicted_relative_return": float(pred),
                        "actual_relative_return": float(row.__getattribute__(target_col))
                        if pd.notna(row.__getattribute__(target_col))
                        else np.nan,
                    }
                )

    predictions = pd.DataFrame(prediction_rows)
    coef_df = pd.DataFrame(coef_rows)
    training_trace = pd.DataFrame(training_trace_rows)
    if not training_trace.empty:
        training_trace = (
            training_trace.drop_duplicates(subset=["pred_date"])
            .sort_values("pred_date")
            .reset_index(drop=True)
        )

    if predictions.empty:
        if return_training_trace:
            return predictions, pd.DataFrame(), dataset, training_trace
        return predictions, pd.DataFrame(), dataset

    diagnostics_rows: list[dict] = []
    for model_name, group in predictions.groupby("model_name"):
        valid = group.dropna(subset=["actual_relative_return"])
        if valid.empty:
            continue
        mse = mean_squared_error(valid["actual_relative_return"], valid["predicted_relative_return"])
        mae = float(np.abs(valid["actual_relative_return"] - valid["predicted_relative_return"]).mean())

        rank_ic_by_date = []
        for _, day_group in valid.groupby("date"):
            if day_group["theme_id"].nunique() < 2:
                continue
            corr = day_group["predicted_relative_return"].corr(
                day_group["actual_relative_return"], method="spearman"
            )
            if pd.notna(corr):
                rank_ic_by_date.append(float(corr))

        top_features = "{}"
        coef_valid = coef_df[coef_df["model_name"] == model_name]
        if not coef_valid.empty:
            agg: dict[str, list[float]] = {}
            for payload in coef_valid["coef"]:
                data = json.loads(payload)
                for k, v in data.items():
                    agg.setdefault(k, []).append(abs(float(v)))
            ranked = sorted(((k, float(np.mean(v))) for k, v in agg.items()), key=lambda x: x[1], reverse=True)
            top_features = json.dumps(dict(ranked[:10]), ensure_ascii=False)

        diagnostics_rows.append(
            {
                "model_name": model_name,
                "n_predictions": int(len(valid)),
                "mse": float(mse),
                "mae": float(mae),
                "rank_ic": float(np.mean(rank_ic_by_date)) if rank_ic_by_date else np.nan,
                "top_features": top_features,
            }
        )

    diagnostics = pd.DataFrame(diagnostics_rows)
    if return_training_trace:
        return predictions, diagnostics, dataset, training_trace
    return predictions, diagnostics, dataset
