from __future__ import annotations

from collections import defaultdict

import numpy as np
import pandas as pd

from .config import Settings


WEEKDAY_MAP = {
    "MON": 0,
    "TUE": 1,
    "WED": 2,
    "THU": 3,
    "FRI": 4,
    "SAT": 5,
    "SUN": 6,
}


def _rebalance_dates(dates: list[pd.Timestamp], freq: str) -> list[pd.Timestamp]:
    if not dates:
        return []
    if freq == "D":
        return dates

    if freq.startswith("W-"):
        key = freq.split("-")[-1].upper()
        weekday = WEEKDAY_MAP.get(key, 4)
        picked = [d for d in dates if d.weekday() == weekday]
        if picked:
            return picked
        # fallback: 週ごとの最終営業日
        df = pd.DataFrame({"date": dates})
        df["week"] = df["date"].dt.to_period("W")
        return df.groupby("week")["date"].max().tolist()

    if freq.startswith("M"):
        df = pd.DataFrame({"date": dates})
        df["month"] = df["date"].dt.to_period("M")
        return df.groupby("month")["date"].max().tolist()

    return dates


def _resolve_execution_date(
    trade_dates: list[pd.Timestamp],
    signal_date: pd.Timestamp,
    lag: int,
) -> pd.Timestamp | None:
    candidates = [d for d in trade_dates if d >= signal_date]
    if not candidates:
        return None
    idx = min(lag, len(candidates) - 1)
    return candidates[idx]


def run_backtest(
    ranking_history: pd.DataFrame,
    theme_returns: pd.DataFrame,
    settings: Settings,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if ranking_history.empty or theme_returns.empty:
        return pd.DataFrame(), pd.DataFrame()

    trade_dates = sorted(pd.to_datetime(theme_returns["date"]).dt.normalize().unique().tolist())
    signal_dates_all = sorted(pd.to_datetime(ranking_history["date"]).dt.normalize().unique().tolist())
    signal_dates = _rebalance_dates(signal_dates_all, settings.rebal_freq)

    weight_rows: list[dict] = []
    turnover_map: dict[pd.Timestamp, float] = defaultdict(float)

    prev_weights: dict[str, float] = {}
    execution_schedule: list[tuple[pd.Timestamp, pd.Timestamp | None, list[str]]] = []

    for signal_date in signal_dates:
        selected = (
            ranking_history[ranking_history["date"] == signal_date]
            .sort_values(["rank", "theme_id"])
            .head(settings.top_n)["theme_id"]
            .tolist()
        )
        if not selected:
            continue

        exec_date = _resolve_execution_date(trade_dates, signal_date, settings.exec_lag)
        if exec_date is None:
            continue
        execution_schedule.append((signal_date, exec_date, selected))

    for i, (signal_date, exec_date, selected) in enumerate(execution_schedule):
        if i + 1 < len(execution_schedule):
            next_exec_date = execution_schedule[i + 1][1]
            hold_dates = [d for d in trade_dates if exec_date <= d < next_exec_date]
        else:
            hold_dates = [d for d in trade_dates if d >= exec_date]

        w = 1.0 / len(selected)
        new_weights = {theme_id: w for theme_id in selected}

        turnover = 0.5 * sum(
            abs(new_weights.get(theme_id, 0.0) - prev_weights.get(theme_id, 0.0))
            for theme_id in set(new_weights) | set(prev_weights)
        )
        turnover_map[pd.Timestamp(exec_date)] = float(turnover)
        prev_weights = new_weights

        for date in hold_dates:
            for theme_id, weight in new_weights.items():
                weight_rows.append(
                    {
                        "date": pd.Timestamp(date),
                        "theme_id": theme_id,
                        "weight": float(weight),
                        "signal_date": pd.Timestamp(signal_date),
                        "execution_date": pd.Timestamp(exec_date),
                    }
                )

    weights_df = pd.DataFrame(weight_rows)
    if weights_df.empty:
        return pd.DataFrame(), pd.DataFrame()

    returns = theme_returns.copy()
    returns["date"] = pd.to_datetime(returns["date"]).dt.normalize()

    joined = weights_df.merge(returns, on=["date", "theme_id"], how="left")
    joined["weighted_theme_return"] = joined["weight"] * joined["theme_return"].fillna(0.0)
    daily = (
        joined.groupby("date", as_index=False)["weighted_theme_return"]
        .sum()
        .rename(columns={"weighted_theme_return": "portfolio_return"})
    )

    benchmark = returns.groupby("date", as_index=False)["theme_return"].mean().rename(
        columns={"theme_return": "benchmark_return"}
    )
    daily = daily.merge(benchmark, on="date", how="left")

    daily["turnover"] = daily["date"].map(lambda d: turnover_map.get(pd.Timestamp(d), 0.0)).fillna(0.0)
    cost_rate = (settings.fee_bps + settings.slippage_bps) / 10000.0
    daily["cost"] = daily["turnover"] * cost_rate
    daily["net_return"] = daily["portfolio_return"] - daily["cost"]

    daily = daily.sort_values("date")
    daily["cumulative_return"] = (1.0 + daily["net_return"].fillna(0.0)).cumprod() - 1.0
    daily["cumulative_benchmark"] = (1.0 + daily["benchmark_return"].fillna(0.0)).cumprod() - 1.0

    return daily, weights_df
