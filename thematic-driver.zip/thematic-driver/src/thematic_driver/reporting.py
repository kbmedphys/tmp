from __future__ import annotations

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from .config import Settings
from .io import save_csv


def _save_cumulative_returns(backtest_returns: pd.DataFrame, path: str) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(backtest_returns["date"], backtest_returns["cumulative_return"], label="Strategy")
    ax.plot(backtest_returns["date"], backtest_returns["cumulative_benchmark"], label="Benchmark")
    ax.set_title("Cumulative Returns")
    ax.set_xlabel("Date")
    ax.set_ylabel("Return")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _save_theme_rank_heatmap(ranking_history: pd.DataFrame, path: str) -> None:
    pivot = ranking_history.pivot_table(index="date", columns="theme_id", values="rank", aggfunc="first")
    fig, ax = plt.subplots(figsize=(11, 6))
    sns.heatmap(pivot, cmap="viridis_r", ax=ax)
    ax.set_title("Theme Rank Heatmap")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _save_topic_drift(theme_daily_features: pd.DataFrame, path: str) -> None:
    pivot = theme_daily_features.pivot_table(
        index="date", columns="theme_id", values="topic_drift", aggfunc="mean"
    ).fillna(0.0)
    fig, ax = plt.subplots(figsize=(11, 6))
    sns.heatmap(pivot, cmap="magma", ax=ax)
    ax.set_title("Topic Drift by Theme")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _save_driver_contribution(driver_scores: pd.DataFrame, path: str) -> pd.DataFrame:
    if driver_scores.empty:
        empty = pd.DataFrame(columns=["theme_id", "driver_name", "driver_group", "avg_driver_score"])
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.set_title("Driver Contribution by Theme")
        fig.tight_layout()
        fig.savefig(path, dpi=150)
        plt.close(fig)
        return empty

    table = (
        driver_scores.groupby(["theme_id", "driver_name", "driver_group"], as_index=False)["driver_score"]
        .mean()
        .rename(columns={"driver_score": "avg_driver_score"})
        .sort_values("avg_driver_score", ascending=False)
    )

    top = table.head(15)
    fig, ax = plt.subplots(figsize=(12, 6))
    sns.barplot(data=top, x="avg_driver_score", y="driver_name", hue="theme_id", ax=ax)
    ax.set_title("Driver Contribution by Theme")
    ax.set_xlabel("Average Driver Score")
    ax.set_ylabel("Driver")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return table


def _save_rolling_sharpe(backtest_returns: pd.DataFrame, path: str) -> None:
    rolling = (
        backtest_returns["net_return"].rolling(20, min_periods=5).mean()
        / backtest_returns["net_return"].rolling(20, min_periods=5).std()
    ) * (252**0.5)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(backtest_returns["date"], rolling)
    ax.set_title("Rolling Sharpe (20d)")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _save_rolling_ic(ranking_history: pd.DataFrame, path: str) -> None:
    rows = []
    if "actual_relative_return" in ranking_history.columns:
        for date, group in ranking_history.groupby("date"):
            corr = group["final_score"].corr(group["actual_relative_return"], method="spearman")
            rows.append({"date": date, "rank_ic": corr})
    ic = pd.DataFrame(rows)

    fig, ax = plt.subplots(figsize=(10, 5))
    if not ic.empty:
        ax.plot(ic["date"], ic["rank_ic"])
    ax.set_title("Rolling IC")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _save_crowding_vs_future_return(ranking_history: pd.DataFrame, path: str) -> None:
    fig, ax = plt.subplots(figsize=(7, 6))
    if "actual_relative_return" in ranking_history.columns:
        ax.scatter(
            ranking_history["crowding_penalty"],
            ranking_history["actual_relative_return"],
            alpha=0.4,
        )
    ax.set_title("Crowding vs Future Return")
    ax.set_xlabel("Crowding Penalty")
    ax.set_ylabel("Actual Relative Return")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def generate_reports(
    backtest_returns: pd.DataFrame,
    ranking_history: pd.DataFrame,
    theme_daily_features: pd.DataFrame,
    driver_scores: pd.DataFrame,
    model_diagnostics: pd.DataFrame,
    performance_summary: pd.DataFrame,
    settings: Settings,
) -> pd.DataFrame:
    settings.ensure_directories()

    cumulative_path = settings.outputs_figures_dir / "cumulative_returns.png"
    heatmap_path = settings.outputs_figures_dir / "theme_rank_heatmap.png"
    topic_drift_path = settings.outputs_figures_dir / "topic_drift_by_theme.png"
    driver_contrib_path = settings.outputs_figures_dir / "driver_contribution_by_theme.png"

    _save_cumulative_returns(backtest_returns, str(cumulative_path))
    _save_theme_rank_heatmap(ranking_history, str(heatmap_path))
    _save_topic_drift(theme_daily_features, str(topic_drift_path))
    driver_table = _save_driver_contribution(driver_scores, str(driver_contrib_path))

    _save_rolling_sharpe(backtest_returns, str(settings.outputs_figures_dir / "rolling_sharpe.png"))
    _save_rolling_ic(ranking_history, str(settings.outputs_figures_dir / "rolling_ic.png"))
    _save_crowding_vs_future_return(
        ranking_history, str(settings.outputs_figures_dir / "crowding_vs_future_return.png")
    )

    save_csv(performance_summary, settings.outputs_tables_dir / "performance_summary.csv")
    save_csv(ranking_history, settings.outputs_tables_dir / "ranking_history.csv")
    save_csv(driver_table, settings.outputs_tables_dir / "driver_scores_per_theme.csv")
    save_csv(model_diagnostics, settings.outputs_tables_dir / "model_diagnostics.csv")

    return driver_table
