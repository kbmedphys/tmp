# IMPLEMENTATION_INSTRUCTIONS.md
# 使い方と運用手順

## 1. この3ファイルの役割

### 1.1 SPEC.md
設計仕様書です。
何を作るのか、どこまでを初版スコープにするのか、入出力、モジュール構成、特徴量、評価方法を定義します。

用途:
- プロジェクトの要件確定
- 後から仕様確認
- Codex の実装判断の基準
- 追加改修時の参照元

### 1.2 CODEX_EXECUTION_PROMPT.md
Codex に最初に渡す実行プロンプトです。
SPEC を前提に、何から着手し、何を作り、何を保存し、どの順で実装するかを明示しています。

用途:
- Codex への初回指示
- 実装着手時のブリーフ
- 仕様逸脱防止

### 1.3 IMPLEMENTATION_INSTRUCTIONS.md
人間側の運用手順書です。
このプロジェクトをどう立ち上げ、どのファイルをどの順に使い、Codex にどう投げるかを説明します。

用途:
- あなた自身の進行管理
- 将来の再開時のメモ
- 他案件への横展開テンプレート

---

## 2. 推奨ディレクトリ配置

以下のように配置してください。

```text
~/workspace/projects/<project_name>/
├─ AGENTS.md
├─ README.md
├─ SPEC.md
├─ CODEX_EXECUTION_PROMPT.md
├─ IMPLEMENTATION_INSTRUCTIONS.md
├─ docs/
│  ├─ sources/
│  └─ notes/
├─ src/<project_name>/
├─ notebooks/
├─ data/
│  ├─ raw/
│  └─ processed/
└─ outputs/
   ├─ figures/
   ├─ tables/
   └─ logs/
```

---

## 3. 実際の使い方

### Step 1: 新規プロジェクトを作る

例:

```bash
mkdir -p ~/workspace/projects/news-driven-theme-rotation
cd ~/workspace/projects/news-driven-theme-rotation
```

必要ディレクトリを作ります。

```bash
mkdir -p docs/sources docs/notes src/news_driven_theme_rotation notebooks data/raw data/processed outputs/figures outputs/tables outputs/logs
```

### Step 2: 3ファイルを配置する

この会話で作成した以下をプロジェクト直下へ置きます。

- SPEC.md
- CODEX_EXECUTION_PROMPT.md
- IMPLEMENTATION_INSTRUCTIONS.md

### Step 3: AGENTS.md を確認する

workspace/AGENTS.md と project 配下の AGENTS.md がある場合は、両方確認します。
特に以下を確認してください。

- 使用する Python 環境
- 依存管理方法
- 出力先ルール
- 実装粒度
- 日本語説明ルール

### Step 4: Codex をプロジェクト直下で起動する

Codex は必ずそのプロジェクトディレクトリで起動します。

### Step 5: 最初に渡すもの

Codex には、まず CODEX_EXECUTION_PROMPT.md の全文を渡します。
同時に、
「SPEC.md を読んだうえで、notes を整備し、Phase 1 を実装してください」
と付けると通りやすいです。

推奨入力例:

```text
まず workspace/AGENTS.md とこのプロジェクトの SPEC.md を読んでください。
その上で CODEX_EXECUTION_PROMPT.md の指示に従って、
Phase 1 の実装を進めてください。
最初に docs/notes/00_doc_index.md, 10_requirements.md, 20_assumptions.md, 30_plan.md を作成し、
その後 src と notebooks/main.ipynb を実装してください。
```

### Step 6: 最初に確認すべき Codex の出力

Codex から最初に返ってきたら、以下を確認します。

- notes が作られているか
- main.ipynb 前提で設計しているか
- src の責務分割が SPEC に沿っているか
- leakage-free を明示しているか
- 初版スコープを勝手に広げていないか

### Step 7: 実装の進め方

おすすめは次の順です。

1. notes 整備
2. config / schema / io
3. theme_definition
4. news_features
5. event_mapping
6. topic_models
7. theme_aggregation
8. calibration
9. ranking
10. backtest
11. reporting
12. notebook 統合

---

## 4. どう使い分けるか

### SPEC.md を使う場面

- 仕様を確認したいとき
- 実装がズレていないかチェックするとき
- 新機能追加時に影響範囲を整理するとき
- 他案件へ流用するとき

### CODEX_EXECUTION_PROMPT.md を使う場面

- Codex の初回起動時
- 作業が脱線したので軌道修正したいとき
- 別セッションで続きから再開するとき

### IMPLEMENTATION_INSTRUCTIONS.md を使う場面

- 手順を忘れたとき
- 新しいプロジェクトで再利用するとき
- 他人に引き継ぐとき

---

## 5. Codex に対する実践的な追加指示例

### 5.1 まず Phase 1 だけやらせる

```text
Phase 1 のみ実装してください。
厳密な D-ETM や本格LLM抽出は不要です。
SPEC.md の初版スコープに限定してください。
```

### 5.2 notebooks/main.ipynb を主導にする

```text
実装は notebooks/main.ipynb から end-to-end で再現できるようにしてください。
src 配下は notebook から呼び出す構成にしてください。
```

### 5.3 notes を先に埋めさせる

```text
コードを書く前に docs/notes/10_requirements.md, 20_assumptions.md, 30_plan.md を作成し、
実装方針を明文化してください。
```

### 5.4 後で D-ETM を拡張したい場合

```text
今回は dynamic topic interface まででよく、厳密な D-ETM 再現は不要です。
将来差し替えできる抽象 interface を残してください。
```

---

## 6. よくある失敗

### 6.1 いきなり重いモデルを入れる
初版で D-ETM 厳密実装や LLM 多段推論に行くと、研究基盤が不安定になりやすいです。
まずは article embedding, rule-based event, BERTopic-like pipeline, linear calibration で土台を作る方がよいです。

### 6.2 テーマ名マッチングに寄りすぎる
AI や低PBRのようなテーマでは、ニュース本文にその語が出なくてもドライバーは観測できます。
テーマ名一致ではなく、driver mapping を主軸にします。

### 6.3 ニュース件数ランキングになる
記事数だけが強いテーマを上位にしてしまうと hype を買いやすいです。
novelty, source quality, crowding penalty を必ず入れてください。

### 6.4 leakage が入る
standardization, topic assignment, training window, target shift のどこかで将来情報が混入しやすいです。
main.ipynb で chronology を明示してください。

---

## 7. 推奨ワークフロー

### 7.1 最初の1回
- SPEC を置く
- Prompt を置く
- Codex に Prompt を渡す
- notes を確認する
- Phase 1 実装を進める

### 7.2 2回目以降
- IMPLEMENTATION_INSTRUCTIONS.md を見て再開
- 必要なら Prompt を再送
- 追加要件は SPEC に追記
- その差分だけ Codex に実装させる

### 7.3 仕様変更時
- まず SPEC.md を更新
- その後、Codex には「SPEC 更新箇所のみ反映してください」と伝える

---

## 8. あなた向けの現実的な進め方

この案件では、次の順番が最も安定します。

1. Phase 1 を完成させる
2. 単純 news count と比較して差が出るか確認する
3. driver library を人手で磨く
4. crowding / stretch を強化する
5. その後に D-ETM や LLM event extraction を追加する

最初からフル装備にせず、
**再現可能な研究基盤 → 解釈可能な特徴量 → 校正 → 拡張**
の順で進めてください。

---

## 9. 最後に

この3ファイルの基本的な役割は次の通りです。

- SPEC.md: 何を作るか
- CODEX_EXECUTION_PROMPT.md: Codex に何をやらせるか
- IMPLEMENTATION_INSTRUCTIONS.md: あなたがどう使うか

この3点セットを毎回プロジェクト直下に置いておくと、
新規案件でもかなり安定して進められます。
