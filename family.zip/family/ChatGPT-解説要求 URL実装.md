# 解説要求 URL実装

**User:** Anonymous  
**Created:** 7/27/2026 21:06:58  
**Updated:** 7/29/2026 0:17:32  
**Exported:** 7/29/2026 0:19:41  
**Link:** [https://chatgpt.com/c/6a6749e1-049c-83ee-8937-a30a66c224d6](https://chatgpt.com/c/6a6749e1-049c-83ee-8937-a30a66c224d6)  

## Response:
2026/7/27 21:06:58

> **ウェブを検索中**
>
>
> **github.com を検索**
>
> 
>
> **GitHubリポジトリのクローンと検索**
>
>
> **クローンしGitHubリポジトリを検索した**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **ウェブを検索中**
>
>
> **github.com を検索**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **Searching for raw GitHub file links**
>
> [GitHub - Ashwin-kumar-0309/AI-Storytelling-Engine-with-Multi-Character-Narratives: Interactive AI-powered storytelling platform with dual protagonists, contextual choice generation, and persistent character management using Llama 3.1 and Streamlit · GitHub](https://github.com/Ashwin-kumar-0309/AI-Storytelling-Engine-with-Multi-Character-Narratives)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **ウェブを検索中**
>
>
> **eliteai.tools を検索**
>
> 
>
> **PDFスキルの読み取り**
>
>
> **読み取ったPDFスキル**
>
> 
>
> **ウェブを検索中**
>
>
> **nvlabs.github.io を検索**
>
> 
>
> **GitHub APIへの接続確認**
>
>
> **確認したGitHub APIへの接続**
>
> 
>
> **ウェブを検索中**
>
> [GitHub - briankeithn/narrative-maps: Narrative Maps Visualization Tool · GitHub](https://github.com/briankeithn/narrative-maps)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **GitHubリポジトリの情報検索**
>
> [Gitingest](https://gitingest.com/)
> [GitHub - TrelisResearch/trelis-gitingest-mcp: An MCP Server for analysing Github Repo Content with Gitingest · GitHub](https://github.com/TrelisResearch/trelis-gitingest-mcp)
> [Traffico del sito web gitingest.com, ranking, analisi [aprile 2026]](https://it.semrush.com/website/gitingest.com/overview/)
> [GitIngest - Prompt-friendly Codebase](https://gitingestzip.com/)
> [gitingest-mcp](https://www.codelibrary.ai/mcp/gitingest-mcp)
> [gitinjest - AI Agent skill](https://eliteai.tools/agent-skills/gitinjest)
> [gitingest · PyPI](https://pypi.org/project/gitingest/)
> [gitingest.com Website Traffic, Ranking, Analytics [May 2026]](https://www.semrush.com/website/gitingest.com/overview/)
> [Gitingest-MCP](https://himcp.ai/server/gitingest-mcp)
> [gitingest.com Tráfico Web, Ranking, Analítica [abril de 2026]](https://es.semrush.com/website/gitingest.com/overview/)
> [narumiruna/gitingest-mcp — MCP Servers · Directories by Enterprise DNA](https://enterprisedna.co/directories/mcp/narumiruna-gitingest-mcp/)
> [Jupyterhub source code compiled by https://gitingest.com/ · GitHub](https://gist.github.com/ptdtan/359cc88c3c73e5143aefa8d530dda3b8)
> [GitIngest](https://www.aitoolnet.com/gitingest)
>
> **13件のウェブサイトを検索しました**
>
> 
>
> **ネットワーク環境のプロキシ設定確認**
>
>
> **確認したネットワークのプロキシ設定とポート経由**
>
> 
>
> **GitHubでのファイルダウンロード方法を検索**
>
> [RepoMapr - Visualize GitHub Repositories](https://www.repomapr.com/)
> [Agenda-based Narrative Extraction: Steering Pathfinding Algorithms with Large Language Models](https://arxiv.org/abs/2603.29661)
> [GitGPS — Navigate Any GitHub Codebase Instantly](https://gitgps.com/)
> [narrativegraphs · PyPI](https://pypi.org/project/narrativegraphs/)
> [GitHub - knaidoo29/mistree: A python package for constructing and analysing minimum spanning trees. · GitHub](https://github.com/knaidoo29/mistree)
> [Navigator | Narrative](https://docs.narrativetools.io/pro/navigator/)
>
> **6件のウェブサイトを検索しました**
>
> 
>
> **DNS接続のテスト**
>
>
> **テストしたDNS接続**
>
> 
>
> **Searching for SoftwareX code archives and repositories**
>
> [Supplementary Materials: Semantic Interaction for Narrative Map Sensemaking | Zenodo](https://zenodo.org/records/18930805)
> [(PDF) Semantic Interaction for Narrative Map Sensemaking: An Insight-based Evaluation](https://www.researchgate.net/publication/403379832_Semantic_Interaction_for_Narrative_Map_Sensemaking_An_Insight-based_Evaluation)
> [ナラティブマップ可視化ツール(NMVT):ナラティブマップフレームワークに基づく対話型ナラティブ分析システム〖JST機械翻訳〗 | 文献情報 | J-GLOBAL 科学技術総合リンクセンター](https://jglobal.jst.go.jp/public/202602227091061478)
> [Design guidelines for narrative maps in sensemaking tasks](https://ouci.dntb.gov.ua/en/works/9JpaGwD4/)
> [components.mesh.eco — the Mutual Component Library](https://components.mesh.eco/)
> [Quantum Kernels for Narrative Coherence: An Application to Path Optimization in Document Graphs for Storyline Extraction](https://www.mdpi.com/2227-7390/14/10/1734)
> [dblp: Brian Keith](https://dblp.org/pid/214/2392)
> [RecallNest MCP server — install in Claude, Cursor & VS Code — Unyly](https://unyly.org/mcp/recallnest)
> [Qyvaria OS Download — All Release Files + Repository Files + Wikipedia](https://qyvaria1ai.neocities.org/)
> [Hu Xiuhan](https://huxiuhan.com/)
> [itilme.com — Portfolio + Knowledgebase](https://www.itilme.com/)
> [SendToSelf Archive](https://sendtoself.dev/)
> [jnthnlstr -](https://jnthnlstr.tiddlyspot.com/)
>
> **13件のウェブサイトを検索しました**
>
> 
>
> **Testing GitHub IP connectivity via curl**
>
>
> **Tested GitHub IP connectivity via curl**
>
> 
>
> **GitHubコードリポジトリ検索とアクセス**
>
> [GitHub - FlashML-org/flashlib: Fast and memory-efficient classical machine learning operators · GitHub](https://github.com/FlashML-org/flashlib)
> [Linear Programming Solving problem using constraints · GitHub](https://gist.github.com/97harsh/e49f3d3415644bd645d561aa845463a8)
>
> **2件のウェブサイトを検索しました**
>
> 
>
> **Reading PDF skill**
>
>
> **読んでPDFをレンダリングしページを分析した**
>
> 
>
> **画像サイズの確認とクロップ**
>
>
> **確認し画像をクロップした**
>
> 
>
> **Pythonツールで画像処理**
>
>
> 35m 28s考えました

# 全体像

添付論文 **“Narrative Maps: An Algorithmic Approach to Represent and Extract Information Narratives”** は、時系列文書群から「複数の相互接続したストーリーライン」を抽出し、重み付き有向非巡回グラフとして表現する方法を提案しています。中心的な貢献は、ナラティブ理論とグラフ理論の対応付け、coherence 最大化と topic coverage を組み合わせた線形計画、そして main route と representative landmarks の抽出です。`2009.04508v2.pdf`

一方、指定された GitHub の `main` ブランチは、2020年論文のコードをそのまま保存したものではなく、**Narrative Maps Visualization Tool 2.1.0** という対話型システムへ発展した現行版です。2020年論文が基本表現と抽出アルゴリズムを扱うのに対し、現行版は Dash/Cytoscape によるUI、semantic interaction、entity-based connection、SHAPによる説明などを追加しています。([github.com](https://github.com/briankeithn/narrative-maps?utm_source=chatgpt.com), [researchgate.net](https://www.researchgate.net/publication/397596644_Narrative_Maps_Visualization_Tool_NMVT_An_interactive_narrative_analytics_system_based_on_the_narrative_maps_framework?utm_source=chatgpt.com))

確認した範囲は、GitHub `main` のディレクトリ構成、README、TUTORIAL、依存関係、SoftwareX掲載時の固定リポジトリ、および2025年のSoftwareX論文です。GitHub側のキャッシュ制約により巨大な `NMVT.py` 本体を行単位で取得できなかったため、以下では、

- **2020年論文部分**：論文の図2・数式から再構成した clean-room 実装仕様
- **現行GitHub部分**：著者のREADME、TUTORIAL、SoftwareX論文に明記された実装仕様

として区別します。内部関数名や未公開の細かな定数は推測していません。

---

# 1. Narrative Map の計算表現

## 1.1 ナラティブ理論とグラフ理論の対応

論文では、ナラティブを単なる時系列リストではなく、**interrelated stories の system** と定義します。対応関係は次のようになります。

| ナラティブ理論 | グラフ表現 | Route map metaphor | 実装上の意味 |
|---|---|---|---|
| Event | node | landmark | ニュース記事などの時点付きイベント |
| Discourse element | node attribute | landmark attribute | 媒体、URL、信頼性、バイアス等 |
| Starting event | source | starting place | 入次数0の開始ノード |
| Ending event | sink | ending place | 出次数0の終了ノード |
| Story | path / chain | route | 時系列に沿うイベント列 |
| Coherence | edge weight | route evaluation metric | 2イベントを接続する自然さ |
| Constituent events | maximum-likelihood chain | main route | 中心ストーリーのイベント |
| Supplementary events | maximum antichain | representative landmarks | 並行ストーリーを横断的に代表するイベント |
| Narrative | weighted st-DAG | route map | 単一source・単一sinkを持つDAG |

この対応は論文の表1で明示されています。特に、イベントはノード、ストーリーはパス、ナラティブ全体は複数パスを含む重み付き st-graph です。`2009.04508v2.pdf`

形式的には、

$$
G=(D,E)
$$

を、単一source $s$ と単一sink $t$ を持つ重み付きDAGとします。各 $s$-$t$ path が一つの storyline であり、edge weight は coherence に基づく遷移確率です。`2009.04508v2.pdf`

---

# 2. 論文のエンド・ツー・エンド処理

論文の図2は、入力から可視化までを次の6段階に分けています。

1. 文書取得・前処理  
2. coherence 計算  
3. 線形計画による st-graph 抽出  
4. main route 抽出  
5. representative landmarks 抽出  
6. GraphVizによる可視化  

`2009.04508v2.pdf`

実装上は、以下の中間生成物を明示的に保存すると再現性を確保できます。

```text
events
  ↓
embedding_matrix
  ↓
angular_similarity_matrix
topic_membership_matrix
topic_similarity_matrix
  ↓
coherence_matrix
  ↓
LP node flows / edge flows / cluster coverage
  ↓
normalized weighted DAG
  ↓
main route
representative landmarks
  ↓
SVG / HTML / JSON
```

---

# 3. Phase 1：データと前処理

## 3.1 論文忠実版の入力

2020年論文ではニュース記事の**見出し**を一つのイベントとして扱います。理由は、ニュース記事の inverted pyramid structure により、見出しに主要イベント情報が集約されているという前提です。入力には少なくとも次の列が必要です。`2009.04508v2.pdf`

```text
event_id
headline
publication_date
url
publication / source
```

実装では次を強制すべきです。

```python
df = (
    df.assign(publication_date=pd.to_datetime(df["publication_date"], utc=True))
      .sort_values(["publication_date", "event_id"], kind="stable")
      .reset_index(drop=True)
)

df["time_index"] = np.arange(len(df))
```

重要なのは、グラフの時間順序が日付そのものではなく、最終的には **row index $i<j$** で決まることです。同一時刻の記事がある場合、元IDなどによる決定論的な tie-break が必要です。

## 3.2 開始・終了イベント

論文の一般定義ではユーザーが $s,t$ を選択します。ただし、事例研究では期間内の最初の記事と最後の記事を使用しています。

再現実装では、最も安全なのは次の処理です。

```python
df = df.loc[
    (df["publication_date"] >= start_date)
    & (df["publication_date"] <= end_date)
].copy()

s = 0
t = len(df) - 1
```

任意の中間ノードを $s,t$ として使用する場合は、論文図2の制約だけでは source に流入したり sink から流出したりする可能性があるため、

$$
\sum_i x_{is}=0,\qquad
\sum_j x_{tj}=0
$$

を明示するか、$s,t$ の時刻区間だけにデータを切る必要があります。

---

# 4. Phase 2：Coherence の計算

論文では、2イベント間の coherence を次の2要素で構成します。

1. **event similarity**：文書埋め込みの意味的近さ  
2. **topic similarity**：クラスタ所属確率分布の近さ  

片方だけが高い接続を避けるため、最終値は算術平均ではなく幾何平均です。`2009.04508v2.pdf` `2009.04508v2.pdf`

---

## 4.1 Event similarity：angular similarity

論文は Universal Sentence Encoder v4.0 により、各見出しを512次元ベクトルに変換しています。

$$
e_i\in\mathbb{R}^{512}
$$

angular similarity は、

$$
A_{ij}
=
1-
\frac{
\arccos
\left(
\frac{e_i^\top e_j}
{\|e_i\|\|e_j\|}
\right)
}{\pi}
$$

です。

$$
A_{ij}\in[0,1]
$$

となり、

- 同方向：1
- 直交：0.5
- 反対方向：0

です。

2020年論文本文では式が省略されていますが、著者の後続研究では上式が明示されています。([MDPI](https://www.mdpi.com/1099-4300/28/7/732?utm_source=chatgpt.com))

実装は次のようになります。

```python
from __future__ import annotations

import numpy as np

def angular_similarity_matrix(embeddings: np.ndarray) -> np.ndarray:
    """埋め込み行列から pairwise angular similarity を計算する。"""
    x = np.asarray(embeddings, dtype=np.float64)

    if x.ndim != 2:
        raise ValueError("embeddings must be a 2D array")

    norms = np.linalg.norm(x, axis=1, keepdims=True)
    if np.any(norms <= 0):
        raise ValueError("zero-norm embedding was found")

    unit = x / norms
    cosine = np.clip(unit @ unit.T, -1.0, 1.0)

    angular = 1.0 - np.arccos(cosine) / np.pi
    np.fill_diagonal(angular, 1.0)

    return np.clip(angular, 0.0, 1.0)
```

---

## 4.2 Topic extraction：UMAP + HDBSCAN

埋め込みをそのままHDBSCANへ渡すと、高次元空間で距離が不安定になり、計算コストも大きくなります。そのため論文では、

$$
e_i
\overset{\mathrm{UMAP}}{\longrightarrow}
z_i
\overset{\mathrm{HDBSCAN}}{\longrightarrow}
p_i
$$

という処理を採用しています。

ここで、

$$
p_i=(p_{i1},\ldots,p_{ic})
$$

はイベント $i$ の各クラスタへの soft membership vector です。HDBSCANを使うため、クラスタ数 $c$ は事前指定されません。`2009.04508v2.pdf`

再現用の基本形は次です。

```python
import hdbscan
import umap

reducer = umap.UMAP(
    n_neighbors=15,
    n_components=5,
    min_dist=0.0,
    metric="cosine",
    random_state=42,
)

projected = reducer.fit_transform(embeddings)

clusterer = hdbscan.HDBSCAN(
    min_cluster_size=5,
    min_samples=None,
    metric="euclidean",
    cluster_selection_method="eom",
    prediction_data=True,
)

labels = clusterer.fit_predict(projected)

topic_prob = hdbscan.all_points_membership_vectors(clusterer)
```

ただし、上のUMAP/HDBSCANパラメータは**決定論的な初期実装例**であり、論文には完全な設定値が記載されていません。したがって、論文図5と同一のグラフを得るには、元コードのパラメータと元データスナップショットが必要です。

### Noise point の処理

HDBSCANの soft membership は、外れ値について行和が1未満になることがあります。論文図2は membership vector の和を1として描いているため、論文忠実な実装では少なくとも正の行について再正規化するのが自然です。

```python
row_sum = topic_prob.sum(axis=1, keepdims=True)

positive = row_sum[:, 0] > 0
topic_prob[positive] /= row_sum[positive]
```

全要素0のイベントは、次のいずれかを明示的に選ぶ必要があります。

- noise cluster を追加する
- coverage計算から除外する
- event similarity のみで接続する

これは論文だけでは一意に決まらない実装上の未特定部分です。

---

## 4.3 Topic similarity：Jensen-Shannon similarity

イベント $i,j$ の topic membership distribution を $p_i,p_j$ とすると、

$$
T_{ij}
=
1-d_{\mathrm{JS}}(p_i,p_j)
$$

とします。

ここで $d_{\mathrm{JS}}$ は Jensen-Shannon **distance**、すなわちJensen-Shannon divergenceの平方根です。著者の2026年の定式化では、この distance を使うことが明示されています。([MDPI](https://www.mdpi.com/1099-4300/28/7/732?utm_source=chatgpt.com))

SciPy の `jensenshannon` は divergence ではなく、その平方根である distance を返します。したがって**二乗してはいけません**。([SciPyドキュメント](https://docs.scipy.org/doc/scipy-1.5.1/reference/generated/scipy.spatial.distance.jensenshannon.html?utm_source=chatgpt.com))

```python
from scipy.spatial.distance import jensenshannon

def topic_similarity_matrix(topic_prob: np.ndarray) -> np.ndarray:
    """HDBSCAN soft-membership 分布の JS similarity を計算する。"""
    p = np.asarray(topic_prob, dtype=np.float64)

    if p.ndim != 2:
        raise ValueError("topic_prob must be a 2D array")
    if np.any(p < 0):
        raise ValueError("topic probabilities must be non-negative")

    row_sum = p.sum(axis=1, keepdims=True)
    if np.any(row_sum <= 0):
        raise ValueError("zero-sum probability vector was found")

    p = p / row_sum

    n = len(p)
    similarity = np.eye(n, dtype=np.float64)

    for i in range(n):
        for j in range(i + 1, n):
            js_distance = float(
                jensenshannon(p[i], p[j], base=2.0)
            )
            value = 1.0 - js_distance
            similarity[i, j] = value
            similarity[j, i] = value

    return np.clip(similarity, 0.0, 1.0)
```

---

## 4.4 Composite coherence

最終的な coherence は、

$$
C_{ij}
=
\sqrt{A_{ij}T_{ij}}
$$

です。

```python
angular = angular_similarity_matrix(embeddings)
topical = topic_similarity_matrix(topic_prob)

coherence = np.sqrt(
    np.clip(angular * topical, 0.0, 1.0)
)
```

幾何平均を使うことで、一方がゼロなら coherence もゼロになります。また、一方だけ高い組合せに対して算術平均より強いペナルティがかかります。論文はこれを、event similarity と topic similarity の両方を満たす厳格な接続条件として説明しています。`2009.04508v2.pdf`

---

# 5. Phase 3：線形計画による Narrative Map 抽出

## 5.1 変数

イベントを時刻順に $i=0,\ldots,n-1$ とします。

| 記号 | 意味 |
|---|---|
| $y_i$ | `node-active_i`：ノード $i$ を通るフロー |
| $x_{ij}$ | `next-node_{i,j}`：$i\to j$ を通るフロー |
| $\gamma$ | `minedge`：目的関数で最大化する bottleneck |
| $a_k$ | `cluster-active_k`：クラスタ $k$ の coverage |
| $K$ | 期待ストーリー長 |
| `mincover` | 平均topic coverageの下限 |

論文図2には変数domainが明示されていません。しかし、

$$
0\le y_i\le1,\qquad
0\le x_{ij}\le1
$$

の**連続変数**と解釈する必要があります。

理由は、これらをbinaryにすると各active nodeの入辺・出辺が一本に限定され、解が一本のpathにしかならず、論文が示す分岐・合流を含む st-graph と矛盾するためです。現行システムが $K$ を “expected main storyline length” と説明していることも、このcontinuous-flow解釈と整合します。([GitHub](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md))

---

## 5.2 目的関数

論文図2の目的関数は、

$$
\max \gamma
$$

です。

coherenceとの関係は、

$$
\gamma
\le
1-x_{ij}+C_{ij}
\qquad \forall i<j
$$

です。

- $x_{ij}=1$ なら  
  $$
  \gamma\le C_{ij}
  $$
- $x_{ij}=0$ なら  
  $$
  \gamma\le1+C_{ij}
  $$
  となり、通常は拘束しません。
- $0<x_{ij}<1$ のside flowは、低coherenceでもある程度許容されます。

したがって厳密には、これは「全ての正の辺の最低coherence」を直接最大化するのではなく、**高いフローを持つ辺ほど強く coherence を要求する flow-relaxed maximin formulation** です。

著者の説明上は「ストーリーは最も弱いlinkによって評価される」という weakest-link objective です。`2009.04508v2.pdf`

---

## 5.3 時間・構造制約

論文図2の構造制約は次のとおりです。

### 開始・終了ノード

$$
y_s=1,\qquad y_t=1
$$

### 時間逆行の禁止

$$
x_{ij}=0
\qquad
\forall i\ge j
$$

実装では、最初から $i<j$ の辺だけ生成すれば同値です。

### Active node を飛び越す辺の制限

$$
x_{ij}
\le
1-y_k
\qquad
\forall i<k<j
$$

中間ノード $k$ に1単位のフローが通っている場合、

$$
y_k=1
\Rightarrow
x_{ij}=0
$$

となり、$k$ を飛び越す辺は作れません。

### Flow conservation

$$
\sum_i x_{ij}=y_j
\qquad
\forall j\ne s
$$

$$
\sum_j x_{ij}=y_i
\qquad
\forall i\ne t
$$

各中間ノードについて、

$$
\text{incoming flow}
=
\text{outgoing flow}
=
y_i
$$

となります。

### 期待長

$$
\sum_i y_i=K
$$

$$
\sum_{i,j}x_{ij}=K-1
$$

図2の線形計画は、論文13ページにまとめて示されています。`2009.04508v2.pdf`

---

## 5.4 $K$ は「選択ノード数」ではなく期待path長

この点は実装上非常に重要です。

一単位の $s$-$t$ flow は、DAG上のpath flowへ、

$$
x
=
\sum_{p\in\mathcal P}
\lambda_p x^{(p)},
\qquad
\sum_p\lambda_p=1
$$

と分解できます。

すると、

$$
y_i
=
\sum_{p:i\in p}\lambda_p
$$

であり、

$$
\sum_i y_i
=
\sum_p\lambda_p |p|
=
K
$$

です。

したがって $K$ は、path mixtureからランダムにpathを選んだときの**期待ノード数**です。グラフ全体に現れるノード数が $K$ に限定されるわけではありません。

これは、事例研究で $K$ が比較的小さくても、最終グラフに20以上のイベントが現れ得る理由です。現行UIも $K$ を期待main-story lengthとして説明しています。([GitHub](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md))

---

# 6. Topic coverage 制約

## 6.1 Edge membership

イベント $i,j$ のクラスタ $k$ へのmembershipを、

$$
p_{ik},\quad p_{jk}
$$

とすると、辺のmembershipは、

$$
m_{ijk}
=
\sqrt{p_{ik}p_{jk}}
$$

です。

例えば、

$$
p_{ik}=0.95,\quad p_{jk}=0.90
$$

なら、

$$
m_{ijk}
=
\sqrt{0.95\times0.90}
\approx0.925
$$

です。

片方だけがクラスタ $k$ に属する場合は小さくなり、どちらかがゼロなら辺membershipもゼロになります。論文の図3はこの処理を具体例で示しています。`2009.04508v2.pdf`

## 6.2 Cluster coverage

クラスタ $k$ のcoverageを、

$$
a_k
=
\sum_{i,j}
x_{ij}m_{ijk}
$$

とします。

制約は、

$$
\sum_{k=1}^{c}a_k
\ge
c\cdot \mathrm{mincover}
$$

すなわち、

$$
\frac{1}{c}
\sum_{k=1}^{c}a_k
\ge
\mathrm{mincover}
$$

です。

ここで注意すべきなのは、

$$
a_k\ge\mathrm{mincover}
\quad\forall k
$$

ではない点です。したがって、各クラスタに個別の最低coverageを強制するのではなく、**クラスタ全体に対する平均coverage制約**です。

また、ノード単体ではなく辺を使うため、あるtopicの記事が一つ孤立しているだけでは、そのtopicを十分にcoverしたとは扱われません。論文は「coherent sequence内にtopicが現れること」をcoverageと解釈しています。`2009.04508v2.pdf` `2009.04508v2.pdf`

論文では予備的な定性評価に基づき、80%程度のminimum coverageがうまく機能したとしています。一方、現行チュートリアルのCOVID例は `mincover=20`、すなわち20%を出発点にしています。モデル、データ、後処理が更新されているため、両者を同じ推奨値として扱うべきではありません。`2009.04508v2.pdf` ([GitHub](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md))

---

# 7. PuLPによるコア線形計画の再現例

以下は論文図2をほぼ直接実装したものです。開始・終了イベントはデータの先頭・末尾に切り出してある前提です。

```python
from __future__ import annotations

from typing import Any

import numpy as np
import pulp

def solve_narrative_map_lp(
    coherence: np.ndarray,
    topic_prob: np.ndarray,
    K: float,
    mincover: float,
    *,
    solver: Any | None = None,
) -> dict[str, Any]:
    """
    論文 Figure 2 の continuous-flow LP。

    Parameters
    ----------
    coherence:
        shape=(n, n), [0, 1] の pairwise coherence.
    topic_prob:
        shape=(n, c), 各イベントの soft cluster membership.
    K:
        expected path length. 通常 2 <= K <= n.
    mincover:
        fraction表記。20%なら0.20。
    solver:
        PuLP solver. NoneならCBC。

    Notes
    -----
    events は時刻順に並び、source=0, sink=n-1 とする。
    """
    C = np.asarray(coherence, dtype=np.float64)
    P = np.asarray(topic_prob, dtype=np.float64)

    if C.ndim != 2 or C.shape[0] != C.shape[1]:
        raise ValueError("coherence must be square")

    n = C.shape[0]
    if P.ndim != 2 or P.shape[0] != n:
        raise ValueError("topic_prob has incompatible shape")

    if not 2 <= K <= n:
        raise ValueError("K must satisfy 2 <= K <= n")

    if not 0.0 <= mincover <= 1.0:
        raise ValueError("mincover must be expressed as a fraction")

    s = 0
    t = n - 1
    n_clusters = P.shape[1]

    # i < j の時系列順辺のみを候補にする
    edges = [
        (i, j)
        for i in range(n)
        for j in range(i + 1, n)
    ]

    model = pulp.LpProblem(
        name="narrative_map",
        sense=pulp.LpMaximize,
    )

    node_active = {
        i: pulp.LpVariable(
            f"node_active_{i}",
            lowBound=0.0,
            upBound=1.0,
            cat="Continuous",
        )
        for i in range(n)
    }

    next_node = {
        (i, j): pulp.LpVariable(
            f"next_node_{i}_{j}",
            lowBound=0.0,
            upBound=1.0,
            cat="Continuous",
        )
        for i, j in edges
    }

    minedge = pulp.LpVariable(
        "minedge",
        lowBound=0.0,
        upBound=1.0,
        cat="Continuous",
    )

    # Objective
    model += minedge

    # Coherence / weakest-link relaxation
    for i, j in edges:
        model += (
            minedge
            <= 1.0 - next_node[i, j] + float(C[i, j])
        )

    # Source and sink
    model += node_active[s] == 1.0
    model += node_active[t] == 1.0

    # An edge may not skip a fully active intermediate node
    for i, j in edges:
        for k in range(i + 1, j):
            model += (
                next_node[i, j]
                <= 1.0 - node_active[k]
            )

    # Expected number of nodes and edges
    model += pulp.lpSum(node_active.values()) == float(K)
    model += pulp.lpSum(next_node.values()) == float(K - 1.0)

    # Incoming flow equals node activity
    for j in range(n):
        if j == s:
            continue

        incoming = pulp.lpSum(
            next_node[i, j]
            for i in range(j)
        )
        model += incoming == node_active[j]

    # Outgoing flow equals node activity
    for i in range(n):
        if i == t:
            continue

        outgoing = pulp.lpSum(
            next_node[i, j]
            for j in range(i + 1, n)
        )
        model += outgoing == node_active[i]

    # Topic coverage
    cluster_coverage_expr = []

    for k in range(n_clusters):
        coverage_k = pulp.lpSum(
            next_node[i, j]
            * float(np.sqrt(P[i, k] * P[j, k]))
            for i, j in edges
        )
        cluster_coverage_expr.append(coverage_k)

    model += (
        pulp.lpSum(cluster_coverage_expr)
        >= float(n_clusters * mincover)
    )

    if solver is None:
        solver = pulp.PULP_CBC_CMD(msg=False)

    model.solve(solver)

    status = pulp.LpStatus[model.status]
    if status != "Optimal":
        raise RuntimeError(f"LP status: {status}")

    node_flow = {
        i: float(pulp.value(node_active[i]))
        for i in range(n)
    }

    edge_flow = {
        (i, j): float(pulp.value(next_node[i, j]))
        for i, j in edges
    }

    cluster_coverage = np.array(
        [
            float(pulp.value(expr))
            for expr in cluster_coverage_expr
        ],
        dtype=np.float64,
    )

    return {
        "status": status,
        "objective_minedge": float(pulp.value(minedge)),
        "node_flow": node_flow,
        "edge_flow": edge_flow,
        "cluster_coverage": cluster_coverage,
        "average_cluster_coverage": float(
            cluster_coverage.mean()
        ),
    }
```

## 実装時の数値上の注意

`edge_flow` には solver tolerance による微小値が残る可能性があります。グラフ生成では、

```python
EDGE_EPS = 1e-7
```

などの閾値を明示し、閾値を変えたときのノード数・辺数の感応度も確認すべきです。

---

# 8. Phase 4：Main route の抽出

LPで得られる $x_{ij}$ はflowであり、まだ条件付き遷移確率ではありません。論文では、各ノードの出辺を正規化します。

$$
p_{ij}
=
\frac{x_{ij}}
{\sum_\ell x_{i\ell}}
$$

その上で、path $c$ の確率を、

$$
P(c)
=
\prod_{(i,j)\in c}p_{ij}
$$

と定義します。

main route は、

$$
c^*
=
\arg\max_{c:s\rightsquigarrow t}
\prod_{(i,j)\in c}p_{ij}
$$

です。

数値計算では、

$$
-\log P(c)
=
\sum_{(i,j)\in c}
-\log p_{ij}
$$

を最小化すればよいため、shortest-path problemになります。`2009.04508v2.pdf`

```python
import math
import networkx as nx

def build_normalized_graph(
    edge_flow: dict[tuple[int, int], float],
    *,
    eps: float = 1e-7,
) -> nx.DiGraph:
    graph = nx.DiGraph()

    positive = {
        edge: value
        for edge, value in edge_flow.items()
        if value > eps
    }

    outgoing_total: dict[int, float] = {}
    for (i, _), value in positive.items():
        outgoing_total[i] = outgoing_total.get(i, 0.0) + value

    for (i, j), flow in positive.items():
        probability = flow / outgoing_total[i]

        graph.add_edge(
            i,
            j,
            flow=flow,
            probability=probability,
            neg_log_probability=-math.log(
                max(probability, 1e-15)
            ),
        )

    return graph

def extract_main_route(
    graph: nx.DiGraph,
    source: int,
    sink: int,
) -> list[int]:
    return nx.shortest_path(
        graph,
        source=source,
        target=sink,
        weight="neg_log_probability",
    )
```

論文上の constituent events は、このmain routeに含まれるイベントです。

---

# 9. Phase 5：Representative landmarks と最大反鎖

## 9.1 Antichain

DAGのantichainとは、互いにpathで到達できないノードの集合です。

$$
A\subseteq V
$$

について、任意の異なる $u,v\in A$ が、

$$
u\not\rightsquigarrow v,
\qquad
v\not\rightsquigarrow u
$$

を満たします。

maximum antichain は要素数が最大のantichainです。

Dilworthの定理により、

$$
\text{maximum antichain size}
=
\text{minimum chain decomposition size}
$$

です。したがって、最大反鎖の各ノードを、並行する各storylineの代表点と解釈できます。`2009.04508v2.pdf`

論文は NetworkX により全antichainを列挙し、

1. 最大要素数のものだけを残す  
2. 複数ある場合はtimestampが最も早いものを選ぶ  

という処理を行っています。`2009.04508v2.pdf`

```python
def first_maximum_antichain(
    graph: nx.DiGraph,
    timestamps: dict[int, pd.Timestamp],
) -> list[int]:
    antichains = list(nx.antichains(graph))

    if not antichains:
        return []

    maximum_size = max(len(a) for a in antichains)

    candidates = [
        list(a)
        for a in antichains
        if len(a) == maximum_size
    ]

    # 「最も早い」の実装を曖昧にしないため、
    # 時刻ベクトルの辞書式順序で決める
    return min(
        candidates,
        key=lambda nodes: tuple(
            sorted(timestamps[node] for node in nodes)
        ),
    )
```

ただし、`nx.antichains` による全列挙は最悪の場合指数時間です。論文再現ではこれを使うべきですが、大規模化する場合は maximum matching に基づく maximum-antichain algorithm に置き換える方が合理的です。

---

# 10. Phase 6：可視化

2020年論文では GraphViz と DOT を使ってSVGを生成し、HTML/CSSに埋め込んでいます。可視化ルールは概ね次です。

- 時間は上から下
- main route は青い破線
- representative landmarks は緑
- source / sink は専用アイコン
- edge weight は数値ではなく線幅
- ノードには日付、見出し、媒体ロゴ
- interactionは基本的なHTMLレベル

数値weightを明示しなかった理由は、予備評価で利用者を混乱させたためです。`2009.04508v2.pdf`

17ページの図5は、main route、side routes、representative landmarks、edge widthを一枚のmap上で表した完成形です。`2009.04508v2.pdf`

---

# 11. GitHub `main` の著者実装

## 11.1 リポジトリ構成

現行リポジトリの主要構成は次のとおりです。

```text
NMVT.py                  # アプリケーションのエントリポイント
packages/                # 内部ロジック
file_system_backend/     # キャッシュ・永続化関連
preprocessing/           # 独自データとembeddingの準備
data/                    # サンプルデータ
static/                  # 静的UI素材
assets/                  # Dash用assets
tutorial/                # 操作例
requirements.txt
Dockerfile
docker-compose.yml
```

READMEでは、`NMVT.py` が Narrative Maps Visualization Tool 本体で、`preprocessing` にカスタムデータ準備、`tutorial` に操作例があると説明されています。現行版は古い依存関係を更新し、過去版に含まれていた実験コードを整理した2.1.0リリースです。([GitHub](https://github.com/briankeithn/narrative-maps))

## 11.2 現行システムの5コンポーネント

SoftwareX論文では、現行NMVTを次の5部分に分けています。

1. Data Processing Module  
2. Narrative Extraction Engine  
3. Interactive Visualization Interface  
4. Semantic Interaction Layer  
5. Explainable AI Components  

データ処理はpandasとSentence Transformers、抽出はUMAP/HDBSCANとPuLP、表示はDash/Cytoscape、semantic interactionは3MSI、説明はSHAPに基づいています。([ResearchGate](https://www.researchgate.net/publication/397596644_Narrative_Maps_Visualization_Tool_NMVT_An_interactive_narrative_analytics_system_based_on_the_narrative_maps_framework?utm_source=chatgpt.com))

---

## 11.3 現行版の入力CSV

GitHub版のカスタムデータには次の列が必要です。

```text
id
title
url
date
publication
full_text
embedding
```

`id` は0始まりで時間順、行順も時間昇順である必要があります。embeddingには `all-MiniLM-L6-v2` が推奨されています。([GitHub](https://github.com/briankeithn/narrative-maps))

したがって2020年版との違いは、

- 2020：headlineをUSE v4で内部変換
- 現行：full textとprecomputed embeddingを受け取るdocument-level design

です。

CSV内のembeddingが文字列の場合は、`eval` ではなく `ast.literal_eval` で読み取るべきです。

```python
import ast

df["embedding"] = df["embedding"].map(
    lambda value: np.asarray(
        ast.literal_eval(value),
        dtype=np.float32,
    )
)
```

---

# 12. 論文版と現行GitHub版の重要な差

| 項目 | 2020年論文 | GitHub main 2.1.0 |
|---|---|---|
| 基本単位 | ニュース見出し | full textを含む文書 |
| 埋め込み | USE v4、512次元 | precomputed embedding、MiniLM推奨 |
| start/end | 単一source・単一sinkが必須 | なし、startのみ、start+endを選択可能 |
| 基本coherence | angular × topic の幾何平均 | semantic、topical、entity connectionを扱う |
| 時間距離 | DAG順序だけ | optional temporal penalty |
| representative | earliest maximum antichain | 各storylineのembedding centroid |
| structural importance | 明示なし | node degree によるhub |
| UI | GraphViz SVG + HTML | Dash + Cytoscape |
| 人間の修正 | なし | event/edge/clusterの追加・削除 |
| XAI | なし | SHAPによるkeyword contribution |
| 出力 | 静的map | PNG、JSON、対話型map |
| $K$ | LP上のexpected length | UI上もexpected main story length |
| coverage例 | 80% | COVID tutorialでは20% |

現行チュートリアルとSoftwareX論文に基づく差分です。([GitHub](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md))

---

# 13. Representative landmark の意味は現行版で変わっている

これは最も注意すべき変更です。

## 2020年論文

代表イベントは、

$$
\text{earliest maximum antichain}
$$

です。

これはグラフ構造に基づく**横断的な代表点**です。複数のstorylineを横切る「breadth」を表します。

## 現行GitHub

赤枠の representative event は、各storylineに含まれるイベントのembedding centroidに最も近いイベントです。

$$
r_\ell
=
\arg\min_{i\in S_\ell}
\|e_i-\bar e_\ell\|
$$

ここで、

$$
\bar e_\ell
=
\frac{1}{|S_\ell|}
\sum_{i\in S_\ell}e_i
$$

です。

青枠の structurally important event は node degree に基づくhubです。現行チュートリアルはこの二種類を明確に区別しています。([GitHub](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md))

したがって、**論文を再現する場合はcentroidを使わずmaximum antichainを使う必要があります**。反対に現行UIを再現するなら、antichainではなくstoryline centroidとdegree centralityを実装します。

---

# 14. 現行版のSemantic Interaction

現行NMVTは、ユーザー操作を単なる表示変更ではなく、再最適化時の制約へ変換します。

## Remove Event

対象イベントを採用しないように、coherenceまたはnode activityをゼロに固定する制約を追加します。

$$
y_i=0
$$

あるいは、対象イベントに接続する候補edgeのcoherenceを0にします。

チュートリアルでは「zero coherenceを強制するstructure-space constraint」と説明されています。([GitHub](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md))

## Add / Remove Edge

選択辺について、

$$
x_{ij}\ge\varepsilon
$$

または、

$$
x_{ij}=0
$$

といった構造制約を追加します。

## Add to Cluster

イベントを指定topicへ割り当てる操作は、

1. semi-supervised UMAPでprojection spaceを変更  
2. cluster membershipを変更  
3. 対象イベントが弱く接続されるようstructure-space制約を追加  

という二層の修正です。([GitHub](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md))

## 正則化とstrict mode

現行UIには、

- edge weightに対するL1 regularization
- startから到達不能なcomponentを除くstrict mode
- common entity term
- temporal-distance penalty

があります。([GitHub](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md))

これらは2020年論文の基本LPにはありません。

---

# 15. 現行版のExplainable AI

現行版では、edge typeを次のように表示します。

- Similarity
- Topical
- Entity

edgeを選択すると、normalized coherence と、接続に寄与したkeywordをSHAPで表示します。また、未接続の2イベントについても比較できます。([GitHub](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md))

これは「なぜ接続されたか」を説明するものであり、因果関係を証明するものではありません。semantic similarity、topic membership、entity overlapの寄与を説明する機能です。

---

# 16. 論文の事例研究

論文はCOVID-19 archiveから、

- 1,576記事
- 373媒体
- 2020年1月から3月

を取得しています。

1月分は607記事で、探索空間を減らすため、記事数上位5媒体に限定し102記事としました。開始・終了イベントは時系列の最初と最後です。最適化後、固定した開始・終了に加えて22イベントが残りました。`2009.04508v2.pdf`

main routeからは主に、

- virus spread
- economic impacts

が抽出されました。

representative landmarksはこれに加えて、

- government containment measures
- scientific information
- criticism of official responses

を表しました。`2009.04508v2.pdf`

ただし、Wuhanでの生活のような一部のthemeは、main routeとrepresentative landmarksだけでは抽象化されて失われています。したがって、この二つはmap全体の完全な要約ではなく、

- main route：longitudinal / depth
- antichain landmarks：transverse / breadth

を提供するものです。`2009.04508v2.pdf` `2009.04508v2.pdf`

---

# 17. ユーザー評価の解釈

評価は、

- Representation
- Metaphor
- Visualization

の3次元、合計22項目の5段階Likert scaleです。Cronbach’s alphaは0.9560でした。`2009.04508v2.pdf`

1月、2月、3月の各mapについて20名の有効回答を集め、全般にcoherence、relevance、metaphorの自然さ、main routeとlandmarkの有用性は肯定的に評価されています。`2009.04508v2.pdf`

ただし、この評価が示すのは主に、

- 表現が理解しやすいか
- map metaphorが自然か
- visual interfaceが役立つか

であり、抽出されたgraphが「唯一正しいナラティブ」であることを検証したものではありません。

また、

- COVIDのみ
- 各map 20名
- headlinesのみ
- 既知テーマで事前知識が多い

という制約があります。著者自身もheadlineに加えてleadやfull textを使う余地、異なるtopicとより多人数での評価が必要だと述べています。`2009.04508v2.pdf`

---

# 18. 再現性と計算量

論文は、主要な計算量を概ね、

$$
O(n^2c)
$$

としています。ここで $n$ は文書数、$c$ はクラスタ数です。主要なボトルネックはpairwise event combinationです。`2009.04508v2.pdf`

より細かく見ると、

- embedding similarity：$O(n^2d)$
- topic similarity：$O(n^2c)$
- edge-cluster membership storage：$O(n^2c)$
- `i<k<j` の素朴なskip constraint生成：最悪 $O(n^3)$
- 全antichain列挙：最悪指数時間

です。

現行SoftwareX版では、著者のテスト環境で500文書程度までreasonable interactivityを維持し、新規データの初回処理は類似度行列・entity情報の計算に時間がかかる一方、キャッシュ後は大幅に短縮されると報告されています。1,000文書も理論上処理可能ですが、500を超えると対話性能が低下するとされています。これは研究用prototypeの実測範囲であり、本番性能保証ではありません。([ResearchGate](https://www.researchgate.net/publication/397596644_Narrative_Maps_Visualization_Tool_NMVT_An_interactive_narrative_analytics_system_based_on_the_narrative_maps_framework?utm_source=chatgpt.com))

---

# 19. 再現実装で必須となる診断

各段階で次を出力すべきです。

## Embedding / clustering

```text
embedding shape
embedding norm distribution
UMAP projection
HDBSCAN cluster count
noise ratio
cluster size
membership row sums
membership entropy
```

## Coherence

```text
angular similarity distribution
topic similarity distribution
composite coherence distribution
top / bottom coherent pairs
coherence vs time-distance scatter
```

## LP

```text
solver status
objective minedge
sum(node_active) - K
sum(edge_flow) - (K - 1)
flow conservation residual
average cluster coverage
coverage by cluster
number of positive-flow nodes and edges
```

## Graph

```text
nx.is_directed_acyclic_graph(G)
source in-degree == 0
sink out-degree == 0
nx.has_path(source, sink)
all edge timestamps increase
outgoing probabilities sum to 1
```

## Narrative summaries

```text
main route node count
main route probability
main route minimum coherence
main route average coherence
maximum antichain width
representative landmark timestamps
```

## Parameter sensitivity

少なくとも、

$$
K\in\{4,6,8,10,12\}
$$

と、

$$
\mathrm{mincover}
\in\{0.1,0.2,0.4,0.6,0.8\}
$$

のgridを評価し、

- feasibility
- main-route coherence
- graph size
- number of storylines
- cluster coverage
- solution stability

を比較すべきです。

---

# 20. 再現対象ごとの推奨仕様

## A. 2020年論文忠実版

次の仕様に固定します。

```text
event text:
    headline

encoder:
    Universal Sentence Encoder v4

topic model:
    UMAP + HDBSCAN soft membership

coherence:
    sqrt(angular_similarity * JS_similarity)

optimization:
    Figure 2 continuous-flow LP

endpoints:
    one fixed source and one fixed sink

main route:
    maximum-likelihood path after outgoing normalization

representative landmarks:
    earliest maximum antichain

visualization:
    GraphViz / DOT / SVG
```

この仕様なら、論文で提案されたアルゴリズムを再現できます。ただし、UMAP/HDBSCANの全設定、noise処理、antichain tie-break、元データの厳密なスナップショットが論文だけでは完全に特定できないため、**図5とbitwiseに同じgraphが得られる保証はありません**。

## B. 現行GitHub 2.1.0互換版

次を追加または変更します。

```text
event text:
    full_text + display title

encoder:
    precomputed all-MiniLM-L6-v2 embeddings

endpoints:
    none / start only / start and end

connection types:
    similarity / topical / entity

optional terms:
    common-entity emphasis
    temporal-distance penalty

representative events:
    storyline embedding centroid

structural events:
    degree-based hubs

semantic interaction:
    add/remove node
    add/remove edge
    add to cluster with semi-supervised UMAP

regularization:
    optional L1 edge regularization

post-processing:
    optional strict mode

XAI:
    SHAP keyword contributions

interface:
    Dash + Cytoscape + GraphViz layout
```

GitHub版を動作させるだけであれば、著者READMEではPython 3.12とGraphVizを前提とし、`NMVT.py`をエントリポイントとしています。主要ライブラリはPuLP、NetworkX、UMAP、HDBSCAN、Dash/Cytoscape、SHAPです。([GitHub](https://github.com/briankeithn/narrative-maps))

---

# 21. 実装上の最終的な判断

論文の本質は、単なる「記事クラスタリング」ではありません。

$$
\boxed{
\text{semantic coherence}
+
\text{topic coverage}
+
\text{chronological unit flow}
}
$$

を同時に満たす fractional-flow DAG を構築し、その後、

$$
\boxed{
\text{main route}
=
\text{maximum-likelihood longitudinal view}
}
$$

と、

$$
\boxed{
\text{representative landmarks}
=
\text{maximum-antichain transverse view}
}
$$

を抽出することにあります。

また、GitHub現行版は、この2020年の静的アルゴリズムをそのまま表示したものではなく、

$$
\text{algorithmic extraction}
\rightarrow
\text{interactive visual analytics}
\rightarrow
\text{human-guided re-optimization}
$$

へ拡張したシステムです。論文再現とGitHub再現を混在させると、特に representative event、endpoint constraints、coherence terms、`mincover` の解釈がずれるため、実装では両モードを明示的に分離する必要があります。

---

**Sources:**

- [An Information-Geometric Justification for Composite Coherence in Event-Based Narrative Extraction](https://www.mdpi.com/1099-4300/28/7/732?utm_source=chatgpt.com)
- [scipy.spatial.distance.jensenshannon — SciPy v1.5.1 Reference Guide](https://docs.scipy.org/doc/scipy-1.5.1/reference/generated/scipy.spatial.distance.jensenshannon.html?utm_source=chatgpt.com)
- [https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md](https://github.com/briankeithn/narrative-maps/blob/main/tutorial/TUTORIAL.md)
- [(PDF) Narrative Maps Visualization Tool (NMVT): An interactive narrative analytics system based on the narrative maps framework](https://www.researchgate.net/publication/397596644_Narrative_Maps_Visualization_Tool_NMVT_An_interactive_narrative_analytics_system_based_on_the_narrative_maps_framework?utm_source=chatgpt.com)

## Response:
2026/7/27 22:59:55

> **Web検索で確認中**
>
> ユーザーの要求に答えるために、GitHubの実装を最新の情報で確認し、関連する論文やリポジトリを調べる必要があります。
>
> **確認した**
>
> 
>
> **GitHub実装の検証と適用可能性調査**
>
> [GitHub - misbahsy/MindMapper: A NextJS based app that takes a user prompt, or a YouTube url, or a Website URL, and generates a beautiful Mindmap. · GitHub](https://github.com/misbahsy/MindMapper)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **GitHubリポジトリをクローン**
>
>
> **クローンしたGitHubリポジトリ**
>
> 
>
> **ウェブを検索中**
>
> [raw.githubusercontent.com](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/NMVT.py)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **適用性の検討**
>
> ユーザーの要求に基づき、紙の方法とGitHubの現在の実装を比較し、コーパスの範囲やナラティブの数による調整が必要であることを明確にする必要があります。
>
> **検討した適用性**
>
> 
>
> **ウェブを検索中**
>
> [raw.githubusercontent.com](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **適用性の確認**
>
> この手法は応用可能ですが、注意点があります。元々の論文は複数の独立したナラティブを抽出することを前提にしていないため、時間範囲やナラティブに応じて調整が必要です。
>
> **適用性と推奨手法**
>
> この方法は、スコープが明確な問題であれば適用可能です。ただし、広範なニュースや不特定のナラティブには、前処理やナラティブの家族のクラスター化が必要です。
>
> **確認した適用性と推奨手法**
>
> 
>
> **ウェブを検索中**
>
> [raw.githubusercontent.com](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> 9m 34s考えました

# 結論

**適用可能です。ただし、そのまま一度だけ全記事へ適用するのではなく、**

$$
\boxed{
\text{独立したNarrative候補の発見}
\rightarrow
\text{候補ごとのNarrative Map構築}
\rightarrow
\text{経路分解}
\rightarrow
\text{関連記事の紐付け}
}
$$

という二段階以上の構成にするのが妥当です。

重要なのは、次の二つを区別することです。

1. **一つのNarrative Map内に含まれる複数のstoryline（経路）の数が不明**
2. **記事集合全体に含まれる独立したNarrative Map自体の数が不明**

前者については論文・GitHubの方法を利用できます。後者については、論文・GitHubとも直接には解いていないため、Narrative Mapの前段に「Narrative familyの発見」を追加する必要があります。

論文の正式な問題設定は、「ある特定のissueに関する時刻付き文書集合」と開始イベント $s$、終了イベント $t$ が与えられたとき、両者を複数のpathで接続する一つのNarrative Mapを求めるものです。したがって、任意期間の一般ニュース全体から独立Narrative数を同時推定するモデルではありません。`2009.04508v2.pdf`

---

# 1. 「Narrative数が不明」の意味を分解する

論文・GitHubでは、以下の三つの数を混同しないことが重要です。

| 概念 | 意味 | 数の決まり方 |
|---|---|---|
| topic cluster | 経済、政策、企業業績などの話題 | HDBSCANがデータから推定 |
| storyline / route | 時系列に沿った記事経路 | Narrative Map上のpathとして出現 |
| narrative family / map | 相互に関連するstorylineのまとまり | 論文・GitHubの前提では原則として事前にスコープされる |

論文では、eventをnode、storylineをpath、Narrative全体を複数pathからなるst-DAGとして表現します。したがって、**一つのNarrativeは一つのpathではなく、相互に分岐・合流する複数のstorylineを含むgraph**です。`2009.04508v2.pdf`

HDBSCANはクラスタ数を事前指定せず、記事のtopic membershipを推定します。しかし、このクラスタ数はNarrative数でもstoryline数でもなく、LPのcoverage制約で利用される「topic数」です。`2009.04508v2.pdf`

したがって、ユーザーのいう「Narrative数」が以下のどちらかで結論が変わります。

- **同じニュースイベント内の経路数が不明**  
  → 論文・GitHubを適用可能
- **期間内に何個の独立したニュースイベントがあるか不明**  
  → 事前のNarrative family discoveryが必要

---

# 2. 適用可能性の判定

| 記事集合の状態 | 直接適用 | 判断 |
|---|---:|---|
| すでに一つのissueに絞られている | 可能 | 論文方式をほぼそのまま利用可能 |
| 企業・テーマ・政策など一つの検索条件で収集されている | 条件付きで可能 | 複数の独立episodeが混在していないか確認が必要 |
| 任意期間の一般ニュース全体 | 非推奨 | 前段でNarrative familyを分離する必要がある |
| 開始・終了イベントが既知 | 可能 | 論文方式に最も整合的 |
| 開始・終了イベントが不明 | 可能だが要拡張 | 仮想source/sinkまたは複数start/endを用いる |
| 全関連記事まで取得したい | 追加処理が必要 | Mapに採用されなかった記事を事後的に経路へ紐付ける |

原論文では単一source・単一sinkを持つst-DAGを採用し、すべてのstorylineをsourceからsinkへのpathとして定義します。`2009.04508v2.pdf`

一方、現行GitHub実装は、start nodeとend nodeを空にすることができ、その場合は入出力フローを等式ではなく不等式制約に変更します。このためendpointなしでも実行できますが、理論上の「一つのst-graphとしてのNarrative」よりも、複数成分を含む探索的graphに近くなります。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

---

# 3. 現行GitHubが返す「storyline数」はNarrative数ではない

現行GitHubの `graph_stories` は、概ね次の処理です。

1. graph上で最も尤もらしいpathを一つ抽出
2. そのpathに含まれるnodeをすべてgraphから削除
3. 残ったgraphから次のpathを抽出
4. edgeがなくなれば残りをsingleton storylineとして返す

実際の実装でも、maximum-likelihood chainを取得した後、そのchainの全nodeを削除して再帰しています。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/graph_utils.py))

したがって、GitHubが表示するstoryline数は、

- 潜在的なNarrative数の統計推定値ではない
- node-disjointな貪欲path decompositionの結果
- graphの閾値やLPパラメータに依存
- singletonもstorylineとして数え得る
- 共通の開始部分や合流部分を持つ経路を別々に表しにくい

という性質があります。

UIで全体像を把握するには有用ですが、**研究・分析目的で「Narrativeが何本存在するか」を推定する方法としては、そのまま採用しない方がよい**です。

---

# 4. 推奨する全体アーキテクチャ

## Stage 0：記事をevent表現に変換する

ユーザーのDataFrameは、最低限次の形に正規化します。

```text
article_id
date
headline
body
event_text
embedding
```

### event_text

本文全体を単純連結するより、次のいずれかが適切です。

$$
\text{event\_text}_i
=
\text{headline}_i
+
\text{leadまたは本文要約}_i
$$

または、headlineと本文を別々に埋め込み、

$$
e_i
=
\operatorname{normalize}
\left(
w_h e_i^{\mathrm{headline}}
+
(1-w_h)e_i^{\mathrm{body}}
\right)
$$

とします。

原論文はheadlineを一つのeventとして扱っています。一方、著者自身が、headlineだけでは情報が不足することがあり、full text、適切なsummary、またはheadlineとleadの組み合わせを利用する余地があると述べています。`2009.04508v2.pdf` `2009.04508v2.pdf`

### 本文全体をそのまま使う際の問題

長い本文には、

- 主要イベント
- 過去経緯
- 複数人物の発言
- 一般的な背景説明
- 別の関連イベント

が混在します。そのため本文埋め込みは「同じ一般テーマの記事」を近づける一方、「どのイベントがどのイベントへ進展したか」という経路を弱める可能性があります。

実務的には、まず以下を推奨します。

```text
event_text = headline + 本文冒頭3～5文
```

その後、より高度な仕様では本文から5W1Hまたはevent summaryを抽出します。一記事に明確に複数イベントが含まれる場合は、一記事一nodeではなく、一記事から複数event nodeを生成する方がNarrative Mapの理論に整合します。

---

## Stage 1：独立したNarrative familyを発見する

これは原論文への追加処理です。

### 4.1 記事間の候補edge

記事 $i$ から、それより後の記事 $j$ への親和度を、例えば次で定義します。

$$
A_{ij}
=
\mathbf 1(t_i<t_j)
\left(S_{ij}^{\mathrm{sem}}\right)^{\alpha}
\left(S_{ij}^{\mathrm{entity}}+\varepsilon\right)^{\beta}
\exp\left(-\frac{t_j-t_i}{\tau}\right)
$$

ここで、

- $S^{\mathrm{sem}}$：embeddingの意味類似度
- $S^{\mathrm{entity}}$：人物、企業、国、商品などのentity overlap
- $\tau$：ニュースNarrativeの時間スケール

です。

全記事対全記事の完全graphを作るのではなく、各記事から、

- 時間的に後方
- 一定期間内
- semantic similarity上位 $k$ 件

だけを候補edgeとします。

### 4.2 Narrative familyの分離

候補graphを基に、

- weakly connected components
- community detection
- HDBSCANによるsoft clustering
- 時系列制約付きクラスタリング

のいずれかで、独立Narrative候補を作ります。

ここで得られるfamily数を、

$$
M=\text{number of candidate narrative families}
$$

とします。

ただし、単一のHDBSCAN結果をそのまま真のNarrative数と解釈するのではなく、以下の安定性を確認すべきです。

- embedding modelを変えてもfamilyが維持されるか
- HDBSCANの `min_cluster_size` を変えても維持されるか
- 対象期間を少し前後させても維持されるか
- random seedを変えても構成記事が維持されるか
- family内のentityと時間的連続性が十分か

記事は複数のNarrativeに関係することがあるため、hard assignmentではなく、

$$
P(m\mid i)
$$

を保持し、一定以上のmembershipを持つ複数familyへ記事を重複所属させる仕様が自然です。

---

# 5. Stage 2：各Narrative familyにNarrative Mapを適用する

family $m$ に属する記事だけを取り出し、その中で論文の処理を行います。

## 5.1 Topic clustering

記事embeddingにUMAPとHDBSCANを適用し、

$$
p_i=(p_{i1},\dots,p_{ic})
$$

というtopic membership vectorを推定します。クラスタ数 $c$ はHDBSCANによって自動的に決まるため、事前にtopic数を設定する必要はありません。`2009.04508v2.pdf`

ただし、これはNarrative familyを分離するStage 1とは別です。

- Stage 1のcluster：独立Narrative候補
- Stage 2のcluster：一つのNarrative内のtopic coverage

という役割分担にします。

## 5.2 Coherence

論文準拠のcoherenceは、

$$
C_{ij}
=
\sqrt{
S_{ij}^{\mathrm{event}}
S_{ij}^{\mathrm{topic}}
}
$$

です。

- $S^{\mathrm{event}}$：angular similarity
- $S^{\mathrm{topic}}$：Jensen-Shannon similarity

幾何平均を使うため、一方が低い記事対には強いペナルティがかかります。`2009.04508v2.pdf`

実務拡張として、時間とentityを追加できます。

$$
\widetilde C_{ij}
=
C_{ij}
\exp\left(-\frac{t_j-t_i}{\tau_m}\right)
\left(1+\eta E_{ij}\right)
$$

ただし、最終値は $[0,1]$ に正規化します。

---

# 6. GitHub実装をそのまま利用する場合の注意点

## 6.1 Semantic similarityがUMAP後の表現で計算される

現行コードは、事前計算されたembedding $X$ にUMAPを適用して `clusterable_embedding` を作り、その低次元表現上でangular similarityを計算しています。HDBSCANも同じUMAP表現に適用されています。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

これは可視化・クラスタリングには合理的ですが、Narrative edgeのsemantic similarityまでUMAP空間で計算すると、UMAPによる局所構造の強調や距離変形がそのままcoherenceへ入ります。

推奨仕様は、

- semantic similarity：元の高次元embedding
- topic clustering：UMAP後のembedding
- visualization：2次元UMAP

と分離することです。

## 6.2 Entity similarityはtitleだけから取得される

現行コードのentity tableは、`article["title"]` にNERを適用して作られています。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

本文を保持している場合は、

```text
headline + lead
```

またはevent summaryからentityを抽出した方がよいでしょう。

日本語記事の場合は、GitHub実装が前提とする英語NERやembeddingをそのまま使わず、日本語または多言語対応のsentence embeddingとNERへ置き換える必要があります。

## 6.3 Temporal termの扱い

現行コードは時間距離から、

$$
\exp(-\Delta t/\sigma_t)
$$

を計算していますが、確認した `create_LP` のcoherence式自体はsemantic similarity、cluster similarity、entity multiplier、relevance multiplierから構成されています。時間情報は主に `3\sigma_t` の候補edge windowとして反映されています。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

時間的に近い記事を単に候補へ残すだけでなく、時間差をcoherenceに直接反映したい場合は、上記の $\widetilde C_{ij}$ のように目的関数側へ明示的に入れるべきです。

---

# 7. 開始・終了イベントが不明な場合

原論文はsourceとsinkをユーザーが選ぶことを前提とします。`2009.04508v2.pdf`

任意期間の記事では、期間の最初の記事がNarrativeの真の開始イベントとは限らず、最後の記事が終端とも限りません。そのため、次の順で推奨します。

## 推奨1：仮想source・仮想sink

Narrative familyごとに仮想node $s^\ast,t^\ast$ を追加します。

$$
s^\ast\to
\{\text{初期期間の候補記事}\}
$$

$$
\{\text{終盤期間の候補記事}\}
\to t^\ast
$$

仮想sourceからの接続先は、例えば、

- 時系列上の初期20%の記事
- entity centralityが高い記事
- 後続記事へのsemantic connectivityが高い記事

から選びます。

仮想sinkも同様に終盤記事から選びます。これにより、一つのst-DAGとしての理論構造を維持しながら、実質的なstart/endをモデルに選択させられます。

## 推奨2：複数start・複数end

現行GitHubは複数のstart node、end nodeを受け取る構造を持ちます。各start/endに均等な初期・終端flowを割り当てます。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

## 探索用：start/endなし

現行GitHubのendpointなしモードも利用できます。ただし、

- 一つのNarrative Mapというより複数componentの探索
- globalな $K$ を複数componentで共有
- singletonが発生しやすい
- storylines数の解釈が不安定

となるため、最終的な経路推定には仮想source/sink方式の方が適切です。

---

# 8. Narrative経路の抽出方法

## 8.1 Main route

論文のmain routeは、正規化されたedge probabilityについて、

$$
r^\ast
=
\arg\max_{r:s\rightsquigarrow t}
\prod_{(i,j)\in r}p_{ij}
$$

を満たすpathです。

実装上は、

$$
-\log p_{ij}
$$

をedge costとしてshortest pathを求めます。`2009.04508v2.pdf`

これはそのまま採用できます。

## 8.2 Alternative routes

論文は、すべてのpathを列挙する代わりに、

- main route
- maximum antichainによるrepresentative landmarks

を抽出します。maximum antichainはNarrativeの横断的な代表点を与えますが、各storylineの記事列を明示的に返すものではありません。`2009.04508v2.pdf`

ユーザーの目的は「経路と関連記事の抽出」であるため、alternative routeも明示的に抽出する必要があります。

### 推奨：LP flowのpath decomposition

LPで得られたedge flowを $x_{ij}$ とします。

1. 正のflowを持つsource-sink pathを一本取得
2. そのpathのweightを  
   $$
   w_r=\min_{(i,j)\in r}x_{ij}
   $$
   とする
3. path上の各edgeから $w_r$ を減算
4. 正のsource-sink flowがなくなるまで繰り返す

すると、

$$
x
=
\sum_{r=1}^{R}w_r x^{(r)}
$$

というweighted path decompositionを得られます。

この方法には、

- LPが実際に配分したflowと整合
- 分岐前の共通pathや合流後のpathを保持可能
- routeごとのweightが得られる
- 貪欲node削除よりNarrative Mapの構造に忠実

という利点があります。

### route数の決定

route数 $R$ は事前指定せず、以下で絞ります。

$$
\frac{\sum_{r=1}^{R^\ast}w_r}
{\sum_{r=1}^{R}w_r}
\ge q
$$

となる最小の $R^\ast$ を採用します。

例えば、累積flow mass、minimum path probability、minimum coherence、既存routeとの重複率を組み合わせます。具体的には、

- 累積flow mass
- path内の最低coherence
- route内の記事数
- main routeとのJaccard overlap
- 他routeに対する追加topic coverage

を用いて選択します。

これは論文にはない拡張ですが、経路数を固定せずに主要routeを抽出するという目的に最も整合します。

---

# 9. 「関連記事」は別工程で紐付ける必要がある

Narrative MapのLPは、すべての記事をMapへ残すわけではありません。

論文の事例では102記事から、固定したstart/endに加えて22記事だけが最適解に採用されました。残りの記事は、追加するとcoherenceが低下するためMapから除外されています。`2009.04508v2.pdf`

したがって、次の二種類を分けます。

- **core article**：LPによってNarrative Mapに選択された記事
- **related article**：Mapには選択されなかったが、特定routeと関連する記事

route $r$ に対する未選択記事 $d$ の関連度は、例えば次で定義できます。

$$
R(d,r)
=
\max_{v\in r}
\left[
\alpha S_{\mathrm{sem}}(d,v)
+
\beta S_{\mathrm{topic}}(d,v)
+
\gamma S_{\mathrm{entity}}(d,v)
\right]
\exp\left(
-\frac{|t_d-t_v|}{\tau}
\right)
$$

または、最大値だけでなくroute内上位3記事との平均類似度を使います。

関連記事は排他的に一つのrouteへ割り当てる必要はありません。例えば、ある金融政策記事が、

- inflation route
- bond-market route
- currency route

のすべてに関係することがあります。そのため、multi-label assignmentにします。

$$
d\in r
\quad\Longleftrightarrow\quad
R(d,r)\ge\theta_r
$$

閾値 $\theta_r$ は、少数の人手ラベルまたは類似度分布の上位分位点から決めます。

---

# 10. 推奨する出力DataFrame

## `narratives_df`

```text
narrative_id
n_articles
start_date
end_date
dominant_entities
n_topic_clusters
family_stability
```

## `routes_df`

```text
narrative_id
route_id
route_rank
route_weight
route_probability
n_core_articles
min_edge_coherence
mean_edge_coherence
topic_coverage
```

## `route_articles_df`

```text
narrative_id
route_id
article_id
date
headline
event_order
role               # main / alternative / landmark / related
core_flag
association_score
topic_membership
path_weight
```

## `edges_df`

```text
narrative_id
source_article_id
target_article_id
semantic_similarity
topic_similarity
entity_similarity
temporal_weight
coherence
lp_flow
transition_probability
```

この形で保持すれば、Narrative Mapの可視化だけでなく、

- 各経路の記事一覧
- 経路別ニュース要約
- Narrativeの出現・消滅
- route間の分岐・合流
- topicやentityの変化
- 日次のNarrative intensity

などへ拡張できます。

---

# 11. パラメータの考え方

論文で重要なパラメータは、

- $K$：期待されるmain routeまたは選択node量
- `mincover`：平均topic coverageの下限

です。これらはNarrative数ではありません。著者も、$K$、`mincover`、embedding、クラスタリング設定が最終Mapへ大きく影響すると述べています。`2009.04508v2.pdf`

現行GitHubの既定値は概ね、

```text
K = 6
mincover = 0.20
min_samples = 2
min_cluster_size = 2
n_neighbors = 2
sigma_t = 30
```

です。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

一方、原論文では対象データに対する予備的評価から80% coverageが機能したと報告しています。`2009.04508v2.pdf`

20%と80%には大きな差があるため、固定値をそのまま採用せず、

$$
K\times\mathrm{mincover}\times\tau
$$

のグリッドで、次を比較する必要があります。

- graph feasibility
- route coherence
- topic coverage
- selected article数
- route数
- singleton数
- parameter変更に対するrouteのJaccard安定性
- 重複記事率

---

# 12. 計算量への対応

原論文のLPは、記事数を $n$、topic cluster数を $c$ とすると、pairwise組み合わせが主要なボトルネックとなり、概ね

$$
O(n^2c)
$$

の変数・計算を必要とします。`2009.04508v2.pdf`

したがって、

- 数百記事程度の一つのNarrative family  
  → 比較的直接適用しやすい
- 数千・数万記事の全期間データ  
  → family分割とcandidate edgeのsparsificationが必須

です。

各記事から全未来記事へedgeを作るのではなく、

```text
時間window内
かつ
semantic nearest neighbor上位k件
かつ／または
共通entityを持つ記事
```

だけを候補にするべきです。

長期間については、全期間を一つの静的Mapにするより、重複するrolling windowでMapを作り、前後window間でNarrative familyをmatchingする方が、Narrativeの発生・分岐・消滅を扱いやすくなります。

---

# 13. 最終的な推奨仕様

採用すべき構成は、**論文準拠の最適化をコアにして、GitHubの拡張を選択的に取り込む方式**です。

## 論文から採用

- eventをnodeとするDAG
- semantic similarityとtopic similarityの幾何平均
- HDBSCANによるtopic数の自動推定
- coherence最大化＋coverage制約のLP
- maximum-likelihood main route
- maximum antichainによる横断的landmark

## GitHubから採用

- endpointを任意または複数にする機能
- entity similarity
- temporal candidate window
- regularized LP
- full-text情報の表示
- interactive graph

## 修正すべき点

- 独立Narrative family発見を前段に追加
- semantic similarityはUMAP後ではなく元embeddingで計算
- 日本語・多言語対応embeddingとNERを使用
- 時間減衰をcoherenceへ明示的に反映
- 現行の貪欲node削除によるstoryline抽出をflow decompositionへ変更
- 未選択記事をrouteへ事後的にmulti-label assignment
- $K$ やHDBSCAN cluster数をNarrative数として解釈しない

したがって適用判定は次のとおりです。

$$
\boxed{
\begin{array}{l}
\text{一つのissueに絞られた記事集合}
\Rightarrow
\text{ほぼ直接適用可能}
\\[4pt]
\text{複数の独立issueを含む任意期間の記事集合}
\Rightarrow
\text{事前分割を追加すれば適用可能}
\\[4pt]
\text{Narrative数・経路数をGitHub出力だけで推定}
\Rightarrow
\text{非推奨}
\end{array}
}
$$

最も適切なのは、**Narrative family discovery → family別LP → LP flowのpath decomposition → 全記事のroute assignment**という構成です。これにより、Narrative数を事前に固定せず、主要経路、代替経路、各経路のcore記事と関連記事を一貫した形で抽出できます。

---

**Sources:**

- [](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py)

## Response:
2026/7/27 23:21:27

> **要件定義を検討中**
>
> ユーザーがステージ1の物語家族発見の要件について尋ねています。以前の議論と添付された資料を基に、GitHubの現在の実装も確認する必要がありそうです。
>
> **検討中の要件定義を作成**
>
> 
>
> **検索してGitHubの現在の実装を確認**
>
> [GitHub - everestmz/llmcat: Render LLM-friendly maps of repositories · GitHub](https://github.com/everestmz/llmcat)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **考慮中の要件定義**
>
> ユーザーは実装要件を1つのノートブックで求めているようです。各セルに説明と入力/出力、診断を含む形で、目的はナラティブファミリーを識別することだと思われます。
>
> **考慮した要件定義**
>
> 
>
> **設計とアルゴリズムの選定**
>
> ステージ1のナラティブファミリー発見のために、HDBSCAN、グラフコミュニティ検出、ハイブリッドアプローチのようなアルゴリズムを選ぶ必要があります。基準となる方法を決定するために、各手法を比較します。
>
> **設計とアルゴリズムを選定した**
>
> 
>
> **アルゴリズムの確認**
>
> 長い時系列に対応するため、時間の影響を加味した類似度計算が必要です。HDBSCANなどの手法でセマンティックとエンティティに基づくクラスタリングを提案中です。
>
> **確認したアルゴリズム**
>
> 
>
> 13m 27s考えました

# 実装要件定義：独立した Narrative family の発見

## 1. 位置づけ

作成するノートブック名は、以下を推奨します。

```text
01_discover_narrative_families.ipynb
```

このノートブックの目的は、任意期間のニュース記事集合から、事前に個数を指定せずに、相互に独立性の高い **Narrative family候補**を抽出することです。

ここでいう `Narrative family` は原論文の正式な用語ではありません。原論文は、ある特定のissueに関する文書集合と開始・終了イベントがすでに与えられた状態で、一つのNarrative Mapを構築する問題を扱っています。Narrativeは複数storylineから構成されますが、記事集合全体にいくつの独立Narrativeが含まれるかは推定していません。`2009.04508v2.pdf` `2009.04508v2.pdf`

また、原論文でUMAP＋HDBSCANにより自動推定されるclusterは、一つのNarrative内部のtopic clusterです。これは独立Narrativeの数ではありません。`2009.04508v2.pdf`

現行GitHub実装も、渡された記事集合に対してUMAP、HDBSCAN、LPを適用する構造であり、任意の記事集合を複数の独立Narrativeへ分割する前処理は実装していません。現行コードには時間窓、entity similarity、UMAP＋HDBSCANなどの構成要素はありますが、Narrative family discoveryは本要件で追加する拡張です。これはコード構成からの推論です。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

---

# 2. 基本設計方針

Narrative familyの抽出には、単純な文書embeddingのHDBSCANだけではなく、以下の情報を統合した**疎な記事間グラフ**を構築し、そのcommunityを抽出します。

$$
\boxed{
\text{semantic similarity}
+
\text{lexical continuity}
+
\text{entity continuity}
+
\text{temporal continuity}
}
$$

実装方式は次のとおりです。

```text
記事の正規化・重複排除
        ↓
文書embedding
        ↓
k近傍による候補記事ペアの限定
        ↓
semantic・lexical・entity・time特徴量
        ↓
時間制約付きweighted graph
        ↓
複数パラメータ・複数seedでcommunity detection
        ↓
consensus partition
        ↓
primary familyとsecondary familyへのsoft assignment
        ↓
family品質・安定性診断
```

最終family数 $M$ は入力パラメータにしません。weighted graphのcommunity構造から決定します。

---

# 3. Narrative familyの操作的定義

本ノートブックでは、Narrative familyを以下の条件を満たす記事集合として定義します。

1. 記事間の意味的類似性が高い  
2. 同一または関連する出来事・entity・語彙が継続している  
3. 時間的に大きく断絶していない  
4. family内部の記事間affinityがfamily外部より高い  
5. 後続のNarrative Mapで時系列経路を構成できる程度の内部接続性がある  

V1では、長期間に反復する抽象的なthemeではなく、**時間的に連続したevent episode**をfamilyとして抽出します。

例えば「金融政策」という数年間継続するtheme全体ではなく、

```text
日銀の政策修正観測
→ 政策決定会合
→ 利上げ決定
→ 市場反応
```

のようなepisode単位をfamilyとします。

設定値は以下で固定します。

```python
FAMILY_GRANULARITY = "episode"
```

---

# 4. スコープ

## 4.1 実装対象

ノートブックは以下を実装します。

- 入力DataFrameの検証
- 日付・本文・headlineの正規化
- exact duplicateとnear duplicateの除去
- headline＋本文冒頭によるevent text作成
- multilingual document embedding
- sparse k-nearest-neighbor graph
- semantic similarity
- lexical similarity
- optional entity similarity
- temporal attenuation
- weighted graph community detection
- parameter・seedを変えたconsensus clustering
- family数の自動決定
- primary／secondary family membership
- family品質診断
- representative article抽出
- Stage 2へ渡せるDataFrame生成
- Notebook上での表・図の表示
- 必要最小限のParquet／NPZ出力

## 4.2 実装対象外

以下は本ノートブックには含めません。

- Narrative MapのLP最適化
- source／sinkの最終決定
- main route抽出
- alternative route抽出
- maximum antichain
- LLM APIによるfamily要約
- リアルタイムまたはオンライン更新
- supervised classifierの学習
- 因果関係の推定

本ノートブックはStage 2の入力を生成するところまでとします。

---

# 5. 入力データ要件

## 5.1 必須列

入力は以下のDataFrameです。

```python
articles_df
```

必須列は次の3列です。

| 列 | 型 | 内容 |
|---|---|---|
| `date` | datetime変換可能 | 記事公開日時 |
| `headline` | string | 記事headline |
| `body` | string | 記事本文 |

## 5.2 任意列

以下は存在すれば利用します。

| 列 | 用途 |
|---|---|
| `article_id` | 記事固有ID |
| `source` | 媒体名 |
| `url` | 記事URL |
| `language` | 言語 |
| `entities` | 事前抽出済みentityのlist |
| `category` | 元データのカテゴリ |
| `author` | 著者 |
| `timestamp_updated` | 更新日時 |

`article_id` がない場合は、次の情報からSHA-256ベースのIDを生成します。

```text
date + normalized_headline + normalized_body_prefix
```

## 5.3 日付処理

日付は次の順序で処理します。

```python
pd.to_datetime(df["date"], errors="coerce", utc=True)
```

処理後に、

```text
date
article_id
original_row_number
```

でstable sortし、以下を生成します。

```text
event_order = 0, 1, ..., N-1
```

同一日時の記事についても、`article_id`による決定論的な順序を付与します。

## 5.4 不正行

以下に該当する行は、黙って削除せず `rejected_rows_df` に格納します。

- 日付をparseできない
- headlineが欠損
- headlineとbodyの双方が空
- article_idが重複し、内容も不整合
- event textが最低文字数未満

```text
original_row_number
article_id
rejection_reason
```

を保持します。

---

# 6. Event textの作成

原論文はheadlineをevent単位としています。一方、論文自身もheadlineだけでなくfull text、summary、またはheadline＋leadを利用する拡張を挙げています。`2009.04508v2.pdf` `2009.04508v2.pdf`

本実装では、以下を標準仕様とします。

```text
event_text
    = normalized headline
    + separator
    + bodyの冒頭5文
```

本文全体をそのままembeddingすると、背景説明、過去経緯、引用、複数イベントが混在しやすいため、デフォルトではlead相当部分だけを使用します。

```python
TEXT_MODE = "headline_plus_lead"
LEAD_SENTENCES = 5
MAX_BODY_CHARS = 4_000
MIN_EVENT_TEXT_CHARS = 20
```

処理内容は以下です。

- Unicode NFKC正規化
- HTMLタグ除去
- 制御文字除去
- 連続空白の圧縮
- headline末尾とbody先頭の重複除去
- 最大文字数で切り詰め
- 元headlineとbodyは別途保持

出力列は次のとおりです。

```text
normalized_headline
normalized_body
lead_text
event_text
event_text_hash
```

---

# 7. 重複記事の処理

重複記事をそのままclusterへ入れると、同一配信記事や転載記事だけで一つのfamilyが形成される可能性があります。そのため、community detectionの前に重複排除を行います。

## 7.1 Exact duplicate

以下のいずれかが一致する記事をexact duplicateとします。

- 正規化headlineと本文prefixが完全一致
- URLが完全一致
- `event_text_hash` が一致

## 7.2 Near duplicate

候補記事ペアについて、

$$
\cos(e_i,e_j)\ge\theta_{\mathrm{dup}}
$$

かつ、

$$
|t_i-t_j|\le d_{\mathrm{dup}}
$$

の場合、near duplicate候補とします。

推奨初期値は以下です。

```python
NEAR_DUPLICATE_COSINE = 0.985
NEAR_DUPLICATE_MAX_DAYS = 3
```

near duplicate graphのconnected componentごとに `duplicate_group_id` を付与します。

canonical articleは次の優先順位で決定します。

1. 公開日時が早い  
2. 本文が長い  
3. source、URLが取得できている  
4. article_idが辞書順で小さい  

community detectionにはcanonical articleだけを使用します。

重複記事は最終出力でcanonical articleのfamily assignmentを継承します。

---

# 8. 文書embedding

## 8.1 標準仕様

Sentence Transformersを使用し、CPU、CUDA、MPSを自動判定します。`SentenceTransformer.encode()` はbatch処理とembedding正規化をサポートするため、`normalize_embeddings=True` を使用します。モデル名、revision、cache directoryは設定可能にします。([SentenceTransformers](https://www.sbert.net/docs/package_reference/sentence_transformer/SentenceTransformer.html))

推奨初期設定は次のとおりです。

```python
EMBEDDING_MODEL = (
    "sentence-transformers/"
    "paraphrase-multilingual-mpnet-base-v2"
)

EMBEDDING_MODEL_REVISION = None
EMBEDDING_BATCH_SIZE = 64
NORMALIZE_EMBEDDINGS = True
EMBEDDING_DTYPE = "float32"
```

モデルは設定セルから差し替え可能にします。

## 8.2 UMAPの利用範囲

本実装では、元の高次元embeddingをsemantic similarityに使用します。

UMAPは以下に限定します。

- 2次元可視化
- optional HDBSCAN baseline
- cluster構造の補助診断

現行GitHubコードはUMAP後のembeddingをsemantic similarityにも利用していますが、本要件ではembedding空間と可視化空間を分離します。現行コードではUMAP projection後にangular similarityとHDBSCANが計算されています。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

## 8.3 Embedding cache

再実行時にembeddingを再計算しないよう、以下を含むfingerprintを生成します。

```text
article_id
event_text_hash
embedding model
model revision
text preprocessing parameters
```

保存形式は以下です。

```text
data/interim/
    narrative_family_embeddings_<fingerprint>.npz
```

cacheのfingerprintが一致しない場合は自動的に再計算します。

---

# 9. Candidate pairの生成

すべての記事対を計算すると、

$$
O(N^2)
$$

となるため、候補記事ペアをk近傍に限定します。原論文もpairwise combinationが主要な計算ボトルネックであると述べています。`2009.04508v2.pdf`

## 9.1 k-nearest neighbors

L2正規化embeddingに対してcosine距離によるk近傍を取得します。

```python
KNN_K = 30
KNN_METRIC = "cosine"
```

データ量に応じてbackendを切り替えます。

```text
Nが小さい:
    sklearn.neighbors.NearestNeighbors

Nが大きい:
    pynndescent.NNDescent
```

`NearestNeighbors` は各点のk近傍indexとdistanceを返し、疎なkNN graphも生成できます。([scikit-learn](https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.NearestNeighbors.html))

## 9.2 時間窓

記事 $i,j$ の日付差を、

$$
\Delta t_{ij}=|t_j-t_i|
$$

とします。

候補ペアは、

$$
\Delta t_{ij}\le W
$$

を満たすものに限定します。

推奨初期値は、

```python
TAU_DAYS = 30
MAX_GAP_DAYS = 3 * TAU_DAYS
```

です。

現行GitHub実装も、時間機能を有効化した場合に概ね $3\sigma_t$ を候補時間窓として使用しています。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

ただし、この30日は論文の普遍的な推奨値ではなく、データに合わせて感応度分析する初期値です。

## 9.3 Candidate rule

記事ペア $(i,j)$ は以下のいずれかを満たす場合に候補とします。

```text
jがiのkNN
または
iがjのkNN
または
強いentity overlapがある
```

そのうえで、

```text
event_order_i != event_order_j
delta_days <= MAX_GAP_DAYS
```

を要求します。

---

# 10. 記事間特徴量

候補記事ペアだけについて、以下を計算します。

## 10.1 Semantic similarity

原論文に合わせてangular similarityを使用します。

$$
S_{ij}^{\mathrm{sem}}
=
1-
\frac{
\arccos\left(
\operatorname{clip}(e_i^\top e_j,-1,1)
\right)
}{\pi}
$$

$$
S_{ij}^{\mathrm{sem}}\in[0,1]
$$

embeddingはL2正規化済みとします。

## 10.2 Lexical similarity

日本語・英語の混在に対して形態素解析を必須にしないため、文字n-gram TF-IDFを使用します。

```python
TfidfVectorizer(
    analyzer="char_wb",
    ngram_range=(3, 5),
    min_df=2,
    max_df=0.98,
    sublinear_tf=True,
    norm="l2",
)
```

記事 $i,j$ のTF-IDF vectorを $v_i,v_j$ として、

$$
S_{ij}^{\mathrm{lex}}
=
v_i^\top v_j
$$

とします。

## 10.3 Entity similarity

entity列が入力に存在する場合、またはNER backendが設定されている場合にだけ使用します。

標準V1ではNERモデルを必須依存にせず、以下の優先順位とします。

```text
1. 入力DataFrameのentities列
2. optional NER backend
3. entity similarityを無効化
```

entity similarityはIDF-weighted Jaccardとします。

$$
S_{ij}^{\mathrm{ent}}
=
\frac{
\sum_{u\in E_i\cap E_j}\operatorname{idf}(u)
}{
\sum_{u\in E_i\cup E_j}\operatorname{idf}(u)
}
$$

entityが利用できない場合は、entity weightをsemantic／lexicalへ再配分します。

現行GitHubコードはtitleからentityを抽出し、entity overlapをcoherence multiplierとして利用しています。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

## 10.4 Temporal attenuation

$$
S_{ij}^{\mathrm{time}}
=
\exp\left(
-\frac{\Delta t_{ij}}{\tau}
\right)
$$

時間は類似性を作る要素ではなく、古い記事間接続を弱める要素として使用します。

## 10.5 Content score

$$
C_{ij}
=
\frac{
w_s S_{ij}^{\mathrm{sem}}
+
w_l S_{ij}^{\mathrm{lex}}
+
w_e S_{ij}^{\mathrm{ent}}
}{
w_s+w_l+w_e
}
$$

推奨初期値は以下です。

```python
SEMANTIC_WEIGHT = 0.80
LEXICAL_WEIGHT = 0.20
ENTITY_WEIGHT = 0.00
```

`entities`が有効な場合は、例えば次の設定を使用します。

```python
SEMANTIC_WEIGHT = 0.70
LEXICAL_WEIGHT = 0.20
ENTITY_WEIGHT = 0.10
```

## 10.6 Final affinity

時間が記事接続を単独で作らないよう、次の乗算型attenuationを使用します。

$$
A_{ij}
=
C_{ij}
\left[
(1-\lambda_t)
+
\lambda_t S_{ij}^{\mathrm{time}}
\right]
$$

```python
TEMPORAL_STRENGTH = 0.35
```

したがって、

$$
A_{ij}\in[0,1]
$$

となります。

---

# 11. Edge sparsification

すべてのkNN edgeを残すと、一般的な表現を含む記事が複数familyをつなぐbridgeになりやすいため、edgeをさらに限定します。

## 11.1 Mutual／strong edge rule

候補ペア全体のaffinity分布から、

$$
q_{\mathrm{low}},
q_{\mathrm{high}}
$$

を計算します。

edgeは次のいずれかを満たす場合に採用します。

$$
\text{mutual-kNN}
\land
A_{ij}\ge q_{\mathrm{low}}
$$

または、

$$
A_{ij}\ge q_{\mathrm{high}}
$$

推奨初期値は次です。

```python
EDGE_LOW_QUANTILE = 0.55
EDGE_HIGH_QUANTILE = 0.80
MAX_EDGES_PER_NODE = 15
```

絶対閾値だけに依存せず、データ内のaffinity分布に基づく相対閾値を使用します。

## 11.2 二種類のgraph

以下の2種類を生成します。

### Temporal directed graph

```text
G_temporal: nx.DiGraph
```

日付順に、

$$
i\rightarrow j
\quad\Longleftrightarrow\quad
event\_order_i<event\_order_j
$$

とします。

これはStage 2の候補edgeおよび時間連続性診断に使用します。

### Community graph

```text
G_family: nx.Graph
```

family抽出は対称的な所属関係なので、undirected weighted graphを使用します。

edge weightは、

$$
w_{ij}=A_{ij}
$$

です。

---

# 12. Community detection

## 12.1 標準方式

NetworkXのweighted Louvain community detectionを使用します。

Louvainはcommunity数を引数として要求せず、weighted graphのmodularityを用いてpartitionを返します。`resolution` が1未満なら大きいcommunity、1より大きければ小さいcommunityを形成しやすくなります。また、node処理順序のランダム性が結果に影響し得るため、複数seedを使用します。([NetworkX](https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.community.louvain.louvain_communities.html))

```python
nx.community.louvain_communities(
    G_family,
    weight="weight",
    resolution=resolution,
    seed=seed,
)
```

## 12.2 単一partitionを最終結果にしない

Louvainの一回の出力をそのまま最終familyとしません。

次の組合せで複数回実行します。

```python
RESOLUTION_GRID = (0.70, 1.00, 1.30)
EDGE_QUANTILE_GRID = (0.55, 0.65, 0.75)
COMMUNITY_SEEDS = (17, 42, 97)
```

合計27 runを標準とします。

各runについて以下を保存します。

```text
run_id
resolution
edge_quantile
seed
n_families
n_noise
largest_family_share
modularity
mean_internal_affinity
mean_external_affinity
```

## 12.3 Communityの後処理

各runについて以下を実施します。

1. community内部が複数connected componentsなら分割  
2. `MIN_FAMILY_SIZE` 未満は一旦noise  
3. edgeを持たないisolated nodeはnoise  
4. duplicateはcommunity計算に含めない  
5. family IDはこの段階ではrun固有IDとする  

```python
MIN_FAMILY_SIZE = 5
```

---

# 13. Consensus clustering

複数runで一貫して同じcommunityに入る記事対を抽出します。

記事 $i,j$ のco-assignment scoreを、

$$
P_{ij}
=
\frac{1}{R}
\sum_{r=1}^{R}
\mathbf{1}
\left(
z_i^{(r)}
=
z_j^{(r)}
\ne -1
\right)
$$

とします。

ただし、計算量を抑えるため、全 $N^2$ ペアではなくcandidate edgeに対してのみ計算します。

最終consensus graphのweightは、

$$
W_{ij}^{*}
=
A_{ij}P_{ij}
$$

とします。

以下を満たすedgeのみ残します。

$$
P_{ij}\ge \theta_{\mathrm{consensus}}
$$

```python
CONSENSUS_EDGE_THRESHOLD = 0.60
```

その後、`W*` をweightとするgraphにLouvainを再適用し、最終familyを決定します。

この方式により、単一seedや単一resolutionにだけ現れる不安定なclusterを抑制します。

---

# 14. HDBSCAN baseline

原論文との対応確認のため、UMAP＋HDBSCANによるbaselineも実装します。ただし、最終family決定には使用せず、診断用とします。

```python
RUN_HDBSCAN_BASELINE = True
```

処理は次のとおりです。

```text
original embedding
→ UMAP 10次元
→ HDBSCAN
→ hard label
→ soft membership vector
```

HDBSCANはcluster数を事前指定せず、noiseを含むclusterを推定できます。`all_points_membership_vectors()` は各点についてcluster membership vectorを返します。`2009.04508v2.pdf` ([HDBSCAN](https://hdbscan.readthedocs.io/en/latest/soft_clustering.html))

baselineとの比較指標は以下です。

- family数
- noise率
- Adjusted Rand Index
- Adjusted Mutual Information
- cluster size分布
- graph familyとの対応表

ここでのHDBSCAN clusterはあくまでsemantic clusterであり、最終Narrative familyとは解釈しません。

---

# 15. Soft family membership

community detectionはhard partitionを返しますが、記事は複数Narrativeに関係する可能性があります。

そのため、最終結果では、

- primary family
- secondary family
- ambiguous
- noise

を区別します。

## 15.1 Family centroid

family $m$ のembedding centroidを、

$$
\mu_m
=
\operatorname{normalize}
\left(
\frac{1}{|F_m|}
\sum_{j\in F_m}e_j
\right)
$$

とします。

## 15.2 Membership raw score

記事 $i$ のfamily $m$ に対するscoreは、

$$
u_{im}
=
\alpha
S^{\mathrm{sem}}(e_i,\mu_m)
+
(1-\alpha)
\frac{
\sum_{j\in F_m} A_{ij}
}{
\sum_j A_{ij}+\varepsilon
}
$$

とします。

```python
CENTROID_MEMBERSHIP_WEIGHT = 0.60
GRAPH_MEMBERSHIP_WEIGHT = 0.40
```

softmaxを適用します。

$$
p_{im}
=
\frac{
\exp(u_{im}/T)
}{
\sum_{\ell}\exp(u_{i\ell}/T)
}
$$

ただし、`p_im` は統計的にcalibrateされた確率ではないため、出力名は `membership_score` とします。

## 15.3 Assignment rule

推奨初期値は以下です。

```python
CORE_MEMBERSHIP_MIN = 0.60
PRIMARY_MEMBERSHIP_MIN = 0.45
SECONDARY_MEMBERSHIP_MIN = 0.25
AMBIGUITY_MARGIN_MIN = 0.10
MAX_SECONDARY_FAMILIES = 2
```

分類は次のとおりです。

| status | 条件 |
|---|---|
| `core` | primary score ≥ 0.60、marginも十分 |
| `peripheral` | primary score ≥ 0.45 |
| `ambiguous` | top1とtop2の差が0.10未満 |
| `noise` | どのfamilyにも十分所属しない |
| `duplicate` | canonical articleの所属を継承 |

hardな独立partitionにはprimary familyを使い、Stage 2で関連記事を補う場合はsecondary familyも使用します。

---

# 16. Family品質指標

各familyについて以下を計算します。

## 16.1 Internal affinity

$$
I_m
=
\frac{1}{|E_m|}
\sum_{(i,j)\in E_m}A_{ij}
$$

## 16.2 External affinity

$$
X_m
=
\frac{1}{|E_m^{\mathrm{cross}}|}
\sum_{\substack{i\in F_m\\j\notin F_m}}
A_{ij}
$$

## 16.3 Separation

$$
\operatorname{separation}_m
=
I_m-X_m
$$

## 16.4 Temporal continuity

family内の記事について、

- 同じfamilyの過去記事へのedge
- 同じfamilyの将来記事へのedge

の少なくとも一方を持つ記事比率を計算します。

## 16.5 Stability

family内部candidate edgeの平均consensus scoreを、

$$
\operatorname{stability}_m
=
\frac{1}{|E_m|}
\sum_{(i,j)\in E_m}P_{ij}
$$

とします。

## 16.6 その他

- canonical article数
- duplicateを含む総記事数
- 開始日・終了日
- duration
- weighted density
- conductance
- source HHI
- duplicate share
- ambiguous share
- centroid similarity to nearest family
- family内最大time gap
- connected component数

## 16.7 Quality flag

以下を満たすfamilyを `accepted` とします。

```text
n_canonical >= MIN_FAMILY_SIZE
stability >= 0.60
separation > 0
temporal_continuity >= 0.60
connected_components == 1
```

満たさない場合も削除せず、以下を付与します。

```text
low_stability
weak_separation
poor_temporal_continuity
too_small
merge_candidate
split_candidate
```

---

# 17. Representative article

各familyについて次の2種類の代表性を計算します。

1. family embedding centroidに近い  
2. family graph内でcentralityが高い  

各記事について、

```text
centroid_distance_rank
graph_centrality_rank
```

を求め、その平均rankが最小の記事をrepresentative articleとします。

出力は以下です。

```text
representative_article_id
representative_headline
representative_date
top_3_representative_article_ids
```

family labelは、外部LLMを使わず次の形式とします。

```text
F0001 | representative headline
```

補助情報として、

- 代表headline上位3件
- dominant entities
- family内TF-IDF上位語
- start／end date

を表示します。

---

# 18. 出力オブジェクト

ノートブック内に以下のdataclassを定義します。

```python
@dataclass
class NarrativeFamilyResult:
    articles: pd.DataFrame
    families: pd.DataFrame
    memberships: pd.DataFrame
    edges: pd.DataFrame
    duplicates: pd.DataFrame
    rejected_rows: pd.DataFrame
    run_diagnostics: pd.DataFrame
    embeddings: np.ndarray
    family_graph: nx.Graph
    temporal_graph: nx.DiGraph
    config: dict
    fingerprint: str
```

エントリポイントは次の形とします。

```python
result = discover_narrative_families(
    articles_df=articles_df,
    config=CONFIG,
)
```

---

# 19. 出力DataFrame要件

## 19.1 `result.articles`

| 列 | 内容 |
|---|---|
| `article_id` | 記事ID |
| `canonical_article_id` | canonical ID |
| `date` | 公開日時 |
| `event_order` | 時系列順 |
| `headline` | 元headline |
| `body` | 元本文 |
| `event_text` | embedding用テキスト |
| `is_duplicate` | duplicate flag |
| `duplicate_group_id` | duplicate group |
| `primary_family_id` | primary family |
| `primary_membership_score` | primary score |
| `secondary_family_ids` | secondary family list |
| `secondary_membership_scores` | secondary scores |
| `assignment_status` | core/peripheral等 |
| `family_stability_score` | 所属安定度 |
| `baseline_hdbscan_label` | 診断用label |

## 19.2 `result.families`

| 列 | 内容 |
|---|---|
| `family_id` | `F0001`形式 |
| `n_canonical_articles` | canonical記事数 |
| `n_all_articles` | duplicateを含む記事数 |
| `start_date` | 開始日 |
| `end_date` | 終了日 |
| `duration_days` | 期間 |
| `representative_article_id` | 代表記事 |
| `representative_headline` | 代表headline |
| `top_article_ids` | 上位記事 |
| `dominant_entities` | 主要entity |
| `mean_internal_affinity` | 内部affinity |
| `mean_external_affinity` | 外部affinity |
| `separation` | 内外差 |
| `stability` | consensus安定性 |
| `temporal_continuity` | 時間連続性 |
| `weighted_density` | weighted density |
| `ambiguity_ratio` | 曖昧記事比率 |
| `quality_flag` | accepted／review |
| `suggested_start_article_ids` | Stage 2用候補 |
| `suggested_end_article_ids` | Stage 2用候補 |

## 19.3 `result.edges`

```text
source_article_id
target_article_id
source_event_order
target_event_order
delta_days
semantic_similarity
lexical_similarity
entity_similarity
temporal_similarity
content_score
affinity
is_mutual_knn
candidate_rule
retained_in_base_graph
consensus_score
final_edge_weight
same_final_family
```

## 19.4 `result.memberships`

long形式とします。

```text
article_id
family_id
membership_raw_score
membership_score
membership_rank
is_primary
is_secondary
assignment_status
```

## 19.5 `result.run_diagnostics`

```text
run_id
seed
resolution
edge_quantile
n_families
noise_rate
largest_family_share
modularity
mean_internal_affinity
mean_separation
median_family_stability
```

---

# 20. Stage 2への引き渡し

各familyについて、以下のhelper関数を実装します。

```python
stage2_df = make_stage2_input(
    result=result,
    family_id="F0001",
    include_secondary=True,
    secondary_threshold=0.30,
    include_duplicates=False,
)
```

出力列は最低限以下とします。

```text
article_id
date
event_order
headline
body
event_text
embedding
family_id
family_membership_score
assignment_status
```

Stage 2に渡すDataFrameは必ず、

```python
sort_values(["date", "event_order"])
```

とします。

duplicate記事は関連記事情報として保持しますが、Narrative Mapのnodeには原則としてcanonical articleだけを使用します。

---

# 21. Notebookのセル構成

すべての関数、設定、実行処理を一つのNotebook内に実装します。.pyファイルは作成しません。

| セクション | 内容 | Notebook上の出力 |
|---|---|---|
| 0 | タイトル・目的 | Markdown |
| 1 | 論文との関係・Stage 1の定義 | 数式・処理図 |
| 2 | Configuration | 全パラメータ表 |
| 3 | Imports・環境確認 | Python、device、version |
| 4 | 入力DataFrame取得 | shape、列、期間 |
| 5 | 入力QA | 欠損・重複・不正日付 |
| 6 | テキスト正規化 | 処理前後サンプル |
| 7 | Exact duplicate | duplicate件数 |
| 8 | Embedding生成／cache | shape、norm分布 |
| 9 | Near duplicate | duplicate group表 |
| 10 | kNN candidate生成 | edge数、degree分布 |
| 11 | Pair feature計算 | similarity分布 |
| 12 | Base graph構築 | node数、edge数、density |
| 13 | 複数community run | run diagnostics |
| 14 | Consensus graph | consensus分布 |
| 15 | Final family抽出 | family size表 |
| 16 | Soft membership | ambiguous／noise表 |
| 17 | Family summary | representative記事 |
| 18 | HDBSCAN baseline | 比較表 |
| 19 | 可視化 | UMAP、timeline等 |
| 20 | Stage 2入力生成 | family別サンプル |
| 21 | QA・assertions | PASS／WARN／FAIL |
| 22 | 出力保存 | 保存ファイル一覧 |
| 23 | 最終サマリー | family数・品質概要 |

各コードセルの直前に日本語Markdownで以下を記載します。

```text
処理目的
入力
主要パラメータ
出力
注意点
```

---

# 22. 可視化要件

Notebook上に最低限、以下を表示します。

## 22.1 データ診断

- 記事数の時系列推移
- headline／body文字数分布
- duplicate率
- 言語別件数
- source別件数

## 22.2 Similarity診断

- semantic similarity分布
- lexical similarity分布
- affinity分布
- affinityとtime gapのscatter
- retained／rejected edge比較

## 22.3 Graph診断

- degree分布
- connected component size
- edge数とnode数
- giant component share

## 22.4 Family診断

- UMAP 2次元scatter
- family別記事timeline
- family size bar chart
- family stability
- internal vs external affinity
- family centroid similarity matrix
- ambiguous／noise記事一覧

UMAP 2次元座標は可視化専用とし、family affinity計算には使用しません。

---

# 23. QA・assertion要件

## 23.1 入力QA

```python
assert articles_df is not None
assert required_columns <= set(df.columns)
assert article_id is unique after generation
assert date has no NaT in accepted rows
assert event_order is monotonic increasing
```

## 23.2 Embedding QA

```python
assert embeddings.ndim == 2
assert embeddings.shape[0] == n_canonical
assert np.isfinite(embeddings).all()
assert np.allclose(
    np.linalg.norm(embeddings, axis=1),
    1.0,
    atol=1e-3,
)
```

## 23.3 Edge QA

```python
assert source_id != target_id
assert source_event_order < target_event_order
assert 0 <= affinity <= 1
assert 0 <= consensus_score <= 1
assert no duplicate edge
```

## 23.4 Graph QA

```python
assert nx.is_directed_acyclic_graph(G_temporal)
assert no self loops
assert every accepted family is connected in G_family
```

## 23.5 Assignment QA

canonical記事は必ず次のいずれかでなければなりません。

```text
core
peripheral
ambiguous
noise
```

duplicate記事は必ずcanonical articleを参照します。

## 23.6 Warning条件

以下はhard errorではなく警告として表示します。

```text
noise率 > 50%
最大familyが全記事の50%以上
family数がparameter run間で大きく変動
median stability < 0.60
internal affinity <= external affinity
temporal continuity < 0.60
duplicate率 > 30%
accepted familyが0件
```

---

# 24. 推奨初期パラメータ

以下は論文由来の固定値ではなく、実装開始時の基準値です。

```python
CONFIG = {
    # Reproducibility
    "random_seed": 42,

    # Input
    "date_col": "date",
    "headline_col": "headline",
    "body_col": "body",
    "article_id_col": None,

    # Text
    "text_mode": "headline_plus_lead",
    "lead_sentences": 5,
    "max_body_chars": 4_000,
    "min_event_text_chars": 20,

    # Embedding
    "embedding_model": (
        "sentence-transformers/"
        "paraphrase-multilingual-mpnet-base-v2"
    ),
    "embedding_batch_size": 64,
    "normalize_embeddings": True,

    # Duplicate
    "near_duplicate_cosine": 0.985,
    "near_duplicate_max_days": 3,

    # Candidate graph
    "knn_k": 30,
    "tau_days": 30,
    "max_gap_days": 90,
    "max_edges_per_node": 15,

    # Affinity
    "semantic_weight": 0.80,
    "lexical_weight": 0.20,
    "entity_weight": 0.00,
    "temporal_strength": 0.35,

    # Consensus community detection
    "resolution_grid": (0.70, 1.00, 1.30),
    "edge_quantile_grid": (0.55, 0.65, 0.75),
    "community_seeds": (17, 42, 97),
    "consensus_edge_threshold": 0.60,
    "min_family_size": 5,

    # Membership
    "core_membership_min": 0.60,
    "primary_membership_min": 0.45,
    "secondary_membership_min": 0.25,
    "ambiguity_margin_min": 0.10,
    "max_secondary_families": 2,

    # Baseline
    "run_hdbscan_baseline": True,

    # Cache / save
    "cache_embeddings": True,
    "save_outputs": True,
}
```

---

# 25. 保存ファイル

大量の中間ファイルは作成せず、以下に限定します。

```text
data/interim/
    narrative_family_embeddings_<fingerprint>.npz
    narrative_family_pair_features_<fingerprint>.parquet

outputs/narrative_family_discovery/
    family_articles.parquet
    family_summary.parquet
    family_memberships.parquet
    family_edges.parquet
    run_diagnostics.parquet
    duplicate_mapping.parquet
    rejected_rows.parquet
    run_metadata.json
```

図表は原則としてNotebook上に表示し、PNGの自動大量保存は行いません。

---

# 26. 依存ライブラリ

Python 3.12を前提に、依存関係は`uv`で管理します。

```bash
uv add \
  pandas \
  numpy \
  scipy \
  scikit-learn \
  sentence-transformers \
  torch \
  networkx \
  umap-learn \
  hdbscan \
  matplotlib \
  pyarrow \
  tqdm \
  pynndescent
```

Notebook内での`pip install`は行いません。

NERを使用する場合だけ、別途optional dependencyを追加します。NERなしでもsemantic＋character n-gram lexical similarityにより、Notebook全体が実行できる仕様にします。

---

# 27. 計算量要件

主要処理の計算量は次を目標とします。

| 処理 | 計算量 |
|---|---:|
| Embedding | $O(N)$ |
| kNN | backend依存 |
| Pair features | $O(Nk)$ |
| Graph storage | $O(Nk)$ |
| Community detection | 疎graphに依存 |
| Consensus | $O(RNk)$ |

通常処理で $N\times N$ のdense similarity matrixは作成しません。

例外として、以下の場合だけdense matrixを許可します。

```python
N <= DENSE_MATRIX_MAX_N
```

推奨値は、

```python
DENSE_MATRIX_MAX_N = 3_000
```

です。

---

# 28. Definition of Done

実装完了条件は以下です。

1. `articles_df`を設定するだけでNotebookが上から下まで実行できる  
2. family数をユーザーが指定しない  
3. 同じ入力・設定・seedで同じ結果を得られる  
4. exact／near duplicateがfamily数を不当に増やさない  
5. semantic、lexical、temporalの各寄与を確認できる  
6. familyごとに記事、代表記事、期間、品質指標を取得できる  
7. primaryとsecondary familyを区別できる  
8. noiseおよびambiguous記事を明示できる  
9. familyのparameter stabilityを確認できる  
10. HDBSCAN baselineとgraph familyを比較できる  
11. accepted familyが時間的・グラフ的に接続している  
12. Stage 2用DataFrameをfamily別に生成できる  
13. future-directed edgeが一件も存在しない  
14. 大規模なdense pairwise matrixを通常処理で生成しない  
15. 各処理セルで入力・出力を目視確認できる  
16. 最終セルにPASS／WARN／FAILのQA summaryを表示する  

この仕様では、**semantic topicの単純クラスタリングではなく、時間的に連続し、関連記事間の接続構造が安定しているevent episodeをNarrative familyとして抽出**します。そのうえで、primary familyによる独立partitionとsecondary membershipによる重複関係を両方保持し、次段階のNarrative Map最適化へ渡せる構造にします。

---

**Sources:**

- [https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py)
- [https://www.sbert.net/docs/package_reference/sentence_transformer/SentenceTransformer.html](https://www.sbert.net/docs/package_reference/sentence_transformer/SentenceTransformer.html)
- [https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.NearestNeighbors.html](https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.NearestNeighbors.html)
- [https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.community.louvain.louvain_communities.html](https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.community.louvain.louvain_communities.html)
- [https://hdbscan.readthedocs.io/en/latest/soft_clustering.html](https://hdbscan.readthedocs.io/en/latest/soft_clustering.html)

## Response:
2026/7/27 23:59:54

> **パーソナライズ中**
>
>
> **パーソナライズ設定を確認し、実装構造を特定した**
>
> 
>
> 33m 1s考えました

## 実装済みNotebook

[01_discover_narrative_families.ipynb をダウンロード](sandbox:/mnt/data/01_discover_narrative_families.ipynb)

Notebookは単体完結で、全コードセルを実行済みです。構文・Notebook形式を検証し、実行エラーがないことも確認しています。

原論文は、あらかじめ「特定のissueに関する記事集合」と開始・終了イベントが与えられた状態で、一つのNarrative Mapを構築する問題を対象としています。したがって、本NotebookのNarrative family discoveryは、その前段に追加した拡張処理です。`2009.04508v2.pdf`  
一方、クラスタ数を事前指定せずにUMAP＋HDBSCANを利用する考え方は原論文に沿っており、Notebook内でも診断用baselineとして実装しています。`2009.04508v2.pdf`

## 実装内容

Notebookには、以下をすべて含めています。

- `date`、`headline`、`body`を持つDataFrameの入力検証
- headline＋本文冒頭からのevent text生成
- Unicode・HTML・空白等のテキスト正規化
- 不正行の隔離と理由記録
- exact duplicateおよびnear duplicateの統合
- Sentence Transformerによる多言語embedding
- 事前計算embeddingの利用
- 軽量なTF-IDF＋TruncatedSVD fallback
- embedding cacheとfingerprint管理
- cosineから変換したangular semantic similarity
- 文字n-gram TF-IDFによるlexical similarity
- 任意の`entities`列を使ったIDF-weighted Jaccard similarity
- 時間減衰を含む記事間affinity
- k-nearest-neighborによる疎なcandidate graph
- 複数resolution・edge threshold・random seedによるLouvain反復
- co-assignmentに基づくconsensus graph
- Narrative family数の自動決定
- primary／secondary soft membership
- `core`、`peripheral`、`ambiguous`、`noise`の分類
- familyごとの代表記事、主要entity、上位語、期間
- internal／external affinity、separation、stability、temporal continuity
- Stage 2向け開始・終了記事候補
- HDBSCAN baselineとのARI・AMI比較
- DataFrame、グラフ、埋め込み、設定をまとめた結果dataclass
- QAのPASS／WARN／FAIL判定
- ParquetまたはCSV、NPZ、JSONへの保存
- family別Stage 2入力DataFrameの生成
- family size、timeline、stability、embedding projectionなどの可視化

原論文でも、embedding空間、クラスタリング手法、期待経路長、coverageなどのパラメータが最終表現へ大きく影響すると指摘されています。そのためNotebookでは単一partitionを採用せず、複数設定によるconsensusと安定性診断を実装しています。`2009.04508v2.pdf`

## 実データへの切り替え

入力セルを次のように変更します。

```python
USE_DEMO_DATA = False
articles_df = your_dataframe.copy()
```

必須列は次の3列です。

```text
date
headline
body
```

任意列として以下を利用できます。

```text
article_id
source
url
language
entities
```

`entities`は、人物、企業、国、政策、商品などをlist形式で保持する想定です。存在しない場合も、semantic similarityとlexical similarityだけで実行できます。

実データでは、Configurationセルの以下が標準設定です。

```python
CONFIG["embedding_backend"] = "sentence_transformer"
CONFIG["embedding_model"] = (
    "sentence-transformers/"
    "paraphrase-multilingual-mpnet-base-v2"
)
```

依存関係はNotebook冒頭に`uv add`形式で記載しており、Notebook内で`pip install`は実行しません。

## 主要出力

実行後の中心オブジェクトは`result`です。

```python
result.articles
```

記事ごとのprimary family、secondary family、duplicate、assignment statusを保持します。

```python
result.families
```

familyごとの期間、代表記事、記事数、安定性、分離度、時間連続性、品質フラグを保持します。

```python
result.memberships
```

記事×familyのlong形式soft membershipです。

```python
result.edges
```

candidate edgeごとのsemantic、lexical、entity、temporal similarity、affinity、consensus scoreを保持します。

```python
result.run_diagnostics
```

resolution、edge threshold、seedを変えた各community detection runの診断結果です。

## Stage 2への受け渡し

任意のfamilyを次のように抽出できます。

```python
stage2_df = make_stage2_input(
    result=result,
    family_id="F0001",
    include_secondary=False,
    include_primary_ambiguous=False,
    include_duplicates=False,
)
```

出力には次が含まれます。

```text
article_id
date
event_order
headline
body
event_text
embedding
family_id
family_membership_score
assignment_status
```

`include_primary_ambiguous=False`が既定であるため、hard communityには属していてもsoft membershipが曖昧な記事は、Narrative Mapのcore node候補から除外されます。

## 実行確認結果

付属の合成データでは、以下を確認しています。

- 36記事を入力
- canonical article：34件
- duplicate：2件
- Narrative family：3個
- 既知の3episodeに対するAdjusted Rand Index：`1.000`
- 既知episode記事のhard-family coverage：`100%`
- 3familyすべての品質判定：`accepted`
- QA assertion：実行エラーなし

付属demoでは、無関係なone-off記事の一つがhard communityへ入るケースも意図的に残していますが、soft membershipでは`ambiguous`と判定され、Stage 2入力から既定で除外されます。これにより、hard partitionだけを過信せず、soft assignmentと品質診断を併用する挙動を確認できます。

## Response:
2026/7/28 22:25:49

> **ノートブック内容のインスペクト**
>
>
> **インスペクトし、ノートブックのセルを解析して抽出**
>
> 
>
> **Searching GitHub for Stage 2 implementation details**
>
> [GitHub - everestmz/llmcat: Render LLM-friendly maps of repositories · GitHub](https://github.com/everestmz/llmcat)
> [tapestry.md · GitHub](https://gist.github.com/flyingmachine/5049858)
>
> **2件のウェブサイトを検索しました**
>
> 
>
> **設計の考慮**
>
> ステージ1の出力を再利用し、計算を避ける方法に注意を払いながら、ステージ2の設計を行う必要があります。別のノートブックでステージ2を独立させて動作させる方法を決めます。
>
> **設計を考慮した**
>
> 
>
> **Inspecting Stage1 notebook functions**
>
>
> **Inspecting Stage1 notebook functions**
>
> 
>
> **ステージ2の設計**
>
> ステージ2の実装は、ステージ1との連携を念頭において進める必要があります。主なタスクはナarrativeマップの抽出とルート、関連記事のマッピングです。
>
> **設計したステージ2**
>
> 
>
> **トピックのクラスタリング方針**
>
> ファミリごとのトピッククラスタリングでは、手動の選択肢に加え、HDBSCANやUMAPを使って、クラスタの可視化と雑音処理に注意を払いながら実装します。
>
> **クラスタリング方針を計画した**
>
> 
>
> **候補エッジの設計**
>
> ステージ1で使用したファミリーエッジを再利用し、密なペアやkNNで一貫性を高める方法を考慮。スタートからエンドまでのパスが確保できるように設計します。
>
> **設計した候補エッジ**
>
> 
>
> **検査と出力生成**
>
>
> **検査し出力を生成した**
>
> 
>
> 14m 15s考えました

# Stage 2 実装要件定義

作成するNotebook名は、以下を推奨します。

```text
02_extract_narrative_maps.ipynb
```

既存の [Stage 1 Notebook](sandbox:/mnt/data/01_discover_narrative_families.ipynb) を確認したうえで、Stage 2は次の構造とします。

$$
\boxed{
\text{Stage 1のNarrative family}
\rightarrow
\text{family内topic推定}
\rightarrow
\text{coherence計算}
\rightarrow
\text{LPによるNarrative Map}
\rightarrow
\text{main route・代替route}
\rightarrow
\text{関連記事の紐付け}
}
$$

論文が直接定義しているのは、あるissueに関する記事集合と開始・終了イベントから、単一source・単一sinkを持つweighted DAGを構築し、そのsource-sink pathをstorylineとして扱う処理です。`2009.04508v2.pdf`  
本要件では、その論文実装をコアにしながら、Stage 1との接続、複数endpoint候補の探索、全routeの抽出、未選択関連記事のroute assignmentを追加します。

---

# 1. Stage 2の目的

Stage 1で抽出された各Narrative familyについて、次を生成します。

1. family内の記事を表すNarrative Map
2. constituent eventsからなるmain route
3. supplementary eventsを含むalternative routes
4. representative landmarks
5. Mapに選択されなかった関連記事と各routeの関連度
6. endpoint、$K$、`mincover`に対する感応度
7. Stage 2結果の再現・監査に必要な全中間データ

論文ではmain routeをmaximum-likelihood path、representative landmarksをmaximum antichainとして定義しています。`2009.04508v2.pdf`

---

# 2. 論文・GitHub・本実装の役割分担

| 機能 | 論文準拠 | GitHub実装 | 本Notebookでの方針 |
|---|---:|---:|---|
| eventをnodeとして扱う | 採用 | 採用 | 採用 |
| 時系列DAG | 採用 | 採用 | 採用 |
| 単一source・sink | 採用 | 任意・複数対応 | 最終Mapは単一source・sink |
| UMAP＋HDBSCAN | 採用 | 採用 | family内topic推定に使用 |
| event similarity | angular similarity | UMAP後の表現でも計算 | Stage 1の元embeddingで計算 |
| topic similarity | JS similarity | 採用 | 採用 |
| coherence | 2要素の幾何平均 | entity・relevanceも乗算可能 | 論文式を標準、拡張式を任意 |
| LP変数 | continuous flow | continuous flow | continuous flow |
| main route | maximum-likelihood path | shortest path | 採用 |
| representative landmark | maximum antichain | centroid／centrality等 | 両方出力 |
| alternative routes | 明示列挙なし | main pathのnodeを削除して再帰 | flow decompositionを標準 |
| 関連記事 | 対象外 | 対象外 | routeへのmulti-label assignment |

現行GitHubコードでも、node activity、edge flow、cluster activityは0-1の連続変数として定義されています。また、coherenceにはsemantic similarity、cluster similarity、entity、relevanceを組み合わせる実装があります。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

一方、GitHubの`graph_stories`は、抽出したmaximum-likelihood chainの全nodeを削除して次のrouteを求めています。この方法では共通幹線や分岐・再合流を複数routeで共有できないため、本実装では標準方式にしません。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/graph_utils.py))

---

# 3. Stage 1との接続契約

## 3.1 標準接続方式

Stage 2は、Stage 1 Notebookを`%run`したり、その関数をimportしたりしません。別Notebookとして独立実行できるよう、Stage 1の保存ファイルを読み込みます。

標準設定は以下です。

```python
INPUT_MODE = "stage1_output_dir"

STAGE1_OUTPUT_DIR = Path(
    "outputs/narrative_family_discovery"
)
```

Stage 1が保存する次のファイルを利用します。

```text
family_articles.parquet または .csv
family_summary.parquet または .csv
family_memberships.parquet または .csv
family_edges.parquet または .csv
canonical_embeddings.npz
run_metadata.json
qa_summary.parquet または .csv
```

## 3.2 任意の接続方式

以下にも対応します。

```python
INPUT_MODE = "in_memory_result"
```

同一kernelにStage 1の`result: NarrativeFamilyResult`が存在する場合に使用します。

```python
INPUT_MODE = "stage2_dataframe"
```

Stage 1の以下の関数で作成したDataFrameを直接設定する場合に使用します。

```python
stage2_df = make_stage2_input(
    result=result,
    family_id="F0001",
    include_secondary=False,
    include_primary_ambiguous=False,
    include_duplicates=False,
)
```

ただし、標準運用はファイル接続とします。

---

# 4. Stage 1から受け取る情報

## 4.1 記事情報

最低限、次の列を読み込みます。

```text
article_id
canonical_article_id
date
event_order
headline
body
event_text
source
url
entities
primary_family_id
primary_membership_score
assignment_status
is_duplicate
```

## 4.2 family情報

`family_summary`から次を利用します。

```text
family_id
quality_flag
quality_flags
n_canonical_articles
start_date
end_date
representative_article_id
suggested_start_article_ids
suggested_end_article_ids
stability
separation
temporal_continuity
```

## 4.3 soft membership

`family_memberships`のlong形式を標準として使用します。

```text
article_id
family_id
membership_score
membership_raw_score
membership_rank
is_primary
is_secondary
assignment_status
```

記事DataFrame内の`secondary_family_ids`のlist列を解析するより、long形式の`family_memberships`を優先します。

## 4.4 embedding

`canonical_embeddings.npz`の以下を読み込みます。

```text
embeddings
article_ids
```

`article_id → embedding`の一対一対応を検証します。

Stage 2では原則としてembeddingを再計算しません。Stage 1と同じ表現空間を使用することで、family discoveryとNarrative Mapの意味表現を整合させます。

---

# 5. family選択要件

## 5.1 family selection mode

以下を切り替えられるようにします。

```python
FAMILY_SELECTION_MODE = "accepted"
```

選択肢は次です。

| mode | 処理 |
|---|---|
| `accepted` | `quality_flag == "accepted"`のみ |
| `all` | reviewを含む全family |
| `manual` | `FAMILY_IDS`で指定 |
| `single` | 一つのfamilyのみ |

```python
FAMILY_IDS = ["F0001"]
```

## 5.2 minimum size

Narrative Mapは理論上2記事から作成できますが、topicとalternative routeを扱うため、標準では次を要求します。

```python
MIN_MAP_CANDIDATES = 5
```

記事数が、

- 2未満：実行不可
- 2～4：単純timelineモード
- 5以上：通常Narrative Mapモード

とします。

---

# 6. 記事集合を二つに分ける

Narrative Mapの最適化対象と、関連記事探索対象を分離します。

## 6.1 Core candidate pool

LPに投入する記事です。

標準条件は、

```text
primary_family_id == family_id
assignment_status in {"core", "peripheral"}
is_duplicate == False
embeddingが存在
```

とします。

曖昧記事、secondary所属記事、duplicateは標準ではLPへ入れません。

## 6.2 Extended related pool

関連記事候補として以下を保持します。

```text
Core candidate pool
＋ primaryだがambiguousの記事
＋ secondary membershipが閾値以上の記事
＋ duplicate記事
```

```python
RELATED_SECONDARY_THRESHOLD = 0.30
```

この分離により、Narrative Map本体はfamilyの中心記事で構築し、境界的・重複的な記事は後段でrouteへ関連付けられます。

---

# 7. Event表現

Stage 2はStage 1で作成した`event_text`をそのまま使用します。

標準では、

```text
event_text = headline + 本文冒頭5文
```

です。

原論文はheadlineをevent単位としていますが、headline＋leadまたはsummaryを使う拡張も妥当だと明記しています。`2009.04508v2.pdf` `2009.04508v2.pdf`

一記事に複数イベントが含まれる問題はStage 2では分割せず、一記事一nodeとします。これは明示的な制約としてNotebook冒頭に記載します。

---

# 8. family内topic推定

Stage 1のNarrative family labelをtopicとして再利用してはいけません。

- Stage 1：独立Narrative familyの分離
- Stage 2：一つのNarrative family内部のtopic推定

という別の役割です。

## 8.1 UMAP

Stage 1から受け取ったembedding $e_i$ に対し、familyごとにUMAPを適用します。

```python
TOPIC_UMAP_COMPONENTS = 5
TOPIC_UMAP_MIN_DIST = 0.0
TOPIC_UMAP_METRIC = "cosine"
TOPIC_UMAP_RANDOM_STATE = 42
```

`n_neighbors`は記事数 $n$ に応じて、

$$
n_{\mathrm{neighbors}}
=
\min(15,\max(2,n-1))
$$

とします。

UMAPはtopic clusteringの前処理と可視化だけに使います。semantic similarityは元の高次元embeddingで計算します。

現行GitHubはUMAP後の表現上でもangular similarityを計算していますが、本実装ではUMAPによる距離変形をevent similarityへ混入させない設計とします。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

## 8.2 HDBSCAN

```python
HDBSCAN_MIN_CLUSTER_SIZE = "auto"
HDBSCAN_MIN_SAMPLES = 1
HDBSCAN_CLUSTER_SELECTION_METHOD = "eom"
HDBSCAN_PREDICTION_DATA = True
```

自動値は、

$$
\mathrm{min\_cluster\_size}
=
\max
\left(
2,
\min\left(10,\mathrm{round}(\sqrt n)\right)
\right)
$$

とします。

HDBSCANはクラスタ数を事前指定せず、各記事のsoft membership vectorを返します。この性質は原論文のtopic抽出方針と一致します。`2009.04508v2.pdf`

## 8.3 noise処理

HDBSCANのnoise probabilityはtopic coverageに直接含めません。

処理は以下とします。

1. `all_points_membership_vectors()`を取得
2. 行和が正なら非noise cluster間で再正規化
3. 行和がゼロなら最も近いcluster centroidへ低信頼で割当て
4. 元のnoise probabilityを別列で保持
5. `topic_assignment_confidence`を出力

## 8.4 fallback

以下の場合はsingle-topic fallbackとします。

```text
記事数が少なすぎる
HDBSCANがclusterを一つも返さない
全記事がnoise
有効cluster数が1
```

この場合、

$$
p_i=[1]
$$

としてtopic similarityを1にし、coverage制約を無効化します。

---

# 9. Coherence計算

## 9.1 Event similarity

L2正規化されたembedding $e_i,e_j$ に対して、

$$
S^{\mathrm{event}}_{ij}
=
1-
\frac{
\arccos
\left(
\operatorname{clip}(e_i^\top e_j,-1,1)
\right)
}{\pi}
$$

とします。

$$
S^{\mathrm{event}}_{ij}\in[0,1]
$$

## 9.2 Topic similarity

topic membership vectorを $p_i,p_j$ とし、

$$
S^{\mathrm{topic}}_{ij}
=
1-
d_{\mathrm{JS}}(p_i,p_j)
$$

とします。

`scipy.spatial.distance.jensenshannon`が返すdistanceを利用します。

## 9.3 論文準拠coherence

標準モードは、

$$
C_{ij}
=
\sqrt{
S^{\mathrm{event}}_{ij}
S^{\mathrm{topic}}_{ij}
}
$$

です。

論文は、一方のscoreだけが高い接続を抑制するため算術平均ではなく幾何平均を使用しています。`2009.04508v2.pdf`

```python
COHERENCE_MODE = "paper"
```

## 9.4 任意の拡張モード

Stage 1のfamily membership、entity、時間減衰を利用する場合は、別モードとします。

```python
COHERENCE_MODE = "hybrid"
```

例えば、

$$
\widetilde C_{ij}
=
C_{ij}
\left(r_ir_j\right)^{\eta_r/2}
\left(1+\eta_eE_{ij}\right)
\exp\left(
-\eta_t\frac{\Delta t_{ij}}{\tau}
\right)
$$

を計算し、$[0,1]$へclipします。

ただし、標準出力では必ず、

```text
event_similarity
topic_similarity
paper_coherence
adjusted_coherence
```

を分けて保持し、拡張項を論文式に混在させません。

---

# 10. Candidate edge生成

## 10.1 時間制約

候補edgeは必ず、

$$
\mathrm{event\_order}_i
<
\mathrm{event\_order}_j
$$

を満たします。

同一日時でもStage 1の`event_order`で決定論的な順序を使用します。

## 10.2 dense mode

記事数が以下の場合は、全forward pairを候補にします。

```python
DENSE_EDGE_MAX_N = 150
```

$$
E=\{(i,j):i<j\}
$$

これは論文に最も近い方式です。

## 10.3 sparse mode

記事数が150を超える場合は、

```text
semantic future-kNN
Stage 1のfamily内edge
時間的に隣接する記事
endpoint候補からの接続
```

の和集合を候補edgeとします。

```python
STAGE2_FUTURE_KNN_K = 30
MAX_EDGE_GAP_DAYS = None
```

`MAX_EDGE_GAP_DAYS=None`の場合はfamily期間全体を許容します。

## 10.4 path feasibility

candidate graphにsource-sink pathが存在しない場合は、次の順に自動拡張します。

1. future-kNNの$k$を増加
2. time windowを拡大
3. chronological adjacent edgeを追加
4. dense modeへfallback

変更内容はすべて`edge_candidate_diagnostics`へ記録し、黙って変更しません。

原論文でもpairwise edge生成が主要な計算ボトルネックであり、計算量は概ね $O(|D|^2k)$ とされています。`2009.04508v2.pdf`

---

# 11. source・sink選択

## 11.1 endpoint mode

以下の三方式を実装します。

```python
ENDPOINT_MODE = "stage1_candidates"
```

| mode | 内容 |
|---|---|
| `manual` | article IDを明示 |
| `stage1_candidates` | Stage 1候補の組合せを評価 |
| `chronological` | 最初・最後の記事 |

## 11.2 Stage 1候補の利用

Stage 1の、

```text
suggested_start_article_ids
suggested_end_article_ids
```

を読み込みます。

各最大3件を使用し、

$$
3\times3=9
$$

以下のendpoint pairを候補とします。

以下は除外します。

```text
sourceのevent_order >= sinkのevent_order
sourceとsinkが同一
間に十分な記事がない
candidate graphにsource-sink pathがない
```

Stage 1候補が欠損している場合は、時系列上の最初・最後の記事を追加します。

## 11.3 interval restriction

source $s$、sink $t$ を選択した場合、

```text
event_order < event_order_s
event_order > event_order_t
```

の記事はそのLP runでは非activeとします。

これにより、選択したsourceより前の記事やsinkより後の記事がMapへ入ることを防ぎます。

## 11.4 manual override

family別overrideを設定可能にします。

```python
FAMILY_OVERRIDES = {
    "F0001": {
        "source_article_id": "A001",
        "sink_article_id": "A058",
    }
}
```

---

# 12. Linear Programming

## 12.1 変数

記事集合を $V$、candidate edge集合を $E$、topic数を $q$ とします。

$$
y_i\in[0,1]
$$

記事 $i$ のnode flowです。

$$
x_{ij}\in[0,1]
$$

edge $i\to j$ のflowです。

$$
a_k\in[0,1]
$$

topic $k$ のcoverageです。

$$
\gamma\in[0,1]
$$

最小coherenceを表す目的変数です。

GitHub著者実装もこれらをcontinuous variableとして定義しています。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py))

## 12.2 目的関数

論文準拠では、

$$
\max\gamma
$$

とします。

各edgeについて、

$$
\gamma
\le
1-x_{ij}+C_{ij}
$$

を課します。

$x_{ij}=1$に近いedgeほど、

$$
\gamma\le C_{ij}
$$

という強い制約を受けます。

これは「storylineは最も弱いlinkによって決まる」というmax-min objectiveです。`2009.04508v2.pdf`

## 12.3 source・sink制約

$$
y_s=1,\qquad y_t=1
$$

$$
\sum_jx_{sj}=1
$$

$$
\sum_ix_{it}=1
$$

$$
\sum_ix_{is}=0
$$

$$
\sum_jx_{tj}=0
$$

## 12.4 flow conservation

sourceとsink以外のnode $v$ について、

$$
\sum_{i:(i,v)\in E}x_{iv}
=
y_v
$$

$$
\sum_{j:(v,j)\in E}x_{vj}
=
y_v
$$

とします。

## 12.5 expected length

$$
\sum_i y_i=K
$$

を課します。

また、数値安定性とQAのため、

$$
\sum_{(i,j)\in E}x_{ij}=K-1
$$

も明示します。

$y_i,x_{ij}$が連続変数なので、$K$は表示されるnode数ではなく、flow decomposition上の**期待path長**です。論文も $K$ をexpected main route lengthとして扱い、`mincover`とともにチューニング対象としています。`2009.04508v2.pdf`

## 12.6 edge activation

冗長ですが数値的な明確性のため、

$$
x_{ij}\le y_i
$$

$$
x_{ij}\le y_j
$$

を追加します。

## 12.7 coverage

記事 $i,j$ のtopic $k$ へのedge membershipを、

$$
m_{ijk}
=
\sqrt{p_{ik}p_{jk}}
$$

とします。

topic coverageは、

$$
a_k
=
\sum_{(i,j)\in E}
x_{ij}m_{ijk}
$$

です。

平均coverage制約は、

$$
\frac{1}{q}
\sum_{k=1}^qa_k
\ge
\mathrm{mincover}
$$

です。

記事単独ではなく、同じtopicに属する記事間edgeによりcoverageを測る点が論文の特徴です。`2009.04508v2.pdf`

topicが一つしかない場合、この制約は無効化します。

## 12.8 structural mode

二つのmodeを実装します。

```python
STRUCTURE_MODE = "st_flow"
```

### `st_flow`

- 時系列DAG
- flow conservation
- 単一source・sink

を課します。実務標準とします。

### `paper_strict`

上記に加え、Figure 2の中間active nodeを飛び越すedge制約を追加します。

$$
x_{ij}
\le
1-y_\ell
\qquad
\forall i<\ell<j
$$

これは制約数が $O(n^3)$ になり得るため、小規模familyの再現確認用とします。

---

# 13. 二段階最適化

max-min objectiveでは複数の同値解が生じる可能性があります。

そのため、標準では二段階で解きます。

## Phase A

$$
\max\gamma
$$

を解き、最適値を $\gamma^\ast$ とします。

## Phase B

$$
\gamma
\ge
\gamma^\ast-\epsilon_\gamma
$$

を固定し、

$$
\min
\sum_{(i,j)\in E}
x_{ij}
\left[
1-C_{ij}
+
\lambda_{\mathrm{time}}
\widetilde{\Delta t}_{ij}
\right]
$$

を解きます。

```python
GAMMA_TOLERANCE = 1e-6
TIE_BREAK_TIME_WEIGHT = 0.05
```

これは論文にないtie-break拡張なので、Phase Aの値とPhase Bの値を別々に保存します。

---

# 14. $K$・`mincover`・endpointの探索

## 14.1 $K$の初期値

familyの記事数を $n$ として、

$$
K_0
=
\operatorname{clip}
\left(
\operatorname{round}(\sqrt n+2),
4,
\min(12,n)
\right)
$$

とします。

候補は、

$$
K\in
\{K_0-2,K_0,K_0+2\}
$$

を有効範囲へclipしたものです。

```python
K_OFFSETS = (-2, 0, 2)
```

この式は論文由来ではなく、Stage 2の自動探索用の初期heuristicです。

## 14.2 `mincover`

```python
MINCOVER_GRID = (0.20, 0.40, 0.60, 0.80)
```

原論文では対象データに対して80%が機能したと報告されていますが、これは普遍的な設定ではありません。`2009.04508v2.pdf`

## 14.3 run grid

各familyで、

```text
endpoint pair
× K
× mincover
× structure mode
```

を実行します。

ただし、標準ではstructure modeを一つに固定します。

## 14.4 自動選択

各LP runについて以下を保存します。

```text
solver_status
source_article_id
sink_article_id
K
mincover
gamma
achieved_average_coverage
n_positive_flow_nodes
n_positive_flow_edges
main_route_length
mean_selected_coherence
minimum_selected_coherence
node_set_stability
edge_set_stability
flow_residual
runtime_seconds
```

最終runは次の辞書式順序で選びます。

1. `Optimal`かつ全QAを満たす
2. 隣接parameter runとのnode-set stabilityが高い
3. $K$が $K_0$ に近い
4. Stage 1 endpoint候補順位が高い
5. $\gamma$が高い
6. coverageが高い
7. positive-flow edgeが少ない

Notebook上では自動選択結果だけでなく、全runのPareto frontierを表示します。

family別に手動指定も可能にします。

```python
FAMILY_OVERRIDES = {
    "F0001": {
        "K": 7,
        "mincover": 0.60,
        "source_article_id": "...",
        "sink_article_id": "...",
    }
}
```

---

# 15. Solver要件

PuLPを使用します。

solverの優先順位は、

```text
1. HiGHS
2. CBC
```

とします。

```python
SOLVER_PREFERENCE = ("HIGHS", "CBC")
SOLVER_TIME_LIMIT_SECONDS = 180
```

solver未導入、infeasible、time limit等を区別して記録します。

infeasible時は、以下を順に試します。

1. `mincover`を一段階低下
2. candidate edgeを拡張
3. 別endpoint pair
4. $K$を一段階変更
5. single-topic fallbackの妥当性を確認

自動fallbackは必ず`lp_attempt_log`へ記録します。

---

# 16. Narrative graph構築

LP解から二つのgraphを作成します。

## 16.1 Raw graph

```python
G_raw: nx.DiGraph
```

solver toleranceを超える全flowを含みます。

```python
SOLVER_FLOW_TOLERANCE = 1e-8
```

## 16.2 Display graph

```python
G_display: nx.DiGraph
```

可視化用に一定以上のflowだけを表示します。

```python
DISPLAY_EDGE_FLOW_THRESHOLD = 0.01
```

ただし、

- main route edge
- flow decompositionに採用されたroute edge
- source／sinkを接続する必須edge

は閾値未満でも保持します。

Raw graphは計算・QA用、Display graphは可視化用とし、混同しません。

## 16.3 transition probability

各nodeのoutgoing flowを正規化します。

$$
P_{ij}
=
\frac{x_{ij}}
{\sum_\ell x_{i\ell}}
$$

sink以外の各selected nodeで、

$$
\sum_jP_{ij}=1
$$

を検証します。

---

# 17. Main route

main routeは、

$$
r^\ast
=
\arg\max_{r:s\rightsquigarrow t}
\prod_{(i,j)\in r}P_{ij}
$$

です。

数値計算では、

$$
-\log P_{ij}
$$

をedge costとしてshortest pathを求めます。

これは論文のmaximum-likelihood chainと一致します。`2009.04508v2.pdf`

出力指標は次です。

```text
route_probability
route_log_probability
n_nodes
duration_days
minimum_coherence
mean_coherence
topic_coverage
node_flow_sum
```

---

# 18. Alternative route抽出

## 18.1 標準方式：flow decomposition

LP edge flowを、

$$
x
=
\sum_{r=1}^Rw_r x^{(r)}
$$

というsource-sink pathの加重和へ分解します。

アルゴリズムは以下です。

1. residual flow graphを作る
2. residual graph上のmaximum-likelihood source-sink pathを取得
3. path weightを  
   $$
   w_r=\min_{e\in r}x_e^{\mathrm{residual}}
   $$
   とする
4. path上のflowから $w_r$ を減算
5. residual source flowが閾値未満になるまで反復

```python
ROUTE_RESIDUAL_TOLERANCE = 1e-8
ROUTE_CUMULATIVE_FLOW_TARGET = 0.95
MAX_ROUTES = 20
MIN_ROUTE_WEIGHT = 0.01
```

route数は事前指定しません。

## 18.2 decompositionの非一意性

flow decompositionは数学的に一意ではありません。

再現性を確保するため、各反復で、

1. maximum residual likelihood
2. minimum event_order sequence
3. article ID辞書順

の順にtie-breakします。

## 18.3 GitHub比較方式

診断用として、

```python
ROUTE_EXTRACTION_COMPARISON = True
```

の場合のみ、GitHubのnode-disjoint recursive routeも計算します。

ただし最終routeには使用しません。

---

# 19. Representative landmarks

## 19.1 論文準拠landmark

selected DAG上でmaximum antichainを取得します。

maximum antichainが複数ある場合、event timestampが最も早いものを採用します。論文では、maximum antichainの各nodeを並行storylineの代表と解釈しています。`2009.04508v2.pdf`

## 19.2 計算方法

Map node数が小さい場合は、

```python
nx.antichains(G)
```

で全列挙します。

```python
ANTICHAIN_ENUMERATION_MAX_N = 60
```

それ以上の場合は、transitive closureを作成し、binary変数 $z_i$ を用いたMILPで、

$$
\max\sum_i z_i
$$

subject to、

$$
z_i+z_j\le1
$$

for comparable node pairとします。

二段階目で最大cardinalityを固定し、

$$
\min\sum_i\mathrm{event\_order}_i z_i
$$

としてearliest maximum antichainを得ます。

## 19.3 GitHub型representative event

各flow routeについて、

- route embedding centroidへの近さ
- betweenness centrality

のrank平均が最小の記事も出力します。

現行GitHubにはcentroid、centrality、および両者のrankを組み合わせる代表記事選択が実装されています。([GitHub](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/graph_utils.py))

以下を区別して保存します。

```text
paper_landmark
route_centroid_representative
structural_hub
```

---

# 20. 関連記事のroute assignment

論文のLPは全記事をMapへ採用しません。事例研究でも102記事から、開始・終了イベントに加えて22記事だけが選択されました。`2009.04508v2.pdf`

そのため、Mapに未採用の記事をrouteへ事後的に関連付けます。

## 20.1 route表現

route $r$ について、

### Route embedding centroid

$$
\bar e_r
=
\operatorname{normalize}
\left(
\sum_{i\in r}\omega_i e_i
\right)
$$

### Route topic distribution

$$
\bar p_r
=
\frac{
\sum_{i\in r}\omega_i p_i
}{
\sum_{i\in r}\omega_i
}
$$

を計算します。

$\omega_i$はnode flowを標準とします。

## 20.2 関連度

未選択記事 $d$ とroute $r$ の関連度を、

$$
R_{dr}
=
w_sS^{\mathrm{sem}}_{dr}
+
w_pS^{\mathrm{topic}}_{dr}
+
w_eS^{\mathrm{entity}}_{dr}
+
w_tS^{\mathrm{time}}_{dr}
+
w_fS^{\mathrm{family}}_{dr}
$$

とします。

標準値は、

```python
RELATED_SCORE_WEIGHTS = {
    "semantic": 0.45,
    "topic": 0.25,
    "entity": 0.10,
    "temporal": 0.10,
    "family_membership": 0.10,
}
```

entityが存在しない場合は、そのweightをsemanticとtopicへ比例再配分します。

### Semantic component

route nodeとのangular similarity上位3件の平均です。

### Topic component

記事topic distributionとroute topic distributionのJS similarityです。

### Entity component

IDF-weighted Jaccardです。

### Temporal component

route内で最も近い記事までの時間差を使い、

$$
S^{\mathrm{time}}_{dr}
=
\exp
\left(
-\frac{
\min_{i\in r}|t_d-t_i|
}{\tau_{\mathrm{related}}}
\right)
$$

とします。

### Family component

Stage 1の`membership_score`です。

## 20.3 route-specific threshold

route core articleを一つずつ除いたleave-one-out scoreを計算し、その分布から閾値を決めます。

$$
\theta_r
=
\max
\left(
\theta_{\min},
Q_{0.10}
\left(
R^{\mathrm{LOO}}_{\cdot r}
\right)-m
\right)
$$

```python
RELATED_GLOBAL_MIN_SCORE = 0.55
RELATED_CORE_QUANTILE = 0.10
RELATED_THRESHOLD_MARGIN = 0.05
MAX_RELATED_ROUTES_PER_ARTICLE = 3
```

route node数が3未満の場合はglobal thresholdを使用します。

## 20.4 multi-label assignment

一記事は複数routeへ所属可能とします。

```text
primary_related_route_id
secondary_related_route_ids
association_score
nearest_core_article_id
```

を出力します。

## 20.5 duplicate

duplicate記事はcanonical articleのroute assignmentを継承し、

```text
role = "duplicate_related"
```

とします。

---

# 21. Result object

## 21.1 family単位

```python
@dataclass
class NarrativeMapFamilyResult:
    family_id: str
    stage1_fingerprint: str

    input_articles: pd.DataFrame
    core_candidates: pd.DataFrame
    related_candidates: pd.DataFrame

    topic_memberships: pd.DataFrame
    topic_summary: pd.DataFrame
    coherence_edges: pd.DataFrame

    endpoint_candidates: pd.DataFrame
    lp_diagnostics: pd.DataFrame
    selected_run: pd.Series

    nodes: pd.DataFrame
    edges: pd.DataFrame

    main_route: pd.DataFrame
    routes: pd.DataFrame
    route_articles: pd.DataFrame
    landmarks: pd.DataFrame

    raw_graph: nx.DiGraph
    display_graph: nx.DiGraph

    qa_summary: pd.DataFrame
    config: dict
    fingerprint: str
```

## 21.2 全family

```python
@dataclass
class NarrativeMapBatchResult:
    family_results: dict[str, NarrativeMapFamilyResult]
    batch_summary: pd.DataFrame
    failures: pd.DataFrame
    config: dict
    stage1_fingerprint: str
```

エントリポイントは以下とします。

```python
batch_result = extract_narrative_maps(
    stage1_bundle=stage1_bundle,
    config=CONFIG,
)
```

---

# 22. 出力DataFrame

## 22.1 `nodes`

```text
family_id
article_id
canonical_article_id
date
event_order
headline
family_membership_score
topic_id
topic_membership_vector
topic_confidence
node_flow
selected_flag
source_flag
sink_flag
main_route_flag
landmark_flag
structural_hub_flag
route_ids
assignment_status
```

## 22.2 `edges`

```text
family_id
source_article_id
target_article_id
delta_days
event_similarity
topic_similarity
paper_coherence
adjusted_coherence
edge_flow
transition_probability
selected_flag
main_route_flag
route_ids
candidate_rule
```

## 22.3 `routes`

```text
family_id
route_id
route_rank
route_type
route_weight
cumulative_flow_weight
route_probability
route_log_probability
n_articles
start_date
end_date
duration_days
minimum_coherence
mean_coherence
topic_coverage
representative_article_id
```

## 22.4 `route_articles`

```text
family_id
route_id
article_id
canonical_article_id
date
headline
route_order
role
core_flag
map_selected_flag
association_score
association_threshold
nearest_core_article_id
primary_route_flag
duplicate_flag
```

`role`は次を取ります。

```text
source
sink
main_route
alternative_route
paper_landmark
map_supplementary
related
duplicate_related
```

## 22.5 `topic_summary`

```text
family_id
topic_id
n_articles
weighted_size
representative_article_id
representative_headline
top_terms
top_entities
mean_noise_probability
```

## 22.6 `lp_diagnostics`

```text
family_id
run_id
source_article_id
sink_article_id
K
mincover
structure_mode
solver
solver_status
gamma_phase_a
gamma_phase_b
achieved_coverage
n_positive_nodes
n_positive_edges
main_route_length
node_set_stability
edge_set_stability
flow_residual
runtime_seconds
selected_run_flag
failure_reason
```

---

# 23. Notebookセル構成

| セクション | 内容 | 主な出力 |
|---|---|---|
| 0 | タイトル・目的 | Markdown |
| 1 | 論文／GitHub／拡張部分の区別 | 数式・対応表 |
| 2 | 依存関係 | `uv add` |
| 3 | Imports・solver確認 | version・solver |
| 4 | Configuration | 全設定表 |
| 5 | Stage 1出力loader | ファイル一覧 |
| 6 | Stage 1 contract QA | fingerprint・件数 |
| 7 | family選択 | 対象family表 |
| 8 | core／related pool作成 | 記事数比較 |
| 9 | topic model関数 | topic membership |
| 10 | coherence関数 | similarity分布 |
| 11 | candidate edge関数 | edge診断 |
| 12 | endpoint候補 | candidate pair表 |
| 13 | LP model builder | 数式との対応 |
| 14 | LP grid runner | run diagnostics |
| 15 | run selection | Pareto・選択理由 |
| 16 | graph構築 | node／edge表 |
| 17 | main route | main route表 |
| 18 | flow decomposition | alternative route表 |
| 19 | antichain／representative | landmark表 |
| 20 | 関連記事assignment | route_articles |
| 21 | family pipeline | family result |
| 22 | batch pipeline | batch result |
| 23 | Pipeline実行 | 進捗 |
| 24 | 結果テーブル | family別結果 |
| 25 | 可視化 | graph・timeline |
| 26 | QA | PASS／WARN／FAIL |
| 27 | 保存 | 保存パス |
| 28 | 最終サマリー | family別route概要 |

すべてのコードセルの直前に、以下を日本語Markdownで記載します。

```text
処理目的
入力
主要パラメータ
出力
論文準拠部分
本実装による拡張部分
注意点
```

---

# 24. 可視化要件

familyごとに最低限、次を表示します。

## 24.1 Topic diagnostics

- UMAP scatter
- HDBSCAN topic
- noise probability
- topic size
- topic representative headline

## 24.2 Coherence diagnostics

- event similarity分布
- topic similarity分布
- coherence分布
- coherenceとtime gap
- 高coherence／低coherence article pair

## 24.3 LP diagnostics

- $\gamma$と`mincover`
- $K$とselected node数
- endpoint pairごとのfeasibility
- parameter runのPareto frontier
- node-set Jaccard stability

## 24.4 Narrative Map

- x軸を時間とするDAG
- node sizeをnode flow
- edge widthをedge flowまたはtransition probability
- main routeを強調
- representative landmarkを別marker
- source／sinkを明示
- headlineは短縮表示

## 24.5 Route timeline

- routeごとの記事列
- 共通node
- 分岐・合流
- route weight
- 関連記事

GraphVizは任意依存とし、未導入でもNetworkX＋Matplotlibで表示できるようにします。原論文の最終可視化はGraphViz／DOT／SVGを利用しています。`2009.04508v2.pdf`

---

# 25. QA要件

## 25.1 Stage 1接続

```python
assert stage1_fingerprint is not None
assert article_id is unique
assert canonical embeddings and article_ids align
assert all core candidates have embeddings
assert selected family exists
```

## 25.2 Topic model

```python
assert topic_memberships.shape[0] == n_articles
assert np.isfinite(topic_memberships).all()
assert topic_memberships >= 0
assert row sums == 1 within tolerance
```

## 25.3 Coherence

```python
assert event_similarity in [0, 1]
assert topic_similarity in [0, 1]
assert coherence in [0, 1]
assert source_event_order < target_event_order
```

## 25.4 LP

```python
assert solver_status == "Optimal"
assert abs(sum(node_flow) - K) <= tolerance
assert abs(sum(edge_flow) - (K - 1)) <= tolerance
assert flow conservation residual <= tolerance
assert source outflow == 1
assert sink inflow == 1
assert achieved_coverage >= mincover
```

## 25.5 Graph

```python
assert nx.is_directed_acyclic_graph(G_raw)
assert source in_degree == 0
assert sink out_degree == 0
assert nx.has_path(source, sink)
```

すべてのpositive-flow nodeについて、

```text
sourceから到達可能
かつ
sinkへ到達可能
```

であることを確認します。

## 25.6 Probability

sink以外のselected nodeについて、

$$
\sum_jP_{ij}=1
$$

を確認します。

## 25.7 Routes

```python
assert main route begins at source
assert main route ends at sink
assert each route is chronological
assert route weights are non-negative
assert residual flow <= tolerance
```

route decomposition完了時に、

$$
\sum_rw_r\approx1
$$

を確認します。

## 25.8 Antichain

選択したlandmark pairについて、

```text
一方から他方へのpathが存在しない
```

ことを全組合せで検証します。

## 25.9 Related articles

```python
assert association_score in [0, 1]
assert duplicate article is not a separate map node
assert duplicate assignment references canonical article
```

---

# 26. Warning条件

以下はhard errorではなく警告とします。

```text
Stage 1 quality_flagがreview
core candidateが5件未満
HDBSCANのnoise率が50%以上
topicが一つしかない
endpoint pairによってMapが大幅に変化
高いmincoverがすべてinfeasible
main routeが2nodeのみ
main routeがKに対して極端に長い／短い
positive-flow edgeが過剰
node-set stabilityが0.60未満
maximum antichainが極端に大きい
一つのrouteがflowの90%以上を占める
関連記事の大半が複数routeへ曖昧に所属
```

---

# 27. 保存ファイル

```text
outputs/narrative_maps/
    batch_summary.parquet
    batch_failures.parquet
    run_metadata.json

    F0001/
        input_articles.parquet
        topic_memberships.parquet
        topic_summary.parquet
        coherence_edges.parquet
        endpoint_candidates.parquet
        lp_diagnostics.parquet
        map_nodes.parquet
        map_edges.parquet
        routes.parquet
        route_articles.parquet
        landmarks.parquet
        qa_summary.parquet
        narrative_graph.graphml
        narrative_map.svg
        config.json

    F0002/
        ...
```

Parquet保存に失敗した場合のみCSVへfallbackします。

GraphMLではlist列をJSON文字列へ変換します。

---

# 28. 依存ライブラリ

Notebook内で`pip install`は行いません。

```bash
uv add \
  pandas \
  numpy \
  scipy \
  scikit-learn \
  networkx \
  umap-learn \
  hdbscan \
  pulp \
  highspy \
  matplotlib \
  pyarrow \
  tqdm
```

GraphVizは任意です。

```bash
uv add graphviz
```

---

# 29. 推奨初期Configuration

```python
CONFIG = {
    # Stage 1 connection
    "input_mode": "stage1_output_dir",
    "stage1_output_dir": "outputs/narrative_family_discovery",

    # Family selection
    "family_selection_mode": "accepted",
    "family_ids": [],
    "min_map_candidates": 5,

    # Map / related pools
    "include_ambiguous_in_map": False,
    "include_secondary_in_map": False,
    "related_secondary_threshold": 0.30,
    "include_duplicates_as_related": True,

    # Topic model
    "topic_umap_components": 5,
    "topic_umap_min_dist": 0.0,
    "topic_umap_metric": "cosine",
    "topic_umap_random_state": 42,
    "hdbscan_min_cluster_size": "auto",
    "hdbscan_min_samples": 1,
    "hdbscan_cluster_selection_method": "eom",

    # Coherence
    "coherence_mode": "paper",
    "hybrid_relevance_strength": 0.0,
    "hybrid_entity_strength": 0.0,
    "hybrid_temporal_strength": 0.0,

    # Candidate edges
    "dense_edge_max_n": 150,
    "future_knn_k": 30,
    "max_edge_gap_days": None,

    # Endpoints
    "endpoint_mode": "stage1_candidates",
    "max_start_candidates": 3,
    "max_end_candidates": 3,

    # LP
    "structure_mode": "st_flow",
    "k_mode": "auto_grid",
    "k_offsets": (-2, 0, 2),
    "mincover_grid": (0.20, 0.40, 0.60, 0.80),
    "two_stage_optimization": True,
    "gamma_tolerance": 1e-6,
    "tie_break_time_weight": 0.05,

    # Solver
    "solver_preference": ("HIGHS", "CBC"),
    "solver_time_limit_seconds": 180,

    # Graph
    "solver_flow_tolerance": 1e-8,
    "display_edge_flow_threshold": 0.01,

    # Routes
    "route_residual_tolerance": 1e-8,
    "route_cumulative_flow_target": 0.95,
    "max_routes": 20,
    "min_route_weight": 0.01,

    # Antichain
    "antichain_enumeration_max_n": 60,

    # Related articles
    "related_score_weights": {
        "semantic": 0.45,
        "topic": 0.25,
        "entity": 0.10,
        "temporal": 0.10,
        "family_membership": 0.10,
    },
    "related_global_min_score": 0.55,
    "related_core_quantile": 0.10,
    "related_threshold_margin": 0.05,
    "max_related_routes_per_article": 3,

    # Reproducibility / output
    "random_seed": 42,
    "strict_qa": False,
    "save_outputs": True,
    "output_dir": "outputs/narrative_maps",
}
```

---

# 30. Definition of Done

実装完了条件は以下です。

1. Stage 1の保存結果を読み込むだけで単独実行できる  
2. Stage 1とStage 2でembeddingが一致する  
3. accepted familyを一括処理できる  
4. familyごとにtopic数を事前指定せず推定できる  
5. event similarity、topic similarity、coherenceを個別に確認できる  
6. endpoint候補をStage 1から受け取り、複数候補を比較できる  
7. $K$、`mincover`、endpointごとのLP結果を比較できる  
8. LPが単一source・sinkの時系列DAGを生成する  
9. main routeがmaximum-likelihood pathとして抽出される  
10. route数を事前指定せずflow decompositionできる  
11. route weightの合計とresidual flowを検証できる  
12. maximum antichainを抽出できる  
13. GitHub型のcentroid／centrality代表記事も比較できる  
14. Map未選択記事をrouteへmulti-labelで紐付けられる  
15. duplicateを独立nodeにせず関連記事として保持できる  
16. 全主要中間結果がDataFrameとして取得できる  
17. familyごとにNarrative Mapとroute timelineを可視化できる  
18. QAをPASS／WARN／FAILで表示できる  
19. 実行した全parameterとStage 1 fingerprintを保存できる  
20. 全処理が一つのNotebook内で完結し、外部`.py`を必要としない  

この設計では、Stage 1が「どの記事が同じNarrative familyに属するか」を決め、Stage 2が「そのfamilyの中で、どの記事がどの経路を形成し、何がmain routeで、どの記事が各routeに関連するか」を決定します。

---

**Sources:**

- [](https://raw.githubusercontent.com/briankeithn/narrative-maps/main/packages/solve_LP.py)

## Response:
2026/7/28 23:35:05

> **パーソナライズ中**
>
>
> **パーソナライズし、ノートブックの好みを特定**
>
> 
>
> 42m 22s考えました

# Stage 2 実装済みNotebook

[02_extract_narrative_maps.ipynb をダウンロード](sandbox:/mnt/data/02_extract_narrative_maps.ipynb)

Stage 1の保存結果を直接読み込み、Narrative familyごとにNarrative Map、主要経路、代替経路、representative landmarks、関連記事を抽出する単体完結Notebookです。外部の`.py`ファイルには依存しません。

論文が定義する、単一source・単一sinkを持つweighted DAGと、source-sink pathをstorylineとして扱う構造をコアにしています。`2009.04508v2.pdf`  
また、論文の6段階、すなわち前処理、coherence計算、LP、main route、maximum antichain、可視化という流れをNotebook内で再現しています。`2009.04508v2.pdf`

## 実装内容

### 1. Stage 1との接続

標準では以下を読み込みます。

```text
outputs/narrative_family_discovery/
    family_articles.parquet / csv
    family_summary.parquet / csv
    family_memberships.parquet / csv
    family_edges.parquet / csv
    canonical_embeddings.npz
    run_metadata.json
```

Stage 2ではembeddingを再計算せず、Stage 1で使用した同一のembeddingを利用します。これにより、Narrative family発見とNarrative Map抽出の意味空間を統一しています。

入力時に以下を検証します。

- 必須列の存在
- `article_id`の一意性
- canonical記事とembeddingの対応
- embeddingの有限性とL2 norm
- Stage 1 fingerprint
- duplicateとcanonical articleの対応

### 2. Map候補記事と関連記事候補の分離

各familyについて、次の二つを生成します。

```text
core_candidates
related_candidates
```

標準の`core_candidates`は、

```text
primary family
かつ
assignment_status ∈ {core, peripheral}
かつ
canonical article
```

です。

以下はMap本体から除外し、関連記事poolに保持します。

- ambiguous記事
- secondary family所属記事
- duplicate記事
- MapのLPで選択されなかった記事

### 3. Family内部のtopic推定

Stage 1のfamily分類とは別に、各family内部でtopicを推定します。

標準処理は、

```text
Stage 1 embedding
→ UMAP
→ HDBSCAN
→ soft topic membership
```

です。

HDBSCANはtopic数を事前指定せず、各記事のcluster probability vectorを生成します。この構成は論文のtopic抽出方法に対応しています。`2009.04508v2.pdf`

環境にUMAPまたはHDBSCANがない場合は、

```text
PCA
→ Gaussian Mixture
```

へfallbackします。topicを安定して推定できない場合はsingle-topicとして処理します。

### 4. 論文準拠のcoherence

元の高次元embeddingからangular event similarityを計算します。

$$
S^{\mathrm{event}}_{ij}
=
1-
\frac{
\arccos(e_i^\top e_j)
}{\pi}
$$

topic probability vectorからJensen-Shannon similarityを計算します。

$$
S^{\mathrm{topic}}_{ij}
=
1-d_{\mathrm{JS}}(p_i,p_j)
$$

最終的な論文準拠coherenceは、

$$
C_{ij}
=
\sqrt{
S^{\mathrm{event}}_{ij}
S^{\mathrm{topic}}_{ij}
}
$$

です。片方だけが高い記事対を抑制するため、論文と同じく幾何平均を用いています。`2009.04508v2.pdf`

出力には以下を分離して保持します。

```text
event_similarity
topic_similarity
paper_coherence
adjusted_coherence
```

`coherence_mode="hybrid"`に変更すると、Stage 1 membership、entity、時間減衰を追加できますが、論文式の`paper_coherence`は常に別列で保存されます。

### 5. Endpoint候補の探索

以下の三方式を実装しています。

```python
CONFIG["endpoint_mode"] = "stage1_candidates"
CONFIG["endpoint_mode"] = "chronological"
CONFIG["endpoint_mode"] = "manual"
```

標準ではStage 1の、

```text
suggested_start_article_ids
suggested_end_article_ids
```

から最大9組のsource-sink候補を作成します。

familyごとの手動overrideにも対応します。

```python
CONFIG["family_overrides"] = {
    "F0001": {
        "source_article_id": "...",
        "sink_article_id": "...",
        "K": 7,
        "mincover": 0.60,
    }
}
```

### 6. Continuous-flow LP

以下の変数を持つLPを実装しています。

$$
y_i\in[0,1]
$$

はnode flow、

$$
x_{ij}\in[0,1]
$$

はedge flow、

$$
a_k\in[0,1]
$$

はtopic coverage、

$$
\gamma\in[0,1]
$$

はflow-relaxed weakest-link objectiveです。

主要制約は、

$$
y_s=y_t=1,
\qquad
\sum_i y_i=K,
$$

$$
\sum_{(i,j)}x_{ij}=K-1,
$$

$$
\sum_i x_{iv}
=
y_v
=
\sum_jx_{vj},
$$

$$
\gamma
\le
1-x_{ij}+C_{ij},
$$

です。

topic $k$ に対するedge membershipは、

$$
m_{ijk}
=
\sqrt{p_{ik}p_{jk}}
$$

として、

$$
a_k
=
\sum_{(i,j)}
x_{ij}m_{ijk}
$$

を計算します。論文と同様、孤立nodeではなく、同じtopicに属する記事を接続するedgeによってcoverageを測定します。`2009.04508v2.pdf`

構造制約は次の二方式です。

```python
CONFIG["structure_mode"] = "st_flow"
```

実務向けの標準方式です。

```python
CONFIG["structure_mode"] = "paper_strict"
```

論文Figure 2の中間active nodeを飛び越すedge制約も追加します。制約数が増えるため、小規模familyの再現確認向けです。

### 7. $K$、`mincover`、endpointのgrid探索

標準では、

```python
CONFIG["k_offsets"] = (-2, 0, 2)
CONFIG["mincover_grid"] = (0.20, 0.40, 0.60, 0.80)
```

として、

```text
endpoint pair
× K
× mincover
```

を探索します。

論文でも、期待経路長 $K$、最低coverage、embedding、clustering設定が最終Mapへ影響するため、調整が必要とされています。`2009.04508v2.pdf`

各runについて以下を保存します。

```text
solver_status
source_article_id
sink_article_id
K
mincover
gamma
achieved_coverage
selected node数
selected edge数
main route長
node-set stability
edge-set stability
flow residual
runtime
```

### 8. 二段階最適化

同値解を減らすため、以下の二段階としています。

#### Phase A

$$
\max\gamma
$$

#### Phase B

$$
\gamma
\ge
\gamma^\ast-\epsilon
$$

を維持しながら、

```text
低coherence edge
長いtime gap
```

を抑える目的関数を最小化します。

Phase AとPhase Bの結果は別々に保存されるため、論文の目的関数と本実装のtie-breakを区別できます。

### 9. Solver fallback

次の順序でsolverを利用します。

```text
1. PuLP HiGHS
2. PuLP CBC
3. SciPy linprog(method="highs")
```

`pulp`や`highspy`がなくても、SciPyがあれば実行可能です。

### 10. Main route

selected edge flowを各nodeのoutgoing flowで正規化します。

$$
P_{ij}
=
\frac{x_{ij}}
{\sum_\ell x_{i\ell}}
$$

main routeは、

$$
r^\ast
=
\arg\max_{r:s\rightsquigarrow t}
\prod_{(i,j)\in r}P_{ij}
$$

です。

実装では、

$$
-\log P_{ij}
$$

をcostとするDAG shortest pathとして計算します。これは論文のmaximum-likelihood main routeに対応します。`2009.04508v2.pdf`

### 11. Alternative route

GitHub型のnode削除による経路抽出だけでは、分岐前や合流後の共通記事を複数routeで共有できません。

そこで標準方式として、LP flowを、

$$
x
=
\sum_{r=1}^{R}
w_r x^{(r)}
$$

というsource-sink pathの加重和へ分解します。

route数は事前指定せず、以下で制御します。

```python
CONFIG["route_cumulative_flow_target"] = 0.95
CONFIG["min_route_weight"] = 0.01
CONFIG["max_display_routes"] = 20
```

診断用として、GitHub型のnode-disjoint routeも別表に保存します。

### 12. Representative landmarks

論文準拠のearliest maximum antichainを抽出します。

小規模graphではNetworkXによるantichain列挙、大規模graphではMILPを使用します。

$$
\max\sum_i z_i
$$

subject to、比較可能なnode pairについて、

$$
z_i+z_j\le1
$$

を課します。

最大cardinalityを固定した後、

$$
\min\sum_i
\mathrm{event\_order}_i z_i
$$

として最も早いmaximum antichainを選びます。論文でも、最大反鎖が複数ある場合はtimestampが最も早いものをrepresentative landmarksとしています。`2009.04508v2.pdf`

以下を区別して出力します。

```text
paper_maximum_antichain
route_centroid_representative
structural_hub
```

### 13. 関連記事のroute assignment

Mapに選択されなかった記事について、routeとの関連度を計算します。

$$
R_{dr}
=
w_sS^{\mathrm{semantic}}_{dr}
+
w_pS^{\mathrm{topic}}_{dr}
+
w_eS^{\mathrm{entity}}_{dr}
+
w_tS^{\mathrm{time}}_{dr}
+
w_fS^{\mathrm{family}}_{dr}
$$

標準weightは、

```python
{
    "semantic": 0.45,
    "topic": 0.25,
    "entity": 0.10,
    "temporal": 0.10,
    "family_membership": 0.10,
}
```

です。

route core記事のleave-one-out scoreからroute別閾値を推定し、一記事を最大3 routeまでmulti-labelで関連付けます。

duplicate記事は独立nodeにせず、canonical articleのroute assignmentを継承します。

## 主要出力

実行後の中心オブジェクトは次です。

```python
batch_result
```

family別結果は、

```python
family_result = batch_result.family_results["F0001"]
```

として取得できます。

主な表は以下です。

```python
family_result.nodes
family_result.edges
family_result.main_route
family_result.routes
family_result.route_articles
family_result.landmarks
family_result.topic_memberships
family_result.topic_summary
family_result.lp_diagnostics
family_result.qa_summary
```

標準保存先は、

```text
outputs/narrative_maps/
```

です。

各familyに対して、以下を保存します。

```text
map_nodes
map_edges
main_route
routes
route_articles
landmarks
topic_memberships
topic_summary
coherence_edges
endpoint_candidates
lp_diagnostics
related_scores
related_thresholds
qa_summary
narrative_graph.graphml
narrative_map.svg
config.json
```

## 実行確認

Stage 1 Notebookの付属demo出力を使って、Notebookを先頭から最後まで実行済みです。

確認結果は次のとおりです。

| 項目 | 結果 |
|---|---:|
| 対象Narrative family | 3 |
| 完了family | 3 |
| 失敗family | 0 |
| familyごとのQA | 28項目すべてPASS |
| Narrative Map SVG | 3件生成 |
| Notebook実行エラー | 0 |
| 外部`.py`依存 | なし |

実データへ適用する際は、Stage 1を実行したプロジェクトrootに本Notebookを配置し、次を確認してから実行してください。

```python
CONFIG["stage1_output_dir"] = "outputs/narrative_family_discovery"
CONFIG["family_selection_mode"] = "accepted"
```

なお、LPの

$$
\gamma\le1-x_{ij}+C_{ij}
$$

はfractional-flow relaxationであるため、`gamma`はすべてのpositive-flow edgeの単純な最低coherenceとは一致しません。Notebookでは`paper_coherence`、selected edge分布、main routeのminimum／mean coherenceも個別に出力しています。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)