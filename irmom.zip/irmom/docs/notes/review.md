# review.md

対象論文: **What Does Residual Momentum Tell Us About Firm-Specific Momentum?**（Sina Ehsani, Juhani Linnainmaa, July 2022）

- 参照元: `docs/sources/WhatDoesResidualMomentumTellUsAbou_preview.pdf`
- 参照表記: `p.xx` は上記PDFのページ番号（このノート内での根拠トレース用）
- 本メモの目的: Phase B の再現実装に必要な仕様抽出（実装は行わない）

---

## 1. 論文メタ情報

- タイトルと著者、日付は p.1 に明記されている（July 2022）(p.1)。
- PDF は本文 48 ページ（p.1〜p.48）で、p.1 は Abstract、p.2 から本文開始 (p.1-2)。
- 主対象は米国株モメンタムと residual momentum で、国際比較（Asia Pacific, Europe, Japan, North America）も行う (p.6-9, p.31)。
- リターン形成は日次データ回帰で residual を作り、月次でポートフォリオを組む設計（後述）(p.6-7, p.19-20)。
- ファイル名に `preview` が含まれるため、最終出版版との差分があり得る（要確認）。

## 2. 研究課題と主要貢献

### 2.1 研究課題

- 既存解釈は「residual momentum の有意な alpha は firm-specific momentum の証拠」と見なすが、本論文はその解釈を否定する (p.1-3)。
- 問題提起: residual には firm-specific 成分だけでなく、
  - betting-against-beta（BAB）成分
  - 省略因子（omitted factors）の momentum 成分
  が混在し、alpha 解釈が汚染される (p.3-4, p.17-18)。

### 2.2 主要貢献

- 残差モメンタムの理論分解を提示し、RMOM の alpha が真の firm-specific momentum だけを表さないことを式で示す (p.12-15, p.16-18)。
- BAB 成分を除去する 4-step 手順を提示し、beta-neutral residual momentum（iRMOM）を構築する (p.19-20)。
- 「真に firm-specific な momentum があるか」を検証する実証テストを提案:
  1. iRMOM の平均分散効率（Sharpe）が RMOM を上回るか
  2. 地域間の相関が iRMOM で低下するか
  3. factor momentum との共変動が iRMOM で低下するか (p.4-5, p.34-38)。

## 3. 記号・変数定義（再現実装に必要な最小集合）

### 3.1 単因子系での基本式

- 株式 i のリターン:
  \( r_i = \eta(\bar\beta-\beta_i) + \beta_i f + \epsilon_i \) (Eq.1) (p.12)。
- 推定 residual:
  \( \hat\epsilon_i = r_i - \hat\beta_i f \) (Eq.2)、近似 \(\hat\beta_i\approx\beta_i\) を置く (p.12)。
- 推定 residual のバイアス表現:
  \( \hat\epsilon_i = \eta(\bar\beta-\beta_i)+\epsilon_i \) (Eq.3) (p.13)。
- BAB 戦略:
  \( BAB_t = \sum_i (\bar\beta-\beta_i)(r_{i,t}-\bar r_t) \) (Eq.4) (p.13)。
- RMOM（Lo-MacKinlay 型の線形重み）:
  \( RMOM_t = \sum_i (\hat\epsilon_{i,t-1}-\bar\epsilon_{t-1})(r_{i,t}-\bar r_t) \) (Eq.5) (p.13)。
- 分解:
  推定 RMOM = 真の firm-specific momentum + \(\eta\times BAB\) (Eq.7) (p.14)。
- 回帰係数の含意:
  \(\beta_{\hat{RMOM}}=-\eta\sigma_\beta^2\) (Eq.9),
  \(\alpha_{\hat{RMOM}}=\alpha_{RMOM}+\eta^2\sigma_\beta^2\) (Eq.10) (p.14-15)。

### 3.2 多因子・省略因子あり

- 多因子過程の拡張は Eq.12、total momentum は Eq.13 (p.16)。
- 投資家が k 個の因子だけ観測する場合、推定 residual に
  1) 長期切片（SFL 歪み）
  2) 省略因子成分
  3) firm-specific 成分
  が混在する（Eq.14-16）(p.17)。
- 残差モメンタム期待収益は、
  - 省略因子の自己共分散
  - 省略因子曝露由来の平均項
  - firm-specific 自己共分散
  - 既知因子 SFL 歪み項
  の和になる（Eq.17）(p.18)。

## 4. 戦略定義（RMOM / iRMOM）

### 4.1 実証での標準 momentum / residual momentum

- ソート期間は \(t-12\) から \(t-2\)（skip-month あり）(p.6-7)。
- total momentum は過去 total return でソート、residual momentum は CAPM/FF3/FF5 回帰の推定 intercept でソート (p.6-7)。
- 回帰は日次 excess return を使用、採用条件は lookback 期間に少なくとも 120 営業日があり、かつ \(t+1\) リターンがある銘柄 (p.6)。
- ポートフォリオは size×signal の 2×3（NYSE median size と NYSE 30/70 ブレークポイント）、value-weighted、winner 2 ポート long / loser 2 ポート short、月次リバランス (p.7 footnote, p.9)。

### 4.2 iRMOM（beta-neutral residual momentum）4-step

1. \([t-12,t-2]\) の日次回帰で各銘柄の residual（短期側）を推定 (p.19)。
2. IID とみなせる長期窓で各銘柄の long-run intercept を推定 (p.19)。
3. 時点 \(t-1\) で、短期 residual を long-run intercept にクロスセクション回帰し、その残差を取得 (p.20)。
4. 手順3の残差でソートして、月 \(t\) の momentum を構築 (p.20)。

- IID 窓の探索法（脚注）:
  1930年以降、\([t-13,t-1]\)〜\([t-60,t-1]\) の 48 窓で戦略を作り、累積収益が 0 に最も近い窓を採用。平均約20か月、最小17・最大23か月 (p.19 footnote)。

## 5. 実証設計（データ・モデル・評価）

### 5.1 実データ実証

- 米国サンプル: 1965-01〜2020-12（N=672）(p.7)。
- 国際サンプル: 1993-07〜2020-10（N=328）、地域は AP/Europe/Japan/NA (p.9)。
- 国際データは Datastream/Worldscope を利用し、普通株抽出と補正ルールを適用 (p.8 footnote)。
- 回帰モデルは主に FF5（必要に応じ CAPM / FF3）で評価、factor momentum との回帰も実施 (p.10-11, p.22, p.38)。

### 5.2 シミュレーション（Result 1-4 の判別設計）

- 4経済を設定: FMOM, FMOM+RMOM, FMOM+BAB, FMOM+RMOM+BAB (Eq.18-21) (p.24)。
- 共通仕様:
  - 因子数 5
  - 660か月
  - 因子平均 0.2%/月、標準偏差 2%、1次自己相関 0.10
  - 銘柄数 100、\(\beta_f\sim N(1,2)\)
  - 反復 1000 回 (p.24-27)。
- idiosyncratic 成分:
  - FMOM は IID（ボラは 5%〜10% の範囲）
  - FMOM+RMOM は idiosyncratic 1次自己相関 0.02
  - BAB 経済は \(\eta_t\sim N(1,2)\) の SFL 歪みを導入 (p.24-25)。
- 実装上の戦略形成は 60か月 rolling 回帰、直近 residual ソート、iRMOM は前述4-stepを適用 (p.26-27)。

## 6. 主要結果（Result 1〜4中心）

### 6.1 観測パズル（導入・Table 1-3）

- RMOM の alpha は平均収益を上回り、因子を増やすほど回帰 \(R^2\) が上がる（直観と逆）(p.8, p.7 table, p.9 table)。
- 例（米国 Table 1）:
  - CAPM RMOM 平均 0.61%、FF5 RMOM 平均 0.50%
  - ただし FF5 alpha 0.69%、Adj. \(R^2\) 22.0% (p.7-8)。
- factor momentum を入れても RMOM の説明は「純粋な firm-specific momentum」解釈と整合しない挙動を示す (p.10-11)。

### 6.2 Result 1（有意な RMOM 平均/alpha は決定打でない）

- シミュレーションでは、RMOM の平均や alpha の有意性だけでは
  - firm-specific momentum
  - omitted factor momentum
  - BAB
  の識別ができないことを示す (p.27-30)。

### 6.3 Result 2（iRMOM の Sharpe 改善は firm-specific momentum の証拠）

- 米国 FF5 で iRMOM は Sharpe を大幅改善（論文中で 0.59 → 1.23）(p.5, p.20-21, p.44)。
- 国際でも CAPM/FF3 より FF5 で改善が大きい（例 AP FF5: 0.84→0.83 だが t 値改善、NA FF5: 0.34→0.29 でも Sharpe 改善）(p.31-33)。
- シミュレーション比較では、Sharpe 改善パターンは FMOM+BAB+RMOM 経済（firm-specific あり）と整合し、FMOM+BAB（firm-specific なし）とは整合しにくい (p.33-34)。

### 6.4 Result 3（地域間共変動の低下）

- RMOM は地域間で高相関だが、iRMOM で一貫して低下 (p.35-37)。
- 平均相関（Table 7 Panel B）:
  - CAPM: 0.45 → 0.37
  - FF3: 0.42 → 0.30
  - FF5: 0.40 → 0.24 (p.37)。

### 6.5 Result 4（factor momentum との共変動低下）

- iRMOM は RMOM より factor momentum 相関が低い (p.38)。
- 例（Table 8）:
  - FF5: 0.36（RMOM）→ 0.19（iRMOM）、差は統計的に有意 (p.38)。

### 6.6 メカニズム含意と時系列安定性

- 因子成分と firm-specific 成分で自己相関パターンが異なり、firm-specific 側は初期反転と長期反転が強い (p.39-40)。
- iRMOM の年次収益は 2002年以降に大きく鈍化。1965-2000 年の年率平均 10.10%（t=10.48）に対し、2000年以降は 3.45%（t=1.53）(p.42-43)。

## 7. 再現実装仕様（Phase Bへの受け渡し）

### 7.1 入力データ要件

- 銘柄日次リターンと日次因子（少なくとも CAPM/FF3/FF5 を構築可能な系列）が必要 (p.6-7, p.31)。
- 国際再現まで行う場合は AP/Europe/Japan/NA の同等データセットが必要 (p.9, p.31)。
- factor momentum との比較を行うには、Ehsani and Linnainmaa (2020) の factor momentum 系列が必要 (p.10-11, p.38)。

### 7.2 時点整合・リーク防止（実装必須）

- 論文の月次記法は「\(t-1\) 時点までの情報でソートし、月 \(t\) 収益を得る」構造 (p.20)。
- 本プロジェクト実装に合わせると、**特徴量は月末 \(t\) までで確定し、適用は翌月（\(t+1\)）** として1か月シフトする。
- residual 推定窓は \([t-12,t-2]\) を使用し、\(t-1\)・\(t\) の情報を混入させない (p.6-7, p.19-20)。
- 銘柄採用条件（120営業日・将来月リターン有無）は時点先読みが起きないように実装する (p.6)。

### 7.3 最低限の再現ステップ

1. 日次 excess return を用意し、月次インデックスへ整列。
2. 月次 \(t\) ごとに \([t-12,t-2]\) で residual/intercept を推定。
3. 長期 IID 窓で long-run intercept を推定。
4. 短期 residual を long-run intercept で直交化して iRMOM ソート変数を作成。
5. 2×3（size×signal）で value-weight ポートフォリオを作成し、winner-minus-loser を算出。
6. RMOM / iRMOM の平均、alpha、Sharpe、factor momentum 相関、地域間相関を比較。

### 7.4 検証チェックリスト（Phase B 受入基準案）

- FF5 iRMOM の Sharpe が FF5 RMOM より改善するか（米国）(p.20-21, p.44)。
- iRMOM の地域間平均相関が RMOM より低いか（国際）(p.37)。
- iRMOM と factor momentum の相関が RMOM より低いか（米国）(p.38)。
- 2002年前後で iRMOM 収益の水準変化が観察されるか (p.42-43)。

## 8. 未確定事項・要追加調査点（Preview版由来を含む）

- `preview` PDF のため、最終出版版との図表番号・文言差分は要確認。
- factor momentum（Ehsani and Linnainmaa 2020）の厳密実装手順は本稿内に完全展開されていないため、原典確認が必要 (p.10-11, p.38)。
- IID 窓探索の計算詳細（タイブレーク規則、更新頻度、欠損処理）は脚注要約のみで、完全再現には追加仕様化が必要 (p.19 footnote)。
- 実売買コスト、スリッページ、実行制約は本稿の主要表で明示的に組み込まれていないため、Phase B で別途仕様決定が必要（要確認）。

---

以上。Phase A の成果物として、実装に必要な論文仕様を根拠ページ付きで整理した。
