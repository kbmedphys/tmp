"""
Replication utilities for:
Candès, Hastie, Hogan, Kahn, Luo, Spector, "Thematic Investing: A Risk-based Perspective".

Purpose
-------
Use LSEG/Refinitiv time-series data to reproduce the paper's core workflow:
1. Build stock return panel.
2. Estimate a cross-sectional risk model and residual returns.
3. Compute average pairwise residual correlation (APC) for broker/theme baskets.
4. Bootstrap a null distribution and z-score for APC.
5. Test whether significant coherent themes show residual-return trending.

This file is intentionally written as a research scaffold. It does not require
lseg.data at import time; LSEG functions import lseg.data only when called.

Important
---------
The paper's exact Mosaic + bootstrap test is technically involved. This module
implements:
- a paper-faithful cross-sectional residualization framework;
- a basic residual permutation bootstrap;
- a block permutation bootstrap approximation that preserves short residual
autocorrelation better than iid shuffling.

For production-grade exact Mosaic+bootstrap, adapt `bootstrap_apc_zscore` to
re-run cross-sectional regressions inside randomized stock/time tiles.
"""
from __future__ import annotations

import math
import os
import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

@dataclass
class RiskModelConfig:
    """Cross-sectional risk model configuration."""
    use_intercept: bool = True
    industry_col: str = "trbc_industry"
    style_cols: Tuple[str, ...] = ("log_mcap", "value", "momentum", "volatility", "liquidity")
    min_obs: int = 50
    ridge_lambda: float = 1e-6
    winsor_z: float = 5.0


@dataclass
class APCConfig:
    """APC and bootstrap configuration."""
    apc_window_days: int = 60           # calendar/event window in paper; for trading-day matrix use rows in chosen window
    min_names: int = 5
    n_boot: int = 1000
    random_state: int = 42
    bootstrap_method: str = "block"     # "iid" or "block"
    block_size: int = 10                # aligns with paper's 10-observation time batches concept


@dataclass
class TrendTestConfig:
    """Residual-return persistence test configuration."""
    lookback_days: int = 60
    horizon_days: int = 60
    z_threshold: float = 2.0


# -----------------------------------------------------------------------------
# LSEG data acquisition helpers
# -----------------------------------------------------------------------------

def normalize_japan_equity_ric(x) -> Optional[str]:
    """Convert Japan stock code/Bloomberg-like ticker/RIC to RIC.

    Examples
    --------
    7203 -> 7203.T
    "7203" -> 7203.T
    "7203 JT Equity" -> 7203.T
    "7203.T" -> 7203.T
    "7203.T^A" -> unchanged
    "JPY=" -> unchanged
    """
    if pd.isna(x):
        return None
    s = str(x).strip()
    if not s:
        return None
    if s.endswith(".T") or ".T^" in s or s.startswith(".") or s.endswith("="):
        return s
    m = re.match(r"^(\d{4})\s+JT\s+Equity$", s, flags=re.IGNORECASE)
    if m:
        return f"{m.group(1)}.T"
    m = re.match(r"^(\d{4})$", s)
    if m:
        return f"{m.group(1)}.T"
    return s


def open_lseg_session():
    """Open an LSEG data session. Requires Workspace/Eikon/Platform config."""
    import lseg.data as ld
    ld.open_session()
    return ld


def _extract_history_field(df: pd.DataFrame, rics: Sequence[str], field: str) -> pd.DataFrame:
    """Normalize ld.get_history output to a wide matrix."""
    if df is None or len(df) == 0:
        return pd.DataFrame()
    out = df.copy()
    if isinstance(out.columns, pd.MultiIndex):
        for level in range(out.columns.nlevels):
            labels = set(out.columns.get_level_values(level))
            if field in labels:
                out = out.xs(field, axis=1, level=level)
                break
        if isinstance(out.columns, pd.MultiIndex):
            # Keep the remaining RIC-like component.
            out.columns = [str(tuple([x for x in c if x != field])[-1]) for c in out.columns]
    else:
        if len(rics) == 1 and out.shape[1] == 1:
            out.columns = [rics[0]]
    out.columns = [str(c) for c in out.columns]
    out.index = pd.to_datetime(out.index)
    return out.sort_index()


def get_history_matrix_lseg(
    rics: Sequence[str],
    start: str,
    end: Optional[str] = None,
    field: str = "TRDPRC_1",
    interval: str = "daily",
    batch_size: int = 80,
) -> pd.DataFrame:
    """Fetch historical time series from LSEG as a wide matrix.

    Parameters are passed to ld.get_history. Field TRDPRC_1 is a common traded
    price/close-like field; replace with an adjusted price/total return field if
    available under your entitlement.
    """
    import lseg.data as ld
    rics = list(dict.fromkeys([str(r) for r in rics if pd.notna(r)]))
    parts: List[pd.DataFrame] = []
    for i in range(0, len(rics), batch_size):
        batch = rics[i:i + batch_size]
        raw = ld.get_history(universe=batch, fields=[field], interval=interval, start=start, end=end)
        mat = _extract_history_field(raw, batch, field)
        parts.append(mat)
        print(f"Downloaded history {min(i + batch_size, len(rics))}/{len(rics)}")
    if not parts:
        return pd.DataFrame()
    out = pd.concat(parts, axis=1)
    out = out.loc[:, ~out.columns.duplicated()]
    return out.sort_index()


def get_reference_data_lseg(rics: Sequence[str], fields: Sequence[str], batch_size: int = 100) -> pd.DataFrame:
    """Fetch reference/fundamental fields from LSEG with ld.get_data."""
    import lseg.data as ld
    rics = list(dict.fromkeys([str(r) for r in rics if pd.notna(r)]))
    parts: List[pd.DataFrame] = []
    for i in range(0, len(rics), batch_size):
        batch = rics[i:i + batch_size]
        df = ld.get_data(universe=batch, fields=list(fields))
        parts.append(df)
        print(f"Downloaded ref data {min(i + batch_size, len(rics))}/{len(rics)}")
    return pd.concat(parts, axis=0) if parts else pd.DataFrame()


# -----------------------------------------------------------------------------
# Data preparation
# -----------------------------------------------------------------------------

def prices_to_returns(prices: pd.DataFrame, log: bool = False) -> pd.DataFrame:
    """Convert price matrix to simple or log returns."""
    x = prices.sort_index().replace([np.inf, -np.inf], np.nan).astype(float)
    return np.log(x).diff() if log else x.pct_change(fill_method=None)


def read_constituents(path: str) -> pd.DataFrame:
    """Read broker theme constituents.

    Expected columns:
    - date or release_date/effective_date
    - theme
    - ticker/ric/symbol/code
    - weight
    """
    df = pd.read_csv(path)
    cols = {c.lower(): c for c in df.columns}
    date_col = cols.get("date") or cols.get("release_date") or cols.get("effective_date")
    theme_col = cols.get("theme")
    weight_col = cols.get("weight") or cols.get("wgt")
    id_col = cols.get("ric") or cols.get("ticker") or cols.get("symbol") or cols.get("code")
    if theme_col is None or weight_col is None or id_col is None:
        raise ValueError("constituents requires theme, weight, and ticker/ric/symbol/code")
    out = pd.DataFrame({
        "date": pd.to_datetime(df[date_col]) if date_col else pd.Timestamp("1900-01-01"),
        "theme": df[theme_col].astype(str),
        "ric": df[id_col].map(normalize_japan_equity_ric),
        "weight": pd.to_numeric(df[weight_col], errors="coerce"),
    })
    out = out.dropna(subset=["date", "theme", "ric", "weight"])
    out = out[out["weight"] > 0].copy()
    out["weight"] = out.groupby(["date", "theme"])["weight"].transform(lambda x: x / x.sum())
    return out.sort_values(["theme", "date", "ric"]).reset_index(drop=True)


def latest_constituents_asof(constituents: pd.DataFrame, dt: pd.Timestamp, theme: str) -> pd.DataFrame:
    """Latest constituent set for a theme as of date dt."""
    sub = constituents[(constituents["theme"] == theme) & (constituents["date"] <= dt)]
    if sub.empty:
        return sub
    last = sub["date"].max()
    return sub[sub["date"] == last].copy()


def zscore_cross_section(x: pd.Series, winsor: float = 5.0) -> pd.Series:
    """Cross-sectional z-score of a Series."""
    s = x.astype(float).replace([np.inf, -np.inf], np.nan)
    mu, sd = s.mean(skipna=True), s.std(skipna=True, ddof=0)
    z = (s - mu) / sd if sd and np.isfinite(sd) else s * np.nan
    return z.clip(-winsor, winsor)


def build_dynamic_style_exposures(
    returns: pd.DataFrame,
    market_cap: Optional[pd.DataFrame] = None,
    volume_or_adv: Optional[pd.DataFrame] = None,
    book_to_price: Optional[pd.DataFrame] = None,
    asof_dates: Optional[Sequence[pd.Timestamp]] = None,
) -> pd.DataFrame:
    """Build simple style exposures from LSEG time-series panels.

    Output is MultiIndex (date, ric) with columns:
    log_mcap, value, momentum, volatility, liquidity.
    """
    returns = returns.sort_index()
    dates = pd.DatetimeIndex(asof_dates) if asof_dates is not None else returns.index
    # 12m-1m momentum using daily returns. Uses past data only.
    mom = returns.shift(21).rolling(252, min_periods=126).sum()
    vol = returns.rolling(126, min_periods=63).std(ddof=0)
    exposures = []
    for dt in dates:
        if dt not in returns.index:
            prev = returns.index[returns.index <= dt]
            if len(prev) == 0:
                continue
            dt0 = prev[-1]
        else:
            dt0 = dt
        df = pd.DataFrame(index=returns.columns)
        df["momentum"] = mom.loc[dt0]
        df["volatility"] = vol.loc[dt0]
        if market_cap is not None:
            mcap = market_cap.reindex(returns.index).ffill().loc[dt0]
            df["log_mcap"] = np.log(mcap.replace(0, np.nan))
        else:
            df["log_mcap"] = np.nan
        if volume_or_adv is not None:
            adv = volume_or_adv.reindex(returns.index).ffill().loc[dt0]
            df["liquidity"] = np.log(adv.replace(0, np.nan))
        else:
            df["liquidity"] = np.nan
        if book_to_price is not None:
            df["value"] = book_to_price.reindex(returns.index).ffill().loc[dt0]
        else:
            df["value"] = np.nan
        df["date"] = dt0
        df["ric"] = df.index
        exposures.append(df.reset_index(drop=True))
    if not exposures:
        return pd.DataFrame()
    out = pd.concat(exposures, axis=0).set_index(["date", "ric"]).sort_index()
    # Cross-sectional standardize per date.
    for c in ["log_mcap", "value", "momentum", "volatility", "liquidity"]:
        out[c] = out.groupby(level=0)[c].transform(lambda s: zscore_cross_section(s))
    return out


def merge_static_industry(exposures: pd.DataFrame, industry_map: pd.Series, industry_col: str = "trbc_industry") -> pd.DataFrame:
    """Add static industry code/name to MultiIndex exposure panel."""
    out = exposures.copy()
    rics = out.index.get_level_values("ric")
    out[industry_col] = rics.map(industry_map.astype(str))
    return out


# -----------------------------------------------------------------------------
# Cross-sectional risk model residuals
# -----------------------------------------------------------------------------

def _build_x_matrix(exposure_df: pd.DataFrame, cfg: RiskModelConfig) -> Tuple[pd.DataFrame, List[str]]:
    """Create design matrix with industry dummies + style exposures."""
    x_parts = []
    names: List[str] = []
    if cfg.use_intercept:
        x_parts.append(pd.DataFrame({"intercept": 1.0}, index=exposure_df.index))
        names.append("intercept")
    if cfg.industry_col in exposure_df.columns:
        dummies = pd.get_dummies(exposure_df[cfg.industry_col].astype(str), prefix="ind", dummy_na=False)
        # Drop one dummy if intercept to avoid exact collinearity; ridge can handle but this is cleaner.
        if cfg.use_intercept and dummies.shape[1] > 0:
            dummies = dummies.iloc[:, 1:]
        x_parts.append(dummies.astype(float))
        names += list(dummies.columns)
    for c in cfg.style_cols:
        if c in exposure_df.columns:
            x_parts.append(exposure_df[[c]].astype(float))
            names.append(c)
    if not x_parts:
        raise ValueError("No exposures available for risk model")
    X = pd.concat(x_parts, axis=1)
    X = X.replace([np.inf, -np.inf], np.nan)
    return X, list(X.columns)


def cross_sectional_residuals(
    returns: pd.DataFrame,
    exposures: pd.DataFrame,
    cfg: Optional[RiskModelConfig] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Daily cross-sectional ridge regression residualization.

    Parameters
    ----------
    returns:
        Date x RIC return matrix.
    exposures:
        MultiIndex (date, ric) exposure panel. Exposures at date t are used for
        returns at t. In production, use prior close/month-end exposures for t.
    cfg:
        RiskModelConfig.

    Returns
    -------
    residuals:
        Date x RIC matrix of idiosyncratic returns.
    factor_returns:
        Date x estimated factor-return matrix.
    """
    cfg = cfg or RiskModelConfig()
    returns = returns.sort_index().replace([np.inf, -np.inf], np.nan)
    residuals = pd.DataFrame(np.nan, index=returns.index, columns=returns.columns)
    factor_rows = []
    for dt in returns.index:
        if dt not in exposures.index.get_level_values(0):
            continue
        exp_dt = exposures.xs(dt, level=0)
        common = returns.columns.intersection(exp_dt.index)
        y = returns.loc[dt, common].astype(float)
        exp_sub = exp_dt.loc[common]
        X, cols = _build_x_matrix(exp_sub, cfg)
        df = pd.concat([y.rename("y"), X], axis=1).dropna()
        if df.shape[0] < cfg.min_obs or df.shape[1] <= 1:
            continue
        yv = df["y"].to_numpy(float)
        Xm = df[cols].to_numpy(float)
        lam = cfg.ridge_lambda
        ridge = np.eye(Xm.shape[1]) * lam
        if cfg.use_intercept and "intercept" in cols:
            ridge[cols.index("intercept"), cols.index("intercept")] = 0.0
        try:
            beta = np.linalg.solve(Xm.T @ Xm + ridge, Xm.T @ yv)
        except np.linalg.LinAlgError:
            beta = np.linalg.pinv(Xm.T @ Xm + ridge) @ Xm.T @ yv
        resid = yv - Xm @ beta
        residuals.loc[dt, df.index] = resid
        factor_rows.append(pd.Series(beta, index=cols, name=dt))
    factor_returns = pd.DataFrame(factor_rows).sort_index()
    return residuals, factor_returns


# -----------------------------------------------------------------------------
# APC statistic and bootstrap
# -----------------------------------------------------------------------------

def average_pairwise_correlation(residual_window: pd.DataFrame, min_names: int = 5) -> float:
    """Average pairwise correlation of residual returns in a window."""
    U = residual_window.dropna(axis=1, thresh=max(5, int(0.5 * len(residual_window))))
    if U.shape[1] < min_names:
        return np.nan
    corr = U.corr(min_periods=max(5, int(0.5 * len(U)))).to_numpy(float)
    if corr.shape[0] < min_names:
        return np.nan
    iu = np.triu_indices_from(corr, k=1)
    vals = corr[iu]
    vals = vals[np.isfinite(vals)]
    return float(vals.mean()) if vals.size else np.nan


def _iid_permute_columns(U: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    out = np.empty_like(U)
    for j in range(U.shape[1]):
        out[:, j] = rng.permutation(U[:, j])
    return out


def _block_permute_columns(U: np.ndarray, rng: np.random.Generator, block_size: int = 10) -> np.ndarray:
    T, N = U.shape
    blocks = [np.arange(i, min(i + block_size, T)) for i in range(0, T, block_size)]
    out = np.empty_like(U)
    for j in range(N):
        order = rng.permutation(len(blocks))
        perm_idx = np.concatenate([blocks[k] for k in order])
        out[:, j] = U[perm_idx[:T], j]
    return out


def bootstrap_apc_zscore(
    residual_window: pd.DataFrame,
    n_boot: int = 1000,
    min_names: int = 5,
    method: str = "block",
    block_size: int = 10,
    random_state: int = 42,
) -> Dict[str, float]:
    """Bootstrap null distribution and z-score for APC.

    Basic null: break cross-stock residual correlations while preserving each
    stock's empirical residual distribution. Block version permutes time blocks
    within each column, preserving short-run autocorrelation inside blocks.
    """
    Udf = residual_window.dropna(axis=1, thresh=max(5, int(0.5 * len(residual_window))))
    if Udf.shape[1] < min_names:
        return {"apc": np.nan, "z": np.nan, "p_upper": np.nan, "null_mean": np.nan, "null_std": np.nan, "n_names": Udf.shape[1]}
    # Fill isolated missing residuals with column means (near zero) for permutation.
    Udf = Udf.apply(lambda s: s.fillna(s.mean()), axis=0)
    apc_obs = average_pairwise_correlation(Udf, min_names=min_names)
    if not np.isfinite(apc_obs):
        return {"apc": np.nan, "z": np.nan, "p_upper": np.nan, "null_mean": np.nan, "null_std": np.nan, "n_names": Udf.shape[1]}
    U = Udf.to_numpy(float)
    rng = np.random.default_rng(random_state)
    null = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        if method == "iid":
            Ub = _iid_permute_columns(U, rng)
        elif method == "block":
            Ub = _block_permute_columns(U, rng, block_size=block_size)
        else:
            raise ValueError("method must be 'iid' or 'block'")
        null[b] = average_pairwise_correlation(pd.DataFrame(Ub, index=Udf.index, columns=Udf.columns), min_names=min_names)
    null = null[np.isfinite(null)]
    mu, sd = float(null.mean()), float(null.std(ddof=1))
    z = (apc_obs - mu) / sd if sd > 0 else np.nan
    p_upper = float((1.0 + np.sum(null >= apc_obs)) / (len(null) + 1.0)) if len(null) else np.nan
    return {"apc": apc_obs, "z": z, "p_upper": p_upper, "null_mean": mu, "null_std": sd, "n_names": Udf.shape[1]}


def compute_basket_apc_table(
    residuals: pd.DataFrame,
    constituents: pd.DataFrame,
    analysis_dates: Sequence[pd.Timestamp],
    cfg: Optional[APCConfig] = None,
) -> pd.DataFrame:
    """Compute APC and bootstrap z-scores by theme and analysis date.

    Uses latest constituents as of analysis date. The window is the trailing
    `apc_window_days` trading rows ending at the analysis date.
    """
    cfg = cfg or APCConfig()
    residuals = residuals.sort_index()
    rows = []
    for dt in pd.DatetimeIndex(analysis_dates):
        dates = residuals.index[residuals.index <= dt]
        if len(dates) == 0:
            continue
        end_dt = dates[-1]
        loc = residuals.index.get_loc(end_dt)
        if not isinstance(loc, (int, np.integer)):
            loc = int(np.asarray(loc).ravel()[-1])
        win = residuals.iloc[max(0, loc - cfg.apc_window_days + 1):loc + 1]
        for theme in sorted(constituents["theme"].unique()):
            c = latest_constituents_asof(constituents, end_dt, theme)
            rics = [r for r in c["ric"].tolist() if r in win.columns]
            if len(rics) < cfg.min_names:
                continue
            res = bootstrap_apc_zscore(
                win[rics],
                n_boot=cfg.n_boot,
                min_names=cfg.min_names,
                method=cfg.bootstrap_method,
                block_size=cfg.block_size,
                random_state=cfg.random_state + hash((str(theme), str(end_dt))) % 1_000_000,
            )
            rows.append({"date": end_dt, "theme": theme, **res})
    return pd.DataFrame(rows).sort_values(["date", "theme"]).reset_index(drop=True)


# -----------------------------------------------------------------------------
# Residual basket returns and trend tests
# -----------------------------------------------------------------------------

def basket_residual_return_panel(
    residuals: pd.DataFrame,
    constituents: pd.DataFrame,
) -> pd.DataFrame:
    """Build date x theme panel of weighted residual returns."""
    residuals = residuals.sort_index()
    themes = sorted(constituents["theme"].unique())
    out = pd.DataFrame(np.nan, index=residuals.index, columns=themes)
    for dt in residuals.index:
        for theme in themes:
            c = latest_constituents_asof(constituents, dt, theme)
            if c.empty:
                continue
            rics = [r for r in c["ric"].tolist() if r in residuals.columns]
            if not rics:
                continue
            w = c.set_index("ric").loc[rics, "weight"].astype(float)
            r = residuals.loc[dt, rics].astype(float)
            valid = r.notna()
            if valid.sum() == 0:
                continue
            wv = w.loc[valid.index[valid]]
            wv = wv / wv.sum()
            out.loc[dt, theme] = float((wv * r.loc[valid]).sum())
    return out


def trend_test_from_apc_table(
    basket_resid_returns: pd.DataFrame,
    apc_table: pd.DataFrame,
    cfg: Optional[TrendTestConfig] = None,
) -> pd.DataFrame:
    """Replicate Exhibit 9/10-style trend regression.

    For each row in apc_table, calculate past 60-day and future 60-day cumulative
    basket residual returns. Split by APC z-score >= threshold and regress future
    on past separately.
    """
    cfg = cfg or TrendTestConfig()
    rows = []
    for _, row in apc_table.iterrows():
        dt = pd.Timestamp(row["date"])
        theme = row["theme"]
        if theme not in basket_resid_returns.columns:
            continue
        idx = basket_resid_returns.index
        if dt not in idx:
            prev = idx[idx <= dt]
            if len(prev) == 0:
                continue
            dt = prev[-1]
        loc = idx.get_loc(dt)
        if not isinstance(loc, (int, np.integer)):
            loc = int(np.asarray(loc).ravel()[-1])
        past = basket_resid_returns[theme].iloc[max(0, loc - cfg.lookback_days + 1):loc + 1].sum()
        future = basket_resid_returns[theme].iloc[loc + 1:loc + 1 + cfg.horizon_days].sum()
        if np.isfinite(past) and np.isfinite(future):
            rows.append({"date": dt, "theme": theme, "z": row["z"], "past_resid_ret": past, "future_resid_ret": future})
    panel = pd.DataFrame(rows)
    if panel.empty:
        return pd.DataFrame()

    def _ols_stats(df: pd.DataFrame) -> pd.Series:
        x = df["past_resid_ret"].to_numpy(float)
        y = df["future_resid_ret"].to_numpy(float)
        X = np.column_stack([np.ones(len(x)), x])
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
        resid = y - X @ beta
        n, p = X.shape
        s2 = (resid @ resid) / max(1, n - p)
        cov = s2 * np.linalg.pinv(X.T @ X)
        se = np.sqrt(np.diag(cov))
        t = beta[1] / se[1] if se[1] > 0 else np.nan
        ybar = y.mean()
        r2 = 1 - (resid @ resid) / np.sum((y - ybar) ** 2) if np.sum((y - ybar) ** 2) > 0 else np.nan
        return pd.Series({"coef": beta[1], "t_stat": t, "obs": n, "r2": r2})

    panel["significant"] = panel["z"] >= cfg.z_threshold
    res_sig = _ols_stats(panel[panel["significant"]]) if panel["significant"].any() else pd.Series(dtype=float)
    res_nsig = _ols_stats(panel[~panel["significant"]]) if (~panel["significant"]).any() else pd.Series(dtype=float)
    summary = pd.DataFrame({"z>=threshold": res_sig, "z<threshold": res_nsig}).T
    return summary


# -----------------------------------------------------------------------------
# Recommended LSEG field templates
# -----------------------------------------------------------------------------

LSEG_REF_FIELDS_JP = [
    "TR.RIC",
    "TR.CommonName",
    "TR.TRBCEconomicSector",
    "TR.TRBCBusinessSector",
    "TR.TRBCIndustryGroup",
    "TR.TRBCIndustry",
    "TR.TRBCActivity",
    "TR.TRBCIndustryCode",
    "TR.CompanyMarketCap",
    "TR.FreeFloatPct",
]

# Use these as starting points. Confirm field names/availability in Data Item Browser.
LSEG_TS_FIELDS_CANDIDATES = {
    "close": "TRDPRC_1",
    "volume": "ACVOL_UNS",
    "market_cap": "TR.CompanyMarketCap",
    "book_to_price": "TR.BookValuePerShare",  # usually combine with price; confirm entitlement/field availability
}


if __name__ == "__main__":
    print("This is a library. Import functions into a notebook/script for replication.")
