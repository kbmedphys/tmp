# 論文再現実装: Thematic Investing: A Risk-based Perspective

添付論文の中核手法を、日本株テーマバスケットと LSEG/Refinitiv データで再現するための研究用モジュールです。

## ファイル

- `thematic_paper_replication_lseg.py`
  - LSEG時系列取得ヘルパー
  - 構成銘柄RIC化
  - クロスセクション・リスクモデル残差化
  - 平均ペアワイズ残差相関(APC)計算
  - bootstrap APC z-score
  - 残差リターン・トレンド検定

## 推奨入力

### 1. テーマ構成銘柄

```text
date,theme,ticker,weight
2024-01-31,AI,6758,0.08
2024-01-31,AI,6501,0.07
2024-01-31,Semiconductor,8035,0.12
```

`ticker` は 4桁証券コード、Bloomberg風 `7203 JT Equity`、RIC `7203.T` のいずれでも可。

### 2. 個別株価格

LSEG `ld.get_history` により `TRDPRC_1` 等を取得。

### 3. クロスセクション・リスクモデル用データ

- TRBC業種
- 時価総額
- 出来高/売買代金
- 価格リターンから作るモメンタム、ボラティリティ
- 可能ならBook-to-Price等のValue指標

## 典型ワークフロー

```python
import pandas as pd
from thematic_paper_replication_lseg import *

ld = open_lseg_session()

# 1. 構成銘柄
const = read_constituents("constituents.csv")
ricks = sorted(const["ric"].unique())

# 2. 価格取得
prices = get_history_matrix_lseg(ricks, start="2016-01-01", field="TRDPRC_1")
returns = prices_to_returns(prices)

# 3. 参照データ取得
ref = get_reference_data_lseg(ricks, LSEG_REF_FIELDS_JP)
industry_map = ref.set_index("Instrument")["TRBC Industry"]  # 実際の列名はLSEG返却に合わせて調整

# 4. style exposure作成
exposures = build_dynamic_style_exposures(returns)
exposures = merge_static_industry(exposures, industry_map)

# 5. クロスセクション残差
resid, factor_ret = cross_sectional_residuals(returns, exposures)

# 6. APC z-score
analysis_dates = pd.date_range("2020-01-01", returns.index.max(), freq="M")
apc_table = compute_basket_apc_table(
    residuals=resid,
    constituents=const,
    analysis_dates=analysis_dates,
    cfg=APCConfig(apc_window_days=60, min_names=5, n_boot=1000, bootstrap_method="block")
)

# 7. 残差リターン・トレンド検定
basket_resid = basket_residual_return_panel(resid, const)
trend_summary = trend_test_from_apc_table(basket_resid, apc_table)
```

## 実装上の注意

論文の厳密な Mosaic + bootstrap は、株式×時間のタイルごとに回帰を再推定する高度な手法です。本モジュールは研究検証を始めるための近似実装として、列シャッフル・ブロックシャッフルの bootstrap を実装しています。本番では、タイル内回帰を再推定する厳密版へ拡張してください。
