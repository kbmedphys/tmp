# 今週のセクター配分

**User:** Anonymous  
**Created:** 7/12/2026 23:55:45  
**Updated:** 7/13/2026 0:16:29  
**Exported:** 7/13/2026 0:17:16  
**Link:** [https://chatgpt.com/c/6a53aa76-4928-83e8-9aa7-0eb917bd170d](https://chatgpt.com/c/6a53aa76-4928-83e8-9aa7-0eb917bd170d)  

## Prompt:
2026/7/12 23:55:42

今週１週間のニュースやイベントと対応つけてセクター配分の提案および解説と見通しのレポートを作成してください。セクター内の構成銘柄の構成にも配慮し関連イベントやニュースなどあれば見通しに加えること

[Attachment: weekly_outlook_20260712.md]

## Response:
2026/7/12 23:55:45

添付のGamma/GEXレポートを定量シグナルの基礎にしつつ、今週の経済指標・決算日程・地政学ニュース・ETF上位構成銘柄を外部情報で監査し、配分案を再構成します。特に日程と政策当局者名は誤りが運用判断に直結するため、一次情報を優先して確認します。

監査上、添付レポートの日程は概ね正確でした。Fed議長の上下両院証言、CPI・PPI・小売売上・住宅着工・鉱工業生産はいずれも公式日程で確認できました。一方、金曜引け後にホルムズ海峡の閉鎖報道が加わっており、XLEの単純Underweightは週初に再考が必要です。

構成銘柄まで織り込むと、添付案からの主な修正は三点です。XLEは週末の海峡閉鎖を受けてUnderweightから小幅なイベント・ヘッジへ、XLYはAmazonとTeslaだけで約42%を占めるためRetail Salesを根拠とする+1.5%をNeutralへ、XLKは半導体比重とモデル首位を踏まえ小幅Overweightへ変更します。

> **検証中の経済イベントと金融データ**
>
>
> **検証した経済イベントと金融データ**
>
> 
>
> **検索: 現在のFRB議長と経済指標の公開予定**
>
> [Gold’s CPI Test: Why September Fed Pricing Matters More Than July](https://www.investing.com/analysis/golds-cpi-test-why-september-fed-pricing-matters-more-than-july-200683713)
> [Schedule of Releases for the Producer Price Index](https://www.bls.gov/schedule/news_release/ppi.htm)
> [統計局ホームページ/消費者物価指数(CPI)](https://www.stat.go.jp/data/cpi/index.html)
> [Economic Indicator Release Schedule: List View](https://www.census.gov/economic-indicators/calendar-listview.html)
> [Federal Reserve Board - Beige Book](https://www.federalreserve.gov/monetarypolicy/publications/beige-book-default.htm)
> [「current」の意味・使い方・表現・読み方](https://eow.alc.co.jp/search?q=current)
> [Retail](https://en.wikipedia.org/wiki/Retail)
> [JR九州リテール](https://www.jr-retail.co.jp/)
> [currentとは・意味・使い方・読み方・例文 - 英ナビ!辞書 英和辞典](https://www.ei-navi.jp/dictionary/content/current/)
> [United States Consumer Price Index (CPI)](https://tradingeconomics.com/united-states/consumer-price-index-cpi)
> [リーテイルブランディング株式会社](https://www.retail-branding.co.jp/)
> [current | ロングマン現代英英辞典でのcurrentの意味 | LDOCE](https://www.ldoceonline.com/jp/dictionary/current)
> [リテールとは？意味や業界別の使われ方、ホールセールとの ...](https://tsun.ec/blogs/ec-tips/what-is-retail)
> [海流、流れ - CURRENT](https://jp.berlitz.com/wm/09/0722.htm)
>
> **検索した複数のウェブサイトと経済指標情報**
>
> 
>
> **Earningsプレビューの情報検索**
>
> [Trading surge, helped by SpaceX IPO, seen lifting Wall St banks' second-quarter earnings](https://www.reuters.com/legal/transactional/trading-surge-helped-by-spacex-ipo-seen-lifting-wall-st-banks-second-quarter-2026-07-07/)
> [7月](https://ja.wikipedia.org/wiki/7%E6%9C%88)
> [July](https://en.wikipedia.org/wiki/July)
> [July](https://open.spotify.com/intl-ja/artist/5UcydON50lbHbBJNiTzyAI)
> [julyって何月なんですか？ - 7月ですねー。January→一月 ...](https://detail.chiebukuro.yahoo.co.jp/qa/question_detail/q1346083658)
>
> **検索して多様な情報源から企業データを収集**
>
> 
>
> **確認とレポート作成**
>
> レポートの内容を決定する必要がありますが、週次報告を提案することが有益かもしれません。直接URLを記載する制限があるため、詳細はマークダウンファイルにまとめるべきです。
>
> **確認しレポートを作成した**
>
> 
>
> **レポート作成準備**
>
> レポートには、必要な価格情報や注目のイベント、企業の見通しを含めます。ナビゲーションリストを使い、ソースも明記。マークダウン形式で正確な内容を提供する方針です。
>
> 4m 26s考えました

# 今週の米国株セクター配分案  
**対象期間：2026年7月13日～17日**

添付のGamma/GEX・価格モメンタム・IV・Vanna/Charm分析を定量シグナルとして採用し、公式の経済指標日程、Fed議長証言、決算、ETF構成銘柄、週末の地政学ニュースを反映して再評価しました。添付レポートのイベント日程は概ね公式発表と整合しています。`weekly_outlook_20260712.md` 

## 1. 推奨アクティブ配分

米国株式スリーブ内の対ベンチマーク配分です。

| セクター | ETF | 判断 | Active |
|---|---|---:|---:|
| 金融 | XLF | 強めOverweight | **+1.50%** |
| 情報技術 | XLK | 小幅Overweight | **+0.75%** |
| エネルギー | XLE | 戦術的Overweight | **+0.50%** |
| ヘルスケア | XLV | 小幅Overweight | **+0.25%** |
| 一般消費財 | XLY | Neutral | **0.00%** |
| 資本財 | XLI | Neutral | **0.00%** |
| 素材 | XLB | Neutral | **0.00%** |
| コミュニケーション | XLC | Underweight | **-0.75%** |
| 生活必需品 | XLP | Underweight | **-0.75%** |
| 不動産 | XLRE | Underweight | **-0.75%** |
| 公益 | XLU | Underweight | **-0.50%** |
| **合計** |  |  | **0.00%** |

60/40ポートフォリオ全体に適用する場合、米国株比率が60%なら各Activeを0.6倍します。例えばXLFの総資産ベースの上乗せは約+0.90%です。

## 2. 添付モデルからの重要な変更

### XLE：Underweightから戦術的Overweightへ

添付モデルでは、XLEはNegative Gamma、Gamma Flip 55.21、Call/Put Wall 55、価格モメンタム最下位を理由に-1.56%でした。`weekly_outlook_20260712.md`

ただし、7月10日の米国市場引け後に、イラン側がホルムズ海峡を「追って通知するまで閉鎖」としたとの報道が加わっています。これは金曜終値に十分織り込まれておらず、Negative Gamma環境では月曜の上方ギャップが増幅される可能性があります。したがって中期的な強気判断ではなく、**地政学的テールリスクへの短期ヘッジとして+0.50%**としました。([Reuters](https://www.reuters.com/world/middle-east/irans-irgc-navy-says-strait-hormuz-closed-until-further-notice-state-media-2026-07-11/?utm_source=chatgpt.com))

XLEはExxon Mobil約19.8%、Chevron約14.7%、ConocoPhillips約5.9%で、上位3社だけで約40%を占めます。原油価格上昇のETFへの伝達は直接的です。一方、Marathon Petroleum、Phillips 66、Valeroなど精製企業は、原油高そのものよりクラックスプレッドや製品在庫の影響を受ける点に注意が必要です。([SSGA](https://www.ssga.com/ch/en_gb/intermediary/etfs/state-street-energy-select-sector-spdr-etf-xle?utm_source=chatgpt.com))

**条件付き運用**
- 55.21を上回って維持：+0.50%
- 原油高を伴い57.43を突破：最大+1.00%
- 海峡再開や停戦進展で55を割る：Neutralへ即時縮小

### XLY：+1.50%からNeutralへ

XLYはAmazon約23.1%、Tesla約19.1%で、上位2社だけで約42%を占めます。したがって、XLYは広範な米国消費の代理というより、短期的にはAmazon・Teslaの合成ポジションに近い構造です。Retail Salesが強くても、Tesla固有材料や金利・原油高で相殺され得るため、Negative Gamma下での+1.50%は過大と判断しました。([SSGA](https://www.ssga.com/us/en/intermediary/etfs/state-street-consumer-discretionary-select-sector-spdr-etf-xly?utm_source=chatgpt.com))

**120のCall Wallを明確に上回るまではNeutral**とします。

### XLK：Neutralから小幅Overweightへ

添付モデルでは総合スコア首位で、20日・50日移動平均線上、Gamma Flip 180.98を上回っています。ASMLとTSMCはXLKの構成銘柄ではありませんが、設備投資、EUV受注、先端ノード、AIアクセラレーター需要の情報が、NVDA、Broadcom、AMD、Micron、Applied Materials、Lam Researchなどに波及します。`weekly_outlook_20260712.md` ([SSGA](https://www.ssga.com/us/en/intermediary/etfs/state-street-technology-select-sector-spdr-etf-xlk?utm_source=chatgpt.com))

ただし、195のCall Wall、高いATM IV、Charm集中、17日の月次OPEXを考慮し、**+0.75%に限定**します。

## 3. 今週の重要イベント

| 日付 | イベント | 主な対象 |
|---|---|---|
| **7/13 月** | Fed高官発言、Fastenal決算 | XLI・XLB、金利感応株 |
| **7/14 火** | CPI、Kevin Warsh Fed議長の下院証言、大手銀行決算 | XLF、XLK、XLY、XLRE、XLU |
| **7/15 水** | PPI、Warsh議長の上院証言、Beige Book、ASML、JNJ、金融決算 | XLK、XLF、XLV、XLI |
| **7/16 木** | Retail Sales、失業保険、Philadelphia Fed、TSMC、Netflix | XLY、XLP、XLK、XLC |
| **7/17 金** | 輸入物価、住宅着工、鉱工業生産、Michigan、月次OPEX | XLRE、XLF、XLI、XLU、全般 |

CPIは7月14日、PPIは15日、輸入物価は17日、Retail Salesは16日、住宅着工と鉱工業生産は17日に予定されています。Warsh議長は14日に下院、15日に上院で半期金融政策報告を行います。([Bureau of Labor Statistics](https://www.bls.gov/schedule/news_release/current_year.asp))

## 4. セクター別の要点

### XLF：+1.50%

JPMorgan、Bank of America、Wells Fargo、Citigroup、Goldman Sachs、Morgan Stanleyなど今週決算を発表する銀行と、ETF構成銘柄の重複が大きい点が最大の強みです。主要銀行だけでXLFの約30%を占めます。([SSGA](https://www.ssga.com/us/en/intermediary/etfs/state-street-financial-select-sector-spdr-etf-xlf?utm_source=chatgpt.com))

トレーディング、投資銀行手数料、融資増加、純金利マージンには追い風が期待されますが、貸倒引当、カード延滞、商業不動産、預金コストを監視します。市場部門収益の増加が見込まれる一方、利益期待のハードル自体も高く、添付案の+2.00%から+1.50%に抑えました。([Reuters](https://www.reuters.com/legal/transactional/trading-surge-helped-by-spacex-ipo-seen-lifting-wall-st-banks-second-quarter-2026-07-07/?utm_source=chatgpt.com))

**54.13維持がOverweight条件。**

### XLV：+0.25%

Eli Lilly約16.4%、Johnson & Johnson約10.6%、AbbVie約7.5%、UnitedHealth約6.7%という構成です。JNJ決算は直接材料ですが、保険会社の医療費率上昇リスクも残ります。Positive Gammaと市場急変時の防御性を評価し、小幅Overweightとします。([SSGA](https://www.ssga.com/us/en/intermediary/etfs/state-street-health-care-select-sector-spdr-etf-xlv?utm_source=chatgpt.com))

### XLC：-0.75%

Netflix決算は注目されますが、NetflixのETF比率は約4.5%にすぎません。Meta約18.4%、Alphabetの2クラス合計約19.5%の方がはるかに大きく、XLC全体では広告需要、AI投資負担、長期金利、規制動向が重要です。([SSGA](https://www.ssga.com/us/en/intermediary/etfs/state-street-communication-services-select-sector-spdr-etf-xlc?utm_source=chatgpt.com))

Negative Gamma、50日線下、Gamma Flip 133.97が遠いため、**115～115.50を突破するまではUnderweight**です。

### XLP：-0.75%

Walmart、Costco、Procter & Gamble、Coca-Cola、Philip Morrisが中心です。防御性はありますが、原油・輸送・包装・農産物コストの上昇と、価格転嫁による販売数量減少が重なり得ます。([SSGA](https://www.ssga.com/us/en/intermediary/etfs/state-street-consumer-staples-select-sector-spdr-etf-xlp?utm_source=chatgpt.com))

Gamma Flip 84.59とCall Wall 85が近接しており、85未満ではUnderweightを維持します。`weekly_outlook_20260712.md`

### XLRE：-0.75%、XLU：-0.50%

XLREではWelltower、Prologis、Equinix、American Towerが上位です。データセンターや通信インフラはAI需要の恩恵を受けますが、ETF全体としては長期金利と資金調達コストへの感応度が高い構造です。([SSGA](https://www.ssga.com/uk/en_gb/intermediary/etfs/state-street-real-estate-select-sector-spdr-etf-xlre?utm_source=chatgpt.com))

XLUもNextEra、Southern、Duke Energyなど規制公益の比率が大きく、AI電力需要の恩恵だけでなく、金利上昇による相対バリュエーション悪化を受けます。([SSGA](https://www.ssga.com/ch/en_gb/intermediary/etfs/state-street-utilities-select-sector-spdr-etf-xlu?utm_source=chatgpt.com))

CPI鈍化と長期金利低下に加え、XLREは45、XLUは46を上抜けるまでUnderweightとします。

### XLI・XLB：Neutral

XLIは航空宇宙・防衛約26%、機械約21%、電気設備約14%で、防衛支出、AI向け電力設備、航空宇宙が追い風です。一方、原油高は輸送・航空・物流に逆風となります。航空会社の比率は約2%にすぎないため、原油高だけを理由にセクター全体をUnderweightにはしません。([SSGA](https://www.ssga.com/ch/en_gb/intermediary/etfs/state-street-industrial-select-sector-spdr-etf-xli?utm_source=chatgpt.com))

XLBはLinde約14.4%、Newmont約6.0%、Freeport-McMoRan約5.2%が上位です。金・銅・産業ガスと、化学・建材が混在しており、地政学・AIインフラの恩恵と金利・投入コスト上昇が相殺します。なお、AlcoaはXLBの主要構成銘柄ではなく、アルミ需要の読み替え指標として扱うべきです。([SSGA](https://www.ssga.com/ch/en_gb/intermediary/etfs/state-street-materials-select-sector-spdr-etf-xlb?utm_source=chatgpt.com))

## 5. シナリオ別の変更ルール

**CPI鈍化＋ホルムズ海峡再開**
- XLEを+0.50%から0%
- XLREを-0.75%から0%
- XLYを0%から+0.50%
- XLK・XLFを維持

**CPI上振れ＋海峡閉鎖継続**
- XLEを最大+1.00%
- XLREを-1.25%
- XLU・XLY・XLCのUnderweightを維持
- XLFは信用指標が悪化しない限り小幅Overweight

**ASML・TSMC好決算＋長期金利上昇**
- XLKは180.98以上で+0.75%を維持
- 195近辺で利食い
- XLRE・XLUは追随しない

**銀行決算で信用悪化**
- XLFを+1.50%から0～+0.50%へ縮小
- 54.13割れを価格面の撤退条件とする

## 6. ダウンロード

詳細な日次イベント対応、全11セクターの構成銘柄分析、シナリオ、監視水準を収録しています。

[監査済み週次セクター見通しレポートをダウンロード](sandbox:/mnt/data/weekly_sector_outlook_20260712_audited.md)

毎週日曜に、最新ニュース・決算・オプション水準を反映した同形式のレポートを更新する自動タスクも設定できます。

- [Reuters](https://www.reuters.com/world/middle-east/irans-irgc-navy-says-strait-hormuz-closed-until-further-notice-state-media-2026-07-11/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/legal/transactional/trading-surge-helped-by-spacex-ipo-seen-lifting-wall-st-banks-second-quarter-2026-07-07/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/markets/europe/wall-st-week-ahead-investors-grapple-with-packed-week-earnings-cpi-iran-2026-07-10/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/business/take-five/global-markets-themes-graphic-2026-07-10/?utm_source=chatgpt.com)

---

**Sources:**

- [XLE: State Street® Energy Select Sector SPDR® ETF](https://www.ssga.com/ch/en_gb/intermediary/etfs/state-street-energy-select-sector-spdr-etf-xle?utm_source=chatgpt.com)
- [Iran's IRGC navy says Strait of Hormuz closed until further notice, state media reports](https://www.reuters.com/world/middle-east/irans-irgc-navy-says-strait-hormuz-closed-until-further-notice-state-media-2026-07-11/?utm_source=chatgpt.com)
- [Schedule of Selected Releases 2026](https://www.bls.gov/schedule/news_release/current_year.asp)

## Prompt:
2026/7/13 0:06:10

モデル出力を最大限尊重して調整して

## Response:
2026/7/13 0:06:12

モデルの方向性とウェイトを原則そのまま採用し、ニュースは配分を反転させる材料ではなく、エントリー時点・縮小条件・損切り条件の調整に限定します。

モデル出力を主判断とし、ニュース・イベントは**方向の上書きではなく、執行タイミングと縮小・撤退条件の設定に限定**する形へ修正しました。添付モデルの最終配分を原則そのまま採用しています。`weekly_outlook_20260712.md`

## 修正後の配分

| セクター | ETF | 判断 | Active |
|---|---|---:|---:|
| 金融 | XLF | Overweight | **+2.00%** |
| 一般消費財 | XLY | Overweight | **+1.50%** |
| 情報技術 | XLK | Neutral | **0.00%** |
| ヘルスケア | XLV | Neutral | **0.00%** |
| 不動産 | XLRE | Neutral | **0.00%** |
| 資本財 | XLI | Neutral | **0.00%** |
| 公益 | XLU | Neutral | **0.00%** |
| 素材 | XLB | Neutral | **0.00%** |
| 生活必需品 | XLP | Underweight | **-0.78%** |
| コミュニケーション | XLC | Underweight | **-1.17%** |
| エネルギー | XLE | Underweight | **-1.56%** |

端数の-0.01%はキャッシュまたはベンチマークETFで調整します。

### 前回案からの主な修正

- **XLE：+0.50% → -1.56%**  
  地政学ニュースを理由にモデルのUnderweightを反転させません。原油急騰時は売りを一括で執行せず、55.21付近の定着失敗を確認して段階的に構築します。57.43超ではNeutralまで戻しますが、裁量でOverweightにはしません。

- **XLY：0.00% → +1.50%**  
  Amazon・Teslaへの集中はリスク管理要因として扱いますが、モデルの価格モメンタム改善と120までの戻り余地を優先します。111.74割れを縮小条件とします。

- **XLK：+0.75% → 0.00%**  
  総合スコア首位でも、高IV、Charm、195のCall Wall、月次OPEXを織り込んだモデルのNeutral判断を尊重します。

- **XLF：+1.50% → +2.00%**  
  総合2位、IV調整後1位、Positive Gamma、銀行決算との直接性を踏まえ、モデルウェイトへ戻しました。54.13割れを縮小条件とします。

[モデル優先版レポートをダウンロード](sandbox:/mnt/data/weekly_sector_outlook_20260712_model_first.md)

## Prompt:
2026/7/13 0:10:59

モデル出力を念頭にニュースで補足したい、マクロイベントやニュースをもとに解説を加えて。もしモデル出力がマクロやニュースと大きく乖離している場合は代替ウェイトを提案

## Response:
2026/7/13 0:11:01

モデルの配分方向は維持し、今週のマクロ・決算・地政学ニュースを「追認材料」「逆風材料」「乖離が大きいケース」に分けます。乖離が大きい場合のみ、元ウェイトを残したうえで代替ウェイトを併記します。

乖離判定では、週末にモデルの情報時点外で発生したホルムズ海峡問題がXLEに対する明確な例外です。XLYは原油高・インフレ・上位銘柄集中との条件付き乖離、XLREはFedのタカ派化との軽度な乖離と整理できます。

> **Browsing for July 2026 economic reports and news**
>
> [Federal Reserve Board - Calendar: July 2026](https://www.federalreserve.gov/newsevents/2026-july.htm)
> [Economic Indicator Release Schedule: List View](https://www.census.gov/economic-indicators/calendar-listview.html)
> [SCHEDULE | English meaning - Cambridge Dictionary](https://dictionary.cambridge.org/dictionary/english/schedule)
> [Producer Price Index News Release - 2026 M05 Results](https://www.bls.gov/news.release/ppi.htm)
> [BEIGE, | ベイジ,](https://www.beige-comma.com/)
> [SCHEDULE Definition & Meaning](https://www.merriam-webster.com/dictionary/schedule)
> [Luggage Bags & Travel Suitcases | July](https://july.com/us/)
> [「schedule」の意味・使い方・表現](https://eow.alc.co.jp/search?q=schedule)
>
> **検索した経済レポート、企業業績、マクロ情報**
>
> 
>
> **整理報告更新**
>
> 報告更新時，考慮提供準確的ETF持有資訊與原油市場的宏觀數據。如果需要，可創建更新的Markdown文件並包含來源連結。
>
> **整理報告更新**
>
> 
>
> **検索：セクターETFの主要構成銘柄**
>
> [XLK: State Street® Technology Select Sector SPDR® ETF](https://www.ssga.com/us/en/intermediary/etfs/state-street-technology-select-sector-spdr-etf-xlk)
>
> **検索したセクターETFの主要構成銘柄**
>
> 
>
> **整理報告與資料**
>
> 報告應包括執行摘要、宏觀評估和主要部門分析。考慮產生Markdown文件並包含簡單引用來源，但不要直接展示URL。
>
> **整理報告與資料**
>
> 
>
> **Searching official release schedules and economic events**
>
> [Industrial Production and Capacity Utilization - G.17](https://www.federalreserve.gov/releases/g17/)
> [US Consumer Confidence](https://www.conference-board.org/topics/consumer-confidence/)
> [Manufacturing Business Outlook Survey (MBOS)](https://www.philadelphiafed.org/surveys-and-data/regional-economic-analysis/manufacturing-business-outlook-survey)
> [News Release](https://www.dol.gov/ui/data.pdf)
>
> **検索した公式リリーススケジュールと経済イベント**
>
> 
>
> 3m 10s考えました

モデルの配分方向を主判断とし、ニュースは「モデルを補強する材料」と「情報時点後の例外」に分けて整理しました。モデルは2026年7月10日終値までを反映しているため、7月11日のホルムズ海峡関連ニュースだけは明確な情報時点外ショックとして扱います。`weekly_outlook_20260712.md`

**document: **

# 週次セクター配分レポート  
## モデル出力を主軸としたマクロ・ニュース補足版  
**対象期間：2026年7月13日～17日**

## 1．最終判断

### モデル基本ウェイト

| ETF | セクター | Active |
|---|---|---:|
| XLF | 金融 | **+2.00%** |
| XLY | 一般消費財 | **+1.50%** |
| XLK | 情報技術 | 0.00% |
| XLV | ヘルスケア | 0.00% |
| XLRE | 不動産 | 0.00% |
| XLI | 資本財 | 0.00% |
| XLU | 公益 | 0.00% |
| XLB | 素材 | 0.00% |
| XLP | 生活必需品 | **-0.78%** |
| XLC | コミュニケーション | **-1.17%** |
| XLE | エネルギー | **-1.56%** |

モデルの中心判断は維持します。特に、**XLFのOverweight、XLC・XLPのUnderweightはマクロ・ニュースとの整合性も高い**と評価します。

一方、モデル情報時点後のニュースを反映した「イベント前の暫定ウェイト」は次のとおりです。

### ニュース調整後の代替ウェイト

| ETF | モデル | 代替 | 乖離理由 |
|---|---:|---:|---|
| XLF | +2.00% | **+2.00%** | モデルと銀行決算材料が整合 |
| XLY | +1.50% | **+0.75%** | 原油高、インフレ、Amazon・Tesla集中 |
| XLRE | 0.00% | **-0.30%** | Fedのインフレ警戒と長期金利上昇リスク |
| XLP | -0.78% | **-0.78%** | Gamma構造と投入コスト上昇が整合 |
| XLC | -1.17% | **-1.17%** | ETF構成上、Netflix決算の寄与が限定的 |
| XLE | -1.56% | **-0.50%** | 週末のホルムズ海峡ショックがモデル情報時点外 |
| その他 | 0.00% | 0.00% | モデル判断を維持 |
| **合計** | -0.01% | **0.00%** |  |

この代替案はモデルを否定するものではありません。**月曜寄り付きから火曜CPIまでのイベントリスクを抑える暫定ポジション**です。

---

## 2．今週のマクロ環境

今週は、インフレ指標、Fed議長証言、決算シーズン入り、地政学リスクが集中します。

- **7月14日：CPI、Kevin Warsh Fed議長の下院証言**
- **7月15日：PPI、上院証言、Beige Book**
- **7月16日：Retail Sales、Business Inventories、Philadelphia Fed**
- **7月17日：Import Prices、Housing Starts、Building Permits、Industrial Production、月次OPEX**

これらの日程はFed、BLS、Census Bureauの公式日程で確認できます。([連邦準備制度](https://www.federalreserve.gov/newsevents/2026-july.htm?utm_source=chatgpt.com))

6月FOMC議事要旨ではインフレへの懸念が強まり、一部参加者は利上げの必要性を議論しました。Fedの7月金融政策報告も、関税、中東情勢、AI設備投資を価格上昇要因として重視しています。したがって今週は、強い経済指標が必ずしも株高要因とはならず、**長期金利上昇を通じてXLY、XLRE、XLU、高バリュエーション株の逆風になる可能性**があります。([連邦準備制度](https://www.federalreserve.gov/monetarypolicy/fomcminutes20260617.htm?utm_source=chatgpt.com))

---

## 3．セクター別評価

### XLF 金融：モデルとニュースは整合  
**判断：+2.00%を維持**

モデルでは総合2位、IV調整後1位、Positive Gamma、Gamma Flip 54.13より上です。`weekly_outlook_20260712.md`

XLFは銀行28.7%、金融サービス27.4%、資本市場26.1%で構成されています。JPMorgan、Bank of America、Goldman Sachs、Morgan Stanley、Wells Fargo、Citigroupの合計は約30%であり、今週の主要銀行決算がETFへ直接波及します。([State Street Global Advisors](https://www.ssga.com/us/en/intermediary/etfs/state-street-financial-select-sector-spdr-etf-xlf))

市場変動の拡大はトレーディング収益、資本市場活動、投資銀行手数料を支えやすく、今週の金融決算に対する市場期待も高い状態です。逆に確認すべき項目は、貸倒引当、カード延滞、商業不動産、預金コストです。([Reuters](https://www.reuters.com/markets/europe/wall-st-week-ahead-investors-grapple-with-packed-week-earnings-cpi-iran-2026-07-10/?utm_source=chatgpt.com))

**運用条件**
- 54.13以上：+2.00%維持
- 54.13割れ＋信用費用悪化：+1.00%へ縮小
- 複数行で信用悪化が確認され、54.13割れが定着：Neutral

---

### XLY 一般消費財：条件付きでマクロと乖離  
**モデル：+1.50%／イベント前代替：+0.75%**

モデルは20日・50日移動平均線の回復と、120のCall Wallまでの戻り余地を評価しています。`weekly_outlook_20260712.md`

一方、XLYはAmazon約23.1%、Tesla約19.1%で、上位2社だけで約42.2%を占めます。広範な米国消費だけでなく、Tesla固有材料、長期金利、Amazonの株価動向に強く左右される構造です。([State Street Global Advisors](https://www.ssga.com/us/en/intermediary/etfs/state-street-consumer-discretionary-select-sector-spdr-etf-xly?utm_source=chatgpt.com))

さらに、ホルムズ海峡の緊張と燃料供給逼迫は、ガソリン・物流コストを通じて実質可処分所得を圧迫します。これはモデルの価格モメンタムとやや乖離します。([Reuters](https://www.reuters.com/business/energy/fuel-markets-flash-supply-crunch-despite-calmer-oil-prices-2026-07-09/?utm_source=chatgpt.com))

したがって、月曜はモデルウェイトの半分である**+0.75%から開始**し、CPIとRetail Salesで+1.50%へ戻すかを判断するのが妥当です。

**運用条件**
- CPI鈍化、111.74維持、Retail Sales堅調：+1.50%
- CPI上振れまたは原油高継続：+0.75%
- Retail Sales悪化または111.74割れ：Neutral
- 120～122.74：利食い水準

---

### XLK 情報技術：ニュースは強いがモデルNeutralが妥当  
**判断：Neutral維持**

XLKは総合スコア首位ですが、高IV、Charm、Short-Dated GEX、Gamma Flip 180.98、Call Wall 195を理由にモデルはNeutralです。`weekly_outlook_20260712.md`

ETFの約46.5%が半導体・半導体製造装置であり、NVDA、Broadcom、AMD、Micron、Applied Materials、Lam ResearchなどへのASML・TSMC決算の波及度は高い構造です。([State Street Global Advisors](https://www.ssga.com/us/en/intermediary/etfs/state-street-technology-select-sector-spdr-etf-xlk?utm_source=chatgpt.com))

AI需要、先端ノード、設備投資は追い風ですが、FedはAI設備投資自体をインフレ圧力の一つとして注視しています。金利上昇とOPEX週のオプション要因まで含めると、モデルのNeutralは合理的です。([Reuters](https://www.reuters.com/business/fed-report-cites-stepped-up-inflation-2026-07-10/?utm_source=chatgpt.com))

**運用条件**
- 180.98以上：Neutral
- ASML・TSMCが強く、OPEX後も195突破：翌週のOverweight候補
- 180.98割れ：弱気化
- 175.86割れ：Underweight検討

---

### XLE エネルギー：モデルとニュースの最大の乖離  
**モデル：-1.56%／イベント前代替：-0.50%**

モデルは総合・IV調整後とも最下位で、Negative Gamma、Gamma Flip 55.21未回復、60日ドローダウンも大きい状態です。`weekly_outlook_20260712.md`

ただし、モデルの価格基準である7月10日終値後、7月11日にイラン側がホルムズ海峡の閉鎖を表明しました。米国側は商業交通が続いているとしていますが、これはモデルの情報集合に含まれない非連続ショックです。([Reuters](https://www.reuters.com/world/middle-east/irans-irgc-navy-says-strait-hormuz-closed-until-further-notice-state-media-2026-07-11/?utm_source=chatgpt.com))

XLEはExxon Mobil約19.8%、Chevron約14.7%、ConocoPhillips約5.9%であり、原油価格上昇の影響がETFへ直接波及します。精製企業も燃料供給逼迫と精製マージン上昇の恩恵を受ける可能性があります。([State Street Global Advisors](https://www.ssga.com/us/en/intermediary/etfs/state-street-energy-select-sector-spdr-etf-xle?utm_source=chatgpt.com))

したがって、モデル方向を反転させるのではなく、**Underweight幅を-0.50%に縮小**するのが適切です。

**運用条件**
- 55.21を回復できず、原油が反落：-1.56%へ戻す
- 55.21以上で推移：-0.50%
- 57.43超＋供給逼迫継続：Neutral
- Overweightまでは引き上げない

---

### XLC コミュニケーション：モデルとニュースは整合  
**判断：-1.17%維持**

モデルはNegative Gamma、50日線下、Gamma Flip 133.97が遠く、115のCall Wallが上値抵抗です。`weekly_outlook_20260712.md`

XLCはMeta約18.4%、Alphabetの2クラス合計約19.5%で、両社が約37.9%を占めます。Netflixは約4.5%にすぎないため、Netflix決算だけでXLC全体を強気転換するのは難しい構造です。([State Street Global Advisors](https://www.ssga.com/us/en/intermediary/etfs/state-street-communication-services-select-sector-spdr-etf-xlc?utm_source=chatgpt.com))

前回Netflix決算後は、ガイダンスへの失望などから株価が大きく下落しており、今回は広告収益と利益率の改善が焦点になります。([Reuters](https://www.reuters.com/business/netflix-shares-fall-after-downbeat-revenue-forecast-co-founder-leave-2026-04-17/?utm_source=chatgpt.com))

**運用条件**
- 115未満：-1.17%維持
- 115.50超＋Meta・Alphabetも上昇：Neutral
- 107.78割れ：Underweight拡大

---

### XLP 生活必需品：概ねモデルと整合  
**判断：-0.78%維持**

XLPはNegative Gamma、Gamma Flip 84.59、Call Wall 85、Short-Dated Riskという弱い構造です。`weekly_outlook_20260712.md`

Walmart、Costco、P&G、Coca-Colaなど防御的企業が中心ですが、ETFの約33%が小売、約20%が飲料、約15%が食品であり、燃料、輸送、包装、農産物コスト上昇の影響を受けます。([State Street Global Advisors](https://www.ssga.com/us/en/intermediary/etfs/state-street-consumer-staples-select-sector-spdr-etf-xlp?utm_source=chatgpt.com))

地政学的リスクオフでは相対的に底堅くなり得ますが、現状ではモデルのUnderweightを変更するほどの乖離ではありません。

**運用条件**
- 85未満：-0.78%
- 市場急落時に85突破・相対強度上昇：Neutral
- 81.94割れ：Underweight拡大

---

### XLRE 不動産：軽度のマクロ乖離  
**モデル：Neutral／イベント前代替：-0.30%**

モデルはPositive Gammaですが、45のCall Wall直下です。`weekly_outlook_20260712.md`

XLREはWelltower、Prologis、Equinix、American Towerなどを含み、データセンターや通信インフラ需要の恩恵があります。一方、予想PERは高く、資金調達コストと長期金利への感応度が高いセクターです。([State Street Global Advisors](https://www.ssga.com/us/en/intermediary/etfs/state-street-real-estate-select-sector-spdr-etf-xlre?utm_source=chatgpt.com))

Fedのインフレ警戒と利上げ議論を考慮すると、CPI前は**-0.30%の小幅Underweight**が妥当です。

**運用条件**
- CPI鈍化＋金利低下＋45突破：Neutralへ復帰
- 43割れ：Underweight拡大

---

## 4．日別の実行方針

### 7月13日
- XLFは+2.00%を執行
- XLYは+0.75%のみ
- XLEは-0.50%に抑え、55.21の攻防を確認
- XLREは-0.30%

### 7月14日：CPI・Fed議長証言・銀行決算
- CPI鈍化：XLYを+1.50%、XLREをNeutralへ
- CPI上振れ：XLYを+0.75%以下、XLRE -0.30%継続
- XLFは信用費用が悪化しない限り+2.00%

### 7月15～16日：PPI、ASML、TSMC、Netflix
- XLKは好決算でもOPEX前はNeutral
- XLCはNetflix単独ではUnderweightを解除しない
- XLYはRetail Salesで最終ウェイトを決定

### 7月17日：住宅・鉱工業生産・OPEX
- Gamma壁付近のピン留めと、壁抜け時の加速を警戒
- XLEの地政学ポジションは週末前に再評価

---

## 5．推奨する最終運用案

今週は、モデルをそのまま適用するよりも、**月曜からCPIまでは次の代替ウェイトを使用し、イベント通過後にモデルウェイトへ収束させる方法**を推奨します。

- XLF **+2.00%**
- XLY **+0.75%**
- XLRE **-0.30%**
- XLP **-0.78%**
- XLC **-1.17%**
- XLE **-0.50%**
- その他 Neutral

XLEはモデルとニュースの乖離が最も大きいものの、モデルの方向を完全には反転させず、Underweight幅の縮小で対応します。XLYもモデルの上昇シグナルを残しつつ、原油高・インフレ・構成銘柄集中を考慮して半分だけ執行します。

XLF、XLC、XLPはモデルとニュースの整合度が高いため、元ウェイトを維持します。

[更新版レポートをダウンロード](sandbox:/mnt/data/weekly_sector_outlook_20260712_model_news_overlay.md)

主要ニュース：
- [Reuters](https://www.reuters.com/business/fed-minutes-due-analysts-debate-whether-warsh-will-curtail-them-2026-07-08/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/business/take-five/global-markets-themes-graphic-2026-07-10/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/business/energy/fuel-markets-flash-supply-crunch-despite-calmer-oil-prices-2026-07-09/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/business/energy/us-iran-escalation-could-threaten-2027-oil-market-surplus-iea-says-2026-07-10/?utm_source=chatgpt.com)

毎週日曜に、モデル出力と週末ニュースの乖離だけを検出して代替ウェイトを提示する更新タスクを設定できます。

---

**Sources:**

- [Federal Reserve Board - Calendar: July 2026](https://www.federalreserve.gov/newsevents/2026-july.htm?utm_source=chatgpt.com)
- [XLF: State Street® Financial Select Sector SPDR® ETF](https://www.ssga.com/us/en/intermediary/etfs/state-street-financial-select-sector-spdr-etf-xlf)
- [Wall St Week Ahead Investors to grapple with packed week of earnings, CPI, Iran headlines](https://www.reuters.com/markets/europe/wall-st-week-ahead-investors-grapple-with-packed-week-earnings-cpi-iran-2026-07-10/?utm_source=chatgpt.com)



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)