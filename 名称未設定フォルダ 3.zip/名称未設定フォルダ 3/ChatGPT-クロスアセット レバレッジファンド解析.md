# クロスアセット レバレッジファンド解析

**User:** Anonymous  
**Created:** 7/13/2026 0:04:01  
**Updated:** 7/13/2026 0:25:21  
**Exported:** 7/13/2026 0:26:49  
**Link:** [https://chatgpt.com/c/6a53ace1-35e4-83e8-ac64-f3db42f6743b](https://chatgpt.com/c/6a53ace1-35e4-83e8-ac64-f3db42f6743b)  

## Response:
2026/7/13 0:04:02

対象を総エクスポージャー100%超のクロスアセット商品に絞り、単純倍率では不変な相関と設計上の歪みを区別します。文献・実装・配分ルールを整理し、GEX＋IEF運用へ接続します。

相関の非線形化要因として、動的レバレッジ、担保流動性、ロール、株債レジーム、リバランスを検証します。併せてGEXと逆ボラ運用による低ボラ評価の二重計上に注意します。

商品を90/60型、100/100型、リスクパリティ型、日次倍率型に分類し、実装別の相関崩壊を比較します。IEFはNAV比率でなくkey-rate DV01、GEXは配分決定変数でなく短期状態変数として扱います。

> **Searching stock-bond correlation, funds, and related literature**
>
>
> **検索して関連資料とETF戦略を確認**
>
> 
>
> **計算ファンドのボラティリティと相関**
>
>
> **計算ファンドのボラティリティと相関関係**
>
> 
>
> **文献検索：キャリートレードと資産クラス의相関**
>
> [Carry](https://www.sciencedirect.com/science/article/abs/pii/S0304405X17302908)
> [Carry](https://www.nber.org/papers/w19325)
> [Understanding the Sources of Risk Underlying the Cross- ...](https://www.aeaweb.org/conference/2015/retrieve.php?pdfid=7750&tk=DDyfabe4)
> [「carry」の意味・使い方・表現・読み方](https://eow.alc.co.jp/search?q=carry)
> [Carry](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2298565)
> [Journal of Financial Economics Carry](https://spinup-000d1a-wp-offload-media.s3.amazonaws.com/faculty/wp-content/uploads/sites/3/2019/04/Carry.pdf)
> [carry - 英和辞典](https://www.sanseido.jp/site/07ncdic/JCE001284.html)
> [Carry](https://ideas.repec.org/a/eee/jfinec/v127y2018i2p197-225.html)
> [CARRY | 意味, Cambridge 英語辞書での定義](https://dictionary.cambridge.org/ja/dictionary/english/carry)
> [動詞Carryの使い方](https://loopal.net/english/carry/)
> [A Better Specified Asset Pricing Model to Explain the Cross ...](https://conference.nber.org/confer/2013/CWf13/Bakshi_Gao_Rossi.pdf)
> [動詞を変化させる carry 英語](https://doushi.reverso.net/%E6%B4%BB%E7%94%A8-%E8%8B%B1%E8%AA%9E-%E5%8B%95%E8%A9%9E-carry.html)
> [Carry | Request PDF](https://www.researchgate.net/publication/321239060_Carry)
> [bringとcarryの違いをズバリ！「運ぶ」の英語表現まとめ！](https://aitem-english.jp/difference-bring-carry)
> [Michael Aked's Post](https://www.linkedin.com/posts/michael-aked_the-power-of-carry-across-diverse-asset-activity-7107513117357527040-Pz-T)
> [CARRY - Basic Verbs - Learn English Grammar](https://www.youtube.com/watch?v=FeaZByFV9Pk)
> [Koijen, Ralph S.J.; Moskowitz, Tobias; Pedersen, Lasse Heje](https://research-api.cbs.dk/ws/portalfiles/portal/57294842/lasse_heje_pedersen_et_al_carry_acceptedmanuscript.pdf)
> [徹底解説！carryと基本文型！よく使われる熟語やイディオム ...](https://eigo-channel.net/?p=275960)
> [Carry∗ - NYU Stern](https://pages.stern.nyu.edu/~lpederse/papers/Carry.pdf)
>
> **検索した様々な研究資料とウェブサイト**
>
> 
>
> **整理した企画案の作成**
>
> ユーザーのリクエストにより、クロスアセットのレバレッジファンドを代表する例として、米国上場ファンドをリストアップします。NTSXやNTSI、RSシリーズを加え、100%のエクスポージャーを明示します。
>
> **作成した企画案を整理した**
>
> 
>
> **Searching GEX integration and Treasury bond details**
>
>
> **検索した複数のファンド情報とウェブサイト**
>
> 
>
> **整理と調整**
>
> BLNDXをミューチュアルファンドの例として追加するか迷いますが、リストが大きすぎるかもしれません。AQRIXやBLNDXは事例として挙げる価値がありますが、それぞれの正確なレバレッジやノーションは公開ページでは明記されていません。
>
> **整理と調整を行った**
>
> 
>
> **Searching leveraged fund methodologies and managed futures strategies**
>
> [iMGP DBi Managed Futures Strategy ETF [DBMF]](https://www.imgp.com/wp-content/uploads/2026/03/DBMF-Quarterly-Deck.pdf)
> [Managed Futures ETF | KMLM | KraneShares Mount Lucas ...](https://kraneshares.com/etf/kmlm/)
> [CTA Simplify Managed Futures Strategy ETF](https://www.simplify.us/etfs/cta-simplify-managed-futures-strategy-etf)
> [WTMF - WisdomTree Managed Futures Strategy Fund](https://www.wisdomtree.com/us/products/alternative/wtmf)
> [Managed Futures ETF Overview | KMLM](https://engage.kraneshares.com/s/c3e5b938/managed-futures-etf-kmlm-presentation/)
>
> **検索したレバレッジドファンドと管理先物戦略**
>
> 
>
> **ウェブを検索中**
>
> [Volatility Managed Portfolios | NBER](https://www.nber.org/papers/w22208)
> [The Impact of Volatility Targeting by Campbell R. Harvey, Edward Hoyle, Russell Korgaonkar, Sandy Rattray, Matthew Sargaison, Otto Van Hemert :: SSRN](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3175538)
> [academic.oup.com](https://academic.oup.com/rfs/article/39/3/702/8203077)
> [www.sec.gov](https://www.sec.gov/Archives/edgar/data/1742912/000199937125005019/upar_497k-042525.htm)
>
> **ウェブサイトを検索した**
>
> 
>
> **クロスアセットレバレッジファンドについての説明**
>
> ユーザーからのリクエストに基づき、クロスアセットのレバレッジファンドの詳細な相関関係や代表的なETFをリストアップします。ETFや相関性の解説は透明性を保ちながら進めます。
>
> **ウェブを検索中**
>
> [Introducing the WisdomTree 90/60 U.S. Balanced Fund (NTSX) | WisdomTree](https://www.wisdomtree.com/us/insights/blog/introducing-the-wisdomtree-90-60-us-balanced-fund-ntsx)
>
> **検索してwww.wisdomtree.comとwww.nber.orgを調べた**
>
> 
>
> **相関関係とボラティリティ計算**
>
>
> **計算した相関関係とボラティリティ**
>
> 
>
> **相関構造の説明**
>
> 仮定を使って相関を説明する必要はないかもしれませんが、異なるファクター負荷を隠す高い相関が実際には別のヘッジ構造を意味することを示したいです。
>
> **ウェブを検索中**
>
> [Is the Traditional 60/40 Dead? Redefining Diversification with Efficient Core Solutions | WisdomTree](https://www.wisdomtree.com/us/insights/blog/is-the-traditional-60-40-dead-redefining-diversification-with-efficient-core-solutions)
>
> **検索して www.wisdomtree.com と www.returnstackedetfs.com を確認**
>
> 
>
> 21m 18s考えました

# 要旨

クロスアセット・レバレッジファンドについて、最も重要な点は次の3つです。

1. **同じポートフォリオを単純に比例レバレッジしただけなら、理論上、相関係数は変わりません。**  
   例えば90%株式＋60%債券は、60%株式＋40%債券を1.5倍したものなので、取引費用、資金調達、先物ベーシス、リバランス誤差を無視すれば両者の相関は1です。変わるのはボラティリティ、β、VaR、ES、ドローダウンの大きさです。

2. **実商品の相関構造を変えるのは、レバレッジそのものではなく、相対配分、動的なポジション決定、先物ベーシス、証拠金制約です。**  
   100%株式＋100%債券、リスクパリティ、トレンド、キャリーなどは、通常の60/40を単純に拡大したものではないため、株式β、DV01、インフレβ、流動性βが変わります。

3. **GEXでセクター配分し、IEFを組み合わせている場合、ファンドをNAV比率で足し算してはいけません。**  
   セクターβ、満期別key-rate DV01、トレンド・キャリー・金・暗号資産等のオルタナティブβに分解して管理すべきです。特にNTSX、RSSB、RSBT、RSBY、RSBA、RPAR/UPARは、IEFとかなりの金利リスクを重複させます。

以下、2026年7月12日時点の情報に基づきます。これはポートフォリオ構築上の分析であり、個別商品の売買推奨ではありません。

---

# 1. レバレッジと相関の数理的関係

基礎資産の超過リターンを $x_t$、ファンド $j$ のNAV当たりルックスルー・エクスポージャーを $a_{j,t-1}$ とすると、

$$
r_{j,t}^{e}
\simeq
a_{j,t-1}^{\top}x_t
-c_{j,t}
+\varepsilon_{j,t}
$$

と書けます。ここで $c_{j,t}$ は資金調達、ロール、ベーシス、手数料等、$\varepsilon$ はトラッキング誤差です。

条件付き共分散は概ね、

$$
\operatorname{Cov}_{t-1}(r_j,r_k)
\simeq
a_j^{\top}\Sigma_t a_k
+
\operatorname{Cov}_{t-1}(\varepsilon_j,\varepsilon_k)
$$

したがって、

$$
\rho_{jk,t}
\simeq
\frac{a_j^{\top}\Sigma_t a_k}
{\sqrt{a_j^{\top}\Sigma_t a_j}
 \sqrt{a_k^{\top}\Sigma_t a_k}}
$$

です。

## 単純な比例レバレッジ

無レバファンドのエクスポージャーを $a_U$、レバレッジ倍率を $L>0$ として、

$$
a_L=L a_U
$$

ならば、

$$
\rho(r_L,r_U)=1
$$

であり、任意の因子 $f$ に対しても、

$$
\rho(r_L,f)=\rho(r_U,f)
$$

です。一方、

$$
\operatorname{Var}(r_L)=L^2\operatorname{Var}(r_U),
\qquad
\beta_{L,f}=L\beta_{U,f}
$$

となります。

つまり、

> **相関係数は変わらなくても、損益感応度と損失額はレバレッジ倍率に応じて増える**

ということです。

## 90/60と60/40

$$
(0.9,0.6)=1.5(0.6,0.4)
$$

なので、理想的な90/60は60/40の純粋な1.5倍です。NTSXは実際に90%の大型株、10%の短期債券・現金相当物を担保として、2・5・10・30年米国債先物で60%の債券エクスポージャーを構成し、目標から5%乖離するとリバランスする設計です。([WisdomTree](https://www.wisdomtree.com/us/insights/blog/introducing-the-wisdomtree-90-60-us-balanced-fund-ntsx))

ただし、ユーザーのポートフォリオは「セクターETF＋IEF」なので、NTSXとの間には次の差があります。

- 株式側：セクターGEX配分ではなく米国大型株時価総額配分
- 債券側：IEFの7～10年集中ではなく、2～30年の先物ラダー
- ファンディング：現物IEFと先物オーバーレイのベーシス差
- リバランス：セクターGEX更新とNTSXのリバランス規則が異なる

したがって、60/40と90/60の理論相関は1でも、**GEXセクターポートフォリオ＋IEFとNTSXの実現相関は1ではありません**。

## 100/100は60/40の単純レバレッジではない

100%株式＋100%債券は、ノーショナルで見れば50/50です。60/40とは相対配分が違うため、債券β・DV01が相対的に大きくなります。

例えば、

$$
\sigma_E=16\%,\quad \sigma_B=7\%,\quad \rho_{E,B}=-0.2
$$

と仮定すると、

$$
\rho(60/40,90/60)=1.000
$$

ですが、

$$
\rho(60/40,100/100)\approx0.990
$$

です。0.99という非常に高い相関であっても、100/100の方が債券βとDV01はかなり大きくなります。

したがって、

> **ファンド同士の高い相関は、リスク構成が同じことを意味しません。**

---

# 2. 実際のファンドで相関構造が変わる要因

| 要因 | 相関構造への影響 |
|---|---|
| 相対ウェイトの変更 | 90/60と100/100、リスクパリティなどでは株式β・DV01・インフレβが変わる |
| 動的ボラティリティ・ターゲット | 低ボラ時にレバレッジを増やし、高ボラ・高相関時に減らすため、状態依存のβと負のコンベクシティが生じる |
| トレンドフォロー | ポジションの符号自体が変わる。平常時は低相関でも、急落初期にはまだ株式ロング・債券ロングの可能性がある |
| キャリー | 平均相関は低くても、資金調達・流動性・グローバル景気後退時に損失が同期し得る |
| 先物・スワップ実装 | ロール、CTD、レポ、先物ベーシス、担保利回りが追加因子となる |
| 証拠金・流動性制約 | 相関が上昇した後に共通のデレバレッジが発生し、ファンド間のテール依存を高める |
| リバランス頻度 | 日次、四半期、乖離幅ベースでは、同じ長期目標配分でも短期パス依存性が異なる |

## 動的レバレッジの問題

ボラティリティ・ターゲットを

$$
L_t=\frac{\sigma^\ast}{\widehat{\sigma}_{p,t}}
$$

とすると、低ボラ・低相関局面ほど $L_t$ は大きくなります。一方、ショック発生後にボラティリティとクロスアセット相関が上昇すると、遅れて一斉にポジションを落とすことになります。

このため、

- ショック前：見かけ上のリスクが低く、レバレッジが最大化
- ショック当日：高いレバレッジのまま損失
- ショック後：価格下落後にデレバレッジ

というプロシクリカルな挙動が生じます。

ただし、すべての「リスクパリティ」商品が日次でこのルールを実行するわけではありません。例えばUPARは、長期ヒストリカル・ボラティリティで定めたRPARの資産配分を四半期ごとに1.4倍し、目標配分自体は市場環境に応じて変えない設計です。したがって、ECBが分析した日次ボラターゲット型リスクパリティとは区別すべきです。([SEC](https://www.sec.gov/Archives/edgar/data/1742912/000199937125005019/upar_497k-042525.htm))

## Pearson相関より条件付き・テール相関が重要

実務上は、全期間の相関だけでなく、

$$
\rho(r_j,r_E\mid \text{GEX sign},\text{inflation regime})
$$

や、

$$
\lambda_L(\alpha)
=
P\left(
r_j\le q_j(\alpha)
\mid
r_p\le q_p(\alpha)
\right)
$$

を見るべきです。

特に、次の3つは区別する必要があります。

1. **基礎資産間の相関**：株式と債券、金、商品、FX等の $\Sigma_t$
2. **ファンドと因子の相関**：ファンドのエクスポージャーベクトル $a_t$ で決まる
3. **ファンド間の内生的相関**：共通のボラ推定、証拠金、リバランスにより生じる

---

# 3. 関連する文献・公的機関の分析

## 近年の重要な論点

| 出典 | 主な内容 | 本件への含意 |
|---|---|---|
| IMF, “Stock-Bond Diversification Offers Less Protection From Market Selloffs,” 2026 | 2020年以降、急激な市場下落時に株式と債券が同時に下落するケースが増え、レバレッジを使うリスクパリティ等が強制デレバレッジに陥りやすくなったと指摘。相関構造の転換点を2019年末頃としている。([IMF](https://www.imf.org/en/blogs/articles/2026/02/18/stock-bond-diversification-offers-less-protection-from-market-selloffs)) | IEFを含む名目国債レバレッジを、過去の負相関だけで評価すべきでない |
| Fang, Liu and Roussanov, “Getting to the Core,” *Review of Financial Studies*, 2026 | 株式はコアインフレに負のβ、エネルギーインフレに正のβ。米国債は両方に負のβ。コアとエネルギーの寄与変化が株式・債券相関の時変性を説明するとする。([OUP Academic](https://academic.oup.com/rfs/article/39/3/702/8203077)) | 「インフレ上昇」だけでなく、コア型かエネルギー型かでIEF・金・商品・株式の役割が変わる |
| ECB, “Volatility-targeting strategies and the market sell-off,” 2020 | 低ボラ・低相関時にはレバレッジが増え、ボラと相関上昇時には資産売却が必要になると分析。8%ボラターゲットのモデルでは、ショック前に最大約2倍のポジションを取り、ショック後には資本の約225%相当を売却、約25%を現金化する結果。([European Central Bank](https://www.ecb.europa.eu/press/financial-stability-publications/fsr/focus/2020/html/ecb.fsrbox202005_02~f6616db9be.en.html)) | 低い実現ボラを「低い潜在リスク」と誤認しない。共通デレバレッジをストレスに入れる |
| BIS, “Leverage and margin spirals in fixed income markets during the Covid-19 crisis,” 2020 | 2020年3月に米国債が安全資産として機能しない局面があり、レバレッジ投資家の強制売却、先物・現物ベーシス、証拠金上昇が価格下落を自己強化したと分析。これはクロスアセットファンドを直接検証したものではないが、債券レッグの流動性リスクを示す。([国際決済銀行](https://www.bis.org/publ/bisbull02.pdf)) | IEFや米国債先物を「常に流動性を供給するヘッジ」と仮定しない |
| Moreira and Muir, “Volatility-Managed Portfolios,” *Journal of Finance*, 2017 | ボラティリティが高いときにリスクを減らす戦略が、複数の株式因子やFXキャリーで過去のSharpeを改善したと報告。ボラ上昇に期待リターンが比例して上昇しないことが理由とされる。([NBER](https://www.nber.org/papers/w22208)) | ボラターゲットの理論的根拠。ただし、市場インパクトや共通デレバレッジとは別問題 |
| Harvey et al., “The Impact of Volatility Targeting,” 2018 | Sharpe改善は主に株式・クレジット等のリスク資産に集中し、債券、通貨、商品では小さい。一方、左尾損失の抑制は幅広い資産で観察されたとする。([SSRN](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3175538)) | すべての資産を一律に逆ボラでスケーリングする合理性は限定的 |
| Koijen et al., “Carry” | キャリーは株式、債券、FX、商品、クレジット、オプション等でリターンを予測する一方、平常時の低相関にもかかわらず、グローバル景気後退時には各資産のキャリー戦略が同時に悪化し得ると報告。([NBER](https://www.nber.org/papers/w19325)) | RSSY・RSBY等は全期間相関より景気後退時の条件付き相関を重視すべき |

文献を総合すると、近年の主題は「通常時の相関」よりも、

- 株式・債券相関のレジーム転換
- ボラターゲットのプロシクリカリティ
- 証拠金・ベーシスによる流動性ショック
- 平均相関とテール相関の乖離

に移っています。

---

# 4. 代表的なクロスアセット・レバレッジファンド

以下は、米国上場でルックスルー情報が比較的入手しやすい代表例です。網羅的なリストではありません。Return Stackedシリーズについては、2026年7月9日時点で以下の主要8商品が掲載されています。([Return Stacked® ETFs](https://www.returnstackedetfs.com/))

## 4.1 固定配分・キャピタルエフィシェント型

| ファンド | 目標エクスポージャー | ポジション決定 |
|---|---|---|
| **NTSX** | 米国大型株90%＋米国債先物60%＋担保10% | 株式は米国大型株。債券は2・5・10・30年米国債先物。NTSXは目標から5%乖離するとリバランス。([WisdomTree](https://www.wisdomtree.com/us/insights/blog/introducing-the-wisdomtree-90-60-us-balanced-fund-ntsx)) |
| **NTSI** | 先進国株式90%＋米国債先物60%＋担保10% | 対象地域の大型株＋2～30年米国債先物。基本的に戦略的固定配分。([WisdomTree](https://www.wisdomtree.com/us/insights/blog/is-the-traditional-60-40-dead-redefining-diversification-with-efficient-core-solutions)) |
| **NTSE** | 新興国株式90%＋米国債先物60%＋担保10% | 新興国大型株＋2～30年米国債先物。([WisdomTree](https://www.wisdomtree.com/us/insights/blog/is-the-traditional-60-40-dead-redefining-diversification-with-efficient-core-solutions)) |
| **GDE** | 米国大型株90%＋金先物90%＋担保10% | 株式と金の固定的な90/90スタック。債券レッグは持たない。([WisdomTree](https://www.wisdomtree.com/us/insights/blog/is-the-traditional-60-40-dead-redefining-diversification-with-efficient-core-solutions)) |
| **RSSB** | グローバル株式100%＋米国債100% | 株式は時価総額加重のグローバル株式。債券は2～30年米国債先物。([Return Stacked® ETFs](https://www.returnstackedetfs.com/rssb-return-stacked-global-stocks-bonds/)) |
| **RPAR / UPAR** | グローバル株式、商品関連株・金、TIPS、米国債 | 長期ヒストリカル・ボラティリティに基づくリスクパリティ。UPARはRPARのエクスポージャーを四半期ごとに1.4倍し、総経済エクスポージャー160～180%を目標。市場環境による目標配分変更は原則行わない。([SEC](https://www.sec.gov/Archives/edgar/data/1742912/000199937125005019/upar_497k-042525.htm)) |

## 4.2 株式または債券＋動的オルタナティブ

| ファンド | 目標スタック | ポジション決定 |
|---|---|---|
| **RSST** | 米国大型株1倍＋マネージド・フューチャーズ1倍 | 商品、FX、株価指数、債券先物のトレンド。日次リバランス。開示モデルでは30%を主要CTA群のリターン回帰によるトップダウン複製、70%を時系列モメンタム、移動平均、ブレイクアウト等のボトムアップモデルに配分。([Return Stacked® ETFs](https://www.returnstackedetfs.com/rsst-return-stacked-us-stocks-managed-futures/)) |
| **RSIT** | 海外大型株1倍＋マネージド・フューチャーズ1倍 | 海外株式と、商品、FX、株式、債券先物のトレンド戦略。([Return Stacked® ETFs](https://www.returnstackedetfs.com/rsit-international-stocks-managed-futures/)) |
| **RSBT** | 米国総合債券1倍＋マネージド・フューチャーズ1倍 | 債券側は米国債、総合債券ETF、米国債先物。トレンド側は4資産をロング・ショートし、日次リバランス。([Return Stacked® ETFs](https://www.returnstackedetfs.com/rsbt-return-stacked-bonds-managed-futures/)) |
| **RSSY** | 米国大型株1倍＋先物キャリー1倍 | 商品、FX、債券、株価指数先物を、ロールイールドに基づきロング・ショート。日次リバランス。([Return Stacked® ETFs](https://www.returnstackedetfs.com/rssy-return-stacked-us-stocks-futures-yield/)) |
| **RSBY** | 米国総合債券1倍＋先物キャリー1倍 | 債券ベースに加え、4資産のキャリー。債券側の例は75%総合債券ETF＋2・5・10・長期米国債先物各6.25%。キャリー戦略も米国債先物をロング・ショートするため、ネットDV01は動的。([Return Stacked® ETFs](https://www.returnstackedetfs.com/rsby-return-stacked-bonds-futures-yield/)) |
| **RSBA** | 米国債1倍＋M&Aアービトラージ1倍 | 米国債は2・5・10・長期先物を概ね均等配分する例。M&A側は発表済み案件のターゲット株をディスカウントで買い、株式交換案件では買収企業をショート。指数はイベントドリブン。([Return Stacked® ETFs](https://www.returnstackedetfs.com/rsba-return-stacked-bonds-merger-arbitrage/)) |
| **RSSX** | 米国株式1倍＋金・Bitcoin戦略1倍 | 金とBitcoinの予測ボラティリティを用いてリスク寄与を均等化。通常は金75～95%、Bitcoin5～25%。([SEC](https://www.sec.gov/Archives/edgar/data/1924868/000183988225008306/rssx_485apos-021125.htm)) |

ここで「マネージド・フューチャーズ100%」や「キャリー100%」は、単純な先物ノーショナル合計がNAVの100%という意味ではなく、**戦略リターンへの1倍エクスポージャー**です。各先物の生ノーショナルは、ボラティリティ、契約乗数、相殺ポジションにより大きく変わり得ます。

## 4.3 比較対象として有用なスタンドアロン戦略

| ファンド | 特徴 |
|---|---|
| **KMLM** | 11商品、6通貨、5グローバル債券の計22先物。3つのバスケットを相対ヒストリカル・ボラティリティで配分し、各バスケット内は等ドル配分。株価指数先物を含まないため、GEXセクターポートフォリオへの広範株式βの重複が比較的小さい。([KraneShares](https://kraneshares.com/etf/kmlm/)) |
| **WTMF** | 商品、FX、株式、金利市場の上昇・下降トレンドを定量ルールでロング・ショート。現在はBitcoin関連商品・先物に最大10%投資可能。([WisdomTree](https://www.wisdomtree.com/us/products/alternative/wtmf)) |

これらは固定的な100/100スタックではありませんが、既存の「セクター＋IEF」にオルタナティブを追加する比較対象として重要です。

---

# 5. GEXセクター配分＋IEFへの具体的な含意

IEFは残存7～10年の米国債にターゲットしたETFで、2026年7月時点の実効デュレーションは約6.93年です。([BlackRock](https://www.ishares.com/us/products/239456/ishares-710-year-treasury-bond-etf))

## 5.1 NAVウェイトではなくエクスポージャー行列で管理する

各ファンドのルックスルー・ベクトルを、

$$
b_{j,t}
=
\begin{bmatrix}
\beta_{\mathrm{XLK}}\\
\beta_{\mathrm{XLF}}\\
\vdots\\
\beta_{\mathrm{US\ equity}}\\
\beta_{\mathrm{Intl}}\\
KRD_{2y}\\
KRD_{5y}\\
KRD_{10y}\\
KRD_{30y}\\
\beta_{\mathrm{commodity}}\\
\beta_{\mathrm{trend}}\\
\beta_{\mathrm{carry}}\\
\beta_{\mathrm{gold}}\\
\beta_{\mathrm{BTC}}\\
\beta_{\mathrm{funding}}
\end{bmatrix}
$$

とし、ファンドウェイト $w_j$ に対して、

$$
z_t=\sum_j w_{j,t}b_{j,t}
$$

をポートフォリオ全体のエクスポージャーとして管理するのが適切です。

特に債券については、単一のデュレーションではなく、

$$
KRD_t=
(KRD_{2y},KRD_{5y},KRD_{10y},KRD_{30y})
$$

で管理すべきです。

NTSX、RSSB、RSBA等の米国債先物ラダーは30年ゾーンを含みますが、IEFは7～10年中心です。したがって、同じDV01であっても、スティープニング、フラットニング、長期タームプレミアム上昇に対する損益が異なります。

## 5.2 IEFの減額はDV01等価で行う

クロスアセットファンド $j$ を追加するときのIEF調整は、概念的には、

$$
w_{\mathrm{IEF}}^{\mathrm{new}}
=
w_{\mathrm{IEF}}^{\mathrm{old}}
-
\sum_j
w_j
\frac{DV01_j}{DV01_{\mathrm{IEF}}}
$$

です。

ただし実際にはスカラーDV01ではなく、

$$
w_{\mathrm{IEF}}KRD_{\mathrm{IEF}}
+
\sum_j w_jKRD_j
=
KRD^\ast
$$

を満たすように調整します。

RSST、RSBT、RSBY、KMLM等の動的戦略は、債券先物をロングにもショートにもするため、目論見書上の長期目標ではなく**当日の保有先物からDV01を計算する必要があります**。

## 5.3 GEXセクター配分の希薄化

セクター $i$ の直接ポジションを $s_{i,t}$、クロスアセットファンド $j$ の株式エクスポージャーを $e_j$、その広範株式指数のセクター比率を $q_{ij}$ とすると、

$$
E_{i,t}
=
s_{i,t}
+
\sum_j w_{j,t}e_jq_{ij}
$$

が実際のセクターエクスポージャーです。

NTSX、RSST、GDE、RSSX等を追加すると、GEXに基づくセクター・オーバーウェイトが、S&P 500型の時価総額配分によって希薄化します。

したがってこれらは、原則として、

- セクター配分の上に「追加」する商品
- ではなく、広範株式部分を「置換」する商品

として扱う方が整合的です。

---

# 6. NTSXを使う場合の具体例

NTSXの90/60に資本の $2/3$ を配分すると、

$$
\frac{2}{3}\times90\%=60\%
$$

の株式エクスポージャーと、

$$
\frac{2}{3}\times60\%=40\%
$$

の米国債エクスポージャーを得られます。すなわち、理論上は資本の66.7%で60/40を再現し、残り33.3%を現金やオルタナティブに振り向けられます。これはNTSXの基本的なキャピタルエフィシェンシーの考え方です。([WisdomTree](https://www.wisdomtree.com/us/insights/blog/introducing-the-wisdomtree-90-60-us-balanced-fund-ntsx))

しかし、ユーザーの既存ポートフォリオに対しては、

$$
\text{60% GEXセクター}+\text{40% IEF}
\neq
\frac{2}{3}\text{NTSX}
$$

です。

理由は、

- GEXセクター配分と米国大型株時価総額配分が異なる
- IEFと2～30年米国債先物ラダーのKRDが異なる
- NTSXには先物ベーシスと担保運用がある

ためです。

したがってNTSXを使うなら、セクターαとKRDを別途ヘッジまたは補正する必要があります。

---

# 7. GEXと株式・債券相関レジームを分離する

GEXは主として短期の株式市場マイクロストラクチャー・シグナルです。一方、株式・債券相関は、インフレ構成、金融政策、実質金利、タームプレミアム等に左右される、より中期的なマクロレジームです。

したがって、

$$
\Sigma_t
=
\Sigma
\left(
G_t^{\mathrm{GEX}},
M_t^{\mathrm{stock/bond}}
\right)
$$

という二層モデルが適切です。

ここで、ユーザーの符号定義でGEX正をディーラーlong gamma、GEX負をshort gammaと仮定すると、概念的には次のように整理できます。

| 状態 | 含意 |
|---|---|
| GEX正、株式・債券相関負 | IEFやNTSX型債券レッグが機能しやすい。ただし低実現ボラを理由に総グロスを増やしすぎない |
| GEX正、株式・債券相関正 | 株式の短期ボラが低くても、債券ヘッジは弱い。名目債券スタックの追加は避ける |
| GEX負、株式・債券相関負 | IEFのヘッジ価値はあるが、急落初期にはトレンド戦略がまだ株式ロングの可能性がある |
| GEX負、株式・債券相関正 | 最も脆弱。株式ギャップ、債券下落、ボラ上昇、デレバレッジが同時発生し得るため、固定的な株式＋債券レバレッジを抑える |

GEXシグナルをIEFウェイトに直接マッピングするのではなく、

1. GEXでセクターβと株式グロスを決める
2. マクロ相関レジームでKRD・IEF量を決める
3. 残余リスクに対してトレンド、金、キャリー等を割り当てる

という順序が安定的です。

---

# 8. 各商品と既存ポートフォリオの適合性

| 商品群 | GEX＋IEFに対する位置づけ |
|---|---|
| **NTSX / NTSI / NTSE** | 株式＋IEFの一部を置換するコア商品。単純追加すると株式βとDV01を同時に増加させる |
| **RSSB** | グローバル株式＋米国債の置換商品。100/100なので60/40より相対的に債券エクスポージャーが大きい |
| **RPAR / UPAR** | 戦略的なオールウェザー配分。米国債と長期TIPSが大きく、IEFとの重複が大きい。短期GEX戦略との親和性は低め |
| **RSST / RSIT** | 株式を置換しつつトレンドを追加する用途。単純追加では広範株式βがGEXセクター配分を希薄化 |
| **RSBT / RSBY** | IEFの代替または置換候補。IEFの上に追加すると債券リスクが重複。動的戦略がDV01を増減する点に注意 |
| **RSBA** | 米国債＋M&Aリスク。債券重複に加え、M&A失敗時のイベント・株式・クレジット的テールがある |
| **GDE** | 金を追加できるが、同時に米国大型株βも追加される。インフレ・供給ショック用の置換商品として検討 |
| **RSSX** | Bitcoinを含むため、防御的なIEF代替とは考えにくい。金部分だけを見てヘッジ商品と評価しない |
| **KMLM** | セクターGEXを維持したまま追加しやすい候補。ただしグローバル債券先物を持つため、動的DV01は残る |
| **WTMF** | 株式・債券を含む広範トレンド。ルックスルー管理が必要で、現在はBitcoinエクスポージャーもあり得る |

ユーザーの現在の構成に最も重要な区別は、

> **NTSX、RSSB、RSST等は、原則として「追加型の分散資産」ではなく「既存βの置換＋別戦略のスタック」である**

という点です。

純粋な追加分散を求めるなら、広範株式βを伴わないKMLMのようなスタンドアロン戦略の方が、GEXセクターαを毀損しにくい構造です。ただし、その場合でも債券先物のネットDV01は日次で確認すべきです。

---

# 9. 実装可能な最適化定式化

ファンドウェイトを $w$、GEXから得た目標セクターエクスポージャーを $S_t^{GEX}$、目標key-rate durationを $D_t^\ast$ とすると、

$$
\min_w
\quad
w^\top\widehat{\Sigma}_{G_t,M_t}w
+
\lambda_S
\left\|
S(w)-S_t^{GEX}
\right\|^2
+
\lambda_D
\left\|
KRD(w)-D_t^\ast
\right\|^2
+
\lambda_T
\left\|
w-w_{t-1}
\right\|_1
$$

が一つの実務的な形です。

制約には少なくとも、

$$
\text{Gross}(w)\le G_{\max}
$$

$$
\text{Margin cash}(w)\ge C_{\min}
$$

$$
ES_\alpha(w\mid\text{stress regime})\le ES_{\max}
$$

を入れます。

共分散行列は全期間一本ではなく、

$$
\widehat{\Sigma}_{G,M}
$$

として、少なくとも、

- GEX正・負
- 株式債券相関正・負
- コアインフレ型・エネルギーインフレ型
- 平常流動性・証拠金ストレス

に分ける方が有効です。

また、トレンド戦略については、単なる同時点相関ではなく、

- 株式ショック当日～5営業日
- ショック後6～20営業日
- トレンド反転後

でβを分ける必要があります。トレンドは急落に対する即時プットではなく、持続的な価格変化に対する適応型戦略だからです。

---

# 10. 最終的な判断基準

このポートフォリオでは、ファンド選択を全期間相関の低さで行うべきではありません。見るべき順序は次の通りです。

1. **GEXに基づくセクターαが、広範株式スタックでどの程度希薄化されるか**
2. **IEFとファンド内部の米国債先物を合算したkey-rate DV01**
3. **株式・債券同時下落時の条件付きβとExpected Shortfall**
4. **GEX負局面の初期ショックに対するトレンド戦略の反応遅延**
5. **キャリー、M&A、Bitcoin、先物ベーシス等の潜在的な共通テール**

実務的には、既存のGEXセクター配分を維持するなら、

- セクターETFを直接保有
- IEFまたは米国債先物をKRDベースで管理
- トレンド等をスタンドアロンで追加

する構造が最も透明です。

NTSX、RSSB、RPAR/UPAR等を使う場合は、既存の株式とIEFの一部を**置換**し、追加後の総株式β、総DV01、総グロスを再計算するのが基本となります。特に、株式・債券相関が正に転じるレジームでは、名目国債を複数の商品から重ねることが、分散ではなく同一マクロ因子へのレバレッジ増加になり得ます。

---

**Sources:**

- [https://www.wisdomtree.com/us/insights/blog/introducing-the-wisdomtree-90-60-us-balanced-fund-ntsx](https://www.wisdomtree.com/us/insights/blog/introducing-the-wisdomtree-90-60-us-balanced-fund-ntsx)
- [https://www.sec.gov/Archives/edgar/data/1742912/000199937125005019/upar_497k-042525.htm](https://www.sec.gov/Archives/edgar/data/1742912/000199937125005019/upar_497k-042525.htm)
- [https://www.imf.org/en/blogs/articles/2026/02/18/stock-bond-diversification-offers-less-protection-from-market-selloffs](https://www.imf.org/en/blogs/articles/2026/02/18/stock-bond-diversification-offers-less-protection-from-market-selloffs)
- [https://academic.oup.com/rfs/article/39/3/702/8203077](https://academic.oup.com/rfs/article/39/3/702/8203077)
- [https://www.ecb.europa.eu/press/financial-stability-publications/fsr/focus/2020/html/ecb.fsrbox202005_02~f6616db9be.en.html](https://www.ecb.europa.eu/press/financial-stability-publications/fsr/focus/2020/html/ecb.fsrbox202005_02~f6616db9be.en.html)
- [https://www.bis.org/publ/bisbull02.pdf](https://www.bis.org/publ/bisbull02.pdf)
- [https://www.nber.org/papers/w22208](https://www.nber.org/papers/w22208)
- [https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3175538](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3175538)
- [https://www.returnstackedetfs.com/](https://www.returnstackedetfs.com/)
- [https://kraneshares.com/etf/kmlm/](https://kraneshares.com/etf/kmlm/)
- [https://www.ishares.com/us/products/239456/ishares-710-year-treasury-bond-etf](https://www.ishares.com/us/products/239456/ishares-710-year-treasury-bond-etf)



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)