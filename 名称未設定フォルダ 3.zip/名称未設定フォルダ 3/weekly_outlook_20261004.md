# 2026年10月5日から9日のセクターとIEF週間見通し

更新日：2026年10月4日JST。価格・オプションの基準日：10月2日米国引け。先週の評価：9月25日引けから10月2日引け。対象：S&P 500の11セクターETFと米国7–10年国債ETFのIEF。

**提案は株式60.25%、IEF39.75%。** 60/40の大枠を維持し、XLV・XLCの前回Overweightを解消して、XLKを主な相対Overweightとして残す。XLU、XLE、XLBの増額は分散とモデル上の相対配分であり、景気・原油・金利に対する一律の強気判断ではない。10月5日のISMサービス、7日のFOMC議事要旨、8日のPepsiCo、9日の消費者心理とDelta決算の後に条件を再判定する。

保有・約定・承認データは未入力。以下は**DRAFTの研究用目標**であり、取引指示や実口座のリバランス実績ではない。Callを正・Putを負とする建玉由来のGEXは需給プロキシで、実際のディーラーポジションを観測したものではない。[実行台帳](../tables/v2_latest_run_manifest.csv) / [承認入力](../tables/v2_latest_approval_input.csv)

## 先週の市場と前回案の検証

確認された事実として、9月の非農業部門雇用者数は前月比**+2.9万人**、失業率は**4.2%**、平均時給は前月比**+0.1%**。7–8月の雇用増は合計6万人下方修正された。一方、8月の実質PCEは前月比**+0.6%**、コアPCE価格指数は同**+0.2%**で、需要減速と物価沈静化を同一視できない。9月ISM製造業PMIは**54.5**、新規受注**55.3**に対し価格指数は**77.9**へ上昇した。[BLS雇用統計](https://www.bls.gov/news.release/archives/empsit_10022026.htm) / [BEA個人所得・支出](https://www.bea.gov/news/2026/personal-income-and-outlays-august-2026) / [ISM製造業](https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/september/)

市場報道では金利上昇が週前半の株式を圧迫し、10月2日の弱い雇用統計後は株式が反発した。ただし**金曜の反発と週間成績は別**で、S&P 500は週間約−0.3%、Nasdaqは約+0.5%。10年金利も雇用統計直後の低下を維持できなかった。これは価格変動と同時に起きた出来事の整理であり、個々のETF騰落の因果関係を断定しない。[APの週間指数報道](https://www.seattlepi.com/business/how-major-us-stock-indexes-fared-friday-10-2-2026-a22460187) / [10月2日の金利・原油市場報道](https://www.kiplinger.com/investing/stocks/nasdaq-adds-319-points-as-rate-hike-odds-ebb-stock-market-today)

企業面ではMicronが9月30日に好調な四半期とAI関連需要を発表し、Accentureも10月1日に四半期売上の上振れを発表した。他方、Teslaの10月2日公表の第3四半期納車**48万6,532台**は需要の材料だが、同社自身が納車台数だけでは利益・キャッシュフローを判断できないと注意している。XLKの上昇とXLYの慎重姿勢を評価する際には、この違いを残す。[Micron IR](https://investors.micron.com/news/press-release/2026/Micron-Technology-Inc--Reports-Record-Fiscal-Fourth-Quarter-and-Full-Year-2026-Results/default.aspx) / [Accenture IR](https://newsroom.accenture.com/news/2026/accenture-reports-fourth-quarter-and-full-year-fiscal-2026-results) / [Tesla IR](https://ir.tesla.com/press-release/tesla-third-quarter-2026-production-deliveries-and-deployments)

前回9月27日に公表した**v2 DRAFT目標**を9月25日終値から固定した反実仮想では、配当調整済みETF価格による目標収益率は**−0.409%**、同時点の時価総額加重セクター60%＋IEF40%基準は**−0.418%**、超過は**+0.85bp**。計算は各資産の前回ウェイト×実現リターンの合計で、実口座収益率ではない。[前回不変目標](../../data/processed/20260925/v2/SGV2-20260928/20260927T110645664872Z/portfolio_target.csv) / [今回計算した配当調整済みETFリターン](../tables/consistent_12asset_weekly_attribution.csv)

| 主な寄与 | 前回Active寄与 | 読み |
|---|---:|---|
| XLK | +3.34bp | 前回の相対OverweightとETF+1.80%が一致 |
| XLP、XLF、XLBのUnderweight | +4.87bp | 3資産の下落回避が寄与 |
| XLV | −4.73bp | ETF−2.65%でOverweightが逆風 |
| XLC | −3.80bp | ETF−2.34%でOverweightが逆風 |
| IEF | +0.16bp | 小幅Underweight下でETF−0.71% |

前回レポートの旧モデル週次検証とはウェイト体系が異なる。ここでは前回の**v2 cap 60/40目標と同じ基準ウェイト**だけを比較し、過去に実際に約定した成績と混ぜない。

## 金利とBEIから見たIEF

[FRED名目10年](https://fred.stlouisfed.org/series/DGS10)は**10月1日観測の5.24%**、[FRED実質10年](https://fred.stlouisfed.org/series/DFII10)は同日**2.88%**。両者は9月25日比でそれぞれ+7bp、+5bp。対して[10年BEI](https://fred.stlouisfed.org/series/T10YIE)は**10月2日観測の2.36%**、9月25日比+2bp、[5年BEI](https://fred.stlouisfed.org/series/T5YIE)は2.37%、同+3bp。名目・実質とBEIの最新観測日が違うため、異なる日付同士の差を「10月2日の実質金利」として扱わない。BEIにはインフレ期待以外にリスク・流動性プレミアムも入る。

モデル内の10月2日市場10年指標は約**5.28%**、IEFは**89.05**。IEFの正GEXは約**1.30億**、Gamma Flipは**86.44**の上だが、Put Wall **90**の下、Call Wall **91**も7日1σレンジ**88.00–90.10**の外側に近い。OptionScoreは+0.358、価格スコアは−1で、合成はほぼ中立の−0.025。**IEF39.75%は基準40%から−0.25pt、前回39.78%から−0.03ptで、方向としてはごく小幅の減額**である。正GEXだけで債券買いを増やさず、弱い雇用と高止まりする実質金利・BEIを同時に評価した結果と読む。[マクロ観測日](../tables/v2_latest_macro_snapshot.csv) / [オプション指標](../tables/v2_latest_option_signal_snapshot.csv)

マクロ判断として、ISMサービスの価格、FOMC議事要旨、消費者のインフレ期待が弱まり、10年金利が5.20%を持続的に下回りIEFが**90を終値で回復**すれば、IEFを40–41%へ再検討する。逆に10年金利が5.30%超、10年BEIが2.40%超、IEFが**88**を割れるなら38–39%を検討する。これは**次回判断の条件**であり、現行Notebookが自動的にBEIを配分へ上乗せしたという意味ではない。

## 来週の目標配分とリバランス案

比較基準は**SPYのセクター時価総額比率×60%＋IEF40%**。前回比は9月27日DRAFT目標からの差で、実際の売買差ではない。端数丸め前の目標合計は100%、Active合計は0。株式バケットは**60.25%**で、IEFは**39.75%**。保存値の基準比片道回転率は**4.12%**、予測Tracking Errorはcap 60/40比**年率0.67%**（予算3%以内）。前回案から今回案への理論上の片道変更は約**4.24%**で、取引費用は含まない。[目標配分](../tables/v2_latest_portfolio_target.csv) / [リスク](../tables/v2_latest_risk_summary.csv)

| 資産 | 基準 | 前回案 | 新目標 | 基準比 | 前回比 | 先週ETF |
|---|---:|---:|---:|---:|---:|---:|
| XLK | 23.22% | 25.07% | **25.40%** | **+2.18pt** | +0.33pt | +1.80% |
| XLY | 5.59% | 4.48% | 4.75% | −0.84pt | +0.27pt | −0.47% |
| XLP | 2.68% | 1.68% | 1.69% | −0.98pt | +0.01pt | −1.86% |
| XLE | 2.09% | 2.31% | **2.69%** | +0.60pt | +0.38pt | +1.26% |
| XLF | 7.24% | 6.56% | 6.75% | −0.49pt | +0.19pt | −2.46% |
| XLV | 5.57% | 7.35% | **5.32%** | −0.25pt | **−2.04pt** | −2.65% |
| XLI | 4.65% | 3.58% | 4.01% | −0.64pt | +0.43pt | −0.28% |
| XLC | 5.70% | 7.32% | **5.14%** | −0.56pt | **−2.18pt** | −2.34% |
| XLB | 1.01% | 0.29% | 1.20% | +0.19pt | +0.91pt | −1.89% |
| XLRE | 1.08% | 0.90% | 0.96% | −0.12pt | +0.06pt | −1.80% |
| XLU | 1.19% | 0.67% | **2.34%** | **+1.15pt** | **+1.67pt** | +0.81% |
| IEF | 40.00% | 39.78% | **39.75%** | −0.25pt | −0.03pt | −0.71% |

実務上は、まず保有・約定・税コストを確認する。**月曜のISMサービス前にこの表を一括執行しない。** XLV/XLCの旧Overweight解消を優先する一方、XLU/XLB/XLEへの移動は下記の価格・金利条件を満たすか確認して段階的に行う。IEFの−0.03ptは前回案比で小さく、取引コストが上回るなら見送る。実保有が未入力のため具体的な株数と注文は計算しない。

## 各セクターのマクロと企業材料

以下は**モデル値を踏まえた条件付き判断**。ETFの銘柄構成や個社ニュースとETF全体の収益を同一視しない。Flip、Wall、IV範囲は次節の10月2日スナップショットに対応する。

- **XLK 25.40% Overweight：** Micron・Accentureの業績はAI投資の売上化を支える一方、実質10年金利2.88%は高PERの逆風。終値199.81はFlip195.65の上、正GEXだがCall Wall200直下で、OptionScore自体は−0.046。200の持続的突破か195.65の維持を確認し、急騰追随は限定する。[Micron IR](https://investors.micron.com/news/press-release/2026/Micron-Technology-Inc--Reports-Record-Fiscal-Fourth-Quarter-and-Full-Year-2026-Results/default.aspx) / [Accenture IR](https://newsroom.accenture.com/news/2026/accenture-reports-fourth-quarter-and-full-year-fiscal-2026-results)
- **XLY 4.75% Underweight：** Tesla納車は堅調でも利益率は未確認。雇用増鈍化・借入金利・エネルギー価格は自動車と一般消費の負担。終値110.04はFlip131.10より大幅に下、Put Wall107.5を警戒。納車だけでUWを解消しない。[Tesla IR](https://ir.tesla.com/press-release/tesla-third-quarter-2026-production-deliveries-and-deployments)
- **XLP 1.69% Underweight：** 8日のPepsiCoでは数量、値上げ、原価、北米事業の採算を分けて見る。物価高局面の防御性は評価するが、終値80.53はFlip94.74を下回り負GEX。85のCall Wallを回復しない限り、良い個社決算をセクター全体の買い材料へ直結させない。[PepsiCo公式日程](https://www.pepsico.com/en/newsroom/press-releases/2026/pepsico-announces-timing-and-availability-of-third-quarter-2026-financial-results)
- **XLE 2.69% 小幅Overweight：** 原油約91ドルとHormuzの輸送不確実性は実現価格の支えになりうるが、同時にインフレと金利経由で他資産を圧迫する。終値62.82はFlip64.41の下、負GEXで、65回復まで追加増額を急がない。60近辺を割れば地政学ヘッジ枠も再評価する。[10月2日の原油市場報道](https://www.kiplinger.com/investing/stocks/nasdaq-adds-319-points-as-rate-hike-odds-ebb-stock-market-today)
- **XLF 6.75% Underweight：** 金利上昇は貸出利回りだけでなく調達費、債券評価、借り手の信用コストも動かす。雇用鈍化とFREDのHYスプレッド拡大を慎重に評価。終値53.49はPut Wall54、Flip57.20の下で、55回復だけではOWへ戻さない。[FRED HYスプレッド](https://fred.stlouisfed.org/series/BAMLH0A0HYM2)
- **XLV 5.32% 小幅Underweight：** 医療需要の耐久性は分散に有効でも、先週ETF−2.65%で旧OWが負担。終値166.18はFlip168.91を割り、GEXも負へ転じた。168.91回復までは旧7.35%へ機械的に戻さず、薬価・償還など個別リスクを確認する。
- **XLI 4.01% Underweight：** 製造業新規受注55.3は需要を示す一方、価格77.9は投入費圧力。9日のDelta決算は旅客需要と燃料費の補助材料。終値169.95はPut Wall170付近、Flip181.87の下で、受注の強さだけを追わない。[ISM製造業](https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/september/) / [Delta IR日程](https://ir.delta.com/news/news-details/2026/Delta-Air-Lines-Announces-Webcast-of-September-Quarter-2026-Financial-Results/default.aspx)
- **XLC 5.14% Underweight：** 広告とプラットフォーム収益は実質消費に支えられる可能性があるが、AI投資費用と評価倍率の金利感応度がある。先週ETF−2.34%、終値110.32はFlip114.02の下で負GEX。115回復まで旧Overweightを復元しない。
- **XLB 1.20% 小幅Overweight：** 相対配分の再配分で前回案から増えたが、景気の絶対強気ではない。6日の貿易統計とRPM決算で工業材料・建材の需要と原価を確認する。終値48.86はPut Wall50とFlip49.24の下、負GEXで、50回復を執行条件にする。[BEA貿易日程](https://www.bea.gov/news/schedule/full) / [RPM公式ニュース](https://www.rpminc.com/news/)
- **XLRE 0.96% Underweight：** 高い実質金利が不動産の資本コストと還元利回りに逆風。終値40.81はPut Wall42とFlip42.08の下。金利低下に加え42回復がそろうまで増額を抑える。
- **XLU 2.34% Overweight：** 電力需要の構造的増加を評価しつつ、設備投資の資金調達費には注意。先週ETF+0.81%、正GEX、終値39.83はFlip38.25の上で、Call/Put Wall40に接近する。価格の短期トレンドはなお弱く、40を終値で回復し、実質金利が再上昇しないことを前回案からの大幅増額の条件にする。

## 10月5日から9日のイベントと判断順序

以下は米東部時間の予定。イベント後に企業IR・公式統計で時刻と発表値を再確認する。9日のミシガン大学速報は公式日程に従う。[ISM公表日](https://www.ismworld.org/supply-management-news-and-reports/reports/rob-report-calendar/) / [Fed日程](https://www.federalreserve.gov/monetarypolicy.htm) / [ミシガン大学2026年日程](https://data.sca.isr.umich.edu/fetchdoc.php?docid=79628) / [決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)

| 日付 | 確認する予定 | 配分への接続 |
|---|---|---|
| 10/5 月 | 10:00 ISMサービス、サービスPMI確報 | 受注と支払価格が両方強ければIEF増額を抑制。価格鈍化ならIEF90回復、XLRE/XLUの金利感応を確認 |
| 10/6 火 | 8:30 8月貿易収支、RPM決算、引け後Constellation Brands決算 | XLI/XLBの外需・投入費、XLPの数量/値上げ。企業決算は公式発表後に再評価 |
| 10/7 水 | 14:00 9月FOMC議事要旨、Constellation Brands説明会、Applied Digital決算予定 | 9月の利上げ判断と今後の物価/雇用バランスを再評価。XLK/XLUのAI設備投資・電力需要は個社とセクターを区別 |
| 10/8 木 | 8:30 新規失業保険申請、PepsiCo決算 | IEF・XLF・XLYには雇用継続性、XLPには数量と採算。IEF90とXLU40の終値を確認 |
| 10/9 金 | 10:00 ミシガン大学10月消費者心理速報、Delta決算 | インフレ期待の上振れはBEI/IEFに逆風。XLYの消費、XLI/XLEの燃料費と旅客需要を確認 |

Constellation Brandsの10月6日引け後発表とDeltaの10月9日説明会は[両社の公式日程](https://ir.cbrands.com/news-events/press-releases/detail/345/constellation-brands-to-report-second-quarter-fiscal-2027-financial-results-on-october-6-2026-after-market-close-and-host-conference-call-on-october-7-2026-at-8-00-am-et)・[Delta IR](https://ir.delta.com/news/news-details/2026/Delta-Air-Lines-Announces-Webcast-of-September-Quarter-2026-Financial-Results/default.aspx)で確認。その他の決算予定は公表前に再確認する。

## オプション監視水準とシナリオ

価格は10月2日終値。7日1σはIVから計算した**モデル上の変動幅**で、予想価格や損失上限ではない。Wallは公開建玉の集中値で、売買方向を断定しない。[全指標](../tables/consistent_option_metrics.csv)

| 資産 | 終値 | Gamma Flip | Call / Put Wall | 7日1σ |
|---|---:|---:|---:|---:|
| XLK | 199.81 | 195.65 | 200 / 180 | 191.13–208.49 |
| XLY | 110.04 | 131.10 | 115 / 107.5 | 105.77–114.31 |
| XLP | 80.53 | 94.74 | 85 / 78 | 76.85–84.21 |
| XLE | 62.82 | 64.41 | 65 / 60 | 60.40–65.24 |
| XLF | 53.49 | 57.20 | 55 / 54 | 51.80–55.18 |
| XLV | 166.18 | 168.91 | 175 / 160 | 159.79–172.57 |
| XLI | 169.95 | 181.87 | 180 / 170 | 164.20–175.70 |
| XLC | 110.32 | 114.02 | 115 / 110 | 106.54–114.10 |
| XLB | 48.86 | 49.24 | 60 / 50 | 46.72–51.00 |
| XLRE | 40.81 | 42.08 | 45 / 42 | 39.32–42.30 |
| XLU | 39.83 | 38.25 | 40 / 40 | 38.70–40.96 |
| IEF | 89.05 | 86.44 | 91 / 90 | 88.00–90.10 |

IEFのVanna/Charm絶対集中比は**57.6%/81.3%**、XLPは**54.4%/51.9%**、XLUは**25.1%/52.5%**。IV低下や時間経過でヘッジ感応度が変わりやすいが、集中比だけから買いフロー・売りフローの方向は決められない。特にIEFは90のPut Wall下で、金利イベント後のIVと価格の両方を確認する。[Vanna/Charm計算](../tables/consistent_option_metrics.csv)

- **基本：** サービス景況感と価格圧力が混在し、10年金利は高止まり。株式約60%、IEF約40%。XLKの相対優位を残し、XLU/XLB/XLEの増額は条件付き。
- **ディスインフレと安定成長：** ISM価格と消費者のインフレ期待が鈍化、10年金利が5.20%未満、IEFが90回復。IEF40–41%へ、XLRE・XLUは金利低下と価格回復を確認してから再評価。
- **再インフレ・高金利：** サービス価格上振れ、10年BEI2.40%超、10年金利5.30%超。IEFは38–39%への小幅減額を検討し、XLK200直下やXLRE/XLUの金利感応度に注意。株式と債券の同時下落を想定する。
- **成長失速：** 雇用・消費が悪化し、信用スプレッドがさらに拡大。IEFが90回復すれば債券の防御効果を評価する一方、XLF/XLY/XLIの景気リスクを減らす。単に弱い雇用だけで株式を買い増さない。

## データと検証

Notebookを隠れた状態なしで上から実行し、[実行済みNotebook](../executed/main_20261004_executed.ipynb)、[12資産ダッシュボード](../dashboard/sector_gamma_dashboard_v2.html)、raw/processed、CSV/parquetを更新した。12資産すべてのチェーンの最終売買日は10月2日で、品質はすべてOK。検証はLegacy **205件PASS**、v2 **610件PASS**、例外・BLOCK・WARNは0。Notebook・ダッシュボード・上書き対象CSVの更新前コピーは[バックアップ](../backups/20261004_weekly_update/)に保存した。

本稿の前週ペーパー検証は、前回v2不変目標と今回の配当調整済み終値を明示的に結合した計算。`consistent_12asset_weekly_attribution.csv`自体の`tactical_portfolio_weight`は**旧12資産モデル**であり、前述のv2収益率へ流用していない。配分は研究用DRAFTなので、実保有を入力・承認するまでは売買数量や実口座P&Lを表示しない。
