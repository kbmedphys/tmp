# 債券動向とマクロイベント

**User:** Anonymous  
**Created:** 5/17/2026 15:08:25  
**Updated:** 7/12/2026 23:49:23  
**Exported:** 7/12/2026 23:51:26  
**Link:** [https://chatgpt.com/c/6a095b58-b258-8324-8889-cfb83a214404](https://chatgpt.com/c/6a095b58-b258-8324-8889-cfb83a214404)  

## Response:
2026/5/17 15:08:26

対象期間は日本時間で2026年5月11日〜15日とし、米国債・独Bund・英Gilt・日本国債を中心に利回り変化を確認します。CPI、中銀発言、入札、地政学・財政材料との対応も整理します。

ここまでの大枠では主要国で債券安・利回り上昇が同時進行し、インフレ再加速懸念が中心材料です。米物価指標や原油高に加え、英国政治不安、日銀利上げ観測も重なっています。

> **最新債券動向とマクロイベントの関連分析**
>
> ユーザーが「主要債券の先週1週間の動向と、マクロイベントを対応付けて解説してください」と尋ねています。もう少し現在の日付（2026年5月17日）を考慮し、5月11〜15日の債券の動きと関連するマクロイベントを調べる必要があります。主要な政府債券（米国、ドイツ、英国、日本など）の利回りに注目し、Webで最新情報を検索して適切なデータを引き出そうと思います。
>
> **Searching bond yields and macro events May 2026**
>
> [Record high Japanese yields trigger bets on repatriation](https://www.ft.com/content/6e363bc3-3114-4ddf-9f3b-67f031b3ef92)
> [UK 10-year bonds head for sharpest daily slump since April 2025](https://www.reuters.com/world/uk/uk-10-year-yields-hit-highest-since-2008-political-worries-global-inflation-2026-05-15/)
> [Weekly Economic Calendar | 11–15 May 2026 A new ...](https://www.facebook.com/XScomPH/posts/weekly-economic-calendar-1115-may-2026-a-new-trading-week-means-new-opportunitie/817888474725435/)
> [Week Ahead: Markets Brace for CPI, PPI and Retail Sales ...](https://www.investing.com/analysis/week-ahead-markets-brace-for-cpi-ppi-and-retail-sales-reports-200680028)
> [Weekly Currency Forecast: 11–15 May 2026 | US CPI & UK ...](https://cambridgecurrencies.com/weekly-currency-forecast-11-may-2026/)
> [Stocks Slide as Inflation Fears Lift Bond Yields](https://finance.yahoo.com/markets/stocks/articles/stocks-slide-inflation-fears-lift-151442159.html)
> [Week Ahead - May 11th](https://jp.tradingeconomics.com/calendar?article=29352&g=top&importance=2&startdate=2026-05-08)
> [Treasury Yields Rise Sharply as Hormuz Hopes Fade Away](https://www.wsj.com/finance/jgb-yields-rise-across-curve-japan-data-in-focus-next-week-1266799a)
> [Macrobond Charts | Week of May 11, 2026](https://www.macrobond.com/resources/macro-charts/week-of-may-11-2026)
> [Stocks end roller-coaster week on a negative note amid ...](https://ng.investing.com/news/stock-market-news/us-stock-futures-steady-after-nvidia-boosts-wall-st-trumpxi-summit-in-focus-2511856)
> [Market Quick Take - 13 May 2026](https://www.home.saxo/content/articles/macro/market-quick-take---13-may-2026-13052026)
>
> **最新債券利回りデータの検索と確認**
>
> 2026年のデータが驚くべき結果を示しています。イラン戦争、石油、市場、トランプ、Warsh など、重要な情報に関して信頼できる情報を引用する必要があり、週ごとの動向も調べなければなりません。5月15日2026年の債券利回りに関する最新データを確認するため、さらに深く検索して情報を集めます。
>
> **現在の債券利回りと最新動向検索**
>
> [Global bonds battered as flaring inflation spooks investors | Reuters](https://www.reuters.com/business/global-bonds-tumble-flaring-inflation-spooks-investors-2026-05-15/)
> [
	Week Ahead - May 11th
](https://jp.tradingeconomics.com/calendar?article=29352&g=top&importance=2&startdate=2026-05-08)
>
> **債券利回りの週次変化の精緻なデータを探す**
>
> 今のところいくつかの情報はありますが、もう少し正確な米国、英国、日本の債券の週ごとの利回り変化に関するデータが必要です。きちんとした分析のため、さらに詳細な情報を探す必要があります。
>
> **米国、英国、JGBの利回り変動調査**
>
> [Fed chair must keep his cool as inflation's feeling hot, hot, hot](https://www.thetimes.com/business/economics/article/fed-chair-must-keep-his-cool-as-inflations-feeling-hot-hot-hot-kcgz60qnm)
> [April's inflation spike leaves Warsh and the Fed zero excuses not to raise rates](https://www.marketwatch.com/story/warsh-faces-rate-pressure-as-aprils-inflation-spike-leaves-the-fed-with-zero-excuses-9610ddb6)
> [April CPI rises more than expected; bond yields climb](https://www.reuters.com/business/view-april-cpi-rises-more-than-expected-bond-yields-climb-2026-05-12/)
> [US inflation jumped to 3.8% in April as war with Iran continues to drive up prices](https://www.theguardian.com/business/2026/may/12/us-inflation-april-iran-war)
> [US consumer inflation posts largest gain in three years](https://www.facebook.com/Reuters/posts/us-consumer-inflation-increased-further-in-april-with-the-annual-rate-posting-it/1545175817473145/)
> [US producer prices surprise with largest increase in four years](https://www.fultonsun.com/news/2026/may/14/us-producer-prices-surprise-with-largest-increase/)
> [US producer prices post biggest gain in four years](https://jp.reuters.com/video/watch/idRW029313052026RP1/)
> [US annual consumer inflation posts largest gain in three ...](https://www.tradingview.com/news/reuters.com%2C2026%3Anewsml_L1N41O125%3A0-us-annual-consumer-inflation-posts-largest-gain-in-three-years-as-prices-increase-broadly/)
> [United States Inflation Rate](https://tradingeconomics.com/united-states/inflation-cpi)
>
> **米国債10年利回りの最新データ確認**
>
> ユーザーのリクエストに応えるため、特に米国10年債の利回りに関して、5月15日2026年週末時点の変更と実際の利回りを調べる必要があります。政治関連の詳細は控えめにし、公式な米国財務省のデータを確認して正確な利回りを探し、情報を取り入れます。
>
> **Searching U.S. Treasury yields and market changes**
>
> [Record high Japanese yields trigger bets on repatriation](https://www.ft.com/content/6e363bc3-3114-4ddf-9f3b-67f031b3ef92)
> [3 reasons bond yields could keep surging](https://www.businessinsider.com/why-are-bond-yields-rising-interest-rates-treasury-bonds-inflation-2026-5)
> [U.S. 30-year Treasury yield tops 5.1% in a bond rout that's gone global](https://www.marketwatch.com/livecoverage/stock-market-today-dow-s-p-500-and-nasdaq-set-to-pull-back-as-treasury-yields-climb/card/u-s-30-year-treasury-yield-tops-5-1-in-a-bond-rout-that-s-gone-global-1m80ZjZHwpf9DvCmYVWL)
> [U.S. 10-Year Treasuries Seen as 'Buy' at 4.50% Yield Level](https://www.barrons.com/livecoverage/stock-market-news-today-051526/card/u-s-10-year-treasuries-seen-as-buy-at-4-50-yield-level-XrHWroFgmEU38dgD0O2c)
> [Daily Treasury Rates | U.S. Department of the ...](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_bill_rates)
> [Treasury Yields Snapshot: May 15, 2026 - dshort](https://www.advisorperspectives.com/dshort/updates/2026/05/15/treasury-yields-snapshot-may-15-2026)
> [10 Year Treasury Rate - Real-Time & Historical Yield Trends](https://ycharts.com/indicators/10_year_treasury_rate)
> [United States Treasury Note 0% May 15, 2026 (912833LZ1=)](https://www.investing.com/rates-bonds/usgovt-0-15-may-2026)
> [U.S. Treasury Yield Curve](https://streetstats.finance/rates/treasuries)
> [Market Yield on U.S. Treasury Securities at 10-Year Constant ...](https://fred.stlouisfed.org/series/DGS10)
> [10 Year Treasury Yield (1962-2026)](https://www.macrotrends.net/2016/10-year-treasury-bond-rate-yield-chart)
> [H.15 - Selected Interest Rates (Daily) - May 15, 2026](https://www.federalreserve.gov/releases/h15/)
> [US 10 Year Treasury Note Yield - Quote - Chart](https://tradingeconomics.com/united-states/government-bond-yield)
> [Treasury yields are starting to challenge the AI-led rally's ...](https://www.facebook.com/Briefingcom/posts/treasury-yields-are-starting-to-challenge-the-ai-led-rallys-valuation-story-high/1657024653096539/)
> [Interest Rate Scenario Analysis | F/m Investments](https://www.fminvest.com/current-us-treasury-rates)
> [US 10 Year Treasury Note TMUBMUSD10Y (Tullett Prebon)](https://www.wsj.com/market-data/quotes/bond/BX/TMUBMUSD10Y/historical-prices)
> [Dollar climbs for fifth straight day as Treasury yields surge](https://www.aol.com/articles/dollar-poised-largest-weekly-rise-005604000.html)
>
> **主要債券の利回りデータ検索**
>
> 主要な債券利回りについて、正確な数字を知る必要があります。例えば、TradingEconomicsのページに各国の債券情報が載っているかもしれません。現在の利回りや日々・月々の変動を確認し、必要なデータを探してみます。
>
> **主要債券の利回りデータを検索中**
>
> [Record high Japanese yields trigger bets on repatriation](https://www.ft.com/content/6e363bc3-3114-4ddf-9f3b-67f031b3ef92)
> [UK 10-year bonds head for sharpest daily slump since April 2025](https://www.reuters.com/world/uk/uk-10-year-yields-hit-highest-since-2008-political-worries-global-inflation-2026-05-15/)
> [UK borrowing costs hit new highs as City traders brace for Burnham, and pound heads for worst week since 2024 - as it happened](https://www.theguardian.com/business/live/2026/may/15/rich-list-sunday-times-billionaires-reform-donor-christopher-harborne-hinduja-radcliffe-dyson-beckham-live-updates)
> [Germany 10-Year Bond Yield - Quote - Chart - Historical Data](https://tradingeconomics.com/germany/government-bond-yield)
> [Italy](https://en.wikipedia.org/wiki/Italy)
> [German 10-Year Bund Yield Hits 3.136%, Highest Since ...](https://www.roic.ai/news/german-10-year-bund-yield-hits-3136-highest-since-2011-05-15-2026)
> [Japan 10-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/japan-10-year-bond-yield-historical-data)
> [Discover Italy: Official Tourism Website - Italia.it](https://www.italia.it/en)
> [UK Gilt Yields Set For Biggest Weekly Jump in Two Months](https://www.tradingview.com/news/te_news%3A551056%3A0-uk-gilt-yields-set-for-biggest-weekly-jump-in-two-months/)
> [JGB yield | HISTORICAL DATA | JAPAN BOND TRADING Co ...](https://www.bb.jbts.co.jp/en/historical/marketdata01.html)
> [Italy | Facts, Geography, History, Flag, Maps, & Population](https://www.britannica.com/place/Italy)
> [German 10-year bond yields rise as much as 8.5 bps to 3.133 ...](https://www.marketscreener.com/news/german-10-year-bond-yields-rise-as-much-as-8-5-bps-to-3-133-highest-since-may-2011-ce7f5bd2de80f024)
> [️ With Keir Starmer under pressure, Labour party rival and ...](https://www.instagram.com/p/DYZvlw1jOq4/)
> [Interest Rate : Ministry of Finance](https://www.mof.go.jp/english/policy/jgbs/reference/interest_rate/index.htm)
> [Italy – EU country | European Union](https://european-union.europa.eu/principles-countries-history/eu-countries/italy_en)
> [UK 10-Year Gilt Yield Hits 5.18%, Highest in 18 Years](https://finance.biggo.com/news/23RkL54BDXrLZJaAFC8X)
> [Interest Rates: Long-Term Government Bond Yields: 10-Year ...](https://fred.stlouisfed.org/series/IRLTLT01JPM156N)
> [Italy | National Geographic Kids](https://kids.nationalgeographic.com/geography/countries/article/italy)
>
> **利回りの履歴データ確認**
>
> 債券利回りについて、日々の歴史的なデータを確認する必要があります。検索結果のスニペットだけでは不十分かもしれませんので、TradingEconomicsやReutersなど、信頼できるサイトを開いて具体的なデータとその出典を確認し、適切に引用する必要があります。
>
> **投資利回りの履歴データ検索**
>
> [
	Germany 10-Year Bond Yield - Quote - Chart - Historical Data - News
](https://tradingeconomics.com/germany/government-bond-yield)
> [United Kingdom 10-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/uk-10-year-bond-yield-historical-data)
> [Japan's wholesale inflation spikes on energy shock, bolsters case for June rate hike | Reuters](https://www.reuters.com/world/asia-pacific/japan-april-wholesale-inflation-rate-spikes-rising-import-costs-2026-05-15/)
>
> **米国の債券データ確認**
>
> 米国の正確な利回りデータが必要です。公式な情報源を確認するために、米国財務省やFRED（連邦準備制度）を開き、H15テーブルやFREDデータを調べる必要があります。これらの信頼性の高いデータソースを参照することが重要です。
>
> **USオープン財務データ検索**
>
> [Federal Reserve Board - H.15 - Selected Interest Rates (Daily) - May 15, 2026](https://www.federalreserve.gov/releases/h15/)
> [Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity, Quoted on an Investment Basis (DGS10) | FRED | St. Louis Fed](https://fred.stlouisfed.org/series/DGS10)
> [
	US 10 Year Treasury Note Yield - Quote - Chart - Historical Data - News
](https://tradingeconomics.com/united-states/government-bond-yield)
>
> **金曜日の工業生産データ確認**
>
> 金曜日の工業生産に関するデータが必要です。これを調べるために、信頼できるデータソースを使って詳細を確認し、最新の情報を得る必要があります。検索して、利用可能な情報を参照しましょう。
>
> **産業生産に関する最新ニュース検索**
>
> [Memorial Day sales mark down fridges and dishwashers. Too bad many Americans aren't buying them right now.](https://www.marketwatch.com/story/cant-afford-to-buy-a-new-fridge-or-dishwasher-over-memorial-day-a-better-holiday-sale-is-coming-up-2355cded)
> [Motor vehicles, AI boost US manufacturing production; supply shortages from war loom](https://www.reuters.com/business/autos-transportation/us-manufacturing-output-accelerates-auto-production-april-2026-05-15/)
> [Retail Sales Chugged Along In April Despite Fuel Crunch](https://www.investopedia.com/retail-sales-rose-in-april-11974597)
> [Retail sales growth slowed in April from March as higher gas cost leaves less room for nonessentials](https://apnews.com/article/f77b8986d274c40b913c26ba39492ead)
> [U.S. Industrial Production Rose in April](https://www.wsj.com/economy/u-s-industrial-production-rose-in-april-c8fecdf8)
> [US Manufacturing Output Rises Most in 14 Months](https://tradingeconomics.com/united-states/manufacturing-production-mom/news/551212)
> [US industrial production rises by most in over a year](https://sg.finance.yahoo.com/news/us-industrial-production-rises-most-061148357.html)
> [US April industrial output data](https://www.tradingview.com/news/reuters.com%2C2026-05-15%3Anewsml_L1N41S0MP%3A0-us-april-industrial-output-data/)
> [April US retail sales rise as expected; default risk climbs](https://www.spglobal.com/market-intelligence/en/news-insights/articles/2026/5/april-us-retail-sales-rise-as-expected-default-risk-climbs-101733084)
> [Motor vehicles, AI boost US manufacturing production](https://www.investing.com/news/economic-indicators/us-manufacturing-output-accelerates-on-auto-production-in-april-4692673)
> [U.S. Industrial Production Jumped in April](https://www.haver.com/articles/u-s-industrial-production-jumped-in-april)
> [Retail Sales: Consumer Spending Rises for Third Straight Month](https://www.advisorperspectives.com/dshort/updates/2026/05/14/april-2026-retail-sales-consumer-spending-growth?topic=risk-management)
> [US Industrial Production Rises by Most in Over a Year](https://www.bloomberg.com/news/articles/2026-05-15/us-industrial-production-rises-by-most-in-over-a-year)
> [Inflation Is Roiling Bond Markets as Yields Rise | The Opening ...](https://www.youtube.com/watch?v=jCfMfVplbxU)
> [US manufacturing output rises marginally in February](https://www.aol.com/articles/us-manufacturing-output-rises-marginally-132955818.html)
> [US Industrial Production Rises by Most in Over a Year (1)](https://news.bloomberglaw.com/business-and-practice/us-industrial-production-rises-by-most-in-over-a-year-1)
>
> **データ収集と週次変動の確認**
>
> ユーザーからのリクエストに応じて、UK GDPや欧州のマクロ経済データを収集する必要があります。ただし、詳細すぎずに十分な情報を提供したいです。テーブルには、10年債の利回りと週ごとの変動を含めます。5月8日から5月15日までの米国の利回り変動を確認して、MarketWatchのデータで22bps増加していることがわかりましたが、それは推定値として使用します。
>
> **日本債の変動データ収集**
>
> テイスト的に日次変動＋月次の利回り変化が重要です。リュウターズによると、ドイツ国債は今週11bps上昇、イタリア国債は16bps上昇しています。日本円については、TEから日本国債の月間データは出ていましたが、週次詳細が必要。インベスティングの歴史的データを調べる必要があります。
>
> **日本の歴史的金利データの検索**
>
> [Japan 10-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/japan-10-year-bond-yield-historical-data)
>
> **歴史的データの収集**
>
> 日本とイギリスについては、Investingの歴史的データを使用すれば良さそうです。ドイツのデータが必要かもしれませんが、その場合もInvestingを参考にしたいので、まずドイツのページを開いて調査してみます。
>
> **投資履歴データの検索（日本、UK、ドイツ）**
>
> [Germany 10-Year Bond Yield - Investing.com](https://www.investing.com/rates-bonds/germany-10-year-bond-yield)
>
> **Investingの履歴データを確認**
>
> Investingのサイトで直接履歴データを確認する必要があります。おそらく、287番のページをクリックすることで見られる情報があるかもしれません。ちょっと試してみます。
>
> **Investing Directの履歴情報の確認**
>
> [Germany 10-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data)
>
> **USのInvesting履歴データを確認**
>
> 今度は、USのInvestingサイトで履歴データを開いてみる必要がありそうです。これで必要な情報を見つけられるかもしれません。ちょっと確認してみます。
>
> **Investingの履歴データ検索**
>
> [United States 10-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/u.s.-10-year-bond-yield-historical-data)
>
> **US 30年債の履歴データ確認**
>
> USの30年債の履歴データが必要かもしれません。Investingを使って確認できるかもしれないので、そのデータがあれば参考にしたいですね。少し見てみます。
>
> **US 30年債券の歴史データ検索**
>
> [United States 30-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/u.s.-30-year-bond-yield-historical-data)
>
> **必要なデータラインの確認**
>
> UK、Japan、Germanyの30年債データは、メディアによって表示されていないかもしれません。関連するラインを確認する必要がありそうです。おそらく387行目を開ければ良いかも。これで必要な情報を見つけられるかもしれません。
>
> **確認出力の行387について**
>
> [United Kingdom 30-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/uk-30-year-bond-yield-historical-data)
>
> **イタリアのデータ確認**
>
> イタリアのデータが本当に必要かどうかは微妙ですが、主要な債券には周辺国のデータも含めたいかも。もし必要なら、イタリアの利回りの歴史的データを検索して開いてみるのが良さそうですね。
>
> **イタリア国債の利回り履歴調査**
>
> [Italy 10-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/italy-10-year-bond-yield-historical-data)
>
> **債券データの調整**
>
> イタリアのデータは良い結果を得ましたが、JSON形式ではないですね。それに加えて、フランスやスペインを考慮するべきかもしれません。表には、米国、ドイツ、イギリス、日本、イタリアの債券利回りが含まれていれば十分だと思います。もしユーザーが「主要債券」を求めているなら、世界の主要国債利回りを含めるべきですね。
>
> **週別の金利変動と重要なイベント**
>
> 今週の金利変動は以下：
> 
> - 米国10年債: +23.1bp
> - 米国30年債: +18.1bp
> - ドイツ10年債: +14.88bp（Reutersと差）
> - ドイツ30年債: +12.2bp
> - 英国10年債: +25.9bp
> - 英国30年債: +27.5bp
> - 日本10年債: +22.8bp
> - 日本30年債: +29.2bp
> - イタリア10年債: +22.7bp
> 
> データ参照が必要です。また、主要なマクロイベントも合わせて記載し、「週間前の姉妹イベント集中」といった形で記録できます。
>
> **Analyzing global bond yields and macroeconomic events**
>
> [US annual consumer inflation posts largest gain in three years as prices increase broadly | Reuters](https://www.reuters.com/business/us-consumer-prices-increase-further-april-2026-05-12/)
>
> **イギリスの政治不安と10Y/30Y利回りの検索**
>
> [UK government to scrap planned rise in fuel tax, Sun reports](https://www.reuters.com/business/energy/uk-government-scrap-planned-rise-fuel-tax-sun-reports-2026-05-16/)
> [The ungovernable country? Why Britain keeps losing prime ministers](https://www.theguardian.com/politics/2026/may/17/the-ungovernable-country-why-britain-keeps-losing-prime-ministers)
> [Political turmoil pushes UK gilt yields to multi-decade highs](https://english.news.cn/europe/20260512/84f4be7f077c49ceb0faa08e243ff50b/c.html)
> [Borrowing costs rise as Starmer's reset fails to quell rebels](https://www.telegraph.co.uk/business/2026/05/11/starmer-uk-bonds-borrowing-costs-ftse-100-markets/)
> [Long-term British borrowing costs surged to their highest in ...](https://www.facebook.com/Reuters/videos/uk-long-term-bond-yields-rise-as-starmers-future-in-doubt/1417547670387224/)
> [UK Gilt Yield Dips Despite Political Risks](https://tradingeconomics.com/united-kingdom/government-bond-yield/news/550693)
> [UK borrowing costs hit 28-year high on UK PM leadership ...](https://global.morningstar.com/en-gb/news/alliance-news/1778573759641228000/uk-borrowing-costs-hit-28-year-high-on-uk-pm-leadership-uncertainty)
> [GDP international comparisons: Economic indicators](https://commonslibrary.parliament.uk/research-briefings/sn02784/)
> [UK borrowing costs surge as Starmer leadership crisis ...](https://www.ft.com/content/4bd1dadd-3a1c-4adf-b255-0b03f7e8c36d?syn-25a6b1a6=1)
> [UK borrowing costs near a 30-year high as Keir Starmer ...](https://www.independent.ie/business/world/uk-borrowing-costs-near-a-30-year-high-as-keir-starmer-teeters/a251848722.html)
> [UK GDP Is Expected to Grow 1.4% This Year Despite ...](https://www.goldmansachs.com/insights/articles/uk-gdp-is-expected-to-grow-1-point-4-percent-this-year-despite-weaker-employment)
>
> **Reuters UKの政治記事を検索中**
>
> [UK economy posts strong Q1, but Iran war casts shadow over outlook | Reuters](https://www.reuters.com/world/uk/uk-economy-shows-unexpected-growth-03-march-2026-05-14/)
>
> **Euro圏およびECBに関連するマクロイベント**
>
> Euro圏の工業生産やドイツZEW指数など、重要なマクロ経済イベントを探す必要があります。特に、グローバルなインフレや原油価格、財政に対する厳しい目線がEuro圏に大きな影響を与える要因です。適切なデータを参照し、正確な情報を基に議論を進めます。
>
> **検索中：ユーロ圏経済指標とマクロイベント**
>
> [Record high Japanese yields trigger bets on repatriation](https://www.ft.com/content/6e363bc3-3114-4ddf-9f3b-67f031b3ef92)
> [German investor morale improves unexpectedly in May, but 'no fresh start' in sight](https://www.reuters.com/business/retail-consumer/german-investor-morale-rises-unexpectedly-may-zew-finds-2026-05-12/)
> [German Investor Sentiment Climbs on Tentative Hopes of End to Iran War](https://www.wsj.com/economy/german-investor-sentiment-climbs-on-hopes-of-end-to-iran-war-22cf5407)
> [German investor morale rises unexpectedly in May, ZEW ...](https://www.aol.com/articles/german-investor-morale-rises-unexpectedly-090610000.html)
> [German investor morale rises unexpectedly in May, ZEW ...](https://uk.finance.yahoo.com/news/german-investor-morale-rises-unexpectedly-090910164.html)
> [Industrial production up by 0.2% in the euro area and by 0.8 ...](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/4-13052026-bp)
> [Bund Yields Surge on Inflation Fears](https://tradingeconomics.com/germany/government-bond-yield/news/545489)
> [Markets tread carefully as oil holds firm](https://www.lgt.com/global-en/market-assessments/market-view/markets-tread-carefully-as-oil-holds-firm-346646)
> [Euro zone bond yields high on energy disruption fears](https://www.rte.ie/news/business/2026/0327/1565492-eurozone-bonds/)
> [German bond yields ease but stay near peak on inflation ...](https://www.investing.com/news/stock-market-news/german-bond-yields-ease-but-stay-near-peak-on-inflation-concerns-93CH-4689488)
>
> **ECBの主要な調査結果を確認する必要あり**
>
> ECBに関連する重要な調査結果を確認することが必要です。これは、今後の政策決定や経済の見通しに影響を与える可能性があるため、最新のデータを収集して正確な分析を行いたいと思います。
>
> **公開鍵ECBポリシーの検索**
>
> [ECB to hike rates in June and at least once more on war-led inflation spike: Reuters poll  | Reuters](https://www.reuters.com/business/ecb-hike-rates-june-least-once-more-war-led-inflation-spike-2026-05-13/)
>
> **日本のマクロ経済に関する情報収集**
>
> 日本の経済に関するマクロデータについて、特に日本銀行（BoJ）の「意見の概要」が今週発表されるかもしれないので、関連の情報を集める必要があります。これが今後の市場展開にどう影響するかも把握したいですね。
>
> **Bank of Japan政策決定者の意見を検索**
>
>
> 思考時間: 6m 3s

対象は **2026年5月11日〜15日の取引週**です。週次変化は市場でよく使う **前週末5月8日終値→5月15日終値**で見ています。ここでは主要国債、すなわち米国債、独Bund、英国Gilt、日本国債を中心に整理します。

## 1. 週次サマリー：全面的な「債券安・利回り上昇」

先週は、典型的なリスクオフの国債買いではなく、**エネルギー価格ショックによるインフレ再加速懸念で、株も債券も売られるタイプの週**でした。米10年は **4.38%→4.59%、+21bp**、独10年は **約3.00%→約3.15%、+15bp**、英10年は **4.92%→5.18%、+26bp**、日10年は **2.48%→2.71%、+23bp**。特に英国と日本は、それぞれ政治・財政プレミアム、BOJ利上げ観測が重なり、グローバル・デュレーション売りを上回るストレスが出ました。([U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve))

| 市場 | 5月8日 | 5月15日 | 週次変化 | コメント |
|---|---:|---:|---:|---|
| 米2年国債 | 3.90% | 4.09% | **+19bp** | Fed利下げ期待が剥落し、利上げ織込みも意識。 |
| 米10年国債 | 4.38% | 4.59% | **+21bp** | CPI・PPI・原油高を受けてインフレリスクを再価格化。 |
| 米30年国債 | 4.95% | 5.12% | **+17bp** | 30年入札の高利回りも長期ゾーンの需給懸念に。([U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)) |
| 独10年Bund | 3.0047% | 3.1535% | **+15bp** | ECB利上げ観測とグローバル長期金利上昇に連動。([Investing.com](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data?utm_source=chatgpt.com)) |
| 英10年Gilt | 4.919% | 5.178% | **+26bp** | グローバル・インフレ懸念に英国政治・財政不安が上乗せ。([Investing.com](https://www.investing.com/rates-bonds/uk-10-year-bond-yield-historical-data?utm_source=chatgpt.com)) |
| 英30年Gilt | 5.575% | 5.850% | **+28bp** | 超長期は財政リスク・LDI/年金需給への懸念を反映。([Investing.com](https://www.investing.com/rates-bonds/uk-30-year-bond-yield-historical-data?utm_source=chatgpt.com)) |
| 日10年国債 | 2.478% | 2.706% | **+23bp** | BOJ利上げ観測、企業物価上振れ、円安・輸入インフレ。([Investing.com](https://www.investing.com/rates-bonds/japan-10-year-bond-yield-historical-data?utm_source=chatgpt.com)) |
| 日30年国債 | 3.719% | 4.011% | **+29bp** | 超長期ゾーンは史上初の4%台到達で、需給不安も顕在化。([Investing.com](https://www.investing.com/rates-bonds/japan-30-year-bond-yield-historical-data?utm_source=chatgpt.com)) |

## 2. マクロイベントとの対応関係

| 日付 | マクロイベント | 金利への効き方 |
|---|---|---|
| 5月12日 | 米4月CPIが前年比 **3.8%**に加速。2023年5月以来の大きな伸びと報じられた。 | Fedの利下げ期待がさらに後退し、短中期ゾーンと10年の名目金利が上昇。インフレ・ブレークイーブンだけでなく、実質金利・タームプレミアムも押し上げ。([Reuters](https://www.reuters.com/business/us-consumer-prices-increase-further-april-2026-05-12/?utm_source=chatgpt.com)) |
| 5月12日 | BOJの4月会合「主な意見」で、近い将来の利上げを示唆する声が確認された。 | JGBは政策金利パスを再価格化。10年JGBが29年ぶり水準へ上昇し、超長期にも売りが波及。([Reuters](https://www.reuters.com/world/asia-pacific/some-boj-saw-need-raise-rates-soon-april-meeting-summary-shows-2026-05-12/?utm_source=chatgpt.com)) |
| 5月13日 | 米4月PPIが前年比 **6.0%**。2022年12月以来の大きな伸び。 | CPIだけでなく川上インフレも強いことが確認され、米長期金利がさらに上昇。企業マージン圧迫と価格転嫁の両方が意識された。([Reuters](https://www.reuters.com/business/us-producer-prices-post-biggest-gain-four-years-april-2026-05-13/?utm_source=chatgpt.com)) |
| 5月13日 | 米財務省の30年債入札が **5.046%**で決着、2007年以来の5%台入札利回り。 | 長期債需給への警戒が強まり、30年・超長期ゾーンのタームプレミアム上昇材料に。([ブルームバーグ](https://www.bloomberg.com/news/articles/2026-05-13/treasury-buyers-get-5-long-bond-rate-for-first-time-since-2007?utm_source=chatgpt.com)) |
| 5月15日 | 原油高・イラン情勢で、米10年・30年が約1年ぶり高水準へ。 | 「エネルギーショック＝インフレショック」として、米国債だけでなくBund、Gilt、JGBにも同時売りが波及。([Reuters](https://www.reuters.com/business/energy/yields-surge-may-2025-highs-oil-prices-and-inflation-data-rattle-markets-2026-05-15/?utm_source=chatgpt.com)) |
| 5月15日 | 日本の企業物価が前年比 **4.9%**、円建て輸入物価が前年比 **17.5%**に上昇。 | BOJの6月利上げ観測を強め、JGBカーブ全体、特に10年〜30年に上昇圧力。([Reuters](https://www.reuters.com/world/asia-pacific/japan-april-wholesale-inflation-rate-spikes-rising-import-costs-2026-05-15/?utm_source=chatgpt.com)) |
| 5月15日 | 英国ではAndy Burnham氏の労働党党首挑戦観測が強まり、政治・財政不安がGiltに波及。 | 英10年Giltは5.17%近辺まで上昇、独Bundとのスプレッドも拡大。英国固有の財政プレミアムが乗った。([Reuters](https://www.reuters.com/world/uk/uk-10-year-yields-hit-highest-since-2008-political-worries-global-inflation-2026-05-15/?utm_source=chatgpt.com)) |

## 3. 国別の解釈

**米国債**は、CPI、PPI、30年債入札の3点セットで売られました。2年が+19bp、10年が+21bp、30年が+17bpなので、単純な「Fed利上げだけ」のフロントエンド主導ではなく、**インフレリスクとタームプレミアムの上昇が10年中心に効いた**形です。5月15日には、原油高とイラン情勢を背景に、10年・30年利回りが2025年5月以来の高水準と報じられました。([U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve))

**独Bund**は、米金利と原油高に引っ張られつつ、ECB利上げ観測が再燃しました。ユーロ圏4月インフレ率は3.0%に上がり、ECB目標の2%を上回った状態で、Brent原油高が続けばECBが6月以降に利上げするとの見方が強まりました。Bund10年は週末に3.15%台まで上昇し、15年ぶり高水準近辺の動きです。([Reuters](https://www.reuters.com/business/euro-zone-inflation-soars-further-above-ecb-target-oil-prices-2026-04-30/?utm_source=chatgpt.com))

**英国Gilt**は、主要国の中でも弱さが目立ちました。背景はグローバルなインフレ金利上昇だけではなく、国内政治不安と財政プレミアムです。10年は+26bp、30年は+28bpと大きく売られ、30年Giltは5.8%台後半まで上昇しました。これは「インフレ再加速＋財政規律への疑念」という、英国債にとって最も悪い組み合わせに近い動きです。([Investing.com](https://www.investing.com/rates-bonds/uk-10-year-bond-yield-historical-data?utm_source=chatgpt.com))

**日本国債**は、グローバル金利上昇に加えて、BOJ正常化観測が主因です。BOJの4月会合で近い将来の利上げを支持する意見が出ていたことに加え、日本の企業物価と輸入物価が大きく上振れしました。10年JGBは2.7%台、30年JGBは4%台まで上昇し、円建て債券としての利回り水準が海外投資家・国内投資家のアセットアロケーションにも影響を与え始めています。([Reuters](https://www.reuters.com/world/asia-pacific/some-boj-saw-need-raise-rates-soon-april-meeting-summary-shows-2026-05-12/?utm_source=chatgpt.com))

## 4. まとめ：先週の本質

先週の主要債券市場は、**「景気悪化を見て国債が買われる」局面ではなく、「供給制約型インフレで中央銀行が緩めにくくなる」局面**として取引されました。そのため、債券は安全資産として機能しにくく、むしろインフレ・タームプレミアム・財政プレミアムの再評価で売られました。

重要なのは、米国は **インフレ指標と長期債需給**、欧州は **エネルギー価格とECB利上げ観測**、英国は **政治・財政プレミアム**、日本は **BOJ利上げ観測と輸入インフレ**というように、同じ「利回り上昇」でもドライバーが少しずつ違う点です。今後は、原油・ホルムズ海峡関連ニュース、米インフレ期待、ECB/BOJの6月会合、英国の政局が、主要国債の次の方向性を決めるイベントになります。([Reuters](https://www.reuters.com/business/global-bonds-tumble-flaring-inflation-spooks-investors-2026-05-15/?utm_source=chatgpt.com))

- [フィナンシャル・タイムズ](https://www.ft.com/content/11233902-2054-4ed5-b647-26402e7b58bd?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/uk/uk-10-year-yields-hit-highest-since-2008-political-worries-global-inflation-2026-05-15/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/uk/uk-30-year-gilt-yield-hits-highest-since-1998-political-inflation-fears-2026-05-15/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/asia-pacific/some-boj-saw-need-raise-rates-soon-april-meeting-summary-shows-2026-05-12/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/asia-pacific/japan-april-wholesale-inflation-rate-spikes-rising-import-costs-2026-05-15/?utm_source=chatgpt.com)

---

**Sources:**

- [Daily Treasury Rates | U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- [Germany 10-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data?utm_source=chatgpt.com)
- [US annual consumer inflation posts largest gain in three ...](https://www.reuters.com/business/us-consumer-prices-increase-further-april-2026-05-12/?utm_source=chatgpt.com)
- [Treasury Buyers Get 5% Long Bond for First Time Since 2007](https://www.bloomberg.com/news/articles/2026-05-13/treasury-buyers-get-5-long-bond-rate-for-first-time-since-2007?utm_source=chatgpt.com)

## Response:
2026/5/18 7:18:18

前回回答の数値・イベント対応を事実確認し、確認できる市場データと公的・一次寄り情報に絞って、誤りを切り分けたうえで修正版を要約します。

大枠の「金利上昇＝債券安」は維持しつつ、因果表現は控えめにし、非米国債の利回りはデータ源により数bpずれる点も明示します。

> **Re-auditing bond yield data and verifying sources**
>
> [Is the Fed turning hawkish as inflation fears rise?](https://www.ft.com/content/e92afb1c-6abc-4883-b268-98b91c1a9679)
> [Inflation Making It Hard for Fed to Cut Rates, Gundlach Says](https://www.barrons.com/livecoverage/sundayshows0517/card/inflation-making-it-hard-for-fed-to-cut-rates-gundlach-says-QcwRUxHZJ09h7qolkmPl)
> [Bond yield spike is risk to unprepared equities market, investors warn](https://www.reuters.com/business/bond-yield-spike-is-risk-unprepared-equities-market-investors-warn-2026-05-17/)
> [Daily Treasury Bill Rates](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_bill_rates)
> [米4月PPI、前年比6.0％上昇 3年4カ月ぶりの高い伸び](https://jp.reuters.com/markets/japan/E4JKNND5FFMYBAKEK4XP2FZFH4-2026-05-13/)
> [米4月PPI、前年比6.0％上昇 3年4カ月ぶりの高い伸び](https://www.threads.com/%40reutersjapan/post/DYR9gq9lOv-)
> [Yields surge to one-year high as oil prices and inflation ...](https://www.kitco.com/news/off-the-wire/2026-05-15/yields-surge-one-year-high-oil-prices-and-inflation-data-rattle)
>
> **確認中：米国財務省の毎日金利**
>
> [Daily Treasury Rates | U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_bill_rates)
> [Yields surge to one-year high as oil prices and inflation data rattle markets | Reuters](https://www.reuters.com/business/energy/yields-surge-may-2025-highs-oil-prices-and-inflation-data-rattle-markets-2026-05-15/)
>
> **URLから日次国債利回り曲線データを検索**
>
> [Daily Treasury Rates | U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
>
> **URLで日次米国債利回りを検索**
>
> [Daily Treasury Rates | U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
>
> **検索: 5月8日〜15日のライン**
>
> [Daily Treasury Rates | U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
>
> **欧州・米国・日本の国債利回り検索**
>
> [Record high Japanese yields trigger bets on repatriation](https://www.ft.com/content/6e363bc3-3114-4ddf-9f3b-67f031b3ef92)
> [Bank under pressure to stop selling bonds as borrowing costs rise](https://www.thetimes.com/business/economics/article/bank-of-england-should-stop-selling-bonds-6h022xwpf)
> [UK 10-year bonds head for sharpest daily slump since April 2025](https://www.reuters.com/world/uk/uk-10-year-yields-hit-highest-since-2008-political-worries-global-inflation-2026-05-15/)
> [German 10-Year Bund Yield Hits 3.136%, Highest Since ...](https://www.roic.ai/news/german-10-year-bund-yield-hits-3136-highest-since-2011-05-15-2026)
> [Ten-Year Bund Yield Hits 15-Year High as Surging Oil ...](https://finance.yahoo.com/economy/policy/articles/ten-bund-yield-hits-15-101800895.html)
> [German 10-year bond yield dips, but still near multi- ...](https://www.tradingview.com/news/reuters.com%2C2026%3Anewsml_L6N41R0VP%3A0-german-10-year-bond-yield-dips-but-still-near-multi-year-high-on-inflation-concerns/)
> [UK 10-year yields hit highest since 2008 on political ...](https://uk.finance.yahoo.com/news/uk-10-yields-hit-highest-091911351.html)
> [Japan 10 Year Government Bond Yield - Quote - Chart](https://tradingeconomics.com/japan/government-bond-yield)
> [Germany 10-Year Bond Yield](https://www.investing.com/rates-bonds/germany-10-year-bond-yield)
> [UK 10-year yields hit highest since 2008 on political worries ...](https://www.marketscreener.com/news/uk-10-year-yields-hit-highest-since-2008-on-political-worries-global-inflation-concerns-ce7f5bd2dc8ff322)
>
> **調べて欧州地域のインフレデータを確認**
>
> 欧州地域のインフレに関して、公式な情報源を使用したほうが良いかもしれません。信頼できる統計や公的機関からのデータを調べて、正確な情報を得る方法を考えます。
>
> **欧州圏インフレと関連データの検索**
>
> [The looming energy crunch](https://www.ft.com/content/08665686-f673-46ca-9dba-fd34e1546e7c)
> [Bond yield spike is risk to unprepared equities market, investors warn](https://www.reuters.com/business/bond-yield-spike-is-risk-unprepared-equities-market-investors-warn-2026-05-17/)
> [Enverus confirms forecast for $90-$95 WTI through 2027](https://www.mrt.com/business/oil/article/strait-hormuz-crude-oil-outlook-22257422.php)
> [Euro area annual inflation up to 3.0% - European Union](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap)
> [Economic Bulletin Issue 3, 2026 - European Central Bank](https://www.ecb.europa.eu/press/economic-bulletin/html/eb202603.en.html)
> [Annual inflation up to 2.6% in the euro area, up to 2.8% in ...](https://www.facebook.com/EurostatStatistics/videos/annual-inflation-up-to-26-in-the-euro-area-up-to-28-in-the-eu-how-does-it-compar/1301855535228060/)
> [Euro area inflation expected to be at 3.0% in April 2026, up ...](https://www.reddit.com/r/europe/comments/1szrayi/euro_area_inflation_expected_to_be_at_30_in_april/)
> [Euro area #inflation expected to be at 3.0% in April 2026, ...](https://x.com/EU_Eurostat/status/2049775773347631467)
>
> **UKの詳細を調べる必要がある**
>
> イギリスに関する詳細情報が必要かもしれません。何か特定の事柄に関して調査が必要な場合、その内容を確認して、正しい情報を得る方法を探ることが重要です。
>
> **情報検索（UK 詳細）**
>
> [UK 10-year bonds head for sharpest daily slump since April 2025 | Reuters](https://www.reuters.com/world/uk/uk-10-year-yields-hit-highest-since-2008-political-worries-global-inflation-2026-05-15/)
>
> **日本の情報を調べる必要がある**
>
> 日本に関連する情報が必要かもしれません。特定の事柄について確認する必要があれば、適切な情報源を開いて調査を始めるべきですね。
>
> **日本オープンの情報検索**
>
> [BOJ debated near‑term rate hike at April meeting, opening door to June move | Reuters](https://www.reuters.com/world/asia-pacific/some-boj-saw-need-raise-rates-soon-april-meeting-summary-shows-2026-05-12/)
> [
	Japan 10 Year Government Bond Yield - Quote - Chart - Historical Data - News
](https://tradingeconomics.com/japan/government-bond-yield)
>
> **ドイツのデータを調べる必要がある**
>
> ドイツに関するデータが必要かもしれません。Trading EconomicsやReutersなどの信頼できる情報源から調べる方法を考え、グローバルな債券市場に関する情報も確認すべきかもしれません。
>
> **検索してドイツとグローバル債券データ**
>
> [Global bonds battered as flaring inflation spooks investors | Reuters](https://www.reuters.com/business/global-bonds-tumble-flaring-inflation-spooks-investors-2026-05-15/)
> [
	Germany 10-Year Bond Yield - Quote - Chart - Historical Data - News
](https://tradingeconomics.com/germany/government-bond-yield)
> [German 10-year bond yield dips, but still near multi-year high on inflation concerns  — TradingView News](https://www.tradingview.com/news/reuters.com%2C2026%3Anewsml_L6N41R0VP%3A0-german-10-year-bond-yield-dips-but-still-near-multi-year-high-on-inflation-concerns/)
> [Euro area annual inflation up to 3.0% - Euro indicators - Eurostat](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap)
>
> **米国財務省とReutersの情報を確認する必要がある**
>
> 米国財務省の公式情報やReutersを参考にする必要があるかもしれません。また、消費者物価指数（CPI）や生産者物価指数（PPI）の情報も開いて確認するべきかもしれません。
>
> **調査中：米財務省、ロイター、CPI/PPI**
>
> [US annual consumer inflation posts largest gain in three years as prices increase broadly | Reuters](https://www.reuters.com/business/us-consumer-prices-increase-further-april-2026-05-12/)
>
> **アメリカ、ヨーロッパ、日本のデータの週次変動**
>
> アメリカの公式データは取得できるけど、ヨーロッパと日本のデータは前週と一致しないかもしれません。Trading Economicsは日/月/年単位でのデータしか提供していないので、週ごとの変動は不明です。一部はInvesting.comの古いデータで調べるかもしれません。
>
> **Searching bond yield historical data for May 2026**
>
> [Record high Japanese yields trigger bets on repatriation](https://www.ft.com/content/6e363bc3-3114-4ddf-9f3b-67f031b3ef92)
> [UK 10-year bonds head for sharpest daily slump since April 2025](https://www.reuters.com/world/uk/uk-10-year-yields-hit-highest-since-2008-political-worries-global-inflation-2026-05-15/)
> [U.S. 30-year Treasury yield tops 5.1% in a bond rout that's gone global](https://www.marketwatch.com/livecoverage/stock-market-today-dow-s-p-500-and-nasdaq-set-to-pull-back-as-treasury-yields-climb/card/u-s-30-year-treasury-yield-tops-5-1-in-a-bond-rout-that-s-gone-global-1m80ZjZHwpf9DvCmYVWL)
> [Left-leaning Andy Burnham's leadership tilt spooks bond market](https://www.thetimes.com/business/companies-markets/article/uk-borrowing-costs-rise-andy-burnham-starmer-mx06zqg69)
> [UK borrowing costs hit new highs as City traders brace for Burnham, and pound heads for worst week since 2024 - as it happened](https://www.theguardian.com/business/live/2026/may/15/rich-list-sunday-times-billionaires-reform-donor-christopher-harborne-hinduja-radcliffe-dyson-beckham-live-updates)
> [Treasury Yields Jump Amid Fed Shift. Blame These Culprits As S&P 500 Falls.](https://www.investors.com/news/treasury-yields-jump-amid-fed-shift-blame-these-culprits-sp-500-falls/)
> [Germany 10-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data)
> [United Kingdom 10-Year Bond Yield Historical Data](https://uk.investing.com/rates-bonds/uk-10-year-bond-yield-historical-data)
> [United Kingdom 10-Year Bond Yield Historical Data](https://ca.investing.com/rates-bonds/uk-10-year-bond-yield-historical-data)
> [Germany 10-Year Bond Yield - Quote - Chart - Historical Data](https://tradingeconomics.com/germany/government-bond-yield)
> [United Kingdom 10-Year Bond Yield Historical Data](https://za.investing.com/rates-bonds/uk-10-year-bond-yield-historical-data)
> [Germany 10 Year Government Bond TMBMKDE-10Y ( ...](https://www.wsj.com/market-data/quotes/bond/BX/TMBMKDE-10Y/)
>
> **前回の回答を確認して修正する必要がある**
>
> 前回の記述を見直して修正が必要かもしれません。修正が必要な部分には「前回の記述のうち、以下は修正」といった注釈を付けたいですね。また、正しい引用と「30年入札 at 5.046 2007 since」について確認するために調査を行う必要があります。
>
> **検索して30年国債入札結果を確認**
>
> [Record high Japanese yields trigger bets on repatriation](https://www.ft.com/content/6e363bc3-3114-4ddf-9f3b-67f031b3ef92)
> [Stocks Rally While Inflation Takes 30-year Yield to 5%](https://www.barrons.com/livecoverage/stock-market-news-today-051326/card/stocks-rally-while-inflation-takes-30-year-yield-to-5--enjlPOU21gHmEQxJ7j8v)
> [Treasury Yields Pare Down Increase Triggered by Hot Inflation](https://www.wsj.com/finance/jgb-yields-rise-after-u-s-treasury-yields-gained-on-inflation-data-ffb489f8)
> [Treasury Buyers Get 5% Long Bond for First Time Since 2007](https://www.bloomberg.com/news/articles/2026-05-13/treasury-buyers-get-5-long-bond-rate-for-first-time-since-2007)
> [US treasury auctions off $25 billion of 30 year bonds at a ...](https://www.tradingview.com/news/forexlive%3Aadea1d5db094b%3A0-us-treasury-auctions-off-25-billion-of-30-year-bonds-at-a-high-yield-of-5-046/)
> [30-Year Treasury Auction Clears Above 5%, Highest Yield ...](https://finance.yahoo.com/markets/currencies/articles/30-treasury-auction-clears-above-084711351.html)
> [Treasury Buyers Get 5% Long Bond For First Time Since ...](https://www.fa-mag.com/news/treasury-buyers-get-5--long-bond-for-first-time-since-2007-87023.html)
> [30-Year Bond Auction Summary The ...](https://x.com/ExanteData/status/2054609802978873833)
> [US Treasury sells USD 25 bn worth of 30-year bonds at ...](https://www.tribuneindia.com/news/business/us-treasury-sells-usd-25-bn-worth-of-30-year-bonds-at-5-046-yield-amid-strong-foreign-demand/)
> [Treasury Sells 30-Year Bonds Above 5% for First Time Since ...](https://www.connectmoney.com/evening-brief/treasury-sells-30-year-bonds-above-5-for-first-time-since-2007-evening-brief-05-13-26/)
> [US sells 30-year debt at highest yield since 2007](https://www.argaam.com/en/article/articledetail/id/1905657)
> [The US Treasury sold 30-year bonds at a yield above 5% ...](https://www.facebook.com/euronews/posts/the-us-treasury-sold-30-year-bonds-at-a-yield-above-5-for-the-first-time-since-2/1354895746685752/)
> [US treasury auctions off $25 billion of 30 year bonds at a ...](https://fxverify.com/ja/news/us-treasury-auctions-off-25-billion-of-30-year-bonds-at-a-high-yield-of-5046-52402)
> [Announcements, Data & Results](https://www.treasurydirect.gov/auctions/announcements-data-results/)
> [US 30-Year Bond Auction Disappoints, Yield Tops 5% for First ...](https://finance.biggo.com/news/brwMI54BrX5PFN7BuNkg)
> [Treasury auctions 5% long bond for first time since 2007](https://seekingalpha.com/news/4592405-treasury-auctions-5-long-bond-for-first-time-since-2007)
> [https://www.bloomberg.com/news ...](https://www.threads.com/%40howard.strauber/post/DYTiFslFkE1)
> [US treasury auctions off $25 billion of 30 year bonds at a ...](https://longbridge.com/en/news/286295801)
> [US long bonds over 5% - buy or beware?](https://www.reuters.com/markets/us/us-long-bonds-over-5-buy-or-beware-2026-05-06/)
> [U.S. Treasury auctions $25bn of 30-year bonds at 5.046 ...](https://tradersunion.com/news/market-voices/show/2049489-us-treasury-bond-auction/)
> [Charles-Henry Monchau, CFA, CMT, CAIA's Post](https://www.linkedin.com/posts/charles-henry-monchau-cfa-cmt-caia-4003096_oops-treasury-buyers-get-5-long-bond-for-activity-7460562059605360641-KEf1)
> [US Treasury Sells $25B in 30-Year Bonds at 5.046% Yield](https://www.binance.com/en/square/post/323001615633473)
> [Yield on 30-yr U.S. Treasury bond climbs slightly after $25 bln ...](https://www.marketscreener.com/news/yield-on-30-yr-u-s-treasury-bond-climbs-slightly-after-25-bln-auction-up-1-7-basis-points-at-5-04-ce7f5bdcdc89fe25)
>
> **ドイツの日付データの取得**
>
> MarketWatchやInvestingからドイツの日付データを取得する必要がありそうですが、検索結果のみを使用しても大丈夫か確認中です。検索結果は引用できるけれど、信頼性については慎重に確認する必要があります。データをダウンロードして、参照できるか確認します。
>
> **検索結果からドイツのデータ取得確認**
>
> [Germany 10-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data)
>
> **再監視してまとめ**
>
> 前回の回答は大体正しかったが、いくつかの数値を修正する必要がありそう。例えば、米国20年債、ドイツ10年債、英国10年債、日本10年債の変動は確認済みだが、日本30年債の数値（4.000か4.011か）について検証が必要。Japan 30の過去データを調べると良いかも。
>
> **Verifying Japan 30-Year JGB Bond Yield Data**
>
> [Record high Japanese yields trigger bets on repatriation](https://www.ft.com/content/6e363bc3-3114-4ddf-9f3b-67f031b3ef92)
> [Japan's wholesale inflation spikes on energy shock, bolsters case for June rate hike](https://www.reuters.com/world/asia-pacific/japan-april-wholesale-inflation-rate-spikes-rising-import-costs-2026-05-15/)
> [U.S. 30-year Treasury yield tops 5.1% in a bond rout that's gone global](https://www.marketwatch.com/livecoverage/stock-market-today-dow-s-p-500-and-nasdaq-set-to-pull-back-as-treasury-yields-climb/card/u-s-30-year-treasury-yield-tops-5-1-in-a-bond-rout-that-s-gone-global-1m80ZjZHwpf9DvCmYVWL)
> [Japan 30-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/japan-30-year-bond-yield-historical-data)
> [日本](https://ja.wikipedia.org/wiki/%E6%97%A5%E6%9C%AC)
> [Japan](https://en.wikipedia.org/wiki/Japan)
> [Travel Japan - Japan National Tourism Organization (Official ...](https://www.japan.travel/en/)
> [JapanGov: The Government of Japan](https://www.japan.go.jp/)
> [Ministry of Foreign Affairs of Japan](https://www.mofa.go.jp/)
> [日本政府観光局（JNTO） - Japan National Tourism ...](https://www.jnto.go.jp/)
> [japan-guide.com - Japan Travel and Living Guide](https://www.japan-guide.com/)
> [The Japan Times - News On Japan, Business News, Opinion ...](https://www.japantimes.co.jp/)
> [Japan travel - Lonely Planet | Asia](https://www.lonelyplanet.com/destinations/japan)
>
> **日本30年債の歴史データを確認する必要がある**
>
> 日本30年債の過去データを開く必要がありそうです。これにより、以前の数値（例えば、4.000か4.011）の確認がスムーズになるかもしれません。さらに詳細な情報を調べてから、正確なデータを反映させたいと思います。
>
> **検索履歴のない日本30年分のデータ**
>
> [Japan 30-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/japan-30-year-bond-yield-historical-data)
>
> **イギリス30年債の歴史データが必要かもしれない**
>
> イギリスの30年債の過去データを確認する必要がありそうです。これにより、関連する情報をさらに正確に把握できるかもしれません。状況に応じて、詳細な情報を調べたほうが良さそうですね。
>
> **英国30年債券利回りの履歴データ検索**
>
> [UK 30-year gilt yield hits highest since 1998 on political and inflation fears](https://www.reuters.com/world/uk/uk-30-year-gilt-yield-hits-highest-since-1998-political-inflation-fears-2026-05-15/)
> [30-Year Treasury Yield Ends Week at Near-Two-Decade High](https://www.wsj.com/livecoverage/stock-market-today-dow-sp-500-nasdaq-05-15-2026/card/30-year-treasury-yield-tops-5-1--1yDfafHleZ3Fjc754T0I)
> [Global bonds tumble on fears of inflation shock from Iran war](https://www.ft.com/content/02015e49-fe11-488f-9e45-9fe70943d155)
> [UK borrowing costs hit new highs as City traders brace for Burnham, and pound heads for worst week since 2024 - as it happened](https://www.theguardian.com/business/live/2026/may/15/rich-list-sunday-times-billionaires-reform-donor-christopher-harborne-hinduja-radcliffe-dyson-beckham-live-updates)
> [Bond yields are breaking out as 30-year yield heads for highest since 2007](https://www.marketwatch.com/livecoverage/stock-market-today-dow-s-p-500-and-nasdaq-set-to-pull-back-as-treasury-yields-climb/card/bond-yields-are-breaking-out-as-30-year-yield-heads-for-highest-since-2007-Z9AVyEeEGX5oet4gd0ID)
> [United Kingdom 30-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/uk-30-year-bond-yield-historical-data)
> [United Kingdom 30-Year Bond Yield Historical Data](https://uk.investing.com/rates-bonds/uk-30-year-bond-yield-historical-data)
> [United Kingdom 30-Year Treasury Gilt Auction - Quote](https://tradingeconomics.com/united-kingdom/30-year-bond-yield)
> [United Kingdom 30 Years Bond - Historical Data](https://www.worldgovernmentbonds.com/bond-historical-data/united-kingdom/30-years/)
> [Historical Average Daily Conventional Gilt Yields](https://www.dmo.gov.uk/data/ExportReport?reportCode=D4H)
> [United Kingdom 30-Year Bond Yield Historical Data](https://ca.investing.com/rates-bonds/uk-30-year-bond-yield-historical-data)
> [United Kingdom Rates & Bonds](https://www.bloomberg.com/markets/rates-bonds/government-bonds/uk)
> [UK - 30-Year Government Bond Yield | Series](https://en.macromicro.me/series/2266/uk-bond-30-year)
> [United Kingdom, Yield, Bonds - Economic Data Series - FRED](https://fred.stlouisfed.org/tags/series?t=bonds%3Bunited+kingdom%3Byield)
>
> **再監する内容と要約**
>
> 前回の回答は大体正しい方向性でしたが、表現や根拠について修正が必要でした。特に、30年JGBのデータに関して、情報源によって違いがあり（Investingは4.011、TradingEconomicsは4.00）。ReuterやInvestingのデータ提供時刻の差も考慮すべきです。また、先週の本質を説明するなら、グローバルにおけるインフレショック（石油/Iran）による債券売りが主因で、安全資産の買い戻しではありません。
>
> **要約と今週の主要イベント**
>
> 今週の重要なマクロイベントとして、米国CPI、PPI、石油価格、米30年債入札、BOJ議事録、CG
>
> **Looking for official BLS CPI/PPI data 2026**
>
> [Record high Japanese yields trigger bets on repatriation](https://www.ft.com/content/6e363bc3-3114-4ddf-9f3b-67f031b3ef92)
> [US inflation jumped to 3.8% in April as war with Iran continues to drive up prices](https://www.theguardian.com/business/2026/may/12/us-inflation-april-iran-war)
> [Inflation Soared to 3.8% in April, Driven by Gasoline Prices](https://www.wsj.com/economy/cpi-inflation-report-april-62b11096)
> [April CPI rises more than expected; bond yields climb](https://www.reuters.com/business/view-april-cpi-rises-more-than-expected-bond-yields-climb-2026-05-12/)
> [BLSとは？ - NPO法人日本ACLS協会 ガイド](https://acls.or.jp/dictionary/bls/)
> [Producer Price Indexes - April 2026](https://www.bls.gov/news.release/pdf/ppi.pdf)
> [Monthly Report on the Corporate Goods Price Index(April ...](https://www.boj.or.jp/en/statistics/pi/cgpi_release/cgpi2604.pdf)
> [BLS（一次救命処置）とは？資格は必要？ ...](https://www.ak-zoll.com/aed/column/aedcolumn033.html)
> [BOJ signals possible June rate hike amid inflation risks ...](https://www.japantimes.co.jp/business/2026/05/12/economy/boj-april-summary-opinion-interest-rate/)
> [一次救命処置](https://www.jrc-cpr.org/wp-content/uploads/2022/07/JRC_0017-0046_BLS.pdf)
> [BOJ Member Saw Possible Near-Term Rate Hike: Summary](https://www.nippon.com/en/news/yjj2026051200361/)
> [Japan's April Corporate Goods Price Index Surges 4.9 ...](https://finance.biggo.com/news/OkORKZ4BrAZSr0oSs7o2)
> [BLS（1次救命処置）](https://www.tokushukai.or.jp/er/bls/)
> [Title: Producer Price Indexes—April 2026](https://fraser.stlouisfed.org/title/producer-price-indexes-6837/producer-price-indexes-april-2026-725562)
> [BOJ policymaker says rate hike possible even amid Middle ...](https://mainichi.jp/english/articles/20260512/p2g/00m/0bu/022000c)
> [Corporate goods price index rose 4.9% in April, the highest ...](https://www.youtube.com/watch?v=5WdDK7iYKb4)
> [Producer Price Index (PPI) Analysis – April 2026 – 05/13/26](https://www.linkedin.com/pulse/producer-price-index-ppi-analysis-april-2026-051326-0830-faisal-amjad-4apsf)
>
> **BLS CPIニュースリリースURL検索**
>
> [US inflation jumped to 3.8% in April as war with Iran continues to drive up prices](https://www.theguardian.com/business/2026/may/12/us-inflation-april-iran-war)
> [The Iran war is hitting home as gasoline prices fuel inflation surge of 3.8% in the US](https://apnews.com/article/3f11b7fdd20ea56d2f0895e5241af7b6)
> [April CPI rises more than expected; bond yields climb](https://www.reuters.com/business/view-april-cpi-rises-more-than-expected-bond-yields-climb-2026-05-12/)
> [Consumer Price Index - April 2026](https://www.bls.gov/news.release/pdf/cpi.pdf)
> [Consumer Price Index: Inflation at 3.8% in April - dshort](https://www.advisorperspectives.com/dshort/updates/2026/05/12/cpi-consumer-price-index-inflation-april-2026)
> [Consumer Price Index (CPI) Analysis – April 2026 – 05/12/26](https://www.linkedin.com/pulse/consumer-price-index-cpi-analysis-april-2026-051226-0830-faisal-amjad-dypvf)
>
> **PDF分析における引用とスクリーンショット**
>
> PDFを分析する際、スクリーンショットツールを使用しなければなりません。今回、BLSとBOJのPDF結果を検索しましたが、スクリーンショットは使いませんでした。公式PDFを引用する際はスクリーンショットが必要ですが、HTML版を利用する方がわかりやすく、Reutersや日本版PDFで確かな情報が得られます。
>
> **適切な引用方法とデータ確認**
>
> PDFリンクで引用する際にはスクリーンショットが必要で、それなしでは避けるべきです。代わりに、以下のようなデータを引用したいです：
> 
> - USTデータは正式にTreasuryから、行724/729を引用。
> - Bund、UK、JGBの歴史的データは、InvestingやTrading Economicsから。必要に応じて特定行のデータを参照し開くことで確認。
>
> **Citing PDFs and Screenshot Requirements in Analysis**
>
>
> 思考時間: 5m 3s

再監査した結果、**前回回答の大筋は妥当**です。対象週は **2026年5月11日〜15日**、評価軸は **5月8日終値→5月15日終値**でよく、主要債券はほぼ全面的に **債券安・利回り上昇**でした。

ただし、**非米国債はデータベンダーや終値定義で数bpの差が出る**ため、独Bund・英Gilt・JGBは「レンジ感」で扱うのが安全です。米国債は米財務省CMTデータで、5月8日から5月15日にかけて2年 **3.90%→4.09%**、10年 **4.38%→4.59%**、30年 **4.95%→5.12%**でした。([U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=202605&type=daily_treasury_yield_curve))

## 再整理後の週次動向

| 市場 | 週次変化 | 主要ドライバー |
|---|---:|---|
| 米2年国債 | **+19bp** | CPI・PPI上振れでFed利下げ期待が後退。 |
| 米10年国債 | **+21bp** | インフレ再燃、原油高、Fedの反応関数再価格化。 |
| 米30年国債 | **+17bp** | インフレ懸念に加え、30年債入札が5%超で長期需給不安を確認。 |
| 独10年Bund | **約+15bp** | ユーロ圏インフレ3.0%、ECB利上げ観測、米金利上昇に連動。([Investing.com](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data?utm_source=chatgpt.com)) |
| 英10年Gilt | **約+26bp** | グローバル金利上昇に、英国の政治・財政プレミアムが上乗せ。([Investing.com](https://www.investing.com/rates-bonds/uk-10-year-bond-yield-historical-data?utm_source=chatgpt.com)) |
| 英30年Gilt | **約+28bp** | 超長期の財政リスク・インフレリスク再評価。30年は1998年以来の高水準圏。([Investing.com](https://www.investing.com/rates-bonds/uk-30-year-bond-yield-historical-data?utm_source=chatgpt.com)) |
| 日10年JGB | **約+23bp** | BOJ利上げ観測、企業物価・輸入物価上振れ。([Investing.com](https://www.investing.com/rates-bonds/japan-10-year-bond-yield-historical-data?utm_source=chatgpt.com)) |
| 日30年JGB | **約+29bp** | 超長期ゾーンの需給不安とBOJ正常化観測。4%台到達。([Investing.com](https://www.investing.com/rates-bonds/japan-30-year-bond-yield-historical-data?utm_source=chatgpt.com)) |

## マクロイベントとの対応

**米国：CPI・PPI・30年入札が中核イベント。**  
4月CPIは前年比 **3.8%**、コアは **2.8%**、エネルギーは前年比 **17.9%**上昇しました。続くPPIも前年比 **6.0%**、前月比 **1.4%**と強く、インフレが単なる一過性ショックで済まない可能性を市場が再評価しました。さらに、5月13日の30年債入札は **5.046%**で決着し、長期債の需給プレミアム上昇を補強しました。([Bureau of Labor Statistics](https://www.bls.gov/news.release/cpi.nr0.htm?utm_source=chatgpt.com))

**欧州：エネルギー起点のインフレとECB利上げ観測。**  
ユーロ圏4月インフレ率は **3.0%**と3月の2.6%から上昇し、エネルギー項目が強く効きました。このため、Bundは米金利だけでなく、ECBの追加引き締め観測でも売られました。([European Commission](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap?utm_source=chatgpt.com))

**英国：インフレ懸念に政治・財政プレミアムが重なった。**  
英Giltは主要国の中でも弱さが目立ちました。10年は5.18%近辺、30年は5.85%近辺まで上昇し、国内政局不安、財政緩和懸念、BoEのQT継続への警戒が重なりました。これは単なる「米金利連動」ではなく、英国固有のリスクプレミアム拡大です。([ザ・タイムズ](https://www.thetimes.com/business/economics/article/bank-of-england-should-stop-selling-bonds-6h022xwpf?utm_source=chatgpt.com))

**日本：BOJ正常化観測と輸入インフレ。**  
BOJの4月会合要旨では近い将来の利上げを支持する声が確認され、さらに日本の4月企業物価は前年比 **4.9%**、円建て輸入物価は **17.5%**上昇しました。これにより、6月利上げ観測が強まり、JGBは10年・30年とも大きく売られました。([Reuters](https://www.reuters.com/world/asia-pacific/some-boj-saw-need-raise-rates-soon-april-meeting-summary-shows-2026-05-12/?utm_source=chatgpt.com))

## 要約

先週の本質は、**「景気悪化で国債が買われる」局面ではなく、「エネルギー主導のインフレ再燃で中央銀行が緩めにくくなる」局面**でした。

したがって、債券は安全資産として買われるよりも、  
**インフレプレミアム上昇 → 政策金利パスの上方修正 → 長期・超長期のタームプレミアム上昇**  
という経路で売られました。

前回回答からの修正点を一言でまとめると、**方向感・イベント対応は妥当だが、非米国債の利回り水準はベンダー差を明示して「約」で扱うべき**、という点です。米国はCPI/PPIと30年入札、欧州はECB利上げ観測、英国は政治・財政プレミアム、日本はBOJ正常化観測が、それぞれ利回り上昇の主因でした。

- [フィナンシャル・タイムズ](https://www.ft.com/content/02015e49-fe11-488f-9e45-9fe70943d155?utm_source=chatgpt.com)
- [フィナンシャル・タイムズ](https://www.ft.com/content/11233902-2054-4ed5-b647-26402e7b58bd?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/uk/uk-30-year-gilt-yield-hits-highest-since-1998-political-inflation-fears-2026-05-15/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/uk/uk-10-year-yields-hit-highest-since-2008-political-worries-global-inflation-2026-05-15/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/asia-pacific/japan-april-wholesale-inflation-rate-spikes-rising-import-costs-2026-05-15/?utm_source=chatgpt.com)

---

**Sources:**

- [Daily Treasury Rates | U.S. Department of the Treasury](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=202605&type=daily_treasury_yield_curve)
- [Germany 10-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data?utm_source=chatgpt.com)
- [Consumer Price Index Summary - 2026 M04 Results](https://www.bls.gov/news.release/cpi.nr0.htm?utm_source=chatgpt.com)
- [Euro area annual inflation up to 3.0% - European Union](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap?utm_source=chatgpt.com)
- [Bank under pressure to stop selling bonds as borrowing costs rise](https://www.thetimes.com/business/economics/article/bank-of-england-should-stop-selling-bonds-6h022xwpf?utm_source=chatgpt.com)
- [BOJ debated near-term rate hike at April meeting, opening door to June move](https://www.reuters.com/world/asia-pacific/some-boj-saw-need-raise-rates-soon-april-meeting-summary-shows-2026-05-12/?utm_source=chatgpt.com)

## Response:
2026/5/18 11:10:38

ドイツ国債を切り出し、週次利回り変化、ユーロ圏インフレ・ECB観測、米金利・原油との連動に分けて補足します。

> **ドイツ国債に関する最新情報を提供**
>
> ユーザーがドイツ国債について触れるよう求めているので、最新の情報を調べる必要があります。おそらく先週のドイツ国債の動向（2026年5月11日～5月15日）を含め、ドイツ経済のマクロイベントに関する詳細が求められています。信頼できる公式なデータ源を探し、引用を追加します。
>
> **Browsing for recent German Bund yield data and analysis**
>
> [Japan's wholesale inflation spikes on energy shock, bolsters case for June rate hike](https://www.reuters.com/world/asia-pacific/japan-april-wholesale-inflation-rate-spikes-rising-import-costs-2026-05-15/)
> [10-Year Treasury Yield Nears Highest Level in Nearly a Year](https://www.wsj.com/livecoverage/stock-market-today-dow-sp-500-nasdaq-05-15-2026/card/10-year-treasury-yield-nears-highest-level-in-nearly-a-year-NESW9n9V7NSOmfNWo27s)
> [Germany 10-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data)
> [Euro area annual inflation up to 3.0% - European Union](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap)
> [Germany 2 Year Schatz Yield - Quote - Chart - Historical Data](https://tradingeconomics.com/germany/2-year-note-yield)
> [Eurozone inflation soars to 3% as Iran war drives up energy prices](https://www.theguardian.com/business/2026/apr/30/eurozone-inflation-increase-iran-war-drives-up-energy-prices)
> [Interest Rates: Long-Term Government Bond Yields: 10-Year ...](https://fred.stlouisfed.org/series/IRLTLT01DEM156N)
> [Euro area #inflation expected to be at 3.0% in April 2026, ...](https://x.com/EU_Eurostat/status/2049775773347631467)
> [Germany Bonds, Schatz 2% 10dec2026, EUR (FIGI ...](https://cbonds.com/bonds/1746675/)
>
> **ドイツ国債のデータと適切な引用**
>
> ドイツ国債の部分を強化するために、検索結果を元に答えを作成します。特にBundやSchatzの利回りに関する表を含め、引用を追加します。5月15日の2年ものSchatzデータ（2.73）を確認しましたが、5月8日のデータも確認する必要があります。信頼性の高い過去のデータを使用します。
>
> **Crafting and sourcing response on German bonds**
>
> [Germany 10-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data)
> [Euro area annual inflation up to 3.0% - Euro indicators - Eurostat](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap)
> [ECB to hike rates in June and at least once more on war-led inflation spike: Reuters poll  | Reuters](https://www.reuters.com/business/ecb-hike-rates-june-least-once-more-war-led-inflation-spike-2026-05-13/)
> [
	Germany 10-Year Bond Yield - Quote - Chart - Historical Data - News
](https://tradingeconomics.com/germany/government-bond-yield)
>
> **ドイツ国債に関する詳細なデータ提供**
>
> ドイツ政府債券（Bund）に関連するデータが必要です。2年および10年物の利回りを基にしたカーブの動きについて言及し、例えば5月15日の2年物が2.73％、10年物が3.15％でした。その後、10年物は3.0047から3.1535に上昇しました。
>
> **Searching German Bund yield data and curve dynamics**
>
> [JGB Yield Curve Steepens Sharply Amid Several Catalysts](https://www.wsj.com/finance/investing/jgbs-slide-on-global-bond-selloff-789740a2)
> [Bond yields are breaking out as 30-year yield heads for highest since 2007](https://www.marketwatch.com/livecoverage/stock-market-today-dow-s-p-500-and-nasdaq-set-to-pull-back-as-treasury-yields-climb/card/bond-yields-are-breaking-out-as-30-year-yield-heads-for-highest-since-2007-Z9AVyEeEGX5oet4gd0ID)
> [Germany](https://en.wikipedia.org/wiki/Germany)
> [Germany 5-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/germany-5-year-bond-yield-historical-data)
> [Germany | Facts, Geography, Maps, & History](https://www.britannica.com/place/Germany)
> [Germany 10-Year Bond Yield - Quote - Chart - Historical Data](https://tradingeconomics.com/germany/government-bond-yield)
> [Germany Travel: Top Attractions and Insider Tips for your ...](https://www.germany.travel/en/home.html)
> [Germany 5 Years Bond - Historical Data](https://www.worldgovernmentbonds.com/bond-historical-data/germany/5-years/)
> [Germany – EU country | European Union](https://european-union.europa.eu/principles-countries-history/eu-countries/germany_en)
> [deutschland.de - Your link to Germany](https://www.deutschland.de/en)
> [ドイツ連邦共和国｜外務省](https://www.mofa.go.jp/mofaJ/area/germany/index.html)
> [Federal Bonds](https://www.deutsche-finanzagentur.de/en/federal-securities/types-of-federal-securities/federal-bonds)
> [Home | Facts about Germany](https://www.tatsachen-ueber-deutschland.de/en)
> [Germany travel - Lonely Planet | Europe](https://www.lonelyplanet.com/destinations/germany)
>
> **投資情報の履歴データ確認**
>
> 2年物および5年物のドイツ国債に関する履歴データをInvestingサイトで確認し、必要な情報が一致するか確認したいと思います。これらのデータが見つかれば、必要な数値で対応を進めます。
>
> **投資の2年/5年履歴データ分析**
>
> [Germany 2-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/germany-2-year-bond-yield-historical-data)
> [
	Germany 5 Year Bobl Yield - Quote - Chart - Historical Data - News
](https://tradingeconomics.com/germany/5-year-note-yield)
>
> **30年物のデータ確認**
>
> 30年物のドイツ国債に関するデータをInvestingで確認して、必要な情報を取得します。それを基に、より詳細な内容を提供できるようにします。
>
> **検索：ドイツ30年債利回り履歴データ**
>
> [JGB Yield Curve Steepens Sharply Amid Several Catalysts](https://www.wsj.com/finance/investing/jgbs-slide-on-global-bond-selloff-789740a2)
> [Bond yields are breaking out as 30-year yield heads for highest since 2007](https://www.marketwatch.com/livecoverage/stock-market-today-dow-s-p-500-and-nasdaq-set-to-pull-back-as-treasury-yields-climb/card/bond-yields-are-breaking-out-as-30-year-yield-heads-for-highest-since-2007-Z9AVyEeEGX5oet4gd0ID)
> [Global bonds tumble on fears of inflation shock from Iran war](https://www.ft.com/content/02015e49-fe11-488f-9e45-9fe70943d155)
> [Germany 30-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/germany-30-year-bond-yield-historical-data)
> [Germany 30 Year Bond Yield - Quote - Chart - Historical Data](https://tradingeconomics.com/germany/30-year-bond-yield)
> [Germany 30 Years Bond - Historical Data](https://www.worldgovernmentbonds.com/bond-historical-data/germany/30-years/)
>
> **30年物の履歴データ確認**
>
> 30年物のドイツ国債の履歴データを確認する必要があります。それをもとに、さらに分析を進めることができるでしょう。
>
> **履歴を30件開く**
>
> [Germany 30-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/germany-30-year-bond-yield-historical-data)
>
> **まとめとデータ分析の要点**
>
> 今すぐに必要な回答として、ドイツ国債の2年、5年、10年、30年についての修正点を加えた表を示さなければなりません。また、EurostatやReuters調査に言及し、Bundと他国債の比較を通して、ドイツの債券市場における動きを説明します。
>
> 思考時間: 2m 25s

はい。前回のまとめには、**ドイツ国債＝Bund/Schatz/Boblをユーロ圏金利の中核ベンチマークとして明示的に入れるべき**です。追加すると次の整理になります。

## ドイツ国債：ECB利上げ観測とエネルギー・インフレで全面売り

先週、ドイツ国債も米国債・Gilt・JGBと同様に売られました。5月8日→5月15日の終値ベースでは、**2年Schatzが+13.5bp、5年Boblが+15.1bp、10年Bundが+14.9bp、30年Bundが+12.2bp**。おおむねパラレルなベア・ムーブですが、5〜10年中心の上昇がやや目立ち、30年は相対的に上昇幅が小さめでした。([Investing.com](https://www.investing.com/rates-bonds/germany-2-year-bond-yield-historical-data))

| ドイツ国債 | 5月8日 | 5月15日 | 週次変化 | 解釈 |
|---|---:|---:|---:|---|
| 2年 Schatz | 2.592% | 2.727% | **+13.5bp** | ECB利上げ織込みの再上昇。 |
| 5年 Bobl | 2.705% | 2.856% | **+15.1bp** | 政策パスと中期インフレ期待の両方を反映。 |
| 10年 Bund | 3.0047% | 3.1535% | **+14.9bp** | ユーロ圏ベンチマーク金利として、米金利・原油高・ECB観測に連動。 |
| 30年 Bund | 3.545% | 3.667% | **+12.2bp** | 超長期も売られたが、英国・日本ほどの固有財政プレミアムは限定的。 |

マクロ面では、ドイツは単なる「米金利連動」ではありませんでした。ドイツ4月卸売物価は前年比**+6.3%**と3年ぶり高水準となり、エネルギー・原材料価格の上昇が主因でした。Reutersは、石油製品価格が前年比**+37.3%**、ドイツのヘッドラインインフレが4月に**2.9%**へ加速したことも報じています。これにより、ドイツ国債は「安全資産として買われるBund」ではなく、**欧州インフレ再燃を織り込んで売られるBund**になりました。([Reuters](https://www.reuters.com/business/german-wholesale-prices-rise-63-april-2026-05-13/))

ECB要因も重要です。BundesbankのNagel総裁は、インフレ見通しが大きく変わらない限りECB利上げの可能性が高まっていると述べ、ECBがすでに前月会合で利上げを議論し、6月利上げを示唆していたとも報じられました。市場はECBの想定する2回より多い、年内3回程度の利上げを織り込む方向に動いており、これが2年〜10年のドイツ金利を押し上げました。([Reuters](https://www.reuters.com/business/ecbs-nagel-sees-rate-hikes-increasingly-likely-handelsblatt-2026-05-12/))

したがって、前回まとめの欧州パートは次のように修正するのが適切です。

> **欧州では、ドイツ10年Bundが3.00%台前半から3.15%近辺へ上昇し、ユーロ圏金利上昇の中心となった。背景は、米金利上昇の波及だけでなく、ドイツ卸売物価の急上昇、エネルギー価格高騰、ECB利上げ観測の再燃である。英国Giltのような政治・財政プレミアム主導ではなく、ドイツ国債はより純粋に「ECB政策パス＋欧州インフレ期待＋グローバル・デュレーション売り」を反映した動きだった。**

全体の位置づけとしては、**米国債＝Fed・米インフレ、ドイツBund＝ECB・欧州インフレ、英国Gilt＝財政/政治プレミアム、日本JGB＝BOJ正常化**という対比で見ると分かりやすいです。ドイツ国債はユーロ圏のアンカーなので、ここが売られたことは、欧州全体のスプレッド商品や周辺国債にも波及しやすいシグナルです。

---

**Sources:**

- [Germany 2-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/germany-2-year-bond-yield-historical-data)
- [Iran war pushes German wholesale price inflation to three-year high | Reuters](https://www.reuters.com/business/german-wholesale-prices-rise-63-april-2026-05-13/)

## Response:
2026/5/18 12:24:42

ドイツ国債に絞り、週次の金利変化を日付別イベントと年限別の反応に対応させて整理し直します。米金利連動、ECB観測、ドイツ物価データを分けます。

> **情報を確認して、正確なデータを取得する**
>
> ユーザーはドイツ国債の動きとマクロイベントの関連について質問しているようです。最近のデータを確認するために、ウェブで調べ、信頼できる情報源を使って更新された内容を提供します。特に、2026年の最新データに基づいた情報を、引用付きで提供する予定です。
>
> **Searching German bond yields and macro events**
>
> [JGB Yield Curve Steepens Sharply Amid Several Catalysts](https://www.wsj.com/finance/investing/jgbs-slide-on-global-bond-selloff-789740a2)
> [Iran war pushes German wholesale price inflation to three-year high](https://www.reuters.com/business/german-wholesale-prices-rise-63-april-2026-05-13/)
> [Germany 2-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/germany-2-year-bond-yield-historical-data)
> [Germany 10-Year Bond Yield - Quote - Chart - Historical Data](https://tradingeconomics.com/germany/government-bond-yield)
> [Wholesale prices in April 2026: +6.3% on April 2025](https://www.destatis.de/EN/Press/2026/05/PE26_164_61281.html)
> [ECB Rate Hikes Increasingly Likely, Nagel Tells Handelsblatt](https://www.bloomberg.com/news/articles/2026-05-12/ecb-rate-hikes-increasingly-likely-nagel-tells-handelsblatt)
> [Germany 2 Year Government Bond Overview](https://www.marketwatch.com/investing/bond/tmbmkde-02y?countrycode=bx)
> [Interest Rates: Long-Term Government Bond Yields: 10-Year ...](https://fred.stlouisfed.org/series/IRLTLT01DEM156N)
> [German wholesale prices rise 6.3% in April By Reuters](https://m.investing.com/news/economic-indicators/german-wholesale-prices-rise-63-in-april-4683243?ampMode=1)
> [ECB interest rate hikes increasingly likely: German central ...](https://www.xinhuanet.com/english/europe/20260513/75a1d411e4a44cc08a17757058fd0fd5/c.html)
> [Germany 30 Years vs Germany 5 Years Bond Spread](https://www.worldgovernmentbonds.com/spread/germany-30-years-vs-germany-5-years/)
> [German wholesale prices rise 6.3% in April](https://www.tradingview.com/news/reuters.com%2C2026%3Anewsml_APN8OJ8B6%3A0-german-wholesale-prices-rise-6-3-in-april/)
> [ECB's Nagel sees rate hikes increasingly likely: Handelsblatt](https://x.com/ReutersBiz/status/2054343537680892032)
> [Germany - 10-Year Government Bond Yields (1956-2026)](https://www.macrotrends.net/3385/germany-10-year-government-bond-yields)
>
> **確認と情報確認のための検索**
>
> ドイツ国債の2年、5年、30年の利回りデータを確認する必要があります。検索結果では、2年分の利回りがページに表示されていないので、もう少し具体的に調べたほうが良さそうです。信頼性のある情報源からデータ確認が必要です。
>
> **検索して債券利回りデータの確認**
>
> [Is the Fed turning hawkish as inflation fears rise?](https://www.ft.com/content/e92afb1c-6abc-4883-b268-98b91c1a9679)
> [April CPI Report: Higher Energy Prices Keep Inflation Hot](https://www.kiplinger.com/investing/economy/cpi-report-april-2026-what-to-expect)
> [Iran war pushes German wholesale price inflation to three-year high](https://www.reuters.com/business/german-wholesale-prices-rise-63-april-2026-05-13/)
> [Germany 5-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/germany-5-year-bond-yield-historical-data)
> [ドイツ 2年 債券 過去データ](https://jp.investing.com/rates-bonds/germany-2-year-bond-yield-historical-data)
> [Eurozone Inflation Outlook: Will Rising Energy Prices Force ...](https://global.morningstar.com/en-nd/economy/eurozone-inflation-outlook-will-rising-energy-prices-force-ecb-rate-hikes)
> [Economic Bulletin Issue 2, 2026 - European Central Bank](https://www.ecb.europa.eu/press/economic-bulletin/html/eb202602.en.html)
> [Energy prices push up inflation in Germany and Spain ...](https://www.euronews.com/business/2026/04/29/energy-prices-push-up-inflation-in-germany-and-spain-ahead-of-ecb-decision)
> [Euro area annual inflation up to 3.0% - European Union](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap)
> [Energy prices push up inflation in Germany and Spain ...](https://finance.yahoo.com/economy/policy/articles/energy-prices-push-inflation-germany-153501688.html)
>
> **ドイツ国債とマクロイベントの関連**
>
> 回答は簡潔で表形式が適切です。公式情報を参照し、マクロイベントの影響を示すタイムラインを作成します。最新のデータを引用し、ReutersやFTなど信頼できるニュースソースを使用して、必要に応じてUIナビリストを追加します。
>
> 思考時間: 3m 29s

以下のように、**ドイツ国債をマクロイベントと日次で対応**させると整理しやすいです。対象は **2026年5月11日〜15日**、利回り変化は **5月8日終値→5月15日終値**です。

## ドイツ国債の週次動向

| 年限 | 5月8日 | 5月15日 | 週次変化 | 主な意味合い |
|---|---:|---:|---:|---|
| 2年 Schatz | 2.592% | 2.727% | **+13.5bp** | ECB利上げ織込みの上昇 |
| 5年 Bobl | 2.705% | 2.856% | **+15.1bp** | 政策パス＋中期インフレ期待 |
| 10年 Bund | 3.0047% | 3.1535% | **+14.9bp** | 欧州ベンチマーク金利の再上昇 |
| 30年 Bund | 3.545% | 3.667% | **+12.2bp** | 長期インフレ・財政/供給プレミアム |

データ上は、**2〜10年がほぼ同じ幅で売られ、30年の上昇幅はやや小さめ**でした。つまり、英国Giltのような超長期主導の財政不安型というより、ドイツ国債は **ECB政策パスとエネルギー起点のインフレ再燃を中心にしたベア・パラレルに近い動き**です。利回りデータはInvesting.comの終値ベースで、10年Bundは5月8日の3.0047%から5月15日の3.1535%へ上昇しました。([Investing.com](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data))

## マクロイベントとの対応

| 日付 | ドイツ国債の動き | 対応するマクロイベント | 解釈 |
|---|---:|---|---|
| **5月11日** | 2年 +5.3bp、5年 +4.4bp、10年 +3.9bp、30年 +3.1bp | 前週から続く原油高・中東情勢・ユーロ圏インフレ懸念 | 週初からBundは買われず、エネルギー・ショックをインフレ材料として織り込み。安全資産買いよりも「ECBが緩められない」方向の反応。 |
| **5月12日** | 2年 +5.9bp、5年 +5.8bp、10年 +5.3bp、30年 +4.8bp | BundesbankのNagel総裁が、インフレ見通しが変わらなければECB利上げが一段とあり得ると発言 | この日は特に政策敏感な2〜5年が上昇。Nagel発言は、エネルギー高が期待インフレを不安定化させるならECBは利上げすべき、というメッセージで、Schatz/Boblに直接効いた。([Reuters](https://www.reuters.com/business/ecbs-nagel-sees-rate-hikes-increasingly-likely-handelsblatt-2026-05-12/)) |
| **5月13日** | 2年 +1.5bp、5年 +1.9bp、10年 +1.3bp、30年 +1.3bp | ドイツ4月卸売物価が前年比 **+6.3%**、前月比 **+2.0%**。鉱物油製品は前年比 **+37.3%** | ドイツ国内の川上インフレが確認され、Bund売りのファンダメンタルズが補強された。ただし前日までに相当織り込んでいたため、当日の利回り上昇幅は限定的。([Statistisches Bundesamt](https://www.destatis.de/EN/Press/2026/05/PE26_164_61281.html)) |
| **5月13日** | 2〜10年中心に高止まり | Reuters調査で、ECBは6月利上げ＋少なくとも追加1回の利上げが見込まれるとの見方 | 市場の焦点は「利下げ時期」ではなく「追加利上げの保険をどこまで掛けるか」に移行。2年・5年を中心に、ECBの反応関数が再価格化された。([Reuters](https://www.reuters.com/business/ecb-hike-rates-june-least-once-more-war-led-inflation-spike-2026-05-13/)) |
| **5月14日** | 2年 -6.0bp、5年 -6.3bp、10年 -6.1bp、30年 -4.9bp | 前日までの急上昇後のポジション調整 | 週中に一度反落。これはインフレ・ECBテーマの否定ではなく、短期的な利食い・リスク整理と見るのが自然。 |
| **5月15日** | 2年 +6.8bp、5年 +9.3bp、10年 +10.9bp、30年 +7.9bp | 原油高、ホルムズ海峡を巡る供給不安、米金利上昇を伴うグローバル債券安 | 週末に再びBund売り。米10年金利上昇のグローバル波及と、欧州自身のエネルギー依存・インフレ懸念が重なった。Reutersは、インフレ懸念と中央銀行の利上げ観測で世界的に債券利回りが上昇したと報じています。([Reuters](https://www.reuters.com/business/global-bonds-tumble-flaring-inflation-spooks-investors-2026-05-15/)) |

## 重要な読み方

ドイツ国債の上昇要因は、主に3つです。

第一に、**ユーロ圏インフレの再加速**です。Eurostatのフラッシュ推計では、ユーロ圏4月HICPは前年比 **3.0%** と、3月の2.6%から上昇しました。特にエネルギー項目は前年比 **10.9%** と大きく、Bund市場にとっては「エネルギー価格上昇がECBの追加引き締めを誘発する」という構図になりました。([European Commission](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap))

第二に、**ドイツ国内の川上インフレ**です。5月13日に発表されたドイツ卸売物価は前年比 **+6.3%**、3月の+4.1%、2月の+1.2%から急加速しました。Destatisは、イラン・中東情勢によるエネルギー製品・原材料価格上昇が主因だと説明しています。これは消費者物価への二次波及懸念を強め、Bundの中期ゾーンを売る材料になりました。([Statistisches Bundesamt](https://www.destatis.de/EN/Press/2026/05/PE26_164_61281.html))

第三に、**ECBの政策パス再価格化**です。Nagel総裁発言とReuters調査により、市場はECBの利上げリスクをより明確に織り込みました。これは2年Schatzと5年Boblに効きやすい材料です。実際、週次変化は5年が+15.1bpと最も大きく、政策金利パスと中期インフレ期待の交点であるBoblゾーンがよく売られました。([Reuters](https://www.reuters.com/business/ecbs-nagel-sees-rate-hikes-increasingly-likely-handelsblatt-2026-05-12/))

## 他国債との比較での位置づけ

ドイツ国債は、英国Giltのように政治・財政プレミアムが主因だったわけではなく、日本国債のように中銀正常化そのものが急速に織り込まれたわけでもありません。ドイツBundの動きはより純粋に、  
**原油高 → 欧州インフレ上振れ → ECB利上げ観測 → 2〜10年Bund売り**  
という経路で説明できます。

したがって、先週の主要債券市場の整理にドイツ国債を入れるなら、次の一文が適切です。

> **ドイツ国債は、ユーロ圏の安全資産として買われるよりも、エネルギー価格上昇とドイツ卸売物価の急加速、Nagel発言に伴うECB利上げ観測の再燃を受けて売られた。2年〜10年がそろって上昇し、英国Giltほどの財政プレミアムではなく、ECB政策パスと欧州インフレ期待の再価格化が主因だった。**

---

**Sources:**

- [Germany 10-Year Bond Historical Data - Investing.com](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data)
- [ECB's Nagel sees rate hikes increasingly likely: Handelsblatt | Reuters](https://www.reuters.com/business/ecbs-nagel-sees-rate-hikes-increasingly-likely-handelsblatt-2026-05-12/)
- [Wholesale prices in April 2026: +6.3% on April 2025  -  German Federal Statistical Office](https://www.destatis.de/EN/Press/2026/05/PE26_164_61281.html)
- [Euro area annual inflation up to 3.0% - Euro indicators - Eurostat](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap)

## Response:
2026/5/18 12:46:55

ユーロ圏全体として、ドイツBundだけでなく、フランス・イタリアなど周辺/準中核国債、ECB観測、インフレ・エネルギー要因、スプレッドの意味までまとめます。前回の週次文脈、つまり2026年5月11日〜15日を前提に整理します。

以下は、**2026年5月11日〜15日のユーロ圏債券市場**を、マクロイベントと対応させた再整理です。中心は **ドイツBund**ですが、ユーロ圏全体として見るには **イタリアBTP、フランスOAT、対Bundスプレッド**も合わせて見る必要があります。

## 1. 結論：ユーロ圏債券は「インフレ再燃＋ECB利上げ観測」で売られた

先週のユーロ圏債券市場は、**ドイツBundを中心に利回り上昇、イタリアBTPなど周辺国債も売られる展開**でした。背景は、米金利上昇の波及だけではなく、ユーロ圏自身の **エネルギー価格上昇 → インフレ再加速 → ECB利上げ観測の再燃**です。

Reutersは5月15日、ユーロ圏の利回りが全般に上昇し、イタリア10年債利回りは当日約+11bp、週次で約+16bp、ドイツ10年Bund利回りは当日約+7bp、週次で約+11bp上昇したと報じています。([Reuters](https://www.reuters.com/business/global-bonds-tumble-flaring-inflation-spooks-investors-2026-05-15/?utm_source=chatgpt.com))

## 2. マクロイベントとの対応

| 日付 | マクロイベント | ユーロ圏債券への影響 |
|---|---|---|
| 4月30日発表 | ユーロ圏4月HICPが前年比 **3.0%**、3月の2.6%から上昇。エネルギーが前年比 **10.9%**。 | 先週の金利上昇の土台。インフレ再加速が確認され、ECBの利上げリスクが意識された。([European Commission](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap?utm_source=chatgpt.com)) |
| 5月12日 | BundesbankのNagel総裁が、インフレ見通しが改善しなければECB利上げの可能性が高まると発言。 | 政策金利パスに敏感なドイツ2年・5年を中心に売り材料。ECBが「据え置き継続」ではなく、再利上げ方向に傾くリスクが織り込まれた。([Reuters](https://www.reuters.com/business/ecbs-nagel-sees-rate-hikes-increasingly-likely-handelsblatt-2026-05-12/?utm_source=chatgpt.com)) |
| 5月13日 | Reuters調査で、エコノミストの大半がECBの6月利上げを予想。70人中59人が6月に預金金利を25bp引き上げ **2.25%** と予想。 | ECB利上げ観測が市場テーマとして定着。Bundだけでなく、OAT、BTPなどユーロ圏全体の金利上昇に波及。([Reuters](https://www.reuters.com/business/ecb-hike-rates-june-least-once-more-war-led-inflation-spike-2026-05-13/?utm_source=chatgpt.com)) |
| 5月15日 | 原油高・中東情勢・米金利上昇を背景に世界的な債券売り。 | ユーロ圏利回りも上昇。特にイタリアBTPはBund以上に売られ、スプレッド面でもややリスクプレミアムが意識された。([Reuters](https://www.reuters.com/business/global-bonds-tumble-flaring-inflation-spooks-investors-2026-05-15/?utm_source=chatgpt.com)) |
| 5月18日以降 | グローバル債券売りが継続。ドイツBund、フランスOAT先物も下落。 | 先週の動きが一過性ではなく、翌週にも持ち越されたことを示唆。エネルギー起点のインフレ・ショックが継続テーマ化。([Reuters](https://www.reuters.com/world/europe/global-bond-rout-deepens-inflation-fears-mount-2026-05-18/?utm_source=chatgpt.com)) |

## 3. 国別・年限別の整理

**ドイツBund**は、ユーロ圏のベンチマークとして売られました。これは英国Giltのような政治・財政不安主導ではなく、より純粋に **ECB政策パスと欧州インフレ期待**を反映した動きです。特に2年〜5年はECB利上げ観測、10年はインフレ期待と米金利連動、30年は長期インフレ・供給プレミアムを反映しました。

**イタリアBTP**は、ドイツBund以上に弱含みました。5月15日の報道では、イタリア10年債利回りは当日約+11bp、週次で約+16bp上昇し、ドイツ10年Bundの週次上昇幅を上回りました。これは、インフレ・ECB利上げ局面では、周辺国債に対して財政・信用リスクプレミアムが乗りやすいことを示します。([Reuters](https://www.reuters.com/business/global-bonds-tumble-flaring-inflation-spooks-investors-2026-05-15/?utm_source=chatgpt.com))

**フランスOAT**は、BundとBTPの中間的な位置づけです。Reutersは5月18日のグローバル債券売りで、ドイツBund先物とフランスOAT先物が下落したと報じています。OATは準中核国債として、Bundほど安全資産性は強くなく、BTPほどリスクプレミアムも大きくないため、ECB観測とリスクセンチメントの両方を受けます。([Reuters](https://www.reuters.com/world/europe/global-bond-rout-deepens-inflation-fears-mount-2026-05-18/?utm_source=chatgpt.com))

## 4. ユーロ圏の金利上昇メカニズム

今回のユーロ圏債券売りは、次の経路で説明できます。

**原油・エネルギー価格上昇**  
→ **ユーロ圏HICPの上振れ、特にエネルギー項目の急加速**  
→ **ECBがインフレの二次波及を警戒**  
→ **6月利上げ観測が上昇**  
→ **ドイツSchatz/Bobl/Bundが売られる**  
→ **BTPやOATにも波及し、周辺国スプレッドにも圧力**

Eurostatの4月フラッシュ推計では、ユーロ圏インフレ率は前年比3.0%に上昇し、エネルギーは10.9%上昇しました。これはECB目標の2%を明確に上回るため、債券市場では「景気減速なら利下げ」ではなく、**インフレ再燃なら利上げ再開**という反応になりました。([European Commission](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap?utm_source=chatgpt.com))

## 5. 投資目線での含意

ユーロ圏債券は、米国債と比べると、**エネルギー価格への感応度が高い**点が重要です。欧州はエネルギー輸入依存が高く、原油・ガス価格上昇が交易条件悪化とインフレ上振れを同時に引き起こしやすい。そのため、通常なら景気悪化でBundが買われる局面でも、今回はインフレ・ショックが優勢になり、Bundが売られました。

ただし、BTP-Bundスプレッドが急拡大する全面的なソブリン・ストレスではなく、現時点では主に **レベル上昇＝金利上昇** が中心です。つまり、ユーロ圏債券市場の主テーマは、まだ「欧州債務危機型の信用不安」ではなく、**ECBの反応関数とインフレ・タームプレミアムの再価格化**です。

## 6. 要約

ユーロ圏については、次の一文でまとめられます。

**先週のユーロ圏債券市場は、ドイツBundを中心に、エネルギー価格上昇とHICP再加速、Nagel発言、6月ECB利上げ観測を受けて売られた。BTPはBund以上に弱く、周辺国リスクプレミアムもやや意識されたが、主因は財政危機ではなく、ECB政策パスとインフレ期待の上方再評価だった。**

---

**Sources:**

- [Global bonds battered as flaring inflation spooks investors](https://www.reuters.com/business/global-bonds-tumble-flaring-inflation-spooks-investors-2026-05-15/?utm_source=chatgpt.com)
- [Euro area annual inflation up to 3.0% - European Union](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30042026-ap?utm_source=chatgpt.com)

## Response:
2026/7/12 23:15:16

今回は「先週」を **2026年7月6日（月）〜10日（金）** として、米国債・ドイツ国債を中心とするユーロ圏債・英国債・日本国債を、主要指標と中銀材料に対応させて確認します。

> **検索：主要債券の先週データと金利**
>
> [Fed report cites 'stepped-up' inflation due to tariffs, Iran war, AI buildout](https://www.reuters.com/business/fed-report-cites-stepped-up-inflation-2026-07-10/)
> [July](https://en.wikipedia.org/wiki/July)
> [July](https://open.spotify.com/intl-ja/artist/5UcydON50lbHbBJNiTzyAI)
>
> **検索した金融市場データと関連ウェブサイト**
>
> 
>
> 2m 43s考えました

## 対象期間

「先週」は **2026年7月6日（月）〜10日（金）**です。週次変化は原則として **7月3日終値→7月10日終値**、米国債のみ7月3日が休場だったため **7月2日→7月10日**で比較します。

## 1. 主要債券の週間動向

| 市場 | 10年利回り・前週末 | 7月10日 | 週次変化 | 週間評価 |
|---|---:|---:|---:|---|
| 米国債 | 4.49% | 4.56% | **+7bp** | 債券安 |
| ドイツBund | 2.932% | 3.035% | **+10.2bp** | 債券安 |
| フランスOAT | 3.726% | 3.829% | **+10.3bp** | 債券安 |
| イタリアBTP | 3.720% | 3.804% | **+8.4bp** | 債券安 |
| 英国Gilt | 4.792% | 4.888% | **+9.7bp** | 債券安 |
| 日本国債JGB | 2.774% | 2.765% | **-0.9bp** | 週末比ほぼ横ばい。ただし週中は急落 |

米30年国債も **4.98%→5.06%、+8bp**となり、米国では長期・超長期ともに売られました。ドイツ、フランス、イタリア、英国も約8〜10bp上昇しており、先週の基本構図は、**原油高と金融引き締め観測を背景とするグローバルな債券安**でした。([ycharts.com](https://ycharts.com/indicators/10_year_treasury_rate?utm_source=chatgpt.com))

日本国債だけは週末比でほぼ横ばいですが、これは安定していたためではありません。10年JGBは7月9日に一時 **2.901%**まで上昇した後、7月10日に政府の年金資金を国内資産へ誘導する構想を受けて **約11.5bp低下**しました。したがって、実態は「週中に大幅な債券安、週末に急反発」という大きな往来です。([Investing.com](https://www.investing.com/rates-bonds/japan-10-year-bond-yield-historical-data?utm_source=chatgpt.com))

## 2. マクロイベントとの対応

### 7月6日：Fed高官発言で米金利が上昇

Fedのウォラー理事は、米経済の主要リスクが労働市場の悪化から**高インフレへ移った**との認識を示しました。6月の失業率が4.2%に低下する一方、インフレが目標を大きく上回っているため、利上げを再検討する余地があるとのメッセージです。

これを受けて、政策金利に敏感な米2年債利回りは7月6日に4.13%へ上昇し、10年は4.48%、30年は4.99%となりました。週初は、景気悪化を理由とする国債買いよりも、**Fedの高金利長期化・追加利上げリスク**が意識されました。([Reuters](https://www.reuters.com/business/waller-says-risks-us-tilted-towards-high-inflation-2026-07-06/?utm_source=chatgpt.com))

### 7月7〜8日：米・イラン情勢と原油急騰で世界的な債券売り

米国とイランの対立が再び激化し、停戦・合意期待が後退しました。原油価格が約5%上昇し、Brentは一時1バレル78ドル近辺まで上昇しました。

地政学リスクは通常、安全資産である国債の買い材料になり得ます。しかし今回は、

**中東情勢悪化  
→ 原油・輸送コスト上昇  
→ インフレ再加速  
→ 中央銀行が利下げできない、または追加利上げ  
→ 国債売り**

という経路が優勢でした。その結果、米国債だけでなく、ドイツBund、英国Gilt、日本国債まで同時に利回りが上昇しました。7月8日の10年利回りは、米国4.56%、ドイツ3.088%、英国4.963%、日本2.873%まで上昇しています。([Reuters](https://www.reuters.com/commentary/reuters-open-interest/global-markets-view-usa-2026-07-08/?utm_source=chatgpt.com))

### 7月8日：FOMC議事要旨がインフレ警戒を確認

6月16〜17日のFOMC議事要旨では、輸送費、航空運賃、石油化学、農業投入価格など、価格上昇が広がっていることへの警戒が確認されました。一部参加者は利上げを支持または検討していましたが、会合では政策金利を **3.50〜3.75%**に据え置きました。

議事要旨自体は直ちに利上げを示すものではありませんでしたが、債券市場には「次の政策変更が利下げではなく、利上げとなる可能性がある」と認識させました。特に米2年債は7月8日に4.21%、10年は4.56%、30年は5.06%まで上昇しました。([Reuters](https://www.reuters.com/business/fed-minutes-due-analysts-debate-whether-warsh-will-curtail-them-2026-07-08/?utm_source=chatgpt.com))

## 3. 国・地域別の解釈

### 米国債：Fed政策パスの上方修正

米10年は週間で+7bp、30年は+8bpでした。週初のウォラー発言、原油高、FOMC議事要旨、7月10日のFed金融政策報告が、一貫してインフレ警戒を示しました。

Fedの報告書は、関税、中東情勢、AI関連投資を背景にインフレ圧力が強まっていると指摘しています。一方で労働市場は安定しているため、Fedが景気支援のために利下げする必要性は低下しています。したがって先週の米国債売りは、主として**政策金利の高止まりと追加利上げ確率の上昇**によるものです。([Reuters](https://www.reuters.com/business/fed-report-cites-stepped-up-inflation-2026-07-10/?utm_source=chatgpt.com))

なお、米10年ブレークイーブン・インフレ率は週を通じて2.24〜2.25%程度で大きく上昇していません。したがって名目金利上昇の全部を長期インフレ期待で説明するより、**実質金利、Fed政策パス、期間プレミアムの上昇**も寄与したとみるのが適切です。([FRED](https://fred.stlouisfed.org/series/T10YIE))

### ユーロ圏：Bund主導の金利水準上昇、信用不安ではない

ドイツ10年Bundは **+10.2bp**、フランスOATは **+10.3bp**、イタリアBTPは **+8.4bp**でした。

重要なのは、国債間スプレッドがほとんど拡大していない点です。

- フランスOAT－Bund：およそ **79.4bp→79.4bp**
- イタリアBTP－Bund：およそ **78.8bp→76.9bp**

したがって、先週のユーロ圏債券安はフランスやイタリアの信用不安ではなく、**ドイツBundをアンカーとするユーロ圏金利全体の上昇**でした。原油高、米金利上昇、ECBの追加引き締めリスクが共通要因です。([Investing.com](https://www.investing.com/rates-bonds/germany-10-year-bond-yield-historical-data?utm_source=chatgpt.com))

ECBのパネッタ理事は7月7日、景気見通しは脆弱であり、エネルギーショックを過小評価すべきでも、2022年と同じように扱うべきでもないと述べました。これはECBが自動的に連続利上げへ向かうわけではない一方、原油高が続けば追加引き締めを排除できないことを意味します。

このためBundは、景気悪化を受けた安全資産買いより、**ECBの高金利長期化と欧州のエネルギー・インフレ感応度**を織り込んで売られました。([Reuters](https://www.reuters.com/business/ecbs-panetta-says-outlook-remains-fragile-2026-07-07/?utm_source=chatgpt.com))

### 英国債：原油高に政治・財政プレミアムが上乗せ

英国10年Giltは **4.79%から4.89%へ約10bp上昇**し、7月8日には一時4.98%まで上昇しました。

英国はエネルギー輸入への依存度が高く、原油・天然ガス価格上昇が消費者物価へ波及しやすいため、原油高はBoEの利上げ観測につながります。加えて、次期首相候補とみられるアンディ・バーナム氏の財政政策や財務相人事を巡る不透明感が、Giltのリスクプレミアムを高止まりさせました。([Investing.com](https://www.investing.com/rates-bonds/uk-10-year-bond-yield-historical-data?utm_source=chatgpt.com))

ただし、バーナム氏は既存の財政ルールを維持する方針を示しており、英国固有の財政不安が急激に悪化した週ではありません。先週の約10bp上昇は、主として**グローバル金利上昇とエネルギー起点の英国インフレ懸念**によるもので、政治要因は追加的な上乗せ要因です。([Reuters](https://www.reuters.com/world/uk/uks-burnham-vows-discipline-fiscal-rules-he-may-need-bend-2026-07-06/?utm_source=chatgpt.com))

### 日本国債：財政・インフレ懸念から売られた後、GPIF構想で急反発

日本の10年JGBは、7月3日の2.774%から7月9日に一時2.901%まで上昇しました。背景は次の三点です。

1. 中東情勢と原油高による輸入インフレ  
2. 円安によるエネルギー・原材料コスト上昇  
3. 政府の大型支出計画と、金融政策への政治的介入懸念

特に長期・超長期ゾーンが弱く、7月9日には20年3.890%、30年4.030%、40年4.055%まで上昇しました。10年－2年スプレッドも143bp程度まで拡大し、単純なBOJ利上げ観測ではなく、**長期インフレ・財政リスクを織り込むベア・スティープニング**が進みました。([Reuters](https://www.reuters.com/world/asia-pacific/japan-benchmark-bond-yield-hits-30-year-high-inflation-fiscal-health-concerns-2026-07-09/))

しかし7月10日、財務相がGPIFなどの公的年金に国内資産への投資を大幅に増やすよう促す方針を示すと、国内債券への大規模な需要が発生するとの期待から、10年JGB利回りは **11.5bp低下して2.760%**となりました。

その結果、週末比ではほぼ横ばいになりましたが、これはインフレ・財政懸念が解消したためではなく、**潜在的な公的需要によって売りが巻き戻された**ものです。([Reuters](https://www.reuters.com/world/asia-pacific/japan-will-not-convey-advance-preference-boj-policy-minister-says-2026-07-10/))

## 4. 先週の全体像

先週の債券市場は、通常の「地政学リスク上昇＝安全資産買い」ではなく、

> **地政学リスク上昇  
> → 原油高  
> → インフレ懸念  
> → G4中央銀行の高金利長期化  
> → 債券安・利回り上昇**

という構造でした。

国別には次のように整理できます。

| 市場 | 中心的なドライバー |
|---|---|
| 米国債 | Fed利上げ・高金利長期化の再価格化 |
| ドイツ・ユーロ圏債 | 原油高、ECB政策パス、米金利上昇 |
| 英国債 | エネルギー・インフレ＋政治・財政プレミアム |
| 日本国債 | 財政・円安・輸入インフレ懸念。ただし週末に公的需要期待で急反発 |

したがって、先週は日本を除いて主要10年債利回りが概ね **8〜10bp上昇**しました。日本も週中の実態は同方向でしたが、金曜日のGPIF関連報道によって週次変化が相殺されています。

今週は米国の6月CPI、Fed議長の議会証言、原油・ホルムズ海峡情勢が、再び主要国債の方向を左右する中心材料になります。([Reuters](https://www.reuters.com/markets/europe/wall-st-week-ahead-investors-grapple-with-packed-week-earnings-cpi-iran-2026-07-10/?utm_source=chatgpt.com))

毎週末に同じ形式で、主要国債の利回り変化とマクロ要因を整理する定期レポートも設定できます。設定しますか？

- [Reuters](https://www.reuters.com/business/fed-minutes-due-analysts-debate-whether-warsh-will-curtail-them-2026-07-08/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/business/waller-says-risks-us-tilted-towards-high-inflation-2026-07-06/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/asia-pacific/japan-benchmark-bond-yield-hits-30-year-high-inflation-fiscal-health-concerns-2026-07-09/)
- [Reuters](https://www.reuters.com/world/asia-pacific/japan-will-not-convey-advance-preference-boj-policy-minister-says-2026-07-10/)
- [Reuters](https://www.reuters.com/business/ecbs-panetta-says-outlook-remains-fragile-2026-07-07/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/uk/britains-bond-market-may-limit-what-burnham-can-do-pm-2026-07-07/?utm_source=chatgpt.com)

---

**Sources:**

- [10 Year Treasury Rate - Real-Time & Historical Yield Trends](https://ycharts.com/indicators/10_year_treasury_rate?utm_source=chatgpt.com)
- [Japan 10-Year Bond Yield Historical Data](https://www.investing.com/rates-bonds/japan-10-year-bond-yield-historical-data?utm_source=chatgpt.com)
- [Waller says risks in US tilted towards high inflation](https://www.reuters.com/business/waller-says-risks-us-tilted-towards-high-inflation-2026-07-06/?utm_source=chatgpt.com)
- [10-Year Breakeven Inflation Rate (T10YIE) | FRED | St. Louis Fed](https://fred.stlouisfed.org/series/T10YIE)

## Response:
2026/7/12 23:21:13

前回内容を、各国の公的データと別系統の主要報道で再検証します。数値やイベント対応に差異があれば修正し、監査済みの内容だけをMarkdownにまとめます。

> **検索して公式データと生産的イベントを検証**
>
> [Speech by Governor Waller on monetary policy](https://www.federalreserve.gov/newsevents/speech/waller20260706a.htm)
> [Daily yields of current Federal securities](https://www.bundesbank.de/en/statistics/money-and-capital-markets/interest-rates-and-yields/daily-yields-of-current-federal-securities-772220)
> [The ECB Blog - European Union](https://www.ecb.europa.eu/press/blog/html/index.en.html)
> [July](https://en.wikipedia.org/wiki/July)
> [july - Turkish English Dictionary](https://tureng.com/en/turkish-english/july)
> [Congressman Jimmy Panetta | Representing the 19th District ...](https://panetta.house.gov/)
> [「daily」の意味・使い方・表現・読み方](https://eow.alc.co.jp/search?q=daily)
> [July Luggage](https://july.com/us/)
> [デイリースポーツonline](https://www.daily.co.jp/)
> [Daily Treasury Rate Archives](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rate-archives)
> [July in Traditional Chinese - Cambridge Dictionary](https://dictionary.cambridge.org/dictionary/english-chinese-traditional/july)
> [DAILY Definition & Meaning](https://www.merriam-webster.com/dictionary/daily)
> [Dailymotion](https://www.dailymotion.com/jp)
> [Financial markets | Bundesbank publications](https://publikationen.bundesbank.de/publikationen-en/reports-studies/monthly-reports/monthly-report-may-2026-996644?article=financial-markets-996606)
> [Daily株式会社](https://daily-daily.co.jp/)
> [デイリーポータルZ](https://dailyportalz.jp/)
>
> **検索して複数のウェブサイトと公式データを確認**
>
> 
>
> **試行によるAPIリクエスト**
>
>
> **試行によるAPIリクエスト**
>
> 
>
> **Searching for Germany 10-year Bund yield data**
>
> [Treasury Yields Rise Ahead of Inflation Data, Warsh Hearings](https://www.wsj.com/finance/investing/jgbs-edge-higher-tracking-gains-in-u-s-treasurys-2cb325e7)
> [Treasury yields jump on fresh inflation fears as oil prices spike](https://www.marketwatch.com/livecoverage/stock-market-today-dow-s-p-500-nasdaq-oil-prices-us-iran-exchange-strikes/card/treasury-yields-jump-on-fresh-inflation-fears-as-oil-prices-spike-XSgdt2fPF9NGA47KYVEO)
> [Crude oil prices rise again while UK stock market falls, dragged down by AstraZeneca - as it happened](https://www.theguardian.com/business/live/2026/jul/09/stock-markets-oil-uk-house-prices-business-news-updates)
> [Germany 10-Year Bond Yield - Quote - Chart - Historical Data](https://tradingeconomics.com/germany/government-bond-yield)
> [Onmobile Global Ltd. Share Price Today: Live updates](https://zerodha.com/markets/stocks/NSE/ONMOBILE/)
> [Daily yields of current Federal securities](https://www.bundesbank.de/en/statistics/money-and-capital-markets/interest-rates-and-yields/daily-yields-of-current-federal-securities-772220)
> [Interest Rates: Long-Term Government Bond Yields: 10-Year ...](https://fred.stlouisfed.org/series/IRLTLT01DEQ156N)
> [Federal Bonds](https://www.deutsche-finanzagentur.de/en/federal-securities/types-of-federal-securities/federal-bonds)
> [Germany 10-Year Bond Yield](https://www.investing.com/rates-bonds/germany-10-year-bond-yield)
> [Germany - 10 year Government Bond - Webstat](https://webstat.banque-france.fr/en/catalog/fm/FM.M.DE.EUR.FR2.BB.DE10YT_RR.YLD)
> [Germany - 10-Year Government Bond Yields (1956-2026)](https://www.macrotrends.net/3385/germany-10-year-government-bond-yields)
> [Germany 10 Years vs Germany 2 Years Bond Spread](https://www.worldgovernmentbonds.com/spread/germany-10-years-vs-germany-2-years/)
> [Archetypal analysis of European 10-year government bond yields with multidimensional scaling of two-mode three-way asymmetric dissimilarities](https://arxiv.org/abs/2606.15876)
>
> **検索してドイツ10年債利回りデータを収集**
>
> 
>
> 7m 9s考えました

再監査の結果、**分析の中心的な方向性は妥当**でしたが、数値定義と因果関係を一部修正しました。

主な修正点は次のとおりです。

- ドイツ10年国債は、Bundesbankの「現行10年連邦債」系列では週間約 **+14bp**、一般的なジェネリック・ベンチマークでは約 **+10bp**です。銘柄更新、観測時刻、系列定義の違いによるため、両方を明記しました。([バンク・ドイツ](https://www.bundesbank.de/en/statistics/money-and-capital-markets/interest-rates-and-yields/daily-yields-of-current-federal-securities-772220))
- 米10年国債は米財務省の丸め済み公式値では **+7bp**ですが、市場終値ベースでは約 **+9bp**です。いずれも方向性は同じです。([U.S. Department of the Treasury](https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics?utm_source=chatgpt.com))
- 週間の主要材料は7月7〜8日の原油急騰、米イラン情勢、FOMC議事要旨であり、7月6日のFed高官発言を単独の主要因とはしていません。([ガーディアン](https://www.theguardian.com/business/live/2026/jul/08/oil-prices-rise-fresh-us-strikes-iran-return-sanctions-tehran-federal-reserve-minutes-live-updates?utm_source=chatgpt.com))
- 日本国債は週末比でほぼ横ばいでしたが、週中に10年利回りが約2.90%まで上昇した後、7月10日に約2.76%へ急低下しました。公的年金関連材料は「既に配分変更が実施された」のではなく、政府方針への市場反応として表現を修正しています。([Reuters](https://www.reuters.com/world/asia-pacific/japan-benchmark-bond-yield-hits-30-year-high-inflation-fiscal-health-concerns-2026-07-09/?utm_source=chatgpt.com))
- 英国・ユーロ圏についても、固有の財政危機より、原油高と世界的な金利水準上昇が中心だったとの整理を維持しています。([Reuters](https://www.reuters.com/world/uk/britains-bond-market-may-limit-what-burnham-can-do-pm-2026-07-07/?utm_source=chatgpt.com))

監査結果、数値比較、日付別イベント、国・地域別評価、出典一覧を収録したMarkdownです。

[主要債券の週間レビュー（2026年7月6日〜10日）をダウンロード](sandbox:/mnt/data/major_bonds_weekly_review_2026-07-06_to_2026-07-10_ja.md)

- [The Wall Street Journal](https://www.wsj.com/finance/investing/jgbs-edge-higher-tracking-gains-in-u-s-treasurys-2cb325e7?utm_source=chatgpt.com)
- [ガーディアン](https://www.theguardian.com/business/live/2026/jul/08/oil-prices-rise-fresh-us-strikes-iran-return-sanctions-tehran-federal-reserve-minutes-live-updates?utm_source=chatgpt.com)
- [The Wall Street Journal](https://www.wsj.com/finance/investing/jgbs-mixed-ahead-of-30-year-auction-2661524b?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/uk/britains-bond-market-may-limit-what-burnham-can-do-pm-2026-07-07/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/asia-pacific/japan-benchmark-bond-yield-hits-30-year-high-inflation-fiscal-health-concerns-2026-07-09/?utm_source=chatgpt.com)

---

**Sources:**

- [
Daily yields of current Federal securities | Deutsche Bundesbank
](https://www.bundesbank.de/en/statistics/money-and-capital-markets/interest-rates-and-yields/daily-yields-of-current-federal-securities-772220)
- [Interest Rate Statistics | U.S. Department of the Treasury](https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics?utm_source=chatgpt.com)
- [Oil prices jump over 5% after Trump suggests ceasefire with Iran has ended following fresh US strikes - as it happened](https://www.theguardian.com/business/live/2026/jul/08/oil-prices-rise-fresh-us-strikes-iran-return-sanctions-tehran-federal-reserve-minutes-live-updates?utm_source=chatgpt.com)
- [Japan benchmark bond yield extends rise after hitting 30-year high](https://www.reuters.com/world/asia-pacific/japan-benchmark-bond-yield-hits-30-year-high-inflation-fiscal-health-concerns-2026-07-09/?utm_source=chatgpt.com)

## Response:
2026/7/12 23:47:14

前回の監査指摘を本文へ完全に織り込み、重複していた「監査結果」と「本編」を統合して、数値定義・因果関係・留意点が一貫したレポートに更新します。

監査結果を独立した前置きではなく、データ表・イベント解説・国別評価へ直接反映しています。特にBundの系列差、米国債の起点日、JGBの週中ボラティリティを本文上で明確化します。

> **ファイルの内容確認と編集**
>
>
> **確認してファイルを編集した**
>
> 
>
> **レポート更新の準備**
>
> 監査結果を反映させたレポートの修正を考えています。元のレポートの構造を改善し、必要に応じてファイル名を変更し、誤りを確認します。
>
> **準備したレポート更新**
>
> 
>
> **Inspecting and updating report content**
>
>
> **Inspecting and updating report content**
>
> 
>
> 33s考えました

監査結果を本文へ統合し、レポートを更新しました。

主な反映内容は、Bundの公式系列と市場ベンチマークの併記、米国債の比較起点日の明確化、7月6日の因果関係の修正、JGBの週中急落と反発の明示、GPIF関連材料の表現修正です。監査前後の変更点も末尾の表に整理しています。

[主要債券の週間レビュー・監査反映版をダウンロード](sandbox:/mnt/data/major_bonds_weekly_review_2026-07-06_to_2026-07-10_ja_audited.md)



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)