# 週次 Sector Gamma 見通し — 2026年8月第1週

**更新日時:** 2026-08-02 JST  
**価格基準:** 2026-07-31米国市場引け  
**オプション・スナップショット:** 2026-08-02  
**先週実績:** 2026-07-24終値〜7月31日終値  
**見通し対象:** 2026-08-03〜8月7日  
**対象:** S&P 500 11セクターETF 60%＋IEF 40%

> 本レポートは研究用モデルの出力であり、投資助言ではない。Signed GEXはcallを正、putを負とする簡易プロキシで、実際のディーラー在庫を直接示さない。IVレンジは7日・1標準偏差であり、実現レンジを保証しない。ニュース・経済統計は事実、配分・シナリオはモデル推論として分けて記載する。

## 1. 結論

先週の12資産ポートフォリオは、**前回戦術配分が+0.224%**、株式60%・IEF40%のベースラインが**+0.307%**で、**超過収益は-0.083%（-8.31bp）**だった。XLF OverweightとXLK Underweightは機能した一方、XLY Underweight、XLU・XLB Overweight、XLC Underweightが逆風となった。

来週は7月雇用統計を最終日に控え、週前半のISM、JOLTS、ADP、サービスPMI、単位労働コストが金利と景気認識を段階的に更新する。前週FOMCのタカ派的な票割れと、GDP減速・PCE高止まりの組み合わせを踏まえると、強い雇用は長期金利上昇、弱すぎる雇用は景気懸念につながりやすい。したがって、単純な株高・債券高の方向予測より、Gamma FlipとWallを使った条件付き運営を優先する。

モデルの更新配分は次の通り。

- 資産バケットは**株式60.00%・IEF40.00%を維持**。株式とIEFの相対スコアから算出した株式増額は+0.177ptにとどまり、0.50ptのノートレード帯内だった。
- セクターでは**XLREのみOverweight**。**XLK、XLC、XLYはUnderweight**、残る7セクターはNeutral。
- 前回比ではXLF -1.102pt、XLU -0.719pt、XLB -0.611ptを減らし、XLRE +0.996ptを新規上乗せ。XLC +0.493pt、XLY +0.439pt、XLK +0.365ptはUnderweight幅の縮小であり、判断自体は弱気のまま。
- 片道売買回転率は**2.510%**。IEFは40.00%で据え置く。

## 2. 先週の振り返り

### 2.1 ポートフォリオ実績

| 指標 | 7/24終値〜7/31終値 |
|---|---:|
| 前回戦術配分 | **+0.2243%** |
| 60/40ベースライン | **+0.3074%** |
| 超過収益 | **-0.0831%（-8.31bp）** |

配当調整済みETF終値で計算した。取引コスト、税、スリッページは含まない。12資産すべてについて、前回スナップショット、評価期間、ウェイト、実現収益率、寄与度をNotebookから再現可能にした。

### 2.2 Active寄与度

| ETF | 前回判断 | 実現騰落率 | Active Weight | Active寄与 |
|---|---|---:|---:|---:|
| XLF | Overweight | +1.119% | +1.102% | **+1.23bp** |
| XLK | Underweight | -0.301% | -0.722% | **+0.22bp** |
| XLP | Underweight | +1.094% | -0.217% | **-0.24bp** |
| XLB | Overweight | -1.619% | +0.611% | **-0.99bp** |
| XLC | Underweight | +1.825% | -0.722% | **-1.32bp** |
| XLU | Overweight | -4.191% | +0.670% | **-2.81bp** |
| XLY | Underweight | +6.105% | -0.722% | **-4.41bp** |

Neutral資産ではXLI -1.544%、XLRE -1.915%、XLE -0.117%、XLV -0.012%、IEF -0.086%だった。

### 2.3 ニュースと結果の対応

#### 確認できる事実

- [FRBは7月29日に政策金利を3.50–3.75%で据え置いた](https://www.federalreserve.gov/newsevents/pressreleases/monetary20260729a.htm)。票決は9対3で、3名は25bpの利上げを支持した。声明はエネルギー価格を通じたインフレ上昇も指摘した。
- [BEAの4–6月期実質GDP速報値は年率+1.5%](https://apnews.com/article/caf3b24d92688568f9c4f95725c87e55)で、1–3月期の+2.1%から減速した。一方、個人消費は+3.2%だった。
- [6月PCEでは名目支出が前月比+0.3%、実質支出が+0.4%](https://www.bea.gov/news/2026/personal-income-and-outlays-june-2026)。PCE価格指数は前年比+3.7%、食品・エネルギー除き+3.3%だった。
- [4–6月期雇用コスト指数は前期比+0.9%、前年比+3.4%](https://www.bls.gov/news.release/eci.nr0.htm)。賃金・給与は前年比+3.2%だった。
- [Fidelityの7月31日付Weekly Market Update](https://www.fidelity.com/learning-center/trading-investing/weekly-market-update)では、S&P 500は週間+0.2%。週初はAI・半導体から資金が流出し、水曜のFOMC後に金利上昇と株安が加速した。木曜はMicrosoftの好決算、金曜はAmazonが反発を支えた一方、MetaはAI投資回収への懸念から約9%下落した。同レポートはTechnology Services、Retail Trade、Consumer Servicesを上位、Communications、Producer Manufacturing、Electronic Technologyを下位としている。
- 同レポートではFOMC後に30年金利が5.21%、10年金利が約4.68%へ上昇した。これはIEF、XLRE、XLUの短期逆風である一方、XLFの利鞘には部分的な支援材料となった。

#### モデル判断の検証

- **XLF Overweightは有効。** 据え置きでも利上げ支持が3票あったため、金利低下を一方向に織り込む局面ではなかった。正のGEXとFlip上の価格構造も相対安定に寄与した。
- **XLK Underweightは小幅に有効。** Microsoftの強さはあったが、Appleの弱い見通しと金利上昇が相殺し、ETFは小幅安。負のGEX、Flip下という警戒は維持された。
- **XLY Underweightは最大の失敗。** Amazonの利益・AWS成長が市場予想を上回り、個人消費の底堅さも重なった。負のGamma構造は方向を決めるものではなく、好決算時には上昇を増幅することが再確認された。
- **XLU Overweightは失敗。** タカ派的な票割れ、PCE・雇用コスト、長期金利上昇が債券代替セクターの評価を圧迫した。オプションの正の構造を金利レジームが上書きした。
- **XLB Overweightは失敗。** GDP減速とコスト不安に対し、相対スコアの優位性が弱かった。今回のモデルは上乗せを全て解消する。
- **XLC Underweightはマイナス。** 大型プラットフォームとAI関連のリスク選好回復に対し、負のGammaは上方向の値幅も増幅した。
- **IEFはほぼ横ばい。** 株式と債券を同時に大きく傾けなかったことで全体の変動を抑えたが、インフレ高止まり下では40%を超えて増やす根拠も弱かった。

## 3. 来週のマクロとイベント

### 3.1 確認できる日程

[Kiplingerの週間経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)、[BLS公式日程](https://www.bls.gov/schedule/2026/home.htm)、[BEA公式日程](https://www.bea.gov/news/schedule)による主要イベントは以下の通り。

| 日付 | 経済指標 | 主な決算・確認対象 | セクター接続 |
|---|---|---|---|
| 8/3 月 | 製造業PMI確報、ISM製造業、建設支出 | Palantir、Vertex、Vornado、SBA Communications、Diamondback、ONEOK、Williams、onsemi | XLK、XLI、XLB、XLRE、XLE |
| 8/4 火 | 貿易収支、JOLTS、製造業受注 | Caterpillar、AMD、Pfizer、Merck、Duke、DuPont、NRG、Rockwell | XLI、XLK、XLV、XLU、XLB |
| 8/5 水 | ADP雇用、サービスPMI、ISMサービス | Eli Lilly、CVS、Disney、Uber、Phillips 66、Kraft Heinz、REIT・公益各社 | XLV、XLC、XLY、XLE、XLP、XLRE、XLU |
| 8/6 木 | 失業保険申請、生産性、単位労働コスト、卸売在庫 | ConocoPhillips、Cheniere、Constellation Energy、Fiserv、Fox、Howmet | XLE、XLU、XLF、XLC、XLI |
| 8/7 金 | **7月雇用統計** | 小規模中心 | 全資産、特にIEF・XLRE・XLU・XLY・XLF |

決算日程は[週間決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)で再確認した。個別企業の発表時刻は企業IRを優先する。

### 3.2 マクロ解釈

前週の組み合わせは「GDPは減速、消費は堅調、インフレと賃金はなお高い、FOMC内には利上げ支持が存在」である。来週は雇用統計までに発表される労働需要・サービス活動・単位労働コストが、この組み合わせをどちらへ崩すかが焦点となる。

- **雇用が緩やかに減速し賃金圧力も鈍化:** IEF、XLRE、XLUに追い風。景気後退懸念が強くなければXLK・XLCにもプラス。
- **雇用・賃金が強い:** XLFの利鞘には支援だが、IEF、XLRE、XLU、長期成長株には金利上昇が逆風。XLYは消費の強さと割引率上昇が競合する。
- **雇用が急減速:** 初動はIEF高・金利感応株高でも、信用・消費懸念が強まればXLF、XLY、XLI、XLBが悪化する。
- **ISMと企業ガイダンスが上振れ:** XLI・XLBのNeutral判断を上方修正する材料。ただし負のGEX下のXLIは180のWallを明確に超える必要がある。

### 3.3 マーケットレポートを踏まえたポジション根拠

以下はモデルスコアをニュースで上書きするものではなく、市場レポートの観測を「なぜその配分を持つか」「どの条件で変更するか」へ接続したクロスチェックである。

#### 市場レポートから得られる共通認識

- **株式の強弱は指数より内部格差が大きい。** [Fidelity Weekly Market Update](https://www.fidelity.com/learning-center/trading-investing/weekly-market-update)では、Microsoft・Amazonが指数を支えた一方、Meta、半導体・電子テクノロジー、Producer Manufacturingは弱かった。したがって、AI関連を一括で強気・弱気とせず、XLK・XLC・XLYを個別のFlipとWallで管理する。
- **AI投資は売上成長だけでなく資本効率が焦点。** [LPLの7月27日Weekly Market Commentary](https://www.lpl.com/research/weekly-market-commentary/can-hyperscalers-earn-their-ai-ambitions.html)は、AWS、Azure、Google Cloudの投資をROIC、売上CAGR、設備投資の組み合わせで評価している。大型テック好決算だけでXLK・XLCのUnderweightを解除せず、収益化と価格構造の両方を確認する根拠となる。
- **長期金利には上昇圧力が残る。** [Kiplingerの金利見通し](https://www.kiplinger.com/economic-forecasts/interest-rates)は、7月に10年金利が4.5%から4.7%へ上昇し、原油高とインフレ懸念が続けば上昇圧力が残るとする。一方、[LPLのFixed Income Outlook](https://www.lpl.com/research/weekly-market-commentary/keep-calm-and-clip-coupons.html)はDurationをベンチマーク比Neutralとし、債券リターンは価格上昇よりクーポン収入中心とみる。両者を合わせると、IEFは40%を維持するが増額しない判断が妥当となる。
- **原油は供給リスクと需要抑制が競合。** [LPLの原油分析](https://www.lpl.com/research/blog/low-chinese-demand-for-foreign-oil-keeping-prices-low.html)は、中国のタンカー経由輸入が2025年平均を約40%下回ったことを指摘し、戦争終結後の価格は供給正常化だけでなく中国需要に左右されるとする。XLEは正のGEXでも60のCall Wall直下で追わない根拠となる。

#### 12資産のポジション・クロスチェック

| 資産 | 先週の市場レポートとの対応 | 今週の材料 | オプション構造との接続 | ポジション根拠 |
|---|---|---|---|---|
| **XLRE** | 金利上昇でREITは逆風 | 雇用・単位労働コスト、Vornado・SBA | 正のGEX、Flip 42.72より上 | **OW。ただしマクロ強気ではなく需給反発狙い。43.86割れで上乗せ解消** |
| **XLE** | 原油は停戦期待と再緊張で乱高下 | 中東情勢、中国需要、COP・LNG決算 | 正のGEX、60 Call Wall直下 | **Neutral。供給リスクを評価するが需要抑制とWallで上値を限定** |
| **XLF** | ヘルスケアとともに相対強、金利上昇 | JOLTS、雇用、Fiserv、信用コスト | 正のGEX、Flip 56.03上、56 Wall超 | **Neutral。前週OWの利益を確定し、追加の金利上昇と信用悪化の両方に備える** |
| **XLV** | ローテーション局面で相対強 | PFE、MRK、LLY、CVS | 正のGEX、165 Call Wall近接 | **Neutral。業績分散とWallを考慮し、165定着まで追わない** |
| **XLB** | Producer Manufacturingが下位 | ISM、建設支出、受注、DuPont | 正のGEXだがスコア優位は小さい | **Neutral。前週OWを解消し、48.50維持とISM上振れ待ち** |
| **XLP** | 成長株上昇の裏で防御需要は限定 | 雇用、食品決算、投入コスト | 負のGEX、85 Wall、Charm集中 | **Neutral。防御性だけでOWせず、85からの離脱方向を確認** |
| **XLI** | Producer Manufacturingが下位 | ISM、CAT、Rockwell、Howmet | 負のGEX、180 Wall、Flip 210.24 | **Neutralだが基準比小幅減。180突破まで循環回復を織り込まない** |
| **XLU** | 金利上昇が債券代替セクターを圧迫 | 公益決算、労働コスト、雇用 | 負のGEX、45.08 Flip下 | **Neutralへ格下げ。45.08回復と金利低下が同時に必要** |
| **XLC** | Communicationsが下位、Metaは約9%安 | Disney、Fox、広告・配信需要 | 負のGEX、Flip 128.60下 | **UW。AI投資回収と広告の不確実性を反映。ただし前回より0.493pt買い戻す** |
| **XLY** | AmazonとRetail/Consumer Servicesが上位 | 雇用、Uber、外食・旅行需要 | 負のGEX、120 Wall、Flip 139.31下 | **UW。先週の強さを反映して幅を縮小するが、金利とFlip下のためNeutralには戻さない** |
| **XLK** | Microsoftは急騰、一方Electronic Technologyは下位 | AMD、PLTR、onsemi、AI投資回収 | 負のGEX、175 Put Wall、Flip 181.39下 | **UW。大型テック内の分散とROIC不確実性を重視。181.39回復まで解除しない** |
| **IEF** | 10年約4.68%、30年5.21%へ金利上昇 | JOLTS、ADP、単位労働コスト、雇用統計 | 負のGEX、Spot 92.95、Flip 93.35下、Put 93 | **40% Neutral。Durationの上値は追わず、クーポンと株式ヘッジ機能を維持** |

このクロスチェックで最も重要なのは、XLRE OverweightとIEF Neutralが矛盾して見えても役割が異なる点である。XLREはポートフォリオ全体で+0.996ptの小さな相対ポジションで、正のGEXとFlip上を使った短期反発を狙う。一方IEFは40%の基幹バケットであり、金利見通しの確信度が低い状態でDurationを増やさず、株式急落時のヘッジとクーポン収入を維持する。

## 4. リバランス案

### 4.1 新しい目標配分

| 資産 | 60/40基準 | 前回目標 | 新目標 | 売買 | 調整後スコア | 確信度 | 判断 |
|---|---:|---:|---:|---:|---:|---:|---|
| XLK | 19.720% | 18.998% | **19.363%** | +0.365pt | -0.386 | 0.911 | Underweight |
| XLF | 7.552% | 8.655% | **7.552%** | -1.102pt | +0.231 | 0.719 | Neutral |
| XLV | 5.694% | 5.694% | **5.694%** | 0.000pt | +0.214 | 0.534 | Neutral |
| XLY | 5.934% | 5.212% | **5.651%** | +0.439pt | -0.361 | 0.665 | Underweight |
| XLC | 6.174% | 5.452% | **5.945%** | +0.493pt | -0.306 | 0.500 | Underweight |
| XLI | 5.395% | 5.395% | **5.318%** | -0.077pt | -0.194 | 0.676 | Neutral |
| XLP | 3.177% | 2.960% | **3.177%** | +0.217pt | -0.128 | 0.602 | Neutral |
| XLE | 2.398% | 2.398% | **2.398%** | 0.000pt | +0.297 | 0.733 | Neutral |
| XLU | 1.499% | 2.168% | **1.449%** | -0.719pt | -0.286 | 0.666 | Neutral |
| XLB | 1.259% | 1.870% | **1.259%** | -0.611pt | +0.059 | 0.648 | Neutral |
| XLRE | 1.199% | 1.199% | **2.195%** | +0.996pt | +0.347 | 0.692 | Overweight |
| IEF | 40.000% | 40.000% | **40.000%** | 0.000pt | -0.222 | 0.500 | Neutral |
| **合計** | **100.000%** | **100.000%** | **100.000%** | **0.000pt** |  |  |  |

株式内Gross Activeは3.319%、ポートフォリオ全体の片道回転率は2.510%。XLF、XLE、XLVはスコアが正でも、Wall近接などのHard RuleによりOverweightを許可しない。XLBは正のスコアが小さく相対優位が不十分で、Neutralに戻す。

### 4.2 執行方針

1. 次の流動性が高い通常取引時間に、XLF、XLU、XLBを先に縮小する。
2. 売却分でXLREを2.195%まで増やし、XLC、XLY、XLKのUnderweight幅を縮め、XLPをベースラインへ戻す。
3. IEFは40.00%を維持し、現金バッファで配分差を吸収しない。
4. 寄り付き直後の成行を避け、指値または時間分散執行を使う。週初の価格ギャップがIV上限・下限を越えた場合は、下記の水準確認後に執行する。

## 5. セクター別見通し

### XLRE 不動産 — Overweight 2.195%

**マクロ:** 金利低下への感応度が高く、弱すぎない雇用減速が最良。単位労働コストや雇用統計が強く長期金利が上昇する場合は逆風。

**ボトムアップ:** Vornado、SBA Communicationsに加え、REIT決算でFFO、入居率、更新賃料、借換金利、データセンター・通信塔需要を確認する。

**オプション:** Spot 45.07、Net GEX +1.62m、Flip 42.72、Call/Put Wall 45、IVレンジ43.86–46.28。正のGEXかつFlip上で12資産中最高の調整後スコア。

**判断:** 新規Overweight。ただし45近辺にポジションが集中し、Charm集中も相対的に高い。43.86割れで上乗せ解消、42.72割れでUnderweight候補。46.28上抜け後は追随より利食い管理を優先する。

### XLE エネルギー — Neutral 2.398%

**マクロ:** 原油・天然ガスと地政学が主因。強い雇用は需要期待を支える一方、ドル・金利上昇は商品価格の上値を抑える。

**ボトムアップ:** Diamondback、ONEOK、Williams、Phillips 66、ConocoPhillips、Cheniereから生産量、実現価格、精製マージン、LNG、設備投資、還元を確認する。

**オプション:** Spot 59.55、GEX +46.91m、Flip 57.73、Call Wall 60、Put Wall 55、レンジ57.19–61.91。

**判断:** 構造は強いが60のCall Wall直下でOverweight禁止。60を出来高を伴って定着すれば上方候補、57.73割れでNeutral維持の根拠が弱まる。

### XLF 金融 — Neutral 7.552%

**マクロ:** 高金利は利鞘にプラスだが、急な金利上昇と景気減速の併存は信用コスト・債券評価にマイナス。JOLTSと雇用統計で信用需要を測る。

**ボトムアップ:** Fiservなど決済・金融インフラ、銀行の貸出・預金動向、クレジットカード延滞、資本市場収益を確認する。

**オプション:** Spot 56.94、GEX +65.50m、Flip 56.03、Call Wall 56、Put Wall 54、レンジ55.41–58.47。

**判断:** 前週OWの利益を確定しベースラインへ。Flip上・正のGEXは下支えだがWallを既に上回り追随余地が限定的。55.41割れで警戒、58.47接近は利益管理。

### XLV ヘルスケア — Neutral 5.694%

**マクロ:** 景気減速耐性はあるが、金利・政策・医療費インフレが企業間格差を広げる。

**ボトムアップ:** Pfizer、Merck、Eli Lilly、CVSで新薬・パイプライン、薬価、利用率、保険採算、ガイダンスを確認する。

**オプション:** Spot 162.55、GEX +56.15m、Flip 145.91、Call Wall 165、Put Wall 155、レンジ153.44–171.66。正の構造だが確信度は0.534。

**判断:** 165近接のHard RuleによりNeutral。165を決算後も維持できればOverweight候補、155割れではディフェンシブ性だけを理由に保有を増やさない。

### XLB 素材 — Neutral 1.259%

**マクロ:** ISM、建設支出、製造業受注、ドル、エネルギーコストが数量とマージンを左右する。

**ボトムアップ:** DuPont等の数量・価格・原料スプレッド、建設・自動車・電子材料向け需要を見る。

**オプション:** Spot 50.43、GEX +12.77m、Flip 48.50、Call Wall 55、Put Wall 47.5、レンジ46.82–54.04。

**判断:** 絶対スコアは小幅プラスでも相対優位が不足。前週OWを全て解消する。48.50維持とISM上振れがそろえば再検討する。

### XLP 生活必需品 — Neutral 3.177%

**マクロ:** 雇用減速時の防御性がある一方、賃金・包装・物流コストと消費者の値上げ耐性が焦点。

**ボトムアップ:** Kraft Heinzなどから販売数量、値上げ、販促、粗利、節約志向を確認する。

**オプション:** Spot 85.05、GEX -42.35m、Flip 99.46、Call Wall 85、Put Wall 78、レンジ81.45–88.65。負のGammaだが直近価格はWall近辺。

**判断:** Underweightを解消してベースラインへ戻す。Charm集中は相対的に高く、週中の時間経過で85近辺への吸着・離脱に注意。81.45割れで再Underweight候補。

### XLI 資本財 — Neutral 5.318%

**マクロ:** ISM、受注、貿易、設備投資に直接反応する。強い雇用は需要面でプラスだが、賃金・金利上昇はマージンと評価に逆風。

**ボトムアップ:** Caterpillar、Rockwell、Howmetで受注、バックログ、価格、建機・自動化・航空宇宙需要を確認する。

**オプション:** Spot 179.84、GEX -65.22m、Flip 210.24、Call Wall 180、Put Wall 165、レンジ172.84–186.84。

**判断:** わずかに基準未満だがNeutral。180を決算・ISM後に明確突破すれば弱気構造を緩和、172.84割れでは負のGammaによる下方加速を警戒する。

### XLU 公益 — Neutral 1.449%

**マクロ:** 金利低下とデータセンター電力需要は支援材料だが、前週のタカ派的票割れと利回り上昇が短期の重石。

**ボトムアップ:** Duke、NRG、Constellation Energyほか公益決算で設備投資、レートベース、規制回収、電力需要、資金調達費用を見る。

**オプション:** Spot 44.35、GEX -10.18m、Flip 45.08、Call/Put Wall 45、レンジ43.08–45.62。

**判断:** 前回OWを解消し、わずかに基準未満。45.08回復と金利低下がそろえばNeutral基準まで戻す。43.08割れでは追加削減を検討する。

### XLC コミュニケーション・サービス — Underweight 5.945%

**マクロ:** 広告は消費・企業活動に、通信は金利と設備投資に反応する。サービスPMIと雇用統計が広告需要の確認材料。

**ボトムアップ:** Disney、Fox、AppLovinなどから広告、配信、テーマパーク、加入者、コンテンツ費用、AI活用の収益化を見る。

**オプション:** Spot 108.24、GEX -59.74m、Flip 128.60、Call Wall 115、Put Wall 104、レンジ100.75–115.73。Vanna集中は相対的に高い。

**判断:** 前回より0.493pt買い戻すがUnderweight継続。115突破で縮小、128.60回復でNeutral候補。104割れ、特に100.75割れでは下方加速を警戒する。

### XLY 一般消費財 — Underweight 5.651%

**マクロ:** 雇用・賃金の強さは消費を支えるが、同時に金利上昇を通じ自動車・住宅・耐久財を圧迫する。弱すぎる雇用も需要懸念となる。

**ボトムアップ:** Uber、McDonald's、Booking等に加え、前週Amazonの上振れがEC・クラウド・広告に限定されたのか、消費全体へ広がるのかを確認する。

**オプション:** Spot 116.09、GEX -59.62m、Flip 139.31、Call Wall 120、Put Wall 110、レンジ109.03–123.15。

**判断:** 前週の踏み上げを受け0.439pt買い戻すが、負のGamma・Flip下のためUnderweight継続。120定着でさらに縮小、139.31回復でNeutral。110割れは109.03方向の加速警戒。

### XLK 情報技術 — Underweight 19.363%

**マクロ:** AI設備投資と生産性期待は追い風だが、長期金利上昇と投資回収への懸念が評価を抑える。

**ボトムアップ:** Palantir、onsemi、AMD、半導体・ソフトウェア決算でデータセンター需要、AIアクセラレータ、在庫、粗利、設備投資回収を確認する。前週のMicrosoft好反応が業界全体へ波及するかが焦点。

**オプション:** Spot 175.35、GEX -14.35m、Flip 181.39、Call Wall 200、Put Wall 175、レンジ167.53–183.17。調整後スコアは12資産中最低、確信度0.911。

**判断:** 0.365pt買い戻すがUnderweight継続。181.39回復で縮小、183.17を維持できればNeutral候補。175割れは167.53までの不安定化を警戒する。

### IEF 米国7–10年国債 — Neutral 40.000%

**マクロ:** 7月雇用統計と単位労働コストが最大材料。緩やかな雇用鈍化は上昇要因、強い雇用・賃金は利回り上昇を通じ下落要因。急激な雇用悪化では景気ヘッジとして機能しやすい。

**ボトムアップ相当:** 財務省の需給、FOMCの反応関数、インフレ期待、タームプレミアムを企業ファンダメンタルの代わりに確認する。

**オプション:** Spot 92.95、GEX -43.54m、Flip 93.35、Call Wall 94、Put Wall 93、レンジ92.14–93.76。Vanna・Charm集中が12資産で最も高く、確信度は下限0.500。

**判断:** 方向スコアは弱いが、株式との相対スコア差から得られる株式増額はノートレード帯内。IEFは40%維持。93.35回復で債券の短期構造改善、92.14割れで追加増額を避ける。94突破と雇用鈍化がそろえば40%超への変更を次回検討する。

## 6. Vanna・Charmを使った運営

VannaとCharmは方向予測ではなく、IV変化と時間経過によるヘッジフロー感応度の警告として使う。

- **IEF:** Vanna 0.726、Charm 0.905と最も集中。雇用統計前後のIV低下や時間経過で93–94周辺のフローが変わりやすいため、40%を機械的に増減しない。
- **XLC:** Vanna集中0.535。決算後のIV低下が負のGammaと重なると、115または104方向への動きが増幅されうる。
- **XLP:** Charm集中0.636。85近辺のWallへの吸着が外れた場合、方向転換が急になりやすい。
- **XLRE:** Charm集中0.548。45のCall/Put Wallが同一で、時間経過に伴う45周辺の安定と、離脱後の値幅拡大の両方を想定する。
- **XLV・XLU:** Charm集中が相対的に高い。165、45のWallを終値で越えたかを日中の一時的な上抜けより重視する。

## 7. シナリオと配分変更条件

### 強気シナリオ

ISMと企業ガイダンスが改善し、雇用は急減速せず、賃金圧力のみ鈍化。長期金利が安定する。

- XLKが181.39、XLCが115、XLYが120を回復すれば各Underweightを段階的に縮小。
- XLREは45上を維持し46.28突破ならOW継続。ただし上限接近で追わない。
- IEFは93.35回復でも、株式ブレッドス改善時は40%を維持。

### 中立シナリオ

ISM・雇用がまちまちで、金利は高止まり。主要ETFがIVレンジ内に残る。

- 本レポートの目標配分を維持。
- 週中の個別決算だけでバケット配分を動かさず、終値でFlip・Wallを確認する。

### 弱気シナリオ

雇用・賃金が強すぎて金利が上昇する、または雇用が急減速して信用・消費懸念が強まる。

- 金利上昇型ではXLRE 43.86、XLU 43.08、IEF 92.14を監視。XLRE上乗せを先に解消する。
- 景気悪化型ではXLY 110、XLC 104、XLI 172.84を監視。XLFも55.41割れならUnderweight候補。
- 株式の負のGamma銘柄が複数同時にIV下限を割る場合、次回更新を待たず株式バケット削減を検討する。ただし今回のモデル値だけでは60/40を変更しない。

## 8. 監視水準一覧

| ETF | Spot | Gamma Flip | Call Wall | Put Wall | 7日IVレンジ | 現判断 |
|---|---:|---:|---:|---:|---:|---|
| XLK | 175.35 | 181.39 | 200 | 175 | 167.53–183.17 | UW |
| XLF | 56.94 | 56.03 | 56 | 54 | 55.41–58.47 | Neutral |
| XLV | 162.55 | 145.91 | 165 | 155 | 153.44–171.66 | Neutral |
| XLY | 116.09 | 139.31 | 120 | 110 | 109.03–123.15 | UW |
| XLC | 108.24 | 128.60 | 115 | 104 | 100.75–115.73 | UW |
| XLI | 179.84 | 210.24 | 180 | 165 | 172.84–186.84 | Neutral |
| XLP | 85.05 | 99.46 | 85 | 78 | 81.45–88.65 | Neutral |
| XLE | 59.55 | 57.73 | 60 | 55 | 57.19–61.91 | Neutral |
| XLU | 44.35 | 45.08 | 45 | 45 | 43.08–45.62 | Neutral |
| XLB | 50.43 | 48.50 | 55 | 47.5 | 46.82–54.04 | Neutral |
| XLRE | 45.07 | 42.72 | 45 | 45 | 43.86–46.28 | OW |
| IEF | 92.95 | 93.35 | 94 | 93 | 92.14–93.76 | Neutral |

## 9. 実装・検証

- Notebookに、前回の一貫12資産配分を自動選択し、次の金曜日までの実績と寄与度を算出する機能を追加した。
- 最新結果は `data/processed/20260802/consistent_12asset_weekly_attribution.parquet` と `outputs/tables/consistent_12asset_weekly_attribution.csv` に保存した。
- IEFをGEX by Strike、Gamma Flip Curve、価格＋20MA/50MA＋Wall、Vanna/Charm by Strikeの全ドロップダウン、12資産IVレンジ図、専用のOptions/Rates/40% Allocation表へ追加した。
- IEF専用データは `data/processed/20260802/ief_dashboard.parquet` と `outputs/tables/ief_dashboard.csv` に保存した。
- 13銘柄の価格・オプションチェーン、有限なGreeks、配分合計100%、Active合計0、寄与度恒等式、IEFを含む全ドロップダウン、HTML、parquet、CSVを検証した。
- `main.ipynb` は隠れた状態なしで上から実行し、**182 / 182 checks PASS、例外0件**。実行済みNotebookは `outputs/executed/main_20260802_ief_dashboard_executed.ipynb`。

## 10. 外部参照

- [Federal Reserve — FOMC statement, July 29, 2026](https://www.federalreserve.gov/newsevents/pressreleases/monetary20260729a.htm)
- [BEA — Personal Income and Outlays, June 2026](https://www.bea.gov/news/2026/personal-income-and-outlays-june-2026)
- [BLS — Employment Cost Index, June 2026](https://www.bls.gov/news.release/eci.nr0.htm)
- [AP — U.S. economic growth slowed to 1.5% in Q2](https://apnews.com/article/caf3b24d926885f9c4f95725c87e55)
- [AP — Weekly market performance and Friday close](https://apnews.com/article/37d8d182f02f0fcdcf9f7db67e6dfadd)
- [AP — Amazon, Microsoft and Apple market reaction](https://apnews.com/article/e31b3a442bcb957a53f1823ef21e73e8)
- [Fidelity — Weekly Market Update, July 31, 2026](https://www.fidelity.com/learning-center/trading-investing/weekly-market-update)
- [LPL — Can Hyperscalers Earn Their AI Ambitions?](https://www.lpl.com/research/weekly-market-commentary/can-hyperscalers-earn-their-ai-ambitions.html)
- [LPL — Fixed Income Outlook: Keep Calm and Clip Coupons](https://www.lpl.com/research/weekly-market-commentary/keep-calm-and-clip-coupons.html)
- [LPL — China’s Lower Oil Imports Weigh on Prices](https://www.lpl.com/research/blog/low-chinese-demand-for-foreign-oil-keeping-prices-low.html)
- [Kiplinger — Interest Rates Outlook](https://www.kiplinger.com/economic-forecasts/interest-rates)
- [Kiplinger — This week's economic calendar](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)
- [Kiplinger — Next week's earnings calendar](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)
- [BLS — 2026 release calendar](https://www.bls.gov/schedule/2026/home.htm)
- [BEA — News release schedule](https://www.bea.gov/news/schedule)
