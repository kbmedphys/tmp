# ポートフォリオアロケーション戦略

**User:** Anonymous  
**Created:** 8/3/2026 0:44:19  
**Updated:** 8/3/2026 1:00:15  
**Exported:** 8/3/2026 7:16:34  
**Link:** [https://chatgpt.com/c/6a6f65d3-12b0-83ee-93cd-aedb7419a1cb](https://chatgpt.com/c/6a6f65d3-12b0-83ee-93cd-aedb7419a1cb)  

## Response:
2026/8/3 0:44:20

円ベース・為替ヘッジなしを基準に、株式比率、IEFのデュレーション、ヘッジ比率を分け、為替・金利差・景気を踏まえて配分レンジを提示します。株式とIEFの入替だけではドル曝露はほぼ変わりません。

> **市場データを確認中**
>
> 現在の為替、日米金利、中央銀行政策、物価、雇用、景気指標を公的資料や信頼できる市場情報で確認し、株式と債券の比率判断に反映しようとしている。
>
> **市場データを確認した**
>
> 
>
> **最新のUSD/JPY・日米金利・中銀政策とマクロ指標を検索**
>
> [Japan to announce Tokyo, Washington took joint action on yen, sources say](https://www.reuters.com/world/asia-pacific/japan-announce-tokyo-washington-took-joint-action-yen-sources-say-2026-08-02/)
> [Treasury Yields Rise in Month That Saw Inflation Fears Revive](https://www.wsj.com/finance/jgbs-edge-lower-ahead-of-bojs-rate-decision-000cd87a)
> [Treasury yields on track to end the month at highest rate in two decades](https://www.marketwatch.com/livecoverage/stock-market-today-dow-s-p-500-nasdaq-tech-amazon-apple-earnings-chip-stocks-kospi/card/treasury-yields-to-end-the-month-at-highest-rate-in-two-decades-letWs8J36VJGfpQ6lsew)
> [Nasdaq 100 Falls Into Correction](https://www.barrons.com/livecoverage/stock-market-news-today-072926/card/dow-falls-1-100-points-ahead-of-tech-earnings-oil-prices-overshadow-fed-hold--eLYJlSHVTPNVxbdrZcxF)
> [US Federal Reserve meet today: Kevin Warsh-led FOMC keeps interest rates unchanged](https://timesofindia.indiatimes.com/business/international-business/us-federal-reserve-meet-today-july-29-2026-kevin-warsh-led-fomc-keeps-interest-rates-unchanged/articleshow/132719195.cms)
> [How major US stock indexes fared Friday 7/31/2026](https://apnews.com/article/37d8d182f02f0fcdcf9f7db67e6dfadd)
> [Daily Treasury Bill Rates](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_bill_rates)
> [Ministry of Finance Japan](https://www.mof.go.jp/english/index.htm)
> [Federal Reserve issues FOMC statement](https://www.federalreserve.gov/newsevents/pressreleases/monetary20260729a.htm)
> [List of Foreign Exchange Rates (Daily)](https://www.boj.or.jp/en/statistics/market/forex/fxdaily/fxlist/index.htm)
> [Japan 10 Year Government Bond Yield - Quote - Chart](https://tradingeconomics.com/japan/government-bond-yield)
> [10 Year Treasury Rate - Real-Time & Historical Yield Trends](https://ycharts.com/indicators/10_year_treasury_rate)
> [FOMC Press Conference, July 29, 2026](https://www.youtube.com/watch?v=cyexh4Ikrp4)
> [USD JPY | US Dollar to Yen Live Rate](https://www.investing.com/currencies/usd-jpy)
> [10-Year Treasury Constant Maturity Minus 2-Year ... - FRED](https://fred.stlouisfed.org/series/T10Y2Y)
> [Japan 10-year gov't bond yield rises to 29-yr high on ...](https://mainichi.jp/english/articles/20260709/p2g/00m/0bu/035000c)
> [US Treasury Yield Curve (updated daily) - Public.com](https://public.com/treasury-yield-curve)
> [The BOJ released "The Bank's View" of the Outlook for ...](https://www.facebook.com/BankofJapan.en/posts/the-boj-released-the-banks-view-of-the-outlook-for-economic-activity-and-prices-/1540222327899500/)
> [Exchange rates of Japanese Yen to the U.S. dollar and ...](https://www.reutersconnect.com/item/exchange-rates-of-japanese-yen-to-the-us-dollar-and-several-other-foreign-currencies-are-displayed-at-a-money-exchange-shop-in-tokyo/dGFnOnJldXRlcnMuY29tLDIwMjY6bmV3c21sX1JDMjVNTUFZNzNFNQ)
> [Japan Economic & Financial Weekly](https://www.mufgresearch.com/rates/japan-economic-financial-weekly-6-july-2026/)
>
> **20件のウェブサイトを検索しました**
>
> 
>
> **追加データを収集中**
>
> 米国債ETFの利回りとデュレーション、株式の予想PER、米国の成長・物価・雇用、日本の金融政策や長期金利を確認し、円投資家にとっての為替ヘッジコストも評価しようとしている。
>
> **追加データを収集した**
>
> 
>
> **配分と為替を整理中**
>
> 株式の業績は底堅い一方、割高感と金利上昇リスクを考慮して、やや守備的な配分を検討している。資産比率以上に、円投資家にはドル為替ヘッジ比率が重要だと見ている。
>
> **配分と為替を整理した**
>
> 
>
> **米国マクロ指標とヘッジ戦略を調査**
>
> [GDP (Advance Estimate), 2nd Quarter 2026](https://www.bea.gov/news/2026/gdp-advance-estimate-2nd-quarter-2026)
> [Consumer Price Index Summary - 2026 M06 Results](https://www.bls.gov/news.release/cpi.nr0.htm)
> [iShares 7-10 Year Treasury Bond ETF | IEF](https://www.ishares.com/us/products/239456/ishares-710-year-treasury-bond-etf)
>
> **3件のウェブサイトを検索しました**
>
> 
>
> **判断材料を統合中**
>
> 足元は成長減速と高めのインフレが併存し、株式と中期国債が同時に弱くなる局面も想定している。大幅な配分変更より、やや守備的にし、円高リスクへ備える方針を検討している。
>
> **判断材料を統合した**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> 15m 52s考えました

## 結論

**円ベース投資家、米国株＝S&P 500相当、運用期間3～6か月**を前提にすると、現在は次の組み合わせが妥当です。

| 項目 | 60/40基準 | 現在の推奨 | 判断 |
|---|---:|---:|---|
| 米国株 | 60% | **55～57.5%** | 小幅アンダーウェイト |
| IEF | 40% | **42.5～45%** | 小幅オーバーウェイト |
| 株式部分の為替ヘッジ | 0% | **25～35%** | 部分ヘッジ |
| IEF部分の為替ヘッジ | 0% | **60～80%** | 高めのヘッジ |
| ポートフォリオ全体の実質的な非ヘッジUSD | 100% | **50～55%程度** | 明確なドル・アンダーウェイト |

具体的な初期配分は、

> **米国株57.5%・IEF42.5%**  
> 米国株の30%、IEFの70%を円ヘッジ

とします。

現時点で最も確信度が高いのは、**IEFの大幅オーバーウェイトではなく、非ヘッジのドル・エクスポージャーを減らすこと**です。

---

## 1. 現在は「米景気減速＋インフレ残存＋円介入レジーム」

2026年8月3日未明時点では市場は週末であり、直近7月31日のドル円終値は約157.38円です。前週には163.99円まで円安が進んだ後、大規模な円買い介入とみられる動きで急反落しました。また、報道ベースでは、日米が協調して円買いを行ったことを日本政府が月曜日に発表する見込みですが、現時点では正式発表前です。([The Wall Street Journal](https://www.wsj.com/market-data/quotes/fx/USDJPY?utm_source=chatgpt.com))

したがって現在のドル円は、

- 日米金利差による**ドル高圧力**
- 160円超での当局介入による**円高テールリスク**
- 日銀の追加利上げによる中期的な円高圧力

が同時に存在する状態です。

157円台は「既に介入で円高になったからドルを買いやすい」というほど安くはなく、一方で金利差が大きいため円を全面的に買う局面でもありません。したがって、**全ヘッジではなく部分ヘッジ**が適切です。

---

## 2. 米国金利は高いが、IEFを強くオーバーウェイトするにはまだ早い

FRBは7月29日に政策金利を3.50～3.75%で据え置きましたが、3名の投票者は0.25%の利上げを主張しました。7月31日の米国債利回りは、2年4.28%、5年4.45%、10年4.75%です。短期より長期金利が高い形であり、単なる景気回復ではなく、インフレ、財政、タームプレミアムの上昇が長期金利を押し上げている可能性があります。([連邦準備制度理事会](https://www.federalreserve.gov/newsevents/pressreleases/monetary20260729a.htm))

IEFは現在、

- 30日SEC利回り：4.43%
- 平均最終利回り：4.60%
- 実効デュレーション：6.87年
- 平均残存期間：8.40年

です。([BlackRock](https://www.ishares.com/us/products/239456/ishares-710-year-treasury-bond-etf?utm_source=chatgpt.com))

1年間の概算リターンを

$$
R_{\mathrm{IEF}}\simeq YTM-D_{\mathrm{eff}}\Delta y
$$

で近似すると、次のようになります。

| 米7～10年金利の変化 | IEFの概算USDリターン |
|---:|---:|
| -50bp | 約+8.0% |
| 変化なし | 約+4.6% |
| ＋50bp | 約+1.2% |
| ＋100bp | 約-2.3% |

凸性、ロールダウン、経費を無視した概算ですが、現在はスタート利回りが高いため、**金利が多少上昇してもキャリーが損失を吸収する**状態です。一方で、インフレ再加速やタームプレミアム上昇で10年金利が5%を明確に超える場合、IEFを45～50%まで増やすのは早計です。

したがって、現時点ではIEFを40%から**42.5%へ小幅に増やし、追加の2.5%は条件確認後**とするのが合理的です。

---

## 3. 米国株は業績が強いが、債券対比でバリュエーション余地が小さい

米国の2026年4～6月期実質GDPは前期比年率1.5%と、1～3月期の2.1%から減速しました。一方、6月のPCEインフレ率は総合3.7%、コア3.3%で、FRB目標を明確に上回っています。景気は減速していますが、FRBが早期に大幅利下げできる環境ではありません。([経済分析局](https://www.bea.gov/news/2026/gdp-advance-estimate-2nd-quarter-2026?utm_source=chatgpt.com))

S&P 500の予想PERは21.37倍、予想3～5年EPS成長率は17.99%です。予想益回りは、

$$
\frac{1}{21.37}\simeq4.68\%
$$

となり、IEFの平均最終利回り4.60%との差は約0.08ポイントしかありません。これは単純な比較にすぎず、株式には利益成長と配当がある一方、利益予想未達やPER低下のリスクもあります。([SSGA](https://www.ssga.com/us/en/intermediary/etfs/state-street-spdr-sp-500-etf-trust-spy?utm_source=chatgpt.com))

したがって、

- 利益成長の強さから株式を大幅アンダーにはしない
- ただし高PERと高金利を考慮し、60%から55～57.5%へ落とす

という判断になります。

---

## 4. 日本側の金利上昇は中期的に円を支える

日銀は7月31日に政策金利を1.0%で据え置きました。日本の10年国債利回りは約2.80%です。日銀の7月展望では、2026年度の実質GDP成長率中央値は0.6%、生鮮食品を除くCPI上昇率中央値は2.5%であり、日銀は経済・物価が見通しに沿えば今後も政策金利を引き上げる方針を示しています。([日本ボードゲーム連盟](https://www.boj.or.jp/en/mopo/mpmdeci/mpr_2026/k260731a.pdf))

現在の日米金利差は概ね、

$$
\text{政策金利差}
=3.625\%-1.00\%
=2.625\%
$$

$$
\text{10年金利差}
=4.75\%-2.80\%
\simeq1.95\%
$$

です。

金利差は依然としてドルを支えていますが、日銀の追加利上げと日米協調介入の可能性を考えると、**ドル円の上方向より下方向のジャンプリスクが大きくなっています**。

---

## 5. 為替は株・債券配分とは別に管理すべき

米国株もIEFもドル建てなので、完全非ヘッジの場合、60/40を55/45に変更してもドル・エクスポージャーは100%のままです。

概算では、

$$
R_{p}^{JPY}
\simeq
w_E R_E^{USD}
+w_B R_B^{USD}
+R_{USD/JPY}
$$

となり、為替項は株式・債券の配分にかかわらずポートフォリオ全体にかかります。

ドル円が157.38円から150円になれば、為替要因だけで円ベース収益率は約-4.7%です。145円なら約-7.9%であり、IEFの1年分の利回りを簡単に上回ります。

このため、**債券部分は株式部分より強く為替ヘッジする**必要があります。債券は本来、ポートフォリオのボラティリティを抑えるための資産であり、そこに大きなドル円リスクを残すと、IEFの防御機能が薄れるからです。

### 推奨する為替構造

| スリーブ | 資産ウェイト | ヘッジ率 | 非ヘッジUSDエクスポージャー |
|---|---:|---:|---:|
| 米国株 | 57.5% | 30% | 40.25% |
| IEF | 42.5% | 70% | 12.75% |
| 合計 | 100% | 約47% | **約53%** |

したがって、完全非ヘッジのドルベータ1.0から、

$$
\beta_{\mathrm{USD}}^{net}
=0.575(1-0.30)+0.425(1-0.70)
=0.53
$$

程度まで下げます。

---

## 6. IEFを100%ヘッジしない理由

為替ヘッジコストを単純に政策金利差で近似すると、約2.6%です。実際には短期OIS、フォワードポイント、クロスカレンシー・ベーシスによって異なります。

IEFを100%ヘッジすると、静的なキャリーは概ね、

$$
4.60\%-2.625\%
\simeq1.98\%
$$

まで低下します。

一方、70%だけヘッジすれば、

$$
4.60\%-0.70\times2.625\%
\simeq2.76\%
$$

となります。

このため、IEFについては、

- 円高リスクを抑える
- ただし高いヘッジコストを全額負担しない
- 米景気後退時の米金利低下メリットを残す

という観点から、**60～80%ヘッジ、中心値70%**が妥当です。

---

## 7. 条件付きのアロケーションルール

### 基本ケース：現在

| 米国株 | IEF | 為替 |
|---:|---:|---|
| **57.5%** | **42.5%** | 株30%、IEF70%ヘッジ |

景気減速を考慮してIEFを小幅オーバーしますが、インフレ・長期金利上昇リスクがあるため、45%まで一括では増やしません。

### ディスインフレと景気減速が明確になった場合

以下が確認された場合は、**55/45、場合によっては52.5/47.5**までIEFを増やせます。

- 米10年金利が4.50%を下回って定着
- コアPCEの3か月年率が3%未満
- 雇用増加の3か月平均が10万人未満
- 企業業績予想の下方修正が拡大

この場合、株式はアンダー、IEFは明確なオーバーです。

### インフレ・タームプレミアムが再上昇した場合

以下の場合は、IEFを**37.5～40%へ戻します**。

- 米10年金利が5.0%を明確に上抜け
- コアPCE前年比が3.5%を超えて再加速
- FRBが追加利上げ
- 原油高と期待インフレ上昇が同時進行

株式とIEFだけの二資産制約なら62.5/37.5ですが、実際にはキャッシュや1～3年米国債を許容できるなら、株式を積極的に増やすより短期債へ逃がす方が自然です。

---

## 8. 為替ヘッジの調整基準

| ドル円 | 対応 |
|---|---|
| 160円以上 | ヘッジ率をさらに10～15ポイント引き上げる |
| 155～160円 | 現在の基本ヘッジを維持 |
| 150円割れ | 日米金利差がなお2%以上なら、ヘッジ益の一部を確定し10ポイント程度落とす余地 |
| 日銀追加利上げ・協調介入継続 | 水準にかかわらず高めのヘッジを維持 |
| 米景気後退・FRB利下げ局面 | ドル安リスクが高まるためヘッジを維持または増加 |

直近は介入直後でギャップリスクが大きいため、ヘッジ変更は一括ではなく、**2～3回に分割**する方が適切です。

---

## 最終判断

現在の優先順位は次の通りです。

1. **非ヘッジのドルを明確に減らす**
2. **IEFを小幅にオーバーウェイトする**
3. **米国株を小幅にアンダーウェイトする**
4. インフレ鈍化を確認するまでは、IEFを50%近くまで増やさない

したがって、実務上の中心案は、

> **米国株57.5%／IEF42.5%**  
> **株式30%ヘッジ／IEF70%ヘッジ**  
> **実質非ヘッジUSD約53%**

です。長期の政策配分60/40自体は維持し、資産配分は月次、為替ヘッジは週次で調整するのが適しています。

- [Reuters](https://www.reuters.com/world/asia-pacific/japan-announce-tokyo-washington-took-joint-action-yen-sources-say-2026-08-02/?utm_source=chatgpt.com)
- [Reuters](https://www.reuters.com/world/asia-pacific/japan-may-have-sold-5897-billion-yen-buying-intervention-2026-07-31/?utm_source=chatgpt.com)
- [ファイナンシャル・タイムズ](https://www.ft.com/content/0f9b2fe7-bde4-4f5f-b49e-93ccb5da9ea8?utm_source=chatgpt.com)
- [The Wall Street Journal](https://www.wsj.com/finance/jgbs-edge-lower-ahead-of-bojs-rate-decision-000cd87a?utm_source=chatgpt.com)

---

**Sources:**

- [USD to JPY Exchange Rate](https://www.wsj.com/market-data/quotes/fx/USDJPY?utm_source=chatgpt.com)
- [Federal Reserve Board - Federal Reserve issues FOMC statement](https://www.federalreserve.gov/newsevents/pressreleases/monetary20260729a.htm)
- [iShares 7-10 Year Treasury Bond ETF | IEF](https://www.ishares.com/us/products/239456/ishares-710-year-treasury-bond-etf?utm_source=chatgpt.com)
- [GDP (Advance Estimate), 2nd Quarter 2026](https://www.bea.gov/news/2026/gdp-advance-estimate-2nd-quarter-2026?utm_source=chatgpt.com)
- [SPY: State Street® SPDR® S&P 500® ETF Trust](https://www.ssga.com/us/en/intermediary/etfs/state-street-spdr-sp-500-etf-trust-spy?utm_source=chatgpt.com)
- [](https://www.boj.or.jp/en/mopo/mpmdeci/mpr_2026/k260731a.pdf)



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)