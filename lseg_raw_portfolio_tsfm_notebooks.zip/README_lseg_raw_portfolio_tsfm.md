
# Raw sector/factor TSFM notebooks for LSEG Data Library

Created notebooks:

- `08_binary_tsfm_raw_sector_factor_lseg.ipynb`
- `09_vol_scaled_tsfm_raw_sector_factor_lseg.ipynb`

These are new notebooks and do not overwrite the prior 01/02 notebooks.

## Data contract

The notebooks expect the following objects. You may either let the notebook generate synthetic smoke-test data, or save a pickle at `data/theme_factor_inputs.pkl` with these keys:

```python
{
    "stock_returns": DataFrame(index=date, columns=security_id, values=daily decimal returns),
    "factor_scores": DataFrame(columns=["date", "security_id", "Factor_Value", "Factor_Size", ...]),
    "sector_classification": DataFrame(columns=["date", "security_id", "sector_id"]),
    "market_cap": DataFrame(columns=["date", "security_id", "market_cap"]),  # recommended
}
```

## LSEG data to acquire

1. Point-in-time universe: RIC, ISIN, PermID, exchange, listing status, security type, and ideally historical constituents.
2. Daily adjusted price / total return data: adjusted close or total return, dividend/split adjustments, currency.
3. Sector classification: TRBC, GICS, or ICB sector and industry fields.
4. Size/liquidity: market cap, free-float market cap or free-float percentage, volume, turnover/traded value.
5. Fundamental fields for raw factor scores: assets, equity/book value, sales/revenue, gross profit, operating income, net income, operating cash flow, capex, shares outstanding, R&D, dividends.
6. Report-date / filing-date / update-date metadata for fundamentals. If not available, apply conservative reporting lags before using fundamentals.
7. FX rates if you build a multi-currency global universe.

Use LSEG Workspace Data Item Browser to confirm exact field names for your entitlement. The notebooks include a `LSEG_FIELD_MAP_TEMPLATE` with candidate fields, but this is intentionally editable.
