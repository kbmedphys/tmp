# Codex実装指示書

文書ID: JIN-CDX-001  
版: 1.0

## 0. 運用規則

- Task 00から順に、原則1タスクずつCodexへ渡す。
- 各タスク開始時にCodexは`AGENTS.md`と指定仕様を読む。
- 変更前に短い計画を提示させる。
- タスク外の機能を先回りして実装させない。
- 完了時に、変更ファイル、テストコマンド、結果、未解決事項を報告させる。
- 実行していないテストを実行済みと書かせない。
- 実データ用credentialsがない場合、fixtureで完了させる。架空の成功レスポンスを実データ取得成功と扱わない。

各ブロックをそのままCodexへ渡せる。

---

## Task 00 — リポジトリ基盤と品質ゲート

**対応要件:** AC-01、NFR-QUAL、NFR-REP、NFR-SEC

```text
Goal
空または仕様ファイルだけがあるリポジトリを、インストール可能でテスト可能なPython研究パッケージへ初期化してください。

Context
最初に AGENTS.md、docs/REQUIREMENTS.md、docs/ARCHITECTURE.md、docs/TEST_PLAN.md を読んでください。パッケージ名は jp-inflation-nowcast、import packageは jp_inflation です。Python 3.11/3.12、uv、src layout、Typer、Pydantic v2、pytest、Ruff、mypyを使います。JAX/Flax/Optaxは依存へ入れますが、このタスクではモデルを実装しません。

Constraints
- Task 00以外の機能を実装しない。
- 任意eval/pickle入力を導入しない。
- CIはネットワークなしで動くこと。
- 秘密情報をcommitしない。
- Linux/macOSで動くMakefileと同等のuvコマンドを用意する。
- 依存versionは互換性を確認し、uv.lockを生成する。
- package import時に重いJAX初期化やファイルI/Oをしない。

Implement
1. pyproject.toml、uv.lock、Makefile、.gitignore、.env.example。
2. src/jp_inflation/__init__.py、cli.py、config/domain等の空package構造。
3. `jp-inflation --help` と `jp-inflation config validate --config ...` の最小CLI。
4. PydanticのRootConfig最小形と、configs/model_mvp.example.yamlを読めるvalidator。
5. structured loggingの最小初期化。
6. tests/unit/test_import.py、test_cli_help.py、test_config_load.py。
7. GitHub Actions等のCI: format check、lint、mypy、pytest、package build。
8. READMEへsetup/testコマンドを追記。

Done when
- `make setup`, `make fmt`, `make lint`, `make typecheck`, `make test` が成功する。
- `uv run jp-inflation --help` が成功する。
- `uv build` が成功する。
- ネットワーク接続なしのCI定義がある。
- 実行したコマンドと正確な結果、変更ファイル、未解決事項を報告する。
```

---

## Task 01 — ドメイン型、設定、JSON Schema

**対応要件:** FR-DATA-008、FR-VINT-001/007、FR-POL-001〜007、FR-OUT-002

```text
Goal
時点整合データ、CPI、政策、予測、実行マニフェストの型付き契約を実装してください。

Context
AGENTS.md、docs/DATA_SPEC.mdの4、8、9節、docs/MODEL_SPEC.mdの11節、docs/ARCHITECTURE.mdの4〜5節を読んでください。schemas/*.jsonとconfigs/*.yamlを契約例として使います。

Constraints
- timezone-naive datetimeを拒否する。
- unknown config fieldsは既定で拒否する。
- 任意コード式をpolicy operatorとして許可しない。
- secretsをconfig modelの通常fieldとして保持しない。
- domain型はJAX/DuckDB/Typerへ依存しない。
- JSON SchemaとPydantic modelの意味を一致させる。

Implement
1. SeriesObservation、VintageQuality、ObservationStatus。
2. CpiNode、CpiWeight、validity interval validator。
3. PolicyEventとdirect effect discriminated union。
4. Scenario operation: add/remove/scale/shift/replace。
5. ForecastOrigin、ForecastTarget、ForecastDistribution metadata。
6. RunManifest、DataSnapshot。
7. YAML RootConfig全体のPydantic modelとresolved canonical JSON hash。
8. schemasの検証テストとround-trip test。
9. invalid timezone、invalid policy dates、unknown operator、unknown config keyのnegative tests。

Done when
- すべてのschema exampleがPydantic/JSON Schema双方でvalid。
- negative fixturesが期待する例外で失敗する。
- canonical config hashがkey orderに依存しない。
- `make lint typecheck test` が成功する。
- public API、shapeではなくfield semanticsをdocstringに記載する。
```

---

## Task 02 — Raw store、VintageStore、as-of join

**対応要件:** FR-DATA-003/004、FR-VINT-001〜007、AC-02

```text
Goal
immutable raw artifact保存と、Parquet/DuckDBを使った時点整合VintageStoreを実装してください。

Context
AGENTS.md、docs/DATA_SPEC.mdの2、4〜7節、docs/TEST_PLAN.mdのT-VINTを読んでください。

Constraints
- future leakageを最重要不変条件とする。
- raw artifactはcontent-addressed、atomic write。
- 同じseries/reference periodの速報・改定を上書きしない。
- `release_at <= origin`を必ずstore query内部で強制する。
- CIでネットワークを使わない。
- data fileのpickleは禁止。

Implement
1. RawArtifactStore: bytes、metadata、SHA-256、dedup、atomic write。
2. ParquetVintageStore: put、as_of、snapshot manifest。
3. DuckDB queryでlatest eligible vintageを選択。
4. quality A/B/C filter。
5. UTC storage、Asia/Tokyo conversion utility。
6. fixture: 2系列、複数reference periods、速報/改定、delayed release。
7. T-VINT-001〜004とfuture mutation test。
8. CLI `data validate` のstore-level diagnostics最小版。

Done when
- originごとに手計算通りのvintageが返る。
- origin後の値を変更してもorigin時点のquery結果hashが変わらない。
- duplicate/conflicting vintageを明示的に処理する。
- interrupted writeで破損したfinal artifactを残さないテストがある。
- `make lint typecheck test` が成功する。
```

---

## Task 03 — データカタログと公式形式コネクタ骨格

**対応要件:** FR-DATA-001〜008、NFR-LIC、NFR-SEC

```text
Goal
catalog-driven connector frameworkと、公式形式fixtureをparseするコネクタを実装してください。

Context
AGENTS.md、docs/DATA_SPEC.mdの3、12〜16節、configs/data_catalog.example.yamlを読んでください。実credentialsがなくてもfixtureで完了できる設計にします。

Constraints
- fetchとparseを分離する。
- unit/integration testsはネットワークを使わない。
- e-Stat app ID等は環境変数SecretProvider経由。
- HTML scrapingを標準実装しない。
- partial parseを成功としてcommitしない。
- URL/logからsecretをredactする。
- 実API endpointやseries IDを推測してhardcodeしない。catalogで定義する。

Implement
1. CatalogEntry、DataCatalog loader/validator。
2. DataConnector Protocol、RemoteObject、RawArtifact、ParseResult。
3. HTTP fetch utility: timeout、retry/backoff、size/content-type checks、redaction。
4. e-Stat JSON/CSV形式fixture parser。
5. BOJ CSV/JSON形式fixture parser。
6. generic official CSV/XLSX manual-import connector。
7. provenance/license/re-distribution metadata。
8. `data ingest --dataset ... --dry-run` とfixture integration test。
9. schema drift、partial body、bad numeric、unexpected codeのfailure tests。

Done when
- fixture -> raw -> parsed observations -> VintageStoreまで原子的に動く。
- credentialsなしでdry-runと全CIが成功する。
- credentialsが必要なlive fetchは明確なエラーを返す。
- catalog追加手順を文書化する。
- `make lint typecheck test` が成功する。
```

---

## Task 04 — CPI階層、ウェイト版、集計、寄与

**対応要件:** FR-CPI-001〜006、AC-03

```text
Goal
versioned CPI hierarchy/weightsと、指数水準ベースの集計・寄与計算を実装してください。

Context
AGENTS.md、docs/DATA_SPEC.mdの8節、docs/MODEL_SPEC.mdの3節、docs/TEST_PLAN.mdのT-CPIを読んでください。

Constraints
- 最終集計をログ近似だけで作らない。
- valid dateに対応するweight versionを使う。
- 「core」等の曖昧名に依存せず除外集合を明示する。
- missing item weightとreconciliation residualを出力する。
- float64を使い、input Decimalを保持できるようにする。

Implement
1. hierarchy loader、cycle/parent/validity validation。
2. weight version resolver。
3. level aggregator、mom/yoy calculator。
4. contribution calculatorとresidual。
5. base-year bridge strategy interface。
6. aggregate definition by tags/exclusions。
7. 小さな2 weight-version fixture。
8. T-CPI-001〜004とproperty tests。
9. CLIまたはlibrary exampleで手計算結果を表示。

Done when
- 手計算fixtureと1e-10以内。
- contribution reconciliationが許容誤差内。
- 間違ったweight version/欠損階層/循環を拒否する。
- aggregate metadataに対象itemとweight versionが記録される。
- `make lint typecheck test` が成功する。
```

---

## Task 05 — As-of特徴量ビルダー

**対応要件:** FR-FEAT-001〜007、FR-VINT-006

```text
Goal
予測起点を必須とするragged-edge/as-of feature builderを実装してください。

Context
AGENTS.md、docs/DATA_SPEC.mdの10〜11節、docs/TEST_PLAN.mdのT-FEATとIT-02を読んでください。

Constraints
- すべてのsource valueはrelease_at <= origin。
- normalizationはtrain windowだけでfit。
- missing value、availability mask、stalenessを別々に保持する。
- latest valueの無条件forward fillをしない。
- feature provenanceを保存する。
- IO mappingの欠損weightを報告する。

Implement
1. FeatureDefinition registryと型付きtransform pipeline。
2. standard transforms: lag、diff、log diff、mom/yoy、rolling、EWMA、calendar。
3. as-of last value、missing mask、staleness、preliminary/final flag。
4. train-only scaler fit/transform artifact。
5. IO weighted input-cost builderとmapping quality。
6. feature matrix + metadata + hashのParquet artifact。
7. future mutation、train-only scaling、ragged edge tests。
8. CLI `features build --as-of ...` とIT-02。

Done when
- feature artifactの各列からsource series/vintage/transformへ追跡できる。
- future values変更で過去origin artifact hashが変わらない。
- test periodの極端値でscalerが変わらない。
- missing/staleness fixtureが手計算通り。
- `make lint typecheck test` が成功する。
```

---

## Task 06 — ベンチマークと疑似リアルタイム・バックテスト骨格

**対応要件:** FR-BENCH、FR-EVAL-001〜004/008、AC-08一部

```text
Goal
共通ForecastModel contract、3つのベンチマーク、時系列backtest engine、主要metricsを実装してください。

Context
AGENTS.md、docs/MODEL_SPEC.mdの4節、docs/TEST_PLAN.mdの6節を読んでください。

Constraints
- random train/test split禁止。
- 同じorigin/targetのpaired evaluation。
- strict/broad/latest_only_diagnosticを区別する。
- model fitはorigin以後を見ない。
- pointだけでなく予測分布を返す。
- complex modelに有利なorigin filteringをしない。

Implement
1. ForecastModel ProtocolとForecastDistribution validation。
2. SeasonalNaive。
3. AutoRegressiveRidge。
4. LinearBridge。
5. residual block bootstrapによるsamples/quantiles。
6. expanding/rolling origin generator。
7. MAE、RMSE、MASE、bias、direction、pinball、CRPS、coverage。
8. result Parquet/JSON schema、run manifest。
9. CLI `backtest run --profile smoke` とIT-03。
10. tests: no lookahead、paired target、quantile monotonicity。

Done when
- 3 origins×2 horizons×2 aggregatesのsmoke backtestが完走する。
- strictnessとvintage qualityが結果へ保存される。
- originごとのtrain endを検査できる。
- metricsを手計算fixtureと照合する。
- `make lint typecheck test backtest-smoke` が成功する。
```

---

## Task 07 — 教師あり二部価格改定モデル

**対応要件:** FR-SUP-001〜007、AC-04

```text
Goal
JAX/Flaxで品目共通のhazard + magnitude二部モデルを実装し、時点整合backtestへ接続してください。

Context
AGENTS.md、docs/MODEL_SPEC.mdの5節、docs/TEST_PLAN.mdのT-MOD/IT-04を読んでください。

Constraints
- 公開CPI item changeは企業価格改定の代理であることをmetadata/model cardに書く。
- random split禁止。
- mask/stalenessを入力できること。
- Student-t scale/nuを安全な変換で制約する。
- float64、明示的JAX PRNG。
- evaluation時にtrain normalizationを更新しない。
- aggregate auxiliary lossは正しいCPI level aggregationを使う。

Implement
1. label builder `z` とmagnitude、threshold config。
2. item/sector embeddings、2層SiLU shared trunk。
3. Bernoulli hazard head、Student-t magnitude head。
4. BCE + conditional NLL + optional aggregate loss。
5. direct multi-horizonまたはhorizon embedding。
6. train/eval loop、early stopping、checkpoint、manifest。
7. sample/quantile predictionとmonotonic validation。
8. synthetic panel fixtureでIT-04。
9. backtest engine adapter。
10. model card templateと代理変数の限界。

Done when
- synthetic dataでlossがfiniteで初期値より改善する。
- same seedで同じsmoke result。
- checkpoint round trip後の予測一致。
- quantiles、shape、CPI aggregate出力がvalid。
- `make lint typecheck test backtest-smoke` が成功する。
```

---

## Task 08 — 観測条件付きアンサンブルと不確実性較正

**対応要件:** FR-ENS-001〜005

```text
Goal
ベンチマーク、教師ありモデル、将来の構造モデルを結合できる時点整合アンサンブルを実装してください。

Context
AGENTS.md、docs/MODEL_SPEC.mdの9節、docs/TEST_PLAN.mdのbacktest設計を読んでください。

Constraints
- ensemble weightsはoriginより前のpseudo-real-time成績だけで推定。
- non-negative、sum-to-one。
- small sampleではequal-weightへregularize。
- missing model forecastを無言でweight再正規化しない。規則を明示する。
- release stageは値の公表済み状態から決める。
- calibration dataをtestへ再利用しない。

Implement
1. simplex-constrained weight fitter。
2. horizon/aggregate/release-stage別weights。
3. prediction samplesのmixtureまたはlinear pool。
4. rolling coverage diagnostics。
5. optional conformal quantile adjustment。
6. new releaseを受けたsame-target rerunのstage metadata。
7. tests: future loss非利用、simplex、missing model policy、coverage adjustment。
8. backtest reportに各model weightとlossを出力。

Done when
- synthetic caseで優れたmodelへweightが寄るがtest futureを見ない。
- equal forecastsなら安定したweights。
- quantile coverage diagnosticsが保存される。
- 既存ForecastModel contractを壊さない。
- `make lint typecheck test backtest-smoke` が成功する。
```

---

## Task 09 — 構造価格設定環境

**対応要件:** FR-ENV-001〜010、AC-05

```text
Goal
4レジーム、型付き状態・行動・遷移・報酬を持つJAX構造シミュレータを実装してください。まだPEPG学習は実装しません。

Context
AGENTS.md、docs/MODEL_SPEC.mdの6節、docs/ARCHITECTURE.mdの9節、docs/TEST_PLAN.mdのT-ENV/T-RNG/IT-05を読んでください。

Constraints
- market_goods、market_services、energy_fresh、administeredを分離。
- 時間方向lax.scan、品目/経路方向vmap。
- policy/env関数はpure、明示的key。
- constraintsは出力変換で満たす。
- direct policy effectをmarket actionと別に適用。
- common shock pathを外から注入できる。
- silent clipping、NaN zero-fill禁止。
- public-data MVPの報酬を観測企業利潤と表現しない。

Implement
1. EnvState、MarketAction、AdministeredAction、EnvParams、ShockPath。
2. regime dispatchをJIT可能なmask/enumで実装。
3. input cost、flexible price、demand、rewardの最小式。
4. direct policy path interface。
5. 2層SiLU policy network skeletonとsafe output transforms。
6. step_fn、rollout、diagnostics。
7. reference non-vectorized rollout for tests。
8. four-regime synthetic fixture。
9. T-ENV、T-RNG-001、JIT/non-JIT、vectorized/reference tests。
10. rollout sample保存。

Done when
- fixed seed/shockでbitwiseまたは許容誤差内再現。
- action/price constraints violation 0。
- zero action/policy/shockのidentity test合格。
- administered fixtureが料金式通り。
- CPU smoke rolloutが完走する。
- `make lint typecheck test test-smoke` が成功する。
```

---

## Task 10 — PEPG、mirrored sampling、探索減衰

**対応要件:** FR-RL-001〜010、AC-06

```text
Goal
構造方策を学習するParameter-Exploring Policy Gradient実装を追加してください。

Context
AGENTS.md、docs/MODEL_SPEC.mdの7節、docs/TEST_PLAN.mdのT-PEPG/IT-06を読んでください。添付論文の設計思想としてparameter perturbation、mirrored sampling、entropy、epsilon-greedy、running normalization、time inputを使います。

Constraints
- `theta_plus/minus = mu +/- sigma*epsilon` の厳密なpair。
- 正負pairは同一initial state、shock、policy path。
- gradientの符号と`2*sigma`をtoy testで検証。
- sigmaが0に近い場合の数値保護。
- explicit JAX PRNG、key再利用禁止。
- smoke/dev/research/paper_scale profiles。
- PBTは実装しないかoptional stubに留める。
- evaluationはnoise/entropy/epsilon-greedyをoff。

Implement
1. tree flatten/unflatten utilityまたはravel_pytreeの安全なwrapper。
2. mirrored perturbation sampler。
3. common-random-number rollout evaluator。
4. PEPG gradient、Optax optimizer update。
5. linear/cosine schedules for sigma/entropy/epsilon。
6. running normalization state、warmup/freeze/checkpoint。
7. metrics、NaN/Inf guards、checkpoint resume。
8. toy quadratic analytic optimum test。
9. small structural environment learning smoke。
10. CLI `model train --model structural --profile smoke`。

Done when
- toy quadraticで複数seedの大半が初期距離を明確に改善。
- antithetic/common shock tests合格。
- checkpoint再開が連続実行と一致する範囲を文書化。
- evaluation pathに探索がないことをテスト。
- `make lint typecheck test test-smoke` が成功する。
```

---

## Task 11 — 外側SMM較正と構造pretraining

**対応要件:** FR-CAL-001〜006

```text
Goal
観測モーメント、シミュレーションモーメント、構造パラメータ探索、cacheを持つ外側較正を実装してください。

Context
AGENTS.md、docs/MODEL_SPEC.mdの8節、docs/REQUIREMENTS.mdの6.10節を読んでください。

Constraints
- 低次元パラメータから開始。
- parameter boundsと識別limitを明示。
- candidate evaluationはdata/config/code/seed hashでcache。
- cache hitを古い不整合checkpointに使わない。
- full nested loopをCIで回さず、toy/smokeを用意。
- supervised pretraining有無をmanifestへ記録。

Implement
1. MomentDefinition registry。
2. data moments: frequency、size、duration、seasonality等。
3. simulated momentsとweighted distance。
4. bounded candidate generator（Sobol/Latin hypercube等）。
5. optional optimizer adapter、smokeはgrid/randomでよい。
6. PEPG inner run cache/checkpoint key。
7. supervised weightsからpolicy initialization adapter。
8. sensitivity summary、multiple starts。
9. toy environmentで既知parameter回復のsmoke test。
10. calibration report JSON/HTML fragment。

Done when
- toy parameterでdistanceが初期候補より改善。
- cache hit/missとcompatibilityがテストされる。
- weak identificationをwarning/reportへ出す。
- CIは短時間で完走。
- `make lint typecheck test test-smoke` が成功する。
```

---

## Task 12 — 政策シナリオ、効果分離、Shapley

**対応要件:** FR-SCEN-001〜007、AC-07

```text
Goal
型付き政策イベントを構造・CPI計算へ介入させ、direct/endogenous/second-round/totalを分離し、複数政策をShapley分解してください。

Context
AGENTS.md、docs/DATA_SPEC.mdの9節、docs/MODEL_SPEC.mdの10節、docs/TEST_PLAN.mdのT-SCEN/T-SHAPを読んでください。

Constraints
- baselineはorigin時点で既知の政策のみ。
- scenarioは原データを上書きしない。
- baseline/scenarioでcommon random numbers。
- direct effectは指数水準へ適用。
- 特徴量除去を政策効果と呼ばない。
- direct/endogenous/second-roundの固定対象をコードとmetadataで明示。
- exact/Monte Carlo Shapley、efficiency residualを出力。
- inconsistent dates/overlap/unitsを検証。

Implement
1. policy operator pure functions。
2. scenario operations add/remove/scale/shift/replace。
3. policy path builder respecting known/effective dates。
4. three counterfactual modes for effect separation。
5. CRN manager/hash。
6. exact Shapley and permutation Monte Carlo。
7. uncertainty/MC standard error for approximate Shapley。
8. synthetic subsidy + administered price fixtures。
9. T-SCEN、T-SHAP、IT-07。
10. CLI `scenario run` とscenario manifest。

Done when
- no-op scenario effect 0。
- decomposition identity合格。
- Shapley sumがgrand coalition差分と一致。
- policy announcement前のbaselineにイベントが入らない。
- same CRN IDが比較出力へ保存される。
- `make lint typecheck test test-smoke` が成功する。
```

---

## Task 13 — E2E nowcast、report、registry

**対応要件:** FR-CLI、FR-OUT、AC-08

```text
Goal
データsnapshotからnowcast、scenario、backtest、HTML reportまでを一貫したrun artifactとして実行できるようにしてください。

Context
AGENTS.md、docs/ARCHITECTURE.mdの6〜13節、docs/REQUIREMENTS.mdの6.14節、docs/TEST_PLAN.mdのIT-08を読んでください。

Constraints
- report生成時に再学習しない。
- run manifestにgit/config/data/model/seed/environmentを記録。
- dirty worktreeを記録し、既定では警告。
- JSON/Parquet出力はschemas/forecast_output.schema.jsonと一致。
- missing/vintage/model limitationsをreportから隠さない。
- CLI exit codesとdry-runを整備。

Implement
1. Ingestion/Feature/Training/Nowcast/Scenario/Backtest application servicesの配線。
2. artifact registryとcontent-based run ID。
3. CLI全サブコマンドの統一オプション。
4. prediction JSON/Parquet、metrics、diagnostics。
5. static HTML report: summary、fan/interval、contributions、policy effects、data quality、model limits。
6. model card/data card/run manifest生成。
7. fixture-only full E2E smoke。
8. idempotent rerunとcollision handling。
9. failure時のpartial artifact cleanup。
10. README quickstart/tutorial更新。

Done when
- fixtureのみでIT-08の全chainが完走。
- reportとmanifestが生成され、schema valid。
- 同じsnapshot/config/seedのrerunが再現可能。
- data qualityとvintage modeがreportに表示。
- `make lint typecheck test test-smoke backtest-smoke nowcast-smoke` が成功する。
```

---

## Task 14 — ハードニング、CI、独立レビュー

**対応要件:** 全NFR、リリースゲート

```text
Goal
全体をリリース可能な研究用MVPとしてハードニングし、仕様トレーサビリティと独立レビューを完了してください。

Context
AGENTS.md、docs/REQUIREMENTS.md、docs/TEST_PLAN.md、docs/TRACEABILITY_MATRIX.md、docs/CODE_REVIEW.mdをすべて読んでください。

Constraints
- 新機能を追加するタスクではない。
- failing testをskip/deleteしない。
- performanceのために時点整合性や数値精度を弱めない。
- 実行していないresearch benchmarkを成功と記載しない。
- 重大問題があれば修正前に一覧化する。

Implement/Review
1. 要件ID -> module -> testのtraceabilityを実ファイルへ更新。
2. coverageと未テストcritical pathsを確認。
3. future leakage、policy timing、CPI aggregation、PRNG、CRN、PEPGを独立レビュー。
4. dependency/license/security audit。
5. docsとCLI helpの整合。
6. packaging clean install test。
7. CPU performance smokeとmemory診断。
8. a fresh temporary directoryでE2E再現。
9. unresolved research risksとdeferred itemsを記録。
10. release checklistとversion tag候補を作る。

Done when
- `make fmt lint typecheck test test-smoke backtest-smoke nowcast-smoke` が成功。
- `uv build`とclean installが成功。
- traceabilityに空欄がないか、未実装は明示的deferred。
- Critical/High review findingsが0。残るMedium/Lowを記録。
- 完了報告に全コマンドの正確な結果、coverage、性能、制約、未解決リスクを含める。
```

## 15. 実データ接続フェーズ用の追加指示

Task 14後に、データセット単位で別タスクを作る。1回の依頼で複数省庁の全系列を実装させない。

テンプレート:

```text
Goal
公式の <dataset name> をcatalog-driven connectorへ追加し、<series list> を取得・ビンテージ保存できるようにしてください。

Context
公式仕様書と既存connectorを確認してください。実装前にseries metadata、release lag、revision policy、license、API authenticationを整理してください。

Constraints
- 公式一次情報だけを仕様根拠にする。
- series ID、unit、base yearを推測しない。
- credentialsは環境変数。
- parserは保存fixtureでテストする。
- live smokeは明示的markerで通常CIから除外する。
- past vintagesが取れない場合はquality B/Cを正確に付ける。

Done when
- fixture parseとschema drift testが成功。
- live取得を実施した場合は件数、期間、hashを報告。
- data cardとcatalogを更新。
- as-of queryとfuture leakage testに追加。
```
