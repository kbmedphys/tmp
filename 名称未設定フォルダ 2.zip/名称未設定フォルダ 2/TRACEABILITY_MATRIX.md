# 要件トレーサビリティ・マトリクス

実装開始時は`予定module/test`を実ファイルへ更新する。

| 要件群 | 主要仕様 | 予定module | 主テスト | Task |
|---|---|---|---|---|
| FR-DATA | DATA 2, 13 | `data/connectors`, `raw_store` | IT-01 | 02,03 |
| FR-VINT | DATA 4-6 | `data/vintage_store`, `features/asof` | T-VINT | 02 |
| FR-CPI | DATA 8, MODEL 3 | `cpi/*` | T-CPI | 04 |
| FR-POL | DATA 9, MODEL 10 | `policy/events`, `operators` | T-POL | 01,12 |
| FR-FEAT | DATA 10-11 | `features/*` | T-FEAT, IT-02 | 05 |
| FR-BENCH | MODEL 4 | `models/benchmarks` | IT-03 | 06 |
| FR-SUP | MODEL 5 | `models/supervised` | T-MOD, IT-04 | 07 |
| FR-ENV | MODEL 6 | `models/structural/environment` | T-ENV, IT-05 | 09 |
| FR-RL | MODEL 7 | `training/pepg`, `schedules` | T-PEPG, IT-06 | 10 |
| FR-CAL | MODEL 8 | `training/calibration` | calibration smoke | 11 |
| FR-ENS | MODEL 9 | `models/ensemble` | ensemble origin split | 08 |
| FR-SCEN | MODEL 10 | `policy/scenarios`, `shapley` | T-SCEN, T-SHAP | 12 |
| FR-EVAL | TEST 6-7 | `evaluation/*` | IT-03, strictness | 06,13 |
| FR-CLI/OUT | ARCH 8, 11 | `cli`, `registry`, `reporting` | IT-08 | 00,13 |
| NFR-REP | ARCH 10-11 | `registry`, RNG utilities | T-RNG | 00,10,13 |
| NFR-SEC | ARCH 16 | config/connectors/reporting | security unit tests | 00,01,03 |
| NFR-PERF | TEST 9 | numerical core | performance smoke | 14 |

## 受入基準とリリース

| AC | 完了Task | エビデンス |
|---|---|---|
| AC-01 | 00,14 | CI run、package build |
| AC-02 | 02,03 | vintage integration artifact |
| AC-03 | 04 | reconciliation report |
| AC-04 | 06,07 | smoke backtest metrics |
| AC-05 | 09 | deterministic rollout report |
| AC-06 | 10 | toy convergence plot/JSON |
| AC-07 | 12 | scenario decomposition fixture |
| AC-08 | 06,13 | strict backtest artifact |
| AC-09 | research phase | rolling research report |
