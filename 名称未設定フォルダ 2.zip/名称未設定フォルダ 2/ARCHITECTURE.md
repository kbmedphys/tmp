# ソフトウェア・アーキテクチャ仕様

文書ID: JIN-ARC-001  
版: 1.0

## 1. 技術スタック

- Python 3.11または3.12
- パッケージ・lock: `uv`
- 数値・ML: JAX、Flax、Optax
- 表データ: PyArrow、PolarsまたはPandas、DuckDB
- 設定・契約: Pydantic v2、YAML、JSON Schema
- CLI: Typer
- テスト: pytest、pytest-cov、Hypothesis
- 品質: Ruff、mypy
- レポート: Jinja2、MatplotlibまたはPlotly（HTMLは静的生成を優先）
- ログ: 標準loggingまたはstructlog

MVPでは単一デバイスを正とする。複数デバイスは抽象化を壊さない範囲で後から追加し、新規コードを`jax.pmap`前提にしない。

## 2. リポジトリ構成

```text
.
├── AGENTS.md
├── README.md
├── pyproject.toml
├── uv.lock
├── Makefile
├── configs/
├── schemas/
├── docs/
├── src/jp_inflation/
│   ├── __init__.py
│   ├── cli.py
│   ├── config/
│   ├── domain/
│   ├── data/
│   │   ├── connectors/
│   │   ├── raw_store.py
│   │   ├── vintage_store.py
│   │   ├── catalog.py
│   │   └── quality.py
│   ├── cpi/
│   │   ├── hierarchy.py
│   │   ├── weights.py
│   │   ├── aggregate.py
│   │   └── contributions.py
│   ├── policy/
│   │   ├── events.py
│   │   ├── operators.py
│   │   ├── scenarios.py
│   │   └── shapley.py
│   ├── features/
│   │   ├── asof.py
│   │   ├── transforms.py
│   │   ├── io_costs.py
│   │   └── builder.py
│   ├── models/
│   │   ├── base.py
│   │   ├── benchmarks/
│   │   ├── supervised/
│   │   ├── structural/
│   │   └── ensemble/
│   ├── training/
│   │   ├── checkpoints.py
│   │   ├── pepg.py
│   │   ├── calibration.py
│   │   └── schedules.py
│   ├── evaluation/
│   │   ├── origins.py
│   │   ├── backtest.py
│   │   ├── metrics.py
│   │   └── episodes.py
│   ├── reporting/
│   ├── registry/
│   └── utils/
├── tests/
│   ├── unit/
│   ├── property/
│   ├── integration/
│   ├── smoke/
│   └── fixtures/
└── artifacts/                 # gitignore
```

## 3. 依存方向

```text
cli/reporting -> application services -> domain interfaces
                                      -> data/model implementations

domain <- data
       <- cpi
       <- policy
       <- features
       <- models
```

原則:

- `domain` はJAX、DuckDB、Typerへ依存しない。
- `models` はコネクタへ依存しない。
- `cli` に計算ロジックを書かない。
- `reporting` は保存済みartifactを読み、再学習しない。
- JAX型はstructural/supervised内部に限定し、永続化境界ではNumPy/Arrowへ変換する。

## 4. ドメイン型

最低限のPydantic/dataclass型:

- `SeriesObservation`
- `ReleaseEvent`
- `CpiNode`
- `CpiWeight`
- `PolicyEvent`
- `ScenarioDefinition`
- `ForecastOrigin`
- `ForecastTarget`
- `ForecastDistribution`
- `RunManifest`
- `DataSnapshot`
- `ModelArtifact`
- `BacktestResult`

時刻型はtimezone-awareだけを許可する。

## 5. 設定

### 5.1 設定階層

```yaml
project:
data:
features:
cpi:
models:
  benchmarks:
  supervised:
  structural:
  ensemble:
training:
backtest:
scenario:
output:
```

### 5.2 検証

- YAMLを読み込んだ直後にPydantic検証。
- unknown fieldは既定でエラー。
- pathはconfig file基準またはproject root基準を一貫させる。
- secretsをYAMLへ書かない。
- 全設定をcanonical JSONへ変換してhash化。

### 5.3 profile

```text
smoke, dev, research, paper_scale
```

profileは個別値のshortcutであり、明示値が優先する。profileごとの解釈をテストする。

## 6. 保存層

### 6.1 RawArtifactStore

- content-addressed
- atomic write: temp -> fsync -> rename
- metadata JSON
- dedup by SHA-256

### 6.2 VintageStore

MVP: Parquet partition + DuckDB view。

partition例:

```text
silver/series_observations/source=<source>/series_group=<group>/year=<reference_year>/part-*.parquet
```

小規模時は単一DuckDB fileでもよいが、rawとsilverの責務を混ぜない。

### 6.3 Registry

```text
artifacts/runs/<run_id>/
  manifest.json
  config.resolved.yaml
  data_snapshot.json
  metrics.json
  predictions.parquet
  model/
  diagnostics/
  report.html
```

`run_id` は日時だけでなくcontent hashを含める。

## 7. アプリケーションサービス

### 7.1 IngestionService

```python
class IngestionService:
    def ingest(self, dataset_ids: list[str], as_of: datetime | None) -> IngestionSummary: ...
```

### 7.2 FeatureBuildService

```python
class FeatureBuildService:
    def build(
        self,
        origin: datetime,
        target_periods: Sequence[date],
        feature_set_id: str,
    ) -> FeatureArtifact: ...
```

### 7.3 TrainingService

```python
class TrainingService:
    def train(self, model_id: str, config: ModelConfig, snapshot: DataSnapshot) -> ModelArtifact: ...
```

### 7.4 NowcastService

```python
class NowcastService:
    def run(self, origin: datetime, model_set: Sequence[str]) -> ForecastRun: ...
```

### 7.5 ScenarioService

```python
class ScenarioService:
    def evaluate(
        self,
        baseline_run_id: str,
        scenario: ScenarioDefinition,
        seed: int,
    ) -> ScenarioRun: ...
```

### 7.6 BacktestService

```python
class BacktestService:
    def run(self, spec: BacktestSpec) -> BacktestArtifact: ...
```

## 8. CLI仕様

Typerサブコマンド:

```text
jp-inflation config validate --config <file>
jp-inflation data ingest --config <file> --dataset <id> [--as-of ...] [--dry-run]
jp-inflation data validate --config <file> [--snapshot ...]
jp-inflation features build --config <file> --as-of <timestamp>
jp-inflation model train --config <file> --model <id> [--profile smoke]
jp-inflation backtest run --config <file> --origins <spec> [--profile smoke]
jp-inflation nowcast run --config <file> --as-of <timestamp>
jp-inflation scenario run --config <file> --baseline <run_id> --scenario <yaml>
jp-inflation report build --run <run_id>
```

全コマンド:

- `--help`
- structured log
- non-zero exit code on validation/data/model failure
- `--dry-run`で予定された読み書き、対象系列、起点を表示
- resolved configとrun IDを最初にログ

## 9. JAX設計

### 9.1 PRNG

関数はkeyを引数で受け、使用後keyを返すか明示的にsplitする。

```python
def sample_shocks(key: PRNGKey, shape: Shape) -> tuple[PRNGKey, ShockPath]:
    next_key, draw_key = jax.random.split(key)
    return next_key, draw(draw_key, shape)
```

禁止:

- module global key
- 同じsubkeyの再利用
- NumPy randomとJAX randomの無秩序な混在

### 9.2 dtype

起動時にfloat64を有効化し、テストで確認する。整数IDをfloatへ暗黙変換しない。

### 9.3 shape contracts

例:

```text
items: I
horizon: H
paths: N
candidates: K
features: F

state.price_level             [N, I]
shock_path.cost               [H, N, I]
perturbations                 [K, P]
returns_plus_minus            [K, 2]
```

public関数docstringにshapeを記載する。

### 9.4 compilation

- data loading/validationはjitしない。
- pure numerical coreをjitする。
- static argsを最小化。
- iterationごとにshapeを変えない。
- 初回compile timeとsteady-state timeを分けて計測。

## 10. チェックポイント

保存内容:

- model parameters
- optimizer state
- normalization state
- schedule step
- PRNG root seedとfold-in strategy
- config hash
- data snapshot hash
- code commit
- training metrics

Flax serializationまたは安全なarray形式を用い、外部から任意pickleをロードしない。

再開時はconfig/data/code compatibilityを検証し、不一致は既定でエラー。明示的overrideだけ許す。

## 11. 実行マニフェスト

```json
{
  "run_id": "...",
  "created_at": "...",
  "command": "...",
  "git_commit": "...",
  "dirty_worktree": false,
  "python_version": "...",
  "platform": "...",
  "jax_backend": "cpu",
  "devices": ["..."],
  "config_hash": "...",
  "data_snapshot_hash": "...",
  "model_code_hash": "...",
  "seeds": {"root": 42, "training": 101, "simulation": 202},
  "vintage_quality_counts": {"A": 10, "B": 4, "C": 0}
}
```

依存環境は`uv.lock` hashと`pip freeze`相当を保存する。

## 12. エラー処理

カスタム例外:

- `ConfigurationError`
- `DataContractError`
- `VintageLeakageError`
- `PolicyValidationError`
- `AggregationError`
- `NumericalStabilityError`
- `CheckpointCompatibilityError`

エラーはseries/item/origin/run contextを含む。例外を握りつぶしてNaNを返さない。

## 13. ログと観測性

structured fields:

- `run_id`, `task`, `origin`, `model_id`
- row counts、min/max reference period
- vintage quality counts
- missing/staleness statistics
- compile time、step time、memory
- loss/reward/gradient norms
- scenario CRN ID

個別API token、raw personal path、秘密値をログしない。

## 14. CI

GitHub Actions等を想定。

必須job:

1. format check
2. lint
3. mypy
4. unit/property tests
5. smoke integration
6. package build
7. JSON Schema validation

CIはCPU、ネットワークなし。large/research testsはmarkerで除外するが、skip理由を明示する。

## 15. 性能方針

- 先に正しさと時点整合性を確立する。
- Arrow/Parquetで列選択・predicate pushdown。
- feature cacheはinput hashをキーにする。
- JAX rolloutはscan/vmap。
- profile-based batch sizing。
- OOM時にsilent batch reductionせず、明示的エラーと推奨値を出す。

## 16. セキュリティ・安全性

- YAML/JSONからevalしない。
- shell commandは引数配列で実行し、ユーザー文字列を連結しない。
- path traversalを検証。
- remote downloadにsize/content-type上限。
- source URL allowlistを設定可能にする。
- HTML reportで入力文字列をescape。
- dependenciesはlockし、脆弱性監査を運用へ追加可能にする。

## 17. ドキュメント

実装完了時に最低限:

- root README quickstart
- data catalog追加方法
- policy operator追加方法
- model plugin追加方法
- reproducible backtest tutorial
- scenario example
- model card/data card templates
- limitations
