# テスト・バックテスト・受入計画

文書ID: JIN-TST-001  
版: 1.0

## 1. 方針

本プロジェクトで最も重大な不具合は、数値誤差よりも、未来情報混入、ビンテージ誤用、政策既知時点の誤り、CPI集計の不整合である。これらを最上位テストとして扱う。

テスト層:

1. unit
2. property-based
3. integration
4. smoke end-to-end
5. pseudo-real-time backtest
6. numerical/research validation

CIはネットワークを使用しない。

## 2. Unit tests

### T-VINT-001 As-of選択

Given: 同一系列・同一reference periodに速報と改定値。  
When: 速報後・改定前のorigin。  
Then: 速報だけが返る。

### T-VINT-002 未来情報遮断

1. origin以前のデータでfeaturesを作る。
2. origin以後の値を極端な値へ変更する。
3. 同じoriginで再構築する。
4. feature hashが一致する。

### T-VINT-003 timestamp境界

`release_at == origin` は利用可能、`release_at > origin` は不可。timezone変換を含める。

### T-VINT-004 quality filter

strict modeでCを除外し、件数と警告が正しい。

### T-CPI-001 水準集計

小さな手計算fixtureで1e-10以内。

### T-CPI-002 contribution reconciliation

品目寄与合計＋residual＝aggregate change。

### T-CPI-003 weight version

基準改定月の前後で正しいweight versionを選択。

### T-CPI-004 hierarchy cycle

循環参照を拒否。

### T-POL-001 known/effective separation

発表済み・未施行、施行中、終了後を区別。

### T-POL-002 typed operator

各direct effect operatorの手計算値と一致。

### T-POL-003 unsafe expression rejection

任意Python式、未知operator、過剰値を拒否。

### T-FEAT-001 train-only scaling

test periodの極端値を変えてもscaler統計が変わらない。

### T-FEAT-002 missing/staleness

未公表、古い公表、当日公表を正しく符号化。

### T-MOD-001 quantile monotonicity

出力分位点が非減少。

### T-MOD-002 two-part mixture moments

既知パラメータでサンプル平均・zero massが理論値に近い。

### T-ENV-001 action constraints

adjustは0/1、magnitudeは範囲内、NaNなし。

### T-ENV-002 transition identity

行動・政策・shockがゼロなら価格水準不変。

### T-ENV-003 administered rule

制度価格fixtureが料金式通り。

### T-RNG-001 deterministic replay

同じconfig/snapshot/seedで同じrollout。

### T-RNG-002 key non-reuse instrumentation

テスト用key trackerまたはfold-in規則で同一用途subkeyの重複を検知。

### T-PEPG-001 antithetic construction

`theta_plus - mu == -(theta_minus - mu)`。

### T-PEPG-002 common shocks

正負pairが同じshock path hashを持つ。

### T-PEPG-003 toy quadratic

`R(theta) = -||theta - theta_star||^2` で距離が減少。

### T-PEPG-004 schedule endpoint

sigma/entropy/epsilonが指定stepでfloorまたは0。

### T-SCEN-001 no-op

空シナリオの全効果が数値許容誤差内でゼロ。

### T-SCEN-002 decomposition identity

Direct + Endogenous + SecondRound = Total。

### T-SHAP-001 exact efficiency

Shapley合計＝grand coalition差分。

### T-SHAP-002 symmetric policies

同一価値を持つ2政策のShapleyが同じ。

## 3. Property-based tests

Hypothesisで生成する。

- 任意正ウェイトと正指数の集計値は子のmin/max内
- softmax出力は非負・合計1
- policy期間外のdirect effectは0
- as-of結果に`release_at > origin`が存在しない
- scenario remove後に同じevent IDが有効集合へ残らない
- quantile projection後の順序
- serialization round trip
- CPI hierarchy topological ordering

## 4. Integration tests

### IT-01 Ingest to vintage query

fixture原本 -> parse -> raw/bronze/silver -> as-of query。

### IT-02 Feature build

複数系列・ragged edge・政策イベント -> feature artifact。

### IT-03 Benchmark backtest

3 origins × 2 horizons × 2 aggregateで完走し、結果schema検証。

### IT-04 Supervised smoke

小さな合成item panelで2 epoch学習、loss finite、予測schema有効。

### IT-05 Structural rollout

4レジームを含む合成環境でrollout、constraints、diagnostics保存。

### IT-06 PEPG smoke

smoke profileで数iteration、checkpoint save/load/replay。

### IT-07 Scenario

補助金イベントをremoveし、直接・内生・総効果を生成。

### IT-08 End-to-end CLI

```text
ingest -> build-features -> train benchmark -> backtest -> nowcast -> report
```

ネットワークなし、temporary directoryで実行。

## 5. 数値テスト

- float64有効確認
- finite differencesとPEPG gradient方向のcosine similarity（toy）
- large/small price levelでoverflowなし
- Student-t scale floor
- near-zero sigmaで0除算を拒否
- JIT/non-JITの結果一致
- vectorized/non-vectorized reference実装一致
- checkpoint前後一致

許容誤差はdtypeと演算に応じ個別に定義し、広い`rtol=1e-2`を一律使用しない。

## 6. Backtest設計

### 6.1 Origin

`ForecastOrigin` はtimestamp。代表stageを設定で生成できるが、実際のrelease timestampsからfeature可用性を決める。

### 6.2 Split

- expanding window
- rolling window
- minimum train months
- validation block
- test origins
- embargoが必要なtransformにはgap

ランダムsplitは禁止。

### 6.3 Strictness

```yaml
vintage_mode: strict | broad | latest_only_diagnostic
```

- strict: A/Bの実際のビンテージ
- broad: 品質Cを許すがラベル付与
- latest_only_diagnostic: 実運用成績とは別表

### 6.4 Horizons/targets

- h=0当月、1、3、6、12
- mom、yoy、index level
- CPI総合、指定除外系列、群別

### 6.5 Metrics

点予測:

- MAE
- RMSE
- MASE
- bias
- directional accuracy

分布:

- CRPS
- log score
- pinball loss
- 50%/90% coverage
- interval width
- PIT diagnostics

分解:

- item contribution MAE
- direct policy effect timing/sign
- aggregate reconciliation residual

### 6.6 比較

- 同じorigin/targetを持つpaired lossだけを比較
- DM test等は補助的
- small sampleではblock bootstrap confidence interval
- performance by inflation regime、policy episode、release stage

## 7. Leave-episode-out

設定例:

```yaml
episodes:
  - id: consumption_tax_change
    start: 2019-08-01
    end: 2020-01-31
  - id: education_free_program
    start: 2019-09-01
    end: 2020-03-31
  - id: mobile_fee_change
    start: 2021-02-01
    end: 2021-08-31
  - id: energy_support
    start: 2023-01-01
    end: 2026-12-31
```

正確な日付・対象はデータ作成時に公式文書で確定する。episodeを学習から丸ごと除外し、一般化を測る。

## 8. Acceptance test mapping

| Acceptance | 主テスト |
|---|---|
| AC-01 | CI jobs、IT-08 |
| AC-02 | T-VINT-001〜004、IT-01 |
| AC-03 | T-CPI-001〜004 |
| AC-04 | IT-03、IT-04、T-MOD-001 |
| AC-05 | T-ENV-001〜003、T-RNG-001 |
| AC-06 | T-PEPG-001〜004、IT-06 |
| AC-07 | T-SCEN、T-SHAP、IT-07 |
| AC-08 | Backtest strictness tests、IT-03 |
| AC-09 | research backtest report |

## 9. Performance tests

CI外またはnightly:

- smoke E2E CPU 10分目標
- trained MVP nowcast CPU 60秒目標
- rollout throughput paths/sec
- feature build peak memory
- compile vs steady-state time
- checkpoint size/load time

性能退行の閾値は安定したbaseline取得後に固定する。

## 10. Failure injection

- API timeout/500/partial body
- corrupt raw file
- duplicate vintage
- delayed release
- missing policy source
- NaN upstream series
- invalid weight sum
- disk full simulation where feasible
- interrupted atomic write
- incompatible checkpoint

partial successを明示し、commit境界を検証する。

## 11. Model validation report

各research runで自動生成:

- data coverage/vintage quality
- feature availability by origin
- baseline comparison
- calibration and coverage
- item/sector residuals
- policy episode results
- structural moments
- PEPG convergence diagnostics
- sensitivity
- limitations

## 12. リリースゲート

### MVP-alpha

- Task 00〜08
- strict vintage fixture E2E
- benchmarks + supervised nowcast
- structural/RLはinterfaceのみでも可

### MVP-beta

- Task 09〜12
- structural rollout、PEPG、scenario、Shapley
- model card/data card

### Research release

- real public data ingestion
- documented vintage quality
- rolling backtest
- sensitivity/episode validation
- reproducible artifact bundle
