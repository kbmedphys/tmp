# ドキュメント解説要求

**User:** Anonymous  
**Created:** 6/30/2026 23:50:39  
**Updated:** 7/1/2026 0:32:36  
**Exported:** 7/1/2026 0:34:17  
**Link:** [https://chatgpt.com/c/6a43d7bc-adb8-83e8-96cf-b1ede9024a47](https://chatgpt.com/c/6a43d7bc-adb8-83e8-96cf-b1ede9024a47)  

## Prompt:
2026/6/30 23:50:35

添付のドキュメントについて内容を詳細に解説してください。実装を前提に必要なデータ要件を明らかにすること

[Attachment: 2606.25811v1.pdf]

## Response:
2026/6/30 23:50:41

以下は添付PDF *Hierarchical Graph Learning for Calendar Spread Strategies in Commodity Futures Markets* に基づく解説です。`2606.25811v1.pdf`

## 1. 論文の主題

この論文は、**商品先物市場におけるカレンダー・スプレッド（Calendar Spread; CS）戦略**を、**満期依存の階層グラフ学習（Hierarchical Graph Learning; HGL）**で構築する手法を提案しています。

問題意識は明確です。既存の機械学習ベースの先物取引研究は、単一限月の方向予測、上位銘柄選択、クロスコモディティのロング・ショートなどが中心で、同一コモディティの異なる限月を売買するカレンダー・スプレッドを本格的に扱っていません。また、商品先物間の関係は満期までの期間、すなわち TTM（time to maturity）に依存するにもかかわらず、既存のグラフ学習研究ではこの満期依存性を十分に区別していない、という立場です。`2606.25811v1.pdf`

本論文の提案は、商品を上位ノード、個別先物契約を下位ノードとする**二層グラフ**を作り、さらにコモディティごとに異なる満期グリッドを仮想的な共通 TTM グリッドに持ち上げることで、同じ TTM の異なる商品間の情報伝播と、同一商品の近接限月間の情報伝播を分けて学習する、というものです。`2606.25811v1.pdf`

---

## 2. カレンダー・スプレッド戦略の位置づけ

カレンダー・スプレッドとは、**同一の商品を原資産とする複数の先物限月の間でロングとショートを組み合わせる戦略**です。論文では、ある商品 $c$ について、限月集合に対するポジション重みベクトル $w_{tcd}$ が

$$
\sum_d w_{tcd}=0,\qquad \|w_{tc}\|_1=1
$$

を満たすものを CS 戦略と定義しています。つまり、同一商品内でネット方向エクスポージャーをゼロにしつつ、ロング側とショート側の総量が対称になる構造です。`2606.25811v1.pdf`

論文が CS を重視する理由は、商品先物の価格変動が大きく分けて

$$
F_{tcd}=S_{tc}\exp(Q_{tcd}(T_{cd}-t))
$$

のように、スポット商品価格 $S_{tc}$ とキャリー・コスト項に分解できるためです。単純なロング・オンリー戦略はスポット商品価格の方向リスクに強く晒されます。一方、同一商品内の異なる限月をロング・ショートする CS は、スポット価格の共通成分を相殺し、相対的なタームストラクチャー変化を狙いやすい、という整理です。論文ではスポットデルタを、原資産価格リスクへのエクスポージャーとして定義しています。`2606.25811v1.pdf`

---

## 3. 理論的主張：なぜ CS が有利になり得るのか

論文の理論部分は、CS 戦略がロング・オンリー（LO）戦略よりも有利になり得る条件を三つの命題で示しています。

**命題1**は、同一商品内の先物リターン同士の相関が十分に正であれば、CS 戦略の分散は LO 戦略より低くなり得る、というものです。商品先物の各限月は同じスポット価格成分を共有するため、同一商品内の限月間リターンは正相関になりやすい。この共通変動をロング・ショートで相殺するため、CS の分散が低くなりやすい、という直観です。

**命題2**は、ある LO ポートフォリオが等ウェイトの非情報戦略を十分に上回る予測力を持つなら、その LO 重みを商品内でデミーンして CS 重みに変換したものは、LO より高い情報比率を持ち得る、という主張です。これは後述する「予測値を商品内で平均控除して CS ポジションに変換する」操作の理論的裏づけになっています。

**命題3**は、CS 戦略はスポット価格へのデルタ・エクスポージャーを LO より低くできる、というものです。特に各限月のデルタのレンジが極端でなければ、CS は LO より原資産方向リスクが小さいと論じています。実証では、命題1に関する条件が平均 81.109%、命題3に関する条件が 99.976% の $(t,c)$ ペアで成立しており、図3ではその充足率のローリング推移が示されています。`2606.25811v1.pdf`

---

## 4. 予測対象：なぜ通常リターンではなく、商品内デミーン・リターンを予測するのか

モデルのターゲットは、通常の先物リターン

$$
R_{tcd}=\frac{F_{tcd}}{F_{t-1,cd}}-1
$$

ではありません。論文では、商品 $c$ の中で平均を引いた

$$
R^\circ_{tcd}=R_{tcd}-R^\bullet_{tc}
$$

を使います。ここで $R^\bullet_{tc}$ は同一商品内の対象限月の平均リターンです。そのうえで、この $R^\circ_{tcd}$ を横断面 CDF に通し、さらに標準正規分位関数 $\Phi^{-1}$ で変換したものを予測ターゲット

$$
Y_{tcd}=\Phi^{-1}(\widehat{\mathrm{cdf}}(R^\circ_{tcd}))
$$

としています。`2606.25811v1.pdf`

この設計は、実装上かなり重要です。CS ポートフォリオでは各商品内の重み和がゼロなので、

$$
\sum_d w_{tcd}R_{tcd}
=
\sum_d w_{tcd}(R_{tcd}-R^\bullet_{tc})
$$

が成り立ちます。したがって、CS の PnL を作るうえでは通常リターンそのものではなく、商品内デミーン後の相対リターンを予測すれば十分です。論文は、この変換によって原資産方向リスクが減り、予測対象が安定しやすいと説明しています。`2606.25811v1.pdf`

---

## 5. 予測値から CS ポジションへの変換

モデルが各契約 $(c,d)$ に対して予測値 $\hat{Y}_{tcd}$ を出した後、次の操作で CS ウェイトを作ります。

まず商品ごとに予測値の平均を引きます。

$$
\hat{Y}^\circ_{tcd}
=
\hat{Y}_{tcd}
-
\hat{Y}^{\bullet}_{tc}
$$

次に全体の $L^1$ ノルムで割ります。

$$
w_{tcd}
=
\frac{\hat{Y}^\circ_{tcd}}
{\|\hat{Y}^\circ_t\|_1}
$$

この操作により、各商品内で

$$
\sum_d w_{tcd}=0
$$

が成立し、全体で

$$
\|w_t\|_1=1
$$

となります。論文の付録では、この商品内平均控除が、CS 制約集合へのユークリッド射影に相当することも示しています。`2606.25811v1.pdf`

実装上の直観は単純です。同一商品内で、モデルが相対的に上がると見た限月をロングし、相対的に下がると見た限月をショートする。商品全体の方向感は捨て、限月間の相対価格変化だけを取りに行く構造です。

---

## 6. HGL モデルの構造

### 6.1 二層グラフ

論文の図1、9ページに示されている通り、グラフは上位層と下位層から成ります。上位層のノードは Silver、Gold、Corn、Gas のような商品そのもの、下位層のノードは各商品の個別先物契約です。上位ノード間には商品間の正・負の相関エッジ、上位ノードと下位ノードの間には商品とその契約を結ぶエッジ、下位ノード間には同一商品の近接限月を結ぶエッジがあります。`2606.25811v1.pdf`

この設計により、モデルは以下の三種類の情報を扱います。

| 関係 | 意味 | 実装上の役割 |
|---|---|---|
| 商品間エッジ $E^{CC+},E^{CC-}$ | 商品同士の正・負の相関 | 例：エネルギー間、農産物間、代替・補完関係 |
| 商品-契約エッジ $E^{CU},E^{UC}$ | 商品ノードと各限月契約ノードの接続 | 上位・下位階層の情報変換 |
| 契約間エッジ $E^{UU}$ | 同一商品内の近接限月接続 | タームストラクチャーの局所的形状を学習 |

### 6.2 グラフ・リフティング：満期グリッドを揃える

商品先物では、すべての商品が同じ満期日を持つわけではありません。例えば、原油、金、トウモロコシでは上場限月や満期日の構造が異なります。そのままでは「同じ 3 カ月 TTM の原油と金」を直接比較できません。

そこで論文は、各商品について仮想的な TTM グリッド

$$
\tau_j=j\cdot \frac{\tau^{max}}{n^{bas}}
$$

を作り、各商品の先物契約表現をこの共通 TTM グリッド上の仮想先物ノードへ線形補間します。実験では $\tau^{max}=1$ 年、$n^{bas}=52$、つまり週次相当の仮想 TTM グリッドを使っています。`2606.25811v1.pdf`

このリフティングが本論文の肝です。これにより、「同じ TTM の異なる商品間」では商品間グラフ畳み込みを行い、「同一商品の近接 TTM 間」ではタームストラクチャー方向の畳み込みを行えます。

### 6.3 二層畳み込み

図2、11ページでは、各畳み込み層が四つの操作で構成されることが示されています。

$$
f^B_{kl}
=
g^{UU}_{kl}
\circ
g^{CU}_{kl}
\circ
g^{CC}_{kl}
\circ
g^{UC}_{kl}
$$

処理順序は次の通りです。

1. $g^{UC}$：下位の実契約ノードの埋め込みを、上位の仮想 TTM ノードへ持ち上げる。  
2. $g^{CC}$：同じ TTM にある異なる商品間で情報を伝播する。  
3. $g^{CU}$：上位の仮想 TTM ノードから、実契約ノードへ情報を戻す。  
4. $g^{UU}$：同一商品内の近接限月間で、タームストラクチャーの相対的な歪みを学習する。  

この構造により、HGL は「異なる商品間の情報」と「同一商品内の限月構造」を別々のパラメータで扱います。論文は、既存 GNN が満期差を区別せず、すべての先物契約関係を汎用的なエッジとして扱う点を問題視し、HGL では満期依存性を明示的に組み込んでいると説明しています。`2606.25811v1.pdf`

特に $g^{UU}$ では、対象限月と近接限月の埋め込み差分を LayerNorm してメッセージを作るため、同一商品のタームストラクチャー上の相対的な歪み、例えば近月だけ割高、遠月だけ割安といった形状を捉える設計になっています。`2606.25811v1.pdf`

---

## 7. 実証設計と結果

データは LSEG Datastream を WRDS 経由で取得した日次商品先物データです。期間は 1977年8月から 2025年12月までで、CME、CBOT、NYMEX、COMEX、eCBOT に上場され、米ドル建てで取引される先物契約を対象としています。`2606.25811v1.pdf`

ベンチマークは Ridge、LightGBM、MLP、通常 GNN です。さらに、アブレーションとして、商品間情報を除いた A1、同一商品内タームストラクチャー情報を除いた A2 を使っています。表1、14ページでは、GNN 系の畳み込みとして GCN、GraphSAGE、GAT を試し、パラメータ数、相関閾値、畳み込み層数などをグリッドサーチしています。`2606.25811v1.pdf`

主要結果は表2、15ページにまとまっています。HGL の CS 戦略は、日次 IR 0.08459、Sortino ratio 0.12409、平均日次リターン 0.01036%、日次ボラティリティ 0.12249%、最大ドローダウン 0.02002、S&P 500 との相関 -0.01850 を示しています。Ridge、MLP、LightGBM、通常 GNN、LO ベースライン、等ウェイト戦略と比較して、リスク調整後リターンとドローダウン面で優位です。表2の注記では、論文のリターンは単位マージン仮定の下で報告されており、実際の先物マージンを考慮すると名目上の資本効率は大きく変わる可能性があることも示されています。`2606.25811v1.pdf`

予測性能でも、表3では HGL の MSE が 1.125511 と最も低く、表4では HGL と各ベンチマークの MSE 差が統計的に有意と報告されています。論文は、HGL が非グラフモデルを上回ることから商品先物間関係が有用であり、通常 GNN も上回ることから TTM 依存性を明示的に扱うことが重要だと結論づけています。`2606.25811v1.pdf`

図4、15ページの累積 PnL では、HGL の曲線が他モデルより安定して右肩上がりであり、2020年と2022年にジャンプが見られます。論文は、それぞれ COVID-19 とロシア・ウクライナ戦争に関連する可能性を示唆しています。`2606.25811v1.pdf`

---

# 8. 実装を前提にしたデータ要件

ここからは、実際にこのモデルを実装する場合に必要なデータ要件を整理します。

## 8.1 最低限必要なデータ

この論文の HGL を再現するために最低限必要なのは、**個別先物契約レベルの日次価格・出来高・満期情報**です。連続先物だけでは不十分です。限月間の相対構造を学習するため、各商品について複数限月の同時点データが必要です。

| データカテゴリ | 必須フィールド | 用途 |
|---|---|---|
| 商品マスター | 商品ID $c$、商品名、セクター、取引所、通貨、価格単位 | 上位ノード構築、商品内集計 |
| 契約マスター | 契約ID $d$、ティッカー、商品ID、限月、満期日 $T_{cd}$、最終取引日、上場日、取引所 | 下位ノード構築、TTM 計算、満期フィルタ |
| 日次価格 | 日付、契約ID、清算値または終値 $F_{tcd}$ | リターン、特徴量、ラベル計算 |
| 日次出来高 | 日付、契約ID、出来高 $V_{tcd}$ | 流動性フィルタ、観測可能契約判定 |
| 取引カレンダー | 日付、営業日フラグ、取引所、時刻 | $t$ インデックス、EOD 推論、満期判定 |
| 単位・通貨情報 | 価格単位、数量単位、通貨、換算係数 | 商品間比較、価格スケール統一 |

論文の実装では、契約が直近 $n^{min}_{sam}$ 日すべてで取引されていることを流動性条件として使います。実験では $n^{min}_{sam}=28$ です。また、満期までの期間が $\tau^{max}=1$ 年以内であり、ポジションを $t+2$ に解消できることもユニバース条件に含まれます。`2606.25811v1.pdf`

---

## 8.2 契約マスターの品質要件

このモデルでは TTM が非常に重要なので、**満期日データの精度**が実装品質を大きく左右します。

論文の付録Cでは、LSEG Datastream の `LastTrdDate` を初期的な満期推定に使いつつ、契約月情報 `ContrDate` と大きく乖離する場合には、次の順で置換しています。

1. `EndDate`
2. `MaxDate`
3. `AppContrDate`

`MaxDate` は価格出来高テーブル上で実際に最後に取引された日、`AppContrDate` は同一商品の履歴的な満期差分から近似した満期日です。また、価格単位が異なる契約については `CurrUnitCode` に基づき単位換算を行い、一部の異常スケールについては追加的にリスケールしています。`2606.25811v1.pdf`

したがって、実装では少なくとも次のチェックが必要です。

| チェック | 内容 |
|---|---|
| 満期日整合性 | 最終取引日、契約月、実取引最終日が極端に矛盾していないか |
| 単位整合性 | セント建て、ドル建て、バレル、ガロン、ブッシェル等の単位差を補正したか |
| 通貨統一 | 論文は米ドル建て契約を対象。複数通貨に拡張するなら FX 換算が必要 |
| サバイバーシップ | 失効済み契約、上場廃止契約を含めた履歴があるか |
| 重複ティッカー | データベンダーのロール後ティッカー、旧ティッカー、リネームを処理したか |

---

## 8.3 日次価格・出来高データの要件

論文の特徴量は、直近 $n^{min}_{sam}$ 日のログ価格から作られます。実験値では 28 営業日分です。

各日 $t$、契約 $(c,d)$ について必要な原データは、

$$
F_{tcd}>0,\qquad V_{tcd}\ge 0
$$

です。リターン計算には連続する二日分の価格が必要で、観測可能契約集合は

$$
V_{tcd}V_{t-1,cd}>0
$$

で定義されます。`2606.25811v1.pdf`

本番実装では、論文のデータに加えて、次のフィールドも持つべきです。

| フィールド | 理由 |
|---|---|
| Open interest | 出来高だけでは建玉の厚みがわからない |
| Bid/ask または日中 quote | スプレッド、スリッページ、執行可能性評価に必要 |
| Settlement flag | 清算値が暫定値か確定値かを区別 |
| Contract multiplier | ポートフォリオ重みを実際の枚数に変換するため |
| Tick size / tick value | 最小価格変動、丸め、取引コスト評価 |
| Initial / maintenance margin | 資本使用量、レバレッジ、リスク制約 |
| Spread margin | CS は通常アウトライトより証拠金が低い可能性があるため |
| Exchange fee / brokerage | 論文では取引コストを無視しているため、本番では必須 |

論文自身も、限月別マージンや取引コストはデータ制約のため扱っておらず、将来課題としています。`2606.25811v1.pdf`

---

## 8.4 特徴量生成に必要な派生データ

HGL のノード特徴量 $X_t$ は、単純な過去リターン列ではありません。直近 $n^{min}_{sam}$ 日のログ価格に対して、商品内で二方向の中心化を行います。

具体的には、各商品 $c$ の中で、

1. 契約ごとの平均ログ価格を引く  
2. 日付ごとの平均ログ価格を引く  
3. 商品内全体平均を足し戻す  
4. 商品内標準偏差でスケールする  
5. 最後に横断面 CDF → 標準正規分位へ変換する  

という処理です。論文はこれを two-way ANOVA-style centering と表現しており、商品ごとの価格水準差を除去し、限月方向・時系列方向の相対構造を取り出します。`2606.25811v1.pdf`

実装上は、各日 $t$ で次のような特徴量テーブルを作るとよいです。

| キー | 値 |
|---|---|
| `asof_date` | 推論時点 $t$ |
| `commodity_id` | $c$ |
| `contract_id` | $d$ |
| `ttm_days` | $T_{cd}-t$ |
| `x_0 ... x_27` | 直近28日の正規化済み特徴量 |
| `selected_universe_flag` | $U_{t+2}$ に入るか |
| `sigma_x` | 商品内スケール値 |
| `data_quality_flag` | 欠損、異常値、単位補正など |

CDF 変換は端点で $\Phi^{-1}(0)$ や $\Phi^{-1}(1)$ が発散し得るため、実装では $[10^{-6},1-10^{-6}]$ などにクリップするのが安全です。論文でも小さい $\epsilon$ を入れた経験 CDF を定義しています。

---

## 8.5 ラベル生成に必要なデータ

学習ラベルは $t+2$ の商品内デミーン・リターンです。日 $t$ に特徴量を作り、モデルは $t+1$ から $t+2$ の価格変化を予測します。

ラベル生成には次のデータが必要です。

$$
R_{t+2,cd}
=
\frac{F_{t+2,cd}}{F_{t+1,cd}}-1
$$

ただし、$t+1$ と $t+2$ の両方で出来高が正であり、観測可能な契約だけを使います。論文では、$U_{t+2}$ は $t$ 時点で決めるため、実際には $t+1,t+2$ に観測不能になる契約があり得る。そのため、学習・評価では $U_{t+2}\cap \tilde{U}_{t+2}$ を使うとしています。`2606.25811v1.pdf`

実装上のラベルテーブルは次のようになります。

| キー | 値 |
|---|---|
| `feature_asof_date` | $t$ |
| `return_date` | $t+2$ |
| `entry_date` | $t+1$ |
| `exit_date` | $t+2$ |
| `commodity_id` | $c$ |
| `contract_id` | $d$ |
| `raw_return` | $R_{t+2,cd}$ |
| `demeaned_return` | $R^\circ_{t+2,cd}$ |
| `target_y` | $\Phi^{-1}(\widehat{cdf}(R^\circ))$ |
| `observable_flag` | $U_{t+2}\cap \tilde{U}_{t+2}$ に属するか |

---

## 8.6 グラフ構築に必要なデータ

HGL の実装では、日次で動的グラフを作ります。必要なエッジは三種類です。

### 商品間エッジ

商品間エッジは、満期を揃えた商品間のデミーン・リターン相関で作ります。相関が $\rho^\*$ 以上なら正のエッジ、$-\rho^\*$ 以下なら負のエッジです。相関推定には、異なる商品の満期グリッドが揃っていないため、リターンを満期方向に線形補間して maturity-aligned pair を作ります。`2606.25811v1.pdf`

必要データは以下です。

| データ | 用途 |
|---|---|
| 各商品の各限月リターン | 相関計算 |
| 各契約の満期日 | TTM アラインメント |
| 商品内デミーン・リターン | ターゲットと整合した相関計算 |
| 過去全履歴またはローリング履歴 | Pearson 相関推定 |
| 最低サンプル数 | $n^{min}_{sam}$ 未満なら相関ゼロ扱い |

### 商品-契約エッジ

これは単純で、商品 $c$ と、その商品に属する契約 $(c,d)$ を結ぶエッジです。双方向、すなわち $E^{CU}$ と $E^{UC}$ が必要です。

### 同一商品内の近接限月エッジ

各商品について、満期順に契約を並べ、各契約を一つ短い限月、一つ長い限月と結びます。最短限月と最長限月は片側だけの接続になります。これはタームストラクチャー方向の局所構造を学習するために使います。`2606.25811v1.pdf`

---

## 8.7 実運用に必要なポジション変換データ

論文上のウェイト $w_{tcd}$ は、先物リターンに対する抽象的なポートフォリオ重みです。本番ではこれを実際の契約枚数に変換する必要があります。

必要データは以下です。

| データ | 用途 |
|---|---|
| 契約価格 $F_{t+1,cd}$ | エントリー価格 |
| 契約倍率 | 1枚あたりノーション計算 |
| 最小取引単位 | 枚数丸め |
| 証拠金 | 資本使用量、レバレッジ制御 |
| スプレッド証拠金 | CS の資本効率評価 |
| tick size / tick value | PnL、丸め誤差、コスト計算 |
| bid/ask または執行価格 | 実現可能なエントリー・エグジット価格 |
| 取引手数料 | ネット PnL |
| 限月別取引停止・納会ルール | デリバリー回避 |

枚数変換の一例は、

$$
q_{tcd}
=
\mathrm{round}
\left(
\frac{w_{tcd}\cdot G}
{F_{t+1,cd}\cdot \mathrm{multiplier}_{cd}}
\right)
$$

です。ここで $G$ は総グロス・ノーションです。ただし、実際には証拠金制約、商品別リスク上限、取引所別上限、流動性上限を同時に満たすように最適化またはスケーリングする必要があります。

---

## 8.8 バックテストで特に注意すべき点

論文の売買タイミングは以下です。

1. $t$ の引け後に、$t$ までの履歴 $\mathcal{H}_t$ だけを使って $t+2$ の予測を作る。  
2. $t+1$ にポジションを構築する。  
3. $t+2$ に清算する。  

モデルは再学習日 $t_k$ に、そこまでの履歴だけで学習されます。学習・検証データも将来データを使わないように設計されています。`2606.25811v1.pdf`

実装では以下を厳格に管理するべきです。

| 論点 | 実装ルール |
|---|---|
| ルックアヘッド | $U_{t+2}$、特徴量、エッジ、相関はすべて $t$ 時点で利用可能なデータのみで作る |
| 契約満期 | $t+2 \le T_{cd}$ だけではなく、本番では納会・現物受渡リスクを避けるため追加バッファが望ましい |
| 流動性 | 論文は出来高 > 0 を条件にするが、本番では ADV、OI、bid/ask、参加率制限を追加する |
| コスト | 論文の主要実験は取引コストなし。高ターンオーバー戦略なのでコスト控除後の検証が必須 |
| 欠損 | 欠損を前方補完するとリターン・出来高条件を歪めるため、原則として観測不能扱いにする |
| 単位補正 | 商品間グラフでは価格スケール差が致命的なので、単位・通貨・倍率の検証が必要 |

---

## 9. 推奨される実装用データマート

実装するなら、少なくとも次のテーブル構成に分けるのがよいです。

| テーブル | 主キー | 内容 |
|---|---|---|
| `commodity_master` | `commodity_id` | 商品名、セクター、取引所、通貨 |
| `contract_master` | `contract_id` | 商品ID、限月、満期日、最終取引日、契約倍率、価格単位 |
| `daily_contract_market` | `date, contract_id` | 清算値、出来高、建玉、bid/ask、データ品質フラグ |
| `trading_calendar` | `date, exchange` | 営業日、引け時刻、休日 |
| `universe_snapshot` | `asof_date, contract_id` | $U_{t+2}$ 採用可否、TTM、流動性判定 |
| `features_hgl` | `asof_date, contract_id` | $X_t$ のベクトル、標準化パラメータ |
| `labels_hgl` | `asof_date, contract_id` | $R$、$R^\circ$、$Y$、観測可能フラグ |
| `graph_edges` | `asof_date, edge_type, src, dst` | 商品間、商品-契約、契約間エッジ |
| `predictions` | `asof_date, model_id, contract_id` | $\hat{Y}_{t+2,cd}$ |
| `positions` | `trade_date, model_id, contract_id` | ウェイト、枚数、エントリー価格、エグジット価格 |
| `cost_margin` | `date, contract_id` | 証拠金、手数料、スリッページ推定 |

---

## 10. 実装上の最小仕様

論文に近い形で MVP を作るなら、以下の仕様で十分です。

| 項目 | MVP 仕様 |
|---|---|
| 頻度 | 日次 EOD |
| ユニバース | CME Group 系商品先物、米ドル建て、個別契約ベース |
| 最大 TTM | 1年 |
| 過去特徴量長 | 28営業日 |
| 仮想 TTM グリッド | 52点、週次相当 |
| ラベル | $t+1$ から $t+2$ の商品内デミーン・リターンの正規スコア |
| 特徴量 | 直近28日のログ価格を商品内 two-way centering し正規スコア化 |
| 商品間エッジ | maturity-aligned demeaned returns の Pearson 相関、閾値 $\rho^\*$ |
| 限月間エッジ | 同一商品の隣接限月 |
| 学習 | 年次または四半期ごとの再学習 |
| 売買 | $t$ 引け後予測、$t+1$ エントリー、$t+2$ エグジット |
| ポジション | 商品内平均控除 + $L^1$ 正規化 |
| 評価 | IR、Sortino、Hit ratio、Vol、MDD、Turnover、コスト控除後 PnL |

---

## 11. この論文を実装する際の最大の落とし穴

最も重要な落とし穴は、**連続先物データで代替しようとすること**です。このモデルは、同一商品内の複数限月の相対構造と、異なる商品間の同一 TTM 比較を学習するため、個別契約レベルの価格・出来高・満期データが必須です。

次に重要なのは、**満期日と単位補正の品質**です。TTM がずれると、グラフ・リフティングで誤った仮想満期ノードに情報が流れます。価格単位がずれると、特徴量やリターン、相関推定が歪みます。論文が付録Cで満期日置換と価格単位補正を詳しく扱っているのは、この点が実証上クリティカルだからです。`2606.25811v1.pdf`

最後に、**論文の成績は取引コストと実際の証拠金制約を完全には含んでいない**点に注意が必要です。表2ではターンオーバーも報告されていますが、本番では bid/ask、手数料、スプレッド証拠金、限月別流動性、枚数丸めを入れたうえで、ネット IR を再評価する必要があります。`2606.25811v1.pdf`

---

## 12. まとめ

この論文の本質は、商品先物を「商品 × 満期」の二次元構造として扱い、CS 戦略に適した相対リターン予測問題へ変換した点です。カレンダー・スプレッドにより原資産方向リスクを抑え、HGL により商品間関係とタームストラクチャー関係を満期依存で学習する。実証では、HGL が予測 MSE、IR、Sortino、ドローダウン、S&P 500 との低相関の面でベンチマークを上回っています。`2606.25811v1.pdf`

実装に必要なデータは、単なる価格系列ではなく、**個別契約単位の日次価格・出来高・満期・単位・契約倍率・取引カレンダー**です。本番運用まで考えるなら、これに加えて **bid/ask、建玉、証拠金、スプレッド証拠金、手数料、限月別取引停止ルール** が必要になります。

## Prompt:
2026/6/30 23:59:54

lseg.data でデータを取得予定とし、１つのノートブックで完結するよう実装したいです。各計算ステップごとデータの入出力を確認できるよう実装したいです。まだ実装せず要件定義をして

## Response:
2026/6/30 23:59:56

> **LSEGデータに関する計画と要件定義**
>
> ユーザーはLSEGデータを使用する計画があるようですが、まだ要件定義が完了していません。LSEGデータのAPIに関する情報をウェブで検索し、公式ドキュメントやファイルを引用することが必須です。Pythonライブラリについても調べ、最新の仕様に合わせます。
>
> **Searching LSEG Data Library Python documentation**
>
> [LSEG Data Library for Python](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation)
> [lseg-data](https://pypi.org/project/lseg-data/)
> [Getting latest data for continuous futures contracts](https://community.developers.lseg.com/discussion/131789/getting-latest-data-for-continuous-futures-contracts)
> [get_history - Download LSEG Workspace](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html)
> [Datastream API (DSWS) Median Index Data](https://medium.com/lseg-developer-community/datastream-api-dsws-median-index-data-in-python-codebook-afdc5d47d324)
> [LD Lib. Python Tutorial 4 - get_history.ipynb](https://github.com/LSEG-API-Samples/Example.DataLibrary.Python/blob/lseg-data-examples/Tutorials/1.Access/LD%20Lib.%20Python%20Tutorial%204%20-%20get_history.ipynb)
> [Datastream: Futures - Research Guides - Princeton University](https://libguides.princeton.edu/datastream/futures)
> [【ロイター×python】lsegデータを取得](https://qiita.com/m_turner/items/1ea16e427f89aa3e371a)
>
> **LSEGの公式ドキュメントを確認**
>
> LSEGのデータに関する正確な情報を得るため、公式ドキュメントを開いて詳細なフィールドを確認する必要があるかもしれません。これでデータの発見や使用方法をより正確にスムーズに進められるはずです。
>
> **Official LSEG ドキュメントのフィールド検索**
>
> [Documentation | Devportal](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation)
> [get_history](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html)
>
> **LSEGデータライブラリのアクセス層とセッション設定の確認**
>
> LSEGデータライブラリのアクセス層やセッション設定について確認が必要かもしれません。セッションの設定方法や適切なアクセス範囲を調べるため、関連する情報を検索し、設定について理解を深める必要があります。
>
> **LSEGデータライブラリのセッション設定確認**
>
> [Discover our Data Library part 1 | Devportal](https://developers.lseg.com/en/article-catalog/article/discover-data-library-part-1)
>
> **LSEGデータの要件定義と引用方法**
>
> 現在、LSEGデータの実装ではなく、要件定義が必要です。LSEGデータの制限やデータの形について触れ、引用はすでに文脈にあるためファイル検索は不要な場合もあります。しかし、ファイル検索からの行ごとの引用は含めるべきかもしれません。要件に従って、適切な引用形式を選びます。
>
> **LSEGデータとDatastreamのフィールド検証**
>
> ユーザー向けに、LSEGデータからWRDS DatastreamテーブルをSQLで直接取得しない前提で、LSEG Workspace/Platformで同等のフィールドを取得できるか検証する必要があります。また、CodeCreatorによるフィールド利用資格や使用できる `get_data` や `get_history` のフィールドに関する公式ドキュメントを参照します。
>
> **LSEG先物の決済フィールド確認**
>
> LSEG先物の決済フィールドについて、公式ドキュメントを使用するのが良いかもしれません。正確な情報を得るために、適切なドキュメントを検索して、必要なフィールドを確認することが重要です。
>
> **LSEGの先物 settlement フィールド検索**
>
> [use function to retrieve "settlement price", "open interest ...](https://community.developers.lseg.com/discussion/96055/use-function-to-retrieve-settlement-price-open-interest-and-open-interest-change-data-in)
> [LSEG: Financial Markets Infrastructure and Data](https://www.lseg.com/en)
> [Commodity seasonality charts with LSEG Data Library for ...](https://developers.lseg.com/en/article-catalog/article/commodity-seasonality-charts-ldlib)
> [London Stock Exchange Group](https://en.wikipedia.org/wiki/London_Stock_Exchange_Group)
> [LSEG](https://uk.linkedin.com/company/london-stock-exchange-group)
> [LD Lib. Python Tutorial 4 - get_history.ipynb](https://github.com/LSEG-API-Samples/Example.DataLibrary.Python/blob/lseg-data-examples/Tutorials/1.Access/LD%20Lib.%20Python%20Tutorial%204%20-%20get_history.ipynb)
> [London Stock Exchange Group plc (LSEG.L)](https://finance.yahoo.com/quote/LSEG.L/)
> [historical_pricing.events.Definition object](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/content-layer/historical-pricing/historical-pricing-events/historical-pricing-events-definition.html)
> [lseg-data](https://pypi.org/project/lseg-data/)
>
> **LSEGのSettlementPriceとOpenInterestに関する言及**
>
> TR.SETTLEMENTPRICEとTR.OPENINTERESTはLSEGの開発者コミュニティからの候補例ですが、公式ではないため、最終的なフィールドはCodeCreator/Data Item Browserで確認する必要があります。公式とコミュニティの情報は慎重に取り扱い、必要に応じて引用を使用します。
>
> **答えの構造と内容**
>
> 「要件定義書 v0.1」として構造化するのが良さそうです。例えば以下のようなセクションを含める：
> - スコープと非スコープ
> - 対象ノートブックの原則
> - 論文から確認した内容（データ、対象/ユニバース、タイミング）
> - LSEGデータ取得の前提条件と未解決の疑問 など
> 
> 各ステップ（0～17）の入力、処理、出力、チェックを詳細化し、ユーザーに明確に回答できます。
>
> **要件の補足とデータ取得アダプタ**
>
> 論文とLSEGドキュメントに基づいて、必要なフィールド（例：DSFutContrInfo、LastTrdDate、DSFutContrChg等）を取り扱います。ライセンスに基づき、適切なデータ取得手段を定義する必要があります。`lseg.data`とDatastreamの両者を運用するため、実装は柔軟に対応が必要です。
>
> **データ処理とモデルの検証**
>
> 各ステップに関して、出力とチェックを行うポイントをリストします。特徴量、ラベル、グラフエッジ、補間手法などについて、漏れなく検証し、増分モデルとバックテスト結果を出力します。また、バリデーション指標や承認基準も含めて、正確なデータと結果を保証します。
>
> 思考時間: 7m 37s

了解しました。ここでは**実装前の要件定義**として、`lseg.data` でデータ取得し、**1つの Jupyter Notebook で取得・加工・特徴量・ラベル・グラフ・予測・CSウェイト・バックテストまで完結**させる前提で整理します。

本件の最重要方針は、**「連続先物」ではなく「個別先物契約」単位で、日付・商品・限月・満期・価格・出来高を厳密に管理すること**です。添付論文の手法は、同一商品内の複数限月の相対リターンを予測し、予測値を商品内でデミーンしてカレンダー・スプレッド・ウェイトに変換する構造なので、個別契約レベルのデータが必須です。`2606.25811v1.pdf`

---

# 1. 実装対象のスコープ

今回の Notebook は、以下を一気通貫で扱う設計にします。

**対象戦略**

商品先物のカレンダー・スプレッド戦略。

**対象データ**

LSEG から取得する個別先物契約データ。

**対象頻度**

日次 EOD。

**対象市場**

論文に合わせるなら、CME、CBOT、NYMEX、COMEX、eCBOT の米ドル建て商品先物。論文では LSEG Datastream を WRDS 経由で利用し、価格・出来高・満期情報を契約単位で処理しています。`2606.25811v1.pdf`

**Notebook の役割**

1つの Notebook の中で、以下を順番に実行できること。

1. `lseg.data` セッション確立  
2. 対象先物契約ユニバース取得  
3. 契約マスター取得・整形  
4. 日次価格・出来高履歴取得  
5. データ品質チェック  
6. 満期・TTM・流動性フィルタ  
7. 特徴量 $X_t$ 作成  
8. ラベル $Y_{t+2}$ 作成  
9. グラフエッジ作成  
10. 学習データセット作成  
11. モデル学習・推論  
12. CS ウェイト作成  
13. バックテスト  
14. 各ステップの入出力確認・保存  

ただし、現段階では**実装しない**ので、ここでは各セル・各計算ブロックの入出力、検証観点、保存対象を定義します。

---

# 2. `lseg.data` 利用に関する前提

`lseg.data` は LSEG Data Library for Python の Access Layer として、`get_data` と `get_history` を使ってスナップショット、リファレンス、価格履歴などを取得できます。`get_data` は pricing snapshot や reference data の取得、`get_history` は pricing history や historical reference data の取得を目的とした関数です。([Refinitiv](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-data-function.html)) ([Refinitiv](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html))

セッション方式は大きく **Desktop Session** と **Platform Session** に分かれます。Desktop Session では Workspace または Eikon Desktop が同一マシンで起動している必要があり、Platform Session では対応ライセンスが必要です。データアクセス範囲は契約・エンタイトルメントに依存するため、最初に小規模な取得テストで、個別先物契約の履歴価格、出来高、満期、契約月、取引所、通貨、単位情報が取れるかを確認する必要があります。([LSEG Developers](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation))

また、LSEG 側にはリクエスト数、レスポンス量、日次上限、エンタイトルメント制約があります。Notebook は都度 API を叩くのではなく、必ずローカルキャッシュを使い、失敗 RIC、取得日時、取得フィールド、取得件数を記録する設計にします。([LSEG Developers](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation))

---

# 3. 重要な設計判断

## 3.1 Notebook は「1ファイル」だが、データはステージ別にキャッシュする

Notebook 自体は1つにします。ただし、LSEG 取得データや中間生成物は、Notebook 内メモリだけに置かず、ステージごとに Parquet / CSV / JSON に保存します。

理由は次の通りです。

1. LSEG の API 呼び出しを毎回繰り返さないため。  
2. 各計算ステップの入出力を再確認できるようにするため。  
3. 後から特定日・特定契約の異常を追跡できるようにするため。  
4. Notebook の途中から再開できるようにするため。  

想定ディレクトリは以下です。

```text
project/
  notebook_hgl_calendar_spread.ipynb
  config/
    field_map.yaml
    universe_seed.csv
  cache/
    raw/
    stage/
    graph/
    model/
    backtest/
  reports/
    data_quality/
    stage_summary/
    figures/
  logs/
```

Notebook は1つですが、データ監査のための永続化ファイルは分けます。

---

## 3.2 全ステップで「入力・出力・検証結果」を表示する

各ステップは必ず次の3点を出す要件にします。

| 項目 | 内容 |
|---|---|
| Input summary | 入力テーブル名、行数、列数、主キー、日付範囲、ユニーク契約数 |
| Output summary | 出力テーブル名、行数、列数、追加・削除件数、保存先 |
| Validation report | 欠損率、重複、異常値、フィルタ理由別件数、hard fail / warning |

Notebook 上では、各ステージ後に以下を表示します。

```text
[Stage Name]
- Input rows / columns
- Output rows / columns
- Date range
- Number of commodities
- Number of contracts
- Missing value summary
- Duplicate key check
- Filtered records by reason
- Sample rows
- Saved path
```

---

## 3.3 LSEG フィールド名はハードコードしない

LSEG のフィールド名・利用可能項目はアクセス経路、プロダクト、エンタイトルメントで変わり得ます。そのため、Notebook 本体に直接フィールド名を散らさず、**論理フィールド名 → LSEG フィールド名候補**の対応表を設定セルに持たせます。

例えば、Notebook 内では常に以下の論理名を使います。

| 論理フィールド | 意味 |
|---|---|
| `ric` | 個別先物契約 RIC |
| `commodity_id` | 原資産商品 ID |
| `exchange` | 取引所 |
| `currency` | 通貨 |
| `contract_month` | 契約月 |
| `maturity_date` | 満期または最終取引日 |
| `last_trade_date` | 最終取引日 |
| `price` | 清算値または終値 |
| `volume` | 出来高 |
| `open_interest` | 建玉 |
| `unit_code` | 価格単位・引用単位 |
| `contract_multiplier` | 契約倍率 |
| `tick_size` | tick size |
| `tick_value` | tick value |

実装時には `field_map.yaml` で、これらを実際の LSEG フィールドに対応させます。

---

# 4. 最低限必要なデータ要件

## 4.1 契約マスター

最重要です。HGL は満期依存のグラフを作るため、満期日が不正確だとモデル全体が壊れます。

| 必須度 | フィールド | 用途 |
|---|---|---|
| 必須 | `ric` | LSEG 取得キー |
| 必須 | `commodity_id` | 同一商品内デミーン、CS制約、商品ノード |
| 必須 | `contract_id` | 内部一意キー |
| 必須 | `exchange` | 対象市場フィルタ |
| 必須 | `currency` | USD建てフィルタ |
| 必須 | `contract_month` | 契約月整合性チェック |
| 必須 | `maturity_date` / `last_trade_date` | TTM、ユニバース、満期フィルタ |
| 強く推奨 | `first_notice_date` | 現物受渡回避 |
| 強く推奨 | `contract_multiplier` | 実運用時の枚数換算 |
| 強く推奨 | `tick_size`, `tick_value` | コスト・丸め・PnL計算 |
| 強く推奨 | `unit_code` | 価格単位補正 |
| 任意 | sector / group | 分析・集計 |

添付論文の Appendix C では、満期日は `LastTrdDate` を初期値とし、`ContrDate` と大きく乖離する場合に `EndDate`、`MaxDate`、近似満期日で補正しています。また、価格単位も `CurrUnitCode` に基づいて変換し、一部のスケール異常を追加補正しています。したがって、Notebook でも**満期整合性チェック**と**価格単位チェック**は独立ステージにします。`2606.25811v1.pdf`

---

## 4.2 日次価格・出来高

| 必須度 | フィールド | 用途 |
|---|---|---|
| 必須 | `date` | 時点キー |
| 必須 | `ric` / `contract_id` | 契約キー |
| 必須 | `settlement_price` または `close_price` | リターン、特徴量、PnL |
| 必須 | `volume` | 流動性判定、観測可能性判定 |
| 強く推奨 | `open_interest` | 流動性補助 |
| 強く推奨 | `bid`, `ask` | 取引コスト、実行可能性 |
| 任意 | `last_price`, `high`, `low`, `open` | 追加特徴量、異常検知 |

論文では日次価格・出来高を使い、直近 $n^{min}_{sam}=28$ 日すべてで出来高が正であることを流動性条件にしています。価格は個別契約の価格であり、連続先物やバックアジャスト済み価格ではありません。`2606.25811v1.pdf`

---

## 4.3 実運用まで見据える場合の追加データ

論文の主要実験は取引コストや契約別証拠金を十分には扱っていません。実運用を前提にするなら、以下も取得可能性を確認します。`2606.25811v1.pdf`

| データ | 用途 |
|---|---|
| initial margin | 資本使用量 |
| maintenance margin | リスク管理 |
| spread margin | CS の実効レバレッジ |
| exchange fee | 手数料 |
| clearing fee | 手数料 |
| bid/ask spread | スリッページ |
| minimum block / lot size | 枚数丸め |
| first notice date | 現物受渡回避 |
| delivery period | 納会リスク管理 |

MVP では取引コストなし・単位マージンで論文に近い評価を行い、次フェーズでコスト・証拠金を追加するのが妥当です。

---

# 5. Notebook 全体構成

以下のセル構成にします。

| セクション | 目的 | 主な出力 |
|---|---|---|
| 0. Notebook Overview | 実行方針・Run Mode・出力先確認 | 実行設定サマリー |
| 1. Imports / Version Check | Python・lseg.data・pandas 等のバージョン確認 | 環境レポート |
| 2. Config | 期間、対象市場、フィールドマップ、閾値 | `CONFIG` |
| 3. LSEG Session | セッション確立・疎通確認 | `session_report` |
| 4. Universe Discovery | 対象契約候補の取得 | `raw_universe` |
| 5. Contract Master | 契約属性取得・整形 | `contract_master` |
| 6. Price/Volume History | 日次履歴取得 | `raw_market_history` |
| 7. Data Cleaning | 価格単位、満期、欠損、重複処理 | `daily_market_clean` |
| 8. Trading Calendar | 営業日・取引日定義 | `trading_calendar` |
| 9. Universe Snapshot | 各 as-of date の取引対象 | `universe_snapshot` |
| 10. Returns | リターンと商品内平均 | `returns_panel` |
| 11. Features | $X_t$ 作成 | `features_hgl` |
| 12. Labels | $Y_{t+2}$ 作成 | `labels_hgl` |
| 13. Graph Construction | CC / CU / UC / UU エッジ | `graph_edges`, `lifting_weights` |
| 14. Dataset Assembly | 学習・検証・テストデータ | `dataset_index`, tensors |
| 15. Model Block | HGL / baseline 学習・推論 | `predictions` |
| 16. CS Weights | 予測値から CS ウェイト | `positions` |
| 17. Backtest | PnL・IR・SR・MDD | `backtest_results` |
| 18. Final Audit | 全ステージの監査表 | `stage_catalog` |

---

# 6. 各ステップの入出力要件

## 6.1 Stage 0: Notebook Overview

**目的**

Notebook の実行モードと全体設定を最初に明示します。

**入力**

なし。

**出力**

`run_metadata`

| フィールド | 内容 |
|---|---|
| `run_id` | 実行ID |
| `run_timestamp` | 実行日時 |
| `run_mode` | `smoke`, `research`, `full` |
| `start_date` | データ開始日 |
| `end_date` | データ終了日 |
| `cache_policy` | read / refresh / overwrite |
| `lseg_session_type` | desktop / platform |

**確認表示**

- 実行モード
- 対象期間
- キャッシュ使用有無
- 出力ディレクトリ
- 乱数シード

---

## 6.2 Stage 1: Imports / Version Check

**目的**

再現性確認。

**入力**

Python 環境。

**出力**

`environment_report`

| 項目 | 確認内容 |
|---|---|
| Python version | 実行環境 |
| `lseg.data` version | API ライブラリ |
| pandas / numpy / scipy | データ処理 |
| torch / torch_geometric | HGL 実装時 |
| lightgbm / sklearn | benchmark |
| OS / timezone | 日付処理 |

**確認表示**

- ライブラリバージョン一覧
- missing package
- optional package availability

---

## 6.3 Stage 2: Config

**目的**

Notebook 全体のパラメータを一元管理します。

**主要パラメータ**

| パラメータ | 論文準拠値 | 説明 |
|---|---:|---|
| `tau_max_days` | 約365日 | 最大 TTM |
| `n_min_sam` | 28 | 特徴量長、流動性判定 |
| `n_bas` | 52 | 仮想 TTM グリッド数 |
| `rho_star` | 0.1 / 0.2 / 0.3 | 商品間相関エッジ閾値 |
| `prediction_horizon_entry` | 1日後 | $t+1$ で建てる |
| `prediction_horizon_exit` | 2日後 | $t+2$ で解消 |
| `target_price_field` | settlement 優先 | 価格定義 |
| `min_contracts_per_commodity` | 2 | CS成立条件 |
| `cdf_epsilon` | 小さい正数 | 正規分位変換の端点回避 |

論文では $\tau^{max}=1$ 年、$n^{bas}=52$、$n^{min}_{sam}=28$ が使われています。`2606.25811v1.pdf`

**確認表示**

- パラメータ一覧
- 論文準拠 / 変更ありフラグ
- field map のロード可否

---

## 6.4 Stage 3: LSEG Session

**目的**

`lseg.data` セッションを確立し、疎通・エンタイトルメントを確認します。

**入力**

- LSEG 設定
- Desktop / Platform session 指定
- 認証情報。ただし Notebook 直書きは禁止。

**出力**

`session_report`

| フィールド | 内容 |
|---|---|
| `session_type` | desktop / platform |
| `opened` | True / False |
| `test_request_status` | success / failed |
| `test_ric` | 疎通確認用 RIC |
| `available_fields` | テストで取れたフィールド |
| `error_message` | 失敗時 |

**確認表示**

- セッション状態
- テスト取得結果
- entitlement failure の有無

**Hard fail 条件**

- セッションが開けない
- 価格履歴取得ができない
- 必須フィールドのうち価格または日付が取れない

---

## 6.5 Stage 4: Universe Discovery

**目的**

対象となる個別先物契約 RIC の候補を作成します。

**入力**

いずれか。

| 入力方式 | 内容 |
|---|---|
| chain / search | LSEG から取引所・商品先物を探索 |
| seed CSV | ユーザーが用意した商品・RIC リスト |
| hybrid | seed から chain をたどり、個別契約 RIC を展開 |

**出力**

`raw_universe`

| フィールド | 内容 |
|---|---|
| `ric` | 個別契約 RIC |
| `root_ric` | ルートまたはチェーン |
| `commodity_hint` | 商品識別候補 |
| `exchange_hint` | 取引所候補 |
| `source_method` | chain / search / seed |
| `discovered_at` | 取得日時 |
| `active_flag_raw` | LSEG 側ステータス |

**確認表示**

- 取得 RIC 数
- root / commodity 別契約数
- 取引所別件数
- 重複 RIC 数
- 取得失敗 RIC

**Hard fail 条件**

- `raw_universe` が空
- 個別契約 RIC と連続先物 RIC が区別できない
- 商品IDに紐づかない RIC が大半

---

## 6.6 Stage 5: Contract Master

**目的**

個別契約ごとの属性テーブルを作ります。

**入力**

`raw_universe`

**出力**

`contract_master_raw`  
`contract_master_clean`

| フィールド | 内容 |
|---|---|
| `contract_id` | 内部ID |
| `ric` | LSEG RIC |
| `commodity_id` | 商品ID |
| `commodity_name` | 商品名 |
| `exchange` | 取引所 |
| `currency` | 通貨 |
| `contract_month` | 契約月 |
| `maturity_date_raw` | LSEG 原値 |
| `maturity_date_clean` | 補正後 |
| `last_trade_date` | 最終取引日 |
| `first_notice_date` | 取得可能なら |
| `unit_code` | 価格単位 |
| `contract_multiplier` | 契約倍率 |
| `tick_size` | tick size |
| `tick_value` | tick value |
| `master_quality_flag` | 品質フラグ |

**確認表示**

- 契約数
- 商品数
- 通貨分布
- 取引所分布
- 満期欠損数
- contract month と maturity の乖離
- 同一 RIC 重複
- 同一商品内の満期順サンプル

**Hard fail 条件**

- `ric` が一意でない
- `commodity_id` が欠損
- `maturity_date_clean` が欠損
- `currency` が USD 以外なのに除外されていない
- 満期日が契約月と明らかに矛盾

---

## 6.7 Stage 6: Price / Volume History

**目的**

個別契約ごとの日次価格・出来高を取得します。

LSEG Data Library の `get_history` は、`universe`, `fields`, `interval`, `start`, `end`, `adjustments` などを指定して履歴データを取得する関数です。日次先物データでは `interval="daily"` または同等指定を使う設計にします。([Refinitiv](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html))

**入力**

- `contract_master_clean`
- `start_date`
- `end_date`
- price / volume field map

**出力**

`raw_market_history`

| フィールド | 内容 |
|---|---|
| `date` | 価格日付 |
| `ric` | 契約 RIC |
| `contract_id` | 内部契約ID |
| `price_raw` | 取得価格 |
| `volume_raw` | 出来高 |
| `open_interest_raw` | 任意 |
| `bid_raw` | 任意 |
| `ask_raw` | 任意 |
| `field_source` | settlement / close 等 |
| `fetch_batch_id` | API バッチID |

**確認表示**

- 取得行数
- 取得成功 RIC 数
- 取得失敗 RIC 数
- RIC別日数分布
- 欠損率
- 価格ゼロ・負値数
- 出来高ゼロ・欠損数
- バッチ別レスポンス時間

**Hard fail 条件**

- 価格がほぼ取得できない
- `date, contract_id` が一意でない
- 価格が負またはゼロ
- `date` がパース不能

---

## 6.8 Stage 7: Data Cleaning

**目的**

価格単位、満期、日付、重複、欠損、異常値を整理します。

**入力**

- `contract_master_clean`
- `raw_market_history`

**出力**

`daily_market_clean`

| フィールド | 内容 |
|---|---|
| `date` | 日付 |
| `contract_id` | 契約ID |
| `commodity_id` | 商品ID |
| `price` | 単位補正後価格 |
| `volume` | 出来高 |
| `open_interest` | 任意 |
| `maturity_date` | 補正後満期 |
| `ttm_days` | 満期までの日数 |
| `valid_price_flag` | 価格有効 |
| `valid_volume_flag` | 出来高有効 |
| `quality_flags` | 異常フラグ |

**主な処理要件**

| 処理 | 内容 |
|---|---|
| 単位補正 | セント建て・ドル建て等の統一 |
| 満期補正 | 契約月と最終取引日の整合性確認 |
| 重複除去 | `date, contract_id` 単位で一意化 |
| 欠損処理 | 価格欠損は原則補完しない |
| 異常リターン検知 | 極端な価格ジャンプを flag |
| 満期後除外 | `date > maturity_date` を除外 |

**確認表示**

- cleaning 前後の行数
- 除外理由別件数
- 価格単位補正件数
- 価格スケール異常候補
- 満期後データ件数
- 商品別価格レンジ

**Hard fail 条件**

- 補正後価格がゼロ以下
- 満期前後の判定が不能
- 商品ごとに価格スケールが極端に不整合

---

## 6.9 Stage 8: Trading Calendar

**目的**

Notebook 内で使う日次 $t$ インデックスを定義します。

**入力**

`daily_market_clean`

**出力**

`trading_calendar`

| フィールド | 内容 |
|---|---|
| `date` | 実日付 |
| `t_index` | 連番 |
| `is_trading_date` | 使用対象日 |
| `n_traded_contracts` | 出来高あり契約数 |
| `n_observed_contracts` | 価格あり契約数 |
| `calendar_quality_flag` | 品質 |

論文では、取引日は「その日に取引された契約ティッカー数が直近365日の平均の50%を超える weekdays」として定義されています。Notebook でも、取引所カレンダーだけでなく、データ実績に基づく取引日判定を持たせます。`2606.25811v1.pdf`

**確認表示**

- trading date 数
- 年別取引日数
- 日次契約数推移
- holiday / low coverage 日
- 欠落期間

**Hard fail 条件**

- `t_index` が連続していない
- 同一日付に複数 index
- テスト期間に長期欠損がある

---

## 6.10 Stage 9: Universe Snapshot

**目的**

各 as-of date $t$ において、$t+1$ で建てて $t+2$ で解消可能な契約集合 $\hat U_{t+2}$ を作ります。

**入力**

- `daily_market_clean`
- `contract_master_clean`
- `trading_calendar`
- `CONFIG`

**出力**

`universe_snapshot`

| フィールド | 内容 |
|---|---|
| `asof_date` | 予測時点 $t$ |
| `target_date` | $t+2$ |
| `entry_date` | $t+1$ |
| `exit_date` | $t+2$ |
| `contract_id` | 契約ID |
| `commodity_id` | 商品ID |
| `ttm_days_asof` | $T_{cd}-t$ |
| `has_recent_volume` | 直近28日出来高条件 |
| `within_tau_max` | TTM 1年以内 |
| `liquidatable` | $t+2 \le T_{cd}$ |
| `sigma_x_positive` | 特徴量スケールが正 |
| `in_universe` | 最終採用フラグ |
| `filter_reason` | 除外理由 |

論文のユニバース条件は、概ね以下です。

$$
t+2 \le T_{cd}
$$

$$
T_{cd}-t \le \tau^{max}
$$

$$
\prod_{t' \in (t-n^{min}_{sam},t]} V_{t'cd} > 0
$$

さらに特徴量標準偏差 $\hat\sigma^x_{tc} > 0$ が必要です。`2606.25811v1.pdf`

**確認表示**

- 日次ユニバース契約数
- 日次商品数
- 商品別平均契約数
- 除外理由別件数
- CS成立可能商品数、つまり2限月以上の商品数
- `ttm_days_asof` 分布

**Hard fail 条件**

- `in_universe=True` で満期超過
- `in_universe=True` で TTM > `tau_max_days`
- 商品内契約数が1本しかないのに CS 対象に残っている
- 直近28日価格または出来高が不足

---

## 6.11 Stage 10: Returns

**目的**

個別契約リターン、商品内平均リターン、商品内デミーン・リターンを作ります。

**入力**

- `daily_market_clean`
- `universe_snapshot`

**出力**

`returns_panel`

| フィールド | 内容 |
|---|---|
| `return_date` | $t$ または $t+2$ |
| `contract_id` | 契約ID |
| `commodity_id` | 商品ID |
| `price_lag1` | 前日価格 |
| `price` | 当日価格 |
| `raw_return` | $R_{tcd}$ |
| `commodity_avg_return` | $R^\bullet_{tc}$ |
| `demeaned_return` | $R^\circ_{tcd}$ |
| `observable_flag` | 実際に観測可能か |

計算式は以下です。

$$
R_{tcd} = \frac{F_{tcd}}{F_{t-1,cd}} - 1
$$

$$
R^\circ_{tcd} = R_{tcd} - R^\bullet_{tc}
$$

CS ウェイトは商品内で和がゼロなので、PnL は通常リターンではなく、商品内デミーン・リターンで評価しても整合します。これは論文のターゲット設計そのものです。`2606.25811v1.pdf`

**確認表示**

- リターン分布
- 商品別平均リターン
- デミーン後に商品別平均がゼロか
- 極端リターン上位
- `raw_return` 欠損理由

**Hard fail 条件**

- 価格があるのにリターンが作れない
- 商品内デミーン後の平均が数値誤差を超えてゼロでない
- $t+1$ または $t+2$ の価格がない契約をラベル対象に含めている

---

## 6.12 Stage 11: Features

**目的**

HGL のノード特徴量 $X_t$ を作ります。

**入力**

- `daily_market_clean`
- `universe_snapshot`
- `CONFIG`

**出力**

`features_hgl`

| フィールド | 内容 |
|---|---|
| `asof_date` | $t$ |
| `contract_id` | 契約ID |
| `commodity_id` | 商品ID |
| `x_0 ... x_27` | 特徴量 |
| `sigma_x` | 商品内スケール |
| `feature_valid_flag` | 有効フラグ |

論文では、直近 $n^{min}_{sam}=28$ 日のログ価格に対して、同一商品内で two-way ANOVA-style centering を行います。すなわち、契約方向の平均、日付方向の平均、商品内全体平均を使って中心化し、その後、商品内標準偏差でスケーリングし、最後に経験CDFと標準正規分位関数で正規スコア化します。`2606.25811v1.pdf`

**確認表示**

- `features_hgl` shape
- $N_t \times 28$ の形状確認
- 欠損特徴量数
- 商品別 `sigma_x`
- 正規化後特徴量の平均・標準偏差・分位点
- 代表商品の $x_0...x_{27}$ サンプル

**Hard fail 条件**

- `sigma_x <= 0`
- 特徴量に inf / -inf / NaN
- 直近28日より未来データを使っている
- `asof_date` より後の価格が特徴量に混入

---

## 6.13 Stage 12: Labels

**目的**

教師ラベル $Y_{t+2,cd}$ を作ります。

**入力**

- `returns_panel`
- `universe_snapshot`

**出力**

`labels_hgl`

| フィールド | 内容 |
|---|---|
| `asof_date` | $t$ |
| `entry_date` | $t+1$ |
| `exit_date` | $t+2$ |
| `contract_id` | 契約ID |
| `commodity_id` | 商品ID |
| `raw_return_t2` | $F_{t+2}/F_{t+1}-1$ |
| `demeaned_return_t2` | $R^\circ_{t+2,cd}$ |
| `target_y` | $Y_{t+2,cd}$ |
| `label_observable_flag` | 実際に観測可能か |

ラベルは以下です。

$$
Y_{tcd}
=
\Phi^{-1}
\left(
\widehat{\mathrm{cdf}}
\left(
R^\circ_{tcd}
\right)
\right)
$$

ここで $R^\circ_{tcd}$ は同一商品内で平均控除したリターンです。論文では、通常リターンではなく商品内デミーン・リターンを予測することで、CS 戦略と整合した目的関数にしています。`2606.25811v1.pdf`

**確認表示**

- `target_y` 分布
- cross-section ごとの平均・標準偏差
- NaN / inf 件数
- CDF 端点クリップ件数
- ラベル欠損理由

**Hard fail 条件**

- `target_y` に inf がある
- 同一 `asof_date` でラベル対象が少なすぎる
- $t+2$ のラベルを $t$ 以前の処理に混ぜている
- 商品内契約数1本のラベルを残している

---

## 6.14 Stage 13: Graph Construction

**目的**

HGL 用の階層グラフを作ります。

**入力**

- `universe_snapshot`
- `features_hgl`
- `returns_panel`
- `contract_master_clean`
- `CONFIG`

**出力**

| 出力 | 内容 |
|---|---|
| `edges_cc_pos` | 商品間正相関エッジ |
| `edges_cc_neg` | 商品間負相関エッジ |
| `edges_cu` | 商品 → 契約エッジ |
| `edges_uc` | 契約 → 商品エッジ |
| `edges_uu` | 同一商品内近接限月エッジ |
| `lifting_weights_uc` | 実契約 → 仮想TTM補間重み |
| `lowering_weights_cu` | 仮想TTM → 実契約補間重み |
| `graph_snapshot_report` | 日次グラフ品質 |

### 商品間エッジ

満期を揃えた商品間のデミーン・リターン相関を計算し、閾値以上なら正エッジ、閾値以下なら負エッジにします。

$$
\hat\rho_{tcc'} \ge \rho^\*
\Rightarrow E^{CC+}
$$

$$
\hat\rho_{tcc'} \le -\rho^\*
\Rightarrow E^{CC-}
$$

### 同一商品内エッジ

同一商品の契約を TTM 順に並べ、隣接限月同士を接続します。

### 仮想TTMグリッド

$$
\tau_j = j \cdot \frac{\tau^{max}}{n^{bas}}
$$

論文では $n^{bas}=52$ です。`2606.25811v1.pdf`

**確認表示**

- 日次ノード数
- 日次商品数
- `CC+`, `CC-`, `CU`, `UC`, `UU` エッジ数
- 商品間相関分布
- 正負エッジ比率
- 補間対象外・外挿件数
- 代表日グラフのサンプル

**Hard fail 条件**

- エッジがすべて空
- `UU` エッジで異なる商品が接続されている
- `CC` エッジで TTM アラインメントができていない
- 補間重みの和が1から大きく外れる
- `CU` / `UC` で商品と無関係な契約が接続されている

---

## 6.15 Stage 14: Dataset Assembly

**目的**

モデル入力として扱える形式に変換します。

**入力**

- `features_hgl`
- `labels_hgl`
- `graph_edges`
- `universe_snapshot`

**出力**

`dataset_index`

| フィールド | 内容 |
|---|---|
| `sample_id` | サンプルID |
| `asof_date` | $t$ |
| `split` | fit / val / test |
| `n_nodes` | ノード数 |
| `n_commodities` | 商品数 |
| `has_label` | ラベル有無 |
| `feature_path` | 保存先 |
| `label_path` | 保存先 |
| `graph_path` | 保存先 |

モデル実装時には、日付ごとに以下を持つデータオブジェクトになります。

| オブジェクト | shape |
|---|---|
| `X_t` | `[N_t, 28]` |
| `Y_t2` | `[N_t]` |
| `contract_index` | `[N_t]` |
| `commodity_index` | `[N_t]` |
| `edge_index_cc_pos` | `[2, E_cc_pos]` |
| `edge_index_cc_neg` | `[2, E_cc_neg]` |
| `edge_index_uu` | `[2, E_uu]` |
| `lifting_matrix` | sparse |
| `lowering_matrix` | sparse |

**確認表示**

- split 別サンプル数
- 年別サンプル数
- ノード数分布
- ラベルありノード比率
- feature / label / graph のキー整合性

**Hard fail 条件**

- feature はあるが label が対応しない
- graph node と feature node の順序が不一致
- split に未来データ漏洩がある
- train / val / test の日付が重複

---

## 6.16 Stage 15: Model Block

**目的**

HGL および baseline モデルを学習・推論します。

現段階では実装しませんが、Notebook 要件としては以下を満たす設計にします。

**入力**

- `dataset_index`
- `model_config`

**出力**

`predictions`

| フィールド | 内容 |
|---|---|
| `asof_date` | $t$ |
| `target_date` | $t+2$ |
| `model_name` | HGL / Ridge / LightGBM / MLP 等 |
| `contract_id` | 契約ID |
| `commodity_id` | 商品ID |
| `y_hat` | 予測値 |
| `y_true` | ラベル |
| `split` | fit / val / test |

**確認表示**

- 学習期間・検証期間・テスト期間
- train / val loss
- 日次 MSE
- 商品別 MSE
- 予測値分布
- `y_hat` と `y_true` の分布比較

**Hard fail 条件**

- test データを学習に使っている
- 予測値に NaN / inf
- 予測対象契約と Universe が不一致
- 同一契約に複数予測がある

**要件上の推奨**

最初から論文と同じ大規模 grid search を Notebook で回すより、以下の3段階が現実的です。

| フェーズ | 内容 |
|---|---|
| Smoke | 1〜2年、少数商品、固定パラメータ |
| Research MVP | 全商品、固定 HGL / Ridge / LightGBM |
| Replication | 年次再学習、複数 CONV、複数 $\rho^\*$、複数層 |

論文では多数のハイパーパラメータ候補を期間ごとに検証していますが、Notebook 実装では最初に「パイプラインの正しさ」を優先し、その後に grid search を追加する方が安全です。`2606.25811v1.pdf`

---

## 6.17 Stage 16: CS Weights

**目的**

予測値からカレンダー・スプレッド・ポジションを作ります。

**入力**

`predictions`

**出力**

`positions`

| フィールド | 内容 |
|---|---|
| `asof_date` | $t$ |
| `entry_date` | $t+1$ |
| `exit_date` | $t+2$ |
| `model_name` | モデル名 |
| `contract_id` | 契約ID |
| `commodity_id` | 商品ID |
| `y_hat` | 予測値 |
| `y_hat_demeaned` | 商品内デミーン後予測 |
| `weight` | CS ウェイト |
| `long_short` | long / short / flat |

変換式は以下です。

$$
\hat Y^\circ_{tcd}
=
\hat Y_{tcd}
-
\hat Y^\bullet_{tc}
$$

$$
w_{tcd}
=
\frac{\hat Y^\circ_{tcd}}
{\|\hat Y^\circ_t\|_1}
$$

これにより、商品ごとにウェイト和がゼロになり、全体の $L^1$ ノルムが1になります。論文の Appendix B では、この商品内デミーンが CS 制約集合へのユークリッド射影に相当することが示されています。`2606.25811v1.pdf`

**確認表示**

- 日次 $L^1$ ノルム
- 商品別ウェイト和
- long / short 総量
- 最大・最小ウェイト
- 商品別 gross exposure
- ウェイトゼロ日

**Hard fail 条件**

- 商品別ウェイト和がゼロでない
- 全体 $L^1$ ノルムが1でない
- 1限月しかない商品にウェイトが付いている
- 予測値が全て同一で $L^1$ 正規化不能

---

## 6.18 Stage 17: Backtest

**目的**

$t$ 引け後に予測し、$t+1$ で建て、$t+2$ で解消する PnL を計算します。

**入力**

- `positions`
- `daily_market_clean`
- `returns_panel`

**出力**

`backtest_daily`

| フィールド | 内容 |
|---|---|
| `asof_date` | $t$ |
| `entry_date` | $t+1$ |
| `exit_date` | $t+2$ |
| `model_name` | モデル名 |
| `gross_return` | コスト前リターン |
| `turnover` | ターンオーバー |
| `n_positions` | ポジション数 |
| `n_long` | ロング数 |
| `n_short` | ショート数 |
| `missing_exit_flag` | exit 欠損 |

`backtest_metrics`

| 指標 | 内容 |
|---|---|
| Ret | 平均日次リターン |
| Vol | 日次ボラティリティ |
| IR | Ret / Vol |
| Sortino | downside risk 対比 |
| Hit | 勝率 |
| MDD | 最大ドローダウン |
| Turnover | 平均ターンオーバー |
| Cor | S&P 500 等との相関 |

論文のバックテストでは、日次 CS ポジションを作り、IR、Sortino、Ret、Vol、MDD、Hit、Turnover、S&P 500 との相関を報告しています。主結果では、HGL が他モデルを上回る結果を示しています。`2606.25811v1.pdf`

**確認表示**

- 累積 PnL
- 日次 PnL 分布
- 年別指標
- 商品別寄与
- turnover 推移
- 欠損 exit 件数
- 最大損失日

**Hard fail 条件**

- entry または exit 価格がない契約を PnL に含めている
- `asof_date` より後の情報でポジションを作っている
- 重複ポジションがある
- PnL とリターン日付がずれている

---

## 6.19 Stage 18: Final Audit

**目的**

Notebook 実行全体の監査証跡を作ります。

**出力**

`stage_catalog`

| フィールド | 内容 |
|---|---|
| `stage_name` | ステージ名 |
| `input_rows` | 入力行数 |
| `output_rows` | 出力行数 |
| `output_path` | 保存先 |
| `n_errors` | hard fail 数 |
| `n_warnings` | warning 数 |
| `started_at` | 開始時刻 |
| `ended_at` | 終了時刻 |
| `runtime_sec` | 実行時間 |
| `data_hash` | 出力ハッシュ |

**確認表示**

- 全ステージ一覧
- failed / warning stage
- 保存済みファイル一覧
- 再実行可能性チェック
- 最終データ期間
- 最終契約数・商品数

---

# 7. データ取得設計の詳細

## 7.1 `get_data` と `get_history` の使い分け

| 用途 | 関数 | 理由 |
|---|---|---|
| 契約マスター | `get_data` | スナップショット・リファレンス取得 |
| 最新属性確認 | `get_data` | RIC 単位の属性確認 |
| 日次価格履歴 | `get_history` | 時系列取得 |
| 出来高履歴 | `get_history` | 時系列取得 |
| 建玉履歴 | `get_history` | 取得可能なら |
| field availability check | `get_data` / `get_history` | 小規模テスト |

`get_data` は `universe`, `fields`, `parameters` を主に指定し、`get_history` は `universe`, `fields`, `interval`, `start`, `end`, `adjustments` 等を指定します。([Refinitiv](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-data-function.html)) ([Refinitiv](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html))

---

## 7.2 バッチング要件

LSEG 側のリクエスト制約・レスポンス制約・エンタイトルメント制約を踏まえ、以下を要件にします。([LSEG Developers](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation))

| 項目 | 要件 |
|---|---|
| history batch size | RIC数ベースで分割 |
| retry | 一時エラーは指数バックオフ |
| failed RIC log | 必ず保存 |
| response cache | raw response を Parquet 保存 |
| refresh mode | 既存キャッシュを再利用可能 |
| throttle | request per second を制御 |
| timeout | バッチ単位で記録 |
| entitlement error | 通常エラーと分離 |

**取得ログの最低項目**

| フィールド | 内容 |
|---|---|
| `batch_id` | バッチID |
| `request_type` | get_data / get_history |
| `n_rics` | RIC数 |
| `fields` | 取得フィールド |
| `start` | 開始日 |
| `end` | 終了日 |
| `status` | success / failed |
| `error_type` | timeout / entitlement / empty / other |
| `runtime_sec` | 実行時間 |
| `n_rows` | 取得行数 |

---

# 8. 品質管理要件

## 8.1 Hard Fail

以下は発生したら処理を止めます。

| カテゴリ | 条件 |
|---|---|
| セッション | LSEG セッション未確立 |
| 契約キー | `ric` または `contract_id` が一意でない |
| 商品キー | `commodity_id` 欠損 |
| 満期 | 満期日欠損または満期後データ混入 |
| 価格 | 補正後価格がゼロ以下 |
| 特徴量 | `X_t` に NaN / inf |
| ラベル | `Y_t` に NaN / inf |
| CS 制約 | 商品別ウェイト和がゼロでない |
| PnL | entry / exit 価格なしで PnL 計算 |
| Look-ahead | $t$ 時点の処理に $t+1$ 以降の情報が混入 |

---

## 8.2 Warning

以下は処理を止めずにレポートします。

| カテゴリ | 条件 |
|---|---|
| 価格 | 極端リターン |
| 出来高 | 急激な出来高消失 |
| 満期 | contract month と maturity の乖離 |
| 流動性 | 特定商品の限月数が少ない |
| グラフ | 商品間エッジが極端に少ない |
| 補間 | 仮想TTM外挿が多い |
| カバレッジ | 商品数・契約数が急減 |
| API | 一部 RIC の取得失敗 |

---

# 9. Notebook 内で必ず可視化・表示すべきもの

最低限、以下を表示します。

## 9.1 データ取得後

- 商品数の時系列
- 契約数の時系列
- 価格欠損率
- 出来高ゼロ率
- 満期までの日数分布
- 商品別契約数ランキング

## 9.2 ユニバース作成後

- 日次対象契約数
- 日次対象商品数
- 商品別平均限月数
- 除外理由別件数
- 流動性条件で落ちた契約数

## 9.3 特徴量作成後

- $X_t$ の分布
- `sigma_x` 分布
- 商品別特徴量サンプル
- NaN / inf 件数

## 9.4 ラベル作成後

- $R_{t+2}$ 分布
- $R^\circ_{t+2}$ 分布
- $Y_{t+2}$ 分布
- 商品内デミーン後平均の確認

## 9.5 グラフ作成後

- `CC+`, `CC-`, `UU` エッジ数の時系列
- 商品間相関分布
- 仮想TTM補間の coverage
- 代表日のグラフ統計

## 9.6 バックテスト後

- 累積 PnL
- 年別 IR / Ret / Vol / MDD
- ターンオーバー
- 商品別 PnL 寄与
- 最大損失日一覧
- ウェイト制約チェック

---

# 10. ルックアヘッド防止要件

この Notebook で最も重要な制約です。

| 処理 | 使用可能データ |
|---|---|
| $t$ 時点のユニバース | $t$ までの価格・出来高、既知の満期情報 |
| $t$ 時点の特徴量 | $t, t-1, ..., t-27$ の価格 |
| $t$ 時点の商品間相関 | $t$ までのリターン |
| $t$ 時点の予測 | $t$ までの履歴 |
| ポジション構築 | $t$ 引け後に決定、$t+1$ で建てる |
| ラベル | $t+1$ から $t+2$ のリターン |
| 学習データ | 再学習日以前のラベルが確定しているサンプルのみ |

全テーブルに `asof_date`, `data_available_through`, `target_date`, `entry_date`, `exit_date` を持たせるべきです。

---

# 11. 実装時の最小 MVP 要件

最初の実装では、以下までを MVP とします。

| 項目 | MVP |
|---|---|
| データ期間 | まず2〜5年 |
| 商品数 | 5〜10商品 |
| 契約 | 個別先物契約のみ |
| 価格 | settlement 優先、なければ close |
| 出来高 | 必須 |
| 特徴量長 | 28営業日 |
| 最大TTM | 365日 |
| ラベル | $t+1$ から $t+2$ の商品内デミーン・リターン正規スコア |
| モデル | Ridge / LightGBM / 簡易MLP / HGL固定パラメータ |
| グラフ | `UU` と `CC` を最低限作成 |
| CSウェイト | 商品内デミーン + $L^1$ 正規化 |
| バックテスト | コストなし・単位マージン |
| 監査 | 全ステージの入出力表 |

最初から完全再現を目指すより、**データ取得・満期処理・ユニバース・特徴量・ラベル・ウェイト制約**の正しさを先に固めるべきです。

---

# 12. 完全版に拡張する場合の要件

| 項目 | 完全版 |
|---|---|
| データ期間 | 可能な限り長期 |
| 商品数 | LSEG で取得可能な全対象商品 |
| 再学習 | 年次または四半期 |
| HGL | GCN / SAGE / GAT 比較 |
| $\rho^\*$ | 0.1 / 0.2 / 0.3 |
| 層数 | 1 / 2 / 3 |
| baseline | Ridge, LightGBM, MLP, GNN |
| アブレーション | A1, A2 |
| コスト | bid/ask, fee, slippage |
| 証拠金 | outright margin, spread margin |
| 実運用変換 | ウェイト → ノーション → 枚数 |
| リスク管理 | 商品別上限、限月別上限、ADV制約 |

---

# 13. 受入基準

Notebook 完成時に、以下を満たせば要件充足とします。

## 13.1 データ要件

- 個別契約単位で価格・出来高・満期が取得できる。
- `date, contract_id` が一意。
- 満期日・契約月・最終取引日の整合性チェックがある。
- 価格単位補正の前後が確認できる。
- 連続先物データを使っていない。

## 13.2 計算要件

- $\hat U_{t+2}$ が $t$ 時点情報のみで作られている。
- 特徴量 $X_t$ が $t$ までのデータだけで作られている。
- ラベル $Y_{t+2}$ が $t+1$ から $t+2$ のリターンで作られている。
- 商品内デミーン後リターンの平均が商品ごとにゼロ。
- CS ウェイトの商品別和がゼロ。
- CS ウェイト全体の $L^1$ ノルムが1。

## 13.3 Notebook 要件

- 全ステージで input / output summary が表示される。
- 全ステージで validation report が表示される。
- 中間データが cache に保存される。
- エラーと warning がステージ別に追跡できる。
- LSEG API の取得ログが残る。
- smoke mode で短時間実行できる。
- full mode で長期データに拡張できる。

---

# 14. 特に注意すべきリスク

## 14.1 LSEG のフィールド取得可否

論文は LSEG Datastream を WRDS 経由で使っており、`DSFutContrInfo`, `DSFutContrVal`, `DSFutContrChg` のようなテーブルを前提にしています。一方、`lseg.data` で同じフィールドが同じ名前で取れるとは限りません。したがって、最初に **field availability pilot** を必ず実施します。`2606.25811v1.pdf`

## 14.2 満期日

HGL では TTM がグラフ構造そのものに入るため、満期日が1か月ずれると、仮想TTMグリッドへのリフティングが歪みます。満期補正は価格取得よりも重要です。

## 14.3 価格単位

商品先物はセント建て、ドル建て、ブッシェル、バレル、ガロンなどが混在します。特徴量は中心化・正規化されますが、リターンや異常値検知、価格スケールチェックでは単位ミスが深刻です。

## 14.4 取得コストと API 制限

長期・多数契約の `get_history` は重くなります。Notebook では必ずバッチング、キャッシュ、再開機能、取得ログを入れます。LSEG のドキュメント上も、リクエスト数・レスポンス量・日次制限・エンタイトルメント制限が存在します。([LSEG Developers](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation))

## 14.5 取引コスト未反映

論文の主結果は単位マージン・コストなしの前提が中心です。本番評価では、bid/ask、手数料、証拠金、スプレッド証拠金、枚数丸めを後続フェーズで入れる必要があります。`2606.25811v1.pdf`

---

# 15. 要件定義の結論

この Notebook は、単なるモデル実装ではなく、**契約レベル先物データの監査可能な研究パイプライン**として設計すべきです。

最小構成では、以下を必須にします。

1. `lseg.data` による契約マスター取得  
2. `lseg.data` による日次価格・出来高履歴取得  
3. 契約単位の満期・TTM・流動性フィルタ  
4. 論文準拠の $X_t$ 特徴量  
5. 論文準拠の $Y_{t+2}$ ラベル  
6. 商品間・商品内限月グラフ  
7. 予測値から CS ウェイトへの変換  
8. $t$ 予測、$t+1$ 建玉、$t+2$ 解消のバックテスト  
9. 全ステップの input / output / validation report  
10. キャッシュと監査ログ  

この設計にしておけば、最初は Ridge や LightGBM でパイプライン検証し、その後 HGL を差し替えても、データ・特徴量・ラベル・CS制約・PnL 計算の正しさを保てます。次の段階では、この要件をそのまま Notebook のセル単位設計、つまり「各セルの見出し・処理内容・期待出力・検証条件」に落とすのが自然です。

---

**Sources:**

- [get_data](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-data-function.html)
- [Documentation | Devportal](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation)

## Prompt:
2026/7/1 0:08:23

実装してください

## Response:
2026/7/1 0:08:24

> **Searching official LSEG Data Library documentation**
>
> [LD Lib. Python Tutorial 4 - get_history.ipynb](https://github.com/LSEG-API-Samples/Example.DataLibrary.Python/blob/lseg-data-examples/Tutorials/1.Access/LD%20Lib.%20Python%20Tutorial%204%20-%20get_history.ipynb)
> [How can we pull futures curve for different dates in python?](https://community.developers.lseg.com/discussion/133692/how-can-we-pull-futures-curve-for-different-dates-in-python)
> [Discover our Data Library part 1 | Devportal](https://developers.lseg.com/en/article-catalog/article/discover-data-library-part-1)
> [get_history - Download LSEG Workspace](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html)
> [lseg-data](https://pypi.org/project/lseg-data/)
> [【ロイター×python】lsegデータを取得](https://qiita.com/m_turner/items/1ea16e427f89aa3e371a)
>
> **開いて参考文献を確認し索引作成**
>
> [get_history](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html)
> [The Data Library for Python  - Quick Reference Guide (Access layer) | Devportal](https://developers.lseg.com/en/article-catalog/article/the-data-library-for-python-quick-reference-guide-access-layer)
> [GET CONSTITUENTS OF AN INDEX USING PYTHON CODE - LSEG Developer Community](https://community.developers.lseg.com/discussion/132879/get-constituents-of-an-index-using-python-code)
>
> **Evaluating Pearson and Spearman correlations between variables**
>
>
> **コードセルの抽出とコンパイル**
>
>
> **実行用ノートブックのスクリプト生成**
>
>
> **ノートブックのコードセル確認**
>
>
> **パッチ適用とグラフ構成の更新**
>
>
> **パッチ後のコードコンパイル**
>
>
> **スクリプトの実行とプロット無効化**
>
>
> 思考時間: 24m 4s

実装しました。以下から Notebook をダウンロードできます。

[HGL Calendar Spread LSEG Pipeline Notebook](sandbox:/mnt/data/hgl_calendar_spread_lseg_pipeline.ipynb)

動作確認用に、LSEG 未接続環境では synthetic fallback で一通り実行できることも確認済みです。

[実行確認済み Notebook（synthetic smoke 実行結果付き）](sandbox:/mnt/data/hgl_calendar_spread_lseg_pipeline_executed.ipynb)

今回の Notebook は、添付論文のカレンダー・スプレッド制約、商品内デミーン・ターゲット、two-way centered log-price feature、TTM-aligned graph lifting、CS weight projection の考え方に沿って実装しています。論文では、`n_min_sam=28`、`tau_max=1年`、`n_bas=52`、予測値の商品内平均控除と L1 正規化による CS ウェイト化が使われています。`2606.25811v1.pdf`

LSEG 側は、`lseg.data` の `get_data()` で reference / snapshot data、`get_history()` で履歴データを取る設計にしています。Desktop session は Workspace / Eikon 側の Data API Proxy を使う前提なので、実行環境では Workspace または Eikon の起動・設定が必要です。([LSEG Developers](https://developers.lseg.com/en/article-catalog/article/discover-data-library-part-1))

## 実装内容

Notebook には以下を入れています。

| ブロック | 内容 |
|---|---|
| Config | LSEG 接続、期間、`n_min_sam=28`、`tau_max_days=365`、`n_bas=52`、`rho_star`、field candidates |
| LSEG取得 | `open_session()`、`get_data()`、`get_history()`、batching、retry、fetch log |
| seed universe | `config/universe_seed.csv` テンプレート自動生成 |
| contract master | RIC、商品ID、通貨、取引所、契約月、満期、tick、倍率、単位 |
| market clean | 価格・出来高整形、単位補正フック、満期後除外、重複除外、価格異常 warning |
| trading calendar | データ coverage に基づく trading date 判定 |
| universe snapshot | `t` 時点で `t+1` 建て、`t+2` 解消可能な契約集合 |
| returns | 個別契約リターン、observable flag |
| features | 論文式の two-way centered log-price feature + normal score |
| labels | `t+1` to `t+2` の商品内デミーン・リターン + normal score |
| graph | `CC_POS`, `CC_NEG`, `CU`, `UC`, `UU`、lifting / lowering weights |
| model | Ridge baseline、optional HGL-lite |
| CS weights | 予測値の商品内デミーン + 全体 L1 正規化 |
| backtest | unit-margin PnL、IR、Sortino、Hit、MDD、turnover |
| audit | 各ステージの input / output summary、保存ファイル、fetch log |

## 使い方

最初に Notebook を開き、`CONFIG` の以下を確認してください。

```python
'data_source': 'lseg'
'allow_synthetic_fallback': True
'start_date': '2021-01-01'
'end_date': '2024-12-31'
'model_names': ['ridge']
```

まずはこのまま実行すると、LSEG セッションが開けない環境では synthetic fallback でパイプライン全体を確認できます。LSEG 実データで実行する場合は、`config/universe_seed.csv` に個別先物契約 RIC と `commodity_id` を入れてください。

```csv
ric,commodity_id,commodity_name,exchange,currency
<individual contract RIC>,CL,Crude Oil,NYMEX,USD
<individual contract RIC>,CL,Crude Oil,NYMEX,USD
<individual contract RIC>,GC,Gold,COMEX,USD
```

重要なのは、**連続先物 RIC ではなく個別契約 RIC**を入れることです。この戦略は限月間の相対リターンを扱うため、連続先物では再現できません。

## HGL-lite について

デフォルトではまず Ridge のみ実行する設定にしています。データ取得・満期処理・特徴量・ラベル・CS 制約を先に検証するためです。

HGL-lite を実行する場合は、CONFIG の該当行を以下に変更してください。

```python
'model_names': ['ridge', 'hgl_lite']
```

HGL-lite は、論文の

```text
lower contract nodes
  -> virtual TTM lifting
  -> inter-commodity CC propagation
  -> lowering
  -> intra-commodity neighboring maturity UU propagation
  -> prediction head
```

を PyTorch で実装しています。ただし、これは Notebook 内で検証しやすい compact implementation です。論文表1のような `GCN/SAGE/GAT × rho_star × layer × parameter size` の完全 grid search までは入れていません。まずこの Notebook でデータマートと CS 制約を固め、その後に PyTorch Geometric 版や walk-forward grid search に拡張する設計です。

## 実データ実行時に確認すべき箇所

Notebook 上で各 Stage ごとに以下が表示されます。

- 行数・列数
- 日付範囲
- 契約数・商品数
- duplicate key 数
- missing report
- selected LSEG field
- `universe_snapshot` の日次契約数
- `features_hgl` の分布
- `labels_hgl` の分布
- graph edge 数
- CS ウェイト制約チェック
- backtest metrics

特に最初に確認すべきなのは以下です。

```text
selected_history_fields
contract_master_clean
daily_market_clean
universe_snapshot
features_hgl
labels_hgl
positions
```

`selected_history_fields` で価格・出来高フィールドが正しく選ばれていない場合は、Notebook 冒頭の `FIELD_CANDIDATES` を編集してください。LSEG の利用可能フィールドは契約・エンタイトルメント・アクセス経路で変わるため、field candidates 方式にしています。

## 注意点

この Notebook は、研究・検証用の一気通貫 MVP 実装です。取引コスト、証拠金、スプレッド証拠金、実約定 bid/ask、枚数丸めは監査列として取り込める構造にしていますが、初期 PnL は論文同様に unit-margin / costless に近い評価です。実運用検証では、次に `contract_multiplier`、tick、bid/ask、fee、margin、spread margin を使った net PnL に拡張してください。

---

**Sources:**

- [https://developers.lseg.com/en/article-catalog/article/discover-data-library-part-1](https://developers.lseg.com/en/article-catalog/article/discover-data-library-part-1)



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)