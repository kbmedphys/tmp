# 数理・統計モデル仕様

文書ID: JIN-MOD-001  
版: 1.0  
対応要件: FR-SUP、FR-ENV、FR-RL、FR-CAL、FR-ENS、FR-SCEN

## 1. モデルの位置づけ

本システムは、次の四つの予測器を同一の時点整合データ上で運用し、観測条件付きアンサンブルで結合する。

1. 単純ベンチマーク
2. 教師あり二部価格改定モデル
3. 制度価格ルール・直接政策効果モジュール
4. 品目・業種別の構造価格設定シミュレータ

添付論文から移植するのは、方策関数のニューラルネット近似、シミュレーション経路による目的評価、離散・連続行動、制約を満たす出力変換、Parameter-Exploring Policy Gradient、mirrored sampling、時間入力によるパラメータ共有という解法思想である。資産配分モデル自体は再現しない。

公開データだけのMVPでは、企業個票の価格改定ではなくCPI基本品目指数の月次変化を観測対象とする。そのため、以下でいう「価格改定確率」は基本品目指数が実質的に変化する確率の代理であり、企業レベルのCalvo確率やメニューコストを直接識別したものではない。

## 2. 記号と時間軸

- 月次時点: `t = 1, ..., T`
- 予測起点日時: `tau`。月だけでなく公表時刻を含む。
- CPI基本品目または最細粒度ノード: `i = 1, ..., I`
- 構造主体群: `g(i) = 1, ..., G`。既定は30〜60群。
- 予測ホライズン: `h in {0, 1, 3, 6, 12}`
- 品目指数水準: `P[i,t] > 0`
- 対数変化: `y[i,t] = log(P[i,t] / P[i,t-1])`
- 公表時点情報集合: `I_tau`
- 政策状態: `G_t`
- 外生ショック: `eps_t`

月次変数のreference periodと、実際のrelease timestampは必ず分離する。

## 3. CPI集計

### 3.1 水準集計

任意の集計ノード `A` の指数水準は、有効期間内のウェイト版 `v(t)` を用いて算出する。

```text
P[A,t] = sum_{i in children(A)} w[i,v(t)] * P[i,t] / sum_{i in children(A)} w[i,v(t)]
```

公式系列の定義が加重算術平均と異なる場合は、公式方式を個別strategyとして実装する。最終的な前年比・前月比は集計水準から計算する。

```text
mom[A,t] = P[A,t] / P[A,t-1] - 1
yoy[A,t] = P[A,t] / P[A,t-12] - 1
```

ログ寄与は診断に使用できるが、最終集計の代替にしない。

### 3.2 寄与

前月比の品目寄与は、集計値との差が丸め誤差内になる方式で算出する。APIは次を返す。

```python
@dataclass(frozen=True)
class ContributionResult:
    aggregate_change: float
    item_contributions: ArrayLike
    residual: float
    weight_version: str
```

`abs(residual) <= tolerance` をテストする。

## 4. ベンチマークモデル

全モデルは次のProtocolを満たす。

```python
class ForecastModel(Protocol):
    def fit(self, dataset: TrainingDataset, *, seed: int) -> FittedModel: ...
    def predict(
        self,
        features: ForecastFeatures,
        *,
        horizons: Sequence[int],
        seed: int,
    ) -> ForecastDistribution: ...
```

必須モデル:

- SeasonalNaive: `P[t+h] = P[t+h-12] * P[t] / P[t-12]` 等、設定可能な季節ナイーブ
- AutoRegressiveRidge: lag、季節lag、外生変数を持つridge
- LinearBridge: 東京CPI、上流価格、為替等の公表済み値を用いる線形ブリッジ

すべてのベンチマークは予測分布を返す。解析的分散がない場合は、学習残差のblock bootstrapを用いる。

## 5. 教師あり二部価格改定モデル

### 5.1 観測ラベル

基本ラベル:

```text
z[i,t] = 1(|y[i,t]| > delta_i)
```

- `delta_i` は観測丸め、指数精度、品目ボラティリティを考慮した閾値。
- 既定は設定値とし、学習データ全期間を見て最適化しない。
- 価格下落も改定として扱う。

改定幅ラベル:

```text
m[i,t] = y[i,t] | z[i,t] = 1
```

### 5.2 入力

```text
x[i,t,tau] = concat(
    item_static[i],
    item_embedding[i],
    sector_embedding[g(i)],
    item_lags[i,t],
    macro_asof[t,tau],
    policy_known[t,tau],
    missing_mask[t,tau],
    staleness[t,tau],
    calendar[t]
)
```

同じreference monthでも予測起点 `tau` によって入力が変わる。

### 5.3 ネットワーク

既定:

- 共通trunk: 2層MLP、各128ユニット、SiLU
- item embedding: 16次元
- sector embedding: 8次元
- hazard head: Bernoulli logit
- magnitude head: Student-tのlocation、positive scale、degrees of freedom
- 任意のaggregate auxiliary head

出力変換:

```text
p[i,t] = sigmoid(hazard_logit)
scale[i,t] = softplus(raw_scale) + scale_floor
nu[i,t] = 2 + softplus(raw_nu)
```

### 5.4 予測分布

二部混合:

```text
Y[i,t] = 0                                with probability 1 - p[i,t]
Y[i,t] ~ StudentT(nu, loc, scale)          with probability p[i,t]
```

実際の指数が小数丸めにより完全なゼロを取りにくい系列では、zero componentを狭いNormalへ置換可能とする。

### 5.5 損失

```text
L_sup = lambda_h * BCE(z, p)
      + lambda_m * z * NLL_StudentT(m; loc, scale, nu)
      + lambda_a * L_aggregate
      + lambda_r * regularization
```

`L_aggregate` は、Monte Carloまたは解析近似で品目予測を水準へ戻してCPI集計した誤差。学習時のウェイトはその時点で有効な版だけを使う。

### 5.6 複数期予測

MVPはdirect multi-horizon方式とする。各horizonにheadを持たせるか、horizon embeddingを入力する。recursive方式は誤差伝播を診断できる拡張として残す。

### 5.7 事前学習としての利用

構造方策ネットワークの初期値は、教師ありモデルのhazardとmagnitude headから移植できる。ただし、移植の有無を設定とrun manifestに記録する。

## 6. 構造価格設定環境

### 6.1 レジーム

`regime[i]` は次のいずれか。

- `market_goods`
- `market_services`
- `energy_fresh`
- `administered`

レジームごとに状態、遷移、行動可能集合、報酬項を切り替える。全品目を同一の企業最適化問題へ押し込まない。

### 6.2 状態

最小状態型:

```python
@struct.dataclass
class EnvState:
    period_index: jax.Array
    price_level: jax.Array
    relative_price_gap: jax.Array
    duration_since_adjustment: jax.Array
    input_cost_index: jax.Array
    wage_cost_index: jax.Array
    demand_index: jax.Array
    inventory_or_capacity: jax.Array
    exchange_rate: jax.Array
    energy_prices: jax.Array
    expectations: jax.Array
    survey_price_diffs: jax.Array
    policy_state: jax.Array
    regime_state: jax.Array
    missing_mask: jax.Array
    staleness: jax.Array
```

状態はJAX pytreeであり、shapeを静的に保つ。文字列や可変長辞書をrollout内部へ入れない。

### 6.3 投入費用

業種投入費用は産業連関係数 `B[g,j]` と上流価格から作る。

```text
Delta log C[g,t] = sum_j B[g,j] * Delta log Q[j,t]
                 + beta_w[g] * Delta log W[g,t]
                 + beta_fx[g] * Delta log FX[t]
                 + beta_e[g] * Delta log Energy[t]
                 + u_c[g,t]
```

`B` の行は使用対象投入に対して正規化し、版、有効年、出典を保存する。

### 6.4 行動

市場財・市場サービス:

```python
@struct.dataclass
class MarketAction:
    adjust: jax.Array          # {0, 1}
    log_price_change: jax.Array
```

実装上は離散headと連続headを持つ。

```text
adjust = argmax(discrete_logits) during evaluation
adjust = epsilon-greedy(discrete_logits) during training
log_price_change = max_change * tanh(raw_change)
realized_change = adjust * log_price_change
```

`max_change` は品目・レジーム別設定。大きな価格変化を必要とする制度変更は直接政策効果側で処理し、安易に上限を広げない。

エネルギー・生鮮:

- 価格設定方策より、商品価格・為替・季節性・料金式を重視する。
- 調整headを使わない設定を許す。

制度価格:

```python
@struct.dataclass
class AdministeredAction:
    scheduled_adjustment: jax.Array
    discretionary_component: jax.Array
```

原則として政策イベントと料金式から決まり、裁量成分だけを推定する。

### 6.5 状態遷移

基本価格遷移:

```text
log P[i,t+1] = log P[i,t]
             + a_adjust[i,t] * delta[i,t]
             + direct_policy_effect[i,t]
             + pass_through_residual[i,t]
```

相対価格ギャップ:

```text
q[i,t] = log P[i,t] - log P_star[i,t]
```

柔軟価格の参照値:

```text
log P_star[i,t] = markup[i]
                + alpha_c[i] log C[i,t]
                + alpha_w[i] log W[i,t]
                + alpha_d[i] log D[i,t]
                + alpha_r[i] relative_competitor_price[i,t]
```

MVPでは `P_star` の係数を教師あり推定またはSMM較正する。

### 6.6 報酬

市場主体の一期間報酬:

```text
r[i,t] = operating_margin[i,t]
       - kappa[i] * a_adjust[i,t]
       - lambda_delta[i] * delta[i,t]^2
       - lambda_share[i] * share_loss[i,t]
       - lambda_gap[i] * q[i,t+1]^2
       - constraint_penalty[i,t]
```

例:

```text
operating_margin = (P - MC) * D(P, aggregate_demand)
D = demand_scale * exp(-elasticity * relative_price)
```

目的関数:

```text
J(theta; psi) = E[sum_{t=0}^{H-1} beta^t sum_i omega_i r[i,t]]
```

- `theta`: 方策ネットワークパラメータ
- `psi`: 構造環境パラメータ
- `omega_i`: CPIウェイトまたは較正用の主体重み

報酬は観測可能な企業利潤を直接復元したものではなく、価格改定モーメントを再現する規律付けである。レポートでは「モデル内目的」と表現する。

### 6.7 方策ネットワーク

既定はレジーム別の共有ネットワーク。

```text
policy_r(state_i, item_embedding_i, sector_embedding_i, time_embedding_t)
```

- hidden layers: 2
- hidden width: 128
- activation: SiLU
- layer norm: 既定off、設定可能
- time: 正規化した月インデックス、月ダミー、horizon残存率
- output heads: discrete adjustment、continuous magnitude、任意のquantity/inventory

論文同様、時点ごとに別ネットワークを持たず、時間を入力してパラメータ共有する。

### 6.8 rollout

JAX実装:

```python
def rollout(
    policy_params: Params,
    env_params: EnvParams,
    initial_state: EnvState,
    shock_path: ShockPath,
    policy_path: PolicyPath,
) -> RolloutResult:
    return jax.lax.scan(step_fn, initial_state, xs=(shock_path, policy_path))
```

- 品目・主体方向: `jax.vmap`
- シミュレーション経路方向: `jax.vmap`
- 時間方向: `jax.lax.scan`
- MVPは単一デバイス
- `jit` 境界はrollout、loss、train_step

## 7. PEPG学習器

### 7.1 パラメータ摂動

方策パラメータをflattenした平均 `mu` の周りで、対称摂動を評価する。

```text
epsilon_k ~ N(0, I)
theta_k_plus  = mu + sigma * epsilon_k
theta_k_minus = mu - sigma * epsilon_k
```

同一 `k` の正負ペアは、同じinitial state、同じ環境ショック、同じ政策pathを使う。

### 7.2 勾配推定

```text
g_mu = mean_k[((R_k_plus - R_k_minus) / (2 * sigma)) * epsilon_k]
```

報酬のscaleが大きい場合、rank normalizationまたはcentered ranksを設定可能とする。ただし生報酬も記録し、変換で悪化を隠さない。

更新:

```text
mu <- optimizer_update(mu, +g_mu)
```

実装上はloss最小化の符号と混同しないよう、`objective_to_maximize` と `optimizer_loss` を明示する。

### 7.3 探索

- parameter noise `sigma`: 正値から0または小さなfloorへanneal
- entropy coefficient: 正値から0へanneal
- epsilon-greedy probability: 正値から0へanneal
- 評価時: parameter noise 0、entropy加算なし、epsilon-greedy 0

scheduleは次の共通interfaceを使う。

```python
class Schedule(Protocol):
    def value(self, step: int) -> float: ...
```

### 7.4 running normalization

状態正規化は訓練rolloutから得るrunning mean/varianceを用いる。

- Welfordまたは指数移動平均
- warmup期間は更新
- 安定後はfreeze可能
- 評価時に更新しない
- normalization stateをcheckpointへ保存

### 7.5 計算プロファイル

| profile | mirrored pairs | candidate vectors | paths per candidate | horizon | 用途 |
|---|---:|---:|---:|---:|---|
| smoke | 8 | 16 | 4 | 6〜12 | CI・CPU |
| dev | 64 | 128 | 16 | 24〜60 | ローカル検証 |
| research | 256以上 | 512以上 | 64以上 | 設定値 | 本学習 |
| paper_scale | 約1024 | 2048 | 256 | 設定値 | 添付論文の計算規模を参照する比較用。MVP必須外 |

実際のshapeは2の累乗またはハードウェア効率のよい値を推奨するが、正しさをshape依存にしない。

### 7.6 収束診断

各iterationで保存する。

- mean、median、std、p10/p90 reward
- positive/negative pair reward correlation
- gradient norm
- `mu` norm、update norm
- sigma、entropy、epsilon
- adjustment frequency、mean adjustment size
- NaN/Inf count
- constraint violation count

早期停止は、validation momentsとobjectiveの両方を参照する。

## 8. 外側SMM較正

### 8.1 目的

構造パラメータ `psi` は、観測モーメントとシミュレーションモーメントの距離で較正する。

```text
Q(psi) = [m_data - m_sim(psi, theta_star(psi))]' W [m_data - m_sim(...)]
```

`theta_star(psi)` は内側PEPGで得た方策。

### 8.2 初期モーメント

- 品目・群別の非ゼロ変化頻度
- 正・負改定幅の平均、分位点
- 据置期間分布
- 4月、10月等の価格変化集中度
- 為替・輸入物価からの分布ラグ
- 賃金からサービス価格への分布ラグ
- Tankan販売価格DIとの相関・方向整合性
- CPI群別volatilityとcross-correlation

### 8.3 実装戦略

MVP:

1. `psi` の低次元範囲を設定
2. Latin hypercubeまたはSobolで候補生成
3. 各候補を短いPEPGで評価
4. surrogateまたはCMA-ES/Optunaで絞り込み
5. 上位候補を長いPEPGで再評価

完全な二重ループを毎回回さないよう、`hash(env_config, psi, data_snapshot, seed)` をキーにcheckpointとmomentsをキャッシュする。

### 8.4 識別と感度

- profile likelihoodまたは局所感度
- 複数初期値
- 重み行列 `W` の代替
- モーメント集合のleave-one-out
- 弱識別パラメータの固定・範囲縮小

結果は点推定だけでなく許容領域を報告する。

## 9. 観測条件付きアンサンブル

### 9.1 入力予測

各モデル `m` は、品目または集計系列について予測サンプル `S[m,n,h]` を返す。

### 9.2 結合

MVPは、過去の疑似リアルタイム損失からnon-negative simplex weightsを推定する。

```text
w_star = argmin_w sum_tau Loss(y_tau, sum_m w_m f_m,tau)
subject to w_m >= 0, sum_m w_m = 1
```

- horizon・aggregate・release stage別に重みを持てる。
- 学習窓は予測起点より前だけ。
- 小標本ではridge toward equal weightsを使う。

### 9.3 観測更新

新規公表が到着したら、同じtarget monthについてfeature setを再構築し、release stageを更新する。

例:

- stage 0: 月初
- stage 1: 上流価格・賃金等の主要月次統計後
- stage 2: 東京都区部CPI後
- stage 3: 全国CPI直前

stageは固定のカレンダー名ではなく、実際の公表済みフラグから決める。

### 9.4 不確実性較正

- rolling coverageを計測
- 必要時、validation residualに基づくconformalized quantile adjustment
- 政策シナリオでは、パラメータ不確実性、ショック不確実性、政策仕様不確実性を可能な範囲で別タグにする

## 10. 政策シナリオ

### 10.1 ベースライン

ベースラインは予測起点で既知の政策だけを含む。未発表の将来政策を自動的に継続・終了させない。既定の継続仮定は設定へ明示する。

### 10.2 介入演算

- `remove(event_id)`
- `scale(event_id, factor)`
- `shift(event_id, months)`
- `replace(event_id, replacement_event)`
- `add(new_event)`

すべて型検証し、原イベントを上書きせず新しいscenario manifestを作る。

### 10.3 効果の定義

同一ショック `omega_n` で比較する。

```text
TotalEffect[h] = mean_n(Inflation_scenario[n,h] - Inflation_base[n,h])
```

分離では、`F0`をベースライン、`FD`を直接価格ルールだけ変更、`FDE`を直接ルールに加えて主体方策を再評価、`FDES`を二次遷移まで許した完全シナリオとする。

```text
DirectEffect = FD - F0
Endogenous   = FDE - FD
SecondRound  = FDES - FDE
TotalEffect  = FDES - F0
```

実装時は、各カウンターファクチュアルの固定対象を明確にする。単純な特徴量除去を政策効果と呼ばない。

### 10.4 Shapley分解

政策集合 `N` に対し、価値関数を総インフレ差分 `F(S)` とする。

```text
phi_j = sum_{S subset N\{j}} |S|!(|N|-|S|-1)!/|N|! * [F(S union {j}) - F(S)]
```

- `|N| <= exact_threshold`: exact
- それ以上: permutation Monte Carlo
- 同じpermutation内の比較は共通乱数
- `sum_j phi_j` と `F(N)-F(empty)` の差を出力

## 11. 出力契約

予測分布:

```python
@dataclass(frozen=True)
class ForecastDistribution:
    item_ids: tuple[str, ...]
    horizons: tuple[int, ...]
    samples: np.ndarray | None
    quantiles: Mapping[float, np.ndarray]
    point: np.ndarray
    metadata: ForecastMetadata
```

必須不変条件:

- quantile axisは単調
- shapeとID順序が一致
- pointは既定でmedian
- sample/quantileの単位を明示
- NaNを無言で落とさない

シナリオ出力:

```python
@dataclass(frozen=True)
class ScenarioEffect:
    baseline: ForecastDistribution
    scenario: ForecastDistribution
    direct: np.ndarray
    endogenous: np.ndarray
    second_round: np.ndarray
    total: np.ndarray
    common_random_number_id: str
```

`direct + endogenous + second_round` と `total` は許容誤差内で一致する。

## 12. モデルカードで必ず明記する限界

- 公開CPI指数を価格設定行動の代理としていること
- 政策シナリオは構造仮定に条件付きのモデルベース反実仮想であること
- 政策導入の内生性を完全には除去していないこと
- 過去ビンテージの品質区分
- 構造パラメータの識別と感度
- 精度がベンチマークを上回らない期間・系列
- 制度価格ルールの手作業依存部分
