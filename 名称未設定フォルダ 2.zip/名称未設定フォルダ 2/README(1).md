# 日本インフレ構造ナウキャスト: Codex実装仕様パッケージ

このパッケージは、Duarte, Fonseca, Goodman and Parker (2024) の高次元動学問題に対する深層強化学習の設計思想を、日本のCPI予測・ナウキャスト・政策シナリオ分析へ移植するための実装仕様です。

## 1. 重要な設計判断

- 最終形は、`リアルタイム観測層 -> 品目・業種別価格設定層 -> 政策シナリオ層` のハイブリッド構造とする。
- 実装は一括で行わず、次の順に段階化する。
  1. データ・ビンテージ基盤
  2. ベンチマークと教師ありナウキャスト
  3. 構造シミュレータ
  4. Parameter-Exploring Policy Gradient (PEPG)
  5. 政策介入、寄与分解、運用化
- 公開データだけで実装するMVPでは、企業の個別価格改定ではなく、CPI基本品目指数の改定を代理変数として扱う。メニューコスト等を企業レベルで識別したとは主張しない。
- 厳密な疑似リアルタイム検証を必須とし、将来公表値、最新改定値、政策発表後の情報を過去の予測起点へ混入させない。
- 制度効果は単なる特徴量重要度ではなく、政策変数への明示的介入と共通乱数による反実仮想差分で測る。

## 2. パッケージ構成

- `AGENTS.md`: Codexが毎回読み込むリポジトリ共通指示
- `docs/REQUIREMENTS.md`: 要件定義書
- `docs/MODEL_SPEC.md`: 数理・統計モデル仕様
- `docs/DATA_SPEC.md`: データ、ビンテージ、制度イベント仕様
- `docs/ARCHITECTURE.md`: ソフトウェア構成、インターフェース、CLI
- `docs/TEST_PLAN.md`: テスト、バックテスト、受入基準
- `docs/CODEX_TASKS.md`: Codexへ順番に渡す実装タスク
- `docs/TRACEABILITY_MATRIX.md`: 要件・実装・テストの対応表
- `docs/CODE_REVIEW.md`: モデル固有のレビュー観点
- `docs/PLANS_TEMPLATE.md`: 長時間タスク用の実行計画テンプレート
- `docs/SOURCE_NOTES.md`: 参照資料と設計根拠
- `configs/*.yaml`: 設定例
- `schemas/*.json`: 入出力契約のJSON Schema
- `examples/`: schema検証用の架空データとシナリオ

## 3. Codexでの利用手順

1. このパッケージを空のGitリポジトリ直下へ展開する。
2. Codexをリポジトリ直下から起動する。
3. 最初に次を実行し、`AGENTS.md`が読み込まれていることを確認する。

```bash
codex --ask-for-approval never "現在有効な指示を要約し、Task 00以外には着手しないことを確認してください。"
```

4. `docs/CODEX_TASKS.md` の Task 00 から1件ずつ実行する。複数タスクを同時に依頼しない。
5. 各タスク完了後に、テスト結果、変更ファイル、未解決事項を確認してから次へ進む。
6. 重要な区切りではCodexのレビュー機能または `docs/CODE_REVIEW.md` を使って別視点のレビューを行う。

## 4. 実装後の標準コマンド

Task 00で以下のコマンドを利用可能にすることを想定しています。

```bash
make setup
make fmt
make lint
make typecheck
make test
make test-smoke
make backtest-smoke
make nowcast-smoke
```

同等の `uv run ...` コマンドも提供してください。

## 5. 仕様の優先順位

矛盾がある場合は、次の順に優先します。

1. `AGENTS.md` の不変条件
2. `docs/REQUIREMENTS.md` の受入基準
3. `docs/MODEL_SPEC.md` と `docs/DATA_SPEC.md` の契約
4. 対象タスクの指示
5. 実装上の便宜

実装上の便宜を理由に、ビンテージ、時点整合性、政策既知時点、再現性を弱めてはいけません。

## 6. 参照資料

- Duarte, V., Fonseca, J., Goodman, A., and Parker, J. A. (2024), *Simple Allocation Rules and Optimal Portfolio Choice Over the Lifecycle*（ユーザー添付論文）
- OpenAI, Codex Best Practices: https://developers.openai.com/codex/learn/best-practices
- OpenAI, Custom instructions with AGENTS.md: https://developers.openai.com/codex/guides/agents-md
- 総務省統計局 CPI: https://www.stat.go.jp/data/cpi/
- e-Stat API: https://www.e-stat.go.jp/api/
- 日本銀行時系列統計データ検索: https://www.stat-search.boj.or.jp/

仕様作成日: 2026-06-18
