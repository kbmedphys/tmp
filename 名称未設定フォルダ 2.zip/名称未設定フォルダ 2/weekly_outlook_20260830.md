# Sector Gamma 週次見通し・リバランス案 — 2026年8月30日

**データ基準:** 2026年8月28日米国引け / 2026年8月30日JST更新  
**振り返り期間:** 2026年8月21日引け → 8月28日引け  
**見通し期間:** 2026年8月31日 → 9月4日  
**対象:** S&P 500 11セクターETF + IEF（米国7–10年国債）

> 本資料は研究・モデル運用のためのもので、個別の投資助言ではない。GEXは公開オプションチェーンからcallを正、putを負として計算した需給プロキシであり、実際のディーラーポジションを直接観測したものではない。配分損益はETFの調整済み終値によるモデル計算で、外部記事のセクター指数騰落率はクロスチェックに用いる。

## 結論

今回の提案は、**株式を58.23%から57.49%へ0.73ポイント減らし、IEFを41.77%から42.51%へ増やす**。60/40基準に対しては株式-2.51ポイント、IEF+2.51ポイントである。株式内では **XLV・XLB・XLEをOverweight、XLF・XLP・XLY・XLI・XLCをUnderweight** とし、XLRE・XLK・XLUはNeutralとする。

判断の中心は四点である。

1. **先週の戦術配分は小幅に負けた。** 8月21日→28日の60/40基準収益率は+0.110%、前回提案は+0.088%、超過収益は**-2.20bp**。XLI Underweightは奏功したが、XLC UnderweightとXLE・XLRE Overweightが相殺した。
2. **指数上昇は大型テクノロジー主導で、セクターの広がりは弱かった。** S&P 500は+0.45%、Nasdaqは+0.83%だった一方、Russell 2000は-1.33%。情報技術+1.93%、通信+1.46%、金融+1.05%に対し、エネルギー-2.26%、ヘルスケア-2.23%、資本財-1.70%だった。[LPL週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-august-28-2026.html)
3. **株式オプションのbreadthはなお弱い。** 11セクター中、正のAdjusted ScoreはXLV・XLRE・XLB・XLEの4セクターだけで、ベンチマーク加重の株式スコアは-0.068、breadthを含む株式合成スコアは-0.184となった。特にXLI・XLC・XLYは負GammaかつFlip下である。
4. **IEFは強気一辺倒ではないが、株式より相対的に良い。** IEFのオプションAdjusted Scoreは+0.094、BEIオーバーレイは+0.082、合成後は+0.091。株式対IEF相対スコアは-0.276となり、IEFを42.51%へ増やす。ただし実質金利は上昇しており、92/91.81割れでは増額を止める。

## データ品質と8月28日終値の扱い

- 8月30日の実行時、yFinanceの日次系列は全13銘柄で8月28日行を空欄として返した。一方、StockAnalysis上ではS&P Global Market Intelligence配信として同日の調整済み終値が公開されていた。
- Notebookに、**週末実行時に完了済み金曜日だけが欠落した場合に限るフォールバック**を追加した。13銘柄の8月28日終値を補完し、オプション計算のspotも同じ終値へ同期した。通常時は引き続きyFinanceを優先する。[StockAnalysisの価格データ例（XLK）](https://stockanalysis.com/etf/xlk/history/)
- 補完した全銘柄、終値、参照URLは `outputs/tables/price_fallback.csv` と日付別parquetに保存した。これにより前週検証は8月21日→28日のちょうど7日間となった。

## 先週の振り返り

### 市場で確認された事実

- S&P 500は週間+0.45%、Dowは+0.49%、Nasdaqは+0.83%だったが、Russell 2000は-1.33%。金曜単日はWarsh議長発言後の金利上昇を受け、S&P 500-0.2%、Nasdaq-0.5%、Russell 2000-1.4%となった。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-august-28-2026.html) / [AP](https://apnews.com/article/wall-street-stocks-dow-nasdaq-3f3477bcea915ac53ec2ae905ae57919)
- 7月PCEは前月比+0.2%、コアPCEも+0.2%。前年比は総合+3.7%、コア+3.3%。名目PCEは+0.2%だった一方、実質PCEはほぼ横ばいで、インフレの粘着性と実質消費の鈍さが同居した。[BEA Personal Income and Outlays](https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026)
- Q2実質GDPの第2次推計は年率+1.5%で据え置かれたが、民間国内最終需要は+4.2%へ上方修正、企業利益は前期比年率換算額で400.9十億ドル増加した。需要の芯と企業収益はGDP総額より強かった。[BEA Q2 GDP第2次推計](https://www.bea.gov/news/2026/gdp-second-estimate-and-corporate-profits-2nd-quarter-2026)
- NVIDIAは売上高962億ドル（前年比+106%）、データセンター売上890億ドル（+117%）、次四半期売上見通し1,080億ドル±2%を公表した。AI投資の継続性を確認し、XLKの週次反発につながった。[NVIDIA公式IR](https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-Second-Quarter-Fiscal-2027/default.aspx)
- Warsh議長は雇用を概ね完全雇用と評価する一方、PCEインフレ3.7%を問題視し、基調インフレが目標へ十分な速度で向かわなければ追加対応が必要との基準を示した。金曜に2年金利は13bp上昇し、10年金利も約5bp上昇した。[Federal Reserve公式講演](https://www.federalreserve.gov/newsevents/speech/warsh20260828a.htm) / [当日の市場反応](https://www.kiplinger.com/investing/stocks/stocks-turn-down-as-warsh-talks-up-rates-stock-market-today)
- 原油は週間-4.27%。エネルギーの先週までの強さが一服し、XLE Overweightには逆風となった。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-august-28-2026.html)

### 前回提案の実績

60/40基準は+0.110%、戦術配分は+0.088%、超過収益は**-2.20bp**だった。S&P 500の+0.45%と差があるのは、本モデル基準が株式60%・IEF40%であり、株式部分も11セクターETFの固定ベンチマークだからである。

| ETF | 前回判断 | ETF騰落率 | Active寄与 | 評価 |
|---|---|---:|---:|---|
| XLI | Underweight | -1.73% | **+1.54bp** | 負Gamma・Flip下の減額が奏功 |
| XLV | Neutral | -1.98% | +0.33bp | 株式バケット縮小分が小幅に寄与 |
| XLY | Underweight | -0.69% | +0.31bp | 消費警戒が奏功 |
| XLP | Neutral | -0.63% | +0.13bp | 小幅プラス |
| IEF | Overweight | +0.03% | +0.06bp | 週中上昇を金曜の金利上昇がほぼ相殺 |
| XLF | Neutral | +1.08% | -0.32bp | 金融上昇を取り切れず |
| XLB | Overweight | -0.67% | -0.47bp | 製造業・商品市況の伸び悩み |
| XLRE | Overweight | -1.33% | **-0.75bp** | 実質金利上昇が逆風 |
| XLK | Neutral | +1.30% | **-0.81bp** | 株式バケット減額によりAI反発を取り切れず |
| XLE | Overweight | -1.51% | **-0.92bp** | 原油反落で失敗 |
| XLC | Underweight | +1.43% | **-1.31bp** | 大型成長株反発を過小評価 |

前回の守りはXLIとXLYでは機能したが、**「正Gammaなら商品・金利逆風にも耐える」と見たXLE・XLREの判断が甘かった**。またXLCは負Gammaでも週次上昇し、方向シグナルを大型株の決算・AIセンチメントが上回った。今週は、XLREをNeutralへ戻し、XLC Underweightは維持するものの追加削減を0.05ポイントに限定する。

## 金利・BEIとIEFの見通し

### 確認された事実

- 8月28日の5年BEIは2.30%、10年BEIは2.31%。8月21日の2.34%/2.34%から、それぞれ-4bp/-3bp低下した。40/60加重BEIは2.306%、5営業日変化-3.4bp、20営業日変化+3.4bpである。[FRED 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [FRED 10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- 8月21日→28日に5年名目金利は4.43%→4.48%（+5bp）、5年実質金利は2.09%→2.18%（+9bp）。10年名目金利は4.74%→4.73%（-1bp）、10年実質金利は2.40%→2.42%（+2bp）だった。[米財務省・名目イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve) / [米財務省・実質イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_real_yield_curve)
- したがってBEI低下はIEFに追い風だが、実質金利上昇がその効果を相殺した。IEFは92.82→92.85、週間+0.03%にとどまった。

### モデル推論

- IEFのオプションAdjusted Scoreは+0.094。現値92.85はGamma Flip 91.81とPut Wall 92を上回り、Net GEXは+236.1百万。Call Wallは94、7日1σレンジは92.09–93.61である。
- BEIオーバーレイは+0.082。5日BEI低下はdurationに追い風だが、20日ではまだ+3.4bpであり、強い債券強気にはしない。オプション75%・BEI25%の最終スコアは+0.091となる。
- IEFは20日線93.07、50日線93.26を下回り、Vanna集中78.2%、Charm集中92.5%と高い。イベント後のIV低下・時間経過によるヘッジフロー変化が大きいため、一括買いは避ける。
- 9月4日の雇用統計が弱くBEIも2.30%以下なら、利上げ期待後退と実質金利低下の組み合わせでIEF 93.61–94を試しやすい。反対に雇用・ISMが強く、BEIが2.35%以上へ戻る、またはIEFが91.81を割るなら増額を停止する。

## 今週のリバランス案

### 配分と売買

| ETF | 新配分 | 前回配分 | 売買 | 60/40基準比 | モデル判断 |
|---|---:|---:|---:|---:|---|
| IEF | **42.51%** | 41.77% | **+0.73pt** | +2.51pt | Overweight |
| XLK | **18.90%** | 19.10% | -0.20pt | -0.82pt | Neutral |
| XLF | **7.03%** | 7.26% | -0.23pt | -0.52pt | Underweight |
| XLV | **6.56%** | 5.53% | **+1.03pt** | +0.87pt | Overweight |
| XLC | **5.21%** | 5.26% | -0.05pt | -0.97pt | Underweight |
| XLY | **5.18%** | 5.49% | -0.31pt | -0.76pt | Underweight |
| XLI | **4.60%** | 4.50% | +0.09pt | -0.80pt | Underweight |
| XLE | **2.97%** | 3.01% | -0.04pt | +0.57pt | Overweight |
| XLP | **2.83%** | 2.97% | -0.14pt | -0.35pt | Underweight |
| XLB | **1.73%** | 1.96% | -0.23pt | +0.47pt | Overweight |
| XLU | **1.35%** | 1.40% | -0.05pt | -0.15pt | Neutral |
| XLRE | **1.15%** | 1.76% | **-0.61pt** | -0.05pt | Neutralへ引下げ |

合計は100.00%、株式57.49%、IEF42.51%。片道売買回転率は約1.86%。XLVの+1.03ポイントは株式内の最大増額、XLREの-0.61ポイントは前回Overweight解消である。XLIは前回比では+0.09ポイントだが、これは株式内の相対順位変化による微調整であり、60/40基準比では-0.80ポイントのUnderweightを維持する。

### 段階執行

- **第1段階（8月31日、50%）:** IEFを41.77%→約42.14%。XLVを約+0.52ポイント増やし、XLRE・XLY・XLF・XLKの削減を半分実施する。主要統計がない月曜を、ポジション整理日に使う。
- **第2段階（9月1–2日、25%）:** ISM製造業・JOLTS後にIEFが92.09以上、5年/10年BEIが2.31%以下ならIEFを約42.32%へ。Broadcom後にXLKが193.09を上回るならXLKの残り削減を見送り、逆に185.37を割るなら削減を完成する。
- **第3段階（9月4日、25%）:** 雇用統計後にIEFが92/91.81を維持し、BEIが再上昇していなければ42.51%を完成する。IEFが91.81を終値で割る、または5年・10年BEIがともに2.35%以上なら増額を停止し、41.77–42.14%に留める。

## 各セクターとIEFの根拠

以下の「事実」は8月28日終値と8月30日JST取得のチェーンから計算した値、「見通し」はマクロ・企業イベントとの対応づけである。

### XLV — Health Care: Overweight 6.56%

- **オプション・価格事実:** Adjusted Score +0.311で11セクター首位。現値171.16はFlip 159.64、Call/Put Wall 170を上回り、Net GEXは+50.2百万。20日+5.30%、60日+16.51%、IVレンジ166.15–176.17。
- **マクロ:** 雇用減速や成長不安に対するディフェンシブ性があり、実質金利上昇の影響は公益・不動産より小さい。一方、強い雇用で金利がさらに上がる場合は高PERのバイオ・医療機器が圧迫される。
- **ボトムアップ:** 9月1日のMedtronicが医療機器需要、手術件数、価格転嫁の確認材料。170を支持線として維持できればOverweight、166.15割れでは増額を戻す。176.17近辺では追随買いを抑える。

### XLRE — Real Estate: Neutral 1.15%

- **オプション・価格事実:** Adjusted Score +0.258、現値44.48はFlip 43.14とPut Wall 43を上回る。Net GEXは+0.7百万、Call Wall 45、IVレンジ43.08–45.88。ただし20日-1.31%で、Hard RuleによりOverweightは禁止。
- **マクロ:** BEIは低下したが5年実質金利は+9bp、10年実質金利は+2bp。資金調達コストと資産還元利回りの観点から、現在はBEIより実質金利上昇が重い。
- **ボトムアップ:** Warsh議長も住宅をストレスのある分野として挙げた。45/45.88を終値で越え、実質金利が低下するまで前回Overweightを解消する。43.14割れは42台への下方加速リスク。

### XLB — Materials: Overweight 1.73%

- **オプション・価格事実:** Adjusted Score +0.224。現値53.18はFlip 49.16を上回り、Net GEX+44.2百万。Call Wall 55、Put Wall 48、IVレンジ50.69–55.67。20日+5.45%。
- **マクロ:** 9月1日のISM製造業・建設支出、2日の工場受注、3日の貿易収支が需要の連続確認になる。強い製造業は追い風だが、金利上昇・ドル高は商品価格を抑えやすい。
- **ボトムアップ:** ArganやToroなど設備・建設関連決算を受注環境の補助指標とする。前回Overweightが-0.47bpだったため配分は縮小し、55接近では利食いを優先する。

### XLE — Energy: Overweight 2.97%

- **オプション・価格事実:** Adjusted Score +0.207、Net GEX+54.9百万。現値62.68はFlip 60.85を上回り、Call Wall 65、Put Wall 60、IVレンジ60.19–65.17。20日+5.26%、60日+7.53%。
- **マクロ:** 先週の原油-4.27%は短期逆風だが、地政学的な供給リスクは残る。今週はISM・サービスPMI・雇用から需要側を確認する。強い統計でもドル高が進む場合は油価上昇が抑えられる点に注意する。
- **ボトムアップ:** 前回Overweightは-0.92bpと失敗したが、正Gammaと60日トレンドは維持。60.85/60を損切り・再評価帯、65を利食い帯とし、Overweight幅は小さく保つ。

### XLK — Information Technology: Neutral 18.90%

- **オプション・価格事実:** Adjusted Score -0.008でほぼ中立。現値185.69はFlip 185.37のわずか0.17%上、Net GEXは+1.9百万に縮小。Call Wall 200、Put Wall 175、IVレンジ178.29–193.09。20日+5.90%だが60日-5.26%。
- **マクロ:** NVIDIAの強い需要確認はAI設備投資を支える一方、Warsh議長のインフレ重視と実質金利上昇は長期duration株の評価を抑える。今週は雇用よりも9月2日のBroadcomがセクター固有の最大材料。
- **ボトムアップ:** 9月1日にDell・Palo Alto Networks、2日にBroadcom・HPE・Snowflakeなどが決算。Broadcomは9月2日引け後にQ3決算と見通しを公表予定で、AIネットワークとカスタムアクセラレータ需要が焦点。[Broadcom公式IR](https://investors.broadcom.com/news-releases/news-release-details/broadcom-inc-announce-third-quarter-fiscal-year-2026-financial) 185.37割れで178.29/175、193.09超で200を次の目安とする。

### XLF — Financials: Underweight 7.03%

- **オプション・価格事実:** Adjusted Score -0.113。現値58.10はFlip 58.06の直上、Put Wall 58、Call Wall 60、IVレンジ56.65–59.55。Net GEXは+4.1百万だが小さく、Put/Call OI比1.61。Vanna・Charmリスクがともに高い。
- **マクロ:** 5年金利上昇・10年金利横ばいによる曲線フラット化は、長短金利差より短期調達コストの上昇を意識させる。JOLTS・ADP・雇用統計が弱ければ信用コスト、強すぎれば追加利上げが問題となる。
- **ボトムアップ:** 先週金融は+1.05%で、Neutralの小幅アンダー配分は-0.32bp。今週は58/58.06を保てるかを優先し、59.55–60回復まではUnderweight。高Vanna/Charmのため統計直後の初動を追わない。

### XLU — Utilities: Neutral 1.35%

- **オプション・価格事実:** Adjusted Score -0.181、Net GEX-23.9百万。現値42.73はFlip 43.60を下回り、Call Wall 45、Put Wall 40、IVレンジ41.54–43.92。20日-3.65%、60日-1.62%。
- **マクロ:** 実質金利上昇は高配当・資本集約型資産に逆風。弱い雇用で金利が低下すれば反発余地はあるが、AI向け電力需要という中期材料より今週は金利が優先する。
- **ボトムアップ:** 負GammaのためOverweightしない。43.60/43.92回復でNeutral維持、41.54割れでは40方向の加速に備える。

### XLP — Consumer Staples: Underweight 2.83%

- **オプション・価格事実:** Adjusted Score -0.206、Net GEX-52.7百万。現値85.45はFlip 99.66を大きく下回り、Call Wall 86、Put Wall 78、IVレンジ82.86–88.04。Put/Call OI比3.71で、Charmリスクが高い。
- **マクロ:** 実質消費横ばいはディフェンシブ需要を支える一方、PCE前年比3.7%は原材料・物流・人件費の圧力が残ることを示す。弱い雇用は数量、強い雇用と金利上昇はバリュエーションにそれぞれ逆風となる。
- **ボトムアップ:** 9月3日のCampbell'sが価格、販売数量、販促費を確認する材料。86を明確に越えるまではUnderweight、82.86割れではPut Wall 78を意識する。

### XLY — Consumer Discretionary: Underweight 5.18%

- **オプション・価格事実:** Adjusted Score -0.247、Net GEX-53.1百万。現値117.21はFlip 140.65を大きく下回る。Call Wall 120、Put Wall 112.5、IVレンジ110.86–123.56、Put/Call OI比2.91。
- **マクロ:** 7月の名目所得は+0.4%、実質可処分所得は+0.4%だったが、実質PCEは横ばい。雇用統計と金利は住宅・自動車・耐久財に同時に効くため、今週最もマクロ感応度が高い。
- **ボトムアップ:** 9月2日のFive Below、3日のLululemon、4日のRHに加え、アパレル・小売決算が集中する。120/123.56を回復するまでUnderweight。110.86/112.5割れでは消費減速の織り込み加速に備える。

### XLI — Industrials: Underweight 4.60%

- **オプション・価格事実:** Adjusted Score -0.297、Net GEX-114.3百万で11セクター中最大の負Gamma。現値177.14はFlip 195.02とCall Wall 180を下回り、Put Wall 175、IVレンジ170.99–183.29。20日-1.50%、60日+2.03%。
- **マクロ:** ISM製造業、建設支出、工場受注、貿易収支が直接材料。Q2民間国内最終需要+4.2%と設備投資の強さは中期支援だが、実質金利上昇と短期の受注減速リスクが上値を抑える。
- **ボトムアップ:** 8月31日のSAIC、9月2日のArgan、3日のBrady・Toroを政府、電力設備、産業機器需要の確認材料とする。前回Underweightは+1.54bp。180/183.29を回復するまで維持する。

### XLC — Communication Services: Underweight 5.21%

- **オプション・価格事実:** Adjusted Score -0.318で最下位。Net GEX-36.1百万、現値112.99はFlip 121.37を下回る。Call Wall 115、Put Wall 104、IVレンジ106.64–119.34、Put/Call OI比5.88。
- **マクロ:** 大型プラットフォームはAI期待の恩恵を受ける一方、実質金利上昇で評価が圧迫され、雇用・消費鈍化は広告需要へ波及する。
- **ボトムアップ:** 先週の通信+1.46%に対しUnderweightは-1.31bpと最大の失敗。今回は追加削減を0.05ポイントに限定する。ただし負Gamma・高put需要は解消しておらず、115/119.34回復まではUnderweightを維持する。

### IEF — 7–10年米国国債: Overweight 42.51%

- **オプション・価格事実:** 現値92.85、Net GEX+236.1百万、Flip 91.81、Call Wall 94、Put Wall 92、IVレンジ92.09–93.61。オプションAdjusted Score+0.094。
- **BEI・金利事実:** 5年/10年BEIは2.30%/2.31%、加重5日変化-3.4bp。BEIオーバーレイ+0.082、合成スコア+0.091。ただし5年・10年実質金利は週間で上昇した。
- **見通し:** JOLTS・ADP・雇用統計が弱くBEI低下を伴えば上、強い雇用とWarsh路線の利上げ織り込みなら下。92.09以上を通常増額帯、92/91.81を停止帯、93.61–94を利食い・再評価帯とする。

## 日別イベントとポジション対応

来週は労働市場が中心で、9月1日のISM・JOLTS、2日のADP・Broadcom、4日の雇用統計が主な変曲点である。[Kiplinger経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar) / [Kiplinger決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)

| 日付 | 主なイベント（米東部時間） | 主なETF | ポジションへの読み替え |
|---|---|---|---|
| 8/31 月 | 主要経済指標なし、SAIC決算 | XLI, IEF | 低流動性の月末。第1段階だけ実施し、XLI 175–180を確認 |
| 9/1 火 | 9:45製造業PMI、10:00 ISM製造業・JOLTS・建設支出、Medtronic朝、Dell・Palo Alto等引け後 | XLI, XLB, XLRE, XLV, XLK, IEF | 強い製造業はXLI/XLB、弱いJOLTSはIEF/XLV。ただし金利とBEIを併読 |
| 9/2 水 | 8:15 ADP、10:00工場受注、14:00 Beige Book、Broadcom・HPE・Snowflake・Five Below等引け後 | XLK, XLI, XLY, XLF, IEF | BroadcomがXLK、ADP/Beige Bookが金利を動かす。第2段階の条件確認 |
| 9/3 木 | 8:30失業保険・Waller理事講演・貿易収支、9:45サービスPMI、10:00 ISMサービス、Campbell・Toro朝、Lululemon等引け後 | IEF, XLF, XLY, XLP, XLI, XLC | サービス雇用・価格指数を重視。弱い需要でも価格が高ければIEF買いを急がない |
| 9/4 金 | 8:30 8月雇用統計、RH朝 | 全資産、特にIEF/XLRE/XLU/XLF/XLY | 今週最大。雇用・賃金・失業率とBEI/実質金利の組み合わせで最終25%を判断 |

BLSは8月雇用統計を9月4日8:30 ETに公表予定で、JOLTSは9月1日10:00 ETである。[BLS 2026年9月公表予定](https://www.bls.gov/schedule/2026/09_sched_list.htm) BEAは9月3日8:30 ETに7月貿易収支を公表予定。[BEA公表予定](https://www.bea.gov/news/schedule/full)

## Vanna / Charmとガンマ運営

- **負Gamma:** XLU、XLP、XLY、XLI、XLC。材料に対する値動きが増幅しやすく、XLI・XLC・XLYはUnderweightを維持する。
- **Flip近傍:** XLKはFlipの0.17%上、XLFは0.07%上。Broadcom・雇用統計で正負Gammaレジームが変わりやすい。
- **高Vanna/Charm:** IEFはVanna 78.2%・Charm 92.5%。株式ではXLFが両方、XLPとXLEがCharm高リスク。イベント初動ではなく終値確認を優先する。
- **Wall運営:** IEF 92–94、XLK 175–200、XLF 58–60、XLI 175–180、XLE 60–65が主要レンジ。Wall到達時は新規追随より利食い・縮小を優先する。

## シナリオ

### 中立シナリオ — 提案配分を段階的に完成

ISM・JOLTSは減速も急失速ではなく、雇用者数は小幅プラス、失業率は安定。BEIは2.28–2.33%、IEFは92.09–93.61、XLKは178.29–193.09で推移する。株式57.49% / IEF42.51%を完成し、XLV・XLB・XLEのOverweightを維持する。

### 株式強気シナリオ — IEF増額を半分戻す

ISMと雇用が底堅く、賃金加速は限定的、BroadcomがAI需要を上方修正する。XLKが193.09、XLIが183.29、XLCが119.34を終値で上抜くなら、株式を58.5–60%、IEFを40–41.5%へ戻す。XLK・XLI・XLCの減額から順に解消する。

### 成長減速・金利低下シナリオ — 防御を強める

JOLTS・ADP・雇用統計が弱く、賃金・サービス価格も鈍化、BEIが2.28%を割る。IEFが93.61を越え、株式ではXLY 110.86、XLI 170.99、XLC 106.64を割る場合は、株式55–57%、IEF43–45%へ防御を強める。

### インフレ・金利上昇型弱気シナリオ — IEFを機械的に増やさない

ISM価格・賃金が強く、BEIが2.35%以上、IEFが92を割って91.81下へ入る。XLKも185.37を割る場合、株式と中期債が同時に下落しうる。この場合はIEFを41.77–42.14%で止め、現金またはより短いdurationを別枠で検討する。

## 監視水準一覧

| ETF | 配分 | Adjusted Score | Spot | Flip | Call Wall | Put Wall | 7日1σレンジ | Gamma / 判断 |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| XLV | 6.56% | +0.311 | 171.16 | 159.64 | 170 | 170 | 166.15–176.17 | 正 / OW |
| XLRE | 1.15% | +0.258 | 44.48 | 43.14 | 45 | 43 | 43.08–45.88 | 正 / Neutral |
| XLB | 1.73% | +0.224 | 53.18 | 49.16 | 55 | 48 | 50.69–55.67 | 正 / OW |
| XLE | 2.97% | +0.207 | 62.68 | 60.85 | 65 | 60 | 60.19–65.17 | 正 / OW |
| IEF | 42.51% | +0.091 | 92.85 | 91.81 | 94 | 92 | 92.09–93.61 | 正 / OW（BEI調整後） |
| XLK | 18.90% | -0.008 | 185.69 | 185.37 | 200 | 175 | 178.29–193.09 | 正・Flip近傍 / Neutral |
| XLF | 7.03% | -0.113 | 58.10 | 58.06 | 60 | 58 | 56.65–59.55 | 正・Flip近傍 / UW |
| XLU | 1.35% | -0.181 | 42.73 | 43.60 | 45 | 40 | 41.54–43.92 | 負 / Neutral |
| XLP | 2.83% | -0.206 | 85.45 | 99.66 | 86 | 78 | 82.86–88.04 | 負 / UW |
| XLY | 5.18% | -0.247 | 117.21 | 140.65 | 120 | 112.5 | 110.86–123.56 | 負 / UW |
| XLI | 4.60% | -0.297 | 177.14 | 195.02 | 180 | 175 | 170.99–183.29 | 負 / UW |
| XLC | 5.21% | -0.318 | 112.99 | 121.37 | 115 | 104 | 106.64–119.34 | 負 / UW |

## データと外部参照

- モデル配分: `outputs/tables/consistent_12asset_allocation.csv`
- 最新保有週検証: `outputs/tables/latest_holding_week_attribution.csv`
- オプション指標: `outputs/tables/consistent_option_metrics.csv`
- IEFダッシュボード表: `outputs/tables/ief_dashboard.csv`
- BEI履歴・オーバーレイ: `outputs/tables/breakeven_inflation.csv`, `outputs/tables/bei_overlay.csv`
- 8月28日価格補完監査表: `outputs/tables/price_fallback.csv`
- HTMLダッシュボード: `outputs/dashboard/sector_gamma_dashboard.html`
- 実行済みNotebook: `outputs/executed/main_20260830_executed.ipynb`
- [LPL: 8月28日までの週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-august-28-2026.html)
- [AP: 8月28日の指数と週間実績](https://apnews.com/article/wall-street-stocks-dow-nasdaq-3f3477bcea915ac53ec2ae905ae57919)
- [Federal Reserve: Warsh議長Jackson Hole講演](https://www.federalreserve.gov/newsevents/speech/warsh20260828a.htm)
- [BEA: 7月Personal Income and Outlays](https://www.bea.gov/news/2026/personal-income-and-outlays-july-2026)
- [BEA: Q2 GDP第2次推計](https://www.bea.gov/news/2026/gdp-second-estimate-and-corporate-profits-2nd-quarter-2026)
- [NVIDIA公式決算](https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-Second-Quarter-Fiscal-2027/default.aspx)
- [Broadcom公式決算予定](https://investors.broadcom.com/news-releases/news-release-details/broadcom-inc-announce-third-quarter-fiscal-year-2026-financial)
- [FRED: 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- [米財務省: 名目イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve) / [実質イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_real_yield_curve)
- [Kiplinger: 8月31日–9月4日の経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)
- [Kiplinger: 8月31日–9月4日の決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)
- [BLS: 2026年9月公表予定](https://www.bls.gov/schedule/2026/09_sched_list.htm)

## モデル検証メモ

- Notebookは非表示状態に依存せず上から完走し、オプションチェーンは11セクターETF、SPY、IEFの13銘柄すべて取得した。
- 8月28日価格フォールバック、既存検証、BEI検証を含む **209/209項目がPASS**。有限なGreeks、配分合計100%、株式内Active合計0、BEIスコア恒等式、全Plotly図、parquet・CSV・HTML保存を確認した。
- 前週検証は12資産、期間8月21日→28日。`戦術収益率 - 基準収益率 = 超過収益率` を確認した。
- 価格補完は13銘柄、同一の8月28日、有限終値、監査用CSV/parquet保存を検証した。補完後のspotをオプションGamma/GEX計算へ同期した。
