# Sector Gamma 週次見通し・リバランス案 — 2026年8月23日

**データ基準:** 2026年8月21日米国引け / 2026年8月23日JST更新  
**振り返り期間:** 2026年8月14日引け → 8月21日引け  
**見通し期間:** 2026年8月24日 → 8月28日  
**対象:** S&P 500 11セクターETF + IEF（米国7–10年国債）

> 本資料は研究・モデル運用のためのもので、個別の投資助言ではない。GEXは公開オプションチェーンからcallを正、putを負として計算した需給プロキシであり、実際のディーラーポジションを直接観測したものではない。外部記事の市場実績はクロスチェック、配分損益は配当調整済みETF終値によるモデル計算である。

## 結論

今回の提案は、**株式を60.00%から58.23%へ1.77ポイント減らし、IEFを40.00%から41.77%へ増やす**。株式内では **XLB・XLRE・XLEをOverweight、XLY・XLC・XLIをUnderweight** とし、XLV・XLK・XLF・XLU・XLPはNeutralとする。前回OverweightだったXLFはNeutralへ戻す。

判断の中心は三つある。

1. **先週は成長株と金利感応株が同時に弱かった。** S&P 500は週間-1.44%、Nasdaqは-2.17%。セクターではヘルスケア+4.32%、エネルギー+2.58%、素材+2.28%に対し、情報技術-3.35%、資本財-3.31%、公益-3.04%だった。[LPLの週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-august-21-2026.html)
2. **オプション需給の弱さが広い。** XLF、XLU、XLP、XLY、XLC、XLIが負Gammaで、XLKも現値183.31がGamma Flip 182.61のすぐ上にある。株式合成スコアは-0.1890、IEFのオプションAdjusted Scoreは+0.1357となった。
3. **BEI上昇を考慮すると、IEFの増額幅は縮小すべきである。** 5年・10年BEIはいずれも2.34%、加重BEIは5営業日で+8.2bp、20営業日で+8.8bp。BEIオーバーレイは-0.4218、オプション75%・BEI25%のIEF金利調整後スコアは-0.0037、株式との相対スコアは-0.1853となった。IEFの方向は増額のままだが、42.86%ではなく41.77%に抑える。

## BEIを含む金利見通し

### 確認された事実

- 8月21日の5年BEIと10年BEIはともに2.34%。8月14日から5年BEIは2.24%→2.34%（+10bp）、10年BEIは2.27%→2.34%（+7bp）へ上昇した。[FRED 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [FRED 10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- 同期間に5年名目金利は4.36%→4.43%と+7bp、5年実質金利は2.12%→2.09%と-3bp。10年名目金利は4.68%→4.74%と+6bp、10年実質金利は2.41%→2.40%と-1bpだった。[米財務省・名目イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve) / [米財務省・実質イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_real_yield_curve)
- したがって、先週の5–10年名目金利上昇は実質成長期待の上昇よりも、主としてインフレ補償の上昇で説明できる。丸め誤差を除けば `名目金利 ≒ 実質金利 + BEI` である。

### モデル推論

- BEIは市場参加者の平均的なインフレ補償を示すが、純粋なインフレ予想ではなくインフレ・リスクプレミアムやTIPSの流動性プレミアムも含むため、オプションスコアを置き換えず25%の補正に限定する。
- IEFのオプション需給は、正Gamma、Flip上、Put Wall 92上で+0.1357とプラス。一方、上昇中のBEIは名目債価格に逆風で、BEIオーバーレイは-0.4218となる。
- IEF最終スコアは、オプション75%とBEI25%を合成して **-0.0037**。BEIを加える前の強気判断はほぼ中立まで低下する。
- それでも株式合成スコア-0.1890よりIEFが相対的に良いため、IEFは40%を下回らせず41.77%へ増やす。ただし、これは強いduration買いではなく株式リスクの部分ヘッジである。
- 8月26日のPCE後にBEIが低下すればIEF増額を完成できる。BEIがさらに上昇し、IEFがFlip 91.77を割る場合は40–40.89%に留める。

## 先週の振り返り

### 市場で確認された事実

- 週間ではS&P 500が-1.4%、Dowが-0.8%、Nasdaqが-2.1%、Russell 2000が-1.6%。金曜はS&P 500が+0.4%、Dowが+1.0%と反発したが、週全体の下落を埋めなかった。[APの週間指数集計](https://apnews.com/article/wall-street-stocks-dow-nasdaq-09c079b43680c3e4564346892b5dc824)
- 長期金利上昇、財政・国債供給への懸念、AI関連の社債発行、原油上昇が重なり、グロース株と金利感応株が圧迫された。週半ばには米財務省の買い戻し策で30年金利が5.28%から5.18%へ低下する場面もあった。[APの債券・小売市場報道](https://apnews.com/article/9e355be634e4a21059fc1d1f20a1239e)
- 7月FOMC議事要旨では、多くの参加者が年後半のインフレ鈍化を見込む一方、鈍化しなければ引き締めが必要となる可能性を指摘し、複数の参加者は25bp利上げを支持していた。[Federal Reserve議事要旨](https://www.federalreserve.gov/monetarypolicy/fomcminutes20260729.htm)
- Walmartの米既存店売上高は+2.6%と6年ぶりの低い伸びで、株価は8%下落した。低所得層の圧力と慎重な見通しは、消費関連へのボトムアップな警戒材料である。[APのWalmart決算報道](https://apnews.com/article/955945e03ffcc111389d62fa3103a051)
- 原油は週間+5.62%、金+5.56%、銀+7.49%。エネルギー・素材の相対優位と、インフレ・地政学ヘッジ需要が同時に確認された。[LPLの週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-august-21-2026.html)

### 前回配分の実績 — 8月17日スナップショット

8月17日に公表した配分を、直前金曜8月14日終値から8月21日終値まで継続保有したものとして評価した。

| 指標 | 収益率 |
|---|---:|
| 60/40基準配分 | -0.876% |
| 前回戦術配分 | -0.816% |
| 超過収益 | **+5.98bp** |

相場下落を回避できたわけではないが、戦術配分は基準配分の損失を約6bp緩和した。

| ETF | 前回判断 | ETF騰落率 | Active寄与 | 評価 |
|---|---|---:|---:|---|
| XLI | Underweight | -3.36% | **+2.66bp** | 負Gammaと景気敏感株の減額が奏功 |
| XLE | Overweight | +2.79% | **+2.57bp** | 油価上昇と正Gammaを捉えた |
| XLC | Underweight | -1.37% | **+1.14bp** | 高put需要・負Gammaへの警戒が奏功 |
| XLB | Overweight | +1.90% | **+0.75bp** | 素材・貴金属高と整合 |
| XLY | Underweight | -0.15% | +0.09bp | 消費警戒の小幅減額がプラス |
| XLP | Underweight | -0.12% | +0.02bp | 小幅プラス |
| XLF | Overweight | -1.17% | **-1.26bp** | 金利上昇を追い風とみた判断が、負Gamma化と株式全体のリスクオフに負けた |

XLKはNeutralだったためActive寄与はゼロだが、ETF自体は-3.53%。前回の「190割れではFlip方向への不安定化」という警戒どおり、190.01から183.31へ下落し、今回のFlip 182.61に接近した。XLVは+4.33%と強かったがNeutralのためActive寄与はゼロだった。

## 今週のリバランス案

### 売買一覧

| ETF | 新配分 | 前回配分 | 売買 | 60/40基準比 | モデル判断 |
|---|---:|---:|---:|---:|---|
| IEF | **41.77%** | 40.00% | **+1.77pt** | +1.77pt | Overweight |
| XLK | **19.10%** | 19.72% | **-0.62pt** | -0.62pt | Neutral |
| XLF | **7.26%** | 8.63% | **-1.37pt** | -0.29pt | Neutralへ引下げ |
| XLV | **5.53%** | 5.69% | -0.17pt | -0.17pt | Neutral |
| XLY | **5.49%** | 5.38% | +0.11pt | -0.45pt | Underweight |
| XLC | **5.26%** | 5.34% | -0.08pt | -0.92pt | Underweight |
| XLI | **4.50%** | 4.60% | -0.10pt | -0.89pt | Underweight |
| XLE | **3.01%** | 3.32% | -0.31pt | +0.61pt | Overweight |
| XLP | **2.97%** | 2.97% | -0.00pt | -0.21pt | Neutral |
| XLB | **1.96%** | 1.65% | +0.31pt | +0.70pt | Overweight |
| XLRE | **1.76%** | 1.20% | **+0.56pt** | +0.56pt | Overweight |
| XLU | **1.40%** | 1.50% | -0.10pt | -0.10pt | Neutral |

配分合計は100.00%、株式58.23%、IEF41.77%。片道売買回転率は約2.75%である。XLEの最終配分が前回より減るのは判断悪化ではなく、**株式バケット全体を1.77ポイント削るため**であり、株式内では引き続きOverweightである。同様にXLV・XLP・XLUの基準比減額はバケット縮小の影響で、株式内判断はNeutralである。

### 段階執行案

- **第1段階（8月24日、目標の50%）:** IEFを40.00%から約40.89%へ増額。資金は主にXLFとXLKの削減で捻出し、XLB・XLREの増額も半分実施する。
- **第2段階（8月26日、PCE・GDP・NVIDIA確認後、25%）:** IEFが92.02以上、Flip 91.77を維持し、5年・10年BEIが2.34%以下なら約41.33%へ。XLKが182.61を割る場合は削減を優先し、NVIDIA後に191.43を超える場合はXLKの残りの削減を見送る。
- **第3段階（8月28日、Jackson Hole講演後、25%）:** IEFがFlip上を維持し、BEIが再上昇していなければ41.77%を完成。IEFが91.77を終値で割る、または5年・10年BEIがともに2.40%を超える場合は増額を停止し、40.00–40.89%に留める。

これは「債券価格が必ず上がる」という予測ではなく、**株式の負Gamma breadthに対するリスク量調整**である。IEF自体も移動平均線下であるため、価格条件を満たさない増額は行わない。

## 各セクターとIEFの根拠

以下の「事実」は8月21日終値と8月23日JSTに取得したオプションチェーンから計算した値、「推論」はマクロ・企業イベントとの対応づけである。

### XLB — Materials: Overweight 1.96%

- **オプション・価格事実:** Adjusted Score +0.395で12資産中首位。現値53.54はFlip 47.09を上回り、Net GEXは+47.5百万。Call Wall 55、Put Wall 50、IVレンジ50.91–56.17。
- **マクロ:** 原油・金属上昇、GDP・耐久財・住宅販売の上振れに強い。一方、PCE上振れによる金利上昇や製造業の失速は逆風。
- **ボトムアップ:** 水曜のDonaldson、Dycom、Synopsysなどから設備・建設需要を読み替える。55に近づくほど追随買いを抑える。

### XLV — Health Care: Neutral 5.53%

- **オプション・価格事実:** Adjusted Score +0.383、正Gamma、20日+7.41%。現値174.62はCall Wall 175の直下、Flip 153.08、IVレンジ168.36–180.88。Call Wall近傍でOverweightは禁止。
- **マクロ:** 景気・消費不安時のディフェンシブ性が支援するが、PCE上振れと長期金利上昇はバリュエーションの逆風。
- **ボトムアップ:** 水曜Agilentが計測・ライフサイエンス需要の確認材料。175を終値で越えるまでは、先週+4.33%を追わずNeutralとする。

### XLRE — Real Estate: Overweight 1.76%

- **オプション・価格事実:** Adjusted Score +0.221、正Gamma。現値45.08はFlip 42.66を上回るが、Call/Put Wall 45近傍。IVレンジ42.61–47.55。
- **マクロ:** 8月25日の新築住宅販売と26日のPCE・GDPを受けた長期金利が主因。金利低下型なら相対優位、PCE上振れなら即座に逆風となる。
- **ボトムアップ:** 住宅需要と資金調達コストの綱引き。45近傍のピン留めを想定し、小幅Overweightに限定する。

### XLE — Energy: Overweight 3.01%

- **オプション・価格事実:** Adjusted Score +0.153、正Gamma、20日+6.74%。現値63.64はFlip 60.46を上回る。Call Wall 65、Put Wall 55、IVレンジ60.24–67.04。
- **マクロ:** 先週の原油+5.62%と中東供給リスクが売上単価を支える。一方、PCE上振れを通じた需要懸念や外交進展による油価反落が下方リスク。
- **ボトムアップ:** 木曜MarvellなどAI決算による電力需要の中期連想はあるが、短期は原油と精製マージンが優先。65超を追わず、60.46–63台の押し目で維持する。

### XLK — Information Technology: Neutral 19.10%

- **オプション・価格事実:** Adjusted Score -0.060。Net GEXは辛うじて正だが、現値183.31はFlip 182.61の0.4%上、Put Wall 180の1.8%上。Call Wall 200、IVレンジ175.19–191.43。
- **マクロ:** PCE・金利とAI投資期待の二重感応。インフレ上振れは長期duration株に逆風、金利低下と強い設備投資は追い風。
- **ボトムアップ:** 水曜引け後のNVIDIAが週最大の個別イベント。NVIDIAは8月26日14時PTに決算会見を予定している。[NVIDIA公式IR](https://nvidianews.nvidia.com/news/nvidia-sets-conference-call-for-second-quarter-financial-results-6927195) 182.61/180割れは175.19方向の加速、191.43超は削減見送りの条件とする。

### XLF — Financials: Neutral 7.26%

- **オプション・価格事実:** Adjusted Score -0.076。Net GEXは-5.7百万、現値57.48はFlip 57.57をわずかに下回る。Call Wall 55、Put Wall 56、IVレンジ55.98–58.98。Vanna・Charm集中が高い。
- **マクロ:** 長期金利上昇は利ざやを支えうるが、財政懸念による無秩序な金利上昇、景気減速、信用コスト上昇は銀行・消費者金融に逆風。
- **ボトムアップ:** Walmartの低所得層への警戒、今週のDollar General・Dollar Tree・Affirmは信用と消費の質を測る材料。前回Overweightの失敗を受け、Flip回復まではNeutralへ戻す。

### XLU — Utilities: Neutral 1.40%

- **オプション・価格事実:** Adjusted Score -0.135、20日-7.60%。Net GEXは-16.3百万、現値42.77はFlip 43.53を下回る。Call Wall 45、Put Wall 40、IVレンジ41.37–44.17。
- **マクロ:** 金利低下は高配当・資本集約型資産に追い風だが、先週は長期金利上昇でセクターが-3.04%。油価・PCE上振れも逆風。
- **ボトムアップ:** AI向け電力需要は中期支援材料だが、今週は金利と資金調達コストが優先。43.53回復までは増額しない。

### XLP — Consumer Staples: Neutral 2.97%

- **オプション・価格事実:** Adjusted Score -0.136、Net GEXは-47.3百万。現値85.99はFlip 98.52を大きく下回り、Call Wall 86直下。Put Wall 78、IVレンジ83.39–88.59、Put/Call OI比3.86、Charm集中が高い。
- **マクロ:** ディフェンシブ需要は下支えだが、油価・輸送費・食品価格と弱い低所得消費の両方がマージンを圧迫する。
- **ボトムアップ:** 木曜のDollar General、Dollar Tree、Hormelが価格投資、客数、在庫の確認材料。負GammaのためOverweightにせずNeutral。

### XLY — Consumer Discretionary: Underweight 5.49%

- **オプション・価格事実:** Adjusted Score -0.160、Net GEXは-56.5百万。現値118.02はFlip 141.62を大きく下回る。Call Wall 120、Put Wall 110、IVレンジ112.33–123.71、Put/Call OI比2.93。
- **マクロ:** 消費者信頼感、新築住宅販売、PCE、金利に最も複合的に反応する。低所得消費の弱さと住宅関連支出の鈍化がリスク。
- **ボトムアップ:** 月曜PDD、火曜Dick's、木曜Best Buy・Burlington・Gap・Ultaが連続する。120を回復し123.71を越えるまでUnderweightを維持する。

### XLC — Communication Services: Underweight 5.26%

- **オプション・価格事実:** Adjusted Score -0.376。Net GEXは-49.8百万、現値111.40はFlip 123.15を下回る。Call Wall 115、Put Wall 104、IVレンジ103.20–119.60、Put/Call OI比6.12。
- **マクロ:** 金利上昇は大型成長株の評価を圧迫し、消費鈍化は広告・娯楽需要に波及する。
- **ボトムアップ:** 火曜引け後のZoomが企業IT需要の確認材料。大型プラットフォームの決算集中週ではないため、115/119.60回復まではオプション需給を優先する。

### XLI — Industrials: Underweight 4.50%

- **オプション・価格事実:** Adjusted Score -0.389で12資産中最低。Net GEXは-87.9百万、現値180.25はFlip 196.91を下回る。Call Wall 195、Put Wall 175、IVレンジ173.12–187.38。
- **マクロ:** 8月26日の耐久財・GDP、27日の在庫・貿易、28日のChicago PMIに直接反応する。強い統計でも金利上昇を伴えば上値が抑えられる。
- **ボトムアップ:** 火曜HEICO、水曜Donaldson・Dycom、木曜Autodeskなどから航空・設備・建設需要を確認。187.38を回復するまではUnderweight。

### IEF — 7–10年米国国債: Overweight 41.77%

- **オプション・価格事実:** オプションAdjusted Score +0.136。現値92.82はFlip 91.77とPut Wall 92を上回り、Net GEXは+117.6百万。Call Wall 94、IVレンジ92.02–93.62。ただし20日線92.999、50日線93.304より下で、Vanna集中74.4%、Charm集中89.8%。
- **BEI・金利事実:** 5年/10年BEIは2.34%/2.34%、加重5日変化+8.2bp、20日変化+8.8bp。BEIオーバーレイ-0.422を25%組み入れた金利調整後スコアは-0.004。
- **マクロ:** 水曜のPCE・GDP、木曜の失業保険、金曜のMichigan期待インフレとJackson Hole講演が方向を決める。PCE鈍化とBEI低下なら上、PCE上振れ・BEI上昇・タカ派講演なら下。
- **運用判断:** 株式対IEF相対スコア-0.1853に従い小幅増額。ただし92.02以上を通常執行帯、91.77割れを増額停止、93.62超を上昇確認、94を利食い・再評価水準とする。

## 日別イベントとポジション対応

来週は8月26日にPCE・GDPとNVIDIAが重なるため、水曜が最大の変曲点となる。[Kiplinger経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar) / [Kiplinger決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)

| 日付 | 主なイベント（米東部時間） | 主なETF | ポジションへの読み替え |
|---|---|---|---|
| 8/24 月 | 主要経済指標なし、PDD決算 | XLY, XLC | 中国・裁量消費の初期チェック。XLY 120回復の有無を確認 |
| 8/25 火 | 9:00 Case-Shiller、10:00新築住宅販売・消費者信頼感・Richmond Fed、DKS朝、HEICO・Intuit・Zoom引け後 | XLRE, XLY, XLB, XLI, XLC, XLK, IEF | 住宅・信頼感が弱ければIEF/XLRE、強ければXLY/XLB。ただし金利反応を併読 |
| 8/26 水 | 8:30 PCE・コアPCE、耐久財、Q2 GDP改定値・企業利益、NVIDIA・Agilent・CrowdStrike・HP・Salesforce・Synopsys等 | IEF, XLK, XLI, XLB, XLV, XLC | 今週最大。PCEと金利がIEF、NVIDIAがXLKを動かす。両方確認後に第2段階 |
| 8/27 木 | 8:30失業保険・貿易収支・卸売/小売在庫、11:00 Kansas City Fed、Best Buy・Burlington・Dollar General/Tree・Hormel、Marvell・Affirm・Gap・Ulta等 | XLY, XLP, XLF, XLI, XLK, IEF | 消費の裾野、在庫、信用、半導体を横断確認。弱い消費はIEF支援でも株式には逆風 |
| 8/28 金 | 9:45 Chicago PMI、10:00 Michigan最終、Jackson HoleでFed Chair Kevin Warsh講演 | 全資産、特にIEF/XLRE/XLU/XLK | 期待インフレと政策反応を確認し最終25%を判断 |

米商務省BEAは8月26日8:30にQ2 GDP第2次推計、企業利益、および7月Personal Income and Outlaysを公表予定。Q2 GDPの速報値は年率+1.5%だった。[BEA公表予定](https://www.bea.gov/news/schedule/full) / [Q2 GDP速報](https://www.bea.gov/news/2026/gdp-advance-estimate-2nd-quarter-2026) 住宅販売は25日、耐久財は26日、在庫・貿易の先行指標は27日に予定される。[米国Census公表予定](https://www.census.gov/economic-indicators/calendar-listview.html) Jackson Hole Symposiumは8月27–29日、テーマは「Financial Innovation: Implications for Payments and Policy」である。[Kansas City Fed公式](https://www.kansascityfed.org/research/jackson-hole-economic-symposium/)

## Vanna / Charmとガンマ運営

- **負Gamma:** XLF、XLU、XLP、XLY、XLC、XLI。材料に対する値動きが増幅しやすい。特にXLI、XLY、XLCのUnderweightを維持し、XLFは前回のOverweightを解消する。
- **Flip近傍:** XLKはFlipの0.4%上、XLFは0.2%下、XLUは1.8%下。水曜前後にレジームが変わりやすい。
- **高Vanna/Charm:** IEFはVanna 74.4%、Charm 89.8%、XLFもVanna 27.6%、Charm 36.0%と高い。IV低下だけで現物ヘッジ方向が変わりうるため、イベント初動を追わず終値確認を優先する。
- **Wall運営:** IEF 92–94、XLK 180–200、XLE 55–65、XLRE 45が短期の主要レンジ。Wall到達時は新規追随より、既存ポジションの縮小・利食いを優先する。

## シナリオ

### 中立シナリオ — 提案配分を完成

PCEは概ね予想範囲、GDP改定も小幅、NVIDIAはAI投資トレンドを維持するが上振れ加速は限定的。BEIは2.30–2.40%内、IEFは92.02–93.62、XLKは180–191.43で推移する。株式58.23 / IEF41.77を段階的に完成し、XLB・XLRE・XLEのOverweightを維持する。

### 強気シナリオ — 株式削減を半分に留める

PCE鈍化、BEI低下、GDP・耐久財は底堅く、NVIDIAが強い見通しを示す。XLKが191.43、XLIが187.38、XLCが119.60を終値で上抜くなら、株式を59–60%に戻し、XLK・XLI・XLCの減額を半分解消する。IEFが93.62を超えても株式が同時上昇する「金利低下型リスクオン」なら、IEF増額を40.89–41.33%で止める。

### 弱気シナリオ — 防御を強める

PCE上振れ、BEI上昇、GDP下方改定、NVIDIA失望、Warsh議長がタカ派となる組み合わせ。XLKが180、XLIが175、XLCが104を割る場合は株式を55–57%へ抑える。ただしIEFも91.77を割る「インフレ・金利上昇型リスクオフ」ではIEFを機械的に増やさず40–40.89%に留め、現金・より短いdurationを別途検討する。

## 監視水準一覧

| ETF | 配分 | Adjusted Score | Spot | Flip | Call Wall | Put Wall | 7日1σレンジ | Gamma / 判断 |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| XLB | 1.96% | +0.395 | 53.54 | 47.09 | 55 | 50 | 50.91–56.17 | 正 / OW |
| XLV | 5.53% | +0.383 | 174.62 | 153.08 | 175 | 160 | 168.36–180.88 | 正 / Neutral |
| XLRE | 1.76% | +0.221 | 45.08 | 42.66 | 45 | 45 | 42.61–47.55 | 正 / OW |
| XLE | 3.01% | +0.153 | 63.64 | 60.46 | 65 | 55 | 60.24–67.04 | 正 / OW |
| IEF | 41.77% | -0.004 | 92.82 | 91.77 | 94 | 92 | 92.02–93.62 | 正 / OW（BEI調整後） |
| XLK | 19.10% | -0.060 | 183.31 | 182.61 | 200 | 180 | 175.19–191.43 | 正・Flip近傍 / Neutral |
| XLF | 7.26% | -0.076 | 57.48 | 57.57 | 55 | 56 | 55.98–58.98 | 負・Flip近傍 / Neutral |
| XLU | 1.40% | -0.135 | 42.77 | 43.53 | 45 | 40 | 41.37–44.17 | 負 / Neutral |
| XLP | 2.97% | -0.136 | 85.99 | 98.52 | 86 | 78 | 83.39–88.59 | 負 / Neutral |
| XLY | 5.49% | -0.160 | 118.02 | 141.62 | 120 | 110 | 112.33–123.71 | 負 / UW |
| XLC | 5.26% | -0.376 | 111.40 | 123.15 | 115 | 104 | 103.20–119.60 | 負 / UW |
| XLI | 4.50% | -0.389 | 180.25 | 196.91 | 195 | 175 | 173.12–187.38 | 負 / UW |

## データと外部参照

- モデル配分: `outputs/tables/consistent_12asset_allocation.csv`
- 最新保有週検証: `outputs/tables/latest_holding_week_attribution.csv`
- オプション指標: `outputs/tables/consistent_option_metrics.csv`
- IEFダッシュボード表: `outputs/tables/ief_dashboard.csv`
- BEI履歴: `outputs/tables/breakeven_inflation.csv`
- BEIオーバーレイ: `outputs/tables/bei_overlay.csv`
- HTMLダッシュボード: `outputs/dashboard/sector_gamma_dashboard.html`
- 実行済みNotebook: `outputs/executed/main_20260823_bei_executed.ipynb`
- [LPL: 8月21日までの週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-august-21-2026.html)
- [AP: 8月21日までの週間指数](https://apnews.com/article/wall-street-stocks-dow-nasdaq-09c079b43680c3e4564346892b5dc824)
- [Federal Reserve: 2026年7月FOMC議事要旨](https://www.federalreserve.gov/monetarypolicy/fomcminutes20260729.htm)
- [FRED: 5年BEI](https://fred.stlouisfed.org/series/T5YIE)
- [FRED: 10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- [米財務省: 名目イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- [米財務省: 実質イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_real_yield_curve)
- [Kiplinger: 8月24–28日の経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)
- [Kiplinger: 8月24–28日の決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)
- [BEA公表予定](https://www.bea.gov/news/schedule/full)
- [Census公表予定](https://www.census.gov/economic-indicators/calendar-listview.html)
- [Kansas City Fed: Jackson Hole Symposium](https://www.kansascityfed.org/research/jackson-hole-economic-symposium/)

## モデル検証メモ

- Notebookは非表示状態に依存せず上から完走し、オプションチェーンは11セクターETF、SPY、IEFの13銘柄すべて取得した。
- 既存検証とBEI検証を含む **203/203項目がPASS**。有限なGreeks、配分合計100%、株式内Active合計0、BEIスコア恒等式、保存CSV・parquet・HTMLを確認した。
- 前週検証は12資産、期間8月14日→21日。`戦術収益率 - 基準収益率 = 超過収益率` を確認した。
- 今回、保有週の配分スナップショット選択を「週初の月曜日までに利用可能な最新値」とする回帰検証を追加し、8月17日配分を正しく8月14日→21日の損益へ対応づけた。
