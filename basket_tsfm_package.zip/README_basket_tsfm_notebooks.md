# Basket TSFM Notebooks

## 目的

この一式は、個別銘柄mimicking portfolioを直接売買するのではなく、テーマバスケット構成行列 `A_t` を使って、純化テーマ因子または統合因子をテーマバスケット係数 `c_t` で複製し、その複製可能リターンに time-series factor momentum を適用する実装です。

売買単位はテーマバスケットです。ルックスルー個別銘柄ウェイト `A_t c_t` は、Barra中立性、純化テーマエクスポージャー、集中度、リスクを診断するためだけに使います。

## ノートブック

| ファイル | 内容 |
|---|---|
| `00_basket_purified_theme_replication_diagnostics.ipynb` | 純化テーマ因子をテーマバスケット係数で複製するための診断用ノートブック。 |
| `01_binary_basket_purified_theme_tsfm_12m.ipynb` | テーマバスケットで複製した純化テーマ因子に対する12カ月Binary TSFM。 |
| `02_vol_scaled_basket_purified_theme_tsfm_12m.ipynb` | テーマバスケットで複製した純化テーマ因子に対するvol-scaled TSFM。 |
| `03_binary_basket_replicated_combined_factor_tsfm_12m.ipynb` | 既存因子 + 純化テーマ因子を、テーマバスケットで複製してBinary TSFMを適用する統合版。 |

各ノートブックは単体で完結します。共通関数はすべてノートブック内に埋め込んであるため、外部 `.py` ファイルに依存しません。

## 文献対応

Ehsani and Linnainmaa は、モメンタムを「他のファクターをタイミングする動的ポートフォリオ」と整理し、過去1年リターンが正のファクターをロング、負のファクターをショートする time-series factor momentum を実装しています。また、momentum-neutral factor では、元のファクターウェイトにできるだけ近いまま不要な過去リターン・エクスポージャーを落としています。

Gupta and Kelly は、特徴量ベースの多数の因子にTSFMを適用し、ボラティリティ標準化されたスケーリング式を提示しています。また、6つの広い theme factors でも同様のfactor momentum現象を再現できると述べています。

本実装では、これらの趣旨をテーマバスケット売買単位に置き換えています。

## 主要式

テーマバスケット構成行列:

\[
A_t \in \mathbb{R}^{N_t \times K_t}
\]

テーマバスケット係数によるルックスルー個別銘柄ウェイト:

\[
w^{stock,lookthrough}_t = A_t c_t
\]

制約行列:

\[
L_t = H_t' A_t
\]

テーマバスケット係数のペナルティ型最適化:

\[
\min_c\ \lambda_Z\|H_t'A_t c-d_h\|^2 + \lambda_0\|A_t(c-e_h)\|^2 + \lambda_R c'\Omega^B_t c + \lambda_2\|c\|^2
\]

テーマバスケットで複製された因子リターン:

\[
y^{basket}_{h,t+1}=c_{h,t}'A_t'r_{t+1}
\]

Binary TSFM:

\[
M^{12}_{h,t}=\prod_{u=t-11}^{t}(1+y^{basket}_{h,u})-1
\]

\[
s_{h,t}=\operatorname{sign}(M^{12}_{h,t})
\]

Vol-scaled TSFM:

\[
\tilde w^F_{h,t}=\frac{\operatorname{sign}(M^{12}_{h,t})}{\hat\sigma_{h,t}}
\]

最終テーマバスケットウェイト:

\[
w^{basket}_t=C_t w^F_t
\]

## 入力スキーマ

デフォルトは `use_synthetic_data=True` です。実データで使う場合は、各ノートブックの設定セルで `use_synthetic_data=False` に変更し、`./data/basket_tsfm_inputs.pkl` または `./data/theme_factor_inputs.pkl` を置いてください。

最低限必要なキーは以下です。

```python
{
    'stock_returns': DataFrame,
    'B_by_date': dict[date, DataFrame],
    'Z_by_date': dict[date, DataFrame],
    'A_by_date': dict[date, DataFrame],
    # または A_by_date の代わりに:
    'theme_basket_weights': DataFrame,
    'purified_theme_factor_returns': DataFrame,  # 任意
}
```

`theme_basket_weights` は `knowledge_date` または `available_date` を持つ場合、point-in-time利用可能日として扱います。ない場合は `effective_date` を使います。

## 目視確認ポイント

各ノートブックは、処理ステップごとに以下を表示します。

- 入力データ概要
- rawテーマバスケットリターン
- テーマバスケットで複製された因子リターン
- 理論上の純化テーマリターン `g_t` との相関・beta・tracking error
- 最新の `A_t`, `Z_t`, `B_t`
- `L_t = H_t' A_t` のrank/shape
- テーマバスケット係数 `C`
- `H_t' A_t C` の露出行列
- target exposure / off-target exposure / Barra residual exposure
- TSFMシグナル
- テーマバスケット売買ウェイト
- ルックスルー個別銘柄ウェイト
- gross/net return, turnover, transaction cost

## 注意

合成データの結果は検算用です。実運用では、テーマバスケットのショート可否、流動性、売買コスト、バスケットのリバランス日、バスケット内構成変更、約定ラグ、キャパシティを必ず確認してください。
