# If required in a fresh environment:
# %pip install lseg-data pandas numpy scipy matplotlib

from pathlib import Path
import json
import math
import re
import warnings

try:
    import lseg.data as ld
except ImportError as exc:
    ld = None
    LSEG_IMPORT_ERROR = exc
else:
    LSEG_IMPORT_ERROR = None

import pandas as pd
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt

pd.set_option("display.max_columns", 120)
pd.set_option("display.width", 160)

NOTEBOOK_PATH = Path("floor_constrained_protective_put_lseg_audited.ipynb")
OUTPUT_DIR = Path("outputs")
TRADING_DAYS_PER_YEAR = 252

CONFIG = {
    # Date range
    "start_date": "2005-01-01",
    "end_date": "2025-12-31",

    # LSEG instruments. User must verify these RICs in their environment.
    "underlying_ric": ".SPX",
    "hedge_ric": None,  # None means use underlying return as linear hedge proxy.
    "risk_free_ric": None,

    # LSEG session
    "lseg_session_name": None,
    "open_lseg_session": True,
    "close_lseg_session_at_end": False,

    # Option chain source
    "option_chain_mode": "lseg_discovery_or_configured_universe",
    "option_universe": None,  # Optional list of put option RICs if discovery is unavailable.
    "configured_option_universe_assumed_puts": True,
    "option_discovery_search_kwargs": None,
    "option_snapshot_lookback_days": 14,

    # Benchmark protective put definition
    "put_moneyness": 0.95,
    "target_tenor_days": 30,
    "roll_rule": "monthly_standard_expiry",  # actual standard monthly expiry signal, next-close effective
    "put_quantity": 1.0,

    # Floor constraint: mandate, not optimized.
    "max_drawdown_budget": 0.20,
    "confidence_level": 0.99,
    "scenario_method": "historical_expanding",
    "scenario_horizon_rule": "next_roll_date",
    "min_history_observations": 252,

    # Put scenario repricing
    "put_scenario_pricing": "intrinsic_conservative",

    # Execution
    "rebalance_frequency": "daily",
    "signal_timing": "close_t",
    "execution_timing": "next_close",

    # Mandate constraints
    "allow_net_short_beta": False,
    "min_total_beta": 0.0,
    "max_total_beta": 1.0,

    # Costs. These are implementation assumptions, not performance-tuned parameters.
    "futures_bps_one_way": 1.0,
    "option_bps_one_way": 20.0,
    "equity_bps_one_way": 1.0,

    # Fallbacks used only when LSEG fields are unavailable.
    "risk_free_rate_default": 0.02,
    "dividend_yield_default": 0.0,

    # Run control
    "run_backtest": False,  # Set True after LSEG session, RICs, fields, and option_universe/discovery settings are configured.
    "raise_on_missing_option_prices": True,
}

FIELD_MAP = {
    "underlying_close": "TRDPRC_1",
    "underlying_total_return": None,
    "option_close": "TRDPRC_1",
    "option_bid": "BID",
    "option_ask": "ASK",
    "option_delta": "DELTA",
    "option_iv": "IMP_VOLT",
    "option_strike": "STRIKE_PRC",
    "option_expiry": "EXPIR_DATE",
    "option_type": None,
    "risk_free_rate": None,
    "dividend_yield": None,
}

CONFIG_CATEGORIES = {
    "mandate": ["max_drawdown_budget", "confidence_level", "scenario_method", "scenario_horizon_rule", "allow_net_short_beta", "min_total_beta", "max_total_beta"],
    "benchmark_definition": ["put_moneyness", "target_tenor_days", "roll_rule", "put_quantity"],
    "lseg_field_mapping": list(FIELD_MAP.keys()),
    "transaction_cost_assumption": ["futures_bps_one_way", "option_bps_one_way", "equity_bps_one_way"],
}

CONFIG_CATEGORIES

def require_lseg():
    if ld is None:
        raise ImportError(
            "lseg.data is not available in this Python environment. "
            "Use an LSEG-enabled environment and update dependencies under envs/base with uv if required."
        ) from LSEG_IMPORT_ERROR
    return ld


def open_lseg_session(config):
    lseg = require_lseg()
    session_name = config.get("lseg_session_name")
    if session_name is None:
        return lseg.open_session()
    return lseg.open_session(name=session_name)


def close_lseg_session():
    lseg = require_lseg()
    return lseg.close_session()


if CONFIG["open_lseg_session"] and CONFIG["run_backtest"]:
    open_lseg_session(CONFIG)
else:
    print("LSEG session opening skipped by CONFIG.")

def _as_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple, set, pd.Index)):
        return list(value)
    return [value]


def required_field(field_map, logical_name):
    field = field_map.get(logical_name)
    if field is None:
        raise ValueError(
            f"Required LSEG field is missing for {logical_name}. "
            "Update FIELD_MAP in the configuration cell."
        )
    return field


def optional_field(field_map, logical_name):
    return field_map.get(logical_name)


def fetch_lseg_history(universe, fields, start, end, interval="1D"):
    'Fetch historical data via lseg.data only.'
    lseg = require_lseg()
    clean_fields = [f for f in _as_list(fields) if f is not None]
    if not clean_fields:
        raise ValueError("No LSEG fields were supplied.")
    df = lseg.get_history(
        universe=universe,
        fields=clean_fields,
        start=start,
        end=end,
        interval=interval,
    )
    if df is None or len(df) == 0:
        raise ValueError(f"No data returned from LSEG for universe={universe}, fields={clean_fields}")
    return df


def fetch_lseg_snapshot(universe, fields):
    'Fetch point-in-time or reference fields via lseg.data only.'
    lseg = require_lseg()
    clean_fields = [f for f in _as_list(fields) if f is not None]
    if not clean_fields:
        raise ValueError("No LSEG snapshot fields were supplied.")
    df = lseg.get_data(universe=universe, fields=clean_fields)
    if df is None or len(df) == 0:
        raise ValueError(f"No snapshot data returned from LSEG for universe={universe}, fields={clean_fields}")
    return df


def flatten_lseg_columns(df):
    out = df.copy()
    if isinstance(out.columns, pd.MultiIndex):
        out.columns = [
            "|".join(str(part) for part in col if part is not None and str(part) != "")
            for col in out.columns
        ]
    else:
        out.columns = [str(col) for col in out.columns]
    return out


def _column_matches_field(column_name, field):
    parts = str(column_name).split("|")
    return str(column_name) == str(field) or str(field) in parts or str(column_name).endswith("|" + str(field))


def find_field_column(df, field, required=True):
    if field is None:
        if required:
            raise ValueError("Required field is None. Update FIELD_MAP.")
        return None
    flat = flatten_lseg_columns(df)
    matches = [col for col in flat.columns if _column_matches_field(col, field)]
    if not matches:
        if required:
            raise ValueError(f"Required LSEG field is missing from returned data: {field}")
        return None
    return matches[0]


def extract_history_series(raw, field, name=None, required=True):
    flat = flatten_lseg_columns(raw)
    col = find_field_column(flat, field, required=required)
    if col is None:
        return pd.Series(index=flat.index, dtype=float, name=name or field)
    series = flat[col].copy()
    series.index = pd.to_datetime(series.index)
    series = series.sort_index()
    series.name = name or field
    return series


def extract_last_value(raw, field, required=False):
    series = extract_history_series(raw, field, required=required)
    series = series.dropna()
    if series.empty:
        if required:
            raise ValueError(f"No non-missing value found for field={field}")
        return np.nan
    return series.iloc[-1]


def normalize_rate(value):
    if pd.isna(value):
        return np.nan
    value = float(value)
    return value / 100.0 if abs(value) > 1.5 else value

def load_underlying_history(config, field_map):
    close_field = required_field(field_map, "underlying_close")
    tr_field = optional_field(field_map, "underlying_total_return")
    fields = [close_field] + ([tr_field] if tr_field else [])
    raw = fetch_lseg_history(
        universe=config["underlying_ric"],
        fields=fields,
        start=config["start_date"],
        end=config["end_date"],
        interval="1D",
    )
    close = extract_history_series(raw, close_field, name="underlying_price")
    if tr_field:
        total_return_level = extract_history_series(raw, tr_field, name="underlying_total_return_level", required=False)
        if total_return_level.notna().sum() > 0:
            underlying_return = total_return_level.pct_change()
        else:
            warnings.warn("underlying_total_return field was configured but unavailable; falling back to close returns.")
            underlying_return = close.pct_change()
    else:
        underlying_return = close.pct_change()

    out = pd.DataFrame({
        "underlying_price": close,
        "underlying_return": underlying_return,
    }).dropna(subset=["underlying_price"])
    out.index.name = "date"
    return out


def load_hedge_return(index, config, field_map, underlying_return):
    if config.get("hedge_ric") is None:
        return underlying_return.reindex(index).rename("hedge_return")
    close_field = required_field(field_map, "underlying_close")
    raw = fetch_lseg_history(
        universe=config["hedge_ric"],
        fields=[close_field],
        start=str(index.min().date()),
        end=str(index.max().date()),
        interval="1D",
    )
    hedge_price = extract_history_series(raw, close_field, name="hedge_price")
    return hedge_price.reindex(index).pct_change().rename("hedge_return")


def load_rate_inputs(index, config, field_map):
    risk_free = pd.Series(config["risk_free_rate_default"], index=index, name="risk_free_rate", dtype=float)
    dividend_yield = pd.Series(config["dividend_yield_default"], index=index, name="dividend_yield", dtype=float)

    rate_field = optional_field(field_map, "risk_free_rate")
    if config.get("risk_free_ric") is not None and rate_field is not None:
        raw = fetch_lseg_history(
            universe=config["risk_free_ric"],
            fields=[rate_field],
            start=str(index.min().date()),
            end=str(index.max().date()),
            interval="1D",
        )
        loaded = extract_history_series(raw, rate_field, name="risk_free_rate", required=False).map(normalize_rate)
        risk_free = loaded.reindex(index).ffill().fillna(config["risk_free_rate_default"])

    div_field = optional_field(field_map, "dividend_yield")
    if div_field is not None:
        try:
            raw_div = fetch_lseg_history(
                universe=config["underlying_ric"],
                fields=[div_field],
                start=str(index.min().date()),
                end=str(index.max().date()),
                interval="1D",
            )
            loaded_div = extract_history_series(raw_div, div_field, name="dividend_yield", required=False).map(normalize_rate)
            dividend_yield = loaded_div.reindex(index).ffill().fillna(config["dividend_yield_default"])
        except Exception as exc:
            warnings.warn(f"Dividend yield field could not be loaded; default used. Details: {exc}")

    return pd.DataFrame({"risk_free_rate": risk_free, "dividend_yield": dividend_yield}, index=index)

def snapshot_from_history_or_data(ric, asof_date, config, field_map):
    lookback_days = int(config.get("option_snapshot_lookback_days", 14))
    asof_date = pd.Timestamp(asof_date)
    start = (asof_date - pd.Timedelta(days=lookback_days)).strftime("%Y-%m-%d")
    end = asof_date.strftime("%Y-%m-%d")

    logical_fields = {
        "close": optional_field(field_map, "option_close"),
        "bid": optional_field(field_map, "option_bid"),
        "ask": optional_field(field_map, "option_ask"),
        "delta": optional_field(field_map, "option_delta"),
        "iv": optional_field(field_map, "option_iv"),
        "strike": optional_field(field_map, "option_strike"),
        "expiry": optional_field(field_map, "option_expiry"),
        "option_type": optional_field(field_map, "option_type"),
    }
    fields = [field for field in logical_fields.values() if field is not None]
    raw_hist = fetch_lseg_history(ric, fields, start=start, end=end, interval="1D")

    row = {"put_ric": ric}
    for logical, field in logical_fields.items():
        if field is None:
            row[logical] = np.nan
            continue
        row[logical] = extract_last_value(raw_hist, field, required=False)

    missing_static = []
    for logical in ["strike", "expiry", "option_type"]:
        if pd.isna(row.get(logical)):
            field = logical_fields[logical]
            if field is not None:
                missing_static.append(field)
    if missing_static:
        try:
            raw_static = fetch_lseg_snapshot(ric, missing_static)
            flat_static = flatten_lseg_columns(raw_static)
            first = flat_static.iloc[0]
            for logical in ["strike", "expiry", "option_type"]:
                field = logical_fields[logical]
                if field is None or not pd.isna(row.get(logical)):
                    continue
                col = find_field_column(flat_static, field, required=False)
                if col is not None:
                    row[logical] = first[col]
        except Exception as exc:
            warnings.warn(f"Static option fields could not be loaded for {ric}; details: {exc}")

    bid = pd.to_numeric(pd.Series([row.get("bid")]), errors="coerce").iloc[0]
    ask = pd.to_numeric(pd.Series([row.get("ask")]), errors="coerce").iloc[0]
    close = pd.to_numeric(pd.Series([row.get("close")]), errors="coerce").iloc[0]
    mid = np.nan
    if pd.notna(bid) and pd.notna(ask) and bid > 0 and ask > 0:
        mid = 0.5 * (bid + ask)

    row["bid"] = bid
    row["ask"] = ask
    row["close"] = close
    row["mid"] = mid
    row["strike"] = pd.to_numeric(pd.Series([row.get("strike")]), errors="coerce").iloc[0]
    row["expiry"] = pd.to_datetime(row.get("expiry"), errors="coerce")
    row["delta"] = normalize_delta(pd.to_numeric(pd.Series([row.get("delta")]), errors="coerce").iloc[0])
    row["iv"] = pd.to_numeric(pd.Series([row.get("iv")]), errors="coerce").iloc[0]
    return row


def get_option_chain_from_configured_universe(asof_date, underlying_ric, config, field_map):
    universe = config.get("option_universe")
    if not universe:
        raise ValueError(
            "No LSEG option discovery configuration or CONFIG['option_universe'] was supplied. "
            "Set CONFIG['option_universe'] to a list of put option RICs available in your LSEG environment."
        )

    rows = []
    errors = []
    for ric in universe:
        try:
            rows.append(snapshot_from_history_or_data(ric, asof_date, config, field_map))
        except Exception as exc:
            errors.append(f"{ric}: {exc}")

    if not rows:
        raise ValueError("No option candidate snapshots could be loaded. First errors: " + "; ".join(errors[:5]))
    return pd.DataFrame(rows)


def get_option_chain_from_lseg(asof_date, underlying_ric, config, field_map):
    'Return option candidates from LSEG only.'
    search_kwargs = config.get("option_discovery_search_kwargs")
    if search_kwargs:
        lseg = require_lseg()
        discovery = getattr(lseg, "discovery", None)
        if discovery is None or not hasattr(discovery, "search"):
            raise NotImplementedError("ld.discovery.search is not available in this LSEG environment.")
        raw = discovery.search(**search_kwargs)
        if raw is None or len(raw) == 0:
            raise ValueError("LSEG discovery returned no option candidates.")
        candidates = pd.DataFrame(raw)
        return candidates

    return get_option_chain_from_configured_universe(asof_date, underlying_ric, config, field_map)

def validate_required_columns(df, columns, name):
    missing = [col for col in columns if col not in df.columns]
    if missing:
        raise ValueError(f"{name} is missing required columns: {missing}")


def validate_no_missing_required_prices(df, columns, name, max_examples=10):
    missing_mask = df[columns].isna()
    if missing_mask.any().any():
        examples = []
        for col in columns:
            dates = df.index[missing_mask[col]].tolist()[:max_examples]
            if dates:
                examples.append(f"{col}: {[str(pd.Timestamp(d).date()) for d in dates]}")
        raise ValueError(f"{name} has missing required prices. " + " | ".join(examples))


def normalize_vol(value):
    if pd.isna(value):
        return np.nan
    value = float(value)
    return value / 100.0 if value > 2.0 else value


def normalize_delta(value):
    """Normalize option delta to decimal units.

    LSEG fields may return either -0.35 or -35.0 for a 35-delta put.
    Values with absolute magnitude above 2 are treated as percentages.
    """
    if pd.isna(value):
        return np.nan
    value = float(value)
    return value / 100.0 if abs(value) > 2.0 else value


def safe_pct_change(series):
    return series.astype(float).pct_change().replace([np.inf, -np.inf], np.nan)

def _third_friday(year, month):
    days = pd.date_range(f"{year}-{month:02d}-01", periods=31, freq="D")
    days = days[days.month == month]
    fridays = days[days.weekday == 4]
    if len(fridays) < 3:
        raise ValueError(f"Could not find third Friday for {year}-{month:02d}.")
    return pd.Timestamp(fridays[2])


def _previous_trading_date(dates, target_date):
    target_date = pd.Timestamp(target_date)
    eligible = dates[dates <= target_date]
    return None if len(eligible) == 0 else pd.Timestamp(eligible[-1])


def _next_trading_date(dates, signal_date):
    signal_date = pd.Timestamp(signal_date)
    pos = dates.get_indexer([signal_date])
    if len(pos) == 0 or pos[0] < 0:
        raise ValueError(f"signal_date={signal_date} is not in the trading calendar.")
    next_pos = pos[0] + 1
    if next_pos >= len(dates):
        return None
    return pd.Timestamp(dates[next_pos])


def make_roll_schedule(trading_index, roll_rule="monthly_standard_expiry"):
    """Create signal/effective roll dates.

    Supported rules:
    - monthly_standard_expiry: signal on the standard monthly option expiry date,
      approximated as the third Friday, or the previous trading day if that date is
      not present in the trading calendar; position becomes effective next close.
    - month_end_next_close: signal on each month-end trading date; position becomes
      effective next close.
    """
    dates = pd.DatetimeIndex(trading_index).sort_values()
    if len(dates) < 2:
        raise ValueError("At least two trading dates are required for next-close execution.")

    supported = {"monthly_standard_expiry", "monthly_standard_expiry_next_close", "month_end_next_close"}
    if roll_rule not in supported:
        raise NotImplementedError(f"Unsupported roll_rule: {roll_rule}. Supported: {sorted(supported)}")

    records = [{"signal_date": dates[0], "effective_date": dates[1], "roll_reason": "initial_next_close"}]
    periods = pd.PeriodIndex(dates.to_period("M")).unique().sort_values()

    for period in periods:
        month_dates = dates[dates.to_period("M") == period]
        if len(month_dates) == 0:
            continue

        if roll_rule in {"monthly_standard_expiry", "monthly_standard_expiry_next_close"}:
            raw_signal = _third_friday(period.year, period.month)
            signal_date = _previous_trading_date(dates, raw_signal)
            reason = "monthly_standard_expiry_next_close"
        elif roll_rule == "month_end_next_close":
            signal_date = pd.Timestamp(month_dates[-1])
            reason = "month_end_next_close"
        else:
            raise NotImplementedError(f"Unsupported roll_rule: {roll_rule}")

        if signal_date is None or signal_date < dates[0] or signal_date > dates[-1]:
            continue
        effective_date = _next_trading_date(dates, signal_date)
        if effective_date is None:
            continue
        records.append({"signal_date": signal_date, "effective_date": effective_date, "roll_reason": reason})

    schedule = pd.DataFrame(records).drop_duplicates(subset=["effective_date"], keep="first")
    schedule = schedule.sort_values("effective_date").reset_index(drop=True)
    return schedule


def scenario_horizon_days(current_date, roll_schedule, trading_index):
    current_date = pd.Timestamp(current_date)
    future_effective = pd.to_datetime(roll_schedule["effective_date"])
    future_effective = future_effective[future_effective > current_date]
    if len(future_effective) == 0:
        return max(1, min(21, len(trading_index) - trading_index.get_loc(current_date) - 1))
    next_roll = future_effective.iloc[0]
    dates = pd.DatetimeIndex(trading_index)
    current_pos = dates.get_loc(current_date)
    next_pos = dates.get_indexer([next_roll], method=None)[0]
    return max(1, int(next_pos - current_pos))


def bs_put_delta(spot, strike, tau_years, rate, dividend_yield, vol):
    if tau_years <= 0 or vol <= 0 or spot <= 0 or strike <= 0:
        return np.nan
    d1 = (np.log(spot / strike) + (rate - dividend_yield + 0.5 * vol**2) * tau_years) / (vol * np.sqrt(tau_years))
    return np.exp(-dividend_yield * tau_years) * (norm.cdf(d1) - 1.0)


def _option_type_is_put(value, config):
    if pd.isna(value):
        return bool(config.get("configured_option_universe_assumed_puts", True))
    normalized = str(value).strip().upper()
    return normalized in {"P", "PUT", "PUT OPTION"} or normalized.startswith("PUT")


def select_option_for_roll(asof_date, spot, config, field_map):
    chain = get_option_chain_from_lseg(asof_date, config["underlying_ric"], config, field_map).copy()

    rename_map = {}
    for possible in ["RIC", "Instrument", "instrument", "ric"]:
        if possible in chain.columns and "put_ric" not in chain.columns:
            rename_map[possible] = "put_ric"
    for possible in ["Strike", "strike_price", "STRIKE_PRC"]:
        if possible in chain.columns and "strike" not in chain.columns:
            rename_map[possible] = "strike"
    for possible in ["Expiry", "expiration_date", "EXPIR_DATE"]:
        if possible in chain.columns and "expiry" not in chain.columns:
            rename_map[possible] = "expiry"
    for possible in ["OptionType", "option_type", "PUTCALLIND"]:
        if possible in chain.columns and "option_type" not in chain.columns:
            rename_map[possible] = "option_type"
    chain = chain.rename(columns=rename_map)

    validate_required_columns(chain, ["put_ric", "strike", "expiry"], "option chain")
    chain["expiry"] = pd.to_datetime(chain["expiry"], errors="coerce")
    chain["strike"] = pd.to_numeric(chain["strike"], errors="coerce")
    if "option_type" not in chain.columns:
        chain["option_type"] = np.nan
    chain = chain[chain["option_type"].map(lambda x: _option_type_is_put(x, config))]
    chain = chain.dropna(subset=["put_ric", "strike", "expiry"])
    chain = chain[chain["expiry"] > pd.Timestamp(asof_date)]
    if chain.empty:
        raise ValueError(f"No valid put option candidates for asof_date={asof_date}.")

    target_expiry = pd.Timestamp(asof_date) + pd.Timedelta(days=int(config["target_tenor_days"]))
    target_strike = float(config["put_moneyness"]) * float(spot)
    chain["tenor_distance"] = (chain["expiry"] - target_expiry).abs().dt.days
    chain["strike_distance"] = (chain["strike"] - target_strike).abs()
    chain = chain.sort_values(["tenor_distance", "strike_distance", "expiry", "strike"])
    selected = chain.iloc[0].to_dict()
    selected["selection_asof_date"] = pd.Timestamp(asof_date)
    selected["target_strike"] = target_strike
    selected["target_expiry"] = target_expiry
    return selected

def fetch_option_history_for_contract(ric, start, end, field_map):
    fields = [
        optional_field(field_map, "option_close"),
        optional_field(field_map, "option_bid"),
        optional_field(field_map, "option_ask"),
        optional_field(field_map, "option_delta"),
        optional_field(field_map, "option_iv"),
        optional_field(field_map, "option_strike"),
        optional_field(field_map, "option_expiry"),
    ]
    fields = [field for field in fields if field is not None]
    return fetch_lseg_history(ric, fields, start=str(pd.Timestamp(start).date()), end=str(pd.Timestamp(end).date()), interval="1D")


def normalize_option_contract_history(raw, ric, selected, market, config, field_map):
    index = pd.to_datetime(raw.index)
    out = pd.DataFrame(index=index)
    out.index.name = "date"

    field_specs = {
        "put_close": optional_field(field_map, "option_close"),
        "put_bid": optional_field(field_map, "option_bid"),
        "put_ask": optional_field(field_map, "option_ask"),
        "put_delta": optional_field(field_map, "option_delta"),
        "put_iv": optional_field(field_map, "option_iv"),
        "put_strike": optional_field(field_map, "option_strike"),
        "put_expiry": optional_field(field_map, "option_expiry"),
    }
    for col, field in field_specs.items():
        if field is None:
            out[col] = np.nan
        else:
            out[col] = extract_history_series(raw, field, name=col, required=False).reindex(out.index)

    out["put_ric"] = ric
    out["put_strike"] = pd.to_numeric(out["put_strike"], errors="coerce").fillna(float(selected["strike"]))
    expiry_series = pd.to_datetime(out["put_expiry"], errors="coerce")
    out["put_expiry"] = expiry_series.fillna(pd.Timestamp(selected["expiry"]))
    out["put_bid"] = pd.to_numeric(out["put_bid"], errors="coerce")
    out["put_ask"] = pd.to_numeric(out["put_ask"], errors="coerce")
    out["put_close"] = pd.to_numeric(out["put_close"], errors="coerce")
    out["put_mid"] = np.where(
        (out["put_bid"] > 0) & (out["put_ask"] > 0),
        0.5 * (out["put_bid"] + out["put_ask"]),
        np.nan,
    )
    out["put_price"] = pd.Series(out["put_mid"], index=out.index).combine_first(out["put_close"])
    out["put_delta"] = pd.to_numeric(out["put_delta"], errors="coerce").map(normalize_delta)
    out["put_iv"] = pd.to_numeric(out["put_iv"], errors="coerce").map(normalize_vol)
    out["put_maturity_days"] = (pd.to_datetime(out["put_expiry"]) - pd.to_datetime(out.index)).days
    out["put_quantity"] = float(config["put_quantity"])

    out["put_delta_source"] = "LSEG"
    missing_delta = out["put_delta"].isna()
    if missing_delta.any():
        for date in out.index[missing_delta]:
            if date not in market.index:
                continue
            spot = market.loc[date, "underlying_price"]
            strike = out.loc[date, "put_strike"]
            tau = max(out.loc[date, "put_maturity_days"], 0) / 365.25
            rate = market.loc[date, "risk_free_rate"]
            div_yield = market.loc[date, "dividend_yield"]
            vol = out.loc[date, "put_iv"]
            out.loc[date, "put_delta"] = bs_put_delta(spot, strike, tau, rate, div_yield, vol)
            out.loc[date, "put_delta_source"] = "BS_FALLBACK"

    return out


def build_option_sleeve(market, roll_schedule, config, field_map):
    dates = pd.DatetimeIndex(market.index)
    columns = [
        "put_ric", "put_price", "put_bid", "put_ask", "put_mid", "put_delta", "put_delta_source",
        "put_iv", "put_strike", "put_expiry", "put_maturity_days", "put_quantity", "roll_flag",
        "put_price_for_pnl", "put_ric_for_pnl", "roll_entry_price", "roll_exit_price", "selection_asof_date",
    ]
    sleeve = pd.DataFrame(index=dates, columns=columns)
    sleeve["roll_flag"] = False

    decisions = []
    for _, row in roll_schedule.iterrows():
        signal_date = pd.Timestamp(row["signal_date"])
        effective_date = pd.Timestamp(row["effective_date"])
        spot_signal = market.loc[signal_date, "underlying_price"]
        selected = select_option_for_roll(signal_date, spot_signal, config, field_map)
        selected["effective_date"] = effective_date
        selected["signal_date"] = signal_date
        decisions.append(selected)

    if not decisions:
        raise ValueError("No option roll decisions were created.")

    for idx, selected in enumerate(decisions):
        effective_date = pd.Timestamp(selected["effective_date"])
        next_effective = pd.Timestamp(decisions[idx + 1]["effective_date"]) if idx + 1 < len(decisions) else dates[-1]
        active_dates = dates[(dates >= effective_date) & (dates < next_effective)]
        pnl_dates = dates[(dates > effective_date) & (dates <= next_effective)]
        fetch_end = next_effective
        raw = fetch_option_history_for_contract(selected["put_ric"], effective_date, fetch_end, field_map)
        hist = normalize_option_contract_history(raw, selected["put_ric"], selected, market, config, field_map)

        if len(active_dates) > 0:
            active = hist.reindex(active_dates)
            for col in [
                "put_ric", "put_price", "put_bid", "put_ask", "put_mid", "put_delta", "put_delta_source",
                "put_iv", "put_strike", "put_expiry", "put_maturity_days", "put_quantity",
            ]:
                sleeve.loc[active_dates, col] = active[col].values
            sleeve.loc[effective_date, "roll_flag"] = True
            sleeve.loc[effective_date, "roll_entry_price"] = sleeve.loc[effective_date, "put_price"]
            sleeve.loc[active_dates, "selection_asof_date"] = selected["selection_asof_date"]

        if len(pnl_dates) > 0:
            pnl = hist.reindex(pnl_dates)
            sleeve.loc[pnl_dates, "put_price_for_pnl"] = pnl["put_price"].values
            sleeve.loc[pnl_dates, "put_ric_for_pnl"] = selected["put_ric"]

    sleeve["put_price_for_pnl"] = sleeve["put_price_for_pnl"].combine_first(sleeve["put_price"])
    sleeve["put_ric_for_pnl"] = sleeve["put_ric_for_pnl"].combine_first(sleeve["put_ric"])

    roll_dates = sleeve.index[sleeve["roll_flag"].fillna(False)]
    for date in roll_dates:
        if pd.isna(sleeve.loc[date, "roll_exit_price"]):
            sleeve.loc[date, "roll_exit_price"] = sleeve.loc[date, "put_price_for_pnl"]

    required_price_cols = ["put_price", "put_delta", "put_strike", "put_expiry", "put_price_for_pnl"]
    active = sleeve[sleeve["put_ric"].notna()]
    if config.get("raise_on_missing_option_prices", True):
        validate_no_missing_required_prices(active, required_price_cols, "option sleeve")
    return sleeve

def build_protective_put_base(results, config):
    out = results.copy()
    underlying_units = 1.0
    put_quantity = float(config["put_quantity"])
    option_bps = float(config["option_bps_one_way"]) / 10000.0

    cash_base = 0.0
    current_put_ric = None
    nav_base = []
    option_costs = []
    option_turnover_notional = []
    base_cash_values = []

    for date, row in out.iterrows():
        tc_option = 0.0
        turnover = 0.0
        if bool(row.get("roll_flag", False)):
            entry_price = float(row["put_price"])
            if current_put_ric is None:
                turnover = abs(put_quantity * entry_price)
                current_put_ric = row["put_ric"]
            else:
                exit_price = float(row["roll_exit_price"])
                turnover = abs(put_quantity * exit_price) + abs(put_quantity * entry_price)
                cash_base += put_quantity * exit_price - put_quantity * entry_price
                current_put_ric = row["put_ric"]
            tc_option = option_bps * turnover
            cash_base -= tc_option

        nav = underlying_units * float(row["underlying_price"]) + put_quantity * float(row["put_price"]) + cash_base
        nav_base.append(nav)
        option_costs.append(tc_option)
        option_turnover_notional.append(turnover)
        base_cash_values.append(cash_base)

    out["nav_protective_put_base"] = nav_base
    out["ret_protective_put_base"] = out["nav_protective_put_base"].pct_change()
    out["transaction_cost_option"] = option_costs
    out["option_turnover_notional"] = option_turnover_notional
    out["base_cash_position"] = base_cash_values
    first_nav = out["nav_protective_put_base"].dropna().iloc[0]
    first_spot = out["underlying_price"].dropna().iloc[0]
    out["nav_underlying_only"] = first_nav * out["underlying_price"] / first_spot
    out["ret_underlying_only"] = out["nav_underlying_only"].pct_change()
    return out

def compute_floor_state(nav, high_watermark, max_drawdown_budget):
    updated_hwm = max(high_watermark, nav)
    floor_value = (1.0 - max_drawdown_budget) * updated_hwm
    cushion = nav - floor_value
    return {
        "high_watermark": updated_hwm,
        "floor_value": floor_value,
        "cushion": cushion,
    }


def compute_beta_pput_ex_hedge(spot, nav, underlying_units, put_quantity, put_delta):
    if nav == 0 or pd.isna(nav):
        return np.nan
    return (underlying_units * spot + put_quantity * normalize_delta(put_delta) * spot) / nav


def compute_historical_loss_scenario(price_series, current_date, horizon_days, confidence_level, min_history_observations):
    """Expanding historical H-day loss scenario using only data known before current_date.

    Uses prices strictly before current_date. Forward H-day returns are computed only
    where both the start and end points are in that pre-current-date history; no extra
    horizon block is discarded.
    """
    hist = price_series.loc[:current_date].iloc[:-1].dropna()
    horizon_days = int(horizon_days)
    if len(hist) <= horizon_days:
        return np.nan

    fwd_returns = hist.shift(-horizon_days) / hist - 1.0
    fwd_returns = fwd_returns.dropna()

    if len(fwd_returns) < int(min_history_observations):
        return np.nan

    q = np.quantile(fwd_returns.values, 1.0 - float(confidence_level))
    return max(0.0, -float(q))


def compute_put_scenario_gain(spot, put_price, strike, quantity, loss_scenario, method="intrinsic_conservative"):
    if method != "intrinsic_conservative":
        raise NotImplementedError(f"Unsupported put_scenario_pricing: {method}")
    if np.isnan(loss_scenario) or loss_scenario <= 0:
        return 0.0
    scen_spot = spot * (1.0 - loss_scenario)
    scen_put_value = max(strike - scen_spot, 0.0)
    return quantity * (scen_put_value - put_price)


def compute_beta_max(nav, cushion, put_scenario_gain, loss_scenario):
    if np.isnan(loss_scenario) or loss_scenario <= 0:
        return np.inf
    return (cushion + put_scenario_gain) / (nav * loss_scenario)


def compute_minimum_hedge_beta(
    beta_pput_ex_hedge,
    beta_max,
    allow_net_short_beta=False,
    min_total_beta=0.0,
    max_total_beta=1.0,
):
    if np.isinf(beta_max):
        hedge_beta = 0.0
    else:
        hedge_beta = min(0.0, beta_max - beta_pput_ex_hedge)

    beta_total = beta_pput_ex_hedge + hedge_beta

    if not allow_net_short_beta:
        beta_total = max(min_total_beta, beta_total)
        hedge_beta = beta_total - beta_pput_ex_hedge

    beta_total = min(max_total_beta, beta_total)
    hedge_beta = beta_total - beta_pput_ex_hedge

    return hedge_beta

def prepare_market_data(config, field_map):
    market = load_underlying_history(config, field_map)
    rates = load_rate_inputs(market.index, config, field_map)
    market = market.join(rates, how="left")
    market["hedge_return"] = load_hedge_return(market.index, config, field_map, market["underlying_return"])
    return market


def align_backtest_inputs(market, option_sleeve):
    combined = market.join(option_sleeve, how="left")
    combined = combined[combined["put_ric"].notna()].copy()
    if combined.empty:
        raise ValueError("No active option sleeve rows after next-close roll alignment.")
    combined["date"] = combined.index
    return combined


def validate_config_implementation_scope(config):
    if config.get("scenario_method") != "historical_expanding":
        raise NotImplementedError("Only scenario_method='historical_expanding' is implemented in the audited notebook.")
    if config.get("put_scenario_pricing") != "intrinsic_conservative":
        raise NotImplementedError("Only put_scenario_pricing='intrinsic_conservative' is implemented in the audited notebook.")
    if config.get("execution_timing") != "next_close":
        raise NotImplementedError("Only execution_timing='next_close' is implemented in the audited notebook.")
    if config.get("signal_timing") != "close_t":
        raise NotImplementedError("Only signal_timing='close_t' is implemented in the audited notebook.")


def run_floor_constrained_engine(results, roll_schedule, config):
    """Run floor-constrained minimum hedge with true next-close execution lag.

    For each date t:
    - P&L over the interval ending at t uses the hedge that was effective at the
      previous close.
    - The order generated by yesterday's close signal is executed at today's close;
      its transaction cost is charged today, and the position becomes effective for
      the next close-to-close return.
    - Today's signal is submitted as an order for tomorrow's close execution.
    """
    validate_config_implementation_scope(config)

    out = results.copy()
    underlying_units = 1.0
    put_quantity = float(config["put_quantity"])
    hedge_bps = float(config["futures_bps_one_way"]) / 10000.0
    max_dd = float(config["max_drawdown_budget"])

    high_watermark = -np.inf
    hedge_cash = 0.0
    floor_nav_prev = np.nan

    # Position mechanics for next-close execution.
    hedge_beta_effective_for_return = 0.0  # earns the return ending at the current row
    order_to_execute_today = 0.0           # signal generated on the previous row

    records = {
        "nav_floor_constrained_protective_put": [],
        "ret_floor_constrained_protective_put": [],
        "high_watermark": [],
        "floor_value": [],
        "cushion": [],
        "loss_scenario": [],
        "put_scenario_gain": [],
        "beta_max": [],
        "beta_pput_ex_hedge": [],
        "hedge_beta_effective_return": [],
        "hedge_beta_executed": [],
        "hedge_beta_target": [],
        "hedge_beta_trade": [],
        "hedge_beta_order_next_close": [],
        "beta_total_after_hedge": [],
        "hedge_pnl": [],
        "transaction_cost_hedge": [],
        "transaction_cost_futures": [],
        "cash_position": [],
        "futures_position": [],
    }

    price_series = out["underlying_price"]
    trading_index = pd.DatetimeIndex(out.index)

    for i, (date, row) in enumerate(out.iterrows()):
        if i == 0:
            hedge_pnl = 0.0
            floor_nav_before_execution = float(row["nav_protective_put_base"])
        else:
            hedge_pnl = hedge_beta_effective_for_return * float(floor_nav_prev) * float(row["hedge_return"])
            hedge_cash += hedge_pnl
            floor_nav_before_execution = float(row["nav_protective_put_base"]) + hedge_cash

        # Execute yesterday's signal at today's close. This execution does not earn today's return.
        hedge_beta_executed = float(order_to_execute_today)
        executed_trade = hedge_beta_executed - hedge_beta_effective_for_return
        hedge_cost = hedge_bps * abs(executed_trade) * float(floor_nav_before_execution)
        hedge_cash -= hedge_cost
        floor_nav = floor_nav_before_execution - hedge_cost

        if pd.isna(floor_nav_prev):
            ret_floor = np.nan
        else:
            ret_floor = floor_nav / floor_nav_prev - 1.0

        floor_state = compute_floor_state(floor_nav, high_watermark if np.isfinite(high_watermark) else floor_nav, max_dd)
        high_watermark = floor_state["high_watermark"]

        beta_pput = compute_beta_pput_ex_hedge(
            spot=float(row["underlying_price"]),
            nav=floor_nav,
            underlying_units=underlying_units,
            put_quantity=put_quantity,
            put_delta=float(row["put_delta"]),
        )
        horizon = scenario_horizon_days(date, roll_schedule, trading_index)
        loss_scenario = compute_historical_loss_scenario(
            price_series=price_series,
            current_date=date,
            horizon_days=horizon,
            confidence_level=float(config["confidence_level"]),
            min_history_observations=int(config["min_history_observations"]),
        )
        put_gain = compute_put_scenario_gain(
            spot=float(row["underlying_price"]),
            put_price=float(row["put_price"]),
            strike=float(row["put_strike"]),
            quantity=put_quantity,
            loss_scenario=loss_scenario,
            method=config.get("put_scenario_pricing", "intrinsic_conservative"),
        )
        beta_max_value = compute_beta_max(floor_nav, floor_state["cushion"], put_gain, loss_scenario)
        hedge_target = compute_minimum_hedge_beta(
            beta_pput_ex_hedge=beta_pput,
            beta_max=beta_max_value,
            allow_net_short_beta=bool(config["allow_net_short_beta"]),
            min_total_beta=float(config["min_total_beta"]),
            max_total_beta=float(config["max_total_beta"]),
        )
        hedge_trade_signal = hedge_target - hedge_beta_executed
        beta_total_after_execution = beta_pput + hedge_beta_executed
        futures_position = hedge_beta_executed * floor_nav / float(row["underlying_price"])

        records["nav_floor_constrained_protective_put"].append(floor_nav)
        records["ret_floor_constrained_protective_put"].append(ret_floor)
        records["high_watermark"].append(floor_state["high_watermark"])
        records["floor_value"].append(floor_state["floor_value"])
        records["cushion"].append(floor_state["cushion"])
        records["loss_scenario"].append(loss_scenario)
        records["put_scenario_gain"].append(put_gain)
        records["beta_max"].append(beta_max_value)
        records["beta_pput_ex_hedge"].append(beta_pput)
        records["hedge_beta_effective_return"].append(hedge_beta_effective_for_return)
        records["hedge_beta_executed"].append(hedge_beta_executed)
        records["hedge_beta_target"].append(hedge_target)
        records["hedge_beta_trade"].append(executed_trade)
        records["hedge_beta_order_next_close"].append(hedge_target)
        records["beta_total_after_hedge"].append(beta_total_after_execution)
        records["hedge_pnl"].append(hedge_pnl)
        records["transaction_cost_hedge"].append(hedge_cost)
        records["transaction_cost_futures"].append(hedge_cost)
        records["cash_position"].append(float(row["base_cash_position"]) + hedge_cash)
        records["futures_position"].append(futures_position)

        # Today's signal becomes tomorrow's close order; today's executed hedge earns tomorrow's return.
        hedge_beta_effective_for_return = hedge_beta_executed
        order_to_execute_today = hedge_target
        floor_nav_prev = floor_nav

    for col, values in records.items():
        out[col] = values
    out["transaction_cost_total"] = out["transaction_cost_option"].fillna(0.0) + out["transaction_cost_hedge"].fillna(0.0)
    return out


def run_full_backtest(config=CONFIG, field_map=FIELD_MAP):
    validate_config_implementation_scope(config)
    market = prepare_market_data(config, field_map)
    roll_schedule = make_roll_schedule(market.index, config["roll_rule"])
    option_sleeve = build_option_sleeve(market, roll_schedule, config, field_map)
    results = align_backtest_inputs(market, option_sleeve)
    results = build_protective_put_base(results, config)

    option_cols = [
        "put_ric", "put_price", "put_delta", "put_strike", "put_expiry",
        "put_maturity_days", "put_quantity", "roll_flag"
    ]
    option_sleeve_pre_floor = results[option_cols].copy(deep=True)

    results = run_floor_constrained_engine(results, roll_schedule, config)
    assert_option_sleeve_identity(option_sleeve_pre_floor, results)

    results = add_attribution(results, config)
    results = finalize_results_columns(results)
    performance_summary = compute_performance_summary(results)
    attribution_summary = compute_attribution_summary(results)
    return results, performance_summary, attribution_summary

def add_attribution(results, config):
    out = results.copy()
    nav_prev = out["nav_floor_constrained_protective_put"].shift(1)
    put_quantity = float(config["put_quantity"])

    roll_beta = out["beta_pput_ex_hedge"].where(out["roll_flag"].fillna(False)).ffill()
    roll_beta = roll_beta.fillna(out["beta_pput_ex_hedge"].expanding().min())
    beta_prev = out["beta_pput_ex_hedge"].shift(1)
    cycle_beta_prev = roll_beta.shift(1)

    out["passive_equity_return"] = cycle_beta_prev * out["underlying_return"]

    put_price_current_for_pnl = pd.to_numeric(out["put_price_for_pnl"], errors="coerce")
    put_price_prev = pd.to_numeric(out["put_price"], errors="coerce").shift(1)
    put_delta_prev = pd.to_numeric(out["put_delta"], errors="coerce").shift(1)
    spot_change = out["underlying_price"] - out["underlying_price"].shift(1)
    out["long_vol_return"] = put_quantity * (put_price_current_for_pnl - put_price_prev - put_delta_prev * spot_change) / nav_prev

    out["dynamic_equity_return"] = (beta_prev - cycle_beta_prev) * out["underlying_return"]
    out["floor_hedge_return"] = out["hedge_pnl"] / nav_prev
    out["cost_return"] = -out["transaction_cost_total"] / nav_prev

    out["attribution_residual"] = out["ret_floor_constrained_protective_put"] - (
        out["passive_equity_return"]
        + out["long_vol_return"]
        + out["dynamic_equity_return"]
        + out["floor_hedge_return"]
        + out["cost_return"]
    )

    residual_abs = out["attribution_residual"].abs().dropna()
    if len(residual_abs) > 0 and residual_abs.quantile(0.99) > 0.01:
        warnings.warn(
            "Attribution residual is large at the 99th percentile. "
            "Review roll-date option P&L and hedge execution timing diagnostics."
        )
    return out


def compute_attribution_summary(results):
    cols = [
        "passive_equity_return",
        "long_vol_return",
        "dynamic_equity_return",
        "floor_hedge_return",
        "cost_return",
        "attribution_residual",
    ]
    summary = pd.DataFrame({
        "mean_daily": results[cols].mean(),
        "annualized_sum": results[cols].mean() * TRADING_DAYS_PER_YEAR,
        "cumulative_compound": (1.0 + results[cols].fillna(0.0)).prod() - 1.0,
    })
    return summary

def max_drawdown(nav):
    nav = nav.dropna()
    if nav.empty:
        return np.nan
    running_max = nav.cummax()
    drawdown = nav / running_max - 1.0
    return float(drawdown.min())


def annualized_return(ret):
    ret = ret.dropna()
    if ret.empty:
        return np.nan
    compounded = (1.0 + ret).prod()
    years = len(ret) / TRADING_DAYS_PER_YEAR
    if years <= 0:
        return np.nan
    return compounded ** (1.0 / years) - 1.0


def annualized_volatility(ret):
    ret = ret.dropna()
    return float(ret.std() * np.sqrt(TRADING_DAYS_PER_YEAR)) if len(ret) > 1 else np.nan


def sharpe_ratio(ret):
    vol = annualized_volatility(ret)
    if pd.isna(vol) or vol == 0:
        return np.nan
    return annualized_return(ret) / vol


def rolling_worst_return(ret, window):
    compounded = (1.0 + ret.fillna(0.0)).rolling(window).apply(np.prod, raw=True) - 1.0
    return float(compounded.min()) if compounded.notna().any() else np.nan


def regression_beta(strategy_ret, underlying_ret, mask=None):
    df = pd.DataFrame({"strategy": strategy_ret, "underlying": underlying_ret}).dropna()
    if mask is not None:
        df = df[mask.reindex(df.index).fillna(False)]
    if len(df) < 2 or df["underlying"].var() == 0:
        return np.nan
    return float(df["strategy"].cov(df["underlying"]) / df["underlying"].var())



def compute_performance_summary(results):
    beta_floor = results["beta_total_after_hedge"] if "beta_total_after_hedge" in results.columns else results["beta_pput_ex_hedge"]
    specs = {
        "underlying_only": ("nav_underlying_only", "ret_underlying_only", pd.Series(1.0, index=results.index)),
        "protective_put_base": ("nav_protective_put_base", "ret_protective_put_base", results["beta_pput_ex_hedge"]),
        "floor_constrained_protective_put": (
            "nav_floor_constrained_protective_put",
            "ret_floor_constrained_protective_put",
            beta_floor,
        ),
    }
    rows = []
    down_mask = results["underlying_return"] < 0
    up_mask = results["underlying_return"] >= 0

    for name, (nav_col, ret_col, beta_series) in specs.items():
        ret = results[ret_col]
        nav = results[nav_col]
        mdd = max_drawdown(nav)
        ann_ret = annualized_return(ret)

        if name == "underlying_only":
            option_turnover = 0.0
            total_cost = 0.0
        elif name == "protective_put_base":
            option_turnover = float(results["option_turnover_notional"].fillna(0.0).sum())
            total_cost = float(results["transaction_cost_option"].fillna(0.0).sum())
        elif name == "floor_constrained_protective_put":
            option_turnover = float(results["option_turnover_notional"].fillna(0.0).sum())
            total_cost = float(
                results["transaction_cost_option"].fillna(0.0).sum()
                + results["transaction_cost_hedge"].fillna(0.0).sum()
            )
        else:
            option_turnover = np.nan
            total_cost = np.nan

        row = {
            "strategy": name,
            "annualized_return": ann_ret,
            "annualized_volatility": annualized_volatility(ret),
            "sharpe_ratio": sharpe_ratio(ret),
            "max_drawdown": mdd,
            "calmar_ratio": ann_ret / abs(mdd) if pd.notna(ann_ret) and pd.notna(mdd) and mdd != 0 else np.nan,
            "worst_1m_return": rolling_worst_return(ret, 21),
            "worst_3m_return": rolling_worst_return(ret, 63),
            "average_beta": float(beta_series.dropna().mean()) if beta_series.dropna().size else np.nan,
            "downside_beta": regression_beta(ret, results["underlying_return"], down_mask),
            "upside_beta": regression_beta(ret, results["underlying_return"], up_mask),
            "floor_breach_count": np.nan,
            "average_hedge_beta": np.nan,
            "hedge_turnover": np.nan,
            "option_turnover": option_turnover,
            "total_transaction_cost": total_cost,
        }
        if name == "floor_constrained_protective_put":
            row["floor_breach_count"] = int((results["nav_floor_constrained_protective_put"] < results["floor_value"]).sum())
            row["average_hedge_beta"] = float(results["hedge_beta_executed"].dropna().mean()) if "hedge_beta_executed" in results else float(results["hedge_beta_target"].dropna().mean())
            row["hedge_turnover"] = float(results["hedge_beta_trade"].abs().sum())
        rows.append(row)

    return pd.DataFrame(rows).set_index("strategy")


def drawdown_series(nav):
    nav = nav.astype(float)
    return nav / nav.cummax() - 1.0


def plot_nav_comparison(results):
    fig, ax = plt.subplots(figsize=(11, 5))
    for col, label in [
        ("nav_underlying_only", "underlying_only"),
        ("nav_protective_put_base", "protective_put_base"),
        ("nav_floor_constrained_protective_put", "floor_constrained_protective_put"),
    ]:
        ax.plot(results.index, results[col], label=label)
    ax.set_title("NAV comparison")
    ax.legend()
    ax.grid(True, alpha=0.3)
    return fig


def plot_drawdown_comparison(results):
    fig, ax = plt.subplots(figsize=(11, 5))
    for col, label in [
        ("nav_underlying_only", "underlying_only"),
        ("nav_protective_put_base", "protective_put_base"),
        ("nav_floor_constrained_protective_put", "floor_constrained_protective_put"),
    ]:
        ax.plot(results.index, drawdown_series(results[col]), label=label)
    ax.set_title("Drawdown comparison")
    ax.legend()
    ax.grid(True, alpha=0.3)
    return fig


def plot_effective_beta_path(results):
    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(results.index, results["beta_pput_ex_hedge"], label="PPUT beta ex hedge")
    ax.plot(results.index, results["beta_total_after_hedge"], label="Total beta after planned hedge")
    ax.set_title("Effective beta path")
    ax.legend()
    ax.grid(True, alpha=0.3)
    return fig


def plot_floor_nav_cushion(results):
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(results.index, results["nav_floor_constrained_protective_put"], label="floor strategy NAV")
    ax.plot(results.index, results["floor_value"], label="floor")
    ax2 = ax.twinx()
    ax2.plot(results.index, results["cushion"], color="tab:green", alpha=0.35, label="cushion")
    ax.set_title("Floor, NAV, and cushion path")
    ax.legend(loc="upper left")
    ax2.legend(loc="upper right")
    ax.grid(True, alpha=0.3)
    return fig


def plot_hedge_beta_target(results):
    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(results.index, results["hedge_beta_target"], label="hedge beta target")
    ax.axhline(0.0, color="black", linewidth=1)
    ax.set_title("Hedge beta target path")
    ax.legend()
    ax.grid(True, alpha=0.3)
    return fig


def plot_attribution_cumulative(results):
    cols = ["passive_equity_return", "long_vol_return", "dynamic_equity_return", "floor_hedge_return", "cost_return", "attribution_residual"]
    fig, ax = plt.subplots(figsize=(11, 5))
    cumulative = (1.0 + results[cols].fillna(0.0)).cumprod() - 1.0
    cumulative.plot(ax=ax)
    ax.set_title("Attribution cumulative contribution")
    ax.grid(True, alpha=0.3)
    return fig


def plot_drawdown_speed_vs_return(results, speed_window=5, return_window=5):
    dd = drawdown_series(results["nav_underlying_only"])
    drawdown_speed = dd.diff(speed_window)
    strategy_return = (1.0 + results["ret_floor_constrained_protective_put"].fillna(0.0)).rolling(return_window).apply(np.prod, raw=True) - 1.0
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(drawdown_speed, strategy_return, s=12, alpha=0.5)
    ax.set_xlabel(f"Underlying drawdown change over {speed_window} days")
    ax.set_ylabel(f"Floor strategy return over {return_window} days")
    ax.set_title("Drawdown speed vs strategy return")
    ax.grid(True, alpha=0.3)
    return fig


def plot_required_diagnostics(results):
    figs = [
        plot_nav_comparison(results),
        plot_drawdown_comparison(results),
        plot_effective_beta_path(results),
        plot_floor_nav_cushion(results),
        plot_hedge_beta_target(results),
        plot_attribution_cumulative(results),
        plot_drawdown_speed_vs_return(results),
    ]
    return figs

def assert_option_sleeve_identity(results_base, results_floor):
    option_cols = [
        "put_ric", "put_price", "put_delta", "put_strike", "put_expiry",
        "put_maturity_days", "put_quantity", "roll_flag"
    ]
    for col in option_cols:
        left = results_base[col].reset_index(drop=True) if isinstance(results_base.index, pd.DatetimeIndex) else results_base[col]
        right = results_floor[col].reset_index(drop=True) if isinstance(results_floor.index, pd.DatetimeIndex) else results_floor[col]
        assert left.equals(right), f"Option sleeve mismatch: {col}"


def notebook_code_source(path=NOTEBOOK_PATH):
    if not path.exists():
        raise FileNotFoundError(f"Notebook file not found for structural checks: {path.resolve()}")
    nb_json = json.loads(path.read_text(encoding="utf-8"))
    pieces = []
    for cell in nb_json.get("cells", []):
        if cell.get("cell_type") == "code":
            source = cell.get("source", "")
            pieces.append("".join(source) if isinstance(source, list) else str(source))
    return "\n".join(pieces)


def assert_no_forbidden_external_imports(source_text):
    forbidden = ["yfinance", "pandas_datareader", "quandl", "xbbg", "blpapi", "wrds"]
    for package in forbidden:
        pattern = re.compile(rf"^\s*(?:import|from)\s+{re.escape(package)}(?:\b|\.)", re.MULTILINE)
        assert not pattern.search(source_text), f"Forbidden external data import found: {package}"


def assert_no_arbitrary_parameter_names(source_text):
    forbidden_parts = [
        ("lambda", "_DD"),
        ("lambda", "_MOM"),
        ("rho", "_up"),
        ("rho", "_down"),
        ("partial_hedge_", "ratio"),
        ("momentum_", "signal"),
        ("trend_", "signal"),
    ]
    for left, right in forbidden_parts:
        name = left + right
        assert name not in source_text, f"Forbidden arbitrary parameter name found: {name}"


# Pure formula tests.
assert normalize_delta(-35.0) == -0.35
assert normalize_delta(-0.35) == -0.35
assert normalize_delta(25.0) == 0.25
assert np.isnan(normalize_delta(np.nan))

assert compute_minimum_hedge_beta(0.6, 0.8) == 0.0
assert np.isclose(compute_minimum_hedge_beta(0.8, 0.5), -0.3)
assert compute_minimum_hedge_beta(1.2, -0.5, allow_net_short_beta=False, min_total_beta=0.0) == -1.2

b1 = compute_beta_max(nav=100, cushion=10, put_scenario_gain=0, loss_scenario=0.1)
b2 = compute_beta_max(nav=100, cushion=10, put_scenario_gain=5, loss_scenario=0.1)
assert b2 > b1

b1 = compute_beta_max(nav=100, cushion=20, put_scenario_gain=0, loss_scenario=0.1)
b2 = compute_beta_max(nav=100, cushion=5, put_scenario_gain=0, loss_scenario=0.1)
assert b2 < b1

assert compute_minimum_hedge_beta(beta_pput_ex_hedge=0.2, beta_max=0.5) == 0.0

# Historical scenario: no future data and no redundant horizon-block deletion.
dates = pd.date_range("2020-01-01", periods=420, freq="B")
prices = pd.Series(100.0 + np.arange(len(dates)) * 0.01, index=dates)
current_date = dates[360]
scenario_a = compute_historical_loss_scenario(prices, current_date, 21, 0.99, 50)
prices_changed_future = prices.copy()
prices_changed_future.loc[dates[361]:] = prices_changed_future.loc[dates[361]:] * 0.1
scenario_b = compute_historical_loss_scenario(prices_changed_future, current_date, 21, 0.99, 50)
assert np.isclose(scenario_a, scenario_b, equal_nan=True)

small_dates = pd.date_range("2022-01-03", periods=8, freq="B")
small_prices = pd.Series([100, 101, 99, 98, 97, 96, 95, 94], index=small_dates, dtype=float)
small_current = small_dates[7]
# Strictly before current date gives 7 prices and 5 valid two-day forward returns.
hist = small_prices.loc[:small_current].iloc[:-1].dropna()
expected_count = len((hist.shift(-2) / hist - 1.0).dropna())
assert expected_count == 5
scenario_small = compute_historical_loss_scenario(small_prices, small_current, 2, 0.80, 1)
assert pd.notna(scenario_small)

# Roll rule semantics.
roll_dates = pd.date_range("2024-01-01", "2024-03-31", freq="B")
standard_schedule = make_roll_schedule(roll_dates, "monthly_standard_expiry")
third_friday_jan = _third_friday(2024, 1)
jan_signal = standard_schedule.loc[standard_schedule["roll_reason"].eq("monthly_standard_expiry_next_close"), "signal_date"].iloc[0]
assert jan_signal <= third_friday_jan
assert jan_signal.weekday() <= 4
month_end_schedule = make_roll_schedule(roll_dates, "month_end_next_close")
assert "month_end_next_close" in set(month_end_schedule["roll_reason"])

# Execution-lag test: today's signal should not earn today's close-to-close return.
synthetic_engine = pd.DataFrame(index=pd.date_range("2020-01-01", periods=5, freq="B"))
synthetic_engine["underlying_price"] = [100, 90, 81, 81, 81]
synthetic_engine["underlying_return"] = synthetic_engine["underlying_price"].pct_change()
synthetic_engine["hedge_return"] = synthetic_engine["underlying_return"]
synthetic_engine["put_price"] = [5, 14, 23, 23, 23]
synthetic_engine["put_price_for_pnl"] = synthetic_engine["put_price"]
synthetic_engine["put_delta"] = [-0.2, -0.8, -0.95, -0.95, -0.95]
synthetic_engine["put_strike"] = 95.0
synthetic_engine["put_expiry"] = pd.Timestamp("2020-02-21")
synthetic_engine["put_maturity_days"] = [37, 36, 35, 34, 33]
synthetic_engine["put_quantity"] = 1.0
synthetic_engine["put_ric"] = "P1"
synthetic_engine["roll_flag"] = [True, False, False, False, False]
synthetic_engine["put_bid"] = synthetic_engine["put_price"]
synthetic_engine["put_ask"] = synthetic_engine["put_price"]
synthetic_engine["put_mid"] = synthetic_engine["put_price"]
synthetic_engine["put_iv"] = 0.2
synthetic_engine["roll_exit_price"] = synthetic_engine["put_price"]
synthetic_engine["base_cash_position"] = 0.0
synthetic_engine["nav_protective_put_base"] = synthetic_engine["underlying_price"] + synthetic_engine["put_price"]
synthetic_engine["ret_protective_put_base"] = synthetic_engine["nav_protective_put_base"].pct_change()
synthetic_engine["transaction_cost_option"] = 0.0
cfg_test = CONFIG.copy()
cfg_test.update({
    "max_drawdown_budget": 0.05,
    "confidence_level": 0.50,
    "min_history_observations": 1,
    "futures_bps_one_way": 0.0,
    "execution_timing": "next_close",
})
roll_test = pd.DataFrame({
    "signal_date": [synthetic_engine.index[0]],
    "effective_date": [synthetic_engine.index[1]],
    "roll_reason": ["initial_next_close"],
})
lagged = run_floor_constrained_engine(synthetic_engine, roll_test, cfg_test)
assert lagged["hedge_beta_effective_return"].iloc[1] == 0.0
assert lagged["hedge_beta_executed"].iloc[1] == 0.0
# If a hedge is signalled on date 1, it executes on date 2 and earns returns only from date 3 onward.
assert lagged["hedge_beta_effective_return"].iloc[2] == 0.0

# Strategy-specific cost summary test.
cost_test = lagged.copy()
cost_test["nav_underlying_only"] = cost_test["nav_protective_put_base"]
cost_test["ret_underlying_only"] = cost_test["nav_underlying_only"].pct_change()
cost_test["option_turnover_notional"] = 10.0
cost_test["transaction_cost_option"] = 1.0
cost_test["transaction_cost_hedge"] = 2.0
summary_test = compute_performance_summary(cost_test)
assert summary_test.loc["underlying_only", "total_transaction_cost"] == 0.0
assert summary_test.loc["protective_put_base", "total_transaction_cost"] == float(cost_test["transaction_cost_option"].sum())
assert summary_test.loc["floor_constrained_protective_put", "total_transaction_cost"] == float((cost_test["transaction_cost_option"] + cost_test["transaction_cost_hedge"]).sum())

synthetic = pd.DataFrame({
    "put_ric": ["P1", "P1"],
    "put_price": [10.0, 11.0],
    "put_delta": [-0.4, -0.5],
    "put_strike": [95.0, 95.0],
    "put_expiry": pd.to_datetime(["2020-02-21", "2020-02-21"]),
    "put_maturity_days": [30, 29],
    "put_quantity": [1.0, 1.0],
    "roll_flag": [True, False],
})
assert_option_sleeve_identity(synthetic, synthetic.copy())

source_text = notebook_code_source()
assert_no_forbidden_external_imports(source_text)
assert_no_arbitrary_parameter_names(source_text)

print("All audited pure-function and structural checks passed.")

def finalize_results_columns(results):
    out = results.copy()
    out["date"] = out.index
    if "transaction_cost_futures" not in out.columns and "transaction_cost_hedge" in out.columns:
        out["transaction_cost_futures"] = out["transaction_cost_hedge"]
    if "futures_position" not in out.columns and {"hedge_beta_executed", "nav_floor_constrained_protective_put", "underlying_price"}.issubset(out.columns):
        out["futures_position"] = out["hedge_beta_executed"] * out["nav_floor_constrained_protective_put"] / out["underlying_price"]

    required_order = [
        "date",
        "underlying_price",
        "underlying_return",
        "nav_underlying_only",
        "ret_underlying_only",
        "nav_protective_put_base",
        "ret_protective_put_base",
        "nav_floor_constrained_protective_put",
        "ret_floor_constrained_protective_put",
        "put_ric",
        "put_price",
        "put_bid",
        "put_ask",
        "put_mid",
        "put_delta",
        "put_delta_source",
        "put_iv",
        "put_strike",
        "put_expiry",
        "put_maturity_days",
        "put_quantity",
        "roll_flag",
        "high_watermark",
        "floor_value",
        "cushion",
        "loss_scenario",
        "put_scenario_gain",
        "beta_max",
        "beta_pput_ex_hedge",
        "hedge_beta_effective_return",
        "hedge_beta_executed",
        "hedge_beta_target",
        "hedge_beta_trade",
        "hedge_beta_order_next_close",
        "beta_total_after_hedge",
        "hedge_return",
        "hedge_pnl",
        "futures_position",
        "cash_position",
        "transaction_cost_option",
        "transaction_cost_hedge",
        "transaction_cost_futures",
        "transaction_cost_total",
        "passive_equity_return",
        "long_vol_return",
        "dynamic_equity_return",
        "floor_hedge_return",
        "cost_return",
        "attribution_residual",
    ]
    for col in required_order:
        if col not in out.columns:
            out[col] = np.nan
    extras = [col for col in out.columns if col not in required_order]
    return out[required_order + extras]


def export_results(results, performance_summary, attribution_summary, output_dir=OUTPUT_DIR):
    output_dir.mkdir(parents=True, exist_ok=True)
    results.to_csv(output_dir / "results_timeseries.csv", index=False)
    performance_summary.to_csv(output_dir / "performance_summary.csv")
    attribution_summary.to_csv(output_dir / "attribution_summary.csv")
    return {
        "results_timeseries": output_dir / "results_timeseries.csv",
        "performance_summary": output_dir / "performance_summary.csv",
        "attribution_summary": output_dir / "attribution_summary.csv",
    }

if CONFIG["run_backtest"]:
    results, performance_summary, attribution_summary = run_full_backtest(CONFIG, FIELD_MAP)

    display(performance_summary)
    display(attribution_summary)
    plot_required_diagnostics(results)
    exported_paths = export_results(results, performance_summary, attribution_summary, OUTPUT_DIR)
    print("Exported:")
    for key, path in exported_paths.items():
        print(f"- {key}: {path}")
else:
    print("CONFIG['run_backtest'] is False. Set it to True in an LSEG-enabled environment to run the full workflow.")

if CONFIG.get("close_lseg_session_at_end", False) and CONFIG["run_backtest"]:
    close_lseg_session()