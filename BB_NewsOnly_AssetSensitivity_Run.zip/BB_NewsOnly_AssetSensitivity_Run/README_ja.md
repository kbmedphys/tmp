# 原BB・change-only × アップロード16セクター

## 実行
展開した本フォルダを作業ディレクトリとし、main.ipynb を上から実行してください。
全PythonコードはNotebook内にあり、ネットワーク・別の.pyファイルは不要です。
必要に応じて `uv add numpy pandas scipy matplotlib ipykernel nbformat nbclient nbconvert tabulate`。

## 入力
`inputs/assets_monthly.csv` は受領した原本を改変せず同梱しました。
BB入力、既存係数の検証用ファイル、GDP固定ビンテージも同梱しています。
入力の価格・配当・通貨・分割調整の詳細は未確認です。

## TOPIX_TRの注意
2015年1月、2026年3月・4月に極端な水準差があります。原因は特定していません。
月次絶対変化50%超の月は要確認としてフラグを付け、該当月を含む12カ月窓を比較パネルから除きます。
元の水準の10倍補正・ゼロリターン補完は一切していません。
主結果：16セクター単独収益率・月次リバランスEQW対比（2011Q1～2023Q2、50四半期）。
参考TOPIX対比：2015Q1～Q4を除いた46四半期。ベンチマークの正確性が保証されたわけではありません。
修正済みTOPIXと指数メタデータが入手できたら原本を別保存し、CSVを差し替えて再実行してください。

## 結果
- results_view.html：主要結果と図
- results/asset_sensitivity_main.csv：6ニュース×16セクター×3評価基準
- results/sector_partial_correlations_EQW.csv：全16セクター偏相関
- results/asset_sensitivity_robustness.csv：BB仕様・標本・非重複窓
- results/asset_bootstrap_main.csv：8四半期ブロック999回
- results/asset_conditional_returns.csv：±1zの記述的な局面平均
- audit/asset_data_alerts.csv：元データの異常値監査
- audit/validation_checks.csv：計算検証

## 統計・解釈
同時12カ月リターンとインフレ要因ニュースの感応度であり、売買バックテストではありません。
ニュース = BB要因寄与の4期平均の4期差。投資式でsurpriseを使わず、BB内部の期待・catch-upは維持。
HAC・bootstrapはいずれもマクロ推計値と価格定義を条件とする不確実性だけを扱います。
全Pythonコードを再実行して結果を再現できます。実行時の入力ハッシュを毎回保存します。
