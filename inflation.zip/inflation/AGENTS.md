# Project Rules: inflation

このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。
このプロジェクトの Prefer explicit python path は 
- envs/base/.venv/bin/python

---

## Source of truth
- legacy/ARCHITECTURE.md : 実装仕様書
- legacy/CODEX_TASKS.md : Codexタスク定義
- legacy/MODEL_SPEC.md : モデル仕様
- legacy/README.md：README
- legacy/TEST_PLAN.md：テスト計画
- legacy/TRACEABILITY_MATRIX.md：要件トレーサビリティ
- legacy/jp_inflation_nowcast-0.1.0 : 実装ソースパッケージ
- legacy/jp_inflation_nowcast-0.1.0-py3-none-any.whl : Python Wheel
  
---

## 0. 目的
本プロジェクトはlegacy配下の実装プログラムおよび各ファイルの内容に基づきプログラムの内容を理解することが目的。１つの jupyter notebook で実行と結果の確認ができるようにする。
本実装プログラムで用いられたインフレ推定手法について学術的な発表を行うため、各処理の入力と出力はユーザが動かしながら確認・理解促進ができるよう留意し実装を行う。

---
## 1. 進め方
### Phase A: レビューのみ（実装禁止）
- 仕様書等ファイルを精読、プログラムを確認する。

### Phase B: 実装
実装ソースパッケージの内容をベースに、ユーザが動かしながら各処理の入出力を確認するためのjupyter notebookを実装する。

---

## 2. 注意
- 計算ロジックは legacy/jp_inflation_nowcast-0.1.0 に準拠
- 実装は１つのjupyter notebook で完結させる。
- 入出力データ要件と処理の概要はノートブックの各セルに記載