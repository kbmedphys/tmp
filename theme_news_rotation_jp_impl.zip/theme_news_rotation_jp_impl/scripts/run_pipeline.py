from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from theme_news_rotation_jp.pipeline import run_pipeline


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    args = parser.parse_args()
    outputs = run_pipeline(args.config)
    for name, df in outputs.items():
        print(f"\n[{name}] shape={df.shape}")
        print(df.head(10).to_string())


if __name__ == "__main__":
    main()
