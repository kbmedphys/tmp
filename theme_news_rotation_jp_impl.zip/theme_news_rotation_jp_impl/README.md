# Japan Equity Theme News Heat Rotation

日本株テーマバスケットを対象に、LSEG/Refinitiv ニュースを用いて以下を実装します。

1. `lseg.data` でニュース取得
2. 完成済みテーマプロファイル YAML の読み込み
3. テーマプロファイル embedding
4. ニュース embedding
5. ニュースのテーマ多ラベル帰属
6. Buzz / Tone / Breadth の算出
7. 上位4テーマ等ウェイト
8. テーマ内ウェイトを構成銘柄ウェイトに展開

## 使い方

```bash
cd ~/workspace/projects/theme_news_rotation_jp
~/workspace/envs/base/.venv/bin/python scripts/run_pipeline.py --config configs/config.yaml
```

または `main.ipynb` を上から順に実行してください。

## 重要

- `configs/theme_profiles.yaml` に完成済みテーマプロファイルを配置してください。
- LSEG が使えない環境では `config.yaml` の `news.mode: mock` または `offline` を使います。
- 実運用では `news.mode: lseg` にします。
- すべての中間成果物は `data/interim/` と `data/processed/` に保存されます。
- すべての確認用出力は `outputs/tables/` と `outputs/figures/` に保存されます。

## 依存関係

必要に応じて、base 環境で以下を追加してください。

```bash
cd ~/workspace/envs/base
uv add pandas numpy pyarrow pyyaml beautifulsoup4 sentence-transformers scikit-learn matplotlib lseg-data
```

`sentence-transformers` がない場合、`TfidfVectorizer` にフォールバックします。ただし本番検証では多言語 SentenceTransformer を推奨します。
