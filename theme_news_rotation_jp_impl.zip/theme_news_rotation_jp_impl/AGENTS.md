# Project Rules

- 最初に必ず `~/workspace/AGENTS.md` を読むこと。
- Python は `~/workspace/envs/base/.venv/bin/python` を使うこと。
- conda / poetry / pipenv は使わないこと。
- `pip install` を直接実行しないこと。依存が足りない場合は `~/workspace/envs/base` で `uv add` を提案すること。
- 出力は `outputs/` 以下に保存すること。
- API 取得処理と後続処理は分離し、保存済み parquet から offline rerun できるようにすること。
- 説明は日本語で行うこと。
