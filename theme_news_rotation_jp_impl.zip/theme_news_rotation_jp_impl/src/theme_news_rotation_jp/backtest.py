from __future__ import annotations

import numpy as np
import pandas as pd


def compute_strategy_returns(theme_weights: pd.DataFrame, theme_returns: pd.DataFrame) -> pd.DataFrame:
    w = theme_weights.copy()
    r = theme_returns.copy()
    w["date"] = pd.to_datetime(w["date"])
    r["date"] = pd.to_datetime(r["date"])
    merged = r.merge(w[["date", "theme_id", "theme_weight"]], on=["date", "theme_id"], how="left")
    merged = merged.sort_values(["theme_id", "date"])
    merged["theme_weight"] = merged.groupby("theme_id")["theme_weight"].ffill().fillna(0.0)
    merged["theme_weight_lag"] = merged.groupby("theme_id")["theme_weight"].shift(1).fillna(0.0)
    merged["contribution"] = merged["theme_weight_lag"] * merged["return"]
    return merged.groupby("date", as_index=False).agg(
        strategy_return=("contribution", "sum"),
        gross_exposure=("theme_weight_lag", "sum"),
    )


def summarize_returns(port: pd.DataFrame, ret_col: str = "strategy_return") -> pd.DataFrame:
    if port.empty or ret_col not in port:
        return pd.DataFrame()
    r = port[ret_col].fillna(0.0)
    nav = (1 + r).cumprod()
    years = len(r) / 252
    cagr = nav.iloc[-1] ** (1 / years) - 1 if years > 0 and nav.iloc[-1] > 0 else np.nan
    annvol = r.std(ddof=0) * np.sqrt(252)
    sharpe = cagr / annvol if annvol and annvol > 0 else np.nan
    dd = nav / nav.cummax() - 1
    return pd.DataFrame([{
        "CAGR": cagr,
        "AnnVol": annvol,
        "Sharpe": sharpe,
        "MaxDD": dd.min(),
        "Days": len(r),
    }])
