from __future__ import annotations


def simple_tone_multilingual(text: str, terms: dict) -> float:
    if not isinstance(text, str):
        return 0.0
    lower = text.lower()
    pos = 0
    neg = 0
    for w in terms.get("positive_terms_ja", []):
        if w and w in text:
            pos += 1
    for w in terms.get("negative_terms_ja", []):
        if w and w in text:
            neg += 1
    for w in terms.get("positive_terms_en", []):
        if w and w.lower() in lower:
            pos += 1
    for w in terms.get("negative_terms_en", []):
        if w and w.lower() in lower:
            neg += 1
    return (pos - neg) / (pos + neg + 1.0)
