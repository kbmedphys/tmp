from __future__ import annotations

from pathlib import Path
from typing import Any
import yaml


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_yaml(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return data or {}


def save_yaml(data: dict[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)


def resolve_path(path: str | Path, base: Path | None = None) -> Path:
    p = Path(path)
    if p.is_absolute():
        return p
    return (base or project_root()) / p


def load_config(config_path: str | Path = "configs/config.yaml") -> dict[str, Any]:
    cfg_path = resolve_path(config_path)
    cfg = load_yaml(cfg_path)
    cfg["_config_path"] = str(cfg_path)
    cfg["_project_root"] = str(project_root())
    return cfg


def ensure_dirs(cfg: dict[str, Any]) -> None:
    root = Path(cfg["_project_root"])
    for key, value in cfg.get("paths", {}).items():
        if key.endswith("dir"):
            resolve_path(value, root).mkdir(parents=True, exist_ok=True)
