from __future__ import annotations

import numpy as np
import pandas as pd


def cross_sectional_zscore(df: pd.DataFrame, value_col: str, date_col: str = "date") -> pd.Series:
    def z(x: pd.Series) -> pd.Series:
        std = x.std(ddof=0)
        if std == 0 or np.isnan(std):
            return x * 0.0
        return (x - x.mean()) / std
    return df.groupby(date_col)[value_col].transform(z)


def build_daily_theme_features(news_df: pd.DataFrame, links_df: pd.DataFrame, theme_df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    if links_df.empty:
        raise ValueError("No news-theme links. Lower threshold or inspect theme profiles/news text.")
    work = links_df.merge(news_df[["story_id", "clean_text", "tone", "related_rics"]], on="story_id", how="left")
    work["date"] = pd.to_datetime(work["date_jst"])

    g = work.groupby(["date", "theme_id"])
    feat = g.agg(
        mentions=("story_id", "nunique"),
        weighted_mentions=("rel_score", "sum"),
        avg_rel_score=("rel_score", "mean"),
    ).reset_index()

    work["weighted_tone"] = work["rel_score"] * work["tone"].fillna(0.0)
    tone = work.groupby(["date", "theme_id"]).agg(
        weighted_tone_sum=("weighted_tone", "sum"),
        rel_sum=("rel_score", "sum"),
    ).reset_index()
    tone["tone_raw"] = tone["weighted_tone_sum"] / (tone["rel_sum"] + 1e-12)
    feat = feat.merge(tone[["date", "theme_id", "tone_raw"]], on=["date", "theme_id"], how="left")

    # Full date-theme panel.
    all_dates = pd.date_range(feat["date"].min(), feat["date"].max(), freq="D")
    all_themes = theme_df["theme_id"].tolist()
    panel = pd.MultiIndex.from_product([all_dates, all_themes], names=["date", "theme_id"]).to_frame(index=False)
    feat = panel.merge(feat, on=["date", "theme_id"], how="left")
    for col in ["mentions", "weighted_mentions", "avg_rel_score", "tone_raw"]:
        feat[col] = feat[col].fillna(0.0)

    lookback = int(cfg.get("features", {}).get("buzz_lookback_days", 40))
    minp = int(cfg.get("features", {}).get("min_periods", 5))
    feat = feat.sort_values(["theme_id", "date"])
    feat["wm_log"] = np.log1p(feat["weighted_mentions"])
    feat["wm_log_ma"] = feat.groupby("theme_id")["wm_log"].transform(lambda s: s.shift(1).rolling(lookback, min_periods=minp).mean())
    feat["buzz_raw"] = feat["wm_log"] - feat["wm_log_ma"].fillna(0.0)

    theme_const = {r["theme_id"]: r.get("top_constituents", []) for _, r in theme_df.iterrows()}
    breadth_rows = []
    for (date, theme_id), sub in work.groupby(["date", "theme_id"]):
        mentioned = set()
        for xs in sub["matched_rics"] if "matched_rics" in sub else []:
            if isinstance(xs, list):
                mentioned.update(xs)
        for xs in sub["related_rics"]:
            if isinstance(xs, list):
                mentioned.update(xs)
        const = theme_const.get(theme_id, []) or []
        total_n = len(const)
        hit_n = 0
        breadth_w = 0.0
        for c in const:
            ric = c.get("ric")
            if ric in mentioned:
                hit_n += 1
                breadth_w += float(c.get("weight") or 0.0)
        breadth_rows.append({
            "date": date,
            "theme_id": theme_id,
            "breadth_weight_raw": breadth_w,
            "breadth_count_raw": hit_n / total_n if total_n else 0.0,
        })
    bdf = pd.DataFrame(breadth_rows)
    feat = feat.merge(bdf, on=["date", "theme_id"], how="left")
    feat["breadth_weight_raw"] = feat["breadth_weight_raw"].fillna(0.0)
    feat["breadth_count_raw"] = feat["breadth_count_raw"].fillna(0.0)

    feat["buzz"] = cross_sectional_zscore(feat, "buzz_raw")
    feat["tone"] = cross_sectional_zscore(feat, "tone_raw")
    feat["breadth"] = cross_sectional_zscore(feat, "breadth_weight_raw")
    sw = cfg.get("features", {}).get("score_weights", {"buzz": 0.35, "tone": 0.25, "breadth": 0.40})
    feat["theme_score"] = sw["buzz"] * feat["buzz"] + sw["tone"] * feat["tone"] + sw["breadth"] * feat["breadth"]
    return feat
