from __future__ import annotations

import re
from bs4 import BeautifulSoup


def strip_html(text: str | None) -> str:
    if not isinstance(text, str):
        return ""
    return BeautifulSoup(text, "html.parser").get_text(" ")


def normalize_whitespace(text: str | None) -> str:
    if not isinstance(text, str):
        return ""
    return re.sub(r"\s+", " ", text).strip()


def clean_news_text(headline: str | None, story_text: str | None) -> str:
    h = normalize_whitespace(strip_html(headline))
    s = normalize_whitespace(strip_html(story_text))
    if h and s:
        return f"{h}. {s}"
    return h or s
