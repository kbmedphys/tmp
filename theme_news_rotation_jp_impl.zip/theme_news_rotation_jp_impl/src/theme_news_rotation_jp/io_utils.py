from __future__ import annotations
from pathlib import Path
import pandas as pd


def write_table(df: pd.DataFrame, path: str | Path, index: bool = False) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        df.to_parquet(path, index=index)
        return path
    except Exception as e:
        fallback = path.with_suffix(".pkl")
        df.to_pickle(fallback)
        csv_path = path.with_suffix(".csv")
        try:
            df.to_csv(csv_path, index=index, encoding="utf-8-sig")
        except Exception:
            pass
        print(f"[WARN] parquet write failed for {path}. Saved pickle fallback: {fallback}. reason={e}")
        return fallback


def read_table(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() in {".pkl", ".pickle"}:
        return pd.read_pickle(path)
    try:
        return pd.read_parquet(path)
    except Exception:
        pkl = path.with_suffix(".pkl")
        if pkl.exists():
            return pd.read_pickle(pkl)
        raise
