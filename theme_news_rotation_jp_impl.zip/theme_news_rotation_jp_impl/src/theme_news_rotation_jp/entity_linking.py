from __future__ import annotations


def detect_entities(text: str, rics: list[str], names_en: list[str], names_ja: list[str]) -> dict[str, list[str]]:
    if not isinstance(text, str):
        text = ""
    lower = text.lower()
    matched_rics, matched_en, matched_ja = [], [], []
    for ric in rics:
        if ric and ric in text:
            matched_rics.append(ric)
    for name in names_en:
        if name and name.lower() in lower:
            matched_en.append(name)
    for name in names_ja:
        if name and name in text:
            matched_ja.append(name)
    return {
        "matched_rics": sorted(set(matched_rics)),
        "matched_names_en": sorted(set(matched_en)),
        "matched_names_ja": sorted(set(matched_ja)),
    }


def entity_overlap_score(news_rics: list[str], theme_rics: list[str], text_matches: dict[str, list[str]]) -> float:
    news_set = set(news_rics or [])
    theme_set = set(theme_rics or [])
    if news_set & theme_set:
        return 1.0
    if text_matches.get("matched_rics") or text_matches.get("matched_names_en") or text_matches.get("matched_names_ja"):
        return 1.0
    return 0.0
