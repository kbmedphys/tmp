from __future__ import annotations

from pathlib import Path
from typing import Any
import pandas as pd


def open_lseg_session():
    import lseg.data as ld
    ld.open_session()
    return ld


def _pick_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    lower_map = {str(c).lower(): c for c in df.columns}
    for cand in candidates:
        if cand in df.columns:
            return cand
        if cand.lower() in lower_map:
            return lower_map[cand.lower()]
    return None


def normalize_headlines_df(df: pd.DataFrame, query_name: str) -> pd.DataFrame:
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=[
            "story_id", "headline", "timestamp_utc", "source", "language", "topics", "related_rics", "query_name", "retrieved_at_utc"
        ])
    out = df.copy()
    story_col = _pick_col(out, ["storyId", "story_id", "StoryId", "Story ID", "storyID"])
    headline_col = _pick_col(out, ["headline", "Headline", "text", "Text", "storyHeadline"])
    time_col = _pick_col(out, ["versionCreated", "timestamp", "Date", "date", "Time", "created", "firstCreated"])
    source_col = _pick_col(out, ["source", "Source", "provider"])
    lang_col = _pick_col(out, ["language", "Language"])
    topics_col = _pick_col(out, ["topics", "Topics", "topic", "Topic"])
    rics_col = _pick_col(out, ["related_rics", "subjects", "RIC", "rics", "Related RICs"])
    if story_col is None:
        raise ValueError(f"Cannot find story id column. columns={list(out.columns)}")
    norm = pd.DataFrame()
    norm["story_id"] = out[story_col].astype(str)
    norm["headline"] = out[headline_col].astype(str) if headline_col else ""
    norm["timestamp_utc"] = pd.to_datetime(out[time_col], errors="coerce", utc=True) if time_col else pd.NaT
    norm["source"] = out[source_col].astype(str) if source_col else ""
    norm["language"] = out[lang_col].astype(str) if lang_col else ""
    norm["topics"] = out[topics_col].apply(_safe_list) if topics_col else [[] for _ in range(len(out))]
    norm["related_rics"] = out[rics_col].apply(_safe_list) if rics_col else [[] for _ in range(len(out))]
    norm["query_name"] = query_name
    norm["retrieved_at_utc"] = pd.Timestamp.now(tz="UTC")
    return norm


def _safe_list(x: Any) -> list[str]:
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return []
    if isinstance(x, list):
        return [str(v) for v in x if v]
    if isinstance(x, tuple) or isinstance(x, set):
        return [str(v) for v in x if v]
    s = str(x)
    if not s:
        return []
    for sep in [",", ";", " "]:
        if sep in s:
            vals = [v.strip() for v in s.split(sep) if v.strip()]
            if vals:
                return vals
    return [s]


def fetch_headlines(ld, query: str, start: str, end: str, count: int) -> pd.DataFrame:
    return ld.news.get_headlines(query=query, start=start, end=end, count=count)


def fetch_story_text(ld, story_id: str) -> str:
    try:
        return ld.news.get_story(story_id, format=ld.news.Format.TEXT) or ""
    except Exception:
        return ""


def fetch_lseg_news(cfg: dict, queries: dict, theme_profiles: pd.DataFrame) -> pd.DataFrame:
    ld = open_lseg_session()
    news_cfg = cfg["news"]
    frames: list[pd.DataFrame] = []
    start, end, count = news_cfg["start"], news_cfg["end"], int(news_cfg["count_per_query"])

    # Broad / explicitly configured queries.
    for qname, qdef in (queries.get("news_queries") or {}).items():
        if qname in {"settings", "by_constituent"}:
            continue
        if isinstance(qdef, dict) and qdef.get("query"):
            raw = fetch_headlines(ld, qdef["query"], start, end, count)
            frames.append(normalize_headlines_df(raw, qname))

    # RIC based queries.
    templates = ((queries.get("news_queries") or {}).get("by_constituent") or {})
    template = templates.get("template_en") or "R:{ric} AND Language:LEN AND Source:RTRS"
    rics = sorted({r for vals in theme_profiles["entity_rics"] for r in vals})
    for ric in rics:
        raw = fetch_headlines(ld, template.format(ric=ric), start, end, count)
        tmp = normalize_headlines_df(raw, f"ric_{ric}")
        tmp["related_rics"] = tmp["related_rics"].apply(lambda xs: sorted(set(xs + [ric])))
        frames.append(tmp)

    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    if news_cfg.get("deduplicate_by_story_id", True):
        df = df.drop_duplicates("story_id")
    if news_cfg.get("fetch_stories", True):
        df["story_text"] = [fetch_story_text(ld, sid) for sid in df["story_id"].astype(str)]
    else:
        df["story_text"] = ""
    return df


def load_offline_news(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    return pd.read_parquet(path)


def make_mock_news(theme_profiles: pd.DataFrame) -> pd.DataFrame:
    rows = []
    base = pd.Timestamp("2026-04-01", tz="UTC")
    for i, row in theme_profiles.head(8).iterrows():
        rics = row.get("entity_rics", [])[:3]
        names_ja = row.get("entity_names_ja", [])[:3]
        theme_ja = row.get("theme_name_ja") or row.get("theme_name_en")
        text = f"{theme_ja} 関連で受注増と設備投資拡大のニュース。" + " ".join(names_ja)
        rows.append({
            "story_id": f"MOCK{i:04d}",
            "headline": f"{theme_ja} 関連銘柄に好材料",
            "story_text": text,
            "timestamp_utc": base + pd.Timedelta(days=i),
            "source": "MOCK",
            "language": "JA",
            "topics": [],
            "related_rics": rics,
            "query_name": "mock",
            "retrieved_at_utc": pd.Timestamp.now(tz="UTC"),
        })
    return pd.DataFrame(rows)
