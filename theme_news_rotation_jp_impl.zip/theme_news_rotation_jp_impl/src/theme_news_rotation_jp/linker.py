from __future__ import annotations

import numpy as np
import pandas as pd
from .entity_linking import detect_entities, entity_overlap_score


def keyword_score(text: str, terms_en: list[str], terms_ja: list[str]) -> tuple[float, list[str], list[str]]:
    if not isinstance(text, str):
        text = ""
    lower = text.lower()
    hits_en, hits_ja = [], []
    for kw in terms_en or []:
        if kw and kw.lower() in lower:
            hits_en.append(kw)
    for kw in terms_ja or []:
        if kw and kw in text:
            hits_ja.append(kw)
    n_terms = len(terms_en or []) + len(terms_ja or [])
    hits = len(hits_en) + len(hits_ja)
    score = 0.0 if n_terms == 0 else min(1.0, hits / max(3.0, n_terms ** 0.5))
    return score, hits_en, hits_ja


def weights_for_theme(theme_type: str, cfg: dict) -> dict[str, float]:
    lw = cfg.get("linking", {})
    return (lw.get("weights_by_theme_type", {}) or {}).get(theme_type) or lw.get("default_weights") or {
        "embedding": 0.45, "entity": 0.35, "keyword": 0.20
    }


def build_news_theme_links(news_df: pd.DataFrame, theme_df: pd.DataFrame, sim: np.ndarray, cfg: dict) -> pd.DataFrame:
    rows = []
    threshold = float(cfg.get("linking", {}).get("threshold", 0.40))
    news_reset = news_df.reset_index(drop=True)
    theme_reset = theme_df.reset_index(drop=True)
    for i, nrow in news_reset.iterrows():
        text = nrow.get("clean_text", "")
        news_rics = nrow.get("related_rics") or []
        if not isinstance(news_rics, list):
            news_rics = []
        for j, trow in theme_reset.iterrows():
            emb_raw = float(sim[i, j])
            # cosine from normalized vectors: [-1, 1] for ST, [0,1] for TF-IDF. Normalize defensively.
            emb_score = max(0.0, min(1.0, (emb_raw + 1.0) / 2.0 if emb_raw < 0 else emb_raw))
            matches = detect_entities(text, trow.get("entity_rics", []), trow.get("entity_names_en", []), trow.get("entity_names_ja", []))
            ent_score = entity_overlap_score(news_rics, trow.get("entity_rics", []), matches)
            kw_score, hits_en, hits_ja = keyword_score(text, trow.get("keyword_match_terms_en", []), trow.get("keyword_match_terms_ja", []))
            w = weights_for_theme(trow.get("theme_type", ""), cfg)
            rel = float(w["embedding"] * emb_score + w["entity"] * ent_score + w["keyword"] * kw_score)
            if rel >= threshold:
                matched_rics = sorted(set((news_rics or [])) & set(trow.get("entity_rics", [])) | set(matches.get("matched_rics", [])))
                rows.append({
                    "story_id": nrow["story_id"],
                    "timestamp_utc": nrow.get("timestamp_utc"),
                    "timestamp_jst": nrow.get("timestamp_jst"),
                    "date_jst": nrow.get("date_jst"),
                    "theme_id": trow["theme_id"],
                    "rel_score": rel,
                    "embedding_score": emb_score,
                    "entity_score": ent_score,
                    "keyword_score": kw_score,
                    "headline": nrow.get("headline", ""),
                    "matched_rics": matched_rics,
                    "matched_keywords_en": hits_en,
                    "matched_keywords_ja": hits_ja,
                })
    return pd.DataFrame(rows)
