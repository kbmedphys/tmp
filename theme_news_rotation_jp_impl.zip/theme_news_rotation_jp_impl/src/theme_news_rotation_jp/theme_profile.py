from __future__ import annotations

from typing import Any
import pandas as pd


def _as_list(x: Any) -> list:
    if x is None:
        return []
    if isinstance(x, list):
        return x
    return [x]


def _top_constituents(theme: dict[str, Any], max_n: int = 30, cum_weight: float = 0.80) -> list[dict[str, Any]]:
    const = list(theme.get("top_constituents") or theme.get("constituents") or [])
    const = sorted(const, key=lambda c: float(c.get("weight") or 0.0), reverse=True)
    selected = []
    total = 0.0
    for c in const:
        if len(selected) >= max_n:
            break
        selected.append(c)
        total += float(c.get("weight") or 0.0)
        if total >= cum_weight and len(selected) > 0:
            break
    return selected


def build_profile_text_from_theme(theme: dict[str, Any]) -> dict[str, Any]:
    # 完成済み profile に embedding_text がある場合は尊重しつつ、不足時は合成する。
    theme_id = theme["theme_id"]
    theme_name_en = theme.get("theme_name_en", "")
    theme_name_ja = theme.get("theme_name_ja", "")
    theme_type = theme.get("theme_type", "")

    parts = []
    for key in [
        "theme_name_en", "theme_name_ja", "description_en", "description_ja",
        "profile_summary_en", "profile_summary_ja", "profile_text_en", "profile_text_ja",
    ]:
        v = theme.get(key)
        if isinstance(v, str) and v.strip():
            parts.append(v.strip())

    for key in [
        "revenue_drivers_en", "revenue_drivers_ja", "catalysts_en", "catalysts_ja",
        "positive_events_en", "positive_events_ja", "negative_events_en", "negative_events_ja",
        "keyword_match_terms_en", "keyword_match_terms_ja",
    ]:
        vals = _as_list(theme.get(key))
        if vals:
            parts.append("; ".join(str(v) for v in vals if v))

    const_lines = []
    for c in _top_constituents(theme):
        const_lines.append(
            " | ".join([
                str(c.get("company_name_en", "")),
                str(c.get("company_name_ja", "")),
                str(c.get("ric", "")),
                str(c.get("company_description_en", "")),
                str(c.get("gics_sector", "")),
                str(c.get("gics_industry", "")),
                str(c.get("trbc_industry", "")),
            ])
        )
    if const_lines:
        parts.append("\n".join(const_lines))

    embedding_text = theme.get("embedding_text") or "\n".join(parts)

    ent = theme.get("entity_linking_terms") or {}
    rics = _as_list(ent.get("rics"))
    names_en = _as_list(ent.get("company_names_en"))
    names_ja = _as_list(ent.get("company_names_ja"))

    if not rics or not names_en or not names_ja:
        const_all = theme.get("top_constituents") or theme.get("constituents") or []
        rics = rics or [c.get("ric") for c in const_all if c.get("ric")]
        names_en = names_en or [c.get("company_name_en") for c in const_all if c.get("company_name_en")]
        names_ja = names_ja or [c.get("company_name_ja") for c in const_all if c.get("company_name_ja")]

    return {
        "theme_id": theme_id,
        "theme_name_en": theme_name_en,
        "theme_name_ja": theme_name_ja,
        "theme_type": theme_type,
        "embedding_text": embedding_text,
        "keyword_match_terms_en": _as_list(theme.get("keyword_match_terms_en")) or _as_list(theme.get("catalysts_en")),
        "keyword_match_terms_ja": _as_list(theme.get("keyword_match_terms_ja")) or _as_list(theme.get("catalysts_ja")),
        "positive_events_en": _as_list(theme.get("positive_events_en")),
        "positive_events_ja": _as_list(theme.get("positive_events_ja")),
        "negative_events_en": _as_list(theme.get("negative_events_en")),
        "negative_events_ja": _as_list(theme.get("negative_events_ja")),
        "entity_rics": [str(x) for x in rics if x],
        "entity_names_en": [str(x) for x in names_en if x],
        "entity_names_ja": [str(x) for x in names_ja if x],
        "top_constituents": _top_constituents(theme, max_n=999, cum_weight=2.0),
    }


def load_theme_profiles(theme_yaml: dict[str, Any]) -> pd.DataFrame:
    themes = theme_yaml.get("themes") or []
    if not themes:
        raise ValueError("theme_profiles.yaml has no themes. Put completed theme profiles under `themes:`.")
    rows = [build_profile_text_from_theme(t) for t in themes]
    return pd.DataFrame(rows)
