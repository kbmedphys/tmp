from __future__ import annotations

from dataclasses import dataclass
import numpy as np


@dataclass
class EmbeddingResult:
    backend: str
    vectors: np.ndarray
    vectorizer: object | None = None
    model: object | None = None


def fit_transform_embeddings(texts: list[str], cfg: dict) -> EmbeddingResult:
    backend = cfg.get("embedding", {}).get("backend", "auto")
    model_name = cfg.get("embedding", {}).get("model_name", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
    batch_size = int(cfg.get("embedding", {}).get("batch_size", 64))
    if backend in {"auto", "sentence_transformers"}:
        try:
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer(model_name)
            vec = model.encode(texts, batch_size=batch_size, normalize_embeddings=True, show_progress_bar=True)
            return EmbeddingResult("sentence_transformers", np.asarray(vec, dtype=float), model=model)
        except Exception as e:
            if backend == "sentence_transformers":
                raise
            print(f"[WARN] sentence-transformers unavailable; falling back to TF-IDF. reason={e}")
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.preprocessing import normalize
    vectorizer = TfidfVectorizer(max_features=50000, ngram_range=(1, 2))
    mat = vectorizer.fit_transform(texts)
    vec = normalize(mat).toarray()
    return EmbeddingResult("tfidf", vec, vectorizer=vectorizer)


def transform_embeddings(texts: list[str], fitted: EmbeddingResult, cfg: dict) -> np.ndarray:
    if fitted.backend == "sentence_transformers":
        batch_size = int(cfg.get("embedding", {}).get("batch_size", 64))
        return np.asarray(fitted.model.encode(texts, batch_size=batch_size, normalize_embeddings=True, show_progress_bar=True), dtype=float)
    from sklearn.preprocessing import normalize
    return normalize(fitted.vectorizer.transform(texts)).toarray()


def cosine_similarity_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return np.asarray(a @ b.T, dtype=float)
