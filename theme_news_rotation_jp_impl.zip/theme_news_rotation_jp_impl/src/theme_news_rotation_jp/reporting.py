from __future__ import annotations

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt


def save_table(df: pd.DataFrame, path: str | Path, n: int | None = None) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    out = df.head(n) if n else df
    out.to_csv(path, index=False, encoding="utf-8-sig")


def plot_theme_scores(features: pd.DataFrame, path: str | Path) -> None:
    if features.empty:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pivot = features.pivot(index="date", columns="theme_id", values="theme_score")
    ax = pivot.plot(figsize=(12, 6), legend=False)
    ax.set_title("Theme Score Timeseries")
    ax.set_xlabel("Date")
    ax.set_ylabel("ThemeScore")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()


def plot_strategy_nav(port: pd.DataFrame, path: str | Path) -> None:
    if port.empty or "strategy_return" not in port:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    nav = (1 + port["strategy_return"].fillna(0.0)).cumprod()
    ax = nav.plot(figsize=(10, 5))
    ax.set_title("Strategy NAV")
    ax.set_xlabel("Date")
    ax.set_ylabel("NAV")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()
