from __future__ import annotations

from pathlib import Path
import pandas as pd

from .config import load_config, load_yaml, resolve_path, ensure_dirs
from .theme_profile import load_theme_profiles
from .news_loader import fetch_lseg_news, load_offline_news, make_mock_news
from .text_cleaning import clean_news_text
from .sentiment import simple_tone_multilingual
from .embeddings import fit_transform_embeddings, transform_embeddings, cosine_similarity_matrix
from .linker import build_news_theme_links
from .features import build_daily_theme_features
from .portfolio import make_rebalance_scores, select_top_themes, expand_to_constituent_weights
from .reporting import save_table, plot_theme_scores
from .io_utils import write_table


def _p(cfg: dict, key: str) -> Path:
    return resolve_path(cfg["paths"][key], Path(cfg["_project_root"]))


def run_pipeline(config_path: str | Path = "configs/config.yaml") -> dict[str, pd.DataFrame]:
    cfg = load_config(config_path)
    ensure_dirs(cfg)
    root = Path(cfg["_project_root"])

    theme_yaml = load_yaml(resolve_path(cfg["paths"]["theme_profiles"], root))
    theme_df = load_theme_profiles(theme_yaml)
    theme_df; write_table(theme_df, _p(cfg, "interim_dir") / "theme_profiles.parquet", index=False)

    mode = cfg.get("news", {}).get("mode", "mock")
    if mode == "lseg":
        queries = load_yaml(root / "configs" / "lseg_queries.yaml")
        news_df = fetch_lseg_news(cfg, queries, theme_df)
    elif mode == "offline":
        news_df = load_offline_news(resolve_path(cfg["news"]["offline_news_path"], root))
    else:
        news_df = make_mock_news(theme_df)

    if news_df.empty:
        raise ValueError("No news data loaded.")
    news_df["timestamp_utc"] = pd.to_datetime(news_df["timestamp_utc"], utc=True, errors="coerce")
    news_df["timestamp_jst"] = news_df["timestamp_utc"].dt.tz_convert("Asia/Tokyo")
    news_df["date_jst"] = news_df["timestamp_jst"].dt.date.astype(str)
    news_df["clean_text"] = [clean_news_text(h, s) for h, s in zip(news_df.get("headline", ""), news_df.get("story_text", ""))]
    if "related_rics" not in news_df:
        news_df["related_rics"] = [[] for _ in range(len(news_df))]

    terms = load_yaml(root / "configs" / "sentiment_terms.yaml")
    news_df["tone"] = news_df["clean_text"].apply(lambda x: simple_tone_multilingual(x, terms))
    write_table(news_df, _p(cfg, "interim_dir") / "news_clean.parquet", index=False)

    # Fit text vectorizer/model on both theme and news text to keep TF-IDF fallback coherent.
    theme_texts = theme_df["embedding_text"].fillna("").astype(str).tolist()
    news_texts = news_df["clean_text"].fillna("").astype(str).tolist()
    fitted = fit_transform_embeddings(theme_texts + news_texts, cfg)
    theme_emb = fitted.vectors[:len(theme_texts)]
    news_emb = fitted.vectors[len(theme_texts):]
    pd.DataFrame({"story_id": news_df["story_id"], "embedding_backend": fitted.backend})
    write_table(pd.DataFrame({"story_id": news_df["story_id"], "embedding_backend": fitted.backend}), _p(cfg, "interim_dir") / "news_embeddings.parquet", index=False)
    sim = cosine_similarity_matrix(news_emb, theme_emb)

    links_df = build_news_theme_links(news_df, theme_df, sim, cfg)
    write_table(links_df, _p(cfg, "interim_dir") / "news_theme_links.parquet", index=False)

    features_df = build_daily_theme_features(news_df, links_df, theme_df, cfg)
    write_table(features_df, _p(cfg, "processed_dir") / "theme_news_features_daily.parquet", index=False)
    write_table(features_df, _p(cfg, "processed_dir") / "theme_scores.parquet", index=False)

    rebalance_scores = make_rebalance_scores(features_df, cfg)
    theme_weights = select_top_themes(rebalance_scores, cfg)
    write_table(theme_weights, _p(cfg, "processed_dir") / "theme_weights.parquet", index=False)

    constituent_weights = expand_to_constituent_weights(theme_weights, theme_df)
    write_table(constituent_weights, _p(cfg, "processed_dir") / "constituent_weights.parquet", index=False)

    out_tables = _p(cfg, "output_tables_dir")
    save_table(theme_df, out_tables / "step01_theme_profiles.csv")
    save_table(news_df, out_tables / "step02_news_clean_sample.csv", n=100)
    save_table(links_df.sort_values("rel_score", ascending=False), out_tables / "step03_news_theme_links_sample.csv", n=200)
    latest = features_df[features_df["date"] == features_df["date"].max()].sort_values("theme_score", ascending=False)
    save_table(latest, out_tables / "step04_theme_scores_latest.csv")
    save_table(theme_weights, out_tables / "step05_theme_weights.csv")
    save_table(constituent_weights, out_tables / "step06_constituent_weights.csv")
    plot_theme_scores(features_df, _p(cfg, "output_figures_dir") / "theme_score_timeseries.png")

    return {
        "theme_profiles": theme_df,
        "news_clean": news_df,
        "news_theme_links": links_df,
        "theme_features": features_df,
        "theme_weights": theme_weights,
        "constituent_weights": constituent_weights,
    }
