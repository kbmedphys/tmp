from __future__ import annotations

import pandas as pd


def make_rebalance_scores(features: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    freq = cfg.get("portfolio", {}).get("rebalance_frequency", "W-FRI")
    feat = features.copy()
    feat["date"] = pd.to_datetime(feat["date"])
    # 各リバランス期間の最後に利用可能なスコアを採用
    rows = []
    for theme_id, sub in feat.sort_values("date").groupby("theme_id"):
        s = sub.set_index("date").resample(freq).last().dropna(subset=["theme_score"]).reset_index()
        s["theme_id"] = theme_id
        rows.append(s)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def select_top_themes(scores: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    n_top = int(cfg.get("portfolio", {}).get("n_top_themes", 4))
    rows = []
    for date, sub in scores.groupby("date"):
        ranked = sub.sort_values("theme_score", ascending=False).head(n_top)
        if ranked.empty:
            continue
        weight = 1.0 / len(ranked)
        for rank, (_, r) in enumerate(ranked.iterrows(), start=1):
            rows.append({
                "date": date,
                "rank": rank,
                "theme_id": r["theme_id"],
                "theme_weight": weight,
                "theme_score": r["theme_score"],
            })
    return pd.DataFrame(rows)


def expand_to_constituent_weights(theme_weights: pd.DataFrame, theme_df: pd.DataFrame) -> pd.DataFrame:
    theme_map = {r["theme_id"]: r.get("top_constituents", []) for _, r in theme_df.iterrows()}
    rows = []
    for _, tw in theme_weights.iterrows():
        for c in theme_map.get(tw["theme_id"], []) or []:
            rows.append({
                "date": tw["date"],
                "theme_id": tw["theme_id"],
                "ric": c.get("ric", ""),
                "company_name_en": c.get("company_name_en", ""),
                "company_name_ja": c.get("company_name_ja", ""),
                "theme_weight": float(tw["theme_weight"]),
                "constituent_weight": float(c.get("weight") or 0.0),
                "final_weight": float(tw["theme_weight"]) * float(c.get("weight") or 0.0),
            })
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    return out.groupby(["date", "ric"], as_index=False).agg(
        final_weight=("final_weight", "sum"),
        themes=("theme_id", lambda x: ",".join(sorted(set(x)))),
        company_name_en=("company_name_en", "first"),
        company_name_ja=("company_name_ja", "first"),
    )
