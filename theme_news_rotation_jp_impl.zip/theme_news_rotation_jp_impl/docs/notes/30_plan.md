# Plan

1. theme_profiles.yaml をロードして `theme_profiles.parquet` を作成。
2. LSEG/offline/mock ニュースをロードして `news_clean.parquet` を作成。
3. Theme profile と news を embedding 化。
4. cosine similarity を計算。
5. EntityOverlap / KeywordMatch を計算し、news_theme_links を作成。
6. Buzz / Tone / Breadth / ThemeScore を作成。
7. 週次リバランス時点で上位4テーマを選択。
8. 構成銘柄ウェイトへ展開。
9. 各ステップの確認用 CSV と図を保存。
