# Assumptions

- テーマプロファイルは `configs/theme_profiles.yaml` に存在する。
- 日本株 RIC は `6501.T` のような形式で格納されている。
- LSEG API の返却列名は環境差があるため `normalize_headlines_df()` で標準化する。
- 初期 Tone は辞書ベースであり、FinBERT/専用日本語モデルは Phase 2 とする。
- 初期実装では TopicMatch は使わない。
- 上位テーマ選択は `W-FRI` を標準とする。
