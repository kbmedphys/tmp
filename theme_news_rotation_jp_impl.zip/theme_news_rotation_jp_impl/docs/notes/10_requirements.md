# Requirements

- 完成済みテーマプロファイル YAML を入力する。
- LSEG ニュース、または offline/mock ニュースを入力する。
- ニュースとテーマプロファイルの embedding 類似度を計算する。
- EntityOverlap と KeywordMatch で関連度を補正する。
- 関連度が threshold 以上のニュースをテーマへ多ラベル帰属する。
- Buzz / Tone / Breadth を日次で計算する。
- ThemeScore 上位4テーマを等ウェイトで選択する。
- テーマ内構成銘柄ウェイトへ展開する。
