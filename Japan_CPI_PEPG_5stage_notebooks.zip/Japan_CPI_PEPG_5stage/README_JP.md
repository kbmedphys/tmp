# 日本CPI予測・ナウキャスト：5段階Jupyterノートブック

## 構成

| 段階 | ノートブック | 独立検証する内容 |
|---|---|---|
| 1 | `01_japan_cpi_realtime_benchmark.ipynb` | 公表日・ビンテージ対応の二段階DFM bridge、AR、季節ナイーブ |
| 2 | `02_japan_cpi_bottom_up_institutional.ipynb` | 日本CPIの制度整合型・部門別ボトムアップ、政策オーバーレイ、集計恒等式 |
| 3 | `03_japan_cpi_crossfit_experts.ipynb` | クロスフィット済みエキスパート、固定stacking、予測フェーズ別glide path |
| 4 | `04_japan_cpi_pepg_moe.ipynb` | mirrored-sampling PEPGによる状態依存型Mixture-of-Experts |
| 5 | `05_japan_cpi_production_attribution.ipynb` | 予測パケット、Shapley改定分解、シナリオ、監査、フォールバック、モデルカード |

各ノートブックは、インポート、データ読込、合成データ生成、特徴量作成、推計、検証、出力までを内部に持ち、他ノートブックの生成ファイルに依存しません。

全ての実行セルの先頭に、以下を記載しています。

- 処理内容
- 入力データ要件
- 出力データ要件

## 最初に確認すべき点

既定値は `DATA_MODE = "demo"` です。これは、日本のCPI部門、公表ラグ、為替・原油・賃金等の指標、消費税・エネルギー補助・行政価格イベントを模した**合成データ**です。

demoモードの数値結果は、コードが最後まで動作し、制約・分解・出力が成立することを確認するためのものです。日本CPIに対する実証的な精度を示すものではありません。

実データ検証では、各ノートブックの設定セルを次のように変更してください。

```python
DATA_MODE = "local"
DATA_DIR = Path("./data_jp_cpi")
```

## localモードの入力ファイル

`data_jp_cpi/` に次の6ファイルを配置します。空のスキーマはルートの `input_schema_templates/` または各段階の出力ディレクトリにあります。

### `cpi_target.csv`

必須列：

```text
reference_month
release_date
vintage_date
headline_index
headline_mom
headline_yoy
base_year
method_version
```

推奨追加列：

```text
core_ex_fresh_mom
core_core_mom
is_first_release
seasonal_adjustment_version
```

### `cpi_components.csv`

必須列：

```text
reference_month
release_date
vintage_date
component
index
weight
base_year
method_version
```

任意列：

```text
component_mom
is_first_release
```

`component`は相互排他的でなければなりません。既定実装は次の10ブロックを想定します。

```text
fresh_food
processed_food
energy_goods
energy_services
housing_rent
durable_goods
other_goods
transport_services
medical_education_admin
other_services
```

実際の類別名称が異なる場合、ノートブック内の`STRUCTURAL_FEATURES`と部門名を一致させてください。

### `monthly_indicators.csv` / `daily_indicators.csv`

必須列：

```text
series_id
reference_date
release_date
vintage_date
value
frequency
source
method_version
```

`reference_date`は統計が表す期間、`release_date`は予測者が値を知り得た日時です。両者を同一にしないでください。

### `policy_events.csv`

必須列：

```text
event_id
announcement_date
effective_date
end_date
component
event_type
shock_size
pass_through_mean
pass_through_sd
lag_months
implementation_probability
analyst_confidence
description
```

推奨追加列：

```text
effect_profile
```

`effect_profile`は、税率・行政価格の一回限りの指数段差なら`one_shot`、補助金等の継続的効果なら`flow`を指定します。

### `analyst_forecasts.csv`

必須列：

```text
target_month
vintage_date
component
forecast_mom
forecast_sd
analyst_id
confidence
```

アナリスト判断は最終予測の自由な上書きではなく、標準偏差と確信度を持つ予測エキスパートとして投入します。

## 日本の推奨データソース

- 総務省統計局：全国CPI、東京都区部CPI、品目・類別指数、ウェイト、基準改定資料
- e-Stat / 統計ダッシュボードAPI：政府統計の機械取得
- 日本銀行：企業物価指数、輸入物価指数、実効為替レート
- 厚生労働省：毎月勤労統計
- 内閣府：消費動向調査、消費者態度指数、物価見通し
- 経済産業省：鉱工業指数、商業動態、サービス産業動向
- 資源エネルギー庁：石油製品価格、電気・ガス価格激変緩和措置
- 気象庁：気温、降水、災害・季節要因
- 民間データ：募集家賃、POS、オンライン価格、航空・宿泊価格

公式CPIページ：
`https://www.stat.go.jp/data/cpi/`

統計ダッシュボードAPI：
`https://dashboard.e-stat.go.jp/static/api`

e-Stat API：
`https://www.e-stat.go.jp/api/`

## 基準改定

ノートブックは`base_year`と`method_version`を保持し、対象月の方法バージョンに対応する部門ウェイトを選びます。基準改定時には次の作業が必要です。

1. 旧・新基準の品目対応表を作成する。
2. 廃止・新設品目、品質調整、価格収集方法の変更をイベントまたは方法状態として記録する。
3. 旧・新基準の最終指数を単純に一つの回帰へ投入せず、方法ダミー、再推計、または共通分類への再集計を行う。
4. 季節調整系列の年次改定をビンテージとして保存する。

## 各段階の主な出力

### 第1段階

- `stage1_forecasts.csv`
- `stage1_metrics.csv`
- `stage1_audit.csv`
- `realtime_feature_store.parquet`またはCSV

### 第2段階

- `stage2_forecasts.csv`
- `stage2_component_details.csv`
- `aggregation_check.csv`
- `stage2_audit.csv`

### 第3段階

- `expert_cube_long.csv`
- `expert_cube_wide.csv`
- `combination_weights.csv`
- `expert_uncertainty.csv`
- `crossfit_audit.csv`

### 第4段階

- `pepg_policy_parameters.npz`
- `pepg_model_metadata.json`
- `state_dependent_policy_rows.csv`
- `stage4_test_metrics.csv`
- `stage4_audit.csv`

### 第5段階

- `forecast_packet_<RUN_ID>.json`
- `component_contributions_<RUN_ID>.csv`
- `revision_decomposition_<RUN_ID>.csv`
- `scenario_table_<RUN_ID>.csv`
- `production_audit_<RUN_ID>.csv`
- `model_card_<RUN_ID>.md`
- `pepg_policy_<RUN_ID>.npz`

## 実行

JupyterLabから各ノートブックを開き、上から順に実行します。

```bash
jupyter lab
```

コマンドラインで再実行する例：

```bash
jupyter nbconvert \
  --to notebook \
  --execute 01_japan_cpi_realtime_benchmark.ipynb \
  --output 01_japan_cpi_realtime_benchmark.executed.ipynb \
  --ExecutePreprocessor.timeout=1200
```

## 学術的・実務的な注意

- 真のナウキャスト評価には、公表日だけでなく改定前ビンテージのアーカイブが必要です。
- 前年比を直接学習するだけでなく、指数水準または前月比を予測し、前年比を指数から再計算してください。
- 政策ショックのパススルーは希少事象です。PEPGネットワークだけで識別せず、制度計算、イベントスタディ、外部推計を事前分布として利用してください。
- PEPGの探索標準偏差は最適化上のノイズであり、予測不確実性ではありません。
- 状態依存政策は固定stackingを必ず上回るとは限りません。時系列validationとフォールバック規則を運用条件にしてください。
- 予測区間は適正スコアと被覆率で評価し、点予測RMSEだけでモデルを選択しないでください。
- demoモードのシナリオ感応度は例示値です。実運用では日本の部門別パススルー推計へ置き換えてください。
