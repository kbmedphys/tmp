# 実行確認レポート

| ノートブック | 実行済み | エラー出力 | 全コードセルに処理・入力・出力要件 |
|---|---:|---:|---:|
| `01_japan_cpi_realtime_benchmark.ipynb` | True | 0 | True |
| `02_japan_cpi_bottom_up_institutional.ipynb` | True | 0 | True |
| `03_japan_cpi_crossfit_experts.ipynb` | True | 0 | True |
| `04_japan_cpi_pepg_moe.ipynb` | True | 0 | True |
| `05_japan_cpi_production_attribution.ipynb` | True | 0 | True |

既定のdemoモードで全ノートブックを上から順に実行し、出力ファイルを`outputs/`に保存しています。
