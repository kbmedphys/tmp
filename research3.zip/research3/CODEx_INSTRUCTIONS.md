# Codex 実行指示書（テーマETF：DM + trendiness + term structure + comom + stmom + optional beta）
最重要：この指示書は「段階的研究フロー」を自動で実行するための手順書です。  
ボラ割り（volatility scaling）は採用しません（不要）。

---

## 0. 共通ルール（絶対遵守）
- workspace直下の AGENTS.md を最初に開き、全ルールを遵守すること（uv運用、pip禁止、outputs配下、日本語、incremental、バックアップ等）。
- 依存追加は禁止（必要なら提案のみ）。
- 変更は incremental（広範囲リファクタ禁止）。
- すべての成果物（図・表・ログ・レビュー文書）は `projects/momentum/research3/outputs/` 配下に保存する。
- リーク防止：特徴量は時点 t までで計算し、適用は必ず t+1 以降。月末確定→翌営業日適用。
- srcは使わない。必要関数はノートブック内に同梱する（セル整理はOK）。

---

## 1. 作業ゴール（最終成果物）
(1) 原典レビューと乖離点の明文化（Phase -1）  
(2) 共通基盤（Phase 0）とベースラインDM（Phase 1）の完走  
(3) シグナル観測（Phase 2）→予測力テスト（Phase 3）  
(4) ゲートを1つずつ追加して増分検証（Phase 4-1〜4-4）  
(5) （任意）β警報ゲート（Phase 4-5）  
(6) 総括（Phase 5：採用/保留/棄却の判断表）

---

## 2. 入力（必須）
### 2.1 原典PDF（プロジェクト内に存在する必要あり）
以下が `docs/sources/` にあることを確認して読む。無い場合は「不足」を outputs に記録して停止する。
- Comomentum.pdf
- Short-term Momentum.pdf
- Understanding Momentum and Reversals.pdf

### 2.2 trend-scanning
trend-scanning は **URLから一次情報へ辿る**。対象URL：
- https://www.mql5.com/en/articles/19253

※環境上ウェブ取得ができない場合は、到達不可理由を明記し、ユーザーに入手してもらう一次情報リストを outputs に出して停止する。

---

## 3. 実行順序（必ずこの順）
### Phase -1：原典レビュー（実装禁止）
目的：
- 各手法の「主張」「定義」「推定手順」「必要データ」「落とし穴」を原典ベースで整理し、
- 本プロジェクト案が原典とどこで一致/乖離（proxy化）するかを明記する。
- trend-scanning はURL→引用→一次情報をトレースし、採用する定義を固定する。

成果物（必須）：
- outputs/docs/literature_review.md
- outputs/docs/original_checklist.md（論文別チェックリスト：ページ/式番号付き）
- outputs/tables/method_mapping_matrix.csv
- outputs/tables/equation_index.csv
- outputs/tables/open_questions.csv
- outputs/docs/trend_scanning_review.md
- outputs/tables/trend_scanning_source_trace.csv
- docs/sources/trend_scanning_primary_source.pdf（入手できた場合）
  - 入手不可なら docs/sources/trend_scanning_sources.md を作成

停止条件：
- 上記が揃うまで Phase0 以降に進まない。

---

### Phase 0：共通基盤（notebooks/00_data_and_calendar.ipynb）
目的：データ→カレンダー→月末→翌営業日適用→遅延→コスト→評価指標まで固定。

必須成果物：
- outputs/logs/run_manifest_phase0.json
- outputs/tables/data_summary.csv
- outputs/tables/calendar_summary.csv
- outputs/tables/unit_test_alignment.csv（遅延・リーク防止の簡易テスト）
- outputs/figs/sample_prices.png（疑似でもOK）
- outputs/figs/sample_returns.png

停止条件：完走＋出力。

---

### Phase 1：ベースラインDM（notebooks/10_baseline_dm.ipynb）
目的：DM（12m-2m）を月次リバランスで完走し、ベースラインを確立。

仕様：
- 月末でシグナル確定 → 翌営業日から適用
- 上位K等ウェイト（Kはパラメータ）
- EQW比較
- コスト控除（比例コスト）

必須成果物：
- outputs/logs/run_manifest_phase1.json
- outputs/tables/metrics_baseline.csv（DM・EQW併記）
- outputs/tables/positions_sample.csv
- outputs/figs/equity_curve_baseline.png
- outputs/figs/drawdown_baseline.png

停止条件：完走＋出力。

---

### Phase 2：シグナル観測（notebooks/20_signal_dashboard.ipynb）
目的：統合せず、各シグナルの時系列・相関・発火率を可視化して冗長性/有用性を判断。

観測対象：
A) trendiness（trend-scanning lookback）：|t| と R2 から作る（L*は使わない）
B) term structure：M6,M12,M18 と S=M6-M18, C=M6-2*M12+M18（差分のみ）
C) comomentum：残差化できる場合のみ（できないなら未実装として明記）
D) stmom/turnover：1ヶ月リターンと turnover proxy
E) optional beta proxy：β、Δβ、fit悪化proxy

必須成果物：
- outputs/logs/run_manifest_phase2.json
- outputs/tables/signal_stats.csv
- outputs/tables/signal_corr.csv
- outputs/figs/dashboard_trendiness.png
- outputs/figs/dashboard_term_structure.png
- outputs/figs/dashboard_stmom_turnover.png
- outputs/figs/dashboard_comom.png（未実装ならnot available表示）
- outputs/figs/dashboard_beta_proxy.png（未実装ならnot available表示）

---

### Phase 3：予測力テスト（notebooks/30_signal_predictiveness.ipynb）
目的：ゲート投入前に、各シグナルが「次月DM成績/リスク」を条件付で分離できるかを確認。

目的変数：
- Y1：次月DMリターン
- Y2：次月DMの下振れ（例：次月リターン<閾値 or 次月MaxDD）

方法：
- 分位ソート（top-bottom差）
- 軽量回帰/ロジット（単変量〜2変量まで）
- Walk-forward で OOS テーブル

必須成果物：
- outputs/logs/run_manifest_phase3.json
- outputs/tables/predictiveness_summary.csv
- outputs/tables/walkforward_oos.csv
- outputs/figs/predictiveness_barplots.png
- outputs/tables/adoption_recommendation_phase3.csv（Phase4へ進める候補/保留の旗）

---

### Phase 4：段階的統合（ゲートは1つずつ追加）
共通ルール：
- 乗算禁止：risk_scale = min(scale_trend, scale_crowd, scale_beta)
- 月中は銘柄入替禁止（リスク量のみ調整）
- STMOMは新規エントリー抑制のみ（既存縮小には使わない）
- trendinessは trendinessのみ（L*不使用）
- ボラ割りはしない

戦略ID：
- S00 = DM
- S10 = DM + trendiness gate
- S20 = S10 + term structure（horizon混合：月次）
- S30 = S20 + comomentum gate（残差化できる場合のみ）
- S40 = S30 + stmom entry filter（新規のみ）
- S50 = S40 + beta gate（任意）

#### Phase 4-1（notebooks/41_bt_dm_plus_trendiness.ipynb）
成果物：
- outputs/tables/metrics_S00_S10.csv
- outputs/tables/gate_stats_S10.csv
- outputs/figs/equity_S00_S10.png
- outputs/figs/drawdown_S00_S10.png
- outputs/tables/incremental_report_S10.csv
- outputs/logs/run_manifest_phase41.json

#### Phase 4-2（notebooks/42_bt_add_term_structure.ipynb）
成果物：
- outputs/tables/metrics_S10_S20.csv
- outputs/tables/term_gate_stats.csv
- outputs/figs/equity_S10_S20.png
- outputs/figs/drawdown_S10_S20.png
- outputs/tables/incremental_report_S20.csv
- outputs/logs/run_manifest_phase42.json

#### Phase 4-3（notebooks/43_bt_add_comomentum.ipynb）
注意：
- 残差化できない場合はS30を作らず、理由を outputs/logs に残して停止（無理に実装しない）。

成果物（実装できた場合）：
- outputs/tables/metrics_S20_S30.csv
- outputs/tables/gate_stats_S30.csv
- outputs/tables/tail_stats_S20_S30.csv
- outputs/figs/equity_S20_S30.png
- outputs/figs/drawdown_S20_S30.png
- outputs/tables/incremental_report_S30.csv
- outputs/logs/run_manifest_phase43.json

#### Phase 4-4（notebooks/44_bt_add_stmom_entry_filter.ipynb）
成果物：
- outputs/tables/metrics_prev_S40.csv（S30が無ければS20と比較）
- outputs/tables/entry_filter_stats.csv
- outputs/figs/equity_compare_entry_filter.png
- outputs/tables/incremental_report_S40.csv
- outputs/logs/run_manifest_phase44.json

#### Phase 4-5（任意：notebooks/45_bt_add_beta_gate.ipynb）
仕様：
- β急変/補償薄化のproxy＋推定不確実性（fit悪化等）
- 縮退上限（例：0.7倍まで）を必ず入れる

成果物：
- outputs/tables/metrics_S40_S50.csv
- outputs/tables/gate_stats_S50.csv
- outputs/figs/equity_S40_S50.png
- outputs/figs/drawdown_S40_S50.png
- outputs/tables/incremental_report_S50.csv
- outputs/logs/run_manifest_phase45.json

---

### Phase 5：総括（notebooks/50_summary_and_decision.ipynb）
目的：S00〜S50を横並びで比較し、採用/保留/棄却の判断を出す。

必須成果物：
- outputs/tables/final_comparison_all_strategies.csv
- outputs/tables/final_tail_and_turnover.csv
- outputs/tables/adoption_decision.csv（採用/保留/棄却＋理由）
- outputs/figs/final_equity_all.png
- outputs/figs/final_drawdown_all.png
- outputs/logs/run_manifest_phase5.json

---

## 4. 最後に必ずやる報告
- 作成/更新したファイル一覧を提示
- 各Phaseの完走可否と、未実装/保留になった理由（例：comom残差化不可、trend-scanning一次未入手）を簡潔にまとめる