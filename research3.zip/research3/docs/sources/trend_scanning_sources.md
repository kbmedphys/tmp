# trend_scanning 一次情報の取得状況

## 現状
- 指定URL（MQL5）と一次情報候補（SSRN abstract_id=3257419）までは到達確認済み。
- ただし、実行環境のネットワーク制約（DNS解決不可、PDF配信URLのリダイレクト制約）により、一次PDFファイルをローカル保存できていない。

## ユーザーに用意いただきたい一次情報（優先順）
1. `trend_scanning_primary_source.pdf`
   - 例: SSRN abstract_id=3257419 に対応する PDF 本文（Machine Learning for Asset Managers 関連資料）
2. 上記PDFの bibliographic メタ情報（著者、年、章/節）
3. trend-scanning の定義式・アルゴリズム部分が含まれるページ指定（再現性確保のため）

## 配置先
- 取得後、以下に配置してください。
  - `docs/sources/trend_scanning_primary_source.pdf`
