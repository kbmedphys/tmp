# original_checklist（論文別チェックリスト）

## A. Comomentum.pdf
- [x] 主張確認: crowding proxy として comomentum を提案（p.2, Abstract）
- [x] 定義確認: loser/winner デシルの残差部分相関平均（p.14, Eq.(1)(2)）
- [x] 推定確認: 12-1ソート + 52週相関 + FF3調整（p.14）
- [x] 予測検証: stock comomentum の将来リターン予測（p.28-29）

## B. Short-term Momentum.pdf
- [x] 主張確認: 高turnover群で短期モメンタム、低turnover群で短期反転（p.1-3）
- [x] 定義確認: 1M return × turnover ダブルソート（p.2 Figure 1）
- [x] コスト式確認: one-way turnover（p.23, Eq.(1)）
- [x] 回帰確認: bear/rebound beta 回帰（p.31, Eq.(2)）

## C. Understanding Momentum and Reversals.pdf
- [x] 主張確認: モメンタム/反転は将来ベータ予測にも現れる（p.1-3）
- [x] 条件付きモデル確認: Eq.(1)
- [x] ベータ予測回帰確認: Eq.(2)
- [x] IPCA定式確認: Eq.(3)(4)

## D. trend-scanning（指定URLトレース）
- [x] 指定URL確認: `https://www.mql5.com/en/articles/19253`
- [x] URLから一次情報候補（SSRN abstract_id=3257419）まで到達
- [ ] 一次PDFローカル保存
  - 理由: ネットワーク制約
- [x] 方針: `secondary_web_only` で条件付き完了として継続
