# research3 結果解釈ノート（Phase -1〜5）

## 1. エグゼクティブサマリー

- 本ランは、`secondary_web_only`（一次PDF未取得）という根拠制約付きで Phase -1〜5 を完走し、全 `run_manifest` が `completed_with_deviation` になっている。
- 最終比較では `Sharpe` 最大が `S00`（0.673）、`CAGR` 最大が `S00`（8.41%）、`MaxDD` 最小が `S50`（-15.33%）だった。
- S00→S30 までは『リスクを抑えつつ総合効率を維持』、S40/S50 は『さらに守備化する代わりに期待リターンが大きく低下』という構造が明確。
- 採用判断は `S30=adopt`、`S00/S10/S20=hold`、`S40/S50=reject`。根拠制約は `trend_scanning_primary_missing` を継続注記。

主要参照:
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/final_comparison_all_strategies.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/adoption_decision.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase5.json`

## 2. 前提と制約

- 根拠階層: 全Phase manifestで `evidence_tier=secondary_web_only`。
- 共通制約: ボラ割り不採用、月中は銘柄入替禁止（リスク量のみ調整）、STMOMは新規エントリー抑制のみ、ゲート統合は min/cap（乗算禁止）。
- 主な乖離: trend-scanning 一次PDFが未取得のため、関連解釈は暫定扱い。

manifest確認（抜粋）:
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase-1.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase0.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase1.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase2.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase3.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase41.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase42.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase43.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase44.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase45.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase5.json`: status=completed_with_deviation, evidence_tier=secondary_web_only, deviation_flags=['trend_scanning_primary_missing']

## 3. データと評価設計

- 対象ユニバース: 12 ETF（AGG, DBC, EEM, EFA, EMB, GLD, HYG, IWM, LQD, SPY, TLT, VNQ）
- 期間: 2005-01-03 〜 2026-02-09（254ヶ月）
- 主評価: CAGR, Vol, Sharpe, MaxDD, AvgTurnover

リーク防止チェック (`unit_test_alignment.csv`):
- `apply_after_month_end`: result=False (all apply_date > month_end)
- `month_end_in_trading_calendar`: result=True (month_end is trading day)
- `ret_index_monotonic`: result=True (returns index increasing)
- `apply_after_month_end` が `False` なのは、最終行（2026-02-09）に `apply_date` が無いことが主因（`calendar_summary.csv` 末尾）。

参照:
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/data_summary.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/calendar_summary.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/unit_test_alignment.csv`

## 4. 手法解説（実装仕様ベース）

### 4.1 DM（12m-2m）
- 理論意図: 中期モメンタムの継続性を月次で取得。
- 本実装proxy: 月末シグナルで Top-K（K=4）等ウェイト、翌営業日適用、10bps片道コスト控除。
- 期待効果: ベースライン超過収益の基礎軸。

### 4.2 trendiness gate（trend-scanning proxy）
- 理論意図: トレンドの強さ/整合性を `|t|` と `R2` で評価。
- 本実装proxy: lookback 20..252日, step 5, log-price OLS。`L*` は不使用。
- 期待効果: 不明瞭トレンド局面のリスク縮小。

### 4.3 term structure proxy gate
- 理論意図: 複数地平のモメンタム形状から slope/curvature を推定。
- 本実装proxy: M6/M12/M18 から `S=M6-M18`, `C=M6-2*M12+M18`。
- 期待効果: 過度な鈍化/反転局面での抑制。

### 4.4 comomentum gate
- 理論意図: crowding（同方向取引の過密）を残差相関で近似。
- 本実装proxy: SPY/AGG/DBC因子で残差化し、相関平均を月次化。
- 期待効果: crowding高局面の縮退。

### 4.5 STMOM entry filter
- 理論意図: 短期反転リスクの高い新規エントリーを抑制。
- 本実装proxy: 1M return + volume由来turnover proxy。**新規のみ**に適用。
- 期待効果: ドローダウン緩和と回転率低下。

### 4.6 beta gate（optional）
- 理論意図: beta急変/適合悪化時の防御。
- 本実装proxy: rolling beta, Δbeta, fit deterioration、`scale_beta` は [0.7, 1.0] に制限。
- 期待効果: テール損失のさらなる抑制。

## 5. Phase別結果と解釈

### Phase -1（原典レビュー）
- 原典3本 + trend-scanning URLトレースは完了。
- 一次PDF未取得のため `completed_with_deviation`。これは以降フェーズの解釈に継続注記。
- 参照: `/Users/kencharoff/workspace/projects/momentum/research3/outputs/docs/literature_review.md`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/docs/trend_scanning_review.md`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase-1.json`

### Phase 0（データ基盤/カレンダー）
- データ整形と月末→翌営業日マップは作成済み。
- `apply_after_month_end=False` は最終月の適用日未確定が主因で、通常月のロジック自体は成立。
- 参照: `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/calendar_summary.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/unit_test_alignment.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase0.json`

### Phase 1（DM baseline）
- DM: CAGR 8.41%, Vol 13.32%, Sharpe 0.673, MaxDD -22.84%.
- EQW: CAGR 7.40%, Vol 11.45%, Sharpe 0.681, MaxDD -35.11%.
- 解釈: DMはCAGRとDD改善で優位、ただしSharpeはEQWと近く、回転率は高い。
- 参照: `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/metrics_baseline.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/positions_sample.csv`

### Phase 2（シグナル観測）
- 欠損率は `comom_level` が最大（約10.24%）で、他は概ね許容範囲。
- 相関では term系内部（M18とS等）と trend系内部（abs_tとR2）の冗長性が高い。
- 解釈: 完全独立シグナル集合ではなく、統合時は過剰な二重カウントを避ける設計が必要。
- 参照: `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/signal_stats.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/signal_corr.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/figs/dashboard_trendiness.png`

### Phase 3（予測力テスト）
- OLS t値は最大でも絶対値1.50未満、AUCもおおむね0.5近傍。
- stmom_mean: ols_t=-1.498, auc=0.533, corr_y1=-0.094, Q5-Q1=-0.85%
- delta_beta_mean: ols_t=-1.343, auc=0.550, corr_y1=-0.085, Q5-Q1=-0.84%
- trend_r2_mean: ols_t=1.337, auc=0.501, corr_y1=0.084, Q5-Q1=0.28%
- 解釈: 単独シグナルの予測力は弱く、厳密な予測モデルというより「リスク縮退フィルタ」として使う方が整合的。
- 参照: `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/predictiveness_summary.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/walkforward_oos.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/adoption_recommendation_phase3.csv`

### Phase 4（段階統合: 4-1〜4-5）
- 4-1 S00→S10: Vol/MaxDD/Turnoverは改善、CAGRは低下。
- 4-2 S10→S20: 同方向の守備化が継続、リターンはさらに低下。
- 4-3 S20→S30: CAGRほぼ横ばいでSharpeが改善（この区間が最も効率的）。
- 4-4 S30→S40: 守備性は大きく改善するが、CAGR/Sharpe低下が大きい。
- 4-5 S40→S50: 追加改善は小さいが、Vol/DDは微改善しSharpeは小幅回復。

増分差分（主要指標）:
- S10: ΔCAGR -1.23%, ΔVol -1.92%, ΔSharpe -0.008, ΔMaxDD 4.90%
- S20: ΔCAGR -0.70%, ΔVol -1.12%, ΔSharpe -0.004, ΔMaxDD 0.63%
- S30: ΔCAGR -0.05%, ΔVol -0.27%, ΔSharpe 0.011, ΔMaxDD 0.05%
- S40: ΔCAGR -2.57%, ΔVol -2.53%, ΔSharpe -0.129, ΔMaxDD 1.73%
- S50: ΔCAGR -0.03%, ΔVol -0.20%, ΔSharpe 0.008, ΔMaxDD 0.20%
- 参照: `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S10.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S20.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S30.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S40.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S50.csv`

### Phase 5（最終比較と採用判断）
- 最終比較の要点:
- S00: CAGR 8.41%, Vol 13.32%, Sharpe 0.673, MaxDD -22.84%, AvgTurnover 0.90%
- S10: CAGR 7.17%, Vol 11.40%, Sharpe 0.665, MaxDD -17.94%, AvgTurnover 0.84%
- S20: CAGR 6.47%, Vol 10.29%, Sharpe 0.661, MaxDD -17.31%, AvgTurnover 0.79%
- S30: CAGR 6.42%, Vol 10.01%, Sharpe 0.672, MaxDD -17.26%, AvgTurnover 0.76%
- S40: CAGR 3.85%, Vol 7.49%, Sharpe 0.542, MaxDD -15.53%, AvgTurnover 0.41%
- S50: CAGR 3.82%, Vol 7.29%, Sharpe 0.551, MaxDD -15.33%, AvgTurnover 0.40%
- 採用判断（CSV原文準拠）:
- S00: hold (borderline)
- S10: hold (borderline)
- S20: hold (borderline)
- S30: adopt (risk_return_balanced)
- S40: reject (weak_risk_return)
- S50: reject (weak_risk_return)
- 解釈: S30は守備性を確保しつつSharpe維持のバランスが最も良く、S40/S50は守備過多で期待リターンが不足。
- 参照: `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/final_comparison_all_strategies.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/final_tail_and_turnover.csv`, `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/adoption_decision.csv`

## 6. ゲート別トレードオフ総括

- trend gate: DD/Vol削減の寄与は大きいが、CAGRを削る。
- term gate: trendと同方向で守備強化。リターン圧縮が継続。
- comom gate: 追加の守備強化に対してリターン低下が小さく、最も効率が高い追加ゲート。
- stmom entry filter: 回転率とDDを大きく下げる代わりに、機会損失でCAGR/Sharpeが悪化。
- beta gate: S40以降の守備を微調整する効果はあるが、期待リターン改善は限定的。

Tail評価（S00→S50）:
- VaR5: -1.33% -> -0.71%
- CVaR5: -2.04% -> -1.15%
- WorstDay: -5.83% -> -3.48%
- WorstMonth: -11.47% -> -7.80%

## 7. 信頼性評価と限界

- 主要制約は `secondary_web_only` と `trend_scanning_primary_missing`。trendiness解釈は一次情報確保前の暫定結論。
- comomentum/term/betaはいずれもETF次元でのproxyであり、原典の個別株・因子設計とは厳密に同値ではない。
- Phase 3で予測力が弱いため、統計的優位性よりも「損失制御の工学的効果」に評価軸が寄っている。

## 8. 次の改善提案

1. trend-scanning 一次情報PDFを取得し、仕様差分（式・閾値・地平選択）を再監査する。
2. Phase 0 の `apply_after_month_end` 判定を「終端月除外」で再定義し、テストを明確化する。
3. STMOM entry filter の閾値（現状 0 判定）を分位閾値化し、CAGR劣化を抑えられるか再検証する。
4. beta gate は現在の微改善幅が小さいため、fit悪化指標の設計を見直し（急変検知の感度調整）する。
5. 採用候補 S30 を基準に、OOS区間分割（サブ期間）で安定性を追加検証する。

---

### 参照ファイル一覧（主要）
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/final_comparison_all_strategies.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/final_tail_and_turnover.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/adoption_decision.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/predictiveness_summary.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/adoption_recommendation_phase3.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/signal_stats.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/signal_corr.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S10.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S20.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S30.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S40.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/tables/incremental_report_S50.csv`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/figs/final_equity_all.png`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/figs/final_drawdown_all.png`
- `/Users/kencharoff/workspace/projects/momentum/research3/outputs/logs/run_manifest_phase5.json`
