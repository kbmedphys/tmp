# 日本株BTQ Small-Scale Lab

## 最初に開くファイル

`main.ipynb`を開いてください。要件定義、全関数、入力テンプレート生成、合成データ、フロー構築、β推定、quantity、予測・評価・追跡・受入テストを一つのNotebookに収録しています。`requirements.md`は冒頭の要件定義と同じ内容の参照用コピーです。別の`.py`ファイルや前回の取得手順書は必要ありません。

既定の`demo`は、架空の24株、6投信、4ETF、3因子、96か月を使用します。日本市場のデータでも正規Barraデータでもなく、BTQの予測成功を埋め込んだサンプルでもありません。平日のみの架空カレンダーを使用します。表示済みの数値・グラフも合成データの動作確認です。

## 1. 環境を用意する

Python 3.11以降を想定します。既存のuvプロジェクト／仮想環境に、Notebook外のターミナルから依存を追加します。以下は動作確認した主要パッケージのバージョンです。

```bash
uv add "numpy==2.3.5" "pandas==2.2.3" "matplotlib==3.10.8" ipykernel
```

VS Code／Jupyterで、その環境のPythonカーネルを選択してください。実行環境のパスはStep 00に表示します。必要な場合だけカーネルを登録します。

```bash
uv run python -m ipykernel install --user --name btq-pilot --display-name "Python (BTQ pilot)"
```

JupyterLabを使う環境に未導入なら、`uv add --dev jupyterlab`、`uv run jupyter lab main.ipynb`で起動できます。Parquet入力を使う場合だけ`uv add pyarrow`を追加します。Notebook内の自動インストールはありません。

## 2. 合成データで上から実行する

Step 00の`CFG = PilotConfig()`を維持し、各Stepの実行セルを順番に実行します。定義セルにも全処理を収録していますが、主に確認するのはその後の短い`execute_step(...)`セルです。

| Step | 確認するもの |
|---|---|
| 00–01 | 設定、Python環境、正規化スキーマ、空テンプレート |
| 02–03 | 読み込んだ表、行数、単位・日時・IDの検査 |
| 04 | 日次超過リターン、暦月TR、日次欠損 |
| 05 | TNA残差／提供フロー／銘柄別フローとその符号 |
| 06 | 単変量β、共分散、観測数、最終観測日 |
| 07 | 観測主体ごとの寄与、前月市場総額、6か月quantity |
| 08 | その判断時点で利用可能だったβ・quantity、適用日 |
| 09 | 適用日後の将来リターン、ラベル欠損、共通標本 |
| 10 | 時系列学習、境界ラベルの除外、学習期尺度、予測値 |
| 11–12 | OOS R²・IC・条件付きSML・FMB、参考の順位バスケットとEQW |
| 13 | 任意の1銘柄・1時点の入力から予測値までの追跡 |
| 14–15 | 独立した合成受入テスト、完了報告と保存先 |

出力は`./btq_pilot_workspace/runs/<run_id>/`へ保存します。大きい表の表示を省略しても、CSVには全行を保存します。チェックポイントの表は`load_saved_table(path)`で再読込できます。これは全実行状態の自動復元ではありません。

### さらに軽い動作試験

Step 00の設定を次のように変更できます。原文の12か月β・6か月quantityとは異なる、処理確認用の設定です。

```python
CFG = PilotConfig(
    demo_months=36, demo_stocks=12, demo_funds=3, demo_etfs=2, demo_factors=2,
    beta_lookback_months=6, beta_min_observations=80, quantity_months=3,
    train_months=12, min_train_months=9,
)
```

## 3. 実データへ切り替える

まず`CFG`を次のように変更してStep 00から実行し、`audit`でファイルの有無を確認します。`audit`は欠損をdemoで埋めず、分析を行いません。

```python
CFG = PilotConfig(mode="audit", root="./my_btq_test", routes=("fund_beta",))
```

`templates`の必要表を`./my_btq_test/inputs/`へ配置します。`inputs/metadata.json`のデータ名・意味・基準通貨・公表日時の確認状況を記録してください。内容を確認せずに`semantics_verified`や`calendar_verified`をtrueにしないでください。

列名が異なる場合はStep 01の`INPUT_SPECS`を編集します。例：

```python
INPUT_SPECS["fund_daily"] = TableSpec(
    "raw/fund_returns.csv",
    columns={"FundCode":"entity_id", "Date":"date", "ReturnPct":"total_return", "PublishedAt":"available_at"},
    multipliers={"total_return":0.01},
)
```

入力がそろったら`mode="local"`にして、Step 00から再実行します。取得済みのDataFrameを使う場合は`mode="dataframe"`とし、Step 01の`FRAME_INPUTS`へ正規化済み表を渡します。日次TR指数から日次リターンへ変換する補助関数もNotebook内にあります。未調整価格や分配を含まないNAVは自動変換しません。

### 使う方法だけを選ぶ

```python
CFG = PilotConfig(mode="local", root="./my_btq_test", routes=("fund_beta",))
CFG = PilotConfig(mode="local", root="./my_btq_test", routes=("etf_beta",), etf_flow_method="supplied")
CFG = PilotConfig(mode="local", root="./my_btq_test", routes=("stock_flow",))
```

`stock_flow`単独では`fund_daily`と`fund_monthly`は不要です。正規Barraを使う場合は、その日次因子リターンを`factor_daily`へ変換して読み込みます。Barraのネイティブ・エクスポージャーをβに流用する実装ではありません。

ETF口数増減に基づくフローは、この版では自動計算しません。別途検算済みの月次金額を`net_flow_jpy`へ渡し、`supplied`を選択してください。

## 4. 中間表を再確認する

```python
inspect_table("07_quantity", "contributions", {"route":"fund_beta", "month":"2021-06"})
inspect_table("06_betas", "betas", {"entity_id":"任意のID", "risk_month":"2021-06"})
```

Step 13の`TRACE_ROUTE`、`TRACE_MONTH`、`TRACE_ENTITY`、`TRACE_FACTOR`を指定すると、その観測の寄与額と予測式を再構築します。`None`は最初の評価可能なOOS観測です。

設定変更時はStep 00から、入力ファイルの変更時はStep 02から再実行してください。上流Stepを再実行すると下流を無効化します。`STORE`内の表を手編集するとハッシュ検査で停止するため、変更は元入力へ反映してください。

## 5. 何をテストしていないか

外部APIの接続、契約権限、日本投信・日本株の実データ、過去版の完全性、実証的な予測力、取引費用控除後の利益は未検証です。複数の公表vintageを保持する時点データベースでもありません。`single_snapshot`の場合、与えた利用可能日時による保守的な制約は適用しますが、改訂前の値を復元したとはみなしません。

テスト報告の合格は、数式・符号・欠損・日時・入力切替・状態管理の実装検査の結果です。少数標本や合成データのR²・シャープレシオから、日本株BTQが有効と判断しないでください。

認証情報をNotebook・CSV・metadataへ記録しないでください。実データ入力後のNotebook出力やチェックポイントにはデータが含まれるため、共有時は契約・機密性を確認してください。
