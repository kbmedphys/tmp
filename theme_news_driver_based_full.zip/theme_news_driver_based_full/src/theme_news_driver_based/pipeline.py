from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

from .config import load_config, load_yaml, resolve_path, ensure_parent, project_root
from .io_utils import save_df, load_df
from .text_utils import build_clean_text
from .theme_profile import build_theme_profiles, build_driver_profiles
from .news_loader import fetch_lseg_news, make_mock_news
from .embeddings import build_embedding_backend, cosine_matrix
from .driver_linker import build_news_driver_links, aggregate_driver_sim_by_theme, build_news_theme_links_driver_based
from .sentiment import add_tone_to_links
from .features_driver_based import build_daily_theme_features_driver_based
from .portfolio import select_top_themes
from .reporting import save_latest_score_table, plot_theme_score_timeseries, plot_selected_theme_heatmap


def load_theme_config(cfg: dict) -> dict:
    path = resolve_path(cfg['paths']['theme_profiles'])
    return load_yaml(path)


def load_queries(cfg: dict) -> dict:
    path = resolve_path(cfg['paths']['lseg_queries'])
    return load_yaml(path)


def get_news(cfg: dict, queries: dict, theme_profiles: pd.DataFrame, driver_profiles: pd.DataFrame) -> pd.DataFrame:
    mode = cfg.get('news', {}).get('mode', 'mock')
    raw_path = resolve_path(cfg['paths']['raw_news'])
    if mode == 'lseg':
        news_df = fetch_lseg_news(cfg, queries, theme_profiles)
        save_df(news_df, raw_path)
    elif mode == 'offline':
        news_df = load_df(raw_path)
    else:
        news_df = make_mock_news(theme_profiles, driver_profiles)
    if 'clean_text' not in news_df.columns:
        story = news_df['story_text'] if 'story_text' in news_df.columns else ''
        news_df['clean_text'] = [build_clean_text(h, b) for h, b in zip(news_df['headline'], story)]
    return news_df


def run_pipeline(config_path: str | Path = 'configs/config.yaml') -> dict[str, pd.DataFrame]:
    cfg = load_config(config_path)
    theme_cfg = load_theme_config(cfg)
    queries = load_queries(cfg)

    theme_profiles = build_theme_profiles(theme_cfg)
    driver_profiles = build_driver_profiles(theme_cfg, include_catalysts=True)
    news_df = get_news(cfg, queries, theme_profiles, driver_profiles)

    # Fit/encode embeddings. For TF-IDF, fit on all corpora to keep vector dimensions aligned.
    all_fit_texts = (
        news_df['clean_text'].fillna('').astype(str).tolist()
        + theme_profiles['embedding_text'].fillna('').astype(str).tolist()
        + driver_profiles['driver_embedding_text'].fillna('').astype(str).tolist()
    )
    backend = build_embedding_backend(cfg, all_fit_texts=all_fit_texts)
    news_emb = backend.encode(news_df['clean_text'].fillna('').astype(str).tolist())
    theme_emb = backend.encode(theme_profiles['embedding_text'].fillna('').astype(str).tolist())
    driver_emb = backend.encode(driver_profiles['driver_embedding_text'].fillna('').astype(str).tolist())

    theme_sim = cosine_matrix(news_emb, theme_emb)
    driver_sim = cosine_matrix(news_emb, driver_emb)

    min_driver_sim = float(cfg.get('linking', {}).get('min_driver_sim', 0.45))
    news_driver_links = build_news_driver_links(news_df, driver_profiles, driver_sim, min_driver_sim=min_driver_sim)
    driver_theme_agg = aggregate_driver_sim_by_theme(news_driver_links)
    news_theme_links = build_news_theme_links_driver_based(news_df, theme_profiles, theme_sim, driver_theme_agg, cfg)
    news_theme_links = add_tone_to_links(news_theme_links, news_df, theme_profiles, driver_profiles)

    features = build_daily_theme_features_driver_based(
        news_df=news_df,
        news_theme_links=news_theme_links,
        driver_links=news_driver_links,
        driver_profiles=driver_profiles,
        theme_profiles=theme_profiles,
        cfg=cfg,
    )

    n_top = int(cfg.get('portfolio', {}).get('n_top_themes', 4))
    theme_weights = select_top_themes(features, n_top=n_top) if not features.empty else pd.DataFrame()

    # Save outputs
    p = cfg['paths']
    save_df(news_df, ensure_parent(p['news_clean']))
    save_df(theme_profiles, ensure_parent(p['theme_profiles_out']))
    save_df(driver_profiles, ensure_parent(p['driver_profiles_out']))
    save_df(news_driver_links, ensure_parent(p['news_driver_links']))
    save_df(news_theme_links, ensure_parent(p['news_theme_links']))
    save_df(features, ensure_parent(p['features_daily']))
    save_df(theme_weights, ensure_parent(p['theme_weights']))

    root = project_root()
    if not news_driver_links.empty:
        news_driver_links.sort_values('driver_sim', ascending=False).head(200).to_csv(root / 'outputs/tables/news_driver_links_sample.csv', index=False, encoding='utf-8-sig')
    if not news_theme_links.empty:
        news_theme_links.sort_values('rel_score', ascending=False).head(200).to_csv(root / 'outputs/tables/news_theme_links_sample.csv', index=False, encoding='utf-8-sig')
    if not features.empty:
        save_latest_score_table(features, root / 'outputs/tables/theme_scores_latest.csv')
        plot_theme_score_timeseries(features, root / 'outputs/figures/theme_score_timeseries_top10.png')
    if not theme_weights.empty:
        theme_weights.to_csv(root / 'outputs/tables/theme_weights.csv', index=False, encoding='utf-8-sig')
        plot_selected_theme_heatmap(theme_weights, root / 'outputs/figures/selected_theme_heatmap.png')

    return {
        'news_df': news_df,
        'theme_profiles': theme_profiles,
        'driver_profiles': driver_profiles,
        'news_driver_links': news_driver_links,
        'news_theme_links': news_theme_links,
        'features': features,
        'theme_weights': theme_weights,
    }
