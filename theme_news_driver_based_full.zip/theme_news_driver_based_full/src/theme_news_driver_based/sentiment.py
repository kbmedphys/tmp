from __future__ import annotations

import pandas as pd


def theme_specific_tone(text: str, theme_row: pd.Series, driver_rows: pd.DataFrame | None = None) -> float:
    text = text or ''
    lower = text.lower()
    pos_terms = []
    neg_terms = []
    pos_terms += theme_row.get('positive_events_en', []) or []
    pos_terms += theme_row.get('positive_events_ja', []) or []
    neg_terms += theme_row.get('negative_events_en', []) or []
    neg_terms += theme_row.get('negative_events_ja', []) or []
    if driver_rows is not None and not driver_rows.empty:
        for _, r in driver_rows.iterrows():
            pos_terms += r.get('positive_driver_events_en', []) or []
            pos_terms += r.get('positive_driver_events_ja', []) or []
            neg_terms += r.get('negative_driver_events_en', []) or []
            neg_terms += r.get('negative_driver_events_ja', []) or []
    pos = 0
    neg = 0
    for t in pos_terms:
        s = str(t).strip()
        if not s:
            continue
        if (s.lower() in lower) if s.isascii() else (s in text):
            pos += 1
    for t in neg_terms:
        s = str(t).strip()
        if not s:
            continue
        if (s.lower() in lower) if s.isascii() else (s in text):
            neg += 1
    return (pos - neg) / (pos + neg + 1.0)


def add_tone_to_links(links: pd.DataFrame, news_df: pd.DataFrame, theme_profiles: pd.DataFrame, driver_profiles: pd.DataFrame) -> pd.DataFrame:
    if links.empty:
        links['tone'] = []
        return links
    news_text = news_df.set_index('story_id')['clean_text'].to_dict()
    theme_map = theme_profiles.set_index('theme_id')
    rows = []
    for _, row in links.iterrows():
        theme_id = row['theme_id']
        txt = news_text.get(row['story_id'], '')
        theme_row = theme_map.loc[theme_id]
        drv_rows = driver_profiles[driver_profiles['theme_id'] == theme_id]
        r = row.to_dict()
        r['tone'] = theme_specific_tone(txt, theme_row, drv_rows)
        rows.append(r)
    return pd.DataFrame(rows)
