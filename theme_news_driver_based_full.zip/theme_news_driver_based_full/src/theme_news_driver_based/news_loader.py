from __future__ import annotations

from pathlib import Path
from typing import Any
import pandas as pd

from .text_utils import safe_list, build_clean_text


def open_lseg_session():
    import lseg.data as ld
    ld.open_session()
    return ld


def _pick_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    lower_map = {str(c).lower(): c for c in df.columns}
    for cand in candidates:
        if cand in df.columns:
            return cand
        if cand.lower() in lower_map:
            return lower_map[cand.lower()]
    return None


def _make_news_storage_safe(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if 'timestamp_utc' in out.columns:
        ts_utc = pd.to_datetime(out['timestamp_utc'], errors='coerce', utc=True)
        out['timestamp_utc'] = ts_utc.dt.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        ts_jst = ts_utc.dt.tz_convert('Asia/Tokyo')
        out['timestamp_jst'] = ts_jst.dt.strftime('%Y-%m-%dT%H:%M:%S.%f%z')
        out['date_jst'] = ts_jst.dt.strftime('%Y-%m-%d')
    if 'retrieved_at_utc' in out.columns:
        ret = pd.to_datetime(out['retrieved_at_utc'], errors='coerce', utc=True)
        out['retrieved_at_utc'] = ret.dt.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
    for col in ['topics', 'related_rics', 'related_rics_lseg']:
        if col in out.columns:
            out[col] = out[col].apply(safe_list)
    for col in ['story_id', 'headline', 'source', 'language', 'query_name', 'query_type', 'timestamp_source', 'story_text', 'clean_text']:
        if col in out.columns:
            out[col] = out[col].fillna('').astype(str)
    return out


def normalize_headlines_df(df: pd.DataFrame, query_name: str, query_type: str = 'unknown') -> pd.DataFrame:
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=[
            'story_id', 'headline', 'timestamp_utc', 'timestamp_jst', 'date_jst', 'timestamp_source',
            'source', 'language', 'topics', 'related_rics', 'related_rics_lseg', 'query_name', 'query_type',
            'retrieved_at_utc'
        ])
    out = df.copy()
    story_col = _pick_col(out, ['storyId', 'story_id', 'StoryId', 'Story ID', 'storyID'])
    headline_col = _pick_col(out, ['headline', 'Headline', 'text', 'Text', 'storyHeadline'])
    time_col = _pick_col(out, ['versionCreated', 'firstCreated', 'created', 'timestamp', 'Timestamp', 'Date', 'date', 'Time', 'time'])
    source_col = _pick_col(out, ['source', 'Source', 'provider'])
    lang_col = _pick_col(out, ['language', 'Language'])
    topics_col = _pick_col(out, ['topics', 'Topics', 'topic', 'Topic'])
    rics_col = _pick_col(out, ['related_rics', 'relatedRics', 'relatedRICs', 'Related RICs', 'RIC', 'rics', 'Rics', 'subjects', 'Subjects'])
    if story_col is None:
        raise ValueError(f'Cannot find story id column. columns={list(out.columns)}')
    norm = pd.DataFrame()
    norm['story_id'] = out[story_col].astype(str).str.strip()
    norm['headline'] = out[headline_col].astype(str) if headline_col else ''
    if time_col:
        norm['timestamp_utc'] = pd.to_datetime(out[time_col], errors='coerce', utc=True)
        norm['timestamp_source'] = time_col
    else:
        norm['timestamp_utc'] = pd.NaT
        norm['timestamp_source'] = 'missing'
    norm['retrieved_at_utc'] = pd.Timestamp.now(tz='UTC')
    mask_nat = norm['timestamp_utc'].isna()
    norm.loc[mask_nat, 'timestamp_utc'] = norm.loc[mask_nat, 'retrieved_at_utc']
    norm.loc[mask_nat, 'timestamp_source'] = 'retrieved_at_fallback'
    norm['source'] = out[source_col].astype(str) if source_col else ''
    norm['language'] = out[lang_col].astype(str) if lang_col else ''
    norm['topics'] = out[topics_col].apply(safe_list) if topics_col else [[] for _ in range(len(out))]
    norm['related_rics_lseg'] = out[rics_col].apply(safe_list) if rics_col else [[] for _ in range(len(out))]
    norm['related_rics'] = norm['related_rics_lseg']
    norm['query_name'] = query_name
    norm['query_type'] = query_type
    norm = norm[norm['story_id'].notna() & norm['story_id'].astype(str).str.len().gt(0) & norm['story_id'].astype(str).ne('nan')].copy()
    norm = norm.drop_duplicates(['story_id', 'query_name']).reset_index(drop=True)
    return _make_news_storage_safe(norm)


def fetch_headlines(ld, query: str, start: str, end: str, count: int) -> pd.DataFrame:
    return ld.news.get_headlines(query=query, start=start, end=end, count=count)


def fetch_story_text(ld, story_id: str) -> str:
    try:
        return ld.news.get_story(story_id, format=ld.news.Format.TEXT) or ''
    except Exception:
        return ''


def _date_windows(start: str, end: str, split_by: str | None) -> list[tuple[str, str]]:
    if not split_by or split_by.lower() == 'none':
        return [(start, end)]
    s = pd.to_datetime(start, utc=True)
    e = pd.to_datetime(end, utc=True)
    freq = 'D' if str(split_by).upper() == 'D' else 'W'
    breaks = list(pd.date_range(s, e, freq=freq))
    pts = [s] + [b for b in breaks if s < b < e] + [e]
    return [(pts[i].isoformat(), pts[i + 1].isoformat()) for i in range(len(pts) - 1)]


def fetch_lseg_news(cfg: dict, queries: dict, theme_profiles: pd.DataFrame) -> pd.DataFrame:
    ld = open_lseg_session()
    news_cfg = cfg['news']
    frames: list[pd.DataFrame] = []
    start, end = news_cfg['start'], news_cfg['end']
    count = int(news_cfg.get('count_per_query', 100))
    split_by = news_cfg.get('split_by', 'none')
    windows = _date_windows(start, end, split_by)

    for qname, qdef in (queries.get('news_queries') or {}).items():
        if qname in {'settings', 'by_constituent'}:
            continue
        if isinstance(qdef, dict) and qdef.get('query'):
            query_type = qdef.get('query_type', 'broad_market')
            for ws, we in windows:
                raw = fetch_headlines(ld, qdef['query'], ws, we, count)
                frames.append(normalize_headlines_df(raw, qname, query_type=query_type))

    ric_cfg = cfg.get('ric_queries', {}) or {}
    if ric_cfg.get('enabled', False):
        templates = ((queries.get('news_queries') or {}).get('by_constituent') or {})
        template = templates.get('template_en') or 'R:{ric} AND Language:LEN AND Source:RTRS'
        max_rics_per_theme = ric_cfg.get('max_rics_per_theme')
        rics: list[str] = []
        for _, row in theme_profiles.iterrows():
            vals = row.get('entity_rics', []) or []
            vals = vals[:int(max_rics_per_theme)] if max_rics_per_theme else vals
            rics.extend(vals)
        for ric in sorted(set(rics)):
            for ws, we in windows:
                raw = fetch_headlines(ld, template.format(ric=ric), ws, we, count)
                tmp = normalize_headlines_df(raw, f'ric_{ric}', query_type='constituent_ric')
                tmp['related_rics'] = tmp['related_rics'].apply(lambda xs: sorted(set(list(xs) + [ric])))
                frames.append(tmp)

    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    if news_cfg.get('deduplicate_by_story_id', True):
        df = df.sort_values(['story_id', 'query_type']).drop_duplicates('story_id').reset_index(drop=True)
    if news_cfg.get('fetch_stories', False):
        df['story_text'] = [fetch_story_text(ld, sid) for sid in df['story_id'].astype(str)]
    else:
        df['story_text'] = ''
    df['clean_text'] = [build_clean_text(h, b) for h, b in zip(df['headline'], df['story_text'])]
    return _make_news_storage_safe(df)


def make_mock_news(theme_profiles: pd.DataFrame, driver_profiles: pd.DataFrame | None = None) -> pd.DataFrame:
    rows = []
    base = pd.Timestamp('2026-04-01', tz='UTC')
    for i, row in theme_profiles.iterrows():
        theme_id = row['theme_id']
        theme_ja = row.get('theme_name_ja') or row.get('theme_name_en')
        rics = (row.get('entity_rics', []) or [])[:3]
        drv = ''
        if driver_profiles is not None and not driver_profiles.empty:
            sub = driver_profiles[driver_profiles['theme_id'] == theme_id]
            if not sub.empty:
                drv = str(sub.iloc[0].get('driver_name_ja') or sub.iloc[0].get('driver_name_en') or '')
        text = f'{theme_ja} 関連で {drv} に関する受注増と設備投資拡大のニュース。'
        rows.append({
            'story_id': f'MOCK{i:04d}',
            'headline': f'{theme_ja} 関連ニュース: {drv}',
            'story_text': text,
            'clean_text': build_clean_text(f'{theme_ja} 関連ニュース: {drv}', text),
            'timestamp_utc': base + pd.Timedelta(days=i),
            'timestamp_source': 'mock',
            'source': 'MOCK',
            'language': 'JA',
            'topics': [],
            'related_rics': rics,
            'related_rics_lseg': rics,
            'query_name': 'mock',
            'query_type': 'mock',
            'retrieved_at_utc': pd.Timestamp.now(tz='UTC'),
        })
    return _make_news_storage_safe(pd.DataFrame(rows))
