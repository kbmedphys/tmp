from __future__ import annotations

import re
from typing import Any
import pandas as pd


def safe_list(x: Any) -> list[str]:
    if x is None:
        return []
    try:
        if pd.isna(x):
            return []
    except Exception:
        pass
    if isinstance(x, list):
        return [str(v).strip() for v in x if str(v).strip()]
    if isinstance(x, tuple) or isinstance(x, set):
        return [str(v).strip() for v in x if str(v).strip()]
    s = str(x).strip()
    if not s:
        return []
    if s.startswith('[') and s.endswith(']'):
        try:
            import ast
            vals = ast.literal_eval(s)
            if isinstance(vals, list):
                return [str(v).strip() for v in vals if str(v).strip()]
        except Exception:
            pass
    for sep in [',', ';', '|']:
        if sep in s:
            return [v.strip() for v in s.split(sep) if v.strip()]
    return [s]


def normalize_text(text: Any) -> str:
    if text is None:
        return ''
    s = str(text)
    s = re.sub(r'<[^>]+>', ' ', s)
    s = re.sub(r'\s+', ' ', s)
    return s.strip()


def build_clean_text(headline: Any, story_text: Any = '') -> str:
    h = normalize_text(headline)
    b = normalize_text(story_text)
    return f'{h}. {b}'.strip() if b else h


def keyword_score(text: str, terms_en: list[str] | None, terms_ja: list[str] | None) -> float:
    text = text or ''
    lower = text.lower()
    hits = 0
    total = 0
    for term in terms_en or []:
        term = str(term).strip()
        if not term:
            continue
        total += 1
        if term.lower() in lower:
            hits += 1
    for term in terms_ja or []:
        term = str(term).strip()
        if not term:
            continue
        total += 1
        if term in text:
            hits += 1
    if total == 0:
        return 0.0
    return min(1.0, hits / max(3.0, total ** 0.5))
