from __future__ import annotations

from pathlib import Path
from typing import Any
import yaml


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_yaml(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    with path.open('r', encoding='utf-8') as f:
        return yaml.safe_load(f) or {}


def load_config(path: str | Path = 'configs/config.yaml') -> dict[str, Any]:
    p = Path(path)
    if not p.is_absolute():
        p = project_root() / p
    return load_yaml(p)


def resolve_path(path: str | Path) -> Path:
    p = Path(path)
    if not p.is_absolute():
        p = project_root() / p
    return p


def ensure_parent(path: str | Path) -> Path:
    p = resolve_path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p
