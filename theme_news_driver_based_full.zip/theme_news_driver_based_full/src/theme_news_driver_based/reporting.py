from __future__ import annotations

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt


def save_latest_score_table(features: pd.DataFrame, out_path: str | Path, top_n: int = 50) -> pd.DataFrame:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    latest_date = features['date'].max()
    cols = [c for c in ['date', 'theme_id', 'theme_score', 'buzz', 'tone', 'driver_breadth', 'entity_breadth', 'mentions', 'weighted_mentions'] if c in features.columns]
    latest = features.loc[features['date'] == latest_date, cols].sort_values('theme_score', ascending=False).head(top_n)
    latest.to_csv(out_path, index=False, encoding='utf-8-sig')
    return latest


def plot_theme_score_timeseries(features: pd.DataFrame, out_path: str | Path, top_n: int = 10) -> None:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if features.empty:
        return
    plot_df = features.pivot_table(index='date', columns='theme_id', values='theme_score', aggfunc='last').sort_index()
    latest_date = features['date'].max()
    top_themes = features.loc[features['date'] == latest_date].sort_values('theme_score', ascending=False).head(top_n)['theme_id'].tolist()
    fig, ax = plt.subplots(figsize=(14, 7))
    for col in top_themes:
        if col in plot_df.columns:
            ax.plot(plot_df.index, plot_df[col], label=col, linewidth=1.5)
    ax.axhline(0, linestyle='--', linewidth=1)
    ax.set_title(f'ThemeScore Time Series: Top {top_n} Themes')
    ax.set_xlabel('Date')
    ax.set_ylabel('ThemeScore')
    ax.legend(loc='center left', bbox_to_anchor=(1.0, 0.5), fontsize=8)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches='tight')
    plt.close(fig)


def plot_selected_theme_heatmap(weights: pd.DataFrame, out_path: str | Path) -> None:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if weights.empty:
        return
    w = weights.copy()
    w['selected'] = (w['theme_weight'] > 0).astype(int)
    mat = w.pivot_table(index='theme_id', columns='date', values='selected', aggfunc='max', fill_value=0)
    mat = mat.loc[mat.sum(axis=1).sort_values(ascending=False).index]
    fig, ax = plt.subplots(figsize=(16, max(5, 0.3 * len(mat))))
    im = ax.imshow(mat.values, aspect='auto', interpolation='nearest')
    ax.set_title('Selected Top Themes Over Time')
    ax.set_xlabel('Date')
    ax.set_ylabel('Theme ID')
    dates = list(mat.columns)
    step = max(1, len(dates) // 10)
    ax.set_xticks(range(0, len(dates), step))
    ax.set_xticklabels([pd.to_datetime(dates[i]).strftime('%Y-%m-%d') for i in range(0, len(dates), step)], rotation=45, ha='right')
    ax.set_yticks(range(len(mat.index)))
    ax.set_yticklabels(mat.index)
    plt.colorbar(im, ax=ax, label='Selected')
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
