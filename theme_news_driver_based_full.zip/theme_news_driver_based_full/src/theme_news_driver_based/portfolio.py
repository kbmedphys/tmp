from __future__ import annotations

import pandas as pd


def select_top_themes(scores: pd.DataFrame, n_top: int = 4, score_col: str = 'theme_score') -> pd.DataFrame:
    rows = []
    if scores.empty:
        return pd.DataFrame(columns=['date', 'theme_id', 'theme_weight', 'theme_score'])
    for date, sub in scores.groupby('date'):
        ranked = sub.sort_values(score_col, ascending=False).head(n_top)
        if ranked.empty:
            continue
        weight = 1.0 / len(ranked)
        for _, row in ranked.iterrows():
            rows.append({'date': date, 'theme_id': row['theme_id'], 'theme_weight': weight, 'theme_score': row[score_col]})
    return pd.DataFrame(rows)
