from __future__ import annotations

import numpy as np
import pandas as pd

from .text_utils import safe_list


def cross_sectional_zscore(df: pd.DataFrame, value_col: str, date_col: str = 'date') -> pd.Series:
    def z(x: pd.Series) -> pd.Series:
        std = x.std(ddof=0)
        if std == 0 or np.isnan(std):
            return x * 0.0
        return (x - x.mean()) / std
    return df.groupby(date_col)[value_col].transform(z)


def compute_driver_breadth(driver_links: pd.DataFrame, driver_profiles: pd.DataFrame, min_driver_sim: float = 0.45) -> pd.DataFrame:
    if driver_links.empty:
        return pd.DataFrame(columns=['date_jst', 'theme_id', 'driver_breadth_raw', 'n_active_drivers', 'n_total_drivers'])
    active = driver_links[driver_links['driver_sim'] >= min_driver_sim].groupby(['date_jst', 'theme_id'])['driver_id'].nunique().reset_index(name='n_active_drivers')
    total = driver_profiles.groupby('theme_id')['driver_id'].nunique().reset_index(name='n_total_drivers')
    out = active.merge(total, on='theme_id', how='left')
    out['driver_breadth_raw'] = out['n_active_drivers'] / out['n_total_drivers'].replace(0, pd.NA)
    out['driver_breadth_raw'] = out['driver_breadth_raw'].fillna(0.0)
    return out


def compute_entity_breadth(news_theme_links: pd.DataFrame, news_df: pd.DataFrame, theme_profiles: pd.DataFrame) -> pd.DataFrame:
    if news_theme_links.empty:
        return pd.DataFrame(columns=['date_jst', 'theme_id', 'entity_breadth_raw'])
    news_small = news_df[['story_id', 'related_rics']].copy()
    merged = news_theme_links.merge(news_small, on='story_id', how='left')
    theme_map = theme_profiles.set_index('theme_id')['entity_rics'].to_dict()
    rows = []
    for (date_jst, theme_id), sub in merged.groupby(['date_jst', 'theme_id']):
        theme_rics = set(theme_map.get(theme_id, []) or [])
        if not theme_rics:
            breadth = 0.0
        else:
            mentioned = set()
            for xs in sub['related_rics']:
                mentioned.update(safe_list(xs))
            breadth = len(theme_rics & mentioned) / len(theme_rics)
        rows.append({'date_jst': date_jst, 'theme_id': theme_id, 'entity_breadth_raw': breadth})
    return pd.DataFrame(rows)


def build_daily_theme_features_driver_based(
    news_df: pd.DataFrame,
    news_theme_links: pd.DataFrame,
    driver_links: pd.DataFrame,
    driver_profiles: pd.DataFrame,
    theme_profiles: pd.DataFrame,
    cfg: dict,
) -> pd.DataFrame:
    if news_theme_links.empty:
        return pd.DataFrame()
    feature_cfg = cfg.get('features', {}) or {}
    lookback_days = int(feature_cfg.get('buzz_lookback_days', 40))
    min_periods = int(feature_cfg.get('min_periods', 5))
    min_driver_sim = float(cfg.get('linking', {}).get('min_driver_sim', 0.45))

    links = news_theme_links.copy()
    links['date'] = pd.to_datetime(links['date_jst'], errors='coerce')

    feat = links.groupby(['date', 'theme_id']).agg(
        mentions=('story_id', 'nunique'),
        weighted_mentions=('rel_score', 'sum'),
        avg_rel_score=('rel_score', 'mean'),
        max_driver_sim=('max_driver_sim', 'mean'),
        keyword_score=('keyword_score', 'mean'),
        entity_score=('entity_score', 'mean'),
    ).reset_index()

    if 'tone' in links.columns:
        links['weighted_tone'] = links['rel_score'] * links['tone']
        tone = links.groupby(['date', 'theme_id']).agg(
            weighted_tone_sum=('weighted_tone', 'sum'),
            rel_sum=('rel_score', 'sum'),
        ).reset_index()
        tone['tone_raw'] = tone['weighted_tone_sum'] / (tone['rel_sum'] + 1e-12)
        feat = feat.merge(tone[['date', 'theme_id', 'tone_raw']], on=['date', 'theme_id'], how='left')
    else:
        feat['tone_raw'] = 0.0

    all_dates = pd.date_range(feat['date'].min(), feat['date'].max(), freq='D')
    all_themes = theme_profiles['theme_id'].tolist()
    panel = pd.MultiIndex.from_product([all_dates, all_themes], names=['date', 'theme_id']).to_frame(index=False)
    feat = panel.merge(feat, on=['date', 'theme_id'], how='left')
    for col in ['mentions', 'weighted_mentions', 'avg_rel_score', 'max_driver_sim', 'keyword_score', 'entity_score', 'tone_raw']:
        feat[col] = feat[col].fillna(0.0)

    feat = feat.sort_values(['theme_id', 'date'])
    feat['wm_log'] = np.log1p(feat['weighted_mentions'])
    feat['wm_log_ma'] = feat.groupby('theme_id')['wm_log'].transform(lambda s: s.shift(1).rolling(lookback_days, min_periods=min_periods).mean())
    feat['buzz_raw'] = feat['wm_log'] - feat['wm_log_ma'].fillna(0.0)

    drv = compute_driver_breadth(driver_links, driver_profiles, min_driver_sim=min_driver_sim)
    if not drv.empty:
        drv['date'] = pd.to_datetime(drv['date_jst'], errors='coerce')
        feat = feat.merge(drv[['date', 'theme_id', 'driver_breadth_raw']], on=['date', 'theme_id'], how='left')
    else:
        feat['driver_breadth_raw'] = 0.0
    feat['driver_breadth_raw'] = feat['driver_breadth_raw'].fillna(0.0)

    ent = compute_entity_breadth(news_theme_links, news_df, theme_profiles)
    if not ent.empty:
        ent['date'] = pd.to_datetime(ent['date_jst'], errors='coerce')
        feat = feat.merge(ent[['date', 'theme_id', 'entity_breadth_raw']], on=['date', 'theme_id'], how='left')
    else:
        feat['entity_breadth_raw'] = 0.0
    feat['entity_breadth_raw'] = feat['entity_breadth_raw'].fillna(0.0)

    feat['buzz'] = cross_sectional_zscore(feat, 'buzz_raw')
    feat['tone'] = cross_sectional_zscore(feat, 'tone_raw')
    feat['driver_breadth'] = cross_sectional_zscore(feat, 'driver_breadth_raw')
    feat['entity_breadth'] = cross_sectional_zscore(feat, 'entity_breadth_raw')

    w = feature_cfg.get('score_weights', {}) or {}
    feat['theme_score'] = (
        float(w.get('buzz', 0.35)) * feat['buzz']
        + float(w.get('tone', 0.25)) * feat['tone']
        + float(w.get('driver_breadth', 0.30)) * feat['driver_breadth']
        + float(w.get('entity_breadth', 0.10)) * feat['entity_breadth']
    )
    return feat
