from __future__ import annotations

import pandas as pd
from .text_utils import safe_list


def build_theme_embedding_text(theme: dict) -> str:
    parts = [
        f"Theme name English: {theme.get('theme_name_en', '')}",
        f"Theme name Japanese: {theme.get('theme_name_ja', '')}",
        f"Description English: {theme.get('description_en', '')}",
        f"Description Japanese: {theme.get('description_ja', '')}",
        f"Profile summary English: {theme.get('profile_summary_en', '')}",
        f"Profile summary Japanese: {theme.get('profile_summary_ja', '')}",
        'Revenue drivers: ' + '; '.join(_driver_names(theme, 'en')),
        '収益ドライバー: ' + '、'.join(_driver_names(theme, 'ja')),
        'Catalysts English: ' + '; '.join(theme.get('catalysts_en', []) or []),
        'Catalysts Japanese: ' + '、'.join(theme.get('catalysts_ja', []) or []),
        'Macro factors English: ' + '; '.join(theme.get('related_macro_factors_en', []) or []),
        'Macro factors Japanese: ' + '、'.join(theme.get('related_macro_factors_ja', []) or []),
        'Policy factors English: ' + '; '.join(theme.get('related_policy_factors_en', []) or []),
        'Policy factors Japanese: ' + '、'.join(theme.get('related_policy_factors_ja', []) or []),
    ]
    return '\n'.join([p for p in parts if p and p.strip()])


def _driver_names(theme: dict, lang: str) -> list[str]:
    key = 'driver_name_en' if lang == 'en' else 'driver_name_ja'
    return [str(d.get(key, '')).strip() for d in theme.get('revenue_drivers', []) or [] if str(d.get(key, '')).strip()]


def build_theme_profiles(themes_config: dict) -> pd.DataFrame:
    rows: list[dict] = []
    for theme in themes_config.get('themes', []):
        entity = theme.get('entity_linking_terms', {}) or {}
        related_industries = theme.get('related_industries', {}) or {}
        rows.append({
            'theme_id': theme['theme_id'],
            'theme_name_en': theme.get('theme_name_en', ''),
            'theme_name_ja': theme.get('theme_name_ja', ''),
            'theme_type': theme.get('theme_type', ''),
            'embedding_text': theme.get('embedding_text') or build_theme_embedding_text(theme),
            'keyword_terms_en': safe_list(theme.get('keyword_match_terms_en', [])) or safe_list(theme.get('catalysts_en', [])),
            'keyword_terms_ja': safe_list(theme.get('keyword_match_terms_ja', [])) or safe_list(theme.get('catalysts_ja', [])),
            'positive_events_en': safe_list(theme.get('positive_events_en', [])),
            'positive_events_ja': safe_list(theme.get('positive_events_ja', [])),
            'negative_events_en': safe_list(theme.get('negative_events_en', [])),
            'negative_events_ja': safe_list(theme.get('negative_events_ja', [])),
            'entity_rics': safe_list(entity.get('rics', [])),
            'entity_names_en': safe_list(entity.get('company_names_en', [])) + safe_list(entity.get('aliases_en', [])),
            'entity_names_ja': safe_list(entity.get('company_names_ja', [])) + safe_list(entity.get('aliases_ja', [])),
            'gics_sectors': safe_list(related_industries.get('gics_sectors', [])),
            'gics_industries': safe_list(related_industries.get('gics_industries', [])),
            'trbc_industries': safe_list(related_industries.get('trbc_industries', [])),
        })
    return pd.DataFrame(rows)


def build_driver_profiles(themes_config: dict, include_catalysts: bool = True) -> pd.DataFrame:
    rows: list[dict] = []
    for theme in themes_config.get('themes', []):
        theme_id = theme['theme_id']
        theme_name_en = theme.get('theme_name_en', '')
        theme_name_ja = theme.get('theme_name_ja', '')
        catalysts_en = safe_list(theme.get('catalysts_en', []))
        catalysts_ja = safe_list(theme.get('catalysts_ja', []))

        for i, driver in enumerate(theme.get('revenue_drivers', []) or [], start=1):
            driver_id = driver.get('driver_id') or f'{theme_id}__driver_{i:03d}'
            driver_name_en = driver.get('driver_name_en', '')
            driver_name_ja = driver.get('driver_name_ja', '')
            kws_en = safe_list(driver.get('driver_keywords_en', []))
            kws_ja = safe_list(driver.get('driver_keywords_ja', []))
            text = driver.get('driver_embedding_text') or '\n'.join([
                f'Theme English: {theme_name_en}',
                f'Theme Japanese: {theme_name_ja}',
                f'Driver English: {driver_name_en}',
                f'Driver Japanese: {driver_name_ja}',
                f"Description English: {driver.get('driver_description_en', '')}",
                f"Description Japanese: {driver.get('driver_description_ja', '')}",
                'Driver keywords English: ' + '; '.join(kws_en),
                'Driver keywords Japanese: ' + '、'.join(kws_ja),
                'Related catalysts English: ' + '; '.join(catalysts_en[:15]),
                'Related catalysts Japanese: ' + '、'.join(catalysts_ja[:15]),
            ])
            rows.append({
                'theme_id': theme_id,
                'theme_name_en': theme_name_en,
                'theme_name_ja': theme_name_ja,
                'driver_id': driver_id,
                'driver_type': driver.get('driver_type', 'revenue_driver'),
                'driver_name_en': driver_name_en,
                'driver_name_ja': driver_name_ja,
                'driver_embedding_text': text,
                'driver_keywords_en': kws_en,
                'driver_keywords_ja': kws_ja,
                'positive_driver_events_en': safe_list(driver.get('positive_driver_events_en', [])),
                'positive_driver_events_ja': safe_list(driver.get('positive_driver_events_ja', [])),
                'negative_driver_events_en': safe_list(driver.get('negative_driver_events_en', [])),
                'negative_driver_events_ja': safe_list(driver.get('negative_driver_events_ja', [])),
            })

        if include_catalysts:
            for j, c in enumerate(catalysts_en[:20], start=1):
                rows.append({
                    'theme_id': theme_id,
                    'theme_name_en': theme_name_en,
                    'theme_name_ja': theme_name_ja,
                    'driver_id': f'{theme_id}__catalyst_en_{j:03d}',
                    'driver_type': 'catalyst',
                    'driver_name_en': c,
                    'driver_name_ja': '',
                    'driver_embedding_text': f'Theme: {theme_name_en} {theme_name_ja}\nCatalyst English: {c}',
                    'driver_keywords_en': [c],
                    'driver_keywords_ja': [],
                    'positive_driver_events_en': [],
                    'positive_driver_events_ja': [],
                    'negative_driver_events_en': [],
                    'negative_driver_events_ja': [],
                })
            for j, c in enumerate(catalysts_ja[:20], start=1):
                rows.append({
                    'theme_id': theme_id,
                    'theme_name_en': theme_name_en,
                    'theme_name_ja': theme_name_ja,
                    'driver_id': f'{theme_id}__catalyst_ja_{j:03d}',
                    'driver_type': 'catalyst',
                    'driver_name_en': '',
                    'driver_name_ja': c,
                    'driver_embedding_text': f'Theme: {theme_name_en} {theme_name_ja}\nCatalyst Japanese: {c}',
                    'driver_keywords_en': [],
                    'driver_keywords_ja': [c],
                    'positive_driver_events_en': [],
                    'positive_driver_events_ja': [],
                    'negative_driver_events_en': [],
                    'negative_driver_events_ja': [],
                })
    return pd.DataFrame(rows)
