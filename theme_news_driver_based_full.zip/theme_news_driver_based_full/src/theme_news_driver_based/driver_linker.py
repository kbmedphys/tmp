from __future__ import annotations

import numpy as np
import pandas as pd

from .text_utils import keyword_score, safe_list


def entity_score(text: str, related_rics: list[str], theme_row: pd.Series) -> float:
    text = text or ''
    lower = text.lower()
    theme_rics = set(theme_row.get('entity_rics', []) or [])
    news_rics = set(related_rics or [])
    if theme_rics and news_rics and theme_rics & news_rics:
        return 1.0
    for name in theme_row.get('entity_names_en', []) or []:
        if name and str(name).lower() in lower:
            return 1.0
    for name in theme_row.get('entity_names_ja', []) or []:
        if name and str(name) in text:
            return 1.0
    return 0.0


def get_weights(query_type: str, cfg: dict) -> dict:
    weights_cfg = cfg.get('linking', {}).get('weights_by_query_type', {})
    return weights_cfg.get(query_type) or weights_cfg.get('default') or {
        'theme_embedding': 0.30,
        'driver_embedding': 0.45,
        'keyword': 0.20,
        'entity': 0.05,
    }


def build_news_driver_links(news_df: pd.DataFrame, driver_profiles: pd.DataFrame, news_driver_sim: np.ndarray, min_driver_sim: float = 0.45) -> pd.DataFrame:
    rows = []
    news_reset = news_df.reset_index(drop=True)
    drv_reset = driver_profiles.reset_index(drop=True)
    for i, nrow in news_reset.iterrows():
        for j, drow in drv_reset.iterrows():
            sim = float(news_driver_sim[i, j])
            if sim < min_driver_sim:
                continue
            rows.append({
                'story_id': nrow['story_id'],
                'date_jst': nrow.get('date_jst', ''),
                'query_type': nrow.get('query_type', ''),
                'theme_id': drow['theme_id'],
                'driver_id': drow['driver_id'],
                'driver_type': drow.get('driver_type', ''),
                'driver_name_en': drow.get('driver_name_en', ''),
                'driver_name_ja': drow.get('driver_name_ja', ''),
                'driver_sim': sim,
                'headline': nrow.get('headline', ''),
            })
    return pd.DataFrame(rows)


def aggregate_driver_sim_by_theme(driver_links: pd.DataFrame) -> pd.DataFrame:
    if driver_links.empty:
        return pd.DataFrame(columns=['story_id', 'theme_id', 'max_driver_sim', 'avg_top_driver_sim', 'matched_driver_ids', 'matched_driver_names_ja'])

    def top_avg(x: pd.Series, n: int = 3) -> float:
        return float(x.sort_values(ascending=False).head(n).mean())

    return driver_links.groupby(['story_id', 'theme_id']).agg(
        max_driver_sim=('driver_sim', 'max'),
        avg_top_driver_sim=('driver_sim', top_avg),
        matched_driver_ids=('driver_id', lambda x: list(dict.fromkeys(x))),
        matched_driver_names_ja=('driver_name_ja', lambda x: [v for v in dict.fromkeys(x) if v]),
    ).reset_index()


def build_news_theme_links_driver_based(news_df: pd.DataFrame, theme_profiles: pd.DataFrame, theme_sim_matrix: np.ndarray, driver_theme_agg: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    threshold = float(cfg.get('linking', {}).get('threshold', 0.50))
    driver_map = {(r['story_id'], r['theme_id']): r for _, r in driver_theme_agg.iterrows()}
    rows = []
    news_reset = news_df.reset_index(drop=True)
    theme_reset = theme_profiles.reset_index(drop=True)
    for i, nrow in news_reset.iterrows():
        text = nrow.get('clean_text', '') or nrow.get('headline', '')
        query_type = nrow.get('query_type', 'default')
        related_rics = safe_list(nrow.get('related_rics', []))
        weights = get_weights(query_type, cfg)
        for j, trow in theme_reset.iterrows():
            theme_id = trow['theme_id']
            theme_sim = float(theme_sim_matrix[i, j])
            theme_sim01 = (theme_sim + 1.0) / 2.0
            drv = driver_map.get((nrow['story_id'], theme_id))
            if drv is not None:
                max_driver_sim = float(drv['max_driver_sim'])
                avg_top_driver_sim = float(drv['avg_top_driver_sim'])
                matched_driver_ids = drv['matched_driver_ids']
                matched_driver_names_ja = drv['matched_driver_names_ja']
            else:
                max_driver_sim = 0.0
                avg_top_driver_sim = 0.0
                matched_driver_ids = []
                matched_driver_names_ja = []
            kw = keyword_score(text, trow.get('keyword_terms_en', []), trow.get('keyword_terms_ja', []))
            ent = entity_score(text, related_rics, trow)
            rel = (
                float(weights.get('theme_embedding', 0.0)) * theme_sim01
                + float(weights.get('driver_embedding', 0.0)) * max_driver_sim
                + float(weights.get('keyword', 0.0)) * kw
                + float(weights.get('entity', 0.0)) * ent
            )
            if rel >= threshold:
                rows.append({
                    'story_id': nrow['story_id'],
                    'date_jst': nrow.get('date_jst', ''),
                    'query_type': query_type,
                    'theme_id': theme_id,
                    'theme_sim': theme_sim01,
                    'max_driver_sim': max_driver_sim,
                    'avg_top_driver_sim': avg_top_driver_sim,
                    'keyword_score': kw,
                    'entity_score': ent,
                    'rel_score': rel,
                    'matched_driver_ids': matched_driver_ids,
                    'matched_driver_names_ja': matched_driver_names_ja,
                    'headline': nrow.get('headline', ''),
                })
    return pd.DataFrame(rows)
