from __future__ import annotations

from pathlib import Path
import pandas as pd


def save_df(df: pd.DataFrame, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    if suffix == '.csv':
        df.to_csv(path, index=False, encoding='utf-8-sig')
    elif suffix in {'.pkl', '.pickle'}:
        df.to_pickle(path)
    elif suffix == '.parquet':
        df.to_parquet(path, index=False)
    else:
        df.to_pickle(path)


def load_df(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == '.csv':
        return pd.read_csv(path)
    if suffix in {'.pkl', '.pickle'}:
        return pd.read_pickle(path)
    if suffix == '.parquet':
        return pd.read_parquet(path)
    return pd.read_pickle(path)
