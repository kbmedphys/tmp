from __future__ import annotations

import numpy as np


class EmbeddingBackend:
    def encode(self, texts: list[str]) -> np.ndarray:
        raise NotImplementedError


class SentenceTransformerBackend(EmbeddingBackend):
    def __init__(self, model_name: str, batch_size: int = 64):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)
        self.batch_size = batch_size

    def encode(self, texts: list[str]) -> np.ndarray:
        return self.model.encode(
            texts,
            batch_size=self.batch_size,
            show_progress_bar=True,
            normalize_embeddings=True,
        )


class TfidfBackend(EmbeddingBackend):
    def __init__(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        self.vectorizer = TfidfVectorizer(max_features=50000, ngram_range=(1, 2))
        self._fit = False

    def fit(self, texts: list[str]) -> None:
        self.vectorizer.fit(texts)
        self._fit = True

    def encode(self, texts: list[str]) -> np.ndarray:
        if not self._fit:
            self.fit(texts)
        arr = self.vectorizer.transform(texts).astype(float)
        dense = arr.toarray()
        norm = np.linalg.norm(dense, axis=1, keepdims=True)
        norm[norm == 0] = 1.0
        return dense / norm


def build_embedding_backend(cfg: dict, all_fit_texts: list[str] | None = None) -> EmbeddingBackend:
    emb_cfg = cfg.get('embedding', {}) or {}
    backend = emb_cfg.get('backend', 'tfidf')
    if backend == 'sentence_transformers':
        return SentenceTransformerBackend(emb_cfg.get('model_name', 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'), int(emb_cfg.get('batch_size', 64)))
    tfidf = TfidfBackend()
    if all_fit_texts:
        tfidf.fit(all_fit_texts)
    return tfidf


def cosine_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return a @ b.T
