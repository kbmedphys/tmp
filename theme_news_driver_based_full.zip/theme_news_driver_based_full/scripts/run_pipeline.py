from __future__ import annotations

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / 'src'))

from theme_news_driver_based.pipeline import run_pipeline


if __name__ == '__main__':
    results = run_pipeline(PROJECT_ROOT / 'configs/config.yaml')
    for k, v in results.items():
        print(f'{k}: shape={getattr(v, "shape", None)}')
