# Suggested dependencies

Use uv in the shared base environment:

```bash
cd ~/workspace/envs/base
uv add pandas numpy pyyaml scikit-learn matplotlib beautifulsoup4 pyarrow sentence-transformers lseg-data
```

If `sentence-transformers` is unavailable, set `embedding.backend: tfidf` in `configs/config.yaml`.
