# Project Rules

- ルートの `~/workspace/AGENTS.md` を優先して読むこと。
- Python は `~/workspace/envs/base/.venv/bin/python` を明示して使うこと。
- conda/poetry/pipenv は使わないこと。
- 依存が不足する場合は `cd ~/workspace/envs/base && uv add ...` を提案すること。
- 出力は `outputs/` 以下に保存すること。
- raw news は list列やtimestamp列が混ざるため、初期検証では pickle 保存を推奨する。
