# Theme News Driver Based Rotation

Broad LSEG News + Revenue Driver Based Theme Rotation の再現実装です。

## 目的

RIC単位で膨大なニュースを取得する代わりに、Broad queryで日本市場・政策・産業・スタイルイベントニュースを取得し、テーマ定義から作成した収益ドライバー embedding によってニュースをテーマへ多ラベル帰属します。

## 実行

```bash
cd ~/workspace/projects/theme_news_driver_based_full
~/workspace/envs/base/.venv/bin/python scripts/run_pipeline.py
```

この配布版では `configs/config.yaml` の `news.mode: mock` で動作確認できます。

LSEGを使う場合:

```yaml
news:
  mode: lseg
```

SentenceTransformerを使う場合:

```yaml
embedding:
  backend: sentence_transformers
  model_name: data/model/paraphrase-multilingual-MiniLM-L12-v2
```

## 入力

- `configs/theme_profiles.yaml`: 拡張済みtheme definition
- `configs/lseg_queries.yaml`: Broad query定義
- `configs/config.yaml`: 実行設定

## 出力

- `data/interim/news_driver_links.pkl`
- `data/interim/news_theme_links.pkl`
- `data/processed/theme_news_features_daily.pkl`
- `data/processed/theme_weights.pkl`
- `outputs/tables/theme_scores_latest.csv`
- `outputs/figures/theme_score_timeseries_top10.png`
- `outputs/figures/selected_theme_heatmap.png`

## ThemeScore

```text
ThemeScore = 0.35 * Buzz + 0.25 * Tone + 0.30 * DriverBreadth + 0.10 * EntityBreadth
```
