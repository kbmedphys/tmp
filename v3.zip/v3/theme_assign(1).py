"""類似度計算と多ラベル付与。"""

from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd



def _normalize_rows(vectors: np.ndarray) -> np.ndarray:
    if vectors.size == 0:
        return vectors
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms = np.where(norms == 0.0, 1.0, norms)
    return vectors / norms



def build_theme_memory_items(
    articles_df: pd.DataFrame,
    scores_df: pd.DataFrame,
    article_embeddings: np.ndarray,
    theme_df: pd.DataFrame,
    min_relevance: float,
    lookback_days: int,
    half_life_days: int,
    max_items: int,
) -> pd.DataFrame:
    if articles_df.empty or scores_df.empty:
        return pd.DataFrame(columns=["theme_id", "article_id", "published_at", "relevance_score", "recency_weight", "memory_weight", "embedding"]) 

    top_scores = scores_df[(scores_df["over_threshold"]) & (scores_df["similarity"] >= float(min_relevance))].copy()
    if top_scores.empty:
        return pd.DataFrame(columns=["theme_id", "article_id", "published_at", "relevance_score", "recency_weight", "memory_weight", "embedding"])

    art_meta = articles_df[["article_id", "published_at"]].copy()
    art_meta["published_at"] = pd.to_datetime(art_meta["published_at"], errors="coerce")
    merged = top_scores.merge(art_meta, on="article_id", how="left")
    merged = merged.dropna(subset=["published_at"]).copy()
    if merged.empty:
        return pd.DataFrame(columns=["theme_id", "article_id", "published_at", "relevance_score", "recency_weight", "memory_weight", "embedding"])

    max_date = merged["published_at"].max()
    min_date = max_date - pd.Timedelta(days=max(1, int(lookback_days)) - 1)
    merged = merged[merged["published_at"] >= min_date].copy()
    if merged.empty:
        return pd.DataFrame(columns=["theme_id", "article_id", "published_at", "relevance_score", "recency_weight", "memory_weight", "embedding"])

    article_index = {str(article_id): idx for idx, article_id in enumerate(articles_df["article_id"].astype(str).tolist())}
    lambda_decay = np.log(2.0) / max(float(half_life_days), 1.0)

    rows: list[dict[str, object]] = []
    for _, row in merged.iterrows():
        article_id = str(row["article_id"])
        idx = article_index.get(article_id)
        if idx is None:
            continue
        age_days = max((max_date - pd.Timestamp(row["published_at"])).days, 0)
        recency_weight = float(np.exp(-lambda_decay * age_days))
        relevance_score = float(row["similarity"])
        memory_weight = recency_weight * relevance_score
        rows.append(
            {
                "theme_id": str(row["theme_id"]),
                "article_id": article_id,
                "published_at": pd.Timestamp(row["published_at"]),
                "relevance_score": relevance_score,
                "recency_weight": recency_weight,
                "memory_weight": memory_weight,
                "embedding": article_embeddings[idx].astype(float).tolist(),
            }
        )

    out = pd.DataFrame(rows)
    if out.empty:
        return pd.DataFrame(columns=["theme_id", "article_id", "published_at", "relevance_score", "recency_weight", "memory_weight", "embedding"])

    out = out.sort_values(["theme_id", "memory_weight", "published_at"], ascending=[True, False, False])
    out = out.groupby("theme_id", group_keys=False).head(int(max_items)).reset_index(drop=True)
    theme_ids = set(theme_df["theme_id"].astype(str).tolist())
    out = out[out["theme_id"].isin(theme_ids)].reset_index(drop=True)
    return out



def build_theme_memory_snapshot(
    memory_items_df: pd.DataFrame,
    theme_df: pd.DataFrame,
) -> tuple[pd.DataFrame, np.ndarray]:
    theme_ids = theme_df["theme_id"].astype(str).tolist()
    if memory_items_df.empty:
        dim = 0
        snapshot = pd.DataFrame({"theme_id": theme_ids, "memory_size": 0, "memory_total_weight": 0.0})
        return snapshot, np.zeros((len(theme_ids), dim), dtype=float)

    first_embedding = np.array(memory_items_df.iloc[0]["embedding"], dtype=float)
    dim = int(first_embedding.shape[0])
    vector_map: dict[str, np.ndarray] = {}
    rows: list[dict[str, object]] = []

    for theme_id in theme_ids:
        group = memory_items_df[memory_items_df["theme_id"].astype(str) == theme_id].copy()
        if group.empty:
            vector_map[theme_id] = np.zeros(dim, dtype=float)
            rows.append({"theme_id": theme_id, "memory_size": 0, "memory_total_weight": 0.0})
            continue

        embeddings = np.vstack(group["embedding"].apply(lambda x: np.array(x, dtype=float)).values)
        weights = group["memory_weight"].astype(float).to_numpy()
        total_weight = float(weights.sum())
        if total_weight <= 0:
            memory_vec = np.zeros(dim, dtype=float)
        else:
            memory_vec = np.average(embeddings, axis=0, weights=weights)
        vector_map[theme_id] = memory_vec
        rows.append({"theme_id": theme_id, "memory_size": int(len(group)), "memory_total_weight": total_weight})

    embedding_matrix = np.vstack([vector_map[theme_id] for theme_id in theme_ids])
    embedding_matrix = _normalize_rows(embedding_matrix)
    snapshot = pd.DataFrame(rows)
    return snapshot, embedding_matrix



def combine_theme_embeddings(
    theme_df: pd.DataFrame,
    core_embeddings: np.ndarray,
    basket_embeddings: np.ndarray | None = None,
    memory_embeddings: np.ndarray | None = None,
    core_weight: float = 0.7,
    basket_weight: float = 0.3,
    memory_weight: float = 0.0,
) -> tuple[pd.DataFrame, np.ndarray]:
    theme_ids = theme_df["theme_id"].astype(str).tolist()
    if core_embeddings.ndim != 2:
        raise ValueError("core_embeddings は 2 次元である必要があります。")
    n_themes, dim = core_embeddings.shape
    combined = np.zeros((n_themes, dim), dtype=float)
    combined += float(core_weight) * core_embeddings
    if basket_embeddings is not None and basket_embeddings.size > 0:
        combined += float(basket_weight) * basket_embeddings
    if memory_embeddings is not None and memory_embeddings.size > 0:
        combined += float(memory_weight) * memory_embeddings
    combined = _normalize_rows(combined)
    info = pd.DataFrame(
        {
            "theme_id": theme_ids,
            "core_weight": float(core_weight),
            "basket_weight": float(basket_weight),
            "memory_weight": float(memory_weight),
        }
    )
    return info, combined



def build_similarity_scores(
    article_ids: Iterable[str],
    article_embeddings: np.ndarray,
    theme_df: pd.DataFrame,
    theme_embeddings: np.ndarray,
    default_threshold: float,
    use_theme_specific_threshold: bool,
    top_k: int,
    theme_core_embeddings: np.ndarray | None = None,
    theme_basket_embeddings: np.ndarray | None = None,
    theme_memory_embeddings: np.ndarray | None = None,
    constituent_df: pd.DataFrame | None = None,
    constituent_embeddings: np.ndarray | None = None,
    enable_margin_filter: bool = False,
    default_margin_threshold: float = 0.0,
    enable_breadth_gate: bool = False,
    default_min_constituent_breadth: float = 0.0,
) -> pd.DataFrame:
    article_ids_list = list(article_ids)
    if article_embeddings.ndim != 2 or theme_embeddings.ndim != 2:
        raise ValueError("embedding 行列は 2 次元である必要があります。")

    score_matrix = np.matmul(article_embeddings, theme_embeddings.T)
    core_score_matrix = np.matmul(article_embeddings, theme_core_embeddings.T) if theme_core_embeddings is not None and theme_core_embeddings.size > 0 else None
    basket_score_matrix = np.matmul(article_embeddings, theme_basket_embeddings.T) if theme_basket_embeddings is not None and theme_basket_embeddings.size > 0 else None
    memory_score_matrix = np.matmul(article_embeddings, theme_memory_embeddings.T) if theme_memory_embeddings is not None and theme_memory_embeddings.size > 0 else None

    constituent_theme_groups: dict[str, pd.DataFrame] = {}
    constituent_score_matrix = None
    if constituent_df is not None and not constituent_df.empty and constituent_embeddings is not None and constituent_embeddings.size > 0:
        constituent_score_matrix = np.matmul(article_embeddings, constituent_embeddings.T)
        work = constituent_df.copy().reset_index(drop=True)
        work["weight"] = pd.to_numeric(work["weight"], errors="coerce").fillna(0.0)
        for theme_id, group in work.groupby("theme_id"):
            constituent_theme_groups[str(theme_id)] = group

    rows: list[dict[str, object]] = []
    for article_idx, article_id in enumerate(article_ids_list):
        similarities = score_matrix[article_idx]
        ranking = np.argsort(-similarities)
        next_best_by_theme_idx: dict[int, float] = {}
        for pos, theme_idx in enumerate(ranking):
            next_best_by_theme_idx[theme_idx] = float(similarities[ranking[pos + 1]]) if pos + 1 < len(ranking) else float("nan")

        for rank, theme_idx in enumerate(ranking, start=1):
            theme_row = theme_df.iloc[theme_idx]
            theme_id = str(theme_row["theme_id"])
            threshold = float(default_threshold)
            if use_theme_specific_threshold:
                threshold = float(theme_row["threshold"])

            similarity = float(similarities[theme_idx])
            similarity_core = float(core_score_matrix[article_idx, theme_idx]) if core_score_matrix is not None else float("nan")
            similarity_basket = float(basket_score_matrix[article_idx, theme_idx]) if basket_score_matrix is not None else float("nan")
            similarity_memory = float(memory_score_matrix[article_idx, theme_idx]) if memory_score_matrix is not None else float("nan")
            next_best = next_best_by_theme_idx.get(theme_idx, float("nan"))
            margin_to_next = float(similarity - next_best) if not np.isnan(next_best) else float("nan")

            breadth_score = float("nan")
            breadth_coverage = float("nan")
            min_constituent_breadth = pd.to_numeric(theme_row.get("controls_min_constituent_breadth", default_min_constituent_breadth), errors="coerce")
            if pd.isna(min_constituent_breadth):
                min_constituent_breadth = float(default_min_constituent_breadth)
            if constituent_score_matrix is not None and theme_id in constituent_theme_groups:
                group = constituent_theme_groups[theme_id]
                idxs = group.index.to_numpy()
                scores = constituent_score_matrix[article_idx, idxs].astype(float)
                weights = group["weight"].to_numpy(dtype=float)
                if weights.sum() <= 0:
                    weights = np.ones_like(weights, dtype=float)
                weight_norm = weights / weights.sum()
                breadth_score = float(np.sum(weight_norm * scores))
                breadth_coverage = float(np.sum(weight_norm * (scores >= threshold)))

            margin_threshold = pd.to_numeric(theme_row.get("controls_margin_threshold", default_margin_threshold), errors="coerce")
            if pd.isna(margin_threshold):
                margin_threshold = float(default_margin_threshold)

            passes_margin = True
            if enable_margin_filter and not np.isnan(margin_to_next):
                passes_margin = margin_to_next >= float(margin_threshold)

            passes_breadth = True
            if enable_breadth_gate and not np.isnan(breadth_coverage):
                passes_breadth = breadth_coverage >= float(min_constituent_breadth)

            over_threshold = (similarity >= threshold) and passes_margin and passes_breadth
            rows.append(
                {
                    "article_id": article_id,
                    "theme_id": theme_id,
                    "theme_name_ja": str(theme_row["name_ja"]),
                    "similarity": similarity,
                    "similarity_core": similarity_core,
                    "similarity_basket": similarity_basket,
                    "similarity_memory": similarity_memory,
                    "breadth_score": breadth_score,
                    "breadth_coverage": breadth_coverage,
                    "margin_to_next": margin_to_next,
                    "similarity_rank": rank,
                    "threshold": threshold,
                    "margin_threshold": float(margin_threshold),
                    "min_constituent_breadth": float(min_constituent_breadth),
                    "over_threshold": over_threshold,
                    "is_top_k": rank <= int(top_k),
                }
            )

    return pd.DataFrame(rows)



def assign_multilabels(scores_df: pd.DataFrame) -> pd.DataFrame:
    if scores_df.empty:
        return pd.DataFrame(columns=["article_id", "theme_ids", "max_similarity", "unclassified", "assigned_by"])

    def collect_theme_ids(group: pd.DataFrame) -> list[str]:
        over = group[group["over_threshold"]].sort_values("similarity", ascending=False)
        return over["theme_id"].astype(str).tolist()

    theme_ids_series = scores_df.groupby("article_id", as_index=True).apply(collect_theme_ids)
    max_similarity = scores_df.groupby("article_id")["similarity"].max()

    assignments = pd.DataFrame(
        {
            "article_id": theme_ids_series.index,
            "theme_ids": theme_ids_series.values,
            "max_similarity": max_similarity.reindex(theme_ids_series.index).values,
        }
    )
    assignments["unclassified"] = assignments["theme_ids"].map(lambda x: len(x) == 0)
    assignments["assigned_by"] = "similarity"
    return assignments.reset_index(drop=True)



def apply_assignment_overrides(
    assignments_df: pd.DataFrame,
    bertopic_promoted_df: pd.DataFrame | None = None,
    manual_labels_df: pd.DataFrame | None = None,
) -> pd.DataFrame:
    out = assignments_df.copy()

    if bertopic_promoted_df is not None and not bertopic_promoted_df.empty:
        required = {"article_id", "theme_id"}
        if required.issubset(bertopic_promoted_df.columns):
            promoted_map = (
                bertopic_promoted_df.groupby("article_id")["theme_id"]
                .apply(lambda s: sorted(set(s.astype(str).tolist())))
                .to_dict()
            )

            mask = out["article_id"].isin(promoted_map.keys())
            out.loc[mask, "theme_ids"] = out.loc[mask, "article_id"].map(promoted_map)
            out.loc[mask, "unclassified"] = False
            out.loc[mask, "assigned_by"] = "bertopic"

    if manual_labels_df is not None and not manual_labels_df.empty:
        required = {"article_id", "theme_id"}
        if required.issubset(manual_labels_df.columns):
            manual_positive = manual_labels_df.copy()
            if "label" in manual_positive.columns:
                manual_positive = manual_positive[manual_positive["label"].astype(int) == 1]

            manual_map = (
                manual_positive.groupby("article_id")["theme_id"]
                .apply(lambda s: sorted(set(s.astype(str).tolist())))
                .to_dict()
            )
            mask = out["article_id"].isin(manual_map.keys())
            out.loc[mask, "theme_ids"] = out.loc[mask, "article_id"].map(manual_map)
            out.loc[mask, "unclassified"] = False
            out.loc[mask, "assigned_by"] = "manual"

    return out
