"""前処理。"""

from __future__ import annotations

import pandas as pd



def _truncate_text(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars]



def _join_parts(parts: list[object]) -> str:
    cleaned = [str(x).strip() for x in parts if str(x).strip()]
    return "\n".join(cleaned).strip()



def _stringify_list(values: object) -> str:
    if not isinstance(values, list):
        return ""
    return ", ".join(str(v).strip() for v in values if str(v).strip())



def _stringify_subpillars(values: object) -> str:
    if not isinstance(values, list):
        return ""
    parts: list[str] = []
    for item in values:
        if isinstance(item, dict):
            name = str(item.get("name") or "").strip()
            desc = str(item.get("description") or "").strip()
            text = ": ".join(x for x in [name, desc] if x)
            if text:
                parts.append(text)
        else:
            text = str(item).strip()
            if text:
                parts.append(text)
    return " ; ".join(parts)



def build_text_for_embedding(df: pd.DataFrame, max_body_chars: int = 1200) -> pd.DataFrame:
    out = df.copy()

    out["title"] = out["title"].fillna("").astype(str)
    out["summary"] = out["summary"].fillna("").astype(str)
    out["body"] = out["body"].fillna("").astype(str)

    out["body_short"] = out["body"].map(lambda x: _truncate_text(x, max_body_chars))

    out["text_for_embedding"] = (
        out["title"].str.strip()
        + "\n"
        + out["summary"].str.strip()
        + "\n"
        + out["body_short"].str.strip()
    ).str.strip()

    return out



def build_theme_text_views(theme_df: pd.DataFrame) -> pd.DataFrame:
    out = theme_df.copy()
    for col in [
        "description",
        "thesis_one_liner",
        "thesis_investment",
        "aliases",
        "keywords",
        "canonical_terms",
        "driver_terms",
        "related_terms",
        "exclusion_terms",
        "ambiguous_terms",
        "economic_mechanism",
        "subpillars",
        "constituent_records",
    ]:
        if col not in out.columns:
            out[col] = "" if "terms" not in col and col not in {"aliases", "keywords", "economic_mechanism", "subpillars", "constituent_records"} else []

    out["theme_text_core"] = out.apply(
        lambda row: _join_parts(
            [
                row.get("name_ja", ""),
                row.get("name_en", ""),
                row.get("description", ""),
                row.get("thesis_one_liner", ""),
                row.get("thesis_investment", ""),
                _stringify_list(row.get("aliases")),
                _stringify_list(row.get("keywords")),
                _stringify_list(row.get("canonical_terms")),
                _stringify_list(row.get("driver_terms")),
                _stringify_list(row.get("related_terms")),
                _stringify_list(row.get("economic_mechanism")),
                _stringify_subpillars(row.get("subpillars")),
            ]
        ),
        axis=1,
    )

    def basket_text(row: pd.Series) -> str:
        constituents = row.get("constituent_records", [])
        parts: list[str] = []
        if isinstance(constituents, list):
            for item in constituents:
                if not isinstance(item, dict):
                    continue
                parts.append(
                    _join_parts(
                        [
                            item.get("name", ""),
                            item.get("description", ""),
                            item.get("role", ""),
                            item.get("pillar", ""),
                            item.get("exposure_direction", ""),
                        ]
                    )
                )
        return _join_parts(parts)

    out["theme_text_basket"] = out.apply(basket_text, axis=1)
    return out



def build_constituent_texts(theme_df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for _, row in theme_df.iterrows():
        constituents = row.get("constituent_records", [])
        if not isinstance(constituents, list):
            continue
        for item in constituents:
            if not isinstance(item, dict):
                continue
            constituent_text = _join_parts(
                [
                    item.get("name", ""),
                    item.get("description", ""),
                    item.get("role", ""),
                    item.get("pillar", ""),
                    item.get("exposure_direction", ""),
                    row.get("name_ja", ""),
                ]
            )
            rows.append(
                {
                    "theme_id": str(row.get("theme_id", "")),
                    "constituent_id": str(item.get("constituent_id") or item.get("security_id") or item.get("name") or ""),
                    "security_id": str(item.get("security_id") or ""),
                    "name": str(item.get("name") or ""),
                    "weight": pd.to_numeric(item.get("weight", 0.0), errors="coerce"),
                    "role": str(item.get("role") or ""),
                    "pillar": str(item.get("pillar") or ""),
                    "exposure_direction": str(item.get("exposure_direction") or ""),
                    "constituent_text": constituent_text,
                }
            )
    out = pd.DataFrame(rows)
    if out.empty:
        return pd.DataFrame(columns=["theme_id", "constituent_id", "security_id", "name", "weight", "role", "pillar", "exposure_direction", "constituent_text"])
    out["weight"] = pd.to_numeric(out["weight"], errors="coerce").fillna(0.0)
    return out
