"""Layer A / B の最小統合例。既存ノートブックに貼り込める形。"""

from pathlib import Path
import sys

import pandas as pd

PROJECT_ROOT = Path.cwd().resolve().parent if Path.cwd().name == "notebooks" else Path.cwd().resolve()
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from news_theme_pipeline.config import build_default_config
from news_theme_pipeline.io import load_articles_csv, load_theme_definitions, save_parquet
from news_theme_pipeline.preprocess import (
    build_text_for_embedding,
    build_theme_text_views,
    build_constituent_texts,
)
from news_theme_pipeline.embed import load_embedding_model, generate_embeddings_with_cache
from news_theme_pipeline.theme_assign import (
    build_theme_memory_items,
    build_theme_memory_snapshot,
    combine_theme_embeddings,
    build_similarity_scores,
)

config = build_default_config(project_root=PROJECT_ROOT)
config.ensure_directories()

articles_df = build_text_for_embedding(load_articles_csv(config.ARTICLE_INPUT_PATH), max_body_chars=config.MAX_BODY_CHARS)
themes_df = build_theme_text_views(load_theme_definitions(config.THEME_DEF_PATH))
constituents_df = build_constituent_texts(themes_df)

model = load_embedding_model(config.EMBEDDING_MODEL_NAME)

_, article_embeddings = generate_embeddings_with_cache(
    articles_df,
    id_col="article_id",
    text_col="text_for_embedding",
    cache_path=config.ARTICLE_EMBEDDING_CACHE_PATH,
    model=model,
)

core_embed_df, theme_core_embeddings = generate_embeddings_with_cache(
    themes_df.assign(theme_text_core=themes_df["theme_text_core"].fillna(themes_df["description"])),
    id_col="theme_id",
    text_col="theme_text_core",
    cache_path=config.THEME_COMPONENT_EMBEDDING_CACHE_PATH.with_name("theme_core_embeddings.parquet"),
    model=model,
)

_, theme_basket_embeddings = generate_embeddings_with_cache(
    themes_df.assign(theme_text_basket=themes_df["theme_text_basket"].fillna("")),
    id_col="theme_id",
    text_col="theme_text_basket",
    cache_path=config.THEME_COMPONENT_EMBEDDING_CACHE_PATH.with_name("theme_basket_embeddings.parquet"),
    model=model,
)

if constituents_df.empty:
    constituent_embeddings = None
else:
    _, constituent_embeddings = generate_embeddings_with_cache(
        constituents_df,
        id_col="constituent_id",
        text_col="constituent_text",
        cache_path=config.CONSTITUENT_EMBEDDING_CACHE_PATH,
        model=model,
    )

# 第1パス: static theme で high-confidence article を作る
static_theme_info, static_theme_embeddings = combine_theme_embeddings(
    themes_df,
    core_embeddings=theme_core_embeddings,
    basket_embeddings=theme_basket_embeddings,
    memory_embeddings=None,
    core_weight=0.65,
    basket_weight=0.35,
    memory_weight=0.0,
)

first_pass_scores = build_similarity_scores(
    article_ids=articles_df["article_id"].astype(str).tolist(),
    article_embeddings=article_embeddings,
    theme_df=themes_df,
    theme_embeddings=static_theme_embeddings,
    default_threshold=config.DEFAULT_THRESHOLD,
    use_theme_specific_threshold=config.USE_THEME_SPECIFIC_THRESHOLD,
    top_k=config.SIMILARITY_TOP_K,
    theme_core_embeddings=theme_core_embeddings,
    theme_basket_embeddings=theme_basket_embeddings,
    constituent_df=constituents_df,
    constituent_embeddings=constituent_embeddings,
    enable_margin_filter=config.ENABLE_MARGIN_FILTER,
    default_margin_threshold=config.DEFAULT_MARGIN_THRESHOLD,
    enable_breadth_gate=False,
)

memory_items_df = build_theme_memory_items(
    articles_df=articles_df,
    scores_df=first_pass_scores,
    article_embeddings=article_embeddings,
    theme_df=themes_df,
    min_relevance=config.THEME_MEMORY_MIN_RELEVANCE,
    lookback_days=config.THEME_MEMORY_LOOKBACK_DAYS,
    half_life_days=config.THEME_MEMORY_HALF_LIFE_DAYS,
    max_items=config.THEME_MEMORY_MAX_ITEMS,
)

memory_daily_df, theme_memory_embeddings = build_theme_memory_snapshot(
    memory_items_df=memory_items_df,
    theme_df=themes_df,
)

# 第2パス: core + basket + memory の動的テーマ表現
final_theme_info, dynamic_theme_embeddings = combine_theme_embeddings(
    themes_df,
    core_embeddings=theme_core_embeddings,
    basket_embeddings=theme_basket_embeddings,
    memory_embeddings=theme_memory_embeddings,
    core_weight=config.THEME_CORE_WEIGHT,
    basket_weight=config.THEME_BASKET_WEIGHT,
    memory_weight=config.THEME_MEMORY_WEIGHT,
)

final_scores = build_similarity_scores(
    article_ids=articles_df["article_id"].astype(str).tolist(),
    article_embeddings=article_embeddings,
    theme_df=themes_df,
    theme_embeddings=dynamic_theme_embeddings,
    default_threshold=config.DEFAULT_THRESHOLD,
    use_theme_specific_threshold=config.USE_THEME_SPECIFIC_THRESHOLD,
    top_k=config.SIMILARITY_TOP_K,
    theme_core_embeddings=theme_core_embeddings,
    theme_basket_embeddings=theme_basket_embeddings,
    theme_memory_embeddings=theme_memory_embeddings,
    constituent_df=constituents_df,
    constituent_embeddings=constituent_embeddings,
    enable_margin_filter=config.ENABLE_MARGIN_FILTER,
    default_margin_threshold=config.DEFAULT_MARGIN_THRESHOLD,
    enable_breadth_gate=config.ENABLE_BREADTH_GATE,
    default_min_constituent_breadth=config.DEFAULT_MIN_CONSTITUENT_BREADTH,
)

save_parquet(memory_items_df, config.THEME_MEMORY_ITEMS_PATH)
save_parquet(memory_daily_df, config.THEME_MEMORY_DAILY_PATH)
save_parquet(final_theme_info, config.THEME_DYNAMIC_EMBEDDINGS_PATH)
save_parquet(final_scores, config.ARTICLE_THEME_SCORES_PATH)

print(final_scores.head())
