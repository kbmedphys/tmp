"""設定管理。"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import os
import random

import numpy as np


@dataclass
class PipelineConfig:
    """パイプライン設定。"""

    PROJECT_ROOT: Path

    EMBEDDING_MODEL_NAME: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
    THEME_DEF_PATH: Path | str = "data/raw/theme_definitions.yaml"
    SIMILARITY_TOP_K: int = 5
    DEFAULT_THRESHOLD: float = 0.42
    USE_THEME_SPECIFIC_THRESHOLD: bool = True
    ENABLE_MARGIN_FILTER: bool = True
    DEFAULT_MARGIN_THRESHOLD: float = 0.03
    ENABLE_BREADTH_GATE: bool = False
    DEFAULT_MIN_CONSTITUENT_BREADTH: float = 0.10
    THEME_CORE_WEIGHT: float = 0.60
    THEME_BASKET_WEIGHT: float = 0.25
    THEME_MEMORY_WEIGHT: float = 0.15
    THEME_MEMORY_MIN_RELEVANCE: float = 0.60
    THEME_MEMORY_LOOKBACK_DAYS: int = 30
    THEME_MEMORY_HALF_LIFE_DAYS: int = 7
    THEME_MEMORY_MAX_ITEMS: int = 300
    BERTOPIC_MIN_TOPIC_SIZE: int = 2
    BERTOPIC_NR_TOP_WORDS: int = 8
    BERTOPIC_USE_REDUCE_OUTLIERS: bool = False
    OUTLIER_RECLUSTER_MODE: str = "rolling_4w"
    OUTLIER_RECLUSTER_LOOKBACK_WEEKS: int = 4
    MIN_HIGH_CONFIDENCE_FOR_PSEUDO_LABEL: float = 0.60

    RANDOM_SEED: int = 42
    MAX_BODY_CHARS: int = 1200

    ARTICLE_INPUT_PATH: Path | str = "data/raw/news_sample.csv"
    MANUAL_LABEL_PATH: Path | str = "data/raw/manual_labels.csv"
    BERTOPIC_PROMOTED_PATH: Path | str = "data/raw/bertopic_promoted_labels.csv"

    DATA_RAW_DIR: Path = field(init=False)
    DATA_PROCESSED_DIR: Path = field(init=False)
    OUTPUTS_DIR: Path = field(init=False)
    OUTPUT_TABLES_DIR: Path = field(init=False)
    OUTPUT_FIGURES_DIR: Path = field(init=False)
    OUTPUT_LOGS_DIR: Path = field(init=False)

    ARTICLE_EMBEDDING_CACHE_PATH: Path = field(init=False)
    THEME_EMBEDDING_CACHE_PATH: Path = field(init=False)
    THEME_COMPONENT_EMBEDDING_CACHE_PATH: Path = field(init=False)
    CONSTITUENT_EMBEDDING_CACHE_PATH: Path = field(init=False)

    ARTICLE_THEME_SCORES_PATH: Path = field(init=False)
    ARTICLE_THEME_ASSIGNMENTS_PATH: Path = field(init=False)
    THEME_MEMORY_ITEMS_PATH: Path = field(init=False)
    THEME_MEMORY_DAILY_PATH: Path = field(init=False)
    THEME_DYNAMIC_EMBEDDINGS_PATH: Path = field(init=False)

    RESIDUAL_TOPICS_PATH: Path = field(init=False)
    RESIDUAL_TOPIC_KEYWORDS_PATH: Path = field(init=False)
    RESIDUAL_TOPIC_REPRESENTATIVE_DOCS_PATH: Path = field(init=False)
    RESIDUAL_OUTLIERS_PATH: Path = field(init=False)
    OUTLIER_WEEKLY_RECLUSTER_PATH: Path = field(init=False)

    LABELS_LONG_PATH: Path = field(init=False)
    LABELS_WIDE_PATH: Path = field(init=False)

    TABLE_THEME_COUNTS_PATH: Path = field(init=False)
    TABLE_UNCLASSIFIED_RATE_PATH: Path = field(init=False)
    TABLE_RESIDUAL_TOPIC_COUNTS_PATH: Path = field(init=False)
    TABLE_OUTLIER_WEEKLY_COUNTS_PATH: Path = field(init=False)

    FIG_KNOWN_THEME_TIMESERIES_PATH: Path = field(init=False)
    FIG_UNCLASSIFIED_RATE_TIMESERIES_PATH: Path = field(init=False)
    FIG_RESIDUAL_TOPIC_TIMESERIES_PATH: Path = field(init=False)
    FIG_OUTLIER_RECLUSTER_TIMESERIES_PATH: Path = field(init=False)
    FIG_OUTLIER_TOPIC_BY_WEEK_PATH: Path = field(init=False)

    def __post_init__(self) -> None:
        self.PROJECT_ROOT = Path(self.PROJECT_ROOT).resolve()

        self.DATA_RAW_DIR = self.PROJECT_ROOT / "data" / "raw"
        self.DATA_PROCESSED_DIR = self.PROJECT_ROOT / "data" / "processed"
        self.OUTPUTS_DIR = self.PROJECT_ROOT / "outputs"
        self.OUTPUT_TABLES_DIR = self.OUTPUTS_DIR / "tables"
        self.OUTPUT_FIGURES_DIR = self.OUTPUTS_DIR / "figures"
        self.OUTPUT_LOGS_DIR = self.OUTPUTS_DIR / "logs"

        self.ARTICLE_INPUT_PATH = self._resolve_path(self.ARTICLE_INPUT_PATH)
        self.THEME_DEF_PATH = self._resolve_path(self.THEME_DEF_PATH)
        self.MANUAL_LABEL_PATH = self._resolve_path(self.MANUAL_LABEL_PATH)
        self.BERTOPIC_PROMOTED_PATH = self._resolve_path(self.BERTOPIC_PROMOTED_PATH)

        self.ARTICLE_EMBEDDING_CACHE_PATH = self.DATA_PROCESSED_DIR / "article_embeddings.parquet"
        self.THEME_EMBEDDING_CACHE_PATH = self.DATA_PROCESSED_DIR / "theme_embeddings.parquet"
        self.THEME_COMPONENT_EMBEDDING_CACHE_PATH = self.DATA_PROCESSED_DIR / "theme_component_embeddings.parquet"
        self.CONSTITUENT_EMBEDDING_CACHE_PATH = self.DATA_PROCESSED_DIR / "constituent_embeddings.parquet"

        self.ARTICLE_THEME_SCORES_PATH = self.OUTPUT_TABLES_DIR / "article_theme_scores.parquet"
        self.ARTICLE_THEME_ASSIGNMENTS_PATH = self.OUTPUT_TABLES_DIR / "article_theme_assignments.parquet"
        self.THEME_MEMORY_ITEMS_PATH = self.OUTPUT_TABLES_DIR / "theme_memory_items.parquet"
        self.THEME_MEMORY_DAILY_PATH = self.OUTPUT_TABLES_DIR / "theme_memory_daily.parquet"
        self.THEME_DYNAMIC_EMBEDDINGS_PATH = self.OUTPUT_TABLES_DIR / "theme_dynamic_embeddings.parquet"

        self.RESIDUAL_TOPICS_PATH = self.OUTPUT_TABLES_DIR / "residual_topics.parquet"
        self.RESIDUAL_TOPIC_KEYWORDS_PATH = self.OUTPUT_TABLES_DIR / "residual_topic_keywords.parquet"
        self.RESIDUAL_TOPIC_REPRESENTATIVE_DOCS_PATH = self.OUTPUT_TABLES_DIR / "residual_topic_representative_docs.parquet"
        self.RESIDUAL_OUTLIERS_PATH = self.OUTPUT_TABLES_DIR / "residual_outliers.parquet"
        self.OUTLIER_WEEKLY_RECLUSTER_PATH = self.OUTPUT_TABLES_DIR / "outlier_weekly_recluster_topics.parquet"

        self.LABELS_LONG_PATH = self.DATA_PROCESSED_DIR / "labels_long.parquet"
        self.LABELS_WIDE_PATH = self.DATA_PROCESSED_DIR / "labels_wide.parquet"

        self.TABLE_THEME_COUNTS_PATH = self.OUTPUT_TABLES_DIR / "theme_article_counts.parquet"
        self.TABLE_UNCLASSIFIED_RATE_PATH = self.OUTPUT_TABLES_DIR / "unclassified_rate.parquet"
        self.TABLE_RESIDUAL_TOPIC_COUNTS_PATH = self.OUTPUT_TABLES_DIR / "residual_topic_counts.parquet"
        self.TABLE_OUTLIER_WEEKLY_COUNTS_PATH = self.OUTPUT_TABLES_DIR / "outlier_weekly_counts.parquet"

        self.FIG_KNOWN_THEME_TIMESERIES_PATH = self.OUTPUT_FIGURES_DIR / "known_theme_counts_timeseries.png"
        self.FIG_UNCLASSIFIED_RATE_TIMESERIES_PATH = self.OUTPUT_FIGURES_DIR / "unclassified_rate_timeseries.png"
        self.FIG_RESIDUAL_TOPIC_TIMESERIES_PATH = self.OUTPUT_FIGURES_DIR / "residual_topic_count_timeseries.png"
        self.FIG_OUTLIER_RECLUSTER_TIMESERIES_PATH = self.OUTPUT_FIGURES_DIR / "outlier_reclustered_theme_count_timeseries.png"
        self.FIG_OUTLIER_TOPIC_BY_WEEK_PATH = self.OUTPUT_FIGURES_DIR / "outlier_topic_count_by_week.png"

    def _resolve_path(self, path_value: Path | str) -> Path:
        path = Path(path_value)
        if path.is_absolute():
            return path
        return self.PROJECT_ROOT / path

    def ensure_directories(self) -> None:
        for directory in [
            self.DATA_RAW_DIR,
            self.DATA_PROCESSED_DIR,
            self.OUTPUTS_DIR,
            self.OUTPUT_TABLES_DIR,
            self.OUTPUT_FIGURES_DIR,
            self.OUTPUT_LOGS_DIR,
        ]:
            directory.mkdir(parents=True, exist_ok=True)



def build_default_config(project_root: Path | None = None) -> PipelineConfig:
    if project_root is None:
        project_root = Path.cwd().resolve().parent
    return PipelineConfig(PROJECT_ROOT=Path(project_root))



def set_random_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
