# 枝分かれ · テーマ定義改良提案

**User:**   
**Created:** 4/15/2026 20:55:17  
**Updated:** 4/16/2026 0:35:24  
**Exported:** 4/16/2026 0:36:17  
**Link:** [https://chatgpt.com/c/69df7c9f-ad3c-83ab-80fa-a777f9abf999](https://chatgpt.com/c/69df7c9f-ad3c-83ab-80fa-a777f9abf999)  

## Response:
2026/4/15 20:22:12

コード全体の設計を見て、まず「どこが既に良くできていて、どこがボトルネックか」を整理しています。実装には入らず、分類精度・運用性・将来拡張の観点で改良方針に絞って提案します。

現状の骨格はかなり良いです。特に「既知テーマへの埋め込み類似度」と「未分類残差に対するBERTopic」を分けている点は筋がよく、改良余地は“モデルを足す”より“判定設計と評価設計を厚くする”ところにあります。

> 思考時間: 23s

添付コードを踏まえると、現状の設計は

1.  テーマ定義を用意する
2.  記事とテーマを同じ埋め込み空間に落とす
3.  類似度閾値で既知テーマに多ラベル付与する
4.  未分類残差だけを BERTopic に回す
5.  高信頼ラベルを将来の SetFit 学習データに蓄積する

という、かなり筋の良い二段構成です。特に `theme_assign.py` の「既知テーマへの直接割当」と、`topic_model.py` の「残差の発見」を分けている点は、実務上も拡張しやすいです。

theme\_assign

topic\_model

その上で、改良方針は「モデルを大きく変える」より、「テーマ定義の作り方」「閾値の決め方」「曖昧記事の扱い」「評価指標」を強化する方向が有効です。

まず結論
----

優先順位を付けるなら、次の順で改良するのが良いです。

**第1優先**  
テーマ定義を“短い説明文1本”から“複数表現の集合”へ拡張する

**第2優先**  
固定閾値から、テーマごと・記事ごとの不確実性を使う判定に変える

**第3優先**  
「どのテーマにも見える記事」を弾く仕組みを入れる

**第4優先**  
BERTopic を“新テーマ発見”ではなく“テーマ辞書改訂の候補生成器”として位置付け直す

**第5優先**  
精度評価を、単なる件数や未分類率から、テーマ単位の precision / recall と時系列安定性へ拡張する

以下、具体的に述べます。

* * *

1\. 最重要: テーマ定義の情報量を増やす
----------------------

今の実装では、テーマ定義は `theme_id, name_ja, description, threshold` を持つ比較的シンプルな構造です。つまり、記事と「1本のテーマ説明文」との近さで判定している設計です。

io

これは最初の最小実装として正しいのですが、実務ではここが最も効きます。  
ニュース記事は表現の揺れが大きく、テーマ説明が短いと、以下の問題が起きやすいです。

*   記事がテーマに関連していても表現が違うため取り逃す
*   大テーマ同士が似た文章だと混同する
*   “対象企業のニュース”と“投資テーマのニュース”が混ざる

### 改良方針

各テーマを**単一 description ではなく、複数の意味表現の束**として管理します。

例えば各テーマに対して、少なくとも次の層を持たせるとよいです。

*   テーマ名
*   1文の定義
*   詳細説明
*   代表キーワード
*   同義語・言い換え
*   関連企業群
*   関連製品・技術語
*   除外語
*   境界が曖昧な隣接テーマ

### これで何が良くなるか

記事を1本のテーマ文と比較するのでなく、

*   テーマの代表説明との類似度
*   キーワード群との一致
*   企業・製品語との一致
*   除外語の有無

を合わせて判定できます。  
埋め込みだけに頼るより、かなり頑健になります。

### 実務的に重要な点

テーマは本来「銘柄バスケットの投資ストーリー」なので、**企業名だけでなく、何がテーマの収益源泉なのか**を明文化した方が良いです。  
たとえば AI なら単なる “AI関連企業” ではなく、

*   GPU / ASIC / サーバー
*   モデル開発
*   データセンター電力
*   ソフトウェア導入
*   産業自動化

のような下位概念に分けると、ニュース帰属の解像度が上がります。

* * *

2\. 固定閾値をやめて、判定を二段化する
---------------------

現状は `similarity >= threshold` で多ラベル付与しています。テーマ別 threshold も持てるので、最低限の工夫は入っています。

theme\_assign

config

ただし、閾値だけだと次が弱いです。

*   類似度 0.48 と 0.47 の差は小さいのに、片方だけ採用される
*   上位1位と2位が僅差でも両方通ってしまう
*   記事自体が曖昧で、どのテーマにも少し似る場合に誤配賦しやすい

### 改良方針

判定を「絶対値」と「相対差」の二段にします。

具体的には次の考え方です。

*   **絶対条件**: 上位テーマの類似度が一定以上
*   **相対条件**: 1位と2位の差、または 1位と平均の差が十分大きい
*   **多ラベル条件**: 2位以降を付けるのは、1位との差が小さく、かつ両方が十分高い場合のみ

### 期待効果

これで

*   “本当にそのテーマらしい記事”
*   “複数テーマにまたがる記事”
*   “どれにも決めきれない記事”

を分けやすくなります。

### 特に有効な指標

各記事について次を持つと良いです。

*   top1 similarity
*   top2 similarity
*   margin = top1 - top2
*   entropy 的な曖昧度指標
*   over-threshold theme count

このあたりを保存しておけば、後でテーマ件数の時系列を見るだけでなく、**分類難易度の時系列**も見られます。

* * *

3\. “テーマに見えるが、実はテーマではない”記事を弾く
-----------------------------

今の `build_text_for_embedding` では、title + summary + body\_short をそのまま結合して埋め込み化しています。これはシンプルでよい一方、ニュース実務ではノイズも入りやすいです。

preprocess

典型的なノイズは次です。

*   決算記事
*   個別企業の事故・不祥事
*   市況概況
*   マクロヘッドライン
*   同一テーマ語を含むが、本質的には別テーマの記事

### 改良方針

**テーマ帰属の前に、記事タイプ分類を1段入れる**のが有効です。

まず記事を大まかに

*   テーマ性が高い記事
*   個別企業ニュース
*   マクロニュース
*   市況サマリー
*   ノイズ / その他

に分け、その上でテーマ性が高い記事だけを強くテーマ分類する構造にします。

### 実務上の意味

テーマ投資で欲しいのは、単なる “話題にその単語が出た記事” ではなく、**テーマの投資ストーリーを更新する情報**です。  
したがって、テーマ分類器の前段に「テーマ性フィルタ」を置くと精度がかなり上がります。

* * *

4\. テーマ定義を階層化する
---------------

今の枠組みだとテーマはフラットです。ですが、実際にはテーマ間に階層があります。

例:

*   AI
    *   半導体
    *   データセンター
    *   生成AIソフトウェア
    *   産業自動化
*   エネルギー転換
    *   再エネ
    *   電力網
    *   蓄電池
    *   EV素材

### 改良方針

**親テーマ → 子テーマ**の二段構造にするのがよいです。

分類も

1.  親テーマに割り当てる
2.  その中で子テーマに細分化する

とすれば、誤判定がかなり減ります。

### なぜ効くか

フラットに全テーマと比較すると、AI とロボティクス、EV と蓄電池、サイバーと防衛など、隣接テーマが衝突しやすいです。  
まず上位概念で絞ると、後段の判定が安定します。

* * *

5\. 類似度一本足から、スコア合成へ
-------------------

現状のコアは埋め込み類似度です。これは正しいですが、ニューステーマ分類では単独だと弱い局面があります。

theme\_assign

### 改良方針

記事×テーマの最終スコアを、複数信号の合成にします。

例えば次のような構成です。

*   semantic score: 埋め込み類似度
*   lexical score: キーワード一致
*   entity score: 企業名・製品名・技術語の一致
*   novelty score: 直近そのテーマで珍しい語の出現
*   purity penalty: 他テーマにも同程度に近いなら減点
*   exclusion penalty: 除外語があるなら減点

### ポイント

ここで大事なのは、最初から複雑な学習器にしないことです。  
まずはルールベース加重平均で十分です。  
理由は、どの要素が効いたか説明しやすいからです。

特にユーザーの用途が「ニュース情報からどのテーマに安慶するか特定」である以上、**説明可能性**は重要です。  
“なぜそのテーマに入ったのか” が見える方が、後でテーマスコアや投資判断に繋げやすいです。

* * *

6\. BERTopic の役割を見直す
--------------------

現状は未分類残差に BERTopic をかけ、さらに outlier を週次で再クラスタリングする設計です。これ自体は合理的です。

topic\_model

ただし、ここは期待値の置き方が重要です。

### 問題

BERTopic は

*   新しい話題の発見
*   残差の整理  
    には強いですが、
*   既存テーマへの高精度帰属
*   時系列一貫性のあるラベル管理  
    にはそのままだと弱いです。

### 改良方針

BERTopic を**本番分類器**ではなく、**テーマ辞書改訂のための探索器**として使うのが良いです。

具体的には、BERTopic から直接テーマを採用するのでなく、

*   未分類記事をクラスタ化
*   各クラスタの代表記事・キーワードを抽出
*   人手で「既存テーマの語彙拡張」か「新規テーマ候補」かを判定
*   採用したものだけテーマ辞書へ昇格

という運用に寄せます。

### なぜか

コード上でも BERTopic 側は例外時に `-1` へ落とすなど、かなり防御的設計です。これは「探索用途」には向いていますが、「自動本番ラベラー」としてはまだ慎重に扱うべきことを示しています。

topic\_model

* * *

7\. 擬似ラベル蓄積は良いが、負例を明示的に持つべき
---------------------------

`label_store.py` では、高信頼な similarity 判定、BERTopic から昇格したラベル、manual ラベルを統合し、将来の SetFit 移行を見据えています。これはとても良い方針です。

label\_store

ただ、ここで次の課題があります。

### 現状の弱点

ポジティブラベル中心になりやすい。  
しかし多ラベル分類では、**何に属さないか** もかなり重要です。

### 改良方針

将来の学習を見据えるなら、次を明示的に持つべきです。

*   positive labels
*   hard negatives
*   ambiguous / review
*   out-of-taxonomy

特に hard negative は重要です。  
例:

*   AI と誤認しやすいが実は半導体景気循環記事
*   再エネに見えるが実は政策一般記事
*   防衛に見えるが実は地政学マクロ記事

これらを蓄積すると、後段の教師ありモデルがかなり強くなります。

* * *

8\. 評価軸を増やす
-----------

現状の reporting は件数、未分類率、残差トピック数などの時系列可視化が中心です。パイプライン監視としては良いですが、分類精度の改善に直結する指標がまだ足りません。

reporting

### 改良方針

最低限、次を見たいです。

*   theme-wise precision
*   theme-wise recall
*   macro F1 / micro F1
*   未分類率
*   多ラベル率
*   human review rate
*   テーマ別の confusion
*   週次でのラベル安定性

### 特に大事

**時系列安定性**です。  
ニューステーマ分類は、週によって分布が急変します。  
ある週だけ AI 記事が急増したのではなく、分類器が何でも AI に入れている可能性もある。  
したがって、件数だけでなく

*   類似度分布
*   margin 分布
*   人手修正率
*   テーマ別 precision の推移

を見るべきです。

* * *

9\. テーマ帰属と“テーマ重要度”は分ける
----------------------

これは設計思想の話ですが、かなり重要です。

ユーザーの最終目的は、おそらく

*   記事をテーマに振り分ける
*   そのテーマの盛り上がりや投資魅力度を測る  
    だと思います。

このとき、**帰属**と**スコアリング**は別問題です。

### 改良方針

まずは分類器を次のように限定します。

*   記事がどのテーマに属するか
*   その帰属の確信度はどれくらいか

その後の別レイヤーで

*   記事の新規性
*   トーン
*   影響度
*   ソース信頼性
*   市場反応の有無

を用いてテーマスコアを作るべきです。

### ありがちな失敗

分類器に「良いニュースかどうか」まで持ち込むと、ラベル定義が崩れます。  
まずは**テーマ帰属の純度**を高めるのが先です。

* * *

10\. 記事単位だけでなく、イベント単位に寄せる
-------------------------

ニュースは同じ話題が多数配信されます。  
このままだと、あるテーマについて同一イベントが大量にカウントされます。

### 改良方針

テーマ分類の前後で、**イベント重複排除**を入れるのが有効です。

たとえば、

*   同一日
*   類似タイトル
*   類似本文
*   同一企業 / 同一発表

をまとめて、1イベントとして扱う。

### 効果

テーマ件数時系列のノイズがかなり減ります。  
投資の観点では、“記事本数”より“イベントの数と重要度”の方が意味があります。

* * *

11\. 下流利用を見据えた出力設計にする
---------------------

現状の設定ファイルは、scores、assignments、residual topics、labels など出力先が整理されていて良いです。

config

この流れでさらに良くするなら、最終出力を

*   article-level
*   event-level
*   theme-day-level
*   theme-week-level

の4層に分けるのがよいです。

### 理由

将来やりたいことが

*   テーマの盛り上がり検知
*   トーン集計
*   テーマ回転戦略
*   ダッシュボード化  
    なら、記事単位だけでは使いにくいからです。

特に theme-day-level では

*   article\_count
*   unique\_event\_count
*   avg\_confidence
*   top\_source\_mix
*   novelty\_score
*   ambiguity\_rate

を持てると、かなり扱いやすくなります。

* * *

推奨する改良ロードマップ
------------

実装しない前提で、設計変更の順番だけ明確にすると次です。

### フェーズ1: いまの方式を保ったまま改善

*   テーマ定義を複数表現化
*   類似度判定を絶対値＋margin の二段化
*   除外語・隣接テーマを導入
*   評価指標に theme-wise precision/recall を追加

### フェーズ2: 曖昧記事処理を強化

*   テーマ性フィルタを前段に追加
*   ambiguous / review バケットを追加
*   hard negative を蓄積

### フェーズ3: 残差探索の運用化

*   BERTopic は辞書改訂候補生成に限定
*   新規テーマ候補の昇格基準を設計
*   イベント重複排除を導入

### フェーズ4: 教師ありへ移行

*   SetFit などで軽量多ラベル分類器へ移行
*   ルールと埋め込みを特徴量として統合
*   確信度校正を実施

* * *

このコードに対する要点だけ一言で言うと
-------------------

一番大きな改良は、**“テーマ description と記事 embedding の単純比較器”から、“テーマ辞書に基づく説明可能な帰属器”へ進化させること**です。  
今のコードはその土台としては十分よくできています。特に、テーマ別閾値、残差トピック、擬似ラベル蓄積の3点は、次段階へ伸ばしやすい設計です。

theme\_assign

topic\_model

label\_store

必要なら次に、  
**「改良方針を設計書レベルに落とした版」**  
として、

*   現行方式
*   課題
*   改良案
*   優先度
*   評価方法  
    の表に整理してお渡しします。

## Response:
2026/4/15 20:36:19

論点を整理しています。今回は実装ではなく、テーマ定義・ニュース処理・時変埋め込み・純度・トーン・銘柄浸透度まで含めた設計フレームワークとしてまとめます。

> **論文検索：教師付きテキストスコアと動的埋め込み**
>
>
> **検索Boudoukhの正確な情報とBERTopicドキュメント**
>
>
> **検索: 顧客埋め込みと時系列KG**
>
>
> **Considering dynamic customer embedding issues**
>
> 動的顧客埋め込みの利点を述べる一方で、フィードバックの不安定さや低い識別可能性のリスクについても触れるべきです。BERTopicのドキュメントを参照し、最近の動的トピックに関する問題を取り上げながら、DTMの問題にも言及する予定です。
>
> **Searching dynamic topic models and customer embedding critiques**
>
>
> 思考時間: 55s

結論から言うと、あなたが考えている方向性はかなり筋が良いです。  
ただし、**「動的 embedding を作れば解ける」ではなく、実際には 3 層に分けて設計する必要があります。**

第1層は **テーマそのものの定義**、第2層は **ニュースがそのテーマにどう作用するかの帰属**、第3層は **そのニュースが投資対象バスケット全体にどれだけ効くかの集約** です。  
この3層を分けると、テーマ名が抽象的でも扱えますし、純度やトーンや銘柄浸透度まで自然に組み込めます。逆に、これらを一つの embedding 更新則に押し込むと、見た目は先進的でも、何を学んでいるのか不明確になりやすいです。動的トピックモデルは語られ方の変化を追うには有用ですが、古典的 DTM はトピック数固定などの制約があり、最近の研究でも時間的一貫性や解釈性の改善が課題とされています。BERTopic 自体も、埋め込みと c-TF-IDF を組み合わせた解釈可能寄りの実装で、時間軸の分析は「global topic を先に作ってから各時点で表現を追う」設計です。[ACLアントロジー+3コロンビア大学コンピュータサイエンス学科+3Maarten G+3](https://www.cs.columbia.edu/~blei/papers/BleiLafferty2006a.pdf?utm_source=chatgpt.com)

提案する全体像
-------

最も実務的で学術的にも納得しやすいのは、**Dynamic Theme Representation Framework** のような三段構えです。

**Layer A: テーマ表現の時変化**  
各テーマを固定 description 1本で持つのではなく、

*   テーマ名
*   テーマ説明文
*   構成銘柄の事業説明
*   構成銘柄ウェイト
*   過去にそのテーマへ高関連と判定されたニュース群  
    からなる「テーマメモリ」として持ちます。これを時点ごとに更新して、テーマ embedding を進化させます。

**Layer B: ニュース → テーマの多面的帰属**  
各ニュースについて

*   semantic relevance
*   topic novelty / topic shift
*   tone / return-predictive text score
*   breadth within basket  
    を別々に推定します。

**Layer C: テーマ魅力度スコア**  
最終的なテーマ選択は  
**news relevance × tone/alpha × breadth × purity × implementability**  
で行います。

この分解にすると、ニュースの「関連」と「有効性」を混同しません。これは重要です。Boudoukh らは、どの種類のニュースが価格に効くかを区別する必要を示し、Ke・Kelly・Xiu は辞書型 sentiment よりも、将来リターン予測に最適化した supervised text score の方が有効であることを示しています。つまり、テーマに関連することと、価格形成に効くことは別問題です。[NBER+3NBER+3SSRN+3](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

1\. テーマ定義は「静的ラベル」ではなく「状態変数」にするべき
--------------------------------

あなたの着眼点で一番良いのはここです。  
テーマバスケットは固定名詞ではなく、**時点 t における意味内容** を持つべきです。

たとえば AI でも、2023 年は「生成AI・LLM」、2024 年は「電力・データセンター・GPU供給制約」、2025 年は「推論最適化・エージェント・産業実装」へと重心がずれます。固定の説明文だけでは、この遷移を吸収しにくいです。時系列を組み込んだ文書表現や temporal entity embedding の発想自体は NLP 側でも合理性があり、time-aware document embeddings はニュースの topic detection/tracking で改善を示しています。[arXiv+3arXiv+3arXiv+3](https://arxiv.org/abs/2112.06166?utm_source=chatgpt.com)

ただし、**dynamic customer embedding の発想をそのままテーマに持ち込むのは危険**です。  
顧客 embedding は行動履歴から latent preference を更新する枠組みですが、テーマは

*   概念そのもの
*   構成銘柄集合
*   メディア言説
*   市場価格反応  
    の混合物です。  
    この4つを一つの latent vector に押し込むと、テーマの意味変化と、市場の過熱・ニュースフロー増加が区別できなくなります。テーマ embedding が「概念の変化」を表しているのか、「単に最近よく報じられている」ことを表しているのかが曖昧になるからです。これは学術的には識別性の問題、実務的には説明責任の問題です。[arXiv+2arXiv+2](https://arxiv.org/abs/2112.06166?utm_source=chatgpt.com)

そのため、テーマ表現は次の3成分に分けるのがよいです。

### 1-1. Core theme embedding

テーマ名、定義文、長めの投資ストーリー、関連技術・用途・サプライチェーン語彙から作る、比較的ゆっくり変わるベクトルです。これはテーマの「本質」を表します。

### 1-2. Basket embedding

構成銘柄の事業説明、10-K/有報テキスト、セグメント記述、ウェイト付き集約で作るベクトルです。これは実際の投資対象の姿を表します。近年は企業やファンドの thematic exposure をテキストから定量化する研究が増えており、保有銘柄からテーマ集中度を測る研究や、10-K から AI engagement を作る研究も出ています。[SSRN+2SSRN+2](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4164823&utm_source=chatgpt.com)

### 1-3. Flowing context embedding

直近 k 日や k 週で、そのテーマへ高関連と判定されたニュースの加重平均 embedding です。これは速く変わる成分で、「今そのテーマがどう語られているか」を表します。

最終的なテーマ表現は  
**Theme\_t = w1 Core + w2 Basket\_t + w3 FlowingContext\_t**  
のように持つのがよいです。  
ここで `w3` は短期的、`w1` は長期的に効かせます。これなら動的更新の恩恵を得つつ、意味の漂流を抑えられます。

2\. ニュースの扱いは「関連度」だけでは足りない
-------------------------

ここはかなり重要です。  
ニュースをテーマに結びつける際、少なくとも4つのスコアを別々に持つべきです。

### 2-1. Relevance

ニュースがそのテーマにどれだけ意味的に近いか。  
これは Sentence-BERT 的な埋め込み比較が最も自然です。テーマ名が抽象的で本文に直接出ないケースでは、辞書より埋め込みが有利です。特にニュース本文、テーマ説明文、銘柄事業説明を同一空間で比較する設計は理にかなっています。BERTopic も multilingual SBERT 系埋め込みを使う構成を採り得ます。[Maarten G+1](https://maartengr.github.io/BERTopic/api/bertopic.html?utm_source=chatgpt.com)

### 2-2. Topic state

そのニュースが、そのテーマの既知の語られ方の延長か、それとも新しい局面か。  
ここで動的トピックモデルや topics-over-time が効きます。古典的 DTM は時系列に沿って topic-word distribution を遷移させるモデルで、BERTopic の dynamic topics はより実装容易な近似です。[コロンビア大学コンピュータサイエンス学科+2ACM Digital Library+2](https://www.cs.columbia.edu/~blei/papers/BleiLafferty2006a.pdf?utm_source=chatgpt.com)

### 2-3. Tone / economic significance

ニュースがポジティブかネガティブか、だけでなく、**価格形成に効くタイプか** を測る必要があります。Boudoukh らはニュースのタイプの違いを、Ke・Kelly・Xiu は return-predictive supervised text score を強調しています。テーマ選択にそのまま移植するなら、記事単位の sentiment ではなく、テーマ日次・週次の aggregated supervised score に落とす方がノイズが少ないです。[NBER+2SSRN+2](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

### 2-4. Breadth within basket

そのニュースがバスケット内の何銘柄に効いているか。  
これはあなたの問題設定で特に重要です。ニュースがテーマに関連していても、上位1銘柄にしか効かないなら、テーマ全体の投資判断には弱いからです。テーマETF の収益化可能性は、ニュースがバスケット内でどれだけ広く浸透するかに依存します。テーマ集中度や thematic exposure の考え方は、この breadth の基礎になります。[SSRN+1](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4164823&utm_source=chatgpt.com)

3\. 最も推奨する設計: 「二重動学」フレームワーク
---------------------------

あなたのアイデアを整理すると、最良案は **ニュース側とテーマ側の両方を時変にする** ことです。私はこれを二重動学と捉えるのが良いと思います。

### 3-1. ニュース側の動学

ニュースをそのまま1本の embedding にして終わりではなく、

*   文書 embedding
*   event cluster
*   dynamic topic assignment
*   tone score  
    を時系列で持つ。

特に、ニュースは記事単位より **event cluster 単位** にした方がよいです。  
同じイベントが複数ソースで流れるので、記事本数をそのまま使うと attention bias が入ります。topic detection and tracking の研究でも、時間情報を使って近接イベントをまとまりとして扱う発想が重要です。[arXiv+2arXiv+2](https://arxiv.org/abs/2112.06166?utm_source=chatgpt.com)

### 3-2. テーマ側の動学

テーマは

*   core concept
*   actual basket
*   recent discourse  
    の合成で update する。  
    ただし、更新は完全オンラインより **指数平滑** がよいです。急にニュースが偏っただけでテーマ meaning が壊れるのを避けるためです。

### 3-3. 結合

各ニュース event e とテーマ j に対し、

*   relevance(e,j,t)
*   novelty(e,j,t)
*   tone(e,j,t)
*   breadth(e,j,t)  
    を計算し、テーマ日次特徴量に集約します。

ここで最終的に学習したいのは記事単位ではなく、  
**ThemeFeatures\_{j,t} → ThemeExcessReturn\_{j,t+5/t+20}**  
です。  
これは Ke・Kelly・Xiu 的な supervised text score を、個別株からテーマ選択へ移植した形としてかなり自然です。[SSRN+1](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3389884&utm_source=chatgpt.com)

4\. 具体的なテーマ定義の持ち方
-----------------

テーマ定義は最低でも次のように持つべきです。

*   `theme_id`
*   `theme_name`
*   `thesis_long`：投資仮説の文章
*   `pillar_tags`：需要側・供給側・規制・インフラなどの下位軸
*   `related_entities`：主要企業、製品、技術、政策語
*   `exclusion_entities`：混同しやすいが除外すべき語
*   `basket_members`：構成銘柄
*   `member_weights`
*   `member_business_embeddings`
*   `theme_purity_score`
*   `implementability_score`

ここで `theme_purity_score` は最初から独立変数として持つべきです。  
テーマ ETF やテーマ投資では、中身の薄いバスケットや theme washing が実際に問題になっており、最近の研究でも、theme washers の存在と相対的なアンダーパフォーマンスが報告されています。特殊化 ETF 一般についても、注目を集めやすいニッチETFが長期的に不振であるという研究があります。[SSRN+3SSRN+3SSRN+3](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2&utm_source=chatgpt.com)

つまり、ニュースシグナルが強くても、  
**テーマ器が悪ければ投資シグナルとしては弱い**  
ということです。  
これは理論ではなく実務上の制約です。

5\. Tone は「センチメント」ではなく「用途別」に分解した方がよい
------------------------------------

ここは批判的に言うと、金融 NLP で tone を1本化する設計は雑です。  
テーマ選択で欲しいのは、単なる positive/negative ではありません。

最低でも

*   growth tone
*   profitability / monetization tone
*   regulatory tone
*   supply-chain tone
*   financing / liquidity tone
*   crowding / exuberance tone  
    くらいに分けた方が実務には合います。

理由は、同じ「ポジティブ」でも、

*   需要増のニュース
*   補助金のニュース
*   競争激化のニュース
*   バリュエーション過熱のニュース  
    は価格への効き方が異なるからです。  
    Boudoukh 系の「ニュースタイプ」と、Ke・Kelly・Xiu 系の「予測最適化スコア」を組み合わせるなら、tone を汎用 sentiment に潰さず、用途別の latent factor に分ける方が良いです。[NBER+2SSRN+2](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

6\. Breadth は非常に重要で、むしろ alpha の持続性に効く
-------------------------------------

あなたが挙げた「テーマバスケット内のどれだけの銘柄に影響しているか」は、かなり本質的です。  
私はこれを relevance より上位に置いてもよいと思います。

同じ AI ニュースでも、

*   NVDA だけに効く
*   電力、冷却、データセンターREIT、半導体製造装置まで広がる  
    では、テーマとしての実装力が違います。

実務的には breadth を次のように分けるとよいです。

*   **Weighted breadth**: ニュース関連度が高い銘柄ウェイト合計
*   **Concentration-adjusted breadth**: 上位1銘柄依存を罰する
*   **Sub-cluster breadth**: バスケット内のどの下位産業に広がっているか
*   **Purity-weighted breadth**: 純度の高い銘柄でどれだけ広がっているか

この発想は、テキストから stock thematic exposure を作って保有で集約する研究と整合的です。[SSRN+1](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4164823&utm_source=chatgpt.com)

7\. 私の推奨フレームワーク
---------------

最終的に提案するなら、次の形です。

### Phase 1: Theme representation layer

各テーマについて

*   static core embedding
*   basket embedding
*   rolling discourse embedding  
    を持つ。

### Phase 2: News parsing layer

各ニュース event について

*   event embedding
*   dynamic topic state
*   multi-head tone
*   impacted-members vector  
    を持つ。

### Phase 3: Theme aggregation layer

日次で各テーマに対して

*   relevance aggregate
*   novelty aggregate
*   tone aggregate
*   breadth aggregate
*   source quality / redundancy controls  
    を集約する。

### Phase 4: Portfolio decision layer

テーマ魅力度を  
**Attractiveness = f(Relevance, Novelty, Tone, Breadth) × Purity × Implementability**  
で作る。

この設計の長所は、  
学術的には「テキスト表現」「時系列トピック」「return-predictive supervision」を分離でき、  
実務的には「純度」「流動性」「上位銘柄偏重」を後段で自然に制御できる点です。  
また、テーマ投資のアンダーパフォーマンスや過熱の文脈とも整合します。[サイエンスダイレクト+3SSRN+3SSRN+3](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3389884&utm_source=chatgpt.com)

8\. 批判的な見方
----------

ここからはあえて否定的に言います。

### 動的 embedding は魅力的だが、過学習しやすい

テーマ meaning をニュースで更新すると、価格に効く情報ではなく、単にニュース量の多い話題へ引っ張られます。結果として「テーマの意味」ではなく「最近の attention」を学んでしまう危険があります。 specialized ETF が attention-driven に発行され、その後不振という研究とも整合的です。[SSRN+1](https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID4238942_code1542588.pdf?abstractid=3765063&mirid=1&utm_source=chatgpt.com)

### Dynamic topic model は“説明”には強いが“予測”には直結しない

トピックの変遷は面白いですが、それ自体が alpha ではありません。  
「何が話題か」と「何がリターンを予測するか」は別です。ここを混同すると、綺麗なダッシュボードはできても投資には結びつきません。Boudoukh や Ke・Kelly・Xiu の示唆は、まさにその点です。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

### テーマ純度を後付けにすると危険

ニュースモデルを先に高度化しても、バスケットが薄ければ成果は出にくいです。近年の theme washing 研究や thematic ETF 研究を見ると、テーマ器そのものの品質管理は後回しにすべきではありません。[SSRN+2SSRN+2](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2&utm_source=chatgpt.com)

### 記事単位学習はノイジー

テーマ選択をしたいなら、記事ラベルを頑張るより、日次・週次のテーマ特徴量に集約して将来のテーマ超過収益を学習する方が、目的関数と整合的です。これはあなたの直感どおりです。[SSRN+1](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3389884&utm_source=chatgpt.com)

9\. 私ならどう始めるか
-------------

実装に移らない前提で、設計だけならこうします。

まず、テーマを固定説明文で持つのはやめて、  
**Core / Basket / Recent Discourse** の三層定義にする。

次に、ニュースを記事ではなく event 単位にまとめ、  
**Relevance / Topic State / Tone / Breadth** を別々に推定する。

その上で、最終スコアは  
**Text signal × Purity × Implementability**  
にする。

そして予測対象は個別記事ラベルではなく、  
**テーマ日次特徴量から 5日・20日先の超過収益** を学習する。

これは学術的にもかなり筋が通っていて、実務で壊れにくい設計です。[SSRN+3SSRN+3SSRN+3](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3389884&utm_source=chatgpt.com)

必要なら次に、  
**このフレームワークを「テーマ定義」「ニュース処理」「スコア設計」「評価設計」の4章で、研究計画書レベルに整理**します。

---

**Sources:**

- [Dynamic Topic Models](https://www.cs.columbia.edu/~blei/papers/BleiLafferty2006a.pdf?utm_source=chatgpt.com)
- [Which News Moves Stock Prices? A Textual Analysis](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)
- [Topic Detection and Tracking with Time-Aware Document Embeddings](https://arxiv.org/abs/2112.06166?utm_source=chatgpt.com)
- [Thematic Investing in Mutual Funds](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4164823&utm_source=chatgpt.com)
- [BERTopic](https://maartengr.github.io/BERTopic/api/bertopic.html?utm_source=chatgpt.com)

## Response:
2026/4/15 20:43:04

必要な論文・実務資料を確認しながら、研究計画書兼実装設計書の形に落とし込みます。今回は「何をどの順番で作れば再現できるか」がそのまま分かる粒度で整理します。

> **Searching for academic papers and structured sources**
>
>
> **検索：テーマ型ETFに関する論文**
>
>
> **テーマ別エクスポージャに関する論文検索**
>
>
> 思考時間: 31s

以下、**再現実装可能な粒度**で、  
「所与のテーマバスケットがあり、日々のニュースから魅力的なテーマを選ぶ」ための **研究計画兼システム設計書** として整理します。

前提として、最も重要な設計判断は次です。

**記事単位で“テーマ名に近いか”を判定する問題** と、  
**テーマ日次・週次で“投資対象として魅力的か”を判定する問題** は分けるべきです。

前者は意味マッチングとトピック追跡の問題で、後者は return-predictive aggregation の問題です。Boudoukh らはニュースの「タイプ」と「トーン」の識別が価格反応に重要だと示し、Ke・Kelly・Xiu は辞書型 sentiment より、将来リターン予測に最適化した supervised text score の優位性を示しています。したがって、ニュース関連度だけで最終投資判断まで持っていく設計は弱く、**関連度層**と**予測層**を明確に分けるべきです。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

* * *

1\. 目標の定式化
----------

### 1.1 目標

各営業日  $t$  において、テーマ集合  $\mathcal{T}=\{1,\dots,K\}$  の中から、将来  $h$  日先に超過収益が高いテーマを選ぶことです。ここで  $h$  は 5営業日、20営業日などを候補にします。Ke・Kelly・Xiu の枠組みに沿うなら、記事単位の感情ではなく、**日次に集約したテキスト特徴量から将来リターンを学習する**のが自然です。[NBER+1](https://www.nber.org/system/files/working_papers/w26186/w26186.pdf?utm_source=chatgpt.com)

### 1.2 入力

時点  $t$  で利用可能なデータは次です。

*   テーマの名前、説明、構成銘柄、構成ウェイト
*   ニュース本文、見出し、要約、発信時刻、発信元
*   各構成銘柄の企業説明文や事業記述
*   必要なら市場データ、テーマETF価格、銘柄価格、流動性指標

### 1.3 出力

日次で各テーマ  $j$  に対し、少なくとも次を出します。

*   `theme_relevance_score_{j,t}`
*   `theme_topic_shift_score_{j,t}`
*   `theme_tone_score_{j,t}`
*   `theme_breadth_score_{j,t}`
*   `theme_purity_score_{j,t}`
*   `theme_implementability_score_{j,t}`
*   `theme_attractiveness_score_{j,t}`

最終的なランキングは

$$
A_{j,t} = f(R_{j,t},S_{j,t},Q_{j,t},B_{j,t}) \times P_{j,t} \times I_{j,t}
$$

のように置きます。ここで  $R$  は関連度、 $S$  はトピック状態、 $Q$  はトーン/予測スコア、 $B$  はバスケット内浸透度、 $P$  は純度、 $I$  は実装可能性です。theme washing や specialized ETF のアンダーパフォームに関する近年研究を踏まえると、**ニュースが盛り上がっていても、器としてのテーマバスケットが弱いと収益化しにくい**ため、純度と実装可能性は後付けではなく明示的に持つべきです。[SSRN+1](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2&utm_source=chatgpt.com)

* * *

2\. 提案フレームワークの全体像
-----------------

推奨するのは、**4層構造**です。

### 2.1 Layer A: Theme Representation Layer

テーマを固定的な説明文1本でなく、**時変のテーマ表現**として持ちます。これは Dynamic Topic Models の「時間とともに表現が変わる」発想と整合的ですが、古典的 DTM をそのままテーマ本体へ適用するのではなく、テーマを構成する複数の情報源を別々に管理して合成します。Blei and Lafferty の DTM は時間に応じた topic-word 分布の遷移を扱うモデルですが、トピック数固定や大規模推定の重さがあるため、実務では representation 更新則を明示した方が扱いやすいです。[Mimno](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf?utm_source=chatgpt.com)

### 2.2 Layer B: News Parsing Layer

各ニュースを event 単位に正規化し、  
**関連度・トピック状態・トーン・浸透度** を別々に出します。  
BERTopic は埋め込みと c-TF-IDF を組み合わせて解釈しやすいトピック表現を作れ、topics-over-time 機能では、まず global topic を作ってから各時点の表現を追う構造です。これは「ニュースがどう語られているか」を追うのに向いています。[Maarten G+1](https://maartengr.github.io/BERTopic/index.html?utm_source=chatgpt.com)

### 2.3 Layer C: Theme-Day Aggregation Layer

記事をそのまま売買判断に使わず、テーマ×日次に集約します。  
ここで、テーマ関連ニュースの量・新規性・トーン・バスケット浸透度を集計します。これはノイズ低減のために重要です。Ke・Kelly・Xiu の文脈でも、テキスト情報は予測対象に合わせて supervised に集約する方が有効です。[NBER+1](https://www.nber.org/system/files/working_papers/w26186/w26186.pdf?utm_source=chatgpt.com)

### 2.4 Layer D: Prediction / Ranking Layer

最終的には、テーマ日次特徴量から  $h$  日先超過収益を予測します。  
ここで初めて教師あり学習を使います。Boudoukh らの知見に従うなら、単純センチメントではなくニュースタイプを分けるべきであり、Ke・Kelly・Xiu に従うなら辞書ベース sentiment ではなく return-targeted supervised score を使うべきです。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

* * *

3\. テーマ定義の設計
------------

ここが最重要です。  
テーマ名が抽象的で本文に直接出ない以上、**テーマをどう持つか** が精度を決めます。

### 3.1 テーマを3つの表現に分ける

各テーマ  $j$  に対して、次の3表現を持ちます。

#### Core Theme Embedding

テーマの本質的説明です。

入力:

*   テーマ名
*   長めの投資仮説文
*   下位概念の説明
*   キーワード、同義語、除外語

出力:

$$
e^{core}_{j}
$$

これは比較的低頻度で更新します。

#### Basket Embedding

構成銘柄の実体を反映する表現です。

入力:

*   構成銘柄  $i \in \mathcal{B}_j$ 
*   各銘柄の事業説明文
*   ETF ウェイト  $w_{ij,t}$ 

各銘柄 embedding を  $e^{firm}_{i,t}$  とすると、

$$
e^{basket}_{j,t} = \sum_{i \in \mathcal{B}_j} w_{ij,t} \, e^{firm}_{i,t}
$$

とします。  
企業説明文や10-K/有報の文面から thematic exposure を測る発想は、テーマエクスポージャー研究や AI engagement の研究と整合的です。テーマETFの銘柄選定がしばしば曖昧である点を考えると、この層は純度評価にも効きます。[SSRN+2サイエンスダイレクト+2](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1&utm_source=chatgpt.com)

#### Flowing Context Embedding

そのテーマに最近関連したニュースから作る短期表現です。

$$
e^{flow}_{j,t} = (1-\lambda)\sum_{\tau=t-L+1}^{t}\lambda^{t-\tau} \cdot \frac{\sum_{n \in \mathcal{N}_{j,\tau}} \alpha_{n,j,\tau} e^{news}_{n}}{\sum_{n \in \mathcal{N}_{j,\tau}} \alpha_{n,j,\tau}}
$$

ここで  $\alpha_{n,j,\tau}$  はニュース  $n$  のテーマ  $j$  への関連度、 $L$  は lookback です。

### 3.2 最終テーマ表現

$$
e^{theme}_{j,t} = \beta_1 e^{core}_{j} + \beta_2 e^{basket}_{j,t} + \beta_3 e^{flow}_{j,t}
$$

とします。  
 $\beta_1,\beta_2,\beta_3$  は固定でもよいですが、実務では

*   通常時は  $\beta_1,\beta_2$  重視
*   直近ニュース急増時は  $\beta_3$  を少し上げる  
    という制御が妥当です。

### 3.3 テーマ定義ファイルの推奨スキーマ

YAML/JSON なら次のように持ちます。

```
theme_id: ai_infra
theme_name: AI Infrastructure
thesis_long: >
  AI model training and inference require semiconductors,
  servers, networking, power supply, cooling, and data center capacity...
pillar_tags:
  - semiconductors
  - data_centers
  - networking
  - power
  - cooling
synonyms:
  - AI infrastructure
  - AI compute
  - AI data center
related_entities:
  - NVIDIA
  - AMD
  - Broadcom
  - Vertiv
  - Equinix
exclusion_entities:
  - AI ethics
  - school AI curriculum
members:
  - ticker: NVDA
    weight: 0.18
  - ticker: AVGO
    weight: 0.11
  - ticker: VRT
    weight: 0.07
purity_priors:
  sector_balance_cap: 0.35
  single_name_cap: 0.20
```

* * *

4\. ニュース処理の設計
-------------

### 4.1 記事単位ではなく event 単位にする

同じ出来事が複数社から配信されるため、記事本数をそのまま使うとノイズが大きいです。  
したがって、まず記事を event cluster にまとめます。

推奨手順:

1.  見出しと本文を埋め込み化
2.  同日または近接時刻のニュースで cosine 類似度が高いものを連結
3.  代表記事、代表時刻、記事数、ソース多様性を保存

これで、`event_id` 単位の分析にします。

### 4.2 文章単位の前処理

ニュースごとに次を保存します。

*   headline
*   summary
*   body
*   normalized\_text
*   entity list
*   source
*   timestamp

推奨テキスト:

$$
x_n = [\text{headline}] \oplus [\text{summary}] \oplus [\text{lead paragraphs}]
$$

短い lead を重視するのは、金融ニュースでは重要情報が前半に集中しやすいためです。

### 4.3 埋め込みモデル

最初の再現実装では multilingual Sentence-BERT 系で十分です。  
BERTopic も transformer embedding を前提に動作し、文書埋め込みと c-TF-IDF を組み合わせます。[Maarten G+1](https://maartengr.github.io/BERTopic/index.html?utm_source=chatgpt.com)

実装上の最低要件:

*   文書 embedding
*   テーマ説明 embedding
*   企業説明 embedding  
    を同一空間に載せることです。

* * *

5\. ニュース → テーマ帰属の設計
-------------------

ここは4ヘッドに分けます。

### 5.1 Relevance Head

ニュース  $n$  とテーマ  $j$  の意味的近さです。

まず単純には

$$
r_{n,j,t}^{(0)} = \cos(e^{news}_n, e^{theme}_{j,t})
$$

でよいです。  
ただし、これだけだとテーマが曖昧なときに誤帰属しやすいので、さらに

$$
r_{n,j,t} = \gamma_1 \cos(e^{news}_n, e^{core}_{j}) + \gamma_2 \cos(e^{news}_n, e^{basket}_{j,t}) + \gamma_3 \cos(e^{news}_n, e^{flow}_{j,t})
$$

と分解して持つ方がよいです。

### 5.2 Topic-State Head

そのニュースがテーマの既知 discourse の延長か、新しい局面かを測ります。

#### 方法A: BERTopic dynamic topics

テーマ関連ニュースだけを時系列 bin に切って topics over time を計算します。BERTopic の dynamic topic modeling は、まず全期間で topic を学習し、各時点で c-TF-IDF により topic representation を更新します。これは厳密な DTM とは異なりますが、実務上はかなり扱いやすいです。[Maarten G+1](https://maartengr.github.io/BERTopic/getting_started/topicsovertime/topicsovertime.html?utm_source=chatgpt.com)

#### 方法B: Rolling cluster drift

各週ごとにテーマ関連イベントをクラスタリングし、前週との語彙/embedding 差を測ります。

トピックシフト指標の一例:

$$
s_{j,t} = 1 - \cos\left( \bar e^{flow}_{j,t}, \bar e^{flow}_{j,t-1} \right)
$$

あるいは、topic-word 分布の Jensen-Shannon divergence を使います。

### 5.3 Tone / Return-Predictive Head

ここは単純 sentiment を避けます。  
Boudoukh らはニュースタイプとトーンの区別の重要性を示し、Ke・Kelly・Xiu は将来リターン予測に最適化したテキストスコアの方が有効と示しています。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

したがって、再現実装の段階でも tone は少なくとも2層に分けます。

#### Stage 1: weak supervision

まず記事ごとに

*   growth / demand
*   regulation / policy
*   supply chain
*   financing / capital
*   crowding / exuberance  
    の多ラベルを付ける簡易分類器を作ります。

#### Stage 2: supervised return score

テーマ日次特徴量  $X_{j,t}$  から

$$
y_{j,t+h} = r^{theme}_{j,t+1:t+h} - r^{bench}_{t+1:t+h}
$$

を予測します。  
ここで  $X_{j,t}$  に relevance 集計、topic shift、tone 集計、breadth 集計を入れます。

### 5.4 Breadth Head

ニュースがテーマバスケット内の何銘柄に効くかを測ります。  
これがテーマ投資では非常に重要です。

各ニュース  $n$  と銘柄  $i$  の近さを

$$
m_{n,i,t} = \cos(e^{news}_n, e^{firm}_{i,t})
$$

で測り、ニュースのテーマ内 breadth を

$$
b_{n,j,t} = \sum_{i \in \mathcal{B}_j} w_{ij,t} \cdot \mathbf{1}(m_{n,i,t} \ge \theta_i)
$$

または連続値版として

$$
b_{n,j,t} = \sum_{i \in \mathcal{B}_j} w_{ij,t} \cdot m_{n,i,t}
$$

とします。  
さらに上位1銘柄集中を罰したいなら

$$
b^{adj}_{n,j,t} = \frac{\sum_i w_{ij,t} m_{n,i,t}}{\max_i (w_{ij,t} m_{n,i,t})}
$$

のような concentration-adjusted 指標を使えます。

* * *

6\. テーマ日次特徴量の集約
---------------

ここからが予測用の本体です。  
event 単位で出した各ヘッドをテーマ×日次へ集約します。

### 6.1 基本集計

テーマ  $j$  の日次特徴量を

$$
X_{j,t} = \Big[ \sum_{n \in \mathcal{E}_t} r_{n,j,t}, \; \sum_{n \in \mathcal{E}_t} r_{n,j,t} q_{n,j,t}, \; \sum_{n \in \mathcal{E}_t} r_{n,j,t} s_{n,j,t}, \; \sum_{n \in \mathcal{E}_t} r_{n,j,t} b_{n,j,t}, \; \text{counts}, \text{source diversity}, \text{novelty} \Big]
$$

のように作ります。

### 6.2 推奨する日次特徴量

最初の再現実装なら次を最低限持てば十分です。

*   relevance\_sum
*   relevance\_mean\_top\_events
*   novelty\_sum
*   positive\_growth\_tone\_sum
*   negative\_regulation\_tone\_sum
*   breadth\_weighted\_sum
*   breadth\_adjusted\_sum
*   unique\_event\_count
*   source\_diversity
*   duplicate\_ratio
*   5日・20日の rolling z-score

### 6.3 正規化

テーマごとにニュース量が異なるため、以下を併用します。

*   same-theme rolling z-score
*   cross-sectional rank normalization
*   market-news-volume control

* * *

7\. 純度と実装可能性の設計
---------------

### 7.1 Purity

テーマニュースが効くかどうかは、テーマ器の純度に依存します。  
theme washing 研究は、テーマ名に比して中身が薄いETFの存在とアンダーパフォームを示しています。[SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2&utm_source=chatgpt.com)

純度スコアの例:

$$
P_{j,t} = \delta_1 \cdot \text{textual thematic coherence} + \delta_2 \cdot (1-\text{single-name concentration}) + \delta_3 \cdot (1-\text{cross-theme overlap})
$$

#### textual thematic coherence

構成銘柄同士の事業説明 embedding 類似度の平均です。

#### single-name concentration

HHI や最大ウェイトで測ります。

#### cross-theme overlap

他テーマとの銘柄重複や embedding 重複で測ります。

### 7.2 Implementability

テーマが魅力的でも、実装できなければ使えません。

最低限:

*   テーマETFの出来高 / AUM
*   bid-ask spread
*   構成上位銘柄の流動性
*   turnover / rebalance cost proxy

特殊化ETFの長期アンダーパフォーマンスを踏まえると、実装可能性はかなり重要です。[NBER+1](https://www.nber.org/papers/w28369?utm_source=chatgpt.com)

* * *

8\. 予測モデルの設計
------------

### 8.1 目的変数

テーマ  $j$  の  $h$  日先超過収益です。

$$
y_{j,t}^{(h)} = \sum_{\tau=1}^{h} r_{j,t+\tau} - \sum_{\tau=1}^{h} r_{bench,t+\tau}
$$

benchmark は

*   全テーマ equal-weight
*   broad equity benchmark
*   sector-neutralized benchmark  
    のいずれかです。

### 8.2 最初の学習器

再現実装の最初は複雑にしない方が良いです。

推奨順:

1.  ridge / elastic net
2.  gradient boosting
3.  ranking model
4.  temporal neural net

Ke・Kelly・Xiu のポイントは「高度な深層モデル」より「目的に適合した supervised text score」です。したがって、最初は線形または木モデルで十分です。[NBER](https://www.nber.org/system/files/working_papers/w26186/w26186.pdf?utm_source=chatgpt.com)

### 8.3 学習単位

**記事単位ではなく、テーマ×日次** です。  
これは必須です。  
記事単位ラベルはノイズが多く、最終目的ともずれます。

* * *

9\. 再現実装の順序
-----------

ここからが実装計画です。

### Step 0: データレイヤー

必要ファイル:

*   `theme_definitions.yaml`
*   `theme_memberships.parquet`
*   `firm_profiles.parquet`
*   `news_raw.parquet`
*   `prices_theme.parquet`
*   `prices_members.parquet`

### Step 1: テーマ表現作成

作るもの:

*   `core_theme_embeddings.parquet`
*   `firm_embeddings.parquet`
*   `basket_embeddings_daily.parquet`

処理:

1.  テーマ定義文を埋め込み
2.  各銘柄事業説明文を埋め込み
3.  ウェイト付き平均で日次 basket embedding を作成

### Step 2: ニュース event 化

作るもの:

*   `news_embeddings.parquet`
*   `event_clusters.parquet`

処理:

1.  各記事を埋め込み
2.  同日近傍で重複クラスタリング
3.  代表 event テキスト作成

### Step 3: Event → Theme スコアリング

作るもの:

*   `event_theme_relevance.parquet`
*   `event_theme_breadth.parquet`
*   `event_theme_member_impacts.parquet`

処理:

1.  event と theme の cosine 類似度
2.  event と各構成銘柄の cosine 類似度
3.  breadth 指標生成

### Step 4: Dynamic topic / novelty

作るもの:

*   `theme_topics_over_time.parquet`
*   `theme_topic_shift_daily.parquet`

処理:

1.  高関連ニュースだけをテーマ別に抽出
2.  週次または月次で BERTopic topics-over-time
3.  topic shift 指標を算出

### Step 5: Tone / weak labels

作るもの:

*   `event_tone_heads.parquet`

処理:

1.  growth/regulation/supply-chain/crowding 等の多ラベル弱教師
2.  event ごとに各 tone head を推定

### Step 6: Theme-day aggregation

作るもの:

*   `theme_day_features.parquet`

処理:

1.  event スコアを日次集約
2.  rolling z-score
3.  source diversity と duplication control

### Step 7: Purity / implementability

作るもの:

*   `theme_day_quality_controls.parquet`

処理:

1.  textual coherence
2.  concentration
3.  overlap
4.  liquidity / cost proxy

### Step 8: 予測モデル

作るもの:

*   `theme_return_targets.parquet`
*   `model_inputs.parquet`
*   `predictions.parquet`
*   `rankings.parquet`

処理:

1.   $h=5,20$  で超過収益ターゲット生成
2.  walk-forward 学習
3.  cross-sectional ranking 出力

* * *

10\. 評価設計
---------

### 10.1 NLP 側評価

まず投資以前に、ニュース帰属の品質を見ます。

必要指標:

*   theme assignment precision / recall
*   top-1 accuracy
*   multilabel F1
*   event dedup accuracy
*   topic coherence
*   topic stability over time

BERTopic 側は coherence と代表文書の妥当性を必ず目視確認します。BERTopic は解釈性が高い一方、トピック数や外れ値処理に依存します。[Maarten G+1](https://maartengr.github.io/BERTopic/index.html?utm_source=chatgpt.com)

### 10.2 投資側評価

次に theme-day feature の有効性を見ます。

必要指標:

*   IC / Rank IC
*   long-short spread by quintile
*   top-N theme portfolio return
*   turnover
*   implementation shortfall proxy
*   subperiod stability

### 10.3 分解評価

特に次の分解が重要です。

*   relevance 単体
*   relevance + topic
*   relevance + tone
*   relevance + breadth
*   全部入り
*   全部入り × purity control

このアブレーションで、何が効いているかを確認します。

* * *

11\. 批判的見解
----------

### 11.1 Dynamic embedding に過度な期待は禁物

テーマ表現を直近ニュースで更新すると、概念そのものではなく attention を追ってしまう危険があります。specialized ETF のアンダーパフォーム研究や theme washing 研究を踏まえると、短期的に盛り上がる物語がそのまま投資妙味ではないケースが多いです。[NBER+1](https://www.nber.org/papers/w28369?utm_source=chatgpt.com)

したがって、`flowing context embedding` は有用ですが、`core` と `basket` を壊さないよう、更新ウェイトは控えめにすべきです。

### 11.2 Dynamic Topic Model は説明用には強いが、予測には直接つながらない

DTM や BERTopic dynamic topics は、「語られ方が変わったか」を捉えるには優れますが、それ自体が alpha とは限りません。Boudoukh と Ke・Kelly・Xiu の示唆に従えば、最終的に重要なのは「どのタイプのニュースが将来収益に効くか」です。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

### 11.3 純度は後回しにしてはいけない

テーマ投資では、器の質が悪いとニュース信号が死にます。  
テキスト処理を先に高度化するより、theme purity を最初から組み込むべきです。[SSRN+1](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2&utm_source=chatgpt.com)

* * *

12\. 最小実装版の推奨仕様
---------------

研究開始時の最小版は、次の仕様が最もバランスが良いです。

1.  テーマを `core + basket + flow` の3表現で保持
2.  ニュースを event cluster 化
3.  event ごとに `relevance`, `breadth`, `novelty`, `weak tone` を出す
4.  テーマ×日次へ集約
5.  5日・20日先超過収益を walk-forward で予測
6.  最後に `purity × implementability` で調整

この順番なら、

*   学術的には DTM/BERT/return-predictive text の論点を切り分けられ、
*   実務的にはテーマ純度・上位銘柄偏重・ニュース重複を抑えられます。[SSRN+3Mimno+3Maarten G+3](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf?utm_source=chatgpt.com)

* * *

引用元
---

*   Blei, D. M., & Lafferty, J. D. “Dynamic Topic Models.” ICML 2006. [Mimno](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf?utm_source=chatgpt.com)
*   BERTopic documentation, including dynamic topic modeling / topics over time. [Maarten G+2Maarten G+2](https://maartengr.github.io/BERTopic/index.html?utm_source=chatgpt.com)
*   Boudoukh, Feldman, Kogan, Richardson. “Which News Moves Stock Prices? A Textual Analysis.” NBER Working Paper 18725. [NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)
*   Ke, Kelly, Xiu. “Predicting Returns With Text Data.” NBER Working Paper 26186 / SSRN. [NBER+1](https://www.nber.org/system/files/working_papers/w26186/w26186.pdf?utm_source=chatgpt.com)
*   Thematic Concentration and Mutual Fund Performance. Text-based thematic exposure aggregation. [SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1&utm_source=chatgpt.com)
*   Ante & Saggu. “Quantifying a Firm’s AI Engagement: Constructing Objective, Data-Driven, AI Stock Indices Using 10-K Filings.” [サイエンスダイレクト+1](https://www.sciencedirect.com/science/article/pii/S0040162524007637?utm_source=chatgpt.com)
*   “Theme Washing in the ETF Space.” SSRN working paper, 2025. [SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2&utm_source=chatgpt.com)
*   Ben-David et al. “Competition for Attention in the ETF Space.” NBER Working Paper 28369. [NBER+1](https://www.nber.org/papers/w28369?utm_source=chatgpt.com)

次に進めるなら、これをそのまま **Codex 指示書向けの実装仕様書** に変換して、  
`入力ファイル`, `中間生成物`, `関数I/O`, `評価指標`, `ノートブック手順` まで固定化できます。

---

**Sources:**

- [Which News Moves Stock Prices? A Textual Analysis](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)
- [Theme Washing in the ETF Space](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2&utm_source=chatgpt.com)
- [Dynamic Topic Models](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf?utm_source=chatgpt.com)
- [BERTopic](https://maartengr.github.io/BERTopic/index.html?utm_source=chatgpt.com)
- [Quantifying a firm's AI engagement: Constructing objective ...](https://www.sciencedirect.com/science/article/pii/S0040162524007637?utm_source=chatgpt.com)

## Response:
2026/4/15 20:55:14

> 思考時間: 23s

はい。まずここは**かなり大きく見直した方がよい**です。  
現行定義は「テーマ説明 + 別名 + キーワード + 構成銘柄 + 閾値」という、**静的な類似度分類器向けの最小構成**としては良いのですが、これまで議論した

*   テーマ表現の時変化
*   構成銘柄ベースのバスケット表現
*   ニュースの relevance / tone / breadth 分解
*   純度と実装可能性
*   将来の教師あり拡張

まで見据えると、情報量が足りません。特に現行コード側も、テーマ定義を `theme_id / name_ja / description / threshold` 中心で読み込む前提になっており、現状スキーマは「まず埋め込み比較するための説明文」を置く発想です。

そのため、次の方針で作り替えるのがよいです。

先に結論
----

テーマ定義は、今後は次の **5ブロック構成** に分けるのを推奨します。

1.  `identity`  
    テーマID、名称、分類などの識別情報
2.  `thesis`  
    テーマの本質的説明、投資ストーリー、下位概念
3.  `lexicon`  
    同義語、関連語、除外語、ドライバー語
4.  `basket`  
    構成銘柄、ウェイト、銘柄説明、役割
5.  `controls`  
    類似度閾値、純度、流動性、集中度などの制御パラメータ

この形にすると、  
**静的テーマ定義** と **時系列で更新されるテーマ表現** を分離できます。

* * *

1\. 現行 YAML の問題点
================

まず、いまの YAML には構造上の問題がいくつかあります。

1-1. スキーマが「分類用最小単位」に寄りすぎている
---------------------------

現状は実質的に

*   `description`
*   `aliases`
*   `keywords`
*   `constituents`
*   `threshold`

だけです。

これだと、ニュースとの意味類似度は取れても、

*   テーマの中で何が中核か
*   どのようなニュースがテーマに効くか
*   どの銘柄群に波及するのか
*   テーマの純度が高いのか

を表現できません。

1-2. `description` が1本しかない
--------------------------

これはかなり弱いです。  
テーマは普通、1文では定義しきれません。

少なくとも分けるべきです。

*   テーマの一文定義
*   投資ストーリー
*   下位概念
*   構成銘柄との結びつき

1-3. `keywords` の意味が曖昧
----------------------

`keywords` に「長期金利」のようなドライバー語を入れるのはよいのですが、今の形だと

*   そのテーマを直接表す語
*   そのテーマの原因ドライバー
*   そのテーマに追い風のマクロ要因
*   逆に誤判定を招く一般語

が全部混ざります。

これは将来的にかなり危険です。

1-4. `constituents.description` が弱い
-----------------------------------

「業種」だけでは足りません。  
将来的に breadth を測るには、各銘柄がテーマの中で何の役割を持つかが必要です。

たとえば AI インフラなら、

*   GPU
*   ネットワーク
*   電力
*   冷却
*   データセンター

のどこに属するかでニュースの効き方が違います。

1-5. `threshold` しか制御パラメータがない
-----------------------------

現状コードでは theme-specific threshold を読む設計なのでこれは必要ですが、今後は最低でも

*   relevance threshold
*   top-2 margin threshold
*   breadth minimum
*   purity prior
*   concentration cap

などを持ちたくなります。現行パイプラインも `threshold` を基準に over-threshold 判定をして多ラベル付与しているため、ここを単純閾値1本で固定し続けるのは拡張のボトルネックになります。

* * *

2\. 新しいテーマ定義の設計思想
=================

おすすめは、テーマを **「固定ラベル」ではなく「情報オブジェクト」** として持つことです。

つまり、テーマ定義は単なる説明文ではなく、

*   何のテーマか
*   何がそのテーマを駆動するか
*   どの銘柄がどう関わるか
*   何と混同しやすいか
*   どういうニュースに反応すべきか

を構造的に持つべきです。

* * *

3\. 推奨スキーマ
==========

以下の形を推奨します。

```
version: 2

themes:
  - identity:
      theme_id: AAAAAAAA
      name_jp: テーマA
      name_en: Theme A
      status: active
      parent_theme_id: null
      region: JP
      asset_type: equity
      theme_type: structural

    thesis:
      one_liner: >
        テーマAの1文定義。
      investment_thesis: >
        このテーマが中長期で拡大する背景、収益源泉、価格形成上の重要論点を書く。
      economic_mechanism:
        - 金利上昇局面で利ざや改善が起きやすい
        - 規制緩和や再編が追い風となる
      subpillars:
        - name: コア事業
          description: テーマの中心部分
        - name: 周辺受益
          description: 間接受益セグメント

    lexicon:
      aliases:
        - テーマA
        - 言い換えA
        - 言い換えB
      canonical_terms:
        - 主要表現1
        - 主要表現2
      driver_terms:
        - 長期金利
        - イールドカーブ
      related_terms:
        - 地方銀行
        - 地域金融機関
      exclusion_terms:
        - 保険
        - メガバンク
      ambiguous_terms:
        - 金融
        - 銀行

    basket:
      weighting_scheme: external
      constituents:
        - security_id: ticker_a
          name: 構成銘柄a
          weight: 0.03
          role: コア
          pillar: コア事業
          business_description: >
            この銘柄がテーマAの中で何を担うのか。単なる業種でなく事業内容を書く。
          exposure_direction: direct
          exposure_confidence: high
        - security_id: ticker_b
          name: 構成銘柄b
          weight: 0.03
          role: 周辺
          pillar: 周辺受益
          business_description: >
            この銘柄がテーマAにどう関係するかを書く。
          exposure_direction: indirect
          exposure_confidence: medium

    controls:
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.15
      max_single_name_weight: 0.20
      purity_prior: 0.75
      liquidity_prior: 0.80

    metadata:
      created_by: analyst
      created_at: 2026-04-15
      updated_at: 2026-04-15
      notes: >
        初期定義。
```

* * *

4\. なぜこの形が良いのか
==============

4-1. `identity`
---------------

これは純粋に識別情報です。

追加したい項目は以下です。

*   `theme_id`
*   `name_jp`
*   `name_en`
*   `status`
*   `parent_theme_id`
*   `region`
*   `asset_type`
*   `theme_type`

### 理由

将来的に、

*   親テーマ → 子テーマ
*   日本テーマ / 米国テーマ
*   株式テーマ / 債券テーマ

のように整理したくなるからです。

* * *

4-2. `thesis`
-------------

ここが **最重要** です。  
今の `description` はここに分解すべきです。

推奨項目:

*   `one_liner`
*   `investment_thesis`
*   `economic_mechanism`
*   `subpillars`

### 理由

ニュースがテーマに関連するかどうかは、単に語が近いかではなく、  
**そのニュースがテーマの収益メカニズムに関係するか** が重要だからです。

たとえば地銀テーマなら、

*   長期金利上昇
*   預貸率
*   有価証券評価損益
*   再編・統合
*   地域経済

のどれに効くかで重要度が変わります。

* * *

4-3. `lexicon`
--------------

今の `aliases` と `keywords` はここへ吸収します。  
ただし細分化します。

推奨項目:

*   `aliases`
*   `canonical_terms`
*   `driver_terms`
*   `related_terms`
*   `exclusion_terms`
*   `ambiguous_terms`

### 役割の違い

`aliases`  
テーマそのものの別名

`canonical_terms`  
テーマを直接表すコア語

`driver_terms`  
テーマを動かす要因語

`related_terms`  
周辺概念、サプライチェーン、制度語

`exclusion_terms`  
誤判定しやすいが除外したい語

`ambiguous_terms`  
よく出るが判定力が弱い一般語

### これはなぜ必要か

今の設計だと `keywords` が1種類しかなく、  
ニュース relevance の説明可能性が弱いです。

* * *

4-4. `basket`
-------------

これは現行の `constituents` を大幅に強化します。

推奨項目:

*   `security_id`
*   `name`
*   `weight`
*   `role`
*   `pillar`
*   `business_description`
*   `exposure_direction`
*   `exposure_confidence`

### 理由

今後やりたい breadth 推定では、  
ニュースがテーマ内のどの銘柄群に効いたかを見たいはずです。

そのためには各銘柄について、

*   コア銘柄か周辺銘柄か
*   どの subpillar に属するか
*   直接受益か間接受益か

を持つ必要があります。

### 例

AI インフラなら

*   NVDA: コア / 半導体 / direct
*   VRT: 周辺 / 電力冷却 / direct
*   EQIX: 周辺 / データセンター / indirect

のように持つべきです。

* * *

4-5. `controls`
---------------

今の `threshold` はここに移します。

推奨項目:

*   `relevance_threshold`
*   `margin_threshold`
*   `min_constituent_breadth`
*   `max_single_name_weight`
*   `purity_prior`
*   `liquidity_prior`

### 理由

現行コードでは `threshold` のみを読み、多ラベルを閾値越えでそのまま付与しています。今後、判定を

*   類似度絶対値
*   2位との差
*   バスケット内広がり
*   純度補正

に拡張するなら、制御値をここで持つのが自然です。

theme\_assign

* * *

5\. まず最低限どこから変えるべきか
===================

一気に全部変える必要はありません。  
段階的には次の順がよいです。

Phase 1: いまのコード互換を保ちながら拡張
-------------------------

現行ローダーは `theme_id / name_ja / description / threshold` を必須で読んでいます。

io

なので最初は、新スキーマにしても **互換カラムを残す** のがよいです。

### 最低限の修正版

```
themes:
  - theme_id: AAAAAAAA
    name_ja: テーマA
    description: >
      テーマAの短い説明文。埋め込み比較用の代表文。
    threshold: 0.40

    thesis:
      one_liner: >
        テーマAの1文定義
      investment_thesis: >
        テーマAの投資ストーリー
      economic_mechanism:
        - 長期金利上昇が追い風
        - 再編が収益性改善要因
      subpillars:
        - コア事業
        - 周辺受益

    lexicon:
      aliases:
        - テーマA
        - 言い換えA
      canonical_terms:
        - 地方銀行
        - 地域金融機関
      driver_terms:
        - 長期金利
        - イールドカーブ
      exclusion_terms:
        - 保険
        - メガバンク

    constituents:
      - name: 構成銘柄a
        description: >
          地方銀行。預貸業務中心。
        weight: 0.03
        role: core
        pillar: コア事業
      - name: 構成銘柄b
        description: >
          地域金融サービス提供企業。
        weight: 0.03
        role: satellite
        pillar: 周辺受益
```

これなら既存コードでも大きく壊れません。

* * *

6\. `description` はどう書くべきか
==========================

ここはかなり重要です。  
埋め込み比較で最初に効くからです。

現行コードではテーマ embedding は、この `description` を中心に作るはずなので、ここを単なる説明文にせず、**埋め込み向け代表文** として設計した方がいいです。

推奨は以下です。

悪い例
---

「地方銀行に関するテーマ」

良い例
---

「地方銀行・地域金融機関を中心に、長期金利、預貸利ざや、再編、地域経済、資本政策の影響を受けやすい金融テーマ」

### 理由

意味空間上で拾いたい表現を、ある程度明示しておくべきだからです。

* * *

7\. `constituents.description` は何を書くべきか
=======================================

「業種」だけでは不十分です。  
少なくとも以下のいずれかを入れるべきです。

*   会社の主要事業
*   そのテーマとの関係
*   直接受益か間接受益か
*   テーマ内の役割

悪い例
---

`description: 銀行`

良い例
---

`description: 地方銀行。貸出・預金を中心に地域金融サービスを提供し、長期金利上昇時の預貸利ざや改善がテーマとの主要接点`

これがあると、将来ニュースと銘柄の意味類似度を見て breadth を測れるようになります。

* * *

8\. `keywords` は廃止ではなく分解がよい
===========================

`keywords` を消す必要はありません。  
ただ、1本化したままは避けた方がよいです。

おすすめは内部で以下に分けることです。

*   テーマ直接語
*   ドライバー語
*   周辺語
*   除外語

地銀テーマなら例として:

```
lexicon:
  canonical_terms:
    - 地方銀行
    - 地域金融機関
  driver_terms:
    - 長期金利
    - イールドカーブ
    - 預貸利ざや
  related_terms:
    - 再編
    - 経営統合
    - 地域経済
    - 有価証券評価損益
  exclusion_terms:
    - 生命保険
    - 損害保険
    - メガバンク
```

* * *

9\. 閾値は `threshold` 1本ではなく将来的に複数持つ
==================================

現時点ではコード互換のため `threshold` は残してよいです。  
ただし実質的には今後、以下へ分ける前提で設計した方がいいです。

*   `relevance_threshold`
*   `margin_threshold`
*   `breadth_threshold`

現行の `assign_multilabels` は「閾値超えのテーマをすべて付ける」だけなので、近い将来ここが粗くなります。

theme\_assign

* * *

10\. あなたの YAML をまずどう直すべきか
=========================

現実的な第一歩として、以下の変更を推奨します。

変更方針
----

*   ルートキーは `theme:` でなく `themes:` に統一
*   `threshold` の綴りを修正
*   `description` を「埋め込み代表文」にする
*   `keywords` を `lexicon` に分割
*   `constituents` に `role` と `pillar` を追加
*   `thesis` ブロックを追加

* * *

11\. 最初の改訂版サンプル
===============

```
version: 2

themes:
  - theme_id: AAAAAAAA
    name_ja: テーマA
    name_en: Theme A

    description: >
      テーマAに関連する代表説明文。ニュースとの意味類似度計算で使うため、
      テーマの中核概念、主要ドライバー、関連主体を簡潔に含める。

    threshold: 0.40

    thesis:
      one_liner: >
        テーマAの1文定義。
      investment_thesis: >
        テーマAが中長期的に成長・再評価される背景、収益源泉、注目論点を書く。
      economic_mechanism:
        - 主要ドライバー1
        - 主要ドライバー2
      subpillars:
        - name: コア領域
          description: テーマAの中核
        - name: 周辺領域
          description: テーマAの周辺受益

    lexicon:
      aliases:
        - テーマA
        - テーマAの言い換え
      canonical_terms:
        - テーマAを直接表す語
      driver_terms:
        - 長期金利
      related_terms:
        - 周辺概念
      exclusion_terms:
        - 誤判定しやすい語

    constituents:
      - name: 構成銘柄a
        security_id: ticker_a
        description: >
          銘柄aの事業説明。テーマAとの関係を明示する。
        weight: 0.03
        role: core
        pillar: コア領域
        exposure_direction: direct
        exposure_confidence: high

      - name: 構成銘柄b
        security_id: ticker_b
        description: >
          銘柄bの事業説明。テーマAとの関係を明示する。
        weight: 0.03
        role: satellite
        pillar: 周辺領域
        exposure_direction: indirect
        exposure_confidence: medium

    controls:
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.15
      purity_prior: 0.70
      liquidity_prior: 0.80

    metadata:
      notes: 初期定義
      updated_at: 2026-04-15

  - theme_id: BBBBBBBB
    name_ja: テーマB
    name_en: Theme B

    description: >
      テーマBに関連する代表説明文。

    threshold: 0.40

    thesis:
      one_liner: >
        テーマBの1文定義。
      investment_thesis: >
        テーマBの投資ストーリー。
      economic_mechanism:
        - 主要ドライバー1
      subpillars:
        - name: コア領域
          description: テーマBの中核

    lexicon:
      aliases:
        - テーマB
      canonical_terms:
        - テーマBを直接表す語
      driver_terms:
        - ドライバー語
      related_terms:
        - 周辺語
      exclusion_terms:
        - 除外語

    constituents:
      - name: 構成銘柄c
        security_id: ticker_c
        description: >
          銘柄cの事業説明。
        weight: 0.03
        role: core
        pillar: コア領域
        exposure_direction: direct
        exposure_confidence: high

      - name: 構成銘柄d
        security_id: ticker_d
        description: >
          銘柄dの事業説明。
        weight: 0.03
        role: satellite
        pillar: コア領域
        exposure_direction: indirect
        exposure_confidence: medium

    controls:
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.15
      purity_prior: 0.70
      liquidity_prior: 0.80

    metadata:
      notes: 初期定義
      updated_at: 2026-04-15
```

* * *

12\. 現行コードとの関係
==============

今のコードベースでは、テーマ定義読み込み側が要求するのは基本的に

*   `theme_id`
*   `name_ja`
*   `description`
*   `threshold`

です。

io

また、類似度計算・閾値判定もそこを前提にしています。

theme\_assign

なので、**最初の改修方針は「互換項目を残したまま、情報を増やす」** が正解です。  
いきなり `identity:` 配下に全部入れてしまうと、ローダーも直さないと動かなくなります。

つまり段階としては

### 第1段階

フラット項目は残す  
その上で `thesis`, `lexicon`, `controls`, `metadata` を増やす

### 第2段階

ローダーを改修してネスト構造を正式対応させる

### 第3段階

`description` 単独 embedding から、`description + thesis + basket` 合成へ移行

が良いです。

* * *

13\. 今ここで最も大事な見直しポイント
=====================

優先順位を付けるなら次です。

最優先
---

`description` を埋め込み用代表文として再設計する

次点
--

`keywords` を `lexicon` に分ける

次点
--

`constituents.description` を「業種」ではなく「テーマとの関係」に書き換える

その次
---

`thesis` と `subpillars` を追加する

その後
---

`controls` を分離する

* * *

14\. 私の提案を一言でまとめると
==================

今の YAML は **「テーマ名に近いニュースを取るための辞書」** です。  
これからは **「テーマの意味・構成・収益メカニズム・判定制御を持つ定義オブジェクト」** に変えるべきです。

必要なら次に、  
**あなたの現行 YAML を題材にして、実際に 2〜3 テーマ分を完全な新スキーマへ書き換えたサンプル** を作れます。

## Response:
2026/4/15 21:02:47

> 思考時間: 2 ～ 3 秒

では、**そのまま雛形として使える粒度**で、  
現行 YAML を **新スキーマに沿って 3テーマ分** 書き換えたサンプルを示します。

今回は次の方針です。

*   **現行コード互換を壊さない**ように、`theme_id / name_ja / description / threshold` は残す
*   その上で、今後使いたい `thesis / lexicon / constituents拡張 / controls / metadata` を追加する
*   まだローダー未対応でも、将来使う情報を YAML 側へ先に載せられる形にする

現行実装は `theme_id`, `name_ja`, `description`, `threshold` を必須として読み込み、閾値ベースで類似度判定する構造なので、この4項目は当面維持するのが安全です。

* * *

改訂版サンプル YAML
============

```
version: 2

themes:
  - theme_id: REGIONAL_BANKS_JP
    name_ja: 地方銀行
    name_en: Regional Banks Japan

    description: >
      日本の地方銀行・地域金融機関を中心に、長期金利、イールドカーブ、
      預貸利ざや、債券評価損益、再編・統合、地域経済動向の影響を受けやすい金融テーマ。

    threshold: 0.40

    thesis:
      one_liner: >
        地方銀行の収益力・資本政策・再編期待に着目する日本金融テーマ。
      investment_thesis: >
        地方銀行は、長期金利やイールドカーブの変化を通じた預貸利ざや改善、
        保有債券ポートフォリオの評価変動、地域経済の信用需要、再編・統合、
        政策変更などの影響を受ける。ニュース上は、金利・金融政策・再編・
        決算・株主還元・不良債権・地場景気に関する報道が重要となる。
      economic_mechanism:
        - 長期金利上昇は預貸利ざや改善を通じて収益押し上げ要因となりうる
        - 債券ポートフォリオの評価損益変動は資本や利益に影響する
        - 経営統合・再編は効率化と株主還元期待を高めうる
        - 地域景気悪化は信用コスト増加要因となる
      subpillars:
        - name: 金利感応
          description: 預貸利ざや、イールドカーブ、債券評価損益
        - name: 再編・資本政策
          description: 統合、自己株買い、配当、ガバナンス改善
        - name: 地域信用環境
          description: 地域景気、貸出需要、不良債権、与信コスト

    lexicon:
      aliases:
        - 地方銀行
        - 地銀
        - 地域金融機関
        - regional banks
      canonical_terms:
        - 地方銀行
        - 地域金融機関
        - 第二地方銀行
      driver_terms:
        - 長期金利
        - イールドカーブ
        - 預貸利ざや
        - 債券評価損益
        - 政策金利
      related_terms:
        - 経営統合
        - 再編
        - 自己株買い
        - 配当
        - 地域経済
        - 貸出需要
        - 不良債権
      exclusion_terms:
        - 生命保険
        - 損害保険
        - 証券会社
        - メガバンク
      ambiguous_terms:
        - 金融
        - 銀行
        - 金利

    constituents:
      - security_id: 8334.T
        name: 群馬銀行
        description: >
          地方銀行。群馬県を主要地盤とし、預金・貸出・法人金融を中心に展開。
          長期金利、地域景気、信用コスト、株主還元、再編思惑の影響を受けやすい。
        weight: 0.03
        role: core
        pillar: 金利感応
        exposure_direction: direct
        exposure_confidence: high

      - security_id: 7186.T
        name: コンコルディア・フィナンシャルグループ
        description: >
          地方銀行グループ。規模の大きい地域金融グループとして、
          金利感応に加え統合・効率化・資本政策ニュースとの結びつきが強い。
        weight: 0.03
        role: core
        pillar: 再編・資本政策
        exposure_direction: direct
        exposure_confidence: high

      - security_id: 7167.T
        name: めぶきフィナンシャルグループ
        description: >
          地方銀行持株会社。地域信用環境、貸出需要、金利、株主還元に関する
          ニュースとの関連が高い。
        weight: 0.03
        role: satellite
        pillar: 地域信用環境
        exposure_direction: direct
        exposure_confidence: high

    controls:
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.15
      max_single_name_weight: 0.20
      purity_prior: 0.80
      liquidity_prior: 0.85

    metadata:
      notes: >
        地銀テーマ。将来的には金利ニュース、再編ニュース、地域景況ニュースを
        tone head で分離して扱う想定。
      updated_at: 2026-04-15

  - theme_id: AI_INFRA
    name_ja: AIインフラ
    name_en: AI Infrastructure

    description: >
      生成AIや機械学習の普及に伴って需要が増加する、半導体、サーバー、
      ネットワーク、電力、冷却、データセンターなどの基盤設備に関するテーマ。

    threshold: 0.42

    thesis:
      one_liner: >
        AI需要拡大を支える計算資源・物理インフラに着目するテーマ。
      investment_thesis: >
        AIの学習・推論需要拡大は、GPU・ASIC・高速ネットワーク・サーバー、
        データセンター容量、電力供給、冷却設備などへの継続的投資を誘発する。
        ニュース上は、モデル性能向上そのものよりも、設備投資、供給制約、
        消費電力、受注、設備増強、資本支出計画、顧客導入事例が重要となる。
      economic_mechanism:
        - AI計算需要増は半導体・サーバー・ネットワーク需要を押し上げる
        - 電力・冷却制約は周辺受益銘柄の需要増要因となる
        - データセンター投資増は設備・不動産・運用企業へ波及する
      subpillars:
        - name: 半導体・計算資源
          description: GPU、ASIC、HBM、サーバー
        - name: ネットワーク
          description: 高速接続、スイッチ、インターコネクト
        - name: 電力・冷却
          description: 電源、空調、液冷、熱管理
        - name: データセンター
          description: データセンター容量、運営、関連設備

    lexicon:
      aliases:
        - AIインフラ
        - AI基盤
        - AI compute infrastructure
        - AI data center
      canonical_terms:
        - GPU
        - AIサーバー
        - データセンター
        - AIインフラ
      driver_terms:
        - 設備投資
        - 資本支出
        - 消費電力
        - 液冷
        - 受注残
      related_terms:
        - HBM
        - ASIC
        - inference
        - training cluster
        - networking
        - power supply
        - cooling
      exclusion_terms:
        - AI倫理
        - 教育用AI
        - 生成AI利用規約
      ambiguous_terms:
        - AI
        - 半導体
        - クラウド

    constituents:
      - security_id: NVDA
        name: NVIDIA
        description: >
          AI計算需要の中心的受益銘柄。GPU、アクセラレータ、サーバー向けプラットフォームを提供し、
          AI投資拡大ニュースとの直接的な結びつきが強い。
        weight: 0.12
        role: core
        pillar: 半導体・計算資源
        exposure_direction: direct
        exposure_confidence: high

      - security_id: AVGO
        name: Broadcom
        description: >
          AIネットワーク・カスタム半導体の受益銘柄。高速通信、スイッチ、ASIC関連ニュースと関連。
        weight: 0.08
        role: core
        pillar: ネットワーク
        exposure_direction: direct
        exposure_confidence: high

      - security_id: VRT
        name: Vertiv
        description: >
          データセンター向け電力・冷却設備を提供。電力制約、液冷、
          データセンター新設・増設ニュースとの関連が高い。
        weight: 0.05
        role: satellite
        pillar: 電力・冷却
        exposure_direction: direct
        exposure_confidence: high

      - security_id: EQIX
        name: Equinix
        description: >
          データセンター運営企業。AI需要に伴うデータセンター容量・運用・接続需要の
          受益が見込まれる周辺銘柄。
        weight: 0.05
        role: satellite
        pillar: データセンター
        exposure_direction: indirect
        exposure_confidence: medium

    controls:
      relevance_threshold: 0.42
      margin_threshold: 0.06
      min_constituent_breadth: 0.20
      max_single_name_weight: 0.25
      purity_prior: 0.78
      liquidity_prior: 0.95

    metadata:
      notes: >
        AIテーマ全般ではなく、アプリケーションよりも物理インフラ側にフォーカス。
        単なる「AI」という語は曖昧なので ambiguous_terms で管理する。
      updated_at: 2026-04-15

  - theme_id: OBESITY_TREATMENT
    name_ja: 肥満治療
    name_en: Obesity Treatment

    description: >
      肥満症治療薬、糖尿病・代謝疾患治療との連関、医薬品開発、
      製造能力、供給制約、保険償還、医療サービス需要への波及を含むテーマ。

    threshold: 0.41

    thesis:
      one_liner: >
        肥満症治療薬の普及と、その周辺医療・供給網への波及に着目するテーマ。
      investment_thesis: >
        GLP-1関連治療薬などの普及は、製薬企業の売上成長だけでなく、
        原薬製造、充填、生産能力増強、保険償還、医療提供体制、食習慣変化、
        一部消費関連への逆風など幅広い波及を伴う。ニュース上は、
        臨床試験、承認、適応拡大、供給不足、生産増強、保険適用、処方動向が重要。
      economic_mechanism:
        - 承認・適応拡大は市場拡大期待を高める
        - 供給制約は短期業績のボトルネックとなる
        - 保険償還や価格設定は普及速度に大きく影響する
      subpillars:
        - name: 先発医薬品
          description: 主力治療薬、パイプライン
        - name: 製造・供給
          description: 原薬、製造受託、充填、増産
        - name: 周辺医療・消費波及
          description: 医療需要、保険、生活習慣変化

    lexicon:
      aliases:
        - 肥満治療
        - obesity treatment
        - obesity drugs
        - GLP-1テーマ
      canonical_terms:
        - 肥満症治療薬
        - GLP-1
        - 代謝疾患
      driver_terms:
        - 承認
        - 適応拡大
        - 保険償還
        - 供給不足
        - 増産
      related_terms:
        - 糖尿病
        - 体重減少
        - 臨床試験
        - 処方動向
        - 原薬
      exclusion_terms:
        - ダイエット食品
        - 一般的な健康法
        - 美容痩身
      ambiguous_terms:
        - 肥満
        - 医薬品
        - ヘルスケア

    constituents:
      - security_id: NVO
        name: Novo Nordisk
        description: >
          肥満症・糖尿病治療薬の中心的企業。承認、適応拡大、供給不足、処方伸長、
          生産能力拡張ニュースとの関連が極めて高い。
        weight: 0.10
        role: core
        pillar: 先発医薬品
        exposure_direction: direct
        exposure_confidence: high

      - security_id: LLY
        name: Eli Lilly
        description: >
          肥満症治療・代謝疾患分野の主要企業。臨床試験、承認、供給能力増強、
          競争環境に関するニュースと強い関連を持つ。
        weight: 0.10
        role: core
        pillar: 先発医薬品
        exposure_direction: direct
        exposure_confidence: high

      - security_id: TECH_SUPPLY_1
        name: 製造受託関連銘柄
        description: >
          原薬・製造受託・充填工程など、肥満治療薬の供給網に関わる周辺受益銘柄。
          増産や供給制約緩和ニュースに反応しやすい。
        weight: 0.04
        role: satellite
        pillar: 製造・供給
        exposure_direction: indirect
        exposure_confidence: medium

    controls:
      relevance_threshold: 0.41
      margin_threshold: 0.05
      min_constituent_breadth: 0.18
      max_single_name_weight: 0.22
      purity_prior: 0.76
      liquidity_prior: 0.92

    metadata:
      notes: >
        「肥満」単語単独は曖昧なので、治療薬・承認・供給・償還との結びつきを重視。
      updated_at: 2026-04-15
```

* * *

このサンプルで特に見てほしい点
===============

1\. `description` は短いが、埋め込み向けに濃くしている
------------------------------------

現行パイプラインではテーマ定義読み込み後、この `description` が中心的なテーマ表現になります。したがって、ここは単なる紹介文ではなく、**埋め込み用の代表文** にすべきです。

2\. `thesis` を別で持たせている
----------------------

これは将来、

*   テーマ embedding を `description` だけでなく `thesis` も使って作る
*   ダッシュボードでテーマの説明を出す
*   人手レビュー時にテーマの境界を確認する

ために効きます。

3\. `lexicon` を分解している
---------------------

現行の `aliases` と `keywords` をそのまま残すより、

*   コア語
*   ドライバー語
*   周辺語
*   除外語
*   曖昧語

に分けた方が、後で relevance の説明性が高くなります。

4\. `constituents.description` を業種ではなく役割説明にしている
-----------------------------------------------

これは breadth 推定のためです。  
将来的に、ニュースと各銘柄の説明文の近さから

*   このニュースはテーマ内のどの pillar に効くか
*   上位1銘柄だけか、複数銘柄へ広く効くか

を見られるようにするためです。

5\. `controls` を先に入れている
-----------------------

今は実際に使うのは `threshold` が中心でも、将来的には

*   `relevance_threshold`
*   `margin_threshold`
*   `min_constituent_breadth`

などを使いたくなるので、YAML 側は先に分けておくと楽です。

* * *

まず次にやるべきこと
==========

次の順で進めるのが一番自然です。

### 1

**いま持っている全テーマ定義を、この新フォーマットへ機械的に移す**  
この段階では `description`, `thesis.one_liner`, `lexicon`, `constituents.role/pillar` を埋めるだけで十分です。

### 2

その後に、**現行ローダーが落ちないよう互換を保ちつつ、追加項目を読む改修方針を決める**  
現行ローダーはフラット項目前提なので、追加項目はまだ未使用でも問題ありません。

io

### 3

次に、**theme embedding を `description` 単独から、`description + thesis + constituents.description` 合成へ拡張する**  
現行の埋め込み生成・キャッシュはテキスト列を入力すれば使える構造なので、ここは比較的拡張しやすいです。

embed

* * *

実務上の注意
======

一番ありがちな失敗は、`description` を長く書きすぎて、何でも入る文章にしてしまうことです。  
そうすると類似度空間で境界がぼけます。

なので使い分けは次がよいです。

*   `description`  
    埋め込み比較用の代表文。**短め・高密度**
*   `thesis.investment_thesis`  
    人間が読むための投資ストーリー。**やや長めで可**
*   `constituents.description`  
    銘柄とテーマの関係を示す文。**役割ベース**

* * *

必要なら次に、  
**あなたの今の YAML 形式を前提に、既存テーマ群を一括変換するための「記入ルール集」** を作ります。

## Response:
2026/4/15 21:07:57

> 思考時間: 数秒

その「テーマメモリ」は、**いまの YAML のどの項目にもまだ対応していません**。  
正確には、これは **静的テーマ定義の一部ではなく、日々更新される動的データ層** として持つべきものです。

現行のテーマ定義ファイルとコードは、基本的に

*   `theme_id`
*   `name_ja`
*   `description`
*   `threshold`

を読んで、テーマ埋め込みを作り、記事との類似度を計算する構造です。つまり今あるのは **静的テーマ表現** だけです。

io

埋め込み生成も、与えられたテキスト列をその時点でベクトル化してキャッシュする形であり、「過去に高関連だったニュースを蓄積してテーマ側へ戻す」仕組みはまだありません。

* * *

位置づけ
----

整理すると、テーマ表現は本来3層あります。

### 1\. 静的テーマ定義

YAML に入る部分です。

*   `description`
*   `thesis`
*   `lexicon`
*   `constituents`

これは **初期テーマ表現** です。

### 2\. バスケット表現

構成銘柄説明とウェイトから作る表現です。  
これも YAML と銘柄説明データから作れます。

### 3\. テーマメモリ

これが質問の対象です。  
これは

*   過去にそのテーマへ高関連と判定されたニュース
*   そのニュースの relevance
*   そのニュースの tone / topic / breadth
*   直近何日で残すか
*   どの程度の重みで残すか

から作る、**時変のテーマコンテキスト**です。

つまり、YAML ではなく、別の保存物として持つべきです。

* * *

どこに対応させるべきか
-----------

設計上は、YAML には **メモリ本体ではなく、メモリの更新ルール** だけを持たせるのが自然です。

たとえばテーマ定義の中に次を追加します。

```
memory:
  enabled: true
  min_relevance: 0.60
  lookback_days: 30
  half_life_days: 7
  max_items: 500
  use_event_level: true
  include_manual_promoted: true
```

これは「このテーマはどの条件でテーマメモリを更新するか」の設定です。  
一方で、実際のメモリ本体は別ファイルに持ちます。

* * *

実際に持つべきデータ
----------

テーマメモリは、たとえば日次でこういうテーブルになります。

### theme\_memory\_items.parquet

各高関連ニュースの記録

*   `theme_id`
*   `article_id` または `event_id`
*   `published_at`
*   `relevance_score`
*   `tone_scores`
*   `topic_id`
*   `breadth_score`
*   `source`
*   `text_hash`
*   `embedding`

### theme\_memory\_daily.parquet

その日までのテーマメモリ集約

*   `theme_id`
*   `as_of_date`
*   `memory_embedding`
*   `memory_size`
*   `avg_relevance`
*   `topic_dispersion`
*   `recent_shift_score`

この `memory_embedding` が、前に話していた `flowing context embedding` に相当します。

* * *

YAML との対応関係
-----------

なので対応関係はこうです。

*   `description`  
    テーマの**静的代表文**
*   `constituents.description`  
    テーマの**バスケット表現の元**
*   `memory.*`  
    テーマメモリの**更新ルール**
*   `theme_memory_*` テーブル  
    テーマメモリの**実体**

つまり、質問への直接回答は、

**「過去にそのテーマへ高関連と判定されたニュース群からなるテーマメモリ」は、YAML の本文ではなく、YAML に更新ルールだけを持たせ、実体は別の時系列データとして管理するのが正しい**  
です。

* * *

なぜ YAML に直接埋め込まないのか
-------------------

理由は3つあります。

### 1\. 毎日更新されるから

YAML は静的定義向きです。  
過去ニュース群は日々増えるので、不向きです。

### 2\. ベクトルや大量ニュースを持つには重すぎるから

テーマごとに数百件の関連ニュースを持つと、YAML は管理しづらいです。

### 3\. 静的定義と動的状態を分けた方が解釈しやすいから

テーマの意味そのものと、最近どう語られているかは別です。  
混ぜると、「テーマ定義が変わった」のか「最近ニュースが偏った」のか分からなくなります。

* * *

どういう更新式になるか
-----------

テーマメモリ埋め込みは、実装上はたとえばこうです。

$$
e^{flow}_{j,t} = (1-\lambda)\sum_{\tau=t-L+1}^{t}\lambda^{t-\tau} \cdot \frac{\sum_{n \in \mathcal{N}_{j,\tau}} \alpha_{n,j,\tau} e^{news}_{n}}{\sum_{n \in \mathcal{N}_{j,\tau}} \alpha_{n,j,\tau}}
$$

ここで

*    $\mathcal{N}_{j,\tau}$ : その日にテーマ  $j$  に高関連だったニュース群
*    $\alpha_{n,j,\tau}$ : relevance や source quality を反映した重み
*    $L$ : lookback 日数
*    $\lambda$ : 減衰率

です。

これを毎日更新して、最終テーマ表現

$$
e^{theme}_{j,t} = \beta_1 e^{core}_j + \beta_2 e^{basket}_{j,t} + \beta_3 e^{flow}_{j,t}
$$

に入れます。

* * *

いまの YAML に足すなら何か
----------------

静的定義側には、まずこれだけ足せば十分です。

```
memory:
  enabled: true
  min_relevance: 0.60
  lookback_days: 30
  half_life_days: 7
  max_items: 300
  use_event_level: true
```

意味は次です。

*   `enabled`  
    メモリ更新を使うか
*   `min_relevance`  
    どの程度高関連ならメモリに採用するか
*   `lookback_days`  
    何日分を見るか
*   `half_life_days`  
    古いニュースをどれだけ減衰させるか
*   `max_items`  
    最大保持件数
*   `use_event_level`  
    記事単位でなく event 単位で持つか

* * *

実務的な注意
------

このテーマメモリは有力ですが、入れ方を間違えると危険です。

一番大きな注意点は、**最近ニュースが多いだけでテーマ meaning が漂流すること**です。  
なので私は、

*   `description` と `thesis` を主軸
*   `constituents` を実体のアンカー
*   `theme memory` は短期補正

として使うのを推奨します。

つまり重みは普通、

*   core 50〜70%
*   basket 20〜40%
*   memory 10〜30%

くらいから始めるのが安全です。

* * *

必要なら次に、  
**YAML に `memory` ブロックを組み込んだ完全版テーマ定義サンプル** を出します。

## Response:
2026/4/15 21:17:29

現行コードの骨格は保ちつつ、Layer A と Layer B を差し込めるように拡張します。まずは既存モジュールの入出力を崩さずに、テーマ定義拡張・テーマメモリ・複合類似度・銘柄 breadth を追加できる形に整理します。

大きな構造変更なしで入れ込むため、既存の `description + threshold` 互換は保ちます。追加実装は「テーマ定義の拡張読込」「静的+動的テーマ表現の合成」「ニュース→テーマの relevance/breadth 分解」に絞ります。

実装自体は入れ込みました。いまは、既存ノートブックからどう呼ぶかが分かるように、Layer A/B を差し込む最小の使用例も併せて用意します。

> **検査とコード修正の計画**
>
>
> **検討中のモジュール修正と新規作成**
>
> 新しいモジュールを作成し、パッケージ名を確認する必要がありそうです。`theme_assign` と `preprocess/config` を強化する予定です。ノートブックを再設計し、ファイルを `/mnt/data` に作成した方が楽かもしれません。それに合わせて、新しい関数や処理を追加してテーマの表現を時間変化で表現します。
>
> **テーマ表現とメモリ関数の設計**
>
> エイリアスや関連用語を含むカラムを追加して、テーマ表現テキストを作成する関数を実装する必要があります。また、記事データを元にテーマメモリを生成する関数も設計します。ただし、ノートブックの変更は最小限にとどめ、コードファイルとREADMEを提供する形にし、動作確認を行います。
>
> **テーマメモリと動的埋め込みの構築**
>
> テーマの埋め込みとメモリを動的に組み合わせるため、簡単な方法として、説明、レキシコン、構成要素のテキストから静的テーマテキストを作成し、それを基に動的な埋め込みを計算します。テーマテキストの管理機能を最小限にするため、既存の埋め込みツールを活用できます。
>
> **テーマ得点の計算と埋め込みの調整**
>
> テーマ得点を計算するために、コア、バスケット、メモリの類似度を計算し、構成要素の埋め込みを抽出するための補助関数が必要です。さらに、旧バージョンの関数を保持しつつ、必要に応じてオプションのパラメータを追加します。
>
> **プログラムの実装と構成整理**
>
> ユーザーが求めたLayer A/Bを実装するため、`build_similarity_scores`に変更を加え、ランクとマージンも実装します。ファイル名に関して、適切なパッケージ構造を作成し、アップロードされたファイルを改名して保存します。また、設定ファイルも新しいパラメータと出力パスに対応させます。
>
> **テーマメモリーテーブルと埋め込みの追加**
>
> テーマメモリーテーブルとテーマコンポーネントの埋め込みを追加する必要がありそうです。`__init__.py`のエクスポートを更新することも考慮しますが、慎重に進めるべきですね。
>
> **実装と構成管理**
>
>
> 思考時間: 8m 3s

実装しました。既存の骨格は維持しつつ、Layer A と Layer B を差し込めるように拡張しています。

主な変更点です。

*   `io(1).py`
    *   新しいテーマ YAML を読めるように拡張
    *   `thesis / lexicon / controls / memory / constituents` をフラット化して保持
*   `preprocess(1).py`
    *   `build_theme_text_views`
    *   `build_constituent_texts`  
        を追加
*   `theme_assign(1).py`
    *   `build_theme_memory_items`
    *   `build_theme_memory_snapshot`
    *   `combine_theme_embeddings`
    *   拡張版 `build_similarity_scores`  
        を追加
    *   `similarity_core / similarity_basket / similarity_memory / breadth_score / margin_to_next` を出力
*   `config(1).py`
    *   テーマメモリ、動的テーマ埋め込み、breadth 関連の設定と出力パスを追加
*   `layer_a_b_usage_example.py`
    *   既存ノートブックへ貼り込める最小統合例を追加

ファイルはこちらです。

*   config(1).py
*   io(1).py
*   preprocess(1).py
*   theme\_assign(1).py
*   layer\_a\_b\_usage\_example.py

実装上のポイントだけ補足します。

*   Layer A は  
    `theme_text_core` + `theme_text_basket` + 高関連ニュースから作る `theme memory` を合成して、動的テーマ埋め込みを作る形です。
*   Layer B は  
    既存の類似度判定を壊さずに、記事ごとに
    *   core 類似度
    *   basket 類似度
    *   memory 類似度
    *   constituent breadth
    *   top1-top2 margin  
        を追加で計算する形にしています。
*   既存コード互換のため、`theme_id / name_ja / description / threshold` はそのまま使えます。

この段階では **ノートブック本体は自動では書き換えていません**。その代わり、`layer_a_b_usage_example.py` をそのまま既存 notebook の中へ移せば、Layer A/B を使った2パス推論に置き換えられます。  
次は、これを踏まえて `main(1).ipynb` 側も実際に差し替えますか。

## Response:
2026/4/15 23:17:33

ノートブック本体へ組み込みます。既存セル構成をなるべく保ちつつ、Layer A/B を使う前処理・テーマ埋め込み生成・スコア計算の流れだけ差し替えます。

ノートブックだけ差し替えるより、依存モジュール側も実際に拡張して整合させます。これで notebook 単体ではなく、元のモジュール構成のまま Layer A/B を再利用できます。

> **Inspecting notebook structure and content**
>
>
> **Inspecting files for contents**
>
>
> **インポートとセル内容の検査**
>
>
> **考慮中のノートブックとモジュールの修正方法**
>
> ユーザーの要望に基づいて、パッケージとしてノートブックにインポートする代わりに、アップロードされたファイルから動的にモジュールを読み込む方法を検討しています。それが実現しなければ、インラインで関数定義を挿入することも考えられます。
>
> **更新されたモジュールとノートブックの修正**
>
>
> **ファイル名の引用とPythonの活用**
>
> ファイル名を括弧で囲む必要があると思います。Pythonを使うと、ファイルの書き込み作業が簡単になるので、これを活用するのが良さそうですね。
>
> **フィル名に括弧を含むファイルの作成**
>
>
> **コンテナの使い方とファイルアクセス設定**
>
> コンテナを使う際、root権限で実行する必要があるかもしれません。`ls` コマンドで確認したところ、`/mnt/data` のファイルは root 所有のようですが、Python は root でないかもしれません。`container.exec` で bash を使い、ファイル名を引用符で囲んで実行してみます。
>
> **ファイルのパーミッション確認**
>
>
> **コンテナ内でrootとして実行**
>
> ファイルを書き換えるためには、`container.exec` を root 権限で使用する必要があります。そのため、Pythonスクリプトを実行する際も、`container.exec` を使って root ユーザーとして実行する方法を選びます。
>
> **実行コンテナ内でPythonスクリプトを使用**
>
>
> **ノートブック修正方法の決定**
>
> スクリプトが未完成でしたが、ノートブック変更だけで良いかもしれません。モジュールを編集する代わりに、関数をインラインで追加したノートブックを作成する方法がシンプルで、既存のアップロードされたモジュールをそのまま使えます。それで、修正した新しいノートブックを作成します。
>
> **ノートブック修正の続き**
>
> 新しいファイルに書き込むから上書きの問題はなし。外部モジュールを変更する代わりに、ノートブック内のセルにインポートのフォールバックとヘルパー関数を追加します。YAMLの新しいネストされたフォーマットに対応するため、`load_theme_definitions_v2` を使って解決し、必要な変数や関数を定義します。
>
> **ノートブックの改良**
>
> まず、セル0の後にヘルパー関数（`load_theme_definitions_extended` や `build_theme_text_views` など）を挿入する。また、セル2を新しいローダー関数に変更し、セル5を記事とテーマのコンポーネント埋め込み生成に変更。セル6は静的・動的な類似性を扱い、セル7では`score_df`を使った割り当て処理を維持。一部は既存の埋め込み処理に留める予定。
>
> **Modifying notebook with helper functions and updates**
>
>
> **ノートブックのセル検証と表示**
>
>
> **パッチ適用：cell6 ローカルパスのフォールバック**
>
>
> 思考時間: 15m 33s

ノートブック本体に組み込んだ版を作成しました。

ファイルはこちらです。  
main\_layer\_ab.ipynb

反映内容は次です。

*   **Layer A: テーマ表現の時変化**
    *   拡張 YAML を読める `load_theme_definitions_extended`
    *   `description + thesis + lexicon` から `theme_text_core`
    *   `constituents` から `theme_text_basket`
    *   第1パスの高関連ニュースから `theme memory`
    *   `core + basket + memory` の合成テーマ埋め込み
*   **Layer B: ニュース → テーマの多面的帰属**
    *   `similarity_core`
    *   `similarity_basket`
    *   `similarity_memory`
    *   `breadth_score`
    *   `breadth_coverage`
    *   `margin_to_next`  
        をスコア表へ追加
*   **既存フローは維持**
    *   その後の `assign_multilabels`
    *   residual 抽出
    *   BERTopic
    *   label store
    *   reporting  
        は元の流れのまま使えます

実装上の注意点を2つだけ挙げます。

1.  これは**既存ノートブックを壊さずに Layer A/B を差し込む最小改修**です。  
    tone head や dynamic topic state の本格実装まではまだ入れていません。今回はまず、
    *   動的テーマ表現
    *   core / basket / memory 分解
    *   constituent breadth  
        までを入れています。
2.  現行の `news_theme_pipeline` パッケージが古いままでも動くように、必要な Layer A/B 関数は**ノートブック内に補助関数として埋め込み**ました。  
    なので、まずはこの notebook 単体で試せます。

次にやるなら、これを notebook 内の暫定関数ではなく、`config.py / io.py / preprocess.py / theme_assign.py` 側へ正式に戻して、パッケージ全体として整備します。

## Response:
2026/4/15 23:38:06

パッケージとして再利用できる形に整えます。Notebook 内の暫定関数をモジュール側へ戻し、既存フローから呼べる API に揃えます。

主要モジュールは差し替え済みです。いま、読み込み時の整合性チェックをしていて、必要なら import 周りも含めて最終調整します。

> **ファイルの内容確認と表示**
>
>
> **スクリプトの内容確認と調整**
>
>
> **設定ファイルと関数の実装**
>
>
> 思考時間: 6m 36s

パッケージ全体として整備しました。  
既存の最小パイプライン構成を保ちながら、Layer A / Layer B をモジュールとして再利用できる形にしています。

更新したファイルです。

*   **init**(1).py
*   config(1).py
*   io(1).py
*   preprocess(1).py
*   theme\_assign(1).py

何を整備したか
-------

### 1\. `io(1).py`

拡張 YAML を正式に読めるようにしました。

*   互換維持:
    *   `theme_id`
    *   `name_ja`
    *   `description`
    *   `threshold`
*   追加読込:
    *   `thesis`
    *   `lexicon`
    *   `memory`
    *   `controls`
    *   `constituents`
*   `constituents` は `constituent_records` に正規化して保持

これで、いまのフラット実装を壊さずに、新しいテーマ定義を読めます。

### 2\. `preprocess(1).py`

Layer A 用のテーマ表現生成を追加しました。

*   `build_theme_text_views(theme_df)`
    *   `theme_text_core`
    *   `theme_text_basket`  
        を生成
*   `build_constituent_texts(theme_df)`
    *   constituent 単位のテキスト表現を生成

### 3\. `theme_assign(1).py`

Layer A / B の中核を追加しました。

*   `build_theme_memory_items(...)`
    *   高関連ニュースからテーマメモリ候補を生成
*   `build_theme_memory_snapshot(...)`
    *   テーマごとの memory embedding を集約
*   `combine_theme_embeddings(...)`
    *   core / basket / memory を加重合成
*   `build_similarity_scores(...)`
    *   既存 API を保ちながら拡張
    *   追加出力:
        *   `similarity_core`
        *   `similarity_basket`
        *   `similarity_memory`
        *   `breadth_score`
        *   `breadth_coverage`
        *   `margin_to_next`

既存の `assign_multilabels` と `apply_assignment_overrides` はそのまま使えます。

### 4\. `config(1).py`

新しいパラメータと出力先を追加しました。

*   テーマ埋め込み合成重み
*   テーマメモリ設定
*   margin filter
*   breadth gate
*   追加出力パス
    *   `THEME_COMPONENT_EMBEDDING_CACHE_PATH`
    *   `CONSTITUENT_EMBEDDING_CACHE_PATH`
    *   `THEME_MEMORY_ITEMS_PATH`
    *   `THEME_MEMORY_DAILY_PATH`
    *   `THEME_DYNAMIC_EMBEDDINGS_PATH`

### 5\. `__init__(1).py`

新しい関数群を export しました。  
これで package import からそのまま Layer A / B を呼べます。

* * *

この状態でできること
----------

パッケージとして、次の流れがそのまま実行できます。

1.  拡張 YAML 読込
2.  `theme_text_core` / `theme_text_basket` 生成
3.  article / theme / constituent 埋め込み生成
4.  第1パスで static theme relevance 計算
5.  高関連ニュースから theme memory 構築
6.  `core + basket + memory` の動的テーマ表現合成
7.  第2パスで relevance + breadth + margin を計算
8.  そのまま既存の multilabel assign / residual BERTopic / label store へ接続

* * *

まだ入れていないもの
----------

今回の整備範囲は、依頼どおり

*   **Layer A: テーマ表現の時変化**
*   **Layer B: ニュース → テーマの多面的帰属**

までです。

なので、まだ本格実装していないのは次です。

*   topic-state head の本格版
    *   BERTopic topics-over-time を theme 単位に回す部分
*   tone head
    *   growth / regulation / supply-chain / crowding など
*   theme-day aggregation と return-predictive supervised layer

ここは次段階です。

* * *

使い方の要点
------

既に作ってある `layer_a_b_usage_example.py` の流れで、そのまま package 側の関数を呼べます。  
つまり notebook 内の暫定関数ではなく、今後はこの package API を正式に使う前提に戻せます。

* * *

補足
--

文法チェックは通しています。  
この次にやると自然なのは、`main_layer_ab.ipynb` の notebook 内に埋め込んだ補助関数を削って、**今回整備した package API 呼び出しに完全置換**することです。

## Response:
2026/4/15 23:48:24

> 思考時間: 6s

承知しました。  
実装には触れず、**YAML の構成そのもの**を、設計意図まで含めて詳しく整理します。

結論からいうと、今回の YAML は単なる「テーマ辞書」ではなく、**テーマを機械可読な投資オブジェクトとして定義するための設計書**です。  
役割は大きく3つあります。

*   テーマの意味を固定する
*   ニュースとの関連付けの基準を与える
*   将来の動的更新や投資判断の土台を与える

現行コードは `theme_id / name_ja / description / threshold` を中核に扱う最小構成なので、そこは互換のため残しつつ、YAML 側ではより豊かな情報を持たせるのが自然です。

io

theme\_assign

* * *

1\. この YAML は何を定義するものか
======================

この YAML は、見た目上は「テーマ一覧」ですが、設計思想としては次の3層を定義する器です。

1-1. テーマの静的定義
-------------

これは「そのテーマとは何か」を人間と機械の両方に明示する部分です。

例:

*   AIインフラとは何か
*   地方銀行テーマとは何か
*   肥満治療テーマとは何か

ここでは、テーマ名だけでなく、投資ストーリー、構成要素、関連語、混同しやすい語まで定義します。

1-2. テーマの実体
-----------

これは「そのテーマを実際に何で表現するか」です。

例:

*   構成銘柄
*   構成ウェイト
*   各銘柄がテーマの中で果たす役割
*   コア受益なのか周辺受益なのか

つまり、テーマ名ではなく**投資可能なバスケットとしてのテーマ**を表します。

1-3. テーマの運用ルール
--------------

これは「ニュースとの関連付けや将来の動的更新でどう扱うか」です。

例:

*   どの程度の関連度でそのテーマとみなすか
*   何日分の高関連ニュースをメモリとして使うか
*   breadth をどの程度必要とするか
*   純度をどの程度重視するか

この3層を一つの YAML に分けて入れるのが今回の設計です。

* * *

2\. ルート構造
=========

まず最上位はこうです。

```
version: 2
themes:
  - ...
  - ...
```

`version`
---------

これはスキーマの版管理です。

役割は、

*   将来構造を変えたときに互換性を判定する
*   ローダーで処理分岐しやすくする
*   古い定義ファイルと新しい定義ファイルを区別する

ためです。

テーマ定義は長く使うので、版番号は持っておいた方がよいです。

`themes`
--------

テーマの配列です。  
1テーマ = 1オブジェクトです。

重要なのは、将来的にテーマ数が増えても、各テーマが**同じ構造**を持つことです。  
そうしないと、特定テーマだけ特別扱いする設計になって保守性が落ちます。

* * *

3\. 各テーマオブジェクトの全体像
==================

各テーマは大きく次のブロックに分かれます。

*   `theme_id`
*   `name_ja`
*   `name_en`
*   `description`
*   `threshold`
*   `thesis`
*   `lexicon`
*   `constituents`
*   `controls`
*   `metadata`
*   `memory`（必要なら）

これを意味ごとに整理すると、

*   **識別子**: `theme_id`, `name_ja`, `name_en`
*   **埋め込み・基準文**: `description`
*   **投資ストーリー**: `thesis`
*   **語彙辞書**: `lexicon`
*   **投資対象実体**: `constituents`
*   **判定ルール**: `controls`
*   **補足情報**: `metadata`
*   **動的更新ルール**: `memory`

です。

* * *

4\. `theme_id`
==============

```
theme_id: AI_INFRA
```

これはテーマの一意識別子です。

役割は単純ですが非常に重要です。

*   データベースや parquet の join キーになる
*   モデル出力の主キーになる
*   テーマ名変更があっても同一テーマとして追跡できる
*   多言語名や別名と独立に管理できる

良い `theme_id` の条件
-----------------

*   人間が読んでも分かる
*   できるだけ不変
*   表記揺れしない
*   日本語名に依存しない

`AI_INFRA` や `REGIONAL_BANKS_JP` のような英数字ベースが扱いやすいです。

* * *

5\. `name_ja`, `name_en`
========================

```
name_ja: AIインフラ
name_en: AI Infrastructure
```

これは表示用名称です。

役割は

*   ダッシュボード表示
*   可視化凡例
*   レポート出力
*   人手レビュー時の可読性

です。

`theme_id` と違って、こちらは多少変更される可能性があります。  
たとえば「生成AIインフラ」から「AI計算基盤」に変えることもありえます。  
そのため、識別には使わず、表示専用にするのが基本です。

* * *

6\. `description`
=================

```
description: >
  生成AIや機械学習の普及に伴って需要が増加する、半導体、サーバー、
  ネットワーク、電力、冷却、データセンターなどの基盤設備に関するテーマ。
```

これは**埋め込み比較用の代表文**です。  
YAML 全体の中でもかなり重要な項目です。

役割
--

*   テーマ埋め込みの最初の核になる
*   ニュース本文との意味類似度比較に使う
*   テーマの境界を短く凝縮して表す

何を書くべきか
-------

ここには、テーマのコア概念を**短く・密度高く**書きます。

含めるべきなのは

*   テーマの中心対象
*   関連する主要サブ領域
*   重要ドライバー
*   混同回避に必要な限定

です。

何を書きすぎない方がいいか
-------------

*   詳細な投資論
*   あまりに長い背景説明
*   なんでも入る一般語

`description` は長文の説明欄ではなく、**意味空間上のアンカー**です。

`thesis` との違い
-------------

*   `description`: 埋め込み向け代表文
*   `thesis`: 人間が読む投資ストーリー

です。

* * *

7\. `threshold`
===============

```
threshold: 0.42
```

これは現行パイプライン互換のための項目です。  
ニュースとテーマの類似度がこの値以上なら「関連あり」とみなす、という基本閾値です。

theme\_assign

役割
--

*   類似度スコアを二値判断に落とす
*   テーマごとの判定の厳しさを調整する
*   既存コード互換を維持する

なぜテーマ別に必要か
----------

テーマによって抽象度が違うからです。

例:

*   「AI」は広すぎて誤ヒットしやすい
*   「肥満治療」は比較的具体的で当たりやすい

したがって、テーマごとに threshold を変えられる設計は自然です。

将来的な位置づけ
--------

今後は `controls.relevance_threshold` へ寄せていくのがよいですが、現時点では互換のため残すのが妥当です。

* * *

8\. `thesis`
============

```
thesis:
  one_liner: ...
  investment_thesis: ...
  economic_mechanism:
    - ...
  subpillars:
    - name: ...
      description: ...
```

これは**投資ストーリーを構造化して持つブロック**です。

* * *

8-1. `one_liner`
----------------

テーマの一文要約です。

役割は

*   人間が素早く意味を把握する
*   UI や一覧表示で短く出す
*   大分類をざっくり捉える

ことです。

`description` に似ていますが、`description` は埋め込み寄り、`one_liner` は説明寄りです。

* * *

8-2. `investment_thesis`
------------------------

ここはテーマの中心的な投資仮説を書きます。

役割は

*   そのテーマがなぜ投資対象になるのかを明文化する
*   ニュースの重要度を評価する文脈を与える
*   人手レビュー時の基準を与える

ここで書くべきなのは

*   成長ドライバー
*   収益源泉
*   規制・政策・供給制約
*   競争構造
*   価格形成に効く論点

です。

これがあると、「そのニュースはこのテーマの本質に関係しているのか」を判断しやすくなります。

* * *

8-3. `economic_mechanism`
-------------------------

これは箇条書きで、テーマを動かす因果メカニズムを持たせる欄です。

例:

*   長期金利上昇 → 預貸利ざや改善
*   AI需要増 → GPU・電力・冷却需要増
*   保険償還拡大 → 肥満治療薬の普及加速

役割
--

*   テーマの論理構造を明示する
*   tone head を将来作るときの軸になる
*   ニュースタイプ分類の基礎になる

単なる説明文よりも、箇条書きにすることで後で利用しやすくなります。

* * *

8-4. `subpillars`
-----------------

これはテーマの内訳です。

例:

*   AIインフラ
    *   半導体・計算資源
    *   ネットワーク
    *   電力・冷却
    *   データセンター

役割
--

*   テーマを下位構造に分解する
*   バスケット内銘柄の役割を紐づける
*   ニュースがどの部分に効いたかを把握する

これは breadth や topic shift を見るときに非常に効きます。  
テーマ全体に効いたのか、一部 pillar だけなのかを見られるからです。

* * *

9\. `lexicon`
=============

```
lexicon:
  aliases:
    - ...
  canonical_terms:
    - ...
  driver_terms:
    - ...
  related_terms:
    - ...
  exclusion_terms:
    - ...
  ambiguous_terms:
    - ...
```

これは**語彙辞書ブロック**です。  
現行の `aliases` と `keywords` を分解・強化したものです。

* * *

9-1. `aliases`
--------------

テーマそのものの別名です。

例:

*   地方銀行
*   地銀
*   地域金融機関

役割
--

*   表記揺れ吸収
*   見出しベース判定の補助
*   テーマ検索や UI の別名対応

これは「同じものを指す別表現」です。

* * *

9-2. `canonical_terms`
----------------------

テーマを直接表すコア語です。

例:

*   GPU
*   AIサーバー
*   GLP-1
*   地方銀行

役割
--

*   テーマ同定の中心語
*   高い判定力を持つ語群
*   description を補完する核語

これが強いほど、直接関連ニュースを取りやすくなります。

* * *

9-3. `driver_terms`
-------------------

テーマを動かす要因語です。

例:

*   長期金利
*   設備投資
*   保険償還
*   供給不足

役割
--

*   テーマの原因・触媒を表す
*   直接テーマ名が出ないニュースを拾う
*   トピック分類や重要度評価の補助

つまり、テーマそのものではなく、**テーマを動かす外生要因・内生要因**です。

* * *

9-4. `related_terms`
--------------------

周辺概念です。

例:

*   液冷
*   原薬
*   自己株買い
*   データセンター容量

役割
--

*   サブトピックとの橋渡し
*   breadth 拡張
*   トピッククラスタリング時の補助

これは直接語ほど強くないが、テーマの周辺として重要です。

* * *

9-5. `exclusion_terms`
----------------------

誤判定を減らすための除外語です。

例:

*   AI倫理
*   美容痩身
*   損害保険
*   メガバンク

役割
--

*   semantic 類似だけでは誤る記事を弾く
*   テーマ境界を狭める
*   曖昧語の誤帰属を防ぐ

これは精度改善にかなり効きます。

* * *

9-6. `ambiguous_terms`
----------------------

よく出るが判定力の弱い語です。

例:

*   AI
*   金融
*   ヘルスケア
*   銀行

役割
--

*   一般語として管理する
*   単独では強い証拠にしない
*   relevance の説明性を高める

これは「使わない語」ではなく、「過信しない語」です。

* * *

10\. `constituents`
===================

```
constituents:
  - security_id: NVDA
    name: NVIDIA
    description: ...
    weight: 0.12
    role: core
    pillar: 半導体・計算資源
    exposure_direction: direct
    exposure_confidence: high
```

これはテーマの**実際の投資対象**を定義するブロックです。

* * *

10-1. `security_id`
-------------------

銘柄識別子です。

役割は

*   価格データや保有データとの接続
*   構成比更新
*   企業情報テーブルとの join

です。

* * *

10-2. `name`
------------

表示用銘柄名です。

* * *

10-3. `description`
-------------------

ここは非常に重要です。  
単なる業種名ではなく、**その銘柄がテーマの中で何を担うか** を書きます。

例:

*   AI計算需要の中心的受益銘柄
*   地方銀行グループとして再編・資本政策との結びつきが強い
*   原薬・製造受託の周辺受益銘柄

役割
--

*   constituent embedding の元になる
*   ニュースがどの銘柄に効いているかを見る basis になる
*   breadth の計算に使える

つまり、これは単なる銘柄説明ではなく、**テーマ内役割説明**です。

* * *

10-4. `weight`
--------------

テーマバスケット内ウェイトです。

役割
--

*   basket embedding の加重平均
*   breadth の重み付け
*   単一銘柄偏重の判定
*   純度や集中度の計算

* * *

10-5. `role`
------------

これはテーマ内での位置づけです。

例:

*   `core`
*   `satellite`

役割
--

*   コア受益か周辺受益かを区別
*   breadth を質的に解釈しやすくする
*   テーマ純度の補助情報になる

* * *

10-6. `pillar`
--------------

どの subpillar に属するかです。

役割は

*   ニュースがテーマ内のどこに効くかを見る
*   subpillar breadth を測る
*   topic shift を構造化して見る

* * *

10-7. `exposure_direction`
--------------------------

テーマとの関係の直接性です。

例:

*   `direct`
*   `indirect`

役割
--

*   ニュースの効き方の強弱を解釈する
*   テーマ純度を調整する
*   間接受益銘柄の過大評価を防ぐ

* * *

10-8. `exposure_confidence`
---------------------------

テーマとの関係に対する人手確信度です。

例:

*   `high`
*   `medium`
*   `low`

役割
--

*   定義の不確実性を表す
*   theme washing への防御
*   モデル側で重みを落とす余地を残す

* * *

11\. `controls`
===============

```
controls:
  relevance_threshold: 0.42
  margin_threshold: 0.06
  min_constituent_breadth: 0.20
  max_single_name_weight: 0.25
  purity_prior: 0.78
  liquidity_prior: 0.95
```

これは**判定・運用の制御パラメータ**です。

* * *

11-1. `relevance_threshold`
---------------------------

将来的な本命閾値です。  
`threshold` と似ていますが、意味的にはより新しい制御値です。

役割:

*   relevance の最低条件

* * *

11-2. `margin_threshold`
------------------------

上位テーマと次点テーマの差の最低値です。

役割:

*   あいまい帰属を減らす
*   top1 と top2 が僅差なら保留しやすくする

* * *

11-3. `min_constituent_breadth`
-------------------------------

テーマ内のどの程度の広がりが必要か、の最低条件です。

役割:

*   1銘柄だけに効いたニュースをテーマ全体のニュースと見なしすぎない
*   バスケット全体に効くニュースを優先する

* * *

11-4. `max_single_name_weight`
------------------------------

単一銘柄偏重の上限です。

役割:

*   純度と集中度を管理
*   幅の狭いテーマバスケットを識別

* * *

11-5. `purity_prior`
--------------------

テーマの事前純度です。

役割:

*   テーマ器としての信頼度を持たせる
*   news relevance をそのまま使いすぎないようにする

* * *

11-6. `liquidity_prior`
-----------------------

実装可能性の事前評価です。

役割:

*   取引コストやサイズ制約を加味する準備
*   実務上の使いやすさを補正する

* * *

12\. `metadata`
===============

```
metadata:
  notes: ...
  updated_at: 2026-04-15
```

これは補足情報ブロックです。

役割は

*   人間向けメモ
*   更新履歴
*   レビュー状況
*   注意点の保存

モデルには直接使わなくても、運用ではかなり有用です。

* * *

13\. `memory`
=============

これは前にも触れた通り、**メモリ本体ではなく更新ルール**を置く場所です。

例:

```
memory:
  enabled: true
  min_relevance: 0.60
  lookback_days: 30
  half_life_days: 7
  max_items: 300
  use_event_level: true
```

役割
--

*   どのニュースをテーマメモリに取り込むか
*   何日分持つか
*   どれくらい早く減衰させるか
*   記事単位か event 単位か

これに対して、実際のメモリ本体は別の時系列データに持つのが正しいです。

* * *

14\. 全体としての使い分け
===============

この YAML を一言で整理すると、各ブロックの役割は次です。

*   `description`  
    埋め込み比較のための短いアンカー
*   `thesis`  
    投資ストーリーと収益メカニズムの説明
*   `lexicon`  
    語彙的な補助情報と境界条件
*   `constituents`  
    投資対象としてのテーマの実体
*   `controls`  
    判定・運用のパラメータ
*   `memory`  
    動的テーマ更新のルール
*   `metadata`  
    人手運用用の補助情報

つまり、これは単なるラベル辞書ではなく、  
**テーマの意味・器・判定ルール・将来更新ルールをまとめた定義ファイル**です。

* * *

15\. 現行の簡易 YAML と比べて何が本質的に変わるか
==============================

元の簡易版は、

*   テーマ名
*   説明文
*   別名
*   キーワード
*   構成銘柄
*   threshold

でした。

これは「類似度判定器のための辞書」としては十分です。  
ただし、そのままだと

*   ニュースがテーマのどこに効いたのか
*   1銘柄だけか、全体か
*   純度が高いか
*   動的テーマ更新をどうするか

が持てません。

新しい構成はそこを補うために、

*   意味を `description + thesis + lexicon` に分解し
*   実体を `constituents` で具体化し
*   判定を `controls` に分離し
*   時変化を `memory` へ切り出した

ということです。

* * *

必要なら次に、  
**この YAML の各項目について「必須」「推奨」「将来用」に分類した一覧表**として整理します。

## Response:
2026/4/15 23:54:15

> 思考時間: 4s

以下の分類が実務的です。  
基準は、**今すぐ動かすために必要か**、**精度改善に強く効くか**、**将来拡張のために先に置いておくとよいか**、です。

* * *

必須
--

これは、テーマ定義として最低限ないと困る項目です。  
現行パイプライン互換の観点でも最重要です。現状コードは少なくとも `theme_id / name_ja / description / threshold` を必須として扱っています。

### `theme_id`

一意識別子です。  
全データの join キーになります。後で名前を変えても追跡できるように、表示名ではなく安定したIDにします。

### `name_ja`

表示用の日本語テーマ名です。  
可視化、レポート、人手レビューで使います。

### `description`

埋め込み比較の中核になる代表文です。  
短めでよいですが、テーマの中心概念・重要ドライバー・関連領域を高密度に含めるべきです。  
ここが弱いと、後段の relevance が全部ぶれます。

### `threshold`

現行互換の基本閾値です。  
将来的には `controls.relevance_threshold` に寄せても、当面は残すべきです。

### `constituents`

テーマの投資実体です。  
ニュース選別だけでなく、テーマバスケットとして何を買うのかを定義するために必要です。

### `constituents[].name`

構成銘柄名です。  
最小限の可読性のために必要です。

### `constituents[].weight`

ウェイトです。  
バスケット表現、breadth、集中度の基礎になります。

### `constituents[].description`

単なる業種ではなく、テーマとの関係を書くべきです。  
breadth や constituent-level relevance をやるなら、ここは実質必須です。

* * *

推奨
--

これは、なくても最初の最小版は動きますが、**精度・解釈性・将来の保守性**に大きく効く項目です。  
私なら初期段階から入れます。

### `name_en`

英語名です。  
論文・英文ニュース・多言語 embedding を使うなら有用です。

### `thesis.one_liner`

テーマの短い投資要約です。  
人間がテーマの境界を素早く確認できます。

### `thesis.investment_thesis`

投資ストーリー本文です。  
ニュースが「本当にこのテーマの本質に効いているか」を考える基準になります。

### `thesis.economic_mechanism`

因果メカニズムの箇条書きです。  
金利上昇→利ざや改善、AI需要増→電力需要増、のような形です。  
tone やニュースタイプ分類の軸になります。

### `thesis.subpillars`

テーマの下位構造です。  
後でニュースがどの pillar に効いたかを見るのに重要です。

### `lexicon.aliases`

別名です。  
表記揺れ対応に効きます。

### `lexicon.canonical_terms`

テーマを直接表すコア語です。  
description を補完します。

### `lexicon.driver_terms`

テーマを動かす要因語です。  
テーマ名が本文に出ないニュースを拾うのに効きます。

### `lexicon.related_terms`

周辺概念です。  
トピック拡張や breadth 解釈に有効です。

### `lexicon.exclusion_terms`

誤判定抑制にかなり効きます。  
広いテーマほど重要です。

### `lexicon.ambiguous_terms`

一般語を明示的に管理します。  
「AI」「金融」など、単独では強い証拠にしない語です。

### `constituents[].security_id`

ticker などの識別子です。  
価格や企業情報と紐づけるため、実務ではほぼ必須に近い推奨です。

### `constituents[].role`

`core` / `satellite` のような役割です。  
コア受益か周辺受益かを区別できます。

### `constituents[].pillar`

どの subpillar に属するかです。  
テーマ内 breadth を見るのに有用です。

### `constituents[].exposure_direction`

`direct` / `indirect` など。  
テーマ純度の解釈に効きます。

### `constituents[].exposure_confidence`

その銘柄が本当にテーマ銘柄か、という人手の確信度です。  
theme washing 対応として有効です。

### `controls.relevance_threshold`

将来の正式閾値です。  
`threshold` と分けて持っておくと移行しやすいです。

### `controls.margin_threshold`

top1 と top2 の差の最低値です。  
曖昧記事を減らせます。

### `controls.min_constituent_breadth`

1銘柄だけでなく、テーマ内にどれくらい広がっているかの最低条件です。  
テーマ投資ではかなり重要です。

### `metadata.updated_at`

定義更新日です。  
どの定義が古いか分かります。

### `metadata.notes`

人手メモです。  
例外処理や注意点を残す場所として便利です。

* * *

将来用
---

これは最初から埋めてもよいですが、**本格運用や拡張時に効く項目**です。  
初期実装では空でも構いません。

### `version`

スキーマ版管理です。  
テーマ定義の構造が変わったときに重要になります。

### `identity.status`

`active / deprecated` など。  
廃止テーマや休止テーマの管理に使えます。

### `identity.parent_theme_id`

親子テーマ構造です。  
「AI」配下に「AIインフラ」「AIアプリ」などを作るときに必要です。

### `identity.region`

地域軸です。  
JP / US / Global など。

### `identity.asset_type`

equity / ETF / basket など。  
将来マルチアセット化するなら便利です。

### `identity.theme_type`

structural / cyclical / policy-driven のような分類です。  
横断分析に使えます。

### `controls.max_single_name_weight`

単一銘柄偏重を制御します。  
純度・集中度管理に有効です。

### `controls.purity_prior`

テーマの事前純度です。  
text signal をそのまま信用しすぎないための重みになります。

### `controls.liquidity_prior`

実装可能性の事前評価です。  
取引しやすさを後で加味できます。

### `memory.enabled`

テーマメモリを使うかどうかです。

### `memory.min_relevance`

どの程度高関連ならテーマメモリへ採用するかです。

### `memory.lookback_days`

何日分の関連ニュースを保持するかです。

### `memory.half_life_days`

古いニュースの減衰速度です。

### `memory.max_items`

メモリ保持上限です。

### `memory.use_event_level`

記事単位でなく event 単位で持つかです。  
ニュース重複を減らすのに重要です。

### `metadata.created_by`

誰が定義したかです。  
チーム運用なら有用です。

### `metadata.review_status`

reviewed / draft など。  
品質管理に使えます。

* * *

私なら最初に採用する最小セット
---------------

最初から全部入れると重いので、現実的には次の3層で始めるのが良いです。

### 最低限の必須セット

*   `theme_id`
*   `name_ja`
*   `description`
*   `threshold`
*   `constituents[].name`
*   `constituents[].weight`
*   `constituents[].description`

### 最初から入れたい推奨セット

*   `name_en`
*   `thesis.one_liner`
*   `thesis.investment_thesis`
*   `thesis.subpillars`
*   `lexicon.aliases`
*   `lexicon.canonical_terms`
*   `lexicon.driver_terms`
*   `lexicon.exclusion_terms`
*   `constituents[].security_id`
*   `constituents[].role`
*   `constituents[].pillar`
*   `controls.relevance_threshold`
*   `controls.margin_threshold`
*   `controls.min_constituent_breadth`

### 後からでよい将来セット

*   `version`
*   `identity.*`
*   `controls.purity_prior`
*   `controls.liquidity_prior`
*   `memory.*`
*   `metadata.review_status`
*   `metadata.created_by`

* * *

判断基準を一言でまとめると
-------------

*   **必須**  
    今すぐテーマ relevance を出し、バスケットとして認識するのに必要なもの
*   **推奨**  
    精度・解釈性・将来の Layer A/B 拡張に強く効くもの
*   **将来用**  
    本格運用、品質管理、動的更新、投資実装まで進めると必要になるもの

必要なら次に、  
**この分類をそのまま反映した「最小推奨 YAML テンプレート」** を作ります。

## Response:
2026/4/15 23:57:30

> 思考時間: 2 ～ 3 秒

以下が、**最小推奨 YAML テンプレート**です。  
方針は、

*   **現行コード互換を保つ**
*   ただし将来の Layer A / Layer B に必要な項目は先に入れる
*   必須・推奨・将来用を見分けやすくする

です。現行ローダーは `theme_id / name_ja / description / threshold` を必須としているので、この4つはトップレベルに残します。

io

また、現行の類似度判定は `threshold` ベースなので、当面はこれも維持します。

theme\_assign

* * *

最小推奨 YAML テンプレート
================

```
version: 2

themes:
  - theme_id: SAMPLE_THEME_001                # 必須
    name_ja: サンプルテーマ                   # 必須
    name_en: Sample Theme                    # 推奨

    description: >                           # 必須
      このテーマの埋め込み比較用代表文。
      テーマの中心概念、主要ドライバー、関連領域を短く高密度に書く。

    threshold: 0.40                          # 必須（現行互換）

    thesis:                                  # 推奨
      one_liner: >
        このテーマの一文要約。
      investment_thesis: >
        このテーマが投資対象になる理由、収益源泉、注目論点を書く。
        長めでもよいが、テーマの境界が分かるようにする。
      economic_mechanism:                    # 推奨
        - ドライバー1が起きると、このテーマに追い風となる
        - ドライバー2が悪化すると、このテーマに逆風となる
      subpillars:                            # 推奨
        - name: コア領域
          description: テーマの中核となる部分
        - name: 周辺領域
          description: 間接受益や補完的領域

    lexicon:                                 # 推奨
      aliases:
        - サンプルテーマ
        - 別名1
      canonical_terms:
        - テーマを直接表す重要語1
        - テーマを直接表す重要語2
      driver_terms:
        - ドライバー語1
        - ドライバー語2
      related_terms:
        - 周辺語1
        - 周辺語2
      exclusion_terms:
        - 誤判定を防ぎたい語1
        - 誤判定を防ぎたい語2
      ambiguous_terms:
        - 一般語1
        - 一般語2

    constituents:                            # 必須
      - security_id: TICKER_A                # 推奨
        name: 構成銘柄A                      # 必須
    #   description は実質必須
        description: >
          この銘柄のテーマ内での役割を書く。
          単なる業種ではなく、なぜこのテーマ銘柄なのかを説明する。
        weight: 0.10                         # 必須
        role: core                           # 推奨
        pillar: コア領域                     # 推奨
        exposure_direction: direct           # 推奨
        exposure_confidence: high            # 推奨

      - security_id: TICKER_B
        name: 構成銘柄B
        description: >
          この銘柄のテーマとの関係を書く。
          周辺受益なら、そのことを明示する。
        weight: 0.05
        role: satellite
        pillar: 周辺領域
        exposure_direction: indirect
        exposure_confidence: medium

    controls:                                # 推奨
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.15

    memory:                                  # 将来用
      enabled: true
      min_relevance: 0.60
      lookback_days: 30
      half_life_days: 7
      max_items: 300
      use_event_level: true

    metadata:                                # 推奨〜将来用
      updated_at: 2026-04-15
      notes: >
        このテーマの注意点や補足メモを書く。
      created_by: analyst
      review_status: draft
```

* * *

このテンプレートの見方
===========

1\. いま絶対に埋める欄
-------------

ここは未記入にしない方がいいです。

*   `theme_id`
*   `name_ja`
*   `description`
*   `threshold`
*   `constituents`
*   `constituents[].name`
*   `constituents[].description`
*   `constituents[].weight`

この範囲だけでも、現行の最小テーマ分類器としては動かせます。特に `description` はテーマ埋め込みの核、`threshold` は判定の核、`constituents` はテーマの実体です。

2\. 初期段階から入れたい欄
---------------

精度改善に効くので、最初から入れる価値があります。

*   `name_en`
*   `thesis.one_liner`
*   `thesis.investment_thesis`
*   `thesis.subpillars`
*   `lexicon.aliases`
*   `lexicon.canonical_terms`
*   `lexicon.driver_terms`
*   `lexicon.exclusion_terms`
*   `constituents[].security_id`
*   `constituents[].role`
*   `constituents[].pillar`
*   `controls.relevance_threshold`
*   `controls.margin_threshold`
*   `controls.min_constituent_breadth`

3\. 後からでもよい欄
------------

動的テーマ更新や運用管理に進んでからでも十分です。

*   `memory.*`
*   `metadata.created_by`
*   `metadata.review_status`
*   さらに細かい purity / liquidity 系 controls

* * *

各欄の記入ルール
========

`description`
-------------

一番重要です。  
長文の紹介文ではなく、**意味類似の基準文**です。

良い書き方:

*   テーマの中核を入れる
*   主なドライバーを入れる
*   関連領域を少し入れる
*   曖昧すぎる一般語だけで終わらせない

悪い例:

```
description: AIに関するテーマ
```

良い例:

```
description: >
  生成AIや機械学習の普及に伴って需要が増加する、半導体、サーバー、
  ネットワーク、電力、冷却、データセンターなどの基盤設備に関するテーマ。
```

`investment_thesis`
-------------------

ここは埋め込み向けではなく、**人間向けの投資仮説**です。  
長めでも構いませんが、テーマの収益源泉が見えるようにします。

`canonical_terms`
-----------------

テーマそのものを直接指す語です。  
ここは少数精鋭がよいです。

`driver_terms`
--------------

テーマ名が出ないニュースを拾うための語です。  
ここをしっかり書くと、抽象的テーマでも関連ニュースを取りやすくなります。

`exclusion_terms`
-----------------

広いテーマほど重要です。  
誤判定が多いなら、まずここを増やすべきです。

`constituents[].description`
----------------------------

単なる業種名ではなく、**テーマとの関係**を書くべきです。  
ここが弱いと breadth をまともに測れません。

悪い例:

```
description: 半導体
```

良い例:

```
description: >
  AI計算需要の中心的受益銘柄。GPU、アクセラレータ、
  サーバー向けプラットフォームを提供する。
```

* * *

テーマ別の簡易記入例
==========

地方銀行
----

```
description: >
  日本の地方銀行・地域金融機関を中心に、長期金利、イールドカーブ、
  預貸利ざや、再編・統合、地域経済動向の影響を受けやすい金融テーマ。
```

```
driver_terms:
  - 長期金利
  - イールドカーブ
  - 預貸利ざや
  - 経営統合
```

AIインフラ
------

```
description: >
  生成AIや機械学習の普及に伴って需要が増加する、半導体、サーバー、
  ネットワーク、電力、冷却、データセンターなどの基盤設備に関するテーマ。
```

```
driver_terms:
  - 設備投資
  - 資本支出
  - 消費電力
  - 液冷
```

肥満治療
----

```
description: >
  肥満症治療薬、糖尿病・代謝疾患治療との連関、医薬品開発、
  製造能力、供給制約、保険償還、医療サービス需要への波及を含むテーマ。
```

```
driver_terms:
  - 承認
  - 適応拡大
  - 保険償還
  - 供給不足
```

* * *

最小運用ルール
=======

テンプレートを運用するなら、最初はこのルールで十分です。

### ルール1

`description` は 1〜3文程度で収める

### ルール2

`canonical_terms` は 3〜8語程度に絞る

### ルール3

`driver_terms` は「テーマを動かす要因」に限定する

### ルール4

`exclusion_terms` は誤判定が見つかるたびに追加する

### ルール5

`constituents[].description` は「テーマとの関係」で書く

### ルール6

`subpillars` は 2〜5個程度に抑える

* * *

私なら最初にこう使う
==========

最初は全テーマをこのテンプレートで埋めて、特に次の3点だけ品質を上げます。

*   `description`
*   `driver_terms`
*   `constituents[].description`

この3つが、ニューステーマ分類と breadth 推定に最も効きます。  
逆に、`memory` や細かい `metadata` は後回しでも大丈夫です。

必要なら次に、  
**あなたが今持っている既存 YAML の各項目を、このテンプレートのどこへ移すかの対応表** を作ります。

## Response:
2026/4/16 0:01:28

> 思考時間: 18s

以下のような **後方互換あり** の読み込み関数にすると扱いやすいです。  
意図は次の3点です。

*   現行の必須項目 `theme_id / name_ja / description / threshold` を残す
*   新テンプレートの `thesis / lexicon / constituents / controls / memory / metadata` も読む
*   下流で使いやすいように、**theme単位 DataFrame** と **constituent単位 DataFrame** に分ける

```
from __future__ import annotations

from pathlib import Path
import json
from typing import Any

import pandas as pd
import yaml

REQUIRED_THEME_COLUMNS = ["theme_id", "name_ja", "description", "threshold"]

def _ensure_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]

def _join_texts(values: list[Any]) -> str:
    cleaned = [str(v).strip() for v in values if str(v).strip()]
    return " | ".join(cleaned)

def _safe_get(d: dict[str, Any], *keys: str, default=None):
    cur = d
    for key in keys:
        if not isinstance(cur, dict) or key not in cur:
            return default
        cur = cur[key]
    return cur

def load_theme_definitions_v2(
    path: str | Path,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    拡張テーマ YAML/JSON を読み込む。

    Returns
    -------
    themes_df : pd.DataFrame
        theme 単位の表
    constituents_df : pd.DataFrame
        constituent 単位の表
    """
    path = Path(path)
    suffix = path.suffix.lower()

    if suffix in {".yml", ".yaml"}:
        with path.open("r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)
    elif suffix == ".json":
        with path.open("r", encoding="utf-8") as f:
            raw = json.load(f)
    else:
        raise ValueError(f"未対応の拡張子です: {suffix}")

    if not isinstance(raw, dict):
        raise ValueError("テーマ定義ファイルは dict 形式である必要があります。")
    if "themes" not in raw:
        raise ValueError("テーマ定義ファイルは {themes: [...]} 形式である必要があります。")
    if not isinstance(raw["themes"], list):
        raise ValueError("themes は配列である必要があります。")

    theme_rows: list[dict[str, Any]] = []
    constituent_rows: list[dict[str, Any]] = []

    for theme in raw["themes"]:
        if not isinstance(theme, dict):
            raise ValueError("各 theme は dict である必要があります。")

        theme_id = str(theme.get("theme_id", "")).strip()
        name_ja = str(theme.get("name_ja", "")).strip()
        description = str(theme.get("description", "")).strip()
        threshold = theme.get("threshold", None)

        thesis = theme.get("thesis", {}) or {}
        lexicon = theme.get("lexicon", {}) or {}
        controls = theme.get("controls", {}) or {}
        memory = theme.get("memory", {}) or {}
        metadata = theme.get("metadata", {}) or {}
        constituents = _ensure_list(theme.get("constituents"))

        if threshold is None:
            threshold = controls.get("relevance_threshold", None)

        row = {
            # ---- 現行互換の必須列 ----
            "theme_id": theme_id,
            "name_ja": name_ja,
            "description": description,
            "threshold": threshold,

            # ---- 表示・識別 ----
            "name_en": theme.get("name_en"),
            "version": raw.get("version"),

            # ---- thesis ----
            "thesis_one_liner": thesis.get("one_liner"),
            "investment_thesis": thesis.get("investment_thesis"),
            "economic_mechanism": _ensure_list(thesis.get("economic_mechanism")),
            "subpillars": _ensure_list(thesis.get("subpillars")),

            # ---- lexicon ----
            "aliases": _ensure_list(lexicon.get("aliases")),
            "canonical_terms": _ensure_list(lexicon.get("canonical_terms")),
            "driver_terms": _ensure_list(lexicon.get("driver_terms")),
            "related_terms": _ensure_list(lexicon.get("related_terms")),
            "exclusion_terms": _ensure_list(lexicon.get("exclusion_terms")),
            "ambiguous_terms": _ensure_list(lexicon.get("ambiguous_terms")),

            # ---- controls ----
            "relevance_threshold": controls.get("relevance_threshold"),
            "margin_threshold": controls.get("margin_threshold"),
            "min_constituent_breadth": controls.get("min_constituent_breadth"),
            "max_single_name_weight": controls.get("max_single_name_weight"),
            "purity_prior": controls.get("purity_prior"),
            "liquidity_prior": controls.get("liquidity_prior"),

            # ---- memory ----
            "memory_enabled": memory.get("enabled"),
            "memory_min_relevance": memory.get("min_relevance"),
            "memory_lookback_days": memory.get("lookback_days"),
            "memory_half_life_days": memory.get("half_life_days"),
            "memory_max_items": memory.get("max_items"),
            "memory_use_event_level": memory.get("use_event_level"),

            # ---- metadata ----
            "updated_at": metadata.get("updated_at"),
            "created_by": metadata.get("created_by"),
            "review_status": metadata.get("review_status"),
            "notes": metadata.get("notes"),

            # ---- raw nested ----
            "constituents": constituents,
        }

        # theme embedding 用の補助テキスト
        row["theme_text_core"] = "\n".join(
            [
                description,
                str(row["thesis_one_liner"] or "").strip(),
                str(row["investment_thesis"] or "").strip(),
                _join_texts(row["aliases"]),
                _join_texts(row["canonical_terms"]),
                _join_texts(row["driver_terms"]),
                _join_texts(row["related_terms"]),
            ]
        ).strip()

        # constituent テキストを後でまとめるための basket text
        basket_texts: list[str] = []

        for idx, c in enumerate(constituents):
            if not isinstance(c, dict):
                continue

            c_row = {
                "theme_id": theme_id,
                "theme_name_ja": name_ja,
                "constituent_index": idx,
                "security_id": c.get("security_id"),
                "name": c.get("name"),
                "description": c.get("description"),
                "weight": c.get("weight"),
                "role": c.get("role"),
                "pillar": c.get("pillar"),
                "exposure_direction": c.get("exposure_direction"),
                "exposure_confidence": c.get("exposure_confidence"),
            }

            c_text = "\n".join(
                [
                    str(c.get("name", "")).strip(),
                    str(c.get("description", "")).strip(),
                    str(c.get("role", "")).strip(),
                    str(c.get("pillar", "")).strip(),
                    str(c.get("exposure_direction", "")).strip(),
                ]
            ).strip()
            c_row["constituent_text"] = c_text

            if c_text:
                basket_texts.append(c_text)

            constituent_rows.append(c_row)

        row["theme_text_basket"] = "\n".join(basket_texts).strip()

        theme_rows.append(row)

    themes_df = pd.DataFrame(theme_rows)
    constituents_df = pd.DataFrame(constituent_rows)

    missing = sorted(set(REQUIRED_THEME_COLUMNS) - set(themes_df.columns))
    if missing:
        raise ValueError(f"テーマ定義に必須列が不足しています: {missing}")

    for col in REQUIRED_THEME_COLUMNS:
        if col != "threshold":
            themes_df[col] = themes_df[col].fillna("").astype(str).str.strip()

    themes_df["threshold"] = pd.to_numeric(themes_df["threshold"], errors="coerce")
    if themes_df["threshold"].isna().any():
        bad = themes_df.loc[themes_df["threshold"].isna(), "theme_id"].tolist()
        raise ValueError(f"threshold を数値変換できない theme_id があります: {bad}")

    if not constituents_df.empty:
        constituents_df["weight"] = pd.to_numeric(constituents_df["weight"], errors="coerce")

    return themes_df, constituents_df
```

使い方
---

```
themes_df, constituents_df = load_theme_definitions_v2("data/raw/theme_definitions.yaml")

print(themes_df.columns.tolist())
print(constituents_df.columns.tolist())

print(themes_df[[
    "theme_id", "name_ja", "description", "threshold",
    "theme_text_core", "theme_text_basket"
]].head())
```

返り値のイメージ
--------

### `themes_df`

1テーマ1行です。

主な列:

*   `theme_id`
*   `name_ja`
*   `description`
*   `threshold`
*   `thesis_one_liner`
*   `investment_thesis`
*   `aliases`
*   `canonical_terms`
*   `driver_terms`
*   `theme_text_core`
*   `theme_text_basket`

### `constituents_df`

1構成銘柄1行です。

主な列:

*   `theme_id`
*   `security_id`
*   `name`
*   `description`
*   `weight`
*   `role`
*   `pillar`
*   `constituent_text`

この設計の意図
-------

`theme_text_core` と `theme_text_basket` をロード時に作っておくと、

*   `theme_text_core`  
    description + thesis + lexicon ベースの静的テーマ表現
*   `theme_text_basket`  
    constituent 群ベースのバスケット表現

として、そのまま埋め込み生成に渡せます。

必要なら次に、  
**このローダーを今の `io.py` 風に `load_theme_definitions()` と差し替えられる形へ整えた版** を出します。

## Response:
2026/4/16 0:05:33

> 思考時間: 数秒

その場合は、**無理に YAML 上で `core / satellite` を人手で決めない**のが正解です。  
曖昧なものを先に固定ラベル化すると、後段のニュース帰属や breadth 計算に誤差を持ち込みやすいです。

結論としては、そういうテーマは **「役割を断定する設計」から「確率・連続値で持つ設計」へ変える**べきです。

* * *

基本方針
----

コア・サテライトが曖昧なテーマには、次の3段階で対応するのがよいです。

### 1\. 最初は役割を未確定にする

`role: core` や `role: satellite` を無理に入れず、

*   `role: unknown`
*   `role: mixed`
*   `role: undecided`

のようにしておきます。

これは「情報不足」ではなく、**そのテーマ定義自体が曖昧である**ことを正しく表現する処理です。

### 2\. 代わりに「テーマとの関係の強さ」を連続値で持つ

たとえば各 constituent に対して、

*   `exposure_score: 0.82`
*   `purity_score: 0.65`
*   `theme_relevance_confidence: 0.55`

のようなスコアを持たせます。

すると、離散的な `core/satellite` が決まらなくても、

*   かなりテーマに近い
*   そこそこ近い
*   周辺的
*   かなり曖昧

を表現できます。

### 3\. 将来的にデータから role を誘導する

ニュース帰属や企業説明文、価格反応、バスケット内相関などから、後で

*   上位群を core
*   中間群を satellite
*   低位群を peripheral / weak link

のように**後付けで分類**する方が自然です。

* * *

どういうテーマで起きやすいか
--------------

特に曖昧になりやすいのは次のようなテーマです。

*   DX
*   AI
*   脱炭素
*   防衛
*   サイバーセキュリティ
*   高齢化
*   地方創生
*   リオープン
*   サプライチェーン再編

これらは概念が広く、企業ごとの関わり方が

*   直接受益
*   間接受益
*   一時的受益
*   期待先行
*   単なる連想

で混ざりやすいです。

この場合、最初から「これはコアだ」と決めると、むしろ精度が下がります。

* * *

YAML ではどう書くべきか
--------------

そういう場合は、次のように書くのが安全です。

```
constituents:
  - security_id: TICKER_A
    name: 構成銘柄A
    description: >
      この銘柄はテーマに関連する可能性があるが、直接受益か周辺受益かは現時点で未確定。
    weight: 0.08
    role: undecided
    pillar: 周辺領域
    exposure_direction: mixed
    exposure_confidence: low
    exposure_score: 0.58
    purity_score: 0.52
```

このようにすると、

*   人手判断で断定していない
*   ただし無関係ではない
*   不確実性込みで持っている

という状態を表せます。

* * *

離散ラベルより連続値が良い理由
---------------

`core / satellite` は分かりやすい反面、境界がかなり恣意的です。  
一方で実務上は、テーマ銘柄の関与度は多くの場合連続的です。

たとえば AI テーマでも、

*   GPU 企業は 0.95
*   電力設備は 0.75
*   データセンター REIT は 0.68
*   クラウドソフト企業は 0.55
*   なんとなく AI と言われる企業は 0.30

のような感じで、明確な段差はないことが多いです。

そのため、まずは **score で持って、必要なら後でバケット分けする** のが自然です。

* * *

推奨する追加項目
--------

曖昧テーマなら、`role` より次を優先した方がよいです。

### `exposure_score`

その銘柄がテーマにどの程度関連するかの総合スコアです。  
0〜1 などで持ちます。

### `exposure_confidence`

その判断にどれくらい自信があるかです。  
`high / medium / low` でもよいですし、数値でもよいです。

### `exposure_direction`

*   `direct`
*   `indirect`
*   `mixed`
*   `unclear`

のようにします。

### `purity_score`

その銘柄の事業内容が、そのテーマにどれだけ純粋に紐づくかです。

### `role`

これは未確定なら `undecided` でよいです。

* * *

breadth 計算はどうするか
----------------

コア・サテライトが曖昧な場合でも、breadth 自体は計算できます。  
そのときは `role` ではなく、

*   `weight`
*   `exposure_score`
*   constituent-level similarity

で計算します。

つまり、ニュース  $n$  のテーマ  $j$  に対する breadth は、たとえば

$$
\text{breadth}_{n,j} = \sum_{i \in \mathcal{B}_j} w_{ij} \cdot s_{ij} \cdot m_{n,i}
$$

のようにできます。

ここで

*    $w_{ij}$ : バスケットウェイト
*    $s_{ij}$ : exposure\_score
*    $m_{n,i}$ : ニュースと constituent の類似度

です。

この方式なら、`core/satellite` の二値ラベルがなくても成立します。

* * *

実務上のおすすめ
--------

私なら、曖昧テーマについては最初はこうします。

### A. role は3値化

*   `core`
*   `satellite`
*   `undecided`

### B. 本体は score 管理

*   `exposure_score`
*   `purity_score`
*   `exposure_confidence`

### C. 後で role を派生させる

たとえばルールで

*   `exposure_score >= 0.75` → `core`
*   `0.45 <= score < 0.75` → `satellite`
*   `score < 0.45` → `peripheral`
*   ただし `confidence` が低ければ `undecided`

のようにすればよいです。

つまり、**role は原データではなく派生ラベル**として扱う方が安全です。

* * *

さらに厳密にやるなら
----------

テーマバスケット自体がかなり曖昧な場合、YAML 上で各 constituent を確定列挙すること自体が弱いこともあります。  
その場合は、構成銘柄に対して

*   `candidate: true`
*   `in_theme_basket: true/false`
*   `theme_membership_score`

のようにして、**候補集合 + 所属確率**で持つ設計もありです。

これは特に、テーマ ETF の中身が頻繁に変わる、または theme washing の疑いがある場合に有効です。

* * *

一言でまとめると
--------

**コア・サテライトの判断がつきにくいテーマでは、無理に離散ラベルを付けず、`undecided` と連続スコアで持つべき**です。  
その上で、ニュース帰属・企業説明文・価格反応を見ながら、後で role を派生させるのが最も頑健です。

必要なら次に、  
**曖昧なテーマ向けの YAML テンプレートだけを別立てで作る版**を示します。

## Response:
2026/4/16 0:10:49

> 思考時間: 数秒

`exposure_score` と `purity_score` は似ていますが、見ているものが違います。

*   `exposure_score` は **その銘柄が、そのテーマの値動きや物語にどれだけ関与しているか**
*   `purity_score` は **その銘柄の事業そのものが、そのテーマにどれだけ“純粋”に属しているか**

です。

* * *

1\. `exposure_score` とは何か
-------------------------

これは、**テーマへのエクスポージャーの強さ**です。  
0〜1 の連続値で持つのを想定します。

### 直感

その銘柄は、そのテーマが盛り上がったときに、どれだけ受益しやすいか。

### 例

AIインフラテーマで考えると、

*   GPU 専業に近い企業  
    → `exposure_score` はかなり高い
*   データセンター冷却設備企業  
    → 高め
*   たまたま AI 向け売上もある総合電機  
    → 中くらい
*   IRで AI を少し言っているだけの企業  
    → 低め

### 何を反映するか

主に次を総合した概念です。

*   売上や利益がそのテーマからどれだけ来ているか
*   そのテーマが伸びたときに業績がどれだけ連動しそうか
*   ニュースや需給がその銘柄へどれだけ波及しそうか
*   テーマバスケットの中で中心的な受益者かどうか

### 重要な点

`exposure_score` は、**必ずしも事業の純粋さだけを見ていません**。  
「間接受益でも、テーマが伸びるとかなり効く」なら高くなりえます。

* * *

2\. `purity_score` とは何か
-----------------------

これは、**その銘柄の事業内容がどれだけ純粋にそのテーマに属しているか**です。  
これも 0〜1 の連続値を想定します。

### 直感

その会社を見たときに、「この会社はこのテーマの会社だ」とどれだけ言いやすいか。

### 例

AIインフラテーマなら、

*   AI 半導体売上が中核の企業  
    → `purity_score` 高い
*   データセンター向け電力・冷却が主力の企業  
    → 高め
*   事業の一部だけ AI 関連の総合電機  
    → 中くらい
*   ほとんど本業は別だが AI 材料で物色される企業  
    → 低い

### 何を反映するか

主に次です。

*   そのテーマ関連事業が会社全体に占める割合
*   企業説明文や事業セグメントの中心がそのテーマか
*   他テーマにも同じくらい当てはまってしまわないか
*   “連想”ではなく“本業”としてそのテーマに属するか

### 重要な点

`purity_score` は、**その会社の本質的なテーマ所属度**です。  
短期のニュース反応や株価連動性とは分けて考えます。

* * *

3\. 両者の違い
---------

たとえば、ある企業が AI データセンター向けの冷却装置を作っているとします。

*   AIブームで受注がかなり伸びる  
    → `exposure_score` は高い
*   ただし会社全体では冷却以外の一般産業機器売上も大きい  
    → `purity_score` はそこまで高くない

このように、

*   **テーマが伸びたら効く** = exposure
*   **その会社自体がテーマの純粋な代表か** = purity

です。

* * *

4\. 0.58 や 0.52 はどう読むか
----------------------

たとえば

```
exposure_score: 0.58
purity_score: 0.52
```

なら、かなりざっくり言うと、

*   その銘柄はテーマと**中程度に関連**
*   ただし、その会社を**純粋なテーマ銘柄とは言い切れない**

という意味です。

### 解釈例

*   テーマが盛り上がれば一定の恩恵はある
*   ただしバスケットの中核銘柄とまでは言いにくい
*   周辺受益、または複数テーマにまたがる銘柄かもしれない

* * *

5\. 典型例
-------

### ケースA: 専業に近い中核銘柄

*   `exposure_score: 0.90`
*   `purity_score: 0.88`

意味:

*   テーマが伸びればかなり効く
*   会社自体もテーマのど真ん中

### ケースB: 間接受益の有力銘柄

*   `exposure_score: 0.75`
*   `purity_score: 0.45`

意味:

*   テーマが伸びると結構効く
*   でも会社全体としてはそのテーマ専業ではない

### ケースC: 連想で入っている銘柄

*   `exposure_score: 0.35`
*   `purity_score: 0.20`

意味:

*   テーマとのつながりは弱い
*   バスケットに入っていても実質的には薄い

### ケースD: 純粋だが市場インパクトは小さい

*   `exposure_score: 0.40`
*   `purity_score: 0.85`

意味:

*   会社はかなり純粋にそのテーマ
*   ただし規模や流動性、収益寄与の観点ではテーマ全体への影響は限定的

* * *

6\. どう使い分けるか
------------

### `exposure_score` の用途

*   breadth 計算の重み
*   ニュースがどの銘柄群に効いたかの推定
*   コア / サテライトの後付け分類

### `purity_score` の用途

*   テーマバスケットの質の評価
*   theme washing の検出
*   最終テーマスコアの補正

* * *

7\. 両者を混同すると何が起きるか
------------------

ここは重要です。

### `exposure_score` だけ見ると

短期的にテーマに反応しそうな銘柄を拾いやすい反面、  
“実は本業は別” の銘柄が多く入りやすいです。

### `purity_score` だけ見ると

テーマの純度は高まりますが、  
実際にテーマのニュースで大きく動く間接受益銘柄を落としやすいです。

したがって、実務上は両方持つのが良いです。

* * *

8\. 最も簡単な理解
-----------

一言で言うと、

*   `exposure_score` = **効きやすさ**
*   `purity_score` = **らしさ**

です。

ある銘柄がテーマに**効く**ことと、  
その銘柄がそのテーマ**そのものらしい**ことは、同じではありません。

* * *

9\. YAML ではどう扱うか
----------------

曖昧なテーマでは、まずこう持つのが安全です。

```
role: undecided
exposure_direction: mixed
exposure_confidence: low
exposure_score: 0.58
purity_score: 0.52
```

これは、

*   まだ core / satellite は断定しない
*   ただしテーマとの関係は中程度ある
*   純粋なテーマ銘柄とも言い切れない

という状態を表します。

* * *

10\. 実務的な目安
-----------

最初は厳密な数値でなくてもよく、こんな感覚で十分です。

*   0.80 以上: かなり高い
*   0.60〜0.79: 高め
*   0.40〜0.59: 中程度
*   0.20〜0.39: 低め
*   0.20 未満: かなり弱い

ただし、これはテーマごとの相対評価で使う方が自然です。  
絶対的な真値というより、**同じテーマ内での順位付け**に近いです。

必要なら次に、  
**exposure\_score と purity\_score を人手で付けるときの判断基準表** を作ります。

## Response:
2026/4/16 0:14:39

> 思考時間: 8s

あります。  
結論からいうと、**人手で難しい項目は「最初から正解を入れる」のではなく、判断を保留できる設計にする**のが一番重要です。

特に挙げてもらった

*   `role`
*   `pillar`
*   `exposure_direction`
*   `exposure_confidence`
*   `subpillars`

は、どれも**曖昧さを含む概念**なので、最初から厳密に埋めようとすると破綻しやすいです。  
対処法は大きく5つあります。

* * *

1\. 無理に確定させず、「未確定」を正式な値として認める
-----------------------------

一番効く方法です。  
難しい項目に対しては、空欄や適当な値を入れるのではなく、**未確定状態を明示的に持つ**べきです。

たとえば:

```
role: undecided
pillar: unknown
exposure_direction: unclear
exposure_confidence: low
```

こうしておくと、

*   まだ判断していない
*   データ不足
*   テーマ自体が曖昧

を区別せずとも、「今は断定していない」という事実を表現できます。

### なぜ大事か

誤った確定ラベルは、空欄より悪いです。  
後で breadth や relevance の計算に混ざると、誤差が構造化されて残ります。

* * *

2\. 離散ラベルを減らし、連続値や補助コメントに置き換える
------------------------------

難しい項目ほど、`core / satellite` のような離散分類より、**スコア + コメント**の方が扱いやすいです。

たとえば `role` が難しいなら、代わりに

```
role: undecided
exposure_score: 0.62
purity_score: 0.48
notes: >
  AI関連売上はあるが、会社全体としては汎用IT比率も高く、
  コア受益か周辺受益かは未確定。
```

の方が現実的です。

### 特に有効な置き換え

*   `role` → `exposure_score`
*   `exposure_direction` → `direct / indirect / mixed / unclear`
*   `exposure_confidence` → 人手確信度を low にして notes へ理由を書く

つまり、**難しいものほど「判定結果」より「判定材料」を残す**方がよいです。

* * *

3\. 項目を「一次情報で埋めるもの」と「二次判断で埋めるもの」に分ける
------------------------------------

人手で難しい項目の多くは、そもそも一次情報から直接読めないから難しいです。  
なので、YAML 項目を次の2群に分けるとかなり楽になります。

### 一次情報ベースで埋めやすいもの

これは人手で比較的安定して入れられます。

*   `theme_id`
*   `name_ja`
*   `description`
*   `aliases`
*   `canonical_terms`
*   `driver_terms`
*   `constituents[].name`
*   `constituents[].weight`
*   `constituents[].description`

### 二次判断が必要なもの

これは解釈が入るので難しいです。

*   `role`
*   `pillar`
*   `exposure_direction`
*   `exposure_confidence`
*   `subpillars`

### 対応策

最初の運用では、

*   一次情報ベース項目は必ず埋める
*   二次判断項目は optional にする

のがよいです。

つまり、難しい項目を「必須」にしないことです。

* * *

4\. 判断ルール表を先に作る
---------------

難しいのは、項目定義が曖昧だからです。  
なので YAML を埋める前に、**各項目の判断基準表**を作るとかなり改善します。

* * *

### `role` の判断ルール例

**core**

*   そのテーマ関連が主力事業の一つ
*   テーマの主要ニュースで直接反応しやすい
*   テーマ内でも代表銘柄として説明しやすい

**satellite**

*   テーマから一定の恩恵はある
*   ただし本業の一部に過ぎない
*   主要受益ではないが無関係でもない

**undecided**

*   情報不足
*   複数テーマにまたがる
*   直接/間接どちらとも言いにくい

* * *

### `pillar` の判断ルール例

pillar は「会社が属する業種」ではなく、**そのテーマの中でどの機能を担うか** で決めるとよいです。

たとえば AIインフラなら:

*   半導体・計算資源
*   ネットワーク
*   電力・冷却
*   データセンター

このとき、会社が複数にまたがるなら

```
pillar: mixed
pillar_candidates:
  - 半導体・計算資源
  - ネットワーク
```

でもよいです。

* * *

### `exposure_direction` の判断ルール例

**direct**

*   そのテーマ需要が増えると、売上・利益に比較的直接効く

**indirect**

*   需要波及の2次・3次効果として効く

**mixed**

*   直接・間接の両面がある

**unclear**

*   判断材料不足

これくらいの粗さで十分です。

* * *

### `exposure_confidence` の判断ルール例

これは「銘柄の良し悪し」ではなく、**こちらの判断の自信**です。

**high**

*   会社説明・事業構成・ニュース反応が整合的

**medium**

*   ある程度妥当だが、周辺事業や他テーマとも重なる

**low**

*   情報不足、または解釈が割れそう

この定義を明示しておくと、付けやすくなります。

* * *

### `subpillars` の判断ルール例

subpillars は細かく作りすぎると破綻します。  
最初は **2〜4個まで** に抑えるのがコツです。

悪い例:

*   8個も10個も作る

良い例:

*   コア領域
*   周辺受益
*   政策・制度
*   供給網

最初は粗く、必要が出たら増やす方がよいです。

* * *

5\. YAML を「確定版」ではなく「草案 + レビュー前提」で運用する
-------------------------------------

これは実務上かなり重要です。  
一人で完璧に埋めようとすると苦しくなります。

おすすめは、テーマごとに状態を持つことです。

```
metadata:
  review_status: draft
```

あるいは constituent ごとに

```
exposure_confidence: low
```

とする。

### 運用イメージ

*   初回入力: rough draft
*   週次または月次レビューで修正
*   ニュース帰属結果や誤分類を見ながら更新

つまり、YAML を静的な正解集ではなく、**学習しながら改善する定義ファイル**として扱うべきです。

* * *

項目ごとの具体的対処法
===========

`role`
------

### 問題

core / satellite の境界が曖昧

### 対処

*   最初は `undecided` を許す
*   補助的に `exposure_score` を持つ
*   後で score から派生させる

### 実務的には

`role` は原データではなく**派生ラベル**に近い扱いがよいです。

* * *

`pillar`
--------

### 問題

どの subpillar に属するか一意に決まらない

### 対処

*   まず subpillars 自体を粗くする
*   `pillar: mixed` を許す
*   必要なら `pillar_candidates` を持つ

例:

```
pillar: mixed
pillar_candidates:
  - 電力・冷却
  - データセンター
```

* * *

`exposure_direction`
--------------------

### 問題

直接か間接かがはっきりしない

### 対処

*   `mixed` と `unclear` を許す
*   direct/indirect を厳密に二値化しない

### コツ

「売上ドライバーとして一次的か」で決めると多少安定します。

* * *

`exposure_confidence`
---------------------

### 問題

何の confidence なのか曖昧

### 対処

「こちらのラベリング判断への自信」と定義する

*   high: 確信あり
*   medium: そこそこ
*   low: 判断保留

この定義に固定すると付けやすいです。

* * *

`subpillars`
------------

### 問題

どう分けるかが恣意的

### 対処

*   最初は少なくする
*   サプライチェーン全部を分けようとしない
*   「ニュース上の論点」で分ける

### 良いやり方

企業分類ではなく、**ニュースの語られ方**で分けることです。

たとえば AI なら、

*   計算資源
*   インフラ設備
*   導入・利用

くらいで十分です。

* * *

さらに楽にするための実務テクニック
=================

A. まず “書きやすい列” だけ埋める
--------------------

最初の入力時に埋めるのは次だけでよいです。

*   `description`
*   `aliases`
*   `driver_terms`
*   `constituents[].description`

難しい列は空欄または `undecided` でよいです。

* * *

B. 1テーマ1ページの判断メモを作る
-------------------

YAML を直接いじる前に、テーマごとに

*   このテーマの本質は何か
*   何がコア受益か
*   何が境界曖昧か
*   何と混同しやすいか

を書いたメモを作ると、後で YAML に落としやすいです。

* * *

C. “埋める”より“比較する”
----------------

role や pillar は単独で考えると難しいです。  
同じテーマ内の constituent を横に並べて、

*   この中で一番テーマらしいのはどれか
*   明らかに周辺なのはどれか

と比較すると決めやすいです。

つまり、絶対判断より**相対判断**の方がやりやすいです。

* * *

D. 迷ったら `notes` に理由を書く
----------------------

これはかなり有効です。

```
notes: >
  AI関連売上は存在するが、非AI事業の比率も高く、
  現時点では core と satellite の境界が曖昧。
```

後から見返したときに、なぜそう判断したか分かります。

* * *

おすすめの最終方針
=========

私なら、難しい項目については次の運用にします。

### 必須入力

*   `description`
*   `driver_terms`
*   `constituents[].description`

### 迷ったら保留

*   `role: undecided`
*   `pillar: unknown`
*   `exposure_direction: unclear`
*   `exposure_confidence: low`

### できれば追加

*   `notes`
*   `exposure_score`
*   `purity_score`

つまり、**難しい項目ほど、無理に確定ラベルを付けず、保留値と補助情報で持つ**のが正解です。

必要なら次に、  
**「判断が難しいテーマ向け」の簡略 YAML テンプレート** を作れます。

## Response:
2026/4/16 0:17:21

> 思考時間: 2 ～ 3 秒

以下が、**判断が難しいテーマ向けの簡略 YAML テンプレート**です。  
狙いは、**無理に確定ラベルを入れず、それでも後で拡張できる形を保つ**ことです。

このテンプレートでは特に、

*   `role`
*   `pillar`
*   `exposure_direction`
*   `exposure_confidence`
*   `subpillars`

を**保留しやすい形**にしています。

* * *

簡略テンプレート
========

```
version: 2

themes:
  - theme_id: SAMPLE_THEME_001
    name_ja: サンプルテーマ
    name_en: Sample Theme

    description: >
      このテーマの埋め込み比較用代表文。
      テーマの中心概念、主要ドライバー、関連領域を短く高密度に書く。

    threshold: 0.40

    thesis:
      one_liner: >
        このテーマの一文要約。
      investment_thesis: >
        このテーマが投資対象になる理由、収益源泉、注目論点を書く。
      economic_mechanism:
        - ドライバー1が追い風
        - ドライバー2が逆風
      subpillars:
        - name: コア領域
          description: 必要最小限の粗い分類
        - name: 周辺領域
          description: 直接受益以外も含む補完領域

    lexicon:
      aliases:
        - サンプルテーマ
        - 別名1
      canonical_terms:
        - コア語1
        - コア語2
      driver_terms:
        - ドライバー語1
        - ドライバー語2
      related_terms:
        - 周辺語1
        - 周辺語2
      exclusion_terms:
        - 除外語1
      ambiguous_terms:
        - 一般語1

    constituents:
      - security_id: TICKER_A
        name: 構成銘柄A
        description: >
          この銘柄がテーマとどう関係するかを書く。
          業種名だけでなく、テーマとの接点を書く。
        weight: 0.10

        role: undecided
        pillar: unknown
        pillar_candidates:
          - コア領域
          - 周辺領域

        exposure_direction: unclear
        exposure_confidence: low

        exposure_score: 0.60
        purity_score: 0.45

        notes: >
          テーマとの関係はあるが、主力事業か周辺受益かの判断は未確定。
          他テーマとも重なりうる。

      - security_id: TICKER_B
        name: 構成銘柄B
        description: >
          この銘柄がテーマに関連すると考える理由を書く。
        weight: 0.06

        role: undecided
        pillar: mixed
        pillar_candidates:
          - コア領域
          - 周辺領域

        exposure_direction: mixed
        exposure_confidence: medium

        exposure_score: 0.72
        purity_score: 0.55

        notes: >
          テーマ需要の恩恵は受ける可能性が高いが、専業ではない。

    controls:
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.15

    metadata:
      updated_at: 2026-04-15
      review_status: draft
      notes: >
        判断が難しいテーマのため、role/pillar は保留値を許容。
```

* * *

この簡略テンプレートの考え方
==============

1\. `role` は無理に決めない
-------------------

ここでは `core` や `satellite` を強制しません。

使う値は、まずこの程度で十分です。

*   `core`
*   `satellite`
*   `undecided`

判断が難しければ `undecided` にします。

### 重要な考え方

`undecided` は「未入力」ではなく、**正式な状態**です。

* * *

2\. `pillar` は `unknown` や `mixed` を許す
--------------------------------------

これも最初からきれいに一意決定しようとしない方がよいです。

使う値の例:

*   `コア領域`
*   `周辺領域`
*   `mixed`
*   `unknown`

さらに迷うなら `pillar_candidates` を置きます。

```
pillar: unknown
pillar_candidates:
  - コア領域
  - 周辺領域
```

これで、「候補はあるが確定していない」を表せます。

* * *

3\. `exposure_direction` は4値で十分
-------------------------------

おすすめは次の4値です。

*   `direct`
*   `indirect`
*   `mixed`
*   `unclear`

`direct / indirect` を厳密に二択にすると苦しくなるので、  
`mixed` と `unclear` を最初から入れておくのがコツです。

* * *

4\. `exposure_confidence` は“こちらの自信”
-----------------------------------

これは銘柄の質ではなく、**ラベリング判断への自信**です。

おすすめは:

*   `high`
*   `medium`
*   `low`

だけです。

難しければ `low` にして、理由を `notes` に書けば十分です。

* * *

5\. `exposure_score` と `purity_score` を補助に使う
--------------------------------------------

離散ラベルが難しいときほど、この2つが有効です。

### `exposure_score`

テーマにどれだけ効きやすいか

### `purity_score`

その銘柄がどれだけそのテーマらしいか

この2つがあると、`role` を保留しても後で整理しやすいです。

* * *

6\. `notes` を重視する
-----------------

難しい項目ほど、ラベルだけよりメモが重要です。

たとえば:

```
notes: >
  AI関連売上は一定あるが、本業全体に占める比率は限定的。
  コア受益か周辺受益かは現時点では未確定。
```

この1文があるだけで、後から見返したときの再判断がかなり楽になります。

* * *

もっと簡略にしたい場合の最小版
===============

さらに簡素化するなら、難しい項目はこの形で十分です。

```
themes:
  - theme_id: SAMPLE_THEME_001
    name_ja: サンプルテーマ
    description: >
      テーマの代表説明文。
    threshold: 0.40

    lexicon:
      aliases:
        - 別名1
      driver_terms:
        - ドライバー語1
      exclusion_terms:
        - 除外語1

    constituents:
      - name: 構成銘柄A
        security_id: TICKER_A
        description: >
          テーマとの関係を書く。
        weight: 0.10
        role: undecided
        pillar: unknown
        exposure_direction: unclear
        exposure_confidence: low
        notes: >
          判断保留。

    metadata:
      review_status: draft
```

これはかなり軽量ですが、  
それでも「無理に決めない」設計は保てます。

* * *

この簡略テンプレートが向いているケース
===================

特に次のようなテーマで有効です。

*   DX
*   AI
*   脱炭素
*   防衛
*   サイバー
*   リオープン
*   サプライチェーン再編
*   高齢化
*   地方創生

こうしたテーマは、企業との結びつきが連続的で、  
`core/satellite` を初手で断定しにくいからです。

* * *

実務上の運用ルール
=========

このテンプレートを使うなら、運用ルールは次で十分です。

### ルール1

迷ったら `undecided / unknown / unclear / low`

### ルール2

確信がないのに `core` を付けない

### ルール3

`notes` に迷った理由を書く

### ルール4

`subpillars` は粗く、2〜4個まで

### ルール5

後から `exposure_score` と実績を見て見直す

* * *

一言でまとめると
========

この簡略テンプレートは、  
**「難しい項目を正しく保留するための YAML」** です。

完璧な初期ラベルを目指すより、

*   保留を許す
*   補助スコアを持つ
*   メモを残す
*   後で更新する

という運用の方が、長期的にはずっと頑健です。

必要なら次に、  
**通常版テンプレートと簡略版テンプレートの使い分け基準** を整理します。

## Response:
2026/4/16 0:20:26

ここはかなり重要な論点です。人手で難しい二次判断項目を、どこまで機械的・定量的に置き換えられるかを、テーマ定義の実務と学術の両面から整理します。

> **検索: トピックモデリング、埋め込み、エクスポージャー測定**
>
> [(PDF) Dynamic Text-Based Industries and Endogenous ...](https://www.researchgate.net/publication/228364167_Dynamic_Text-Based_Industries_and_Endogenous_Product_Differentiation)
> [Measuring exposure to network concentration risk in global ...](https://www.sciencedirect.com/science/article/am/pii/S0954349X23001339)
> [Confidence-Diversity Calibration of AI Judgement Enables ...](https://arxiv.org/pdf/2508.02029)
> [Hierarchical Topic Modeling - BERTopic](https://maartengr.github.io/BERTopic/getting_started/hierarchicaltopics/hierarchicaltopics.html)
> [Firm-Level Exposure to Epidemic Diseases: COVID-19, ...](https://www.nber.org/system/files/working_papers/w26971/w26971.pdf)
> [CESifo Working Paper No. 12271](https://www.ifo.de/DocDL/cesifo1_wp12271.pdf)
> [Quantitative Approach for Equity Thematic Exposure ...](https://assets.contentstack.io/v3/assets/blt4eb669caa7dc65b2/bltee2e5dcbc0aca502/Theme_Retrieval_for_Equities.pdf)
> [The Impact of Trade Disruption with China on ...](https://www.rieti.go.jp/jp/publications/dp/24e073.pdf)
> [An Efficient Probability Calibration Method of Knowledge ...](https://aclanthology.org/2025.emnlp-main.1522.pdf)
> [Horses for courses: measuring foreign supply chain exposure](https://www.bankofengland.co.uk/-/media/boe/files/working-paper/2022/horses-for-courses-measuring-foreign-supply-chain-exposure.pdf)
> [A Survey on Confidence Calibration of Deep Learning- ...](https://www.techrxiv.org/doi/pdf/10.36227/techrxiv.171623912.22862601/v2?onload=true)
> [Implementation of Dynamic Topic Modeling to Discover ...](https://pdfs.semanticscholar.org/49d8/93b8221c1e3f93db1ee888dcfbaf449d6aee.pdf)
> [AI Unboxed and Jobs: A Novel Measure and Firm-Level ...](https://docs.iza.org/dp16717.pdf)
> [A Study on the Calibrated Confidence of Text Classification ...](https://www.mdpi.com/2076-3417/12/18/9007)
> [BERTopic for Topic Modeling - Maarten Grootendorst - Talking ...](https://www.youtube.com/watch?v=uZxQz87lb84)
> [Hidden Exposure: Measuring US Supply Chain Reliance](https://www.brookings.edu/wp-content/uploads/2023/09/Baldwin-et-al-session_16820-BPEA-FA23_WEB.pdf)
>
> **検索: 温度スケーリングと定量的手法**
>
> [On Calibration of Modern Neural Networks](https://arxiv.org/abs/1706.04599)
> [Firm-Level Exposure to Epidemic Diseases: COVID-19, ...](https://www.nber.org/system/files/working_papers/w26971/w26971.pdf)
> [Hierarchical Topic Modeling - BERTopic](https://maartengr.github.io/BERTopic/getting_started/hierarchicaltopics/hierarchicaltopics.html)
> [On Calibration of Modern Neural Networks](https://proceedings.mlr.press/v70/guo17a/guo17a.pdf)
> [Firm-Level Exposure to Epidemic Diseases: COVID-19, ...](https://bfi.uchicago.edu/wp-content/uploads/Hassan_Firm-level-Exposure-to-Epidemic-Diseases.pdf)
> [Thematic ETF Report](https://globalxetfs.co.jp/content/files/Thematic-ETF-Report-Q3-2020-1.pdf)
> [On Calibration of Modern Neural Networks](https://fernandoperezc.github.io/Advanced-Topics-in-Machine-Learning-and-Data-Science/Fluri.pdf)
> [split topic into sub-topic · Issue #1782 · MaartenGr/BERTopic](https://github.com/MaartenGr/BERTopic/issues/1782)
> [Quantitative Approach for Equity Thematic Exposure ...](https://assets.contentstack.io/v3/assets/blt4eb669caa7dc65b2/bltee2e5dcbc0aca502/Theme_Retrieval_for_Equities.pdf)
> [On calibration of modern neural networks](https://dl.acm.org/doi/10.5555/3305381.3305518)
> [Firm-Level Exposure to Epidemic Diseases: Covid-19, Sars ...](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3594194)
> [BERTopic with Hierarchical Clustering | by Dr.Tiya Vaj - Medium](https://vtiya.medium.com/bertopic-with-hierarchical-clustering-d781c9f66253)
> [What makes thematic investing a strong alternative in ...](https://www.robeco.com/files/docm/docu-20250625-what-makes-thematic-investing-a-strong-alternative-in-volatile-markets.pdf)
> [On Calibration of Modern Neural Networks: Temperature ...](https://users.cs.fiu.edu/~sjha/class2023/Lecture8/Slides/2017TemperatureScaling.pdf)
> [White Paper Thematic Investing](https://cpram.com/pdfDocuments/mkt/download/da25c04b-9b7e-4fb2-989d-2e67442f7165/White%20Paper%20%20Thematic%20Investing.pdf)
>
> **構築する詳細な回答の作成**
>
> 答えは詳細にし、データ駆動型の指標を使って定量的に定義できることを言及する必要がある。アイテムごとのマッピングが必要かもしれない。また、TReEのホワイトペーパーやHassanを引用し、ネットワーク曝露などを考慮して説明する。すべての事実には出典を記載し、数式を使って構造的に組み立てることが必要。
>
> 思考時間: 46s

あります。  
しかも、挙げてもらった二次判断項目は、**かなりの部分を定量化できます**。ただし、完全に「真値」を自動推定するというより、**スコアを作って、離散ラベルはその派生物にする**のが実務的です。

一言でいうと、

*   `role`
*   `pillar`
*   `exposure_direction`
*   `exposure_confidence`
*   `subpillars`

は、**最初から YAML に手入力する主項目ではなく、定量スコアから後付けで決める派生項目**にした方がよいです。  
テーマ投資の文脈でも、テキストだけでなく revenue / asset ベースの客観テストを組み合わせるべき、という実務的な考え方があります。[assets.contentstack.io+1](https://assets.contentstack.io/v3/assets/blt4eb669caa7dc65b2/bltee2e5dcbc0aca502/Theme_Retrieval_for_Equities.pdf?utm_source=chatgpt.com)

以下、各項目ごとに、どのように定量化するかを整理します。

* * *

全体方針
----

人手で難しい項目は、いきなり `core` や `direct` を入れるのではなく、まず次のような**基礎スコア**を作ります。

1.  **Semantic exposure**  
    企業説明文・有報・10-K・製品説明とテーマ定義の埋め込み類似度
2.  **Economic exposure**  
    売上セグメント、事業比率、設備投資感応度、テーマ関連売上比率
3.  **Network exposure**  
    サプライチェーンや入出力ネットワーク経由の間接露出
4.  **Purity**  
    その企業がどれだけそのテーマ専業に近いか
5.  **Confidence**  
    ラベル推定の不確実性

この基礎スコアから、`role` や `pillar` を派生させます。  
特に supply chain の直接・間接露出は、Leontief inverse や foreign supply chain exposure 指標のようなネットワーク測定の発想がそのまま使えます。[サイエンスダイレクト+2イングランド銀行+2](https://www.sciencedirect.com/science/article/am/pii/S0954349X23001339?utm_source=chatgpt.com)

* * *

1\. `role` を定量化する方法
===================

`role` は本質的には  
**「その銘柄がテーマ内でどれくらい中心的か」**  
です。

したがって、離散ラベルにする前に **Role score** を作るのが自然です。

推奨定義
----

$$
\text{RoleScore}_{i,j} = w_1 \cdot \text{ExposureScore}_{i,j} + w_2 \cdot \text{PurityScore}_{i,j} + w_3 \cdot \text{BasketImportance}_{i,j} + w_4 \cdot \text{ThemeCentrality}_{i,j}
$$

ここで

*   `ExposureScore`  
    その銘柄がテーマの成長やニュースにどれだけ効きやすいか
*   `PurityScore`  
    その銘柄がどれだけそのテーマらしいか
*   `BasketImportance`  
    バスケット内ウェイトや市場規模
*   `ThemeCentrality`  
    テーマ関連銘柄群の中でどれだけ中心にいるか

です。

`ThemeCentrality` の作り方
----------------------

銘柄説明文やテーマ関連ニュースから銘柄間類似グラフを作り、その中心性を取ります。  
10-K の製品説明から動的な product similarity を作って企業間の近さを測る研究や、テキストから firms’ AI engagement を定量化する研究は、この考え方と整合的です。[ResearchGate+1](https://www.researchgate.net/publication/228364167_Dynamic_Text-Based_Industries_and_Endogenous_Product_Differentiation?utm_source=chatgpt.com)

role への変換
---------

たとえば、

*   上位 20% → `core`
*   次の 30% → `satellite`
*   それ以外 → `peripheral`
*   信頼度が低い場合 → `undecided`

とすればよいです。

### 重要

`core/satellite` は**入力項目**ではなく、`RoleScore` からの**派生ラベル**にします。

* * *

2\. `pillar` を定量化する方法
=====================

`pillar` は  
**その銘柄がテーマのどの下位機能・下位論点に属するか**  
です。

これはかなり人手で迷いやすいですが、定量的には **クラスタリングまたは nearest-centroid** にできます。

方法A: 事前定義した pillar に nearest assignment
---------------------------------------

テーマごとに subpillars の説明文を作り、その埋め込みを `p_{j,k}` とします。  
銘柄説明文 embedding を `e_i` とすると、

$$
\text{PillarScore}_{i,j,k} = \cos(e_i, p_{j,k})
$$

で各 pillar への近さを測れます。

*   最大スコアの pillar を採用
*   1位と2位が僅差なら `mixed`
*   すべて低ければ `unknown`

でよいです。

方法B: テーマ内銘柄を自動クラスタリングして pillar を作る
----------------------------------

企業説明文やテーマ関連ニュースを材料に、テーマ内銘柄をクラスタリングします。  
その後、各クラスタに人手で名前を付けます。

これは BERTopic の hierarchical topics の発想とかなり相性が良いです。BERTopic は topic embeddings や c-TF-IDF に基づいて、トピック間階層を可視化できます。[Maarten's GitHub Page+2Maarten's GitHub Page+2](https://maartengr.github.io/BERTopic/getting_started/hierarchicaltopics/hierarchicaltopics.html?utm_source=chatgpt.com)

実務上のおすすめ
--------

最初は pillar を 2〜4 個に限定し、  
**nearest-centroid + mixed/unknown 許容**  
が一番壊れにくいです。

* * *

3\. `exposure_direction` を定量化する方法
=================================

これは  
**その銘柄がテーマに直接効くのか、ネットワークや周辺需要を通じて間接的に効くのか**  
です。

ここは supply chain / input-output の考え方が使えます。

基本スコア
-----

$$
\text{Directness}_{i,j} = a \cdot \text{SemanticDirectMatch}_{i,j} + b \cdot \text{RevenueLink}_{i,j} - c \cdot \text{NetworkDistance}_{i,j}
$$

### `SemanticDirectMatch`

銘柄説明文がテーマのコア説明にどれだけ直接一致するかです。  
たとえば AIインフラで GPU メーカーなら高い、一般電力会社ならそこまで高くない、という感じです。

### `RevenueLink`

売上や事業比率のうち、テーマコア事業にどれだけ紐づくかです。  
実務文書でも、text mining 単独ではなく revenue/asset ベースの客観テストを組み合わせるべきとされています。[assets.contentstack.io+1](https://assets.contentstack.io/v3/assets/blt4eb669caa7dc65b2/bltee2e5dcbc0aca502/Theme_Retrieval_for_Equities.pdf?utm_source=chatgpt.com)

### `NetworkDistance`

サプライチェーンや入出力表で見た距離です。  
1次サプライヤーなら direct に近く、2次・3次なら indirect に近づきます。Leontief inverse を使うと、直接・間接リンクを含む露出を測れます。[サイエンスダイレクト+2イングランド銀行+2](https://www.sciencedirect.com/science/article/am/pii/S0954349X23001339?utm_source=chatgpt.com)

離散化
---

*   `Directness ≥ 0.7` → `direct`
*   `0.4 ≤ Directness < 0.7` → `mixed`
*   `Directness < 0.4` → `indirect`
*   confidence が低ければ `unclear`

くらいで十分です。

* * *

4\. `exposure_confidence` を定量化する方法
==================================

これは  
**そのラベル推定にどれだけ自信があるか**  
です。

ここは calibration の問題です。  
分類モデルの生の確率はしばしば過信的なので、Temperature Scaling などで較正した確率を使うのが定石です。Guo et al. は、modern neural nets はしばしば miscalibrated で、temperature scaling が実務上有効だと示しています。[arXiv+1](https://arxiv.org/abs/1706.04599?utm_source=chatgpt.com)

推奨定義
----

$$
\text{Confidence}_{i,j} = f( \text{CalibratedProb}, \text{Margin}, \text{ModelAgreement}, \text{DataCoverage} )
$$

### 具体的には

*   **CalibratedProb**  
    温度スケーリング後の予測確率
*   **Margin**  
    1位ラベルと2位ラベルの差
*   **ModelAgreement**  
    ルールベース、埋め込み、クラスタリング、ネットワーク指標の一致度
*   **DataCoverage**  
    その銘柄について十分なテキスト・財務・事業説明があるか

使い方
---

たとえば

*   `Confidence ≥ 0.8` → `high`
*   `0.5–0.8` → `medium`
*   `< 0.5` → `low`

とします。

### 実務上のコツ

`confidence` は「その企業が良い銘柄か」ではなく、  
**こちらのラベリングがどれだけ安定しているか**  
です。

* * *

5\. `subpillars` を定量化して作る方法
===========================

`subpillars` は一番「作るのが難しい」項目です。  
ただし、ここも人手でゼロから考えるより、**データから候補を作って人手で命名する**のがよいです。

方法A: テーマ関連ニュースの hierarchical topic modeling
-------------------------------------------

テーマ関連ニュースを集めて BERTopic などで topic modeling を行い、さらに hierarchical topics で上位・下位構造を見ます。BERTopic は transformer embeddings と c-TF-IDF を使い、topic の階層可視化もサポートしています。[Maarten's GitHub Page+2Maarten's GitHub Page+2](https://maartengr.github.io/BERTopic/index.html?utm_source=chatgpt.com)

これにより、たとえば AIインフラの下位論点として

*   半導体・計算資源
*   電力・冷却
*   データセンター
*   ネットワーク

のような cluster が浮かぶ可能性があります。

方法B: 企業説明文のクラスタリング
------------------

テーマ構成銘柄の企業説明文を埋め込み化し、階層クラスタリングします。  
そのクラスタに human-readable な名前を付けると subpillars になります。

方法C: shock-oriented subpillars
------------------------------

ニュースの「語られ方」で pillar を作ります。  
たとえば肥満治療なら

*   承認・臨床
*   保険償還
*   供給制約
*   周辺消費波及

のように、**企業分類ではなくニュース論点で分ける**やり方です。  
投資用途ならこちらの方が有効なことが多いです。

実務上のおすすめ
--------

subpillars は最初から細かくしすぎず、  
**2〜5 個程度の安定した大分類** にするのが無難です。

* * *

6\. まとめると、各項目はこう定量化できる
======================

`role`
------

**中心性スコア**で定量化する。  
Semantic exposure、purity、weight、centrality から作る。

`pillar`
--------

**pillar centroid への近さ**か、**テーマ内クラスタ所属**で定量化する。

`exposure_direction`
--------------------

**直接一致度 + 売上リンク − ネットワーク距離** で定量化する。

`exposure_confidence`
---------------------

**較正済み確率 + 1位2位差 + 複数手法の一致度** で定量化する。

`subpillars`
------------

**テーマ関連ニュース / 企業説明文の階層トピック・クラスタ構造**から作る。

* * *

7\. 一番実務的な設計
============

私なら YAML には最初から確定値を書かず、こうします。

*   `role`, `pillar`, `exposure_direction`  
    → 入力しないか、`undecided / unknown / unclear`
*   `role_score`, `pillar_scores`, `directness_score`, `confidence_score`  
    → 別テーブルで定量化
*   YAML には最終的なレビュー済みラベルだけ戻す

つまり、  
**YAML は“人間が納得した最終ラベル”の保存先**  
**定量スコアは別途計算して、ラベルは派生させる**  
のが一番きれいです。

* * *

8\. 批判的に言うと
===========

完全自動化には限界があります。  
理由は、テーマそのものが将来志向で曖昧だからです。  
特に `subpillars` や `role` は、客観的事実だけでなく「そのテーマをどう投資対象として切るか」という設計思想が入ります。

なので、定量化の正しい使い方は、

*   人手判断をゼロにすることではなく
*   **人手判断を“狭いレビュー工程”に押し込むこと**

です。

つまり、

*   候補生成はモデル
*   最終承認は人

が最も現実的です。

必要なら次に、  
**この5項目それぞれについて、YAML に直接書く値と、別テーブルで持つべきスコアの対応表** を作れます。

---

**Sources:**

- [Quantitative Approach for Equity Thematic Exposure ...](https://assets.contentstack.io/v3/assets/blt4eb669caa7dc65b2/bltee2e5dcbc0aca502/Theme_Retrieval_for_Equities.pdf?utm_source=chatgpt.com)
- [Measuring exposure to network concentration risk in global ...](https://www.sciencedirect.com/science/article/am/pii/S0954349X23001339?utm_source=chatgpt.com)
- [(PDF) Dynamic Text-Based Industries and Endogenous ...](https://www.researchgate.net/publication/228364167_Dynamic_Text-Based_Industries_and_Endogenous_Product_Differentiation?utm_source=chatgpt.com)
- [Hierarchical Topic Modeling - BERTopic](https://maartengr.github.io/BERTopic/getting_started/hierarchicaltopics/hierarchicaltopics.html?utm_source=chatgpt.com)
- [On Calibration of Modern Neural Networks](https://arxiv.org/abs/1706.04599?utm_source=chatgpt.com)

## Response:
2026/4/16 0:27:30

> 思考時間: 2 ～ 3 秒

以下に、**通常版テンプレート** と **簡略版テンプレート** を並べて示します。  
違いは一言でいうと、

*   **通常版**: できるだけ構造化して持つ
*   **簡略版**: 判断が難しい項目を保留しやすくする

です。

* * *

1\. 通常版テンプレート
=============

これは、テーマの意味・語彙・投資対象・判定制御をある程度しっかり持たせる版です。  
テーマ定義を継続的に育てていく前提なら、こちらが基本形です。

```
version: 2

themes:
  - theme_id: SAMPLE_THEME_001
    name_ja: サンプルテーマ
    name_en: Sample Theme

    description: >
      このテーマの埋め込み比較用代表文。
      テーマの中心概念、主要ドライバー、関連領域を短く高密度に書く。

    threshold: 0.40

    thesis:
      one_liner: >
        このテーマの一文要約。
      investment_thesis: >
        このテーマが投資対象になる理由、収益源泉、注目論点を書く。
      economic_mechanism:
        - ドライバー1が起きると追い風
        - ドライバー2が起きると逆風
      subpillars:
        - name: コア領域
          description: テーマの中核となる領域
        - name: 周辺領域
          description: 間接受益や補完的領域

    lexicon:
      aliases:
        - サンプルテーマ
        - 別名1
      canonical_terms:
        - テーマを直接表す語1
        - テーマを直接表す語2
      driver_terms:
        - ドライバー語1
        - ドライバー語2
      related_terms:
        - 周辺語1
        - 周辺語2
      exclusion_terms:
        - 除外語1
        - 除外語2
      ambiguous_terms:
        - 一般語1
        - 一般語2

    constituents:
      - security_id: TICKER_A
        name: 構成銘柄A
        description: >
          この銘柄がテーマの中で何を担うかを書く。
          単なる業種ではなく、テーマとの関係を書く。
        weight: 0.10
        role: core
        pillar: コア領域
        exposure_direction: direct
        exposure_confidence: high
        exposure_score: 0.88
        purity_score: 0.81

      - security_id: TICKER_B
        name: 構成銘柄B
        description: >
          この銘柄がテーマにどう関与するかを書く。
        weight: 0.06
        role: satellite
        pillar: 周辺領域
        exposure_direction: indirect
        exposure_confidence: medium
        exposure_score: 0.62
        purity_score: 0.46

    controls:
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.15
      max_single_name_weight: 0.20
      purity_prior: 0.75
      liquidity_prior: 0.80

    memory:
      enabled: true
      min_relevance: 0.60
      lookback_days: 30
      half_life_days: 7
      max_items: 300
      use_event_level: true

    metadata:
      updated_at: 2026-04-15
      created_by: analyst
      review_status: reviewed
      notes: >
        補足メモ。
```

* * *

2\. 簡略版テンプレート
=============

これは、`role` や `pillar` などの二次判断項目が難しいときに使う版です。  
ポイントは、**無理に確定させない**ことです。

```
version: 2

themes:
  - theme_id: SAMPLE_THEME_001
    name_ja: サンプルテーマ
    name_en: Sample Theme

    description: >
      このテーマの埋め込み比較用代表文。
      テーマの中心概念、主要ドライバー、関連領域を短く高密度に書く。

    threshold: 0.40

    thesis:
      one_liner: >
        このテーマの一文要約。
      investment_thesis: >
        このテーマが投資対象になる理由、収益源泉、注目論点を書く。
      economic_mechanism:
        - ドライバー1が追い風
        - ドライバー2が逆風
      subpillars:
        - name: コア領域
          description: 必要最小限の粗い分類
        - name: 周辺領域
          description: 補完的・周辺的領域

    lexicon:
      aliases:
        - サンプルテーマ
      canonical_terms:
        - コア語1
      driver_terms:
        - ドライバー語1
      related_terms:
        - 周辺語1
      exclusion_terms:
        - 除外語1
      ambiguous_terms:
        - 一般語1

    constituents:
      - security_id: TICKER_A
        name: 構成銘柄A
        description: >
          この銘柄がテーマとどう関係するかを書く。
        weight: 0.10

        role: undecided
        pillar: unknown
        pillar_candidates:
          - コア領域
          - 周辺領域

        exposure_direction: unclear
        exposure_confidence: low

        exposure_score: 0.58
        purity_score: 0.52

        notes: >
          テーマとの関係はあるが、コア受益か周辺受益かは未確定。

      - security_id: TICKER_B
        name: 構成銘柄B
        description: >
          この銘柄がテーマに関連すると考える理由を書く。
        weight: 0.06

        role: undecided
        pillar: mixed
        pillar_candidates:
          - コア領域
          - 周辺領域

        exposure_direction: mixed
        exposure_confidence: medium

        exposure_score: 0.72
        purity_score: 0.55

        notes: >
          受益可能性はあるが、専業ではない。

    controls:
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.15

    metadata:
      updated_at: 2026-04-15
      review_status: draft
      notes: >
        判断が難しいため、role/pillar は保留値を許容。
```

* * *

3\. 2つの違い
=========

通常版
---

向いているケース:

*   テーマ定義が比較的はっきりしている
*   構成銘柄の役割もだいたい見えている
*   コア受益と周辺受益をある程度分けられる
*   継続運用して精緻化したい

特徴:

*   `role`, `pillar`, `exposure_direction` を明示
*   `controls`, `memory` も厚め
*   そのまま構造化データとして使いやすい

簡略版
---

向いているケース:

*   テーマが広くて曖昧
*   constituent の位置づけが決めにくい
*   初期構築段階
*   まずは荒く定義して後で見直したい

特徴:

*   `undecided`, `unknown`, `unclear`, `mixed` を許容
*   `pillar_candidates` と `notes` を重視
*   スコアは持つが、離散ラベルは保留しやすい

* * *

4\. どちらを使うべきか
=============

私なら次の基準で分けます。

通常版を使う
------

*   地方銀行
*   肥満治療
*   AIインフラ
*   防衛装備
*   半導体製造装置

のように、比較的テーマの中核が見えやすいもの

簡略版を使う
------

*   DX
*   脱炭素
*   AI全般
*   地方創生
*   リオープン
*   サプライチェーン再編

のように、概念が広く企業との関係が連続的なもの

* * *

5\. 実務上のおすすめ
============

最初から全テーマを通常版で埋めようとすると重いので、

*   **判断しやすいテーマは通常版**
*   **判断しにくいテーマは簡略版**

で混在させて構いません。

つまり、テンプレートは1種類に統一しなくてもよくて、  
**通常版を基本、難しいテーマだけ簡略版**  
が最も現実的です。

必要なら次に、  
**通常版と簡略版を1つの共通スキーマに統一した「ハイブリッド版テンプレート」** を出します。

## Response:
2026/4/16 0:31:46

> 思考時間: 5s

以下に、**地銀テーマバスケット**を例にして、

*   **通常版テンプレート**
*   **簡略版テンプレート**

を実際に埋めたサンプルを示します。  
目的は、**どう書けばよいかの感触を掴むこと**なので、銘柄や数値はあくまで例示です。実運用では、実際の採用ユニバース・ウェイト・銘柄説明に合わせて調整してください。

* * *

1\. 地銀テーマの通常版テンプレート記入例
======================

これは、**地銀テーマの収益源泉や受益構造が比較的見えやすい**前提で、ある程度しっかり構造化して書いた例です。

```
version: 2

themes:
  - theme_id: REGIONAL_BANKS_JP
    name_ja: 地方銀行
    name_en: Regional Banks Japan

    description: >
      日本の地方銀行・地域金融機関を中心に、長期金利、イールドカーブ、
      預貸利ざや、債券評価損益、経営統合、株主還元、地域景気の影響を受けやすい金融テーマ。

    threshold: 0.40

    thesis:
      one_liner: >
        長期金利、再編、資本政策、地域信用環境を主要ドライバーとする日本の地方銀行テーマ。
      investment_thesis: >
        地方銀行は、長期金利やイールドカーブの変化を通じた預貸利ざや改善、
        保有債券の評価損益、地域企業・個人向け貸出需要、経営統合や店舗再編、
        株主還元強化などの影響を受けやすい。ニュース上は、日銀政策、金利、
        地域景況、再編・統合、自己株買い、配当、与信費用、決算などが主要論点となる。
      economic_mechanism:
        - 長期金利やイールドカーブの変化は預貸利ざやに影響する
        - 債券ポートフォリオの評価損益は資本・利益の変動要因となる
        - 経営統合や再編は効率化と株主還元期待につながりやすい
        - 地域景気悪化は信用コスト増加要因となる
      subpillars:
        - name: 金利感応
          description: 預貸利ざや、イールドカーブ、債券評価損益に関する領域
        - name: 再編・資本政策
          description: 経営統合、自己株買い、配当、効率化に関する領域
        - name: 地域信用環境
          description: 地域景況、貸出需要、不良債権、与信費用に関する領域

    lexicon:
      aliases:
        - 地方銀行
        - 地銀
        - 地域金融機関
        - regional banks
      canonical_terms:
        - 地方銀行
        - 地銀
        - 地域金融機関
        - 第二地方銀行
      driver_terms:
        - 長期金利
        - イールドカーブ
        - 預貸利ざや
        - 債券評価損益
        - 経営統合
        - 自己株買い
        - 配当
      related_terms:
        - 地域景気
        - 地方経済
        - 与信費用
        - 不良債権
        - 貸出需要
        - 事業再編
      exclusion_terms:
        - メガバンク
        - 生命保険
        - 損害保険
        - 証券会社
      ambiguous_terms:
        - 金融
        - 銀行
        - 金利

    constituents:
      - security_id: 8334.T
        name: 群馬銀行
        description: >
          関東地盤の地方銀行。預金・貸出を中核とし、金利変動、地域景況、
          信用コスト、株主還元、地銀再編観測の影響を受けやすい。
        weight: 0.10
        role: core
        pillar: 金利感応
        exposure_direction: direct
        exposure_confidence: high
        exposure_score: 0.86
        purity_score: 0.82

      - security_id: 7186.T
        name: コンコルディア・フィナンシャルグループ
        description: >
          地方銀行グループ。金利感応に加え、統合・効率化・資本政策に関するニュースとの結びつきが強い。
        weight: 0.11
        role: core
        pillar: 再編・資本政策
        exposure_direction: direct
        exposure_confidence: high
        exposure_score: 0.88
        purity_score: 0.78

      - security_id: 7167.T
        name: めぶきフィナンシャルグループ
        description: >
          地域金融グループ。長期金利、貸出需要、地域企業動向、
          株主還元に関するニュースに反応しやすい。
        weight: 0.10
        role: core
        pillar: 地域信用環境
        exposure_direction: direct
        exposure_confidence: high
        exposure_score: 0.84
        purity_score: 0.79

      - security_id: 7180.T
        name: 九州フィナンシャルグループ
        description: >
          地方銀行持株会社。地域景気、信用環境、経営効率化、
          資本政策の観点から地銀テーマとの関連が高い。
        weight: 0.08
        role: satellite
        pillar: 地域信用環境
        exposure_direction: direct
        exposure_confidence: medium
        exposure_score: 0.73
        purity_score: 0.71

      - security_id: 7380.T
        name: 十六フィナンシャルグループ
        description: >
          地域金融グループ。金利感応と地域信用環境の双方に露出するが、
          全国大型地銀グループと比べるとニュース波及はやや限定的。
        weight: 0.06
        role: satellite
        pillar: 金利感応
        exposure_direction: direct
        exposure_confidence: medium
        exposure_score: 0.65
        purity_score: 0.76

    controls:
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.18
      max_single_name_weight: 0.20
      purity_prior: 0.82
      liquidity_prior: 0.78

    memory:
      enabled: true
      min_relevance: 0.60
      lookback_days: 30
      half_life_days: 7
      max_items: 250
      use_event_level: true

    metadata:
      updated_at: 2026-04-15
      created_by: analyst
      review_status: reviewed
      notes: >
        地銀テーマは、金利そのものよりも「金利 × 預貸利ざや × 債券評価 × 再編 × 地域信用環境」の
        組み合わせで解釈する。メガバンク関連ニュースの誤混入に注意。
```

* * *

2\. 地銀テーマの簡略版テンプレート記入例
======================

こちらは、**地銀テーマといっても各銘柄のドライバーや役割分担を厳密に切り分けるのは難しい**という立場で書いた版です。  
たとえば、ある地銀グループが「金利感応」なのか「再編・資本政策」なのか「地域信用環境」なのかを一意に決めにくいときに向いています。

```
version: 2

themes:
  - theme_id: REGIONAL_BANKS_JP
    name_ja: 地方銀行
    name_en: Regional Banks Japan

    description: >
      日本の地方銀行・地域金融機関を中心に、長期金利、イールドカーブ、
      預貸利ざや、債券評価損益、再編・統合、株主還元、地域景気の影響を受けやすい金融テーマ。

    threshold: 0.40

    thesis:
      one_liner: >
        長期金利、再編、地域信用環境に感応する日本の地方銀行テーマ。
      investment_thesis: >
        地方銀行は、金利・信用環境・資本政策・経営統合の複数要因に影響されるため、
        個別銘柄ごとに主たる受益要因がやや異なる。ニュース分類では、
        地銀全体に波及するニュースと個別行固有ニュースを切り分けることが重要。
      economic_mechanism:
        - 長期金利やイールドカーブの変化は利ざやに影響する
        - 地域景況や不動産・中小企業環境は信用コストに影響する
        - 再編・統合・株主還元はバリュエーション再評価要因となる
      subpillars:
        - name: 金利・収益性
          description: 金利、利ざや、債券評価など
        - name: 資本政策・再編
          description: 統合、自己株買い、配当など
        - name: 地域信用環境
          description: 景気、貸出、不良債権、与信費用など

    lexicon:
      aliases:
        - 地方銀行
        - 地銀
        - 地域金融機関
      canonical_terms:
        - 地方銀行
        - 地銀
        - 第二地方銀行
      driver_terms:
        - 長期金利
        - 預貸利ざや
        - 経営統合
        - 自己株買い
        - 地域景気
      related_terms:
        - 与信費用
        - 貸出需要
        - 配当
      exclusion_terms:
        - メガバンク
        - 保険
      ambiguous_terms:
        - 金融
        - 銀行

    constituents:
      - security_id: 8334.T
        name: 群馬銀行
        description: >
          地方銀行。長期金利、地域景況、株主還元のいずれにも反応しうるため、
          主たる pillar は現時点で固定しない。
        weight: 0.10
        role: undecided
        pillar: mixed
        pillar_candidates:
          - 金利・収益性
          - 地域信用環境
        exposure_direction: direct
        exposure_confidence: medium
        exposure_score: 0.81
        purity_score: 0.80
        notes: >
          地銀テーマとの関連は強いが、金利感応と地域信用環境のどちらが主軸かは局面依存。

      - security_id: 7186.T
        name: コンコルディア・フィナンシャルグループ
        description: >
          地方銀行グループ。再編・効率化・資本政策と金利感応の両面があり、
          コア受益とみなせる可能性は高いが、役割は単一ではない。
        weight: 0.11
        role: undecided
        pillar: mixed
        pillar_candidates:
          - 金利・収益性
          - 資本政策・再編
        exposure_direction: mixed
        exposure_confidence: medium
        exposure_score: 0.86
        purity_score: 0.76
        notes: >
          地銀テーマの代表銘柄候補だが、再編テーマとしての色も強い。

      - security_id: 7167.T
        name: めぶきフィナンシャルグループ
        description: >
          地域金融グループ。貸出需要、地場企業動向、金利、株主還元など複数ドライバーにまたがる。
        weight: 0.10
        role: undecided
        pillar: unknown
        pillar_candidates:
          - 金利・収益性
          - 地域信用環境
          - 資本政策・再編
        exposure_direction: unclear
        exposure_confidence: low
        exposure_score: 0.79
        purity_score: 0.78
        notes: >
          地銀としての純度は高いが、ニュース上どの論点で最も効くかは一意に決めにくい。

      - security_id: 7180.T
        name: 九州フィナンシャルグループ
        description: >
          地域金融グループ。地域景況や信用環境への露出が大きいが、
          金利感応や資本政策との関連もある。
        weight: 0.08
        role: undecided
        pillar: mixed
        pillar_candidates:
          - 地域信用環境
          - 金利・収益性
        exposure_direction: mixed
        exposure_confidence: medium
        exposure_score: 0.71
        purity_score: 0.73
        notes: >
          周辺受益と断定するほど弱くはないが、コアと固定するほど単純でもない。

      - security_id: 7380.T
        name: 十六フィナンシャルグループ
        description: >
          地銀テーマとの関係は明確だが、全国ニュースフロー上では相対的に露出が小さい可能性がある。
        weight: 0.06
        role: undecided
        pillar: unknown
        pillar_candidates:
          - 金利・収益性
          - 地域信用環境
        exposure_direction: direct
        exposure_confidence: low
        exposure_score: 0.61
        purity_score: 0.75
        notes: >
          地銀としての純度は高めだが、テーマ内での中心性は今後要確認。

    controls:
      relevance_threshold: 0.40
      margin_threshold: 0.05
      min_constituent_breadth: 0.18

    metadata:
      updated_at: 2026-04-15
      review_status: draft
      notes: >
        地銀テーマは構成銘柄の事業モデルが似ている一方、ニュース反応の主軸が金利・再編・信用環境にまたがるため、
        role/pillar は保留値を許容する。
```

* * *

3\. 2つの違いを地銀テーマで見ると
===================

通常版
---

通常版では、地銀テーマの中でもある程度、

*   金利感応が強い
*   再編・資本政策の色が強い
*   地域信用環境の影響が強い

といった**主担当を決めにいっています**。

つまり、  
**「テーマ構造はだいたい見えている」**  
という前提です。

簡略版
---

簡略版では、地銀テーマに属すること自体は比較的明確でも、

*   どの pillar が主軸か
*   core と satellite をどう切るか
*   direct と mixed のどちらが妥当か

が微妙だと認めています。

つまり、  
**「地銀テーマには属するが、テーマ内での役割までは断定しない」**  
という前提です。

* * *

4\. 地銀テーマではどちらが向いているか
=====================

実務上は、**最初は簡略版の方が安全**です。  
理由は、地銀はどの銘柄も

*   金利感応
*   地域景気
*   資本政策
*   再編観測

の複数要因にまたがるためです。

そのため、初期段階では

*   `role: undecided`
*   `pillar: mixed / unknown`
*   `exposure_confidence: low / medium`

を許した方が自然です。

その後、ニュース分類結果や価格反応を見ながら、  
通常版のように少しずつ役割を固定していくのがよいです。

* * *

5\. 私ならこう使い分けます
===============

初期構築
----

簡略版で全地銀銘柄を埋める

何週間かニュースを見た後
------------

*   金利ニュースで consistently 反応する銘柄
*   再編ニュースで consistently 反応する銘柄
*   信用環境ニュースで反応する銘柄

を見て、通常版へ昇格させる

つまり、  
**地銀テーマでは「簡略版 → 通常版」への移行運用が最も自然**です。

必要なら次に、  
**この地銀テーマの例をさらに「最小必須項目だけ」に削った版** も作れます。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)