"""入出力処理。"""

from __future__ import annotations

from pathlib import Path
import json
from typing import Any

import pandas as pd
import yaml


REQUIRED_ARTICLE_COLUMNS = [
    "article_id",
    "published_at",
    "source",
    "title",
    "summary",
    "body",
    "url",
]

REQUIRED_THEME_COLUMNS = ["theme_id", "name_ja", "description", "threshold"]


def _as_list_str(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    return [str(value).strip()]


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _constituents_to_records(theme_id: str, value: Any) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not isinstance(value, list):
        return rows
    for idx, item in enumerate(value):
        item_dict = _as_dict(item)
        rows.append(
            {
                "theme_id": str(theme_id),
                "constituent_id": str(item_dict.get("security_id") or item_dict.get("name") or f"{theme_id}_{idx}"),
                "security_id": str(item_dict.get("security_id") or ""),
                "name": str(item_dict.get("name") or ""),
                "description": str(item_dict.get("description") or ""),
                "weight": pd.to_numeric(item_dict.get("weight", 0.0), errors="coerce"),
                "role": str(item_dict.get("role") or ""),
                "pillar": str(item_dict.get("pillar") or ""),
                "exposure_direction": str(item_dict.get("exposure_direction") or ""),
                "exposure_confidence": str(item_dict.get("exposure_confidence") or ""),
            }
        )
    return rows



def load_articles_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = sorted(set(REQUIRED_ARTICLE_COLUMNS) - set(df.columns))
    if missing:
        raise ValueError(f"入力CSVに必須カラムが不足しています: {missing}")

    out = df.copy()
    out["published_at"] = pd.to_datetime(out["published_at"], errors="coerce")
    if out["published_at"].isna().any():
        invalid_count = int(out["published_at"].isna().sum())
        raise ValueError(f"published_at を datetime へ変換できない行があります: {invalid_count} 件")

    for col in ["article_id", "source", "title", "summary", "body", "url"]:
        out[col] = out[col].fillna("").astype(str)
    return out



def load_theme_definitions(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()

    if suffix in {".yml", ".yaml"}:
        with path.open("r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)
    elif suffix == ".json":
        with path.open("r", encoding="utf-8") as f:
            raw = json.load(f)
    else:
        raise ValueError(f"未対応のテーマ定義ファイル拡張子です: {suffix}")

    if not isinstance(raw, dict) or "themes" not in raw:
        raise ValueError("テーマ定義は {themes: [...]} 形式である必要があります。")

    themes = raw["themes"]
    if not isinstance(themes, list):
        raise ValueError("themes は配列である必要があります。")

    normalized_rows: list[dict[str, Any]] = []
    for item in themes:
        if not isinstance(item, dict):
            continue

        controls = _as_dict(item.get("controls"))
        memory = _as_dict(item.get("memory"))
        thesis = _as_dict(item.get("thesis"))
        lexicon = _as_dict(item.get("lexicon"))

        theme_id = str(item.get("theme_id") or "")
        row: dict[str, Any] = {
            "theme_id": theme_id,
            "name_ja": str(item.get("name_ja") or ""),
            "name_en": str(item.get("name_en") or ""),
            "description": str(item.get("description") or ""),
            "threshold": item.get("threshold", controls.get("relevance_threshold")),
            "thesis_one_liner": str(thesis.get("one_liner") or ""),
            "thesis_investment": str(thesis.get("investment_thesis") or ""),
            "economic_mechanism": _as_list_str(thesis.get("economic_mechanism")),
            "subpillars": thesis.get("subpillars", []),
            "aliases": _as_list_str(item.get("aliases")) + _as_list_str(lexicon.get("aliases")),
            "keywords": _as_list_str(item.get("keywords")),
            "canonical_terms": _as_list_str(lexicon.get("canonical_terms")),
            "driver_terms": _as_list_str(lexicon.get("driver_terms")),
            "related_terms": _as_list_str(lexicon.get("related_terms")),
            "exclusion_terms": _as_list_str(lexicon.get("exclusion_terms")),
            "ambiguous_terms": _as_list_str(lexicon.get("ambiguous_terms")),
            "constituents": item.get("constituents", []),
            "memory_enabled": bool(memory.get("enabled", False)),
            "memory_min_relevance": pd.to_numeric(memory.get("min_relevance"), errors="coerce"),
            "memory_lookback_days": pd.to_numeric(memory.get("lookback_days"), errors="coerce"),
            "memory_half_life_days": pd.to_numeric(memory.get("half_life_days"), errors="coerce"),
            "memory_max_items": pd.to_numeric(memory.get("max_items"), errors="coerce"),
            "memory_use_event_level": bool(memory.get("use_event_level", True)),
            "controls_margin_threshold": pd.to_numeric(controls.get("margin_threshold"), errors="coerce"),
            "controls_min_constituent_breadth": pd.to_numeric(controls.get("min_constituent_breadth"), errors="coerce"),
            "controls_purity_prior": pd.to_numeric(controls.get("purity_prior"), errors="coerce"),
            "controls_liquidity_prior": pd.to_numeric(controls.get("liquidity_prior"), errors="coerce"),
        }
        row["constituent_records"] = _constituents_to_records(theme_id, row["constituents"])
        normalized_rows.append(row)

    df = pd.DataFrame(normalized_rows)
    missing = sorted(set(REQUIRED_THEME_COLUMNS) - set(df.columns))
    if missing:
        raise ValueError(f"テーマ定義に必須項目が不足しています: {missing}")

    out = df.copy()
    out["theme_id"] = out["theme_id"].astype(str)
    out["name_ja"] = out["name_ja"].astype(str)
    out["description"] = out["description"].fillna("").astype(str)
    out["threshold"] = pd.to_numeric(out["threshold"], errors="coerce")

    if out["threshold"].isna().any():
        invalid_count = int(out["threshold"].isna().sum())
        raise ValueError(f"threshold に数値変換できない値があります: {invalid_count} 件")

    list_like_cols = [
        "aliases",
        "keywords",
        "canonical_terms",
        "driver_terms",
        "related_terms",
        "exclusion_terms",
        "ambiguous_terms",
        "economic_mechanism",
        "subpillars",
        "constituents",
        "constituent_records",
    ]
    for col in list_like_cols:
        if col in out.columns:
            out[col] = out[col].apply(lambda x: x if isinstance(x, list) else [])

    numeric_defaults = {
        "memory_min_relevance": pd.NA,
        "memory_lookback_days": pd.NA,
        "memory_half_life_days": pd.NA,
        "memory_max_items": pd.NA,
        "controls_margin_threshold": pd.NA,
        "controls_min_constituent_breadth": pd.NA,
        "controls_purity_prior": pd.NA,
        "controls_liquidity_prior": pd.NA,
    }
    for col, default in numeric_defaults.items():
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")
            if default is not pd.NA:
                out[col] = out[col].fillna(default)

    return out



def load_optional_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)



def save_parquet(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)



def read_parquet_if_exists(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_parquet(path)
