"""
Theme Basket Strategy Implementation
====================================

Coherence-Gated Narrative Momentum with Governance/PBR Catalyst Overlay
for Japanese equity theme baskets.

This module is intentionally dependency-light: pandas + numpy only.
It supports four implementation levels:

1. MVP: theme basket prices only
   - residual/simple theme momentum
   - return-acceleration crowding control
   - long-only or long-short theme allocation

2. Factor-adjusted: theme prices + factor returns
   - rolling factor residualization of theme basket returns
   - residual theme momentum

3. Coherence-gated: add PIT constituents + stock prices/returns
   - rolling residualization of stock returns
   - theme-level average pairwise residual correlation / eigenshare
   - effective name count gate

4. Complete overlay: add precomputed news/governance/theme features
   - news confirmation score
   - governance/PBR catalyst score
   - crowding score from turnover/news if available

Author: ChatGPT
Date: 2026-05-10
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import asdict, dataclass
from typing import Dict, Iterable, List, Literal, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

Mode = Literal["long_only", "long_short"]
InputKind = Literal["price", "return", "auto"]


@dataclass
class StrategyConfig:
    """Main strategy parameters.

    Notes
    -----
    - All rolling calculations are designed to avoid obvious same-period
      look-ahead in signal construction. Portfolio weights are shifted by one
      trading day in the backtest.
    - Lookback/skip values are in trading days.
    """

    # Input treatment
    theme_input_kind: InputKind = "auto"  # auto/price/return
    stock_input_kind: InputKind = "auto"  # auto/price/return

    # Residualization
    residualize_themes: bool = True
    residualize_stocks: bool = True
    rolling_beta_window: int = 252
    rolling_beta_min_obs: int = 126
    ridge_lambda: float = 1e-4

    # Momentum
    mom_lookbacks: Tuple[int, int, int] = (252, 126, 63)
    mom_weights: Tuple[float, float, float] = (0.50, 0.30, 0.20)
    mom_skip: int = 21
    mom_vol_floor: float = 1e-4

    # Coherence gate
    use_coherence_gate: bool = True
    coherence_window: int = 126
    coherence_min_names: int = 8
    coherence_min_effective_names: float = 5.0
    coherence_apc_threshold: float = 0.00
    coherence_score_threshold: Optional[float] = None  # if None only hard gates
    eigenshare_weight: float = 0.35
    apc_weight: float = 0.65

    # Optional overlays
    use_news: bool = True
    use_governance: bool = True
    use_leadlag: bool = False  # placeholder; supplied features can include it
    use_valuation: bool = False  # placeholder; supplied features can include it
    use_crowding: bool = True

    # Final score weights
    w_momentum: float = 0.45
    w_news: float = 0.20
    w_governance: float = 0.20
    w_leadlag: float = 0.10
    w_valuation: float = 0.05
    w_crowding_penalty: float = 0.25

    # Portfolio construction
    mode: Mode = "long_only"
    rebalance: str = "ME"  # pandas offset alias: ME/M, W-FRI, 2W-FRI, etc.
    top_n: Optional[int] = None
    bottom_n: Optional[int] = None
    long_quantile: float = 0.20
    short_quantile: float = 0.20
    max_theme_weight: float = 0.15
    min_abs_score: float = 0.0
    gross_exposure: float = 1.0
    net_exposure: float = 1.0  # ignored in long_short unless custom desired

    # Costs and diagnostics
    cost_bps_per_turnover: float = 5.0
    annualization: int = 252

    # Missing data
    min_theme_obs: int = 126
    fill_missing_returns: bool = False

    def normalized_mom_weights(self) -> np.ndarray:
        w = np.asarray(self.mom_weights, dtype=float)
        if not np.isfinite(w).all() or w.sum() == 0:
            raise ValueError("mom_weights must be finite and have non-zero sum")
        return w / w.sum()


# ---------------------------------------------------------------------------
# IO utilities
# ---------------------------------------------------------------------------


def _infer_date_col(columns: Sequence[str]) -> str:
    candidates = ["date", "Date", "DATE", "datetime", "timestamp", "Timestamp"]
    for c in candidates:
        if c in columns:
            return c
    return columns[0]


def read_matrix_csv(
    path: str,
    date_col: Optional[str] = None,
    value_col: Optional[str] = None,
    key_col: Optional[str] = None,
) -> pd.DataFrame:
    """Read a time-series matrix from a CSV file.

    Supported schemas
    -----------------
    Wide:
        date, AI, Semiconductor, Defense, ...

    Long:
        date, theme, value
        date, ticker, value
        date, factor, value

    Parameters
    ----------
    path:
        CSV path.
    date_col:
        Date column. If omitted, inferred.
    value_col:
        For long format, the value column. If omitted, inferred among
        [value, price, return, ret, score].
    key_col:
        For long format, the key column. If omitted, inferred among
        [theme, ticker, symbol, factor, name].

    Returns
    -------
    pd.DataFrame
        Date-indexed, wide-format matrix.
    """
    df = pd.read_csv(path)
    if df.empty:
        raise ValueError(f"Empty CSV: {path}")

    date_col = date_col or _infer_date_col(list(df.columns))
    if date_col not in df.columns:
        raise ValueError(f"date_col='{date_col}' not found in {path}")

    cols_lower = {c.lower(): c for c in df.columns}
    if key_col is None:
        for c in ["theme", "ticker", "symbol", "ric", "factor", "name"]:
            if c in cols_lower:
                key_col = cols_lower[c]
                break
    if value_col is None:
        for c in ["value", "price", "px", "return", "ret", "score", "weight"]:
            if c in cols_lower:
                value_col = cols_lower[c]
                break

    df[date_col] = pd.to_datetime(df[date_col])

    # Long format
    if key_col is not None and value_col is not None and key_col in df.columns and value_col in df.columns:
        out = df.pivot_table(index=date_col, columns=key_col, values=value_col, aggfunc="last")
        out = out.sort_index()
        out.columns = out.columns.astype(str)
        return out.apply(pd.to_numeric, errors="coerce")

    # Wide format
    out = df.set_index(date_col).sort_index()
    out = out.loc[:, ~out.columns.astype(str).str.lower().isin(["unnamed: 0"])]
    out.columns = out.columns.astype(str)
    return out.apply(pd.to_numeric, errors="coerce")


def read_constituents_csv(path: str) -> pd.DataFrame:
    """Read point-in-time theme constituents.

    Required columns
    ----------------
    - theme
    - ticker or ric or symbol
    - weight

    Optional columns
    ----------------
    - date: effective date. If missing, treated as static from 1900-01-01.
    - purity: semantic/theme purity in [0, 1] or any positive score.
    - liquidity_adj: optional positive multiplier.

    Returns
    -------
    pd.DataFrame with columns [date, theme, ticker, weight, purity, liquidity_adj]
    """
    df = pd.read_csv(path)
    cols_lower = {c.lower(): c for c in df.columns}

    theme_col = cols_lower.get("theme")
    ticker_col = cols_lower.get("ticker") or cols_lower.get("ric") or cols_lower.get("symbol")
    weight_col = cols_lower.get("weight") or cols_lower.get("wgt")
    date_col = cols_lower.get("date") or cols_lower.get("effective_date")

    if theme_col is None or ticker_col is None or weight_col is None:
        raise ValueError(
            "constituents_csv requires columns: theme, ticker/ric/symbol, weight "
            f". Found columns={list(df.columns)}"
        )

    out = pd.DataFrame(
        {
            "date": pd.to_datetime(df[date_col]) if date_col else pd.Timestamp("1900-01-01"),
            "theme": df[theme_col].astype(str),
            "ticker": df[ticker_col].astype(str),
            "weight": pd.to_numeric(df[weight_col], errors="coerce"),
        }
    )
    out["purity"] = pd.to_numeric(df[cols_lower["purity"]], errors="coerce") if "purity" in cols_lower else 1.0
    out["liquidity_adj"] = (
        pd.to_numeric(df[cols_lower["liquidity_adj"]], errors="coerce") if "liquidity_adj" in cols_lower else 1.0
    )
    out = out.dropna(subset=["date", "theme", "ticker", "weight"])
    out["weight"] = out["weight"].clip(lower=0.0)
    out["purity"] = out["purity"].fillna(1.0).clip(lower=0.0)
    out["liquidity_adj"] = out["liquidity_adj"].fillna(1.0).clip(lower=0.0)
    return out.sort_values(["theme", "date", "ticker"]).reset_index(drop=True)


def prices_to_returns(data: pd.DataFrame, kind: InputKind = "auto") -> pd.DataFrame:
    """Convert price or return matrix to returns.

    If kind='auto', use a simple heuristic:
    - If median absolute value > 2, treat as prices.
    - Otherwise treat as returns.
    """
    x = data.copy().sort_index()
    x = x.replace([np.inf, -np.inf], np.nan)

    if kind == "auto":
        med_abs = np.nanmedian(np.abs(x.to_numpy(dtype=float)))
        kind = "price" if med_abs > 2.0 else "return"

    if kind == "price":
        ret = x.pct_change(fill_method=None)
    elif kind == "return":
        ret = x.copy()
    else:
        raise ValueError("kind must be one of 'auto', 'price', 'return'")

    ret = ret.replace([np.inf, -np.inf], np.nan)
    return ret


# ---------------------------------------------------------------------------
# Math utilities
# ---------------------------------------------------------------------------


def zscore_cross_sectional(x: pd.DataFrame, winsor: float = 5.0) -> pd.DataFrame:
    """Cross-sectional z-score by date."""
    mu = x.mean(axis=1, skipna=True)
    sd = x.std(axis=1, skipna=True, ddof=0).replace(0.0, np.nan)
    z = x.sub(mu, axis=0).div(sd, axis=0)
    if winsor is not None:
        z = z.clip(-winsor, winsor)
    return z


def _safe_std(x: pd.Series, floor: float) -> float:
    s = float(x.std(ddof=0))
    if not np.isfinite(s) or s < floor:
        return np.nan
    return s


def rolling_residualize(
    returns: pd.DataFrame,
    factors: Optional[pd.DataFrame],
    window: int = 252,
    min_obs: int = 126,
    ridge_lambda: float = 1e-4,
) -> pd.DataFrame:
    """Rolling one-step residualization against factor returns.

    For each asset and date t, beta is estimated using observations up to t-1,
    and residual at t is r_t - X_t beta_{t-1}. This avoids using r_t to
    estimate beta_t.

    If factors is None or empty, returns are returned unchanged.
    """
    y = returns.copy().sort_index()
    if factors is None or factors.empty:
        return y

    X = factors.copy().sort_index()
    idx = y.index.intersection(X.index)
    y = y.loc[idx]
    X = X.loc[idx]
    X = X.replace([np.inf, -np.inf], np.nan)
    y = y.replace([np.inf, -np.inf], np.nan)

    # Add intercept.
    Xmat_full = np.column_stack([np.ones(len(X)), X.to_numpy(dtype=float)])
    ymat = y.to_numpy(dtype=float)
    out = np.full_like(ymat, np.nan, dtype=float)

    k = Xmat_full.shape[1]
    ridge = np.eye(k) * ridge_lambda
    ridge[0, 0] = 0.0  # do not penalize intercept

    for t in range(len(idx)):
        start = max(0, t - window)
        end = t  # up to t-1
        if end - start < min_obs:
            continue
        Xw_all = Xmat_full[start:end, :]
        Xt = Xmat_full[t, :]
        if not np.isfinite(Xt).all():
            continue
        for j in range(ymat.shape[1]):
            yw_all = ymat[start:end, j]
            mask = np.isfinite(yw_all) & np.isfinite(Xw_all).all(axis=1)
            if int(mask.sum()) < min_obs:
                continue
            Xw = Xw_all[mask, :]
            yw = yw_all[mask]
            try:
                beta = np.linalg.solve(Xw.T @ Xw + ridge, Xw.T @ yw)
            except np.linalg.LinAlgError:
                beta = np.linalg.pinv(Xw.T @ Xw + ridge) @ Xw.T @ yw
            if np.isfinite(ymat[t, j]):
                out[t, j] = ymat[t, j] - float(Xt @ beta)

    return pd.DataFrame(out, index=idx, columns=y.columns)


def rolling_momentum(
    returns: pd.DataFrame,
    lookbacks: Sequence[int] = (252, 126, 63),
    weights: Sequence[float] = (0.50, 0.30, 0.20),
    skip: int = 21,
    vol_floor: float = 1e-4,
) -> pd.DataFrame:
    """Compute risk-adjusted, multi-horizon momentum with a skip period.

    Signal at t uses returns [t-lookback-skip+1, ..., t-skip].
    """
    ret = returns.copy().sort_index()
    weights_arr = np.asarray(weights, dtype=float)
    weights_arr = weights_arr / weights_arr.sum()
    signals = []
    for lb, w in zip(lookbacks, weights_arr):
        # use shifted returns to create skip
        shifted = ret.shift(skip)
        cum = shifted.rolling(lb, min_periods=max(20, lb // 2)).sum()
        vol = shifted.rolling(lb, min_periods=max(20, lb // 2)).std(ddof=0).replace(0.0, np.nan)
        sig = cum / vol.clip(lower=vol_floor)
        signals.append(w * sig)
    raw = sum(signals)
    return zscore_cross_sectional(raw)


def return_acceleration_crowding(returns: pd.DataFrame, short: int = 21, medium: int = 63) -> pd.DataFrame:
    """A simple crowding/overheat proxy from return acceleration.

    High values mean recent one-month return is much stronger than the prior
    medium window. This is only a proxy; volume/news turnover features are
    better when available.
    """
    r_short = returns.rolling(short, min_periods=max(5, short // 2)).sum()
    r_med_lag = returns.shift(short).rolling(medium, min_periods=max(10, medium // 2)).sum()
    accel = r_short - r_med_lag
    return zscore_cross_sectional(accel)


def rolling_theme_turnover_crowding(turnover: pd.DataFrame, window: int = 60) -> pd.DataFrame:
    """Turnover surprise crowding score from theme-level turnover/volume data."""
    x = np.log1p(turnover.replace([np.inf, -np.inf], np.nan).clip(lower=0))
    surpr = x - x.rolling(window, min_periods=max(10, window // 2)).mean()
    return zscore_cross_sectional(surpr)


def align_feature_matrix(
    feature: Optional[pd.DataFrame],
    index: pd.Index,
    columns: Sequence[str],
    fill_value: float = 0.0,
) -> pd.DataFrame:
    """Align optional theme-level feature matrix to strategy index/columns."""
    if feature is None or feature.empty:
        return pd.DataFrame(fill_value, index=index, columns=columns, dtype=float)
    f = feature.copy().sort_index()
    f = f.reindex(index).ffill()
    f = f.reindex(columns=columns)
    return f.fillna(fill_value).astype(float)


# ---------------------------------------------------------------------------
# Constituents / coherence
# ---------------------------------------------------------------------------


def _latest_constituents_for_date(constituents: pd.DataFrame, dt: pd.Timestamp) -> Dict[str, pd.DataFrame]:
    """Return latest constituent slice for each theme as of dt."""
    c = constituents[constituents["date"] <= dt]
    if c.empty:
        return {}
    out: Dict[str, pd.DataFrame] = {}
    for theme, g in c.groupby("theme"):
        latest_date = g["date"].max()
        gg = g[g["date"] == latest_date].copy()
        gg = gg[gg["weight"] > 0]
        if gg.empty:
            continue
        # Apply purity/liquidity weight adjustment for analysis.
        adj_w = gg["weight"] * gg["purity"].fillna(1.0) * gg["liquidity_adj"].fillna(1.0)
        if adj_w.sum() <= 0:
            continue
        gg["adj_weight"] = adj_w / adj_w.sum()
        out[str(theme)] = gg
    return out


def effective_n(weights: Union[pd.Series, np.ndarray]) -> float:
    w = np.asarray(weights, dtype=float)
    w = w[np.isfinite(w)]
    if w.size == 0 or w.sum() <= 0:
        return np.nan
    w = w / w.sum()
    return float(1.0 / np.sum(w**2))


def compute_coherence_features(
    residual_stock_returns: pd.DataFrame,
    constituents: pd.DataFrame,
    theme_columns: Sequence[str],
    signal_dates: Sequence[pd.Timestamp],
    window: int = 126,
    min_names: int = 8,
    min_effective_names: float = 5.0,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Compute theme coherence features on selected signal dates.

    Returns
    -------
    apc, eigenshare, eff_n, gate
        All DataFrames indexed by signal_dates and theme_columns.
    """
    stock_ret = residual_stock_returns.copy().sort_index()
    dates = pd.DatetimeIndex(signal_dates)
    themes = list(map(str, theme_columns))
    apc = pd.DataFrame(np.nan, index=dates, columns=themes)
    eig = pd.DataFrame(np.nan, index=dates, columns=themes)
    eff = pd.DataFrame(np.nan, index=dates, columns=themes)
    gate = pd.DataFrame(False, index=dates, columns=themes)

    for dt in dates:
        if dt not in stock_ret.index:
            # use nearest previous date present in stock returns
            prev = stock_ret.index[stock_ret.index <= dt]
            if len(prev) == 0:
                continue
            dtx = prev[-1]
        else:
            dtx = dt
        loc = stock_ret.index.get_loc(dtx)
        if isinstance(loc, slice) or isinstance(loc, np.ndarray):
            loc = int(np.asarray(loc).ravel()[-1])
        start = max(0, int(loc) - window + 1)
        win = stock_ret.iloc[start : int(loc) + 1]
        latest = _latest_constituents_for_date(constituents, dt)
        for theme in themes:
            gg = latest.get(theme)
            if gg is None or gg.empty:
                continue
            tickers = [t for t in gg["ticker"].astype(str).tolist() if t in win.columns]
            if len(tickers) < min_names:
                continue
            w = gg.set_index("ticker").loc[tickers, "adj_weight"].astype(float)
            en = effective_n(w.values)
            eff.loc[dt, theme] = en
            if not np.isfinite(en) or en < min_effective_names:
                continue
            sub = win[tickers].dropna(axis=1, thresh=max(20, window // 2))
            if sub.shape[1] < min_names:
                continue
            corr = sub.corr(min_periods=max(20, window // 2)).to_numpy(dtype=float)
            if corr.shape[0] < min_names:
                continue
            iu = np.triu_indices_from(corr, k=1)
            pair_corr = corr[iu]
            pair_corr = pair_corr[np.isfinite(pair_corr)]
            if pair_corr.size == 0:
                continue
            apc_val = float(np.nanmean(pair_corr))
            apc.loc[dt, theme] = apc_val

            # Eigenshare based on pairwise-complete correlation. Fill remaining NaN with 0 off diag.
            cmat = np.array(corr, copy=True)
            np.fill_diagonal(cmat, 1.0)
            cmat = np.nan_to_num(cmat, nan=0.0, posinf=0.0, neginf=0.0)
            try:
                vals = np.linalg.eigvalsh(cmat)
                vals = np.clip(vals, 0.0, None)
                es = float(vals[-1] / vals.sum()) if vals.sum() > 0 else np.nan
            except np.linalg.LinAlgError:
                es = np.nan
            eig.loc[dt, theme] = es
            gate.loc[dt, theme] = True

    return apc, eig, eff, gate


# ---------------------------------------------------------------------------
# Signal and portfolio construction
# ---------------------------------------------------------------------------


def make_rebalance_dates(index: pd.DatetimeIndex, rule: str = "ME") -> pd.DatetimeIndex:
    """Return trading dates that correspond to period-end rebalances.

    Pandas versions differ on whether monthly end is represented as ``M`` or
    ``ME``. This helper accepts both and falls back gracefully.
    """
    if len(index) == 0:
        return index
    s = pd.Series(index=index, data=np.arange(len(index)))
    # Last available date in each rule bucket.
    try:
        rebal = s.resample(rule).last().dropna().astype(int).values
    except ValueError:
        if rule == "ME":
            rebal = s.resample("M").last().dropna().astype(int).values
        elif rule == "M":
            rebal = s.resample("ME").last().dropna().astype(int).values
        else:
            raise
    return pd.DatetimeIndex(index[rebal])


def cap_and_normalize_long(w: pd.Series, max_weight: float, gross: float = 1.0) -> pd.Series:
    """Normalize positive weights with iterative max-weight cap."""
    x = w.clip(lower=0).astype(float).copy()
    x = x.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    if x.sum() <= 0:
        return x
    x = x / x.sum() * gross
    if max_weight is None or max_weight <= 0:
        return x
    cap = max_weight * gross if max_weight <= 1 else max_weight
    # iterative water filling
    for _ in range(20):
        over = x > cap
        if not over.any():
            break
        excess = float((x[over] - cap).sum())
        x[over] = cap
        under = ~over
        if x[under].sum() <= 0 or excess <= 1e-12:
            break
        x[under] += x[under] / x[under].sum() * excess
    # final normalize if possible
    if x.sum() > 0:
        x = x / x.sum() * gross
    return x


def construct_theme_weights(
    scores: pd.DataFrame,
    config: StrategyConfig,
    gates: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """Construct theme-level weights from scores at rebalance dates."""
    s = scores.copy().replace([np.inf, -np.inf], np.nan)
    if gates is not None:
        gates_aligned = gates.reindex_like(s).fillna(False)
        s = s.where(gates_aligned)

    weights = pd.DataFrame(0.0, index=s.index, columns=s.columns)
    n_cols = len(s.columns)

    for dt, row in s.iterrows():
        row = row.dropna()
        if row.empty:
            continue
        row = row[row.abs() >= config.min_abs_score]
        if row.empty:
            continue

        if config.mode == "long_only":
            r = row[row > 0]
            if r.empty:
                continue
            if config.top_n is not None:
                selected = r.nlargest(config.top_n)
            else:
                qn = max(1, int(math.ceil(n_cols * config.long_quantile)))
                selected = r.nlargest(qn)
            raw = selected.clip(lower=0)
            w = cap_and_normalize_long(raw, config.max_theme_weight, config.gross_exposure)
            weights.loc[dt, w.index] = w

        elif config.mode == "long_short":
            q_long = config.top_n if config.top_n is not None else max(1, int(math.ceil(n_cols * config.long_quantile)))
            q_short = config.bottom_n if config.bottom_n is not None else max(1, int(math.ceil(n_cols * config.short_quantile)))
            longs = row[row > 0].nlargest(q_long)
            shorts = row[row < 0].nsmallest(q_short)  # most negative
            if not longs.empty:
                wl = cap_and_normalize_long(longs.clip(lower=0), config.max_theme_weight, config.gross_exposure / 2.0)
                weights.loc[dt, wl.index] = wl
            if not shorts.empty:
                ws_abs = cap_and_normalize_long((-shorts).clip(lower=0), config.max_theme_weight, config.gross_exposure / 2.0)
                weights.loc[dt, ws_abs.index] = -ws_abs
        else:
            raise ValueError("mode must be long_only or long_short")

    return weights


def expand_rebalance_weights(weights_rebal: pd.DataFrame, full_index: pd.DatetimeIndex) -> pd.DataFrame:
    """Forward-fill rebalance weights onto the full daily index."""
    w = weights_rebal.reindex(full_index).ffill().fillna(0.0)
    return w


def backtest_theme_weights(
    theme_returns: pd.DataFrame,
    weights_daily: pd.DataFrame,
    cost_bps_per_turnover: float = 5.0,
) -> Tuple[pd.Series, pd.DataFrame]:
    """Backtest theme-level weights.

    Portfolio return at t uses weights from t-1. Costs are charged on daily
    absolute turnover in weights.
    """
    ret = theme_returns.reindex_like(weights_daily).fillna(0.0)
    w_lag = weights_daily.shift(1).fillna(0.0)
    gross_ret = (w_lag * ret).sum(axis=1)
    turnover = weights_daily.diff().abs().sum(axis=1).fillna(weights_daily.abs().sum(axis=1))
    cost = turnover * (cost_bps_per_turnover / 10000.0)
    net_ret = gross_ret - cost
    details = pd.DataFrame(
        {
            "gross_return": gross_ret,
            "turnover": turnover,
            "cost": cost,
            "net_return": net_ret,
            "gross_exposure": weights_daily.abs().sum(axis=1),
            "net_exposure": weights_daily.sum(axis=1),
        }
    )
    return net_ret, details


def performance_metrics(returns: pd.Series, annualization: int = 252) -> pd.Series:
    """Compute common backtest metrics."""
    r = returns.dropna().astype(float)
    if r.empty:
        return pd.Series(dtype=float)
    nav = (1.0 + r).cumprod()
    peak = nav.cummax()
    dd = nav / peak - 1.0
    vol = r.std(ddof=0) * math.sqrt(annualization)
    ann_ret = nav.iloc[-1] ** (annualization / max(1, len(r))) - 1.0
    sharpe = ann_ret / vol if vol > 0 else np.nan
    downside = r[r < 0].std(ddof=0) * math.sqrt(annualization)
    sortino = ann_ret / downside if downside > 0 else np.nan
    return pd.Series(
        {
            "ann_return": ann_ret,
            "ann_vol": vol,
            "sharpe": sharpe,
            "sortino": sortino,
            "max_drawdown": dd.min(),
            "calmar": ann_ret / abs(dd.min()) if dd.min() < 0 else np.nan,
            "hit_rate_daily": (r > 0).mean(),
            "avg_daily_return": r.mean(),
            "daily_vol": r.std(ddof=0),
            "skew": r.skew(),
            "kurtosis": r.kurtosis(),
            "n_obs": len(r),
            "final_nav": nav.iloc[-1],
        }
    )


# ---------------------------------------------------------------------------
# Main strategy class
# ---------------------------------------------------------------------------


class ThemeBasketStrategy:
    """End-to-end theme basket strategy engine."""

    def __init__(
        self,
        theme_data: pd.DataFrame,
        config: Optional[StrategyConfig] = None,
        factor_returns: Optional[pd.DataFrame] = None,
        constituents: Optional[pd.DataFrame] = None,
        stock_data: Optional[pd.DataFrame] = None,
        news_score: Optional[pd.DataFrame] = None,
        governance_score: Optional[pd.DataFrame] = None,
        leadlag_score: Optional[pd.DataFrame] = None,
        valuation_score: Optional[pd.DataFrame] = None,
        turnover_data: Optional[pd.DataFrame] = None,
    ) -> None:
        self.config = config or StrategyConfig()
        self.theme_raw = theme_data.copy().sort_index()
        self.factor_returns = factor_returns.copy().sort_index() if factor_returns is not None else None
        self.constituents = constituents
        self.stock_raw = stock_data.copy().sort_index() if stock_data is not None else None
        self.news_score = news_score
        self.governance_score = governance_score
        self.leadlag_score = leadlag_score
        self.valuation_score = valuation_score
        self.turnover_data = turnover_data

        self.results: Dict[str, Union[pd.DataFrame, pd.Series]] = {}

    def prepare_returns(self) -> Tuple[pd.DataFrame, Optional[pd.DataFrame]]:
        cfg = self.config
        theme_returns = prices_to_returns(self.theme_raw, cfg.theme_input_kind)
        # Drop columns with insufficient observations.
        valid_cols = theme_returns.columns[theme_returns.notna().sum() >= cfg.min_theme_obs]
        theme_returns = theme_returns[valid_cols]
        if cfg.fill_missing_returns:
            theme_returns = theme_returns.fillna(0.0)

        stock_returns = None
        if self.stock_raw is not None:
            stock_returns = prices_to_returns(self.stock_raw, cfg.stock_input_kind)
            if cfg.fill_missing_returns:
                stock_returns = stock_returns.fillna(0.0)

        self.results["theme_returns"] = theme_returns
        if stock_returns is not None:
            self.results["stock_returns"] = stock_returns
        return theme_returns, stock_returns

    def compute(self) -> Dict[str, Union[pd.DataFrame, pd.Series]]:
        cfg = self.config
        theme_returns, stock_returns = self.prepare_returns()

        idx = theme_returns.index
        cols = list(theme_returns.columns)

        factors = None
        if self.factor_returns is not None:
            factors = self.factor_returns.reindex(idx).astype(float)

        # Theme residual returns for momentum.
        if cfg.residualize_themes and factors is not None and not factors.empty:
            theme_resid = rolling_residualize(
                theme_returns,
                factors,
                window=cfg.rolling_beta_window,
                min_obs=cfg.rolling_beta_min_obs,
                ridge_lambda=cfg.ridge_lambda,
            )
        else:
            theme_resid = theme_returns.copy()
        self.results["theme_residual_returns"] = theme_resid

        # Momentum signal.
        mom = rolling_momentum(
            theme_resid,
            lookbacks=cfg.mom_lookbacks,
            weights=cfg.normalized_mom_weights(),
            skip=cfg.mom_skip,
            vol_floor=cfg.mom_vol_floor,
        )
        self.results["momentum_score"] = mom

        # Coherence gate/features.
        coherence_gate = pd.DataFrame(True, index=idx, columns=cols)
        coherence_score = pd.DataFrame(0.0, index=idx, columns=cols)
        apc_full = pd.DataFrame(np.nan, index=idx, columns=cols)
        eig_full = pd.DataFrame(np.nan, index=idx, columns=cols)
        eff_full = pd.DataFrame(np.nan, index=idx, columns=cols)

        if cfg.use_coherence_gate and self.constituents is not None and stock_returns is not None:
            stock_factors = self.factor_returns.reindex(stock_returns.index).astype(float) if self.factor_returns is not None else None
            if cfg.residualize_stocks and stock_factors is not None and not stock_factors.empty:
                stock_resid = rolling_residualize(
                    stock_returns,
                    stock_factors,
                    window=cfg.rolling_beta_window,
                    min_obs=cfg.rolling_beta_min_obs,
                    ridge_lambda=cfg.ridge_lambda,
                )
            else:
                stock_resid = stock_returns.copy()
            self.results["stock_residual_returns"] = stock_resid

            rebal_dates = make_rebalance_dates(idx, cfg.rebalance)
            apc, eig, eff, gate_rebal = compute_coherence_features(
                stock_resid,
                self.constituents,
                cols,
                rebal_dates,
                window=cfg.coherence_window,
                min_names=cfg.coherence_min_names,
                min_effective_names=cfg.coherence_min_effective_names,
            )
            apc_full = apc.reindex(idx).ffill()
            eig_full = eig.reindex(idx).ffill()
            eff_full = eff.reindex(idx).ffill()
            raw_coh = cfg.apc_weight * zscore_cross_sectional(apc_full) + cfg.eigenshare_weight * zscore_cross_sectional(eig_full)
            coherence_score = raw_coh.fillna(0.0)
            hard_gate = (apc_full > cfg.coherence_apc_threshold) & (eff_full >= cfg.coherence_min_effective_names)
            if cfg.coherence_score_threshold is not None:
                hard_gate &= coherence_score >= cfg.coherence_score_threshold
            coherence_gate = hard_gate.fillna(False)
        elif cfg.use_coherence_gate:
            # If data is unavailable, do not silently set all False. Use all True and record warning.
            self.results["warning_coherence"] = pd.Series(
                [
                    "Coherence gate requested but constituents and/or stock_data were not supplied. "
                    "Using all-True gate. Supply constituents_csv + stock_prices/returns_csv "
                    "to activate residual-correlation coherence gate."
                ]
            )

        self.results["coherence_apc"] = apc_full
        self.results["coherence_eigenshare"] = eig_full
        self.results["coherence_effective_n"] = eff_full
        self.results["coherence_score"] = coherence_score
        self.results["coherence_gate"] = coherence_gate

        # Optional overlays.
        news = align_feature_matrix(self.news_score, idx, cols, fill_value=0.0)
        gov = align_feature_matrix(self.governance_score, idx, cols, fill_value=0.0)
        leadlag = align_feature_matrix(self.leadlag_score, idx, cols, fill_value=0.0)
        valuation = align_feature_matrix(self.valuation_score, idx, cols, fill_value=0.0)

        # crowding: return acceleration + optional turnover; news overheat can be supplied via news_score if desired.
        crowd = return_acceleration_crowding(theme_returns)
        if self.turnover_data is not None:
            turn = align_feature_matrix(self.turnover_data, idx, cols, fill_value=np.nan)
            crowd = 0.5 * crowd + 0.5 * rolling_theme_turnover_crowding(turn)
            crowd = zscore_cross_sectional(crowd)
        crowd = crowd.fillna(0.0)

        self.results["news_score"] = news
        self.results["governance_score"] = gov
        self.results["leadlag_score"] = leadlag
        self.results["valuation_score"] = valuation
        self.results["crowding_score"] = crowd

        # Final score.
        score = cfg.w_momentum * mom.fillna(0.0)
        if cfg.use_news:
            score = score + cfg.w_news * zscore_cross_sectional(news).fillna(0.0)
        if cfg.use_governance:
            score = score + cfg.w_governance * zscore_cross_sectional(gov).fillna(0.0)
        if cfg.use_leadlag:
            score = score + cfg.w_leadlag * zscore_cross_sectional(leadlag).fillna(0.0)
        if cfg.use_valuation:
            score = score + cfg.w_valuation * zscore_cross_sectional(valuation).fillna(0.0)
        if cfg.use_crowding:
            # Penalize crowded names; stronger penalty if short-term return is already negative.
            short_ret = theme_returns.rolling(10, min_periods=5).sum()
            break_mask = (short_ret < 0).astype(float)
            score = score - cfg.w_crowding_penalty * crowd * (0.5 + 0.5 * break_mask)

        # Apply coherence gate by setting non-gated scores to NaN before selection.
        score_gated = score.where(coherence_gate)
        self.results["final_score"] = score
        self.results["final_score_gated"] = score_gated

        # Rebalance weights.
        rebal_dates = make_rebalance_dates(idx, cfg.rebalance)
        scores_rebal = score_gated.reindex(rebal_dates)
        gates_rebal = coherence_gate.reindex(rebal_dates).fillna(False)
        w_rebal = construct_theme_weights(scores_rebal, cfg, gates=gates_rebal)
        w_daily = expand_rebalance_weights(w_rebal, idx)
        self.results["theme_weights_rebalance"] = w_rebal
        self.results["theme_weights_daily"] = w_daily

        # Backtest using raw theme returns, not residual returns.
        strat_ret, details = backtest_theme_weights(theme_returns, w_daily, cfg.cost_bps_per_turnover)
        metrics = performance_metrics(strat_ret, cfg.annualization)
        self.results["strategy_returns"] = strat_ret
        self.results["backtest_details"] = details
        self.results["metrics"] = metrics

        return self.results

    def save_results(self, output_dir: str) -> None:
        os.makedirs(output_dir, exist_ok=True)
        for name, obj in self.results.items():
            path = os.path.join(output_dir, f"{name}.csv")
            if isinstance(obj, pd.DataFrame):
                obj.to_csv(path, index=True)
            elif isinstance(obj, pd.Series):
                obj.to_csv(path, header=True)
        with open(os.path.join(output_dir, "config.json"), "w", encoding="utf-8") as f:
            json.dump(asdict(self.config), f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Theme basket strategy backtest")
    p.add_argument("--theme_csv", required=True, help="Theme basket price/return CSV")
    p.add_argument("--factor_csv", default=None, help="Optional factor return CSV")
    p.add_argument("--constituents_csv", default=None, help="Optional PIT constituents CSV")
    p.add_argument("--stock_csv", default=None, help="Optional stock price/return CSV")
    p.add_argument("--news_csv", default=None, help="Optional theme-level news score CSV")
    p.add_argument("--governance_csv", default=None, help="Optional theme-level governance score CSV")
    p.add_argument("--leadlag_csv", default=None, help="Optional theme-level lead-lag score CSV")
    p.add_argument("--valuation_csv", default=None, help="Optional theme-level valuation score CSV")
    p.add_argument("--turnover_csv", default=None, help="Optional theme-level turnover/volume CSV")
    p.add_argument("--output_dir", default="theme_strategy_output", help="Output directory")
    p.add_argument("--theme_input_kind", default="auto", choices=["auto", "price", "return"])
    p.add_argument("--stock_input_kind", default="auto", choices=["auto", "price", "return"])
    p.add_argument("--mode", default="long_only", choices=["long_only", "long_short"])
    p.add_argument("--rebalance", default="ME", help="Pandas offset alias, e.g. ME/M, W-FRI, 2W-FRI")
    p.add_argument("--top_n", type=int, default=None)
    p.add_argument("--bottom_n", type=int, default=None)
    p.add_argument("--long_quantile", type=float, default=0.20)
    p.add_argument("--short_quantile", type=float, default=0.20)
    p.add_argument("--max_theme_weight", type=float, default=0.15)
    p.add_argument("--cost_bps", type=float, default=5.0)
    p.add_argument("--no_residualize_themes", action="store_true", help="Use raw theme returns for momentum even if factors are supplied")
    p.add_argument("--no_residualize_stocks", action="store_true", help="Use raw/precomputed stock returns for coherence even if factors are supplied")
    p.add_argument("--disable_coherence_gate", action="store_true")
    p.add_argument("--disable_news", action="store_true")
    p.add_argument("--disable_governance", action="store_true")
    p.add_argument("--enable_leadlag", action="store_true")
    p.add_argument("--enable_valuation", action="store_true")
    p.add_argument("--disable_crowding", action="store_true")
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> None:
    args = parse_args(argv)

    cfg = StrategyConfig(
        theme_input_kind=args.theme_input_kind,
        stock_input_kind=args.stock_input_kind,
        mode=args.mode,
        rebalance=args.rebalance,
        top_n=args.top_n,
        bottom_n=args.bottom_n,
        long_quantile=args.long_quantile,
        short_quantile=args.short_quantile,
        max_theme_weight=args.max_theme_weight,
        cost_bps_per_turnover=args.cost_bps,
        residualize_themes=not args.no_residualize_themes,
        residualize_stocks=not args.no_residualize_stocks,
        use_coherence_gate=not args.disable_coherence_gate,
        use_news=not args.disable_news,
        use_governance=not args.disable_governance,
        use_leadlag=args.enable_leadlag,
        use_valuation=args.enable_valuation,
        use_crowding=not args.disable_crowding,
    )

    theme = read_matrix_csv(args.theme_csv)
    factors = read_matrix_csv(args.factor_csv) if args.factor_csv else None
    constituents = read_constituents_csv(args.constituents_csv) if args.constituents_csv else None
    stock = read_matrix_csv(args.stock_csv) if args.stock_csv else None
    news = read_matrix_csv(args.news_csv) if args.news_csv else None
    governance = read_matrix_csv(args.governance_csv) if args.governance_csv else None
    leadlag = read_matrix_csv(args.leadlag_csv) if args.leadlag_csv else None
    valuation = read_matrix_csv(args.valuation_csv) if args.valuation_csv else None
    turnover = read_matrix_csv(args.turnover_csv) if args.turnover_csv else None

    strat = ThemeBasketStrategy(
        theme,
        config=cfg,
        factor_returns=factors,
        constituents=constituents,
        stock_data=stock,
        news_score=news,
        governance_score=governance,
        leadlag_score=leadlag,
        valuation_score=valuation,
        turnover_data=turnover,
    )
    res = strat.compute()
    strat.save_results(args.output_dir)

    print("Saved outputs to", args.output_dir)
    print("\nMetrics:")
    print(res["metrics"].to_string())
    if "warning_coherence" in res:
        print("\nWarning:")
        print(res["warning_coherence"].iloc[0])


if __name__ == "__main__":
    main()
