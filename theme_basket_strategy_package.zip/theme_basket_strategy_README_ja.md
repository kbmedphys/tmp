# 日本株テーマバスケット戦略 Python 実装 README

## 1. ファイル

- `theme_basket_strategy.py`  
  Coherence-Gated Narrative Momentum with Governance/PBR Catalyst Overlay の実装。

## 2. 最小実行

テーマバスケット価格CSVだけで、月次リバランスのテーマ・モメンタム戦略を実行できます。

```bash
python theme_basket_strategy.py \
  --theme_csv theme_prices.csv \
  --theme_input_kind price \
  --mode long_only \
  --top_n 5 \
  --output_dir output_mvp \
  --disable_coherence_gate \
  --disable_news \
  --disable_governance
```

ロング・ショート版：

```bash
python theme_basket_strategy.py \
  --theme_csv theme_prices.csv \
  --theme_input_kind price \
  --mode long_short \
  --top_n 5 \
  --bottom_n 5 \
  --output_dir output_ls \
  --disable_coherence_gate \
  --disable_news \
  --disable_governance
```

## 3. テーマ価格CSVスキーマ

ワイド形式：

```text
date,AI,Semiconductor,Defense,LowPBR,Governance
2021-01-04,100.0,100.0,100.0,100.0,100.0
2021-01-05,101.2,99.8,100.5,100.3,100.1
```

またはロング形式：

```text
date,theme,price
2021-01-04,AI,100.0
2021-01-04,Semiconductor,100.0
```

リターンCSVの場合は `--theme_input_kind return` を指定してください。

## 4. 推奨実行：ファクター調整付き

テーマの生リターンではなく、TOPIX・スタイル・業種等で残差化したテーマ・モメンタムを使います。

```bash
python theme_basket_strategy.py \
  --theme_csv theme_prices.csv \
  --factor_csv factor_returns.csv \
  --theme_input_kind price \
  --mode long_only \
  --top_n 5 \
  --output_dir output_factor_adjusted \
  --disable_coherence_gate
```

`factor_returns.csv` 例：

```text
date,TOPIX,Size,Value,Momentum,Quality,USDJPY,Rate10Y,SOX
2021-01-04,0.003,0.001,-0.002,0.000,0.001,0.002,0.0001,0.010
```

## 5. 完全版：coherence gate 有効化

テーマ内の構成銘柄が本当に共通残差リスクを持つかを判定するには、以下が必要です。

```bash
python theme_basket_strategy.py \
  --theme_csv theme_prices.csv \
  --factor_csv factor_returns.csv \
  --constituents_csv constituents.csv \
  --stock_csv stock_prices.csv \
  --theme_input_kind price \
  --stock_input_kind price \
  --mode long_only \
  --top_n 5 \
  --output_dir output_full
```

`constituents.csv` 例：

```text
date,theme,ticker,weight,purity,liquidity_adj
2023-01-31,AI,6758.T,0.08,0.75,1.00
2023-01-31,AI,6501.T,0.07,0.60,1.00
2023-01-31,Semiconductor,8035.T,0.12,0.95,1.00
```

必須列：

- `theme`
- `ticker` または `ric` または `symbol`
- `weight`

任意列：

- `date`: point-in-time の構成有効日。ない場合は静的構成として扱います。
- `purity`: テーマ純度。会社概要文・TRBC・ニュース関連度などから別途作成。
- `liquidity_adj`: 流動性調整係数。

`stock_prices.csv` 例：

```text
date,6758.T,6501.T,8035.T,6857.T
2021-01-04,1000,4200,38000,6500
```


大量の個別株で rolling OLS が重い場合は、個別株の残差リターンを外部で前計算して `--stock_input_kind return --no_residualize_stocks` として渡してください。

```bash
python theme_basket_strategy.py \
  --theme_csv theme_prices.csv \
  --factor_csv factor_returns.csv \
  --constituents_csv constituents.csv \
  --stock_csv stock_residual_returns.csv \
  --stock_input_kind return \
  --no_residualize_stocks \
  --output_dir output_full_fast
```

## 6. ニュース・ガバナンス特徴量

Reuters / LSEG ニュースはAPI制約があるため、本実装では raw news API 呼び出しではなく、事前に作ったテーマ別スコアをCSVで受け取ります。

```bash
python theme_basket_strategy.py \
  --theme_csv theme_prices.csv \
  --factor_csv factor_returns.csv \
  --news_csv news_score.csv \
  --governance_csv governance_score.csv \
  --turnover_csv theme_turnover.csv \
  --output_dir output_overlay
```

`news_score.csv` 例：

```text
date,AI,Semiconductor,Defense,LowPBR
2024-01-31,1.25,0.80,0.40,-0.10
```

ニューススコアの推奨構成：

```text
news_score = z(news_count_surprise)
           + z(news_breadth)
           + z(sentiment)
           + z(event_quality)
           - z(repetition)
```

`governance_score.csv` 例：

```text
date,LowPBR,Governance,HighDividend,ListSubsidiary,Megabank
2024-01-31,1.10,0.95,0.60,0.75,0.55
```

ガバナンス/PBRスコアの推奨構成：

```text
governance_score = cheapness
                 + efficiency_gap
                 + balance_sheet_optionality
                 + governance_action
                 + shareholder_return
                 + event_optionality
                 - value_trap_risk
```

## 7. 出力ファイル

`output_dir` に以下が保存されます。

- `theme_returns.csv`
- `theme_residual_returns.csv`
- `momentum_score.csv`
- `coherence_apc.csv`
- `coherence_eigenshare.csv`
- `coherence_effective_n.csv`
- `coherence_gate.csv`
- `news_score.csv`
- `governance_score.csv`
- `crowding_score.csv`
- `final_score.csv`
- `final_score_gated.csv`
- `theme_weights_rebalance.csv`
- `theme_weights_daily.csv`
- `strategy_returns.csv`
- `backtest_details.csv`
- `metrics.csv`
- `config.json`

## 8. Python API 使用例

```python
import pandas as pd
from theme_basket_strategy import (
    StrategyConfig,
    ThemeBasketStrategy,
    read_matrix_csv,
    read_constituents_csv,
)

cfg = StrategyConfig(
    theme_input_kind="price",
    stock_input_kind="price",
    mode="long_only",
    rebalance="ME",
    top_n=5,
    max_theme_weight=0.15,
    cost_bps_per_turnover=5.0,
)

theme = read_matrix_csv("theme_prices.csv")
factors = read_matrix_csv("factor_returns.csv")
constituents = read_constituents_csv("constituents.csv")
stock = read_matrix_csv("stock_prices.csv")
news = read_matrix_csv("news_score.csv")
governance = read_matrix_csv("governance_score.csv")

strategy = ThemeBasketStrategy(
    theme_data=theme,
    config=cfg,
    factor_returns=factors,
    constituents=constituents,
    stock_data=stock,
    news_score=news,
    governance_score=governance,
)

results = strategy.compute()
strategy.save_results("output_full")
print(results["metrics"])
```

## 9. 追加で必要なデータ

テーマ価格CSVだけでMVPは動きますが、提案戦略の本質である coherence gate とニュース/ガバナンス overlay には以下が必要です。

| 優先度 | データ | 用途 |
|---:|---|---|
| 必須 | テーマバスケット価格/リターン | MVP、テーマモメンタム |
| 強く推奨 | ファクターリターン | TOPIX・業種・スタイル控除後の残差モメンタム |
| 強く推奨 | テーマ構成銘柄・ウェイト・有効日 | coherence gate、銘柄重複管理 |
| 強く推奨 | 構成銘柄の日次価格/リターン | テーマ内平均ペアワイズ残差相関 |
| 推奨 | 会社概要文・TRBC/業種コード | semantic purity 作成 |
| 推奨 | Reuters ニュース特徴量 | narrative confirmation |
| 推奨 | TSE対応状況・自社株買い・増配等 | PBR/Governance overlay |
| 推奨 | 出来高・売買代金・回転率 | crowding control、容量/コスト推定 |
| 推奨 | セキュリティマスター | Bloomberg ticker、RIC、TSE code、ISIN の紐付け |

