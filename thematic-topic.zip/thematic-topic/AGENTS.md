# Project Rules: thematic-topic

このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。
このプロジェクトの Prefer explicit python path は 
- envs/nlp/.venv/bin/python

---
# 最優先
このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。

このプロジェクトで使う Python は明示パスで統一すること。
- envs/nlp/.venv/bin/python
