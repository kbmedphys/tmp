# thematic-topic

LSEG Reuters日本語ヘッドラインを対象に、BERTopicとテーマバスケット市場反応を結合したメガトレンド抽出基盤です。

- Python実行パス: `envs/nlp/.venv/bin/python`
- メイン設定: `config/default.yaml`
- ライブラリ: `src/thematic_topic`
- Notebook: `notebooks/main.ipynb`

## Theme Definitions Input

`theme_definitions_path` は `.parquet` / `.csv` に加えて `.yaml` / `.yml` を受け入れます。
YAML は以下の形を前提にします。

```yaml
themes:
  - theme_id: semiconductor_equipment_jp
    theme_name_ja: 半導体製造装置
    theme_name_en: Japanese Semiconductor Equipment
    description_ja: 半導体製造装置テーマ
    description_en: Semiconductor equipment theme
    revenue_drivers_ja: [半導体設備投資サイクル]
    positive_events_ja: [受注増加]
    negative_events_ja: [受注減少]
    keyword_match_terms_ja: [半導体設備投資]
    catalysts_ja: [半導体製造装置]
    related_industries:
      gics_industries: [Semiconductors & Semiconductor Equipment]
      trbc_industries: [Semiconductor Equipment]
    entity_linking_terms:
      company_names_ja: [東京エレクトロン, アドバンテスト]
```

`config/default.yaml` の `paths.theme_definitions_path` を YAML ファイルに向ければ利用できます。

```yaml
paths:
  theme_definitions_path: "/absolute/or/relative/path/theme_profiles.yaml"
```

注意:
- YAML 構文エラーがある場合は停止します（自動補正しません）。
- `*_ja` を優先し、欠損時のみ `*_en` を補完利用します。
