import sys
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from thematic_topic.intensity import build_topic_intensity


class IntensityTest(unittest.TestCase):
    def test_daily_weekly_metrics_exist(self):
        df = pd.DataFrame(
            {
                "news_id": [f"n{i}" for i in range(12)],
                "timestamp": pd.date_range("2024-01-01", periods=12, freq="D", tz="UTC"),
                "topic_id": [0] * 10 + [-1, 1],
                "topic_probability": [0.2, 0.3, 0.4, 0.6, 0.8, 0.7, 0.5, 0.4, 0.3, 0.2, 0.9, 0.5],
            }
        )

        daily, weekly, outlier = build_topic_intensity(df, ewma_span=3, lookback=5)

        for col in ["topic_ewma", "topic_z", "topic_delta", "topic_accel", "topic_persistence"]:
            self.assertIn(col, daily.columns)
            self.assertIn(col, weekly.columns)

        self.assertIn("outlier_ratio", outlier.columns)


if __name__ == "__main__":
    unittest.main()
