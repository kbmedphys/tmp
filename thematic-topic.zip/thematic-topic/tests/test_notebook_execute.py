import subprocess
import sys
import unittest
from pathlib import Path


class NotebookExecuteTest(unittest.TestCase):
    def test_notebook_executes(self):
        root = Path(__file__).resolve().parents[1]
        notebook = root / "notebooks" / "main.ipynb"
        out_name = "main.executed.ipynb"

        cmd = [
            "/Users/kencharoff/workspace/envs/nlp/.venv/bin/python",
            "-m",
            "jupyter",
            "nbconvert",
            "--to",
            "notebook",
            "--execute",
            str(notebook),
            "--output",
            out_name,
            "--output-dir",
            str(notebook.parent),
        ]

        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            error_text = f"{proc.stderr}\n{proc.stdout}"
            if "Operation not permitted" in error_text:
                self.skipTest("sandbox環境ではjupyter kernel用ポート確保が禁止されるためskip")
            self.fail(f"Notebook execution failed: {error_text}")

        self.assertTrue((notebook.parent / out_name).exists())


if __name__ == "__main__":
    unittest.main()
