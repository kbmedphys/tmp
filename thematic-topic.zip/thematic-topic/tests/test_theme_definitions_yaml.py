import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from thematic_topic.data_io import THEME_REQUIRED_COLUMNS, load_theme_definitions


class ThemeDefinitionsYamlTest(unittest.TestCase):
    def test_yaml_mixed_driver_and_ja_fallback(self):
        yaml_text = """
themes:
  - theme_id: t1
    theme_name_ja: テーマ1
    theme_name_en: Theme1 EN
    description_ja: 説明1
    description_en: Description1
    revenue_drivers_ja: [需要増, 設備投資]
    positive_events_ja: [受注増]
    negative_events_ja: [受注減]
    keyword_match_terms_ja: [半導体設備投資]
    catalysts_ja: [半導体製造装置]
    related_industries:
      gics_industries: [Semiconductors]
      trbc_industries: [Semiconductor Equipment]
    entity_linking_terms:
      company_names_ja: [東京エレクトロン]
    profile_summary_ja: 概要1

  - theme_id: t2
    theme_name_en: Theme2 EN
    description_en: Description2 EN
    revenue_drivers:
      - driver_name_ja: 資本効率改革
        negative_driver_events_ja: [ガバナンス不祥事, 資本政策後退]
    positive_events_ja: [増配]
    negative_events_ja: [減配]
    keyword_match_terms_ja: [PBR1倍割れ]
    catalysts_ja: [資本効率]
    related_industries:
      gics_industries: []
      trbc_industries: []
    entity_linking_terms:
      company_names_ja: [企業A]
    notes_for_classification: 補足2
"""

        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "theme_profiles.yaml"
            p.write_text(yaml_text, encoding="utf-8")
            df = load_theme_definitions(p)

        self.assertTrue(set(THEME_REQUIRED_COLUMNS).issubset(df.columns))
        self.assertEqual(len(df), 2)

        r1 = df[df["theme_id"] == "t1"].iloc[0]
        self.assertEqual(r1["theme_name"], "テーマ1")
        self.assertIn("需要増", r1["positive_drivers"])
        self.assertIn("受注増", r1["positive_drivers"])
        self.assertIn("半導体製造装置", r1["related_keywords"])

        r2 = df[df["theme_id"] == "t2"].iloc[0]
        self.assertEqual(r2["theme_name"], "Theme2 EN")
        self.assertEqual(r2["theme_description"], "Description2 EN")
        self.assertIn("減配", r2["negative_drivers"])
        self.assertIn("ガバナンス不祥事", r2["negative_drivers"])
        self.assertEqual(r2["constituent_descriptions"], "補足2")

    def test_yaml_syntax_error_raises_value_error(self):
        bad_yaml = """
themes:
  - theme_id: t1
    theme_name_ja: テーマ1
    catalysts_ja
      - 半導体
"""
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "bad.yaml"
            p.write_text(bad_yaml, encoding="utf-8")
            with self.assertRaises(ValueError):
                load_theme_definitions(p)

    def test_csv_parquet_backward_compatible(self):
        base = {
            "theme_id": ["t1"],
            "theme_name": ["Theme 1"],
            "theme_description": ["Desc"],
            "positive_drivers": ["A"],
            "negative_drivers": ["B"],
            "related_keywords": ["C"],
            "excluded_keywords": [""],
            "constituent_names": ["Corp"],
            "constituent_descriptions": ["Desc2"],
            "gics_industries": ["Ind1"],
            "trbc_industries": ["Ind2"],
        }
        frame = pd.DataFrame(base)

        with tempfile.TemporaryDirectory() as td:
            td_path = Path(td)
            csv_path = td_path / "theme_definitions.csv"
            pq_path = td_path / "theme_definitions.parquet"
            frame.to_csv(csv_path, index=False)
            frame.to_parquet(pq_path, index=False)

            loaded_csv = load_theme_definitions(csv_path)
            loaded_pq = load_theme_definitions(pq_path)

        self.assertEqual(loaded_csv.shape, frame.shape)
        self.assertEqual(loaded_pq.shape, frame.shape)
        self.assertEqual(loaded_csv.iloc[0]["theme_name"], "Theme 1")
        self.assertEqual(loaded_pq.iloc[0]["theme_name"], "Theme 1")


if __name__ == "__main__":
    unittest.main()
