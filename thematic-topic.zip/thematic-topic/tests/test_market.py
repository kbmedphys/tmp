import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from thematic_topic.market import _forward_cum_return, build_market_targets


class MarketTest(unittest.TestCase):
    def test_forward_return_no_lookahead(self):
        arr = np.array([0.1, 0.1, 0.1], dtype=float)
        fwd = _forward_cum_return(arr, horizon=2)
        self.assertAlmostEqual(fwd[0], 0.21, places=8)
        self.assertTrue(np.isnan(fwd[1]))
        self.assertTrue(np.isnan(fwd[2]))

    def test_build_market_targets(self):
        dates = pd.date_range("2024-01-01", periods=8, freq="D")
        df = pd.DataFrame(
            {
                "date": list(dates) * 2,
                "theme_id": ["T1"] * 8 + ["T2"] * 8,
                "theme_return": [0.01] * 8 + [0.005] * 8,
                "theme_turnover": [10, 11, 12, 13, 12, 11, 10, 9] + [8, 8, 9, 9, 10, 10, 9, 8],
            }
        )
        out = build_market_targets(df, horizon=5)
        self.assertIn("y_attention", out.columns)
        self.assertIn("y_return", out.columns)
        self.assertTrue(out["forward_return"].isna().tail(5).all())


if __name__ == "__main__":
    unittest.main()
