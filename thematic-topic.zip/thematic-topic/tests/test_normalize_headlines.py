import sys
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from thematic_topic.headlines import normalize_headlines_df


class NormalizeHeadlinesTest(unittest.TestCase):
    def test_version_created_index_priority(self):
        idx = pd.date_range("2024-01-01", periods=2, freq="h", tz="UTC")
        raw = pd.DataFrame(
            {
                "headline": ["A", "B"],
                "storyId": ["s1", "s2"],
                "sourceCode": ["RTRS", "RTRS"],
            },
            index=idx,
        )
        raw.index.name = "versionCreated"

        out = normalize_headlines_df(raw, query="Q")

        self.assertEqual(
            out.columns.tolist(),
            [
                "news_id",
                "story_id",
                "timestamp",
                "headline",
                "story_text",
                "source",
                "query",
                "request_start",
                "request_end",
                "retrieved_at_utc",
            ],
        )
        self.assertEqual(len(out), 2)
        self.assertTrue(out["timestamp"].notna().all())
        self.assertEqual(out["query"].iloc[0], "Q")
        self.assertTrue((out["story_text"] == "").all())


if __name__ == "__main__":
    unittest.main()
