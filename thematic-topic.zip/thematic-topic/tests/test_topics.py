import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from thematic_topic.config import TopicModelSettings
from thematic_topic.topics import fit_topic_model, transform_topics


class _DummyTopicModel:
    def __init__(self):
        self.fit_docs: list[str] = []
        self.transform_docs: list[str] = []

    def fit_transform(self, docs, embeddings=None):
        self.fit_docs = list(docs)
        return [0] * len(docs), np.full(len(docs), 0.5, dtype=float)

    def transform(self, docs, embeddings=None):
        self.transform_docs = list(docs)
        return [0] * len(docs), np.full(len(docs), 0.4, dtype=float)

    def get_topic(self, topic_id):
        return [("topic", 1.0)]


class TopicsTextColTest(unittest.TestCase):
    def _sample_df(self) -> pd.DataFrame:
        return pd.DataFrame(
            {
                "news_id": ["n1", "n2"],
                "timestamp": pd.to_datetime(["2024-01-01T00:00:00Z", "2024-01-01T01:00:00Z"], utc=True),
                "headline_clean": ["見出しA", "見出しB"],
                "model_input_text": ["見出しA 本文A", "見出しB 本文B"],
            }
        )

    def test_fit_topic_model_uses_text_col(self):
        df = self._sample_df()
        emb = np.array([[1.0, 0.0], [0.0, 1.0]], dtype=float)
        settings = TopicModelSettings(top_n_words=3, top_n_headlines=2)
        dummy_model = _DummyTopicModel()

        with patch("thematic_topic.topics._build_topic_model", return_value=dummy_model):
            _, tables = fit_topic_model(df, emb, settings, text_col="model_input_text")

        self.assertEqual(dummy_model.fit_docs, df["model_input_text"].tolist())
        self.assertIn("topic_summary", tables)
        self.assertFalse(tables["topic_summary"].empty)

    def test_transform_topics_uses_text_col(self):
        df = self._sample_df()
        emb = np.array([[1.0, 0.0], [0.0, 1.0]], dtype=float)
        dummy_model = _DummyTopicModel()

        out = transform_topics(df, dummy_model, emb, text_col="model_input_text")
        self.assertEqual(dummy_model.transform_docs, df["model_input_text"].tolist())
        self.assertIn("topic_probability", out.columns)

    def test_missing_text_col_raises(self):
        df = self._sample_df().drop(columns=["model_input_text"])
        emb = np.array([[1.0, 0.0], [0.0, 1.0]], dtype=float)
        settings = TopicModelSettings()

        with self.assertRaises(ValueError):
            fit_topic_model(df, emb, settings, text_col="model_input_text")

        with self.assertRaises(ValueError):
            transform_topics(df, object(), emb, text_col="model_input_text")


if __name__ == "__main__":
    unittest.main()
