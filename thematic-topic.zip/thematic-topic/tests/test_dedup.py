import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from thematic_topic.dedup import deduplicate_headlines


class DedupTest(unittest.TestCase):
    def test_rule_and_embedding_dedup(self):
        df = pd.DataFrame(
            {
                "news_id": ["n1", "n2", "n3", "n4"],
                "story_id": ["s1", "s1", "s2", "s3"],
                "headline_clean": ["A", "B", "C", "C2"],
                "timestamp": pd.to_datetime(
                    [
                        "2024-01-01T00:00:00Z",
                        "2024-01-01T01:00:00Z",
                        "2024-01-01T02:00:00Z",
                        "2024-01-01T03:00:00Z",
                    ]
                ),
            }
        )
        emb = np.array(
            [
                [1.0, 0.0],
                [1.0, 0.0],
                [0.0, 1.0],
                [0.1, 0.99],
            ],
            dtype=float,
        )
        emb = emb / np.linalg.norm(emb, axis=1, keepdims=True)

        dedup_df, dedup_log = deduplicate_headlines(df, emb, similarity_threshold=0.92, window_hours=24)

        self.assertEqual(len(dedup_df), 2)
        self.assertSetEqual(set(dedup_df["news_id"].tolist()), {"n1", "n3"})
        self.assertEqual(len(dedup_log), 2)


if __name__ == "__main__":
    unittest.main()
