import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from thematic_topic.supervised import fit_supervised_models
from thematic_topic.trends import build_trends_alerts_rankings


class SupervisedTrendTest(unittest.TestCase):
    def test_supervised_and_trend_outputs(self):
        dates = pd.date_range("2024-01-01", periods=80, freq="D")

        rows = []
        target_rows = []
        for d_i, d in enumerate(dates):
            x1 = np.sin(d_i / 10.0)
            x2 = np.cos(d_i / 8.0)
            rows.append({"date": d, "theme_id": "T1", "topic_id": 0, "theme_topic_exposure": x1})
            rows.append({"date": d, "theme_id": "T1", "topic_id": 1, "theme_topic_exposure": x2})
            rows.append({"date": d, "theme_id": "T2", "topic_id": 0, "theme_topic_exposure": 0.1})
            y_att = 2.0 * x1 - 1.0 * x2
            y_ret = 0.3 * x1 + 0.2 * x2
            target_rows.append({"date": d, "theme_id": "T1", "y_attention": y_att, "y_return": y_ret})
            target_rows.append({"date": d, "theme_id": "T2", "y_attention": 0.1, "y_return": 0.0})

        exposure = pd.DataFrame(rows)
        targets = pd.DataFrame(target_rows)

        beta_df, pred_df = fit_supervised_models(
            exposure,
            targets,
            model_type="ridge",
            min_obs_per_theme=60,
            time_series_splits=4,
        )

        self.assertTrue((beta_df["scaler"] == "StandardScaler").any())
        self.assertTrue((beta_df["cv"] == "TimeSeriesSplit").any())
        self.assertFalse(pred_df.empty)

        topic_summary = pd.DataFrame(
            {
                "topic_id": [0, 1],
                "top_words": [["AI"], ["Bank"]],
                "representative_headlines": [["A"], ["B"]],
                "topic_summary_text": ["AI A", "Bank B"],
            }
        )
        topic_theme_map = pd.DataFrame(
            {
                "topic_id": [0, 1],
                "theme_id": ["T1", "T1"],
                "topic_theme_similarity": [0.8, 0.7],
                "rank_in_topic": [1, 1],
            }
        )
        theme_profile = pd.DataFrame({"theme_id": ["T1", "T2"], "theme_name": ["AI", "Other"]})

        trend_df, alert_df, ranking_df, explanation_df = build_trends_alerts_rankings(
            exposure,
            beta_df,
            topic_summary,
            topic_theme_map,
            theme_profile,
            trend_ewma_span=3,
            trend_lookback=20,
        )

        self.assertFalse(trend_df.empty)
        self.assertFalse(alert_df.empty)
        self.assertFalse(ranking_df.empty)
        self.assertFalse(explanation_df.empty)


if __name__ == "__main__":
    unittest.main()
