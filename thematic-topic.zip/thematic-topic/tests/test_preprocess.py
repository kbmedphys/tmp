import sys
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from thematic_topic.preprocess import clean_headlines


class PreprocessTest(unittest.TestCase):
    def test_prefix_and_low_information_modes(self):
        df = pd.DataFrame(
            {
                "headline": [
                    "UPDATE 1- 企業決算が改善 https://example.com",
                    "東証前引け",
                    "再送- 半導体需要が拡大",
                ],
                "story_text": [
                    "URL付き本文 https://example.com/a",
                    "市況本文",
                    "本文3",
                ],
            }
        )

        dropped = clean_headlines(df, mode="drop", min_chars=3)
        flagged = clean_headlines(df, mode="flag", min_chars=3)

        self.assertTrue(all("UPDATE" not in x for x in dropped["headline_clean"]))
        self.assertEqual(len(dropped), 2)
        self.assertEqual(len(flagged), 3)
        self.assertTrue(flagged["low_information_flag"].any())
        self.assertIn("story_text_clean", dropped.columns)
        self.assertIn("model_input_text", dropped.columns)
        self.assertEqual(dropped.loc[0, "model_input_text"], "企業決算が改善 URL付き本文")

    def test_story_text_optional(self):
        df = pd.DataFrame({"headline": ["再送- テスト見出し"]})
        out = clean_headlines(df, mode="flag", min_chars=1)
        self.assertEqual(out.loc[0, "headline_clean"], "テスト見出し")
        self.assertEqual(out.loc[0, "story_text_clean"], "")
        self.assertEqual(out.loc[0, "model_input_text"], "テスト見出し")


if __name__ == "__main__":
    unittest.main()
