import importlib.util
import sys
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from thematic_topic.topic_reports import build_topic_top_headline_table, make_topic_wordclouds


class TopicTopHeadlineTableTest(unittest.TestCase):
    def test_pick_max_probability_with_stable_tiebreak(self):
        df = pd.DataFrame(
            {
                "topic_id": [0, 0, 1, 1, -1],
                "topic_probability": [0.7, 0.7, 0.5, 0.6, 0.99],
                "headline_clean": ["A", "B", "C", "D", "OUT"],
                "timestamp": pd.to_datetime(
                    [
                        "2024-01-02T00:00:00Z",
                        "2024-01-01T00:00:00Z",
                        "2024-01-01T00:00:00Z",
                        "2024-01-01T00:00:00Z",
                        "2024-01-01T00:00:00Z",
                    ],
                    utc=True,
                ),
                "news_id": ["n2", "n1", "n3", "n4", "n5"],
            }
        )

        out = build_topic_top_headline_table(df, exclude_outlier=True)
        self.assertEqual(out.columns.tolist(), ["topic_id", "composition_ratio", "headline"])
        self.assertEqual(out["topic_id"].tolist(), [0, 1])
        self.assertEqual(out["headline"].tolist(), ["B", "D"])
        self.assertAlmostEqual(float(out.loc[out["topic_id"] == 0, "composition_ratio"].iloc[0]), 0.7)

    def test_headline_fallback_column(self):
        df = pd.DataFrame(
            {
                "topic_id": [1],
                "topic_probability": [0.8],
                "headline": ["fallback headline"],
            }
        )
        out = build_topic_top_headline_table(df, exclude_outlier=True)
        self.assertEqual(out.iloc[0]["headline"], "fallback headline")


@unittest.skipUnless(importlib.util.find_spec("wordcloud") is not None, "wordcloud is not installed")
class TopicWordCloudTest(unittest.TestCase):
    def _font_candidate(self) -> str:
        candidates = [
            "/Library/Fonts/Arial Unicode.ttf",
            "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        ]
        for c in candidates:
            if Path(c).exists():
                return c
        self.skipTest("日本語フォントが見つからないためskip")

    def test_make_topic_wordclouds_with_scores(self):
        topic_summary = pd.DataFrame(
            {
                "topic_id": [0, 1],
                "top_words": [["半導体", "AI"], ["銀行", "金利"]],
                "top_word_scores": [[0.9, 0.4], [0.8, 0.3]],
                "topic_count": [20, 10],
            }
        )
        wc_map = make_topic_wordclouds(topic_summary, font_path=self._font_candidate())
        self.assertSetEqual(set(wc_map.keys()), {0, 1})
        self.assertTrue(hasattr(wc_map[0], "words_"))

    def test_make_topic_wordclouds_without_scores(self):
        topic_summary = pd.DataFrame(
            {
                "topic_id": [2],
                "top_words": [["再エネ", "電力", "蓄電池"]],
            }
        )
        wc_map = make_topic_wordclouds(topic_summary, font_path=self._font_candidate())
        self.assertIn(2, wc_map)
        self.assertTrue(hasattr(wc_map[2], "words_"))

    def test_font_not_found_raises(self):
        topic_summary = pd.DataFrame(
            {"topic_id": [0], "top_words": [["半導体"]], "top_word_scores": [[1.0]]}
        )
        with self.assertRaises(ValueError):
            make_topic_wordclouds(topic_summary, font_path="/path/does/not/exist.ttf")


if __name__ == "__main__":
    unittest.main()
