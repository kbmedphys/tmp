# APC Strategy Variants 実装 README

この追加実装は、Level 3: Coherence-gated の結果 `results_l3` を使い、以下の3戦略を実行します。

## 実装戦略

| 戦略名 | スコア | 投資対象 |
|---|---|---|
| `Pure_Coherence` | APCの時系列zスコアをクロスセクション相対化した `apc_ts_cs_z` | APC activation 上位テーマ |
| `Coherence_Gated_Momentum` | `momentum_score` | `coherence_gate=True` の中で残差モメンタム上位テーマ |
| `APC_Activation_Positive_Momentum` | `apc_ts_cs_z` | APC activation 上位、かつ `momentum_score > 0` のテーマ |

## 前提

事前に Level 3 を実行し、以下を含む `results_l3` が存在している必要があります。

```python
results_l3["theme_returns"]
results_l3["momentum_score"]
results_l3["coherence_apc"]
results_l3["coherence_effective_n"]
results_l3["coherence_gate"]
```

## Notebookでの実行

```python
from dataclasses import replace
from apc_strategy_variants import run_apc_strategy_variants

cfg_apc_variants = replace(
    cfg_l3,
    mode="long_only",
    top_n=5,
    max_theme_weight=0.20,
    use_news=False,
    use_governance=False,
    use_leadlag=False,
    use_valuation=False,
    use_crowding=False,
)

apc_variants = run_apc_strategy_variants(
    results_l3=results_l3,
    config=cfg_apc_variants,
    apc_z_window=252,
    apc_z_min_periods=126,
    min_effective_n=5.0,
    use_hard_gate=True,
    winsor=5.0,
    output_dir="output_apc_variants",
)

apc_variants["metrics"]
```

## APCスコアの意味

`apc_ts_z` は、各テーマのAPCがそのテーマ自身の過去対比でどれだけ高いかを示します。

```text
apc_ts_z = (APC - rolling mean(APC)) / rolling std(APC)
```

`apc_ts_cs_z` は、その時系列zスコアを同時点のテーマ間で横断標準化したものです。

```text
apc_ts_cs_z = cross-sectional z-score(apc_ts_z)
```

したがって、`apc_ts_cs_z` が高いテーマは、

```text
自分の過去対比でもAPCが高く、同時点の他テーマ対比でもAPC activation が強いテーマ
```

です。

## 出力

`output_apc_variants` に以下が保存されます。

```text
apc_ts_z.csv
apc_ts_cs_z.csv
pure_coherence_score.csv
coherence_gated_momentum_score.csv
apc_activation_momentum_positive_score.csv
eligibility.csv
apc_variant_returns.csv
apc_variant_metrics.csv
Pure_Coherence_weights_rebalance.csv
Coherence_Gated_Momentum_weights_rebalance.csv
APC_Activation_Positive_Momentum_weights_rebalance.csv
```

## 注意

`Pure_Coherence` は方向性を持たないAPC activationを買う戦略です。テーマ内銘柄が一緒に上がっていても、一緒に下がっていてもAPCは上がります。したがって、実務上は `APC_Activation_Positive_Momentum` または `Coherence_Gated_Momentum` を主力候補にしてください。
