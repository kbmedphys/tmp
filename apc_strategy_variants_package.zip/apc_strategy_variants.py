"""APC / residual-coherence strategy variants.

This add-on module assumes that Level 3 (Coherence-gated) has already been
run with ``theme_basket_strategy.py`` and that ``results_l3`` contains:

- theme_returns
- momentum_score
- coherence_apc
- coherence_effective_n
- coherence_gate

Implemented variants
--------------------
1. Pure Coherence Strategy
   Buy themes with high time-series-z-scored APC, cross-sectionally relativized.

2. Coherence-Gated Momentum
   Buy positive residual momentum themes that pass the coherence gate.

3. APC Activation + Positive Momentum
   Buy high APC activation score themes, but only if residual momentum is positive.

Dependencies: pandas, numpy, and theme_basket_strategy.py
"""
from __future__ import annotations

import os
from dataclasses import replace
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

from theme_basket_strategy import (
    StrategyConfig,
    backtest_theme_weights,
    construct_theme_weights,
    make_rebalance_dates,
    performance_metrics,
    zscore_cross_sectional,
)


def rolling_time_series_zscore(
    x: pd.DataFrame,
    window: int = 252,
    min_periods: Optional[int] = None,
    std_floor: float = 1e-8,
    winsor: Optional[float] = 5.0,
) -> pd.DataFrame:
    """Rolling time-series z-score for each column.

    Parameters
    ----------
    x:
        Date x theme matrix, e.g. APC.
    window:
        Rolling window length in trading days.
    min_periods:
        Minimum observations. If omitted, max(20, window//2).
    std_floor:
        Std floor to avoid division by zero.
    winsor:
        If not None, clip z-scores to [-winsor, winsor].

    Notes
    -----
    The z-score at date t uses the rolling mean/std including t. In the
    provided backtest engine weights are shifted by one day, so this does not
    use t's signal to earn t's return.
    """
    if min_periods is None:
        min_periods = max(20, window // 2)
    y = x.copy().sort_index().replace([np.inf, -np.inf], np.nan)
    mu = y.rolling(window=window, min_periods=min_periods).mean()
    sd = y.rolling(window=window, min_periods=min_periods).std(ddof=0)
    z = (y - mu) / sd.clip(lower=std_floor)
    if winsor is not None:
        z = z.clip(-winsor, winsor)
    return z


def make_apc_activation_score(
    apc: pd.DataFrame,
    ts_window: int = 252,
    ts_min_periods: Optional[int] = None,
    winsor: Optional[float] = 5.0,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Create APC activation score.

    Step 1: time-series z-score by theme:
        How unusual is the theme's APC versus its own history?

    Step 2: cross-sectional z-score at each date:
        How unusual is that activation versus other themes today?

    Returns
    -------
    apc_ts_z, apc_ts_cs_z
    """
    apc_ts_z = rolling_time_series_zscore(
        apc,
        window=ts_window,
        min_periods=ts_min_periods,
        winsor=winsor,
    )
    apc_ts_cs_z = zscore_cross_sectional(apc_ts_z, winsor=winsor)
    return apc_ts_z, apc_ts_cs_z


def _eligibility_from_results(
    results_l3: Dict[str, object],
    min_effective_n: float = 5.0,
    use_hard_gate: bool = True,
) -> pd.DataFrame:
    """Build strategy eligibility mask from Level 3 outputs."""
    apc = results_l3["coherence_apc"]
    eligibility = apc.notna()

    eff = results_l3.get("coherence_effective_n")
    if isinstance(eff, pd.DataFrame):
        eligibility &= eff >= min_effective_n

    if use_hard_gate:
        gate = results_l3.get("coherence_gate")
        if isinstance(gate, pd.DataFrame):
            eligibility &= gate.reindex_like(eligibility).fillna(False)

    return eligibility.fillna(False)


def build_apc_variant_scores(
    results_l3: Dict[str, object],
    apc_z_window: int = 252,
    apc_z_min_periods: Optional[int] = None,
    min_effective_n: float = 5.0,
    use_hard_gate: bool = True,
    winsor: Optional[float] = 5.0,
) -> Dict[str, pd.DataFrame]:
    """Build signal matrices for the three requested APC strategies.

    Returns a dict containing:
    - apc_ts_z
    - apc_ts_cs_z
    - pure_coherence_score
    - coherence_gated_momentum_score
    - apc_activation_momentum_positive_score
    - eligibility
    """
    required = ["coherence_apc", "momentum_score"]
    for key in required:
        if key not in results_l3:
            raise KeyError(f"results_l3 must contain {key!r}")

    apc = results_l3["coherence_apc"]
    mom = results_l3["momentum_score"].reindex_like(apc)

    apc_ts_z, apc_ts_cs_z = make_apc_activation_score(
        apc,
        ts_window=apc_z_window,
        ts_min_periods=apc_z_min_periods,
        winsor=winsor,
    )

    eligibility = _eligibility_from_results(
        results_l3,
        min_effective_n=min_effective_n,
        use_hard_gate=use_hard_gate,
    ).reindex_like(apc_ts_cs_z).fillna(False)

    # 1. Pure Coherence Strategy:
    #    rank by APC activation score. Direction of return is NOT used.
    pure = apc_ts_cs_z.where(eligibility)

    # 2. Coherence-Gated Momentum:
    #    rank by residual momentum, but only among coherent themes.
    gated_mom = mom.where(eligibility)

    # 3. APC Activation + Positive Momentum:
    #    rank by APC activation score, but require residual momentum > 0.
    apc_pos_mom = apc_ts_cs_z.where(eligibility & (mom > 0))

    return {
        "apc_ts_z": apc_ts_z,
        "apc_ts_cs_z": apc_ts_cs_z,
        "pure_coherence_score": pure,
        "coherence_gated_momentum_score": gated_mom,
        "apc_activation_momentum_positive_score": apc_pos_mom,
        "eligibility": eligibility,
    }


def backtest_score_variant(
    theme_returns: pd.DataFrame,
    score: pd.DataFrame,
    config: StrategyConfig,
    gate: Optional[pd.DataFrame] = None,
    cost_bps_per_turnover: Optional[float] = None,
) -> Dict[str, object]:
    """Turn a score matrix into rebalance weights and backtest returns."""
    rebal_dates = make_rebalance_dates(theme_returns.index, config.rebalance)
    score_rebal = score.reindex(rebal_dates)
    gate_rebal = gate.reindex(rebal_dates).fillna(False) if gate is not None else None

    weights_rebal = construct_theme_weights(score_rebal, config, gates=gate_rebal)
    weights_daily = weights_rebal.reindex(theme_returns.index).ffill().fillna(0.0)

    strat_ret, details = backtest_theme_weights(
        theme_returns=theme_returns,
        weights_daily=weights_daily,
        cost_bps_per_turnover=cost_bps_per_turnover
        if cost_bps_per_turnover is not None
        else config.cost_bps_per_turnover,
    )
    metrics = performance_metrics(strat_ret, config.annualization)

    return {
        "weights_rebalance": weights_rebal,
        "weights_daily": weights_daily,
        "returns": strat_ret,
        "details": details,
        "metrics": metrics,
    }


def run_apc_strategy_variants(
    results_l3: Dict[str, object],
    config: Optional[StrategyConfig] = None,
    apc_z_window: int = 252,
    apc_z_min_periods: Optional[int] = None,
    min_effective_n: float = 5.0,
    use_hard_gate: bool = True,
    winsor: Optional[float] = 5.0,
    output_dir: Optional[str] = None,
) -> Dict[str, object]:
    """Run the three requested APC strategy variants.

    Parameters
    ----------
    results_l3:
        Output dict from Level 3 strategy run.
    config:
        Portfolio config. If None, uses StrategyConfig with long-only defaults.
        For these variants, ``mode='long_only'`` is strongly recommended.
    apc_z_window:
        Time-series z-score window for APC.
    apc_z_min_periods:
        Minimum observations for APC z-score.
    min_effective_n:
        Minimum effective number of names for eligibility.
    use_hard_gate:
        If True, also require existing ``coherence_gate`` from Level 3.
        If False, use only valid APC and effective-N eligibility.
    winsor:
        Winsorization level for z-scores.
    output_dir:
        If supplied, save scores, returns, metrics and weights to this folder.

    Returns
    -------
    dict with scores, returns, metrics and per-strategy results.
    """
    if "theme_returns" not in results_l3:
        raise KeyError("results_l3 must contain 'theme_returns'")

    theme_returns = results_l3["theme_returns"].copy()
    cfg = config or StrategyConfig(
        mode="long_only",
        top_n=5,
        max_theme_weight=0.20,
        use_news=False,
        use_governance=False,
        use_leadlag=False,
        use_valuation=False,
        use_crowding=False,
    )
    # Ensure overlay flags do not affect score-variant backtests.
    cfg = replace(cfg, use_news=False, use_governance=False, use_leadlag=False, use_valuation=False)

    scores = build_apc_variant_scores(
        results_l3,
        apc_z_window=apc_z_window,
        apc_z_min_periods=apc_z_min_periods,
        min_effective_n=min_effective_n,
        use_hard_gate=use_hard_gate,
        winsor=winsor,
    )

    strategy_score_map = {
        "Pure_Coherence": scores["pure_coherence_score"],
        "Coherence_Gated_Momentum": scores["coherence_gated_momentum_score"],
        "APC_Activation_Positive_Momentum": scores["apc_activation_momentum_positive_score"],
    }

    per_strategy = {}
    returns = pd.DataFrame(index=theme_returns.index)
    metrics = {}

    for name, score in strategy_score_map.items():
        res = backtest_score_variant(
            theme_returns=theme_returns,
            score=score,
            config=cfg,
            gate=scores["eligibility"],
        )
        per_strategy[name] = res
        returns[name] = res["returns"]
        metrics[name] = res["metrics"]

    metrics_df = pd.concat(metrics, axis=1).T

    out = {
        "scores": scores,
        "returns": returns,
        "metrics": metrics_df,
        "per_strategy": per_strategy,
        "config": cfg,
    }

    if output_dir is not None:
        os.makedirs(output_dir, exist_ok=True)
        for key, df in scores.items():
            df.to_csv(os.path.join(output_dir, f"{key}.csv"), index=True)
        returns.to_csv(os.path.join(output_dir, "apc_variant_returns.csv"), index=True)
        metrics_df.to_csv(os.path.join(output_dir, "apc_variant_metrics.csv"), index=True)
        for name, res in per_strategy.items():
            res["weights_rebalance"].to_csv(os.path.join(output_dir, f"{name}_weights_rebalance.csv"), index=True)
            res["weights_daily"].to_csv(os.path.join(output_dir, f"{name}_weights_daily.csv"), index=True)
            res["details"].to_csv(os.path.join(output_dir, f"{name}_backtest_details.csv"), index=True)

    return out
