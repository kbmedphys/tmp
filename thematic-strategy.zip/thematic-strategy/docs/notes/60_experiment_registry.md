# 60_experiment_registry

## 記録ルール

- 実験結果は `outputs/tables/*.csv` を一次記録とし、本台帳へ要点を転記する。
- `LeakageCheck` は以下を満たすと `PASS`:
  - `exec_lag=1` でシグナル時点と執行時点を分離
  - ローンチ前は non-investable（missing）
  - 非投資期間/投資可能期間の欠損を0リターン補完しない（2026-02-04改修）
- 候補採択は `RobustScore = TestSharpe - 0.50*StabilitySharpeStd - 0.30*TestTurnover` の最大値。

## 参照ファイル

- `outputs/tables/phase3_candidate_summary.csv`
- `outputs/tables/phase3_candidate_detailed_metrics.csv`
- `outputs/tables/phase3_best_metrics.csv`
- `outputs/tables/phase3_best_stability.csv`

## 候補比較サマリ（Phase3）

| ID | Candidate | Strategy | Params(主要) | Normalization | Train(Test) Sharpe | Train(Test) MDD | Train(Test) Turnover | Train(Test) CostDrag | Subperiod Sharpe (17-19 / 20-21 / 22-now) | LeakageCheck | Decision |
|---|---|---|---|---|---:|---:|---:|---:|---|---|---|
| EXP-001 | P1_T1_baseline | T1 | rebalance=M, top_k=4, lookback_price=252, factor_set=minimal_3, λ(attn/risk/down)=0/0/0 | cross_sectional_zscore | 0.975 (0.437) | -0.361 (-0.485) | 0.071 (0.114) | 0.148 (0.189) | 0.654 / 1.077 / 0.589 | PASS | **採択**（OOS Sharpe最大、turnover低位） |
| EXP-002 | P2_T1_attention_downside | T1 | rebalance=M, top_k=4, lookback_price=252, factor_set=minimal_3, λ(attn/risk/down)=0.35/0.20/0.20 | cross_sectional_zscore | 0.570 (0.252) | -0.432 (-0.458) | 0.185 (0.501) | 0.382 (0.984) | 0.046 / 1.021 / 0.303 | PASS | 却下（turnover過大、コスト過大） |
| EXP-003 | P3_T2_minimal3 | T2 | rebalance=M, top_k=4, factor_set=minimal_3, reg_lookback=252, residual=63, corr=63, λ_corr=0.25 | cross_sectional_zscore | 1.000 (0.224) | -0.398 (-0.398) | 0.169 (0.204) | 0.306 (0.293) | 0.871 / 1.244 / 0.184 | PASS | 却下（Test SharpeがP1未満） |
| EXP-004 | P4_T2_minimal5_riskaware | T2 | rebalance=M, top_k=4, factor_set=minimal_5, reg_lookback=252, residual=63, corr=63, λ_corr/risk/down=0.20/0.25/0.20 | cross_sectional_zscore | 0.966 (0.200) | -0.399 (-0.437) | 0.167 (0.218) | 0.306 (0.334) | 0.746 / 1.218 / 0.098 | PASS | 却下（直近サブ期間Sharpeが弱い） |
| EXP-005 | P5_T3_hybrid | T3 | rebalance=M, top_k=4, factor_set=minimal_3, reg_lookback=252, residual=63, corr=63, λ_corr/risk/down/text/amb=0.20/0.20/0.15/0.20/0.50 | cross_sectional_zscore + text_purity_z | 0.946 (0.274) | -0.370 (-0.350) | 0.175 (0.200) | 0.310 (0.314) | 0.750 / 1.088 / 0.315 | PASS | 却下（MDD改善はあるがTest Sharpeで劣後） |

## 個別メモ（採択/却下理由）

- EXP-001 / P1
  - 採択根拠: OOS Sharpeが最大、turnover抑制、サブ期間Sharpeが全期間でプラス。
  - 懸念: Test MDDはEQWより深い（-0.485）。今後はドローダウン制御を追加検討。

- EXP-002 / P2
  - 却下根拠: attention + downside により売買頻度が増加し、コスト負担が大きい。
  - 過学習兆候: 2020-2021だけ相対的に強く、他期間で再現性が低い。

- EXP-003 / P3
  - 却下根拠: T2 minimal_3 は一定の安定性があるが、採択基準（OOS Sharpe優位）を満たさず。
  - 補足: 直近期間Sharpeはプラス維持だがP1より低い。

- EXP-004 / P4
  - 却下根拠: 因子拡張で説明力は増えるが、OOS Sharpe改善に繋がらず。
  - 過学習兆候: 2022-now Sharpeが0.098と弱く、レジーム変化に脆弱。

- EXP-005 / P5
  - 却下根拠: text purityでMDDは改善したが、採択基準のOOS SharpeでP1に劣後。
  - 次アクション: text更新頻度/λ_textを固定範囲で再探索（Phase4候補）。
