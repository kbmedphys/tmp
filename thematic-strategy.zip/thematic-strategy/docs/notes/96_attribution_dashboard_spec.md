# 96_attribution_dashboard_spec

## 目的（写経）

- 単一の最終統計値ではなく、各時点の寄与を同一時間軸で確認できるダッシュボードを作る。
- 寄与の内訳は以下4系統を同時表示する。
  1) 因子寄与（`beta \times factor return`）
  2) 残差/alpha
  3) 内部寄与（selection vs weighting）
  4) overlay寄与（ON/OFFのみ）

## 対象戦略（固定ルール）

- 全戦略ではなく代表戦略のみ対象。
- 代表戦略の選定ルール（固定）:
  - `EQW` を必ず含める。
  - best `T1 base` を必ず含める。
  - best `ON/OFF`（StepA または StepB）を1本含める。
  - best `T2`（存在する場合）を1本含める。
- 参照元summary:
  - `outputs/tables/nav_summary_with_onoff_stepB.csv` を優先。
  - 無ければ最新summary（`nav_summary_with_onoff.csv` など）を使用。
- 選定結果:
  - `outputs/tables/dashboard_selected_strategies.csv` に保存。
  - 本ファイルにも追記して単一真実化する。

## 図の構成（4パネル固定）

- 代表戦略ごとに `outputs/figures/dashboard_{strategy_id}.png` を1枚生成。
- 時系列は月次で統一。

### Panel 1: NAV

- `strategy` と `EQW` の月次NAVを描画。
- タイトルに `strategy_id` と主要パラメータ（rebalance/top_k/exec_lag/split_date）を記載。

### Panel 2: 因子寄与 + alpha/resid

- 表示優先因子（最大3本）:
  1) `EQW`
  2) `SPY`
  3) `IEF`
  4) `QQQ`
- 残りは `OTHER_FACTORS` に合算。
- alpha列があれば `alpha`、なければ `resid` を表示。
- 定義:
  - `contrib_key_t = \sum_{j \in key} contrib_{j,t}`
  - `total_factor_contrib_t = \sum_j contrib_{j,t}`
  - `contrib_other_t = total_factor_contrib_t - contrib_key_t`

### Panel 3: 内部寄与

- `R_sel`, `R_wgt` を描画。
- 任意で `R_port` を薄線表示可。
- データが無ければ `N/A` 表示。

### Panel 4: Overlay寄与

- ON/OFF戦略:
  - `overlay_excess` と `indicator` を同一時間軸で描画（必要なら2軸）。
- ON/OFF以外:
  - `No overlay` と表示。

## 入出力（固定）

- 必須出力:
  - `outputs/tables/dashboard_selected_strategies.csv`
  - `outputs/tables/dashboard_components_{strategy_id}.csv`
  - `outputs/figures/dashboard_{strategy_id}.png`
- `dashboard_components` 例:
  - `date, nav, nav_eqw, contrib_EQW, contrib_SPY, contrib_IEF, contrib_QQQ, contrib_OTHER, alpha_or_resid, R_sel, R_wgt, R_port, overlay_excess, indicator`

## 既存出力再利用ルール

- 以下が存在すれば再利用を優先する:
  - `outputs/tables/attribution_factor_contrib_all.csv`（または `attribution_factor_contrib.csv`）
  - `outputs/tables/attribution_factor_alpha_all.csv`（または `attribution_factor_alpha.csv`）
  - `outputs/tables/attribution_internal_selection_weighting.csv`
  - `outputs/tables/attribution_overlay_excess.csv`
- 無い場合のみ、94/95ロジック（attribution計算）を再実行して同形式で保存する。

## 採用ルール（固定）

- 図は matplotlib のみ（依存追加なし）。
- 先読み禁止（`exec_lag` 厳守）。
- ローンチ前0埋め禁止（missing扱い）。
- 外部センチメント禁止。

## 選定結果（実行後に追記）

- 実行後に `dashboard_selected_strategies.csv` の内容をここへ追記する。

### 2026-02-04 実行結果（単一真実）

- 参照summary: `outputs/tables/nav_summary_with_onoff_stepB.csv`
- 選定結果（`outputs/tables/dashboard_selected_strategies.csv` と同一）:
  - `EQW`（role=`EQW`）
  - `T1_base_best`（role=`best_T1_base`）
  - `T1_best_onoff_statepred_M12_eta0p2`（role=`best_ONOFF`）
  - `T2_resid_eqw_only`（role=`best_T2`）
