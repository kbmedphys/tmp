# 11_data_catalog

## データ一覧（取得可能ソース限定）

| 区分 | フィールド | 頻度 | 主ソース | 観測可能時点 | 欠損/注意点 | 利用先 |
|---|---|---|---|---|---|---|
| Investable価格 | Adjusted Close | 日次 | yfinance `download` | 当日終値確定後 | ティッカーごと開始日が異なる | T1/T2、NAV |
| Investable出来高 | Volume | 日次 | yfinance `download` | 当日終値確定後 | 休場/新規上場前は欠損 | T1 attention proxy |
| 経費率 | expense_ratio | 静的 | `01_universe.csv`（主）/ yfinance info（補助） | 取得時点 | 情報欠落あり、CSV値を優先 | コスト控除 |
| テーマ説明文 | objective_strategy_short | 静的 | `01_universe.csv` | ファイル読込時 | 手入力由来の揺れあり | T3 purity |
| 指数名 | index_name | 静的 | `01_universe.csv` | ファイル読込時 | アクティブETFは欠損/記述差 | T3 purity |
| テーマラベル | theme | 静的 | `01_universe.csv` | ファイル読込時 | 日本語表記揺れ | T3 group prototype |
| T2因子価格 | Adj Close (factor ETFs) | 日次 | yfinance | 当日終値確定後 | 銘柄欠損時はset変更/代替 | T2回帰 |
| 内生因子 | EQW return | 日次 | investable価格から自前算出 | 当日終値確定後 | その時点投資可能ETFのみで算出 | T2 factor_set |

## yfinance項目（想定実装）

- 価格/出来高:
  - `yfinance.download(tickers, interval="1d", auto_adjust=False, actions=False)`
  - 使用列: `Adj Close`, `Volume`
- 経費率（任意取得）:
  - `Ticker.info` の `annualReportExpenseRatio` / `totalExpenseRatio` / `expenseRatio` を探索
  - 欠損時は `01_universe.csv` を使用

## 派生データ

- `first_valid_date[ticker]`: Adj Closeの最初の非欠損日（ローンチ日）。
- `returns[ticker,t]`: `AdjClose_t / AdjClose_{t-1} - 1`（両日観測時のみ）。
- `investable_mask[ticker,t]`: `date >= first_valid_date[ticker]`。
- `eqw_return[t]`: その日投資可能な銘柄集合で等ウェイト平均。

## 保存ポリシー

- raw: `data/raw/`（取得直後データ）
- processed: `data/processed/`（整形後の価格・リターン・マスク）
- すべて再現可能なCSV/Parquetで保存。
