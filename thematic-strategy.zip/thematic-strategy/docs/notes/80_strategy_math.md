# 80_strategy_math

## 1) 共通記法

### 1.1 記号

- 銘柄集合（固定18ETF）: `\mathcal{U}`
- 日付集合: `t = 1,2,...,T`
- 価格: `P_{i,t}`（Adjusted Close）
- リターン: `r_{i,t} = P_{i,t}/P_{i,t-1} - 1`
- 投資可能マスク: `m_{i,t} \in \{0,1\}`
  - `m_{i,t}=0` はローンチ前または当日欠損で非投資
- 執行ラグ: `L`（本実装は `L=1`）
- リバランス時点集合: `\mathcal{T}_{reb}`（月末）
- 目標ウェイト: `\tilde{w}_{i,t}`
- 執行ウェイト: `w_{i,t}=\tilde{w}_{i,t-L}`

### 1.2 ウェイト生成（共通）

- スコア `s_{i,t}` を計算し、投資可能集合 `\mathcal{I}_t=\{i\in\mathcal{U}|m_{i,t}=1\}` で降順ランキング。
- Top-K集合 `\mathcal{K}_t` を選択（`K=4`）。
- 等ウェイト:
  - `\tilde{w}_{i,t}=1/K` if `i\in\mathcal{K}_t`, else `0`。

### 1.3 欠損処理ポリシー（重要）

- ローンチ前: `m_{i,t}=0`（missing、0リターン埋め禁止）。
- 投資可能期間中の欠損リターン:
  - `r_{i,t}` が欠損の銘柄は当日だけ非投資（`w_{i,t}=0`）とし、
  - 残り銘柄で当日再正規化して `\sum_i w_{i,t}=1`（可能な場合）
  - これは「0リターン扱い」ではなく「非投資扱い」。

### 1.4 ポートフォリオ収益とNAV

- グロス収益:
  - `r^{gross}_t = \sum_i w_{i,t} r_{i,t}`
- ターンオーバー:
  - `TO_t = \sum_i |w_{i,t}-w_{i,t-1}|`
- 取引コスト:
  - `c^{trade}_t = TO_t\cdot(\text{fee}_{bps}+\text{slippage}_{bps})/10^4`
- 経費率コスト（日割り）:
  - `c^{exp}_t = \sum_i w_{i,t}\cdot ER_i/252`
- ネット収益:
  - `r^{net}_t = r^{gross}_t - c^{trade}_t - c^{exp}_t`
- NAV更新:
  - `NAV_t = NAV_{t-1}(1+r^{net}_t)`, `NAV_0=1`

---

## 2) T1: スコア→TopK→等ウェイト

### 2.1 モメンタム（trend）

- `mom_{i,t} = P_{i,t-L}/P_{i,t-L-\tau} - 1`（標準 `\tau=252`）

### 2.2 Attention proxy（price/volume由来）

- `attn_{i,t} = z_{cs}(\log V_{i,t-L} - \mu_{20}(\log V_i))`

### 2.3 リスク/下方リスク

- 実現ボラ: `vol_{i,t}=\sigma_{63}(r_{i,t-L})`
- 下方半偏差: `down_{i,t}=\sigma_{63}(\min(r_{i,t-L},0))`

### 2.4 正規化

- 各日 cross-sectional z-score:
  - `z_{cs}(x_{i,t})=(x_{i,t}-\bar{x}_{\cdot,t})/s_{\cdot,t}`

### 2.5 T1スコア族

- `T1_mom`:
  - `s_{i,t}=z_{cs}(mom_{i,t})`
- `T1_mom_attn`:
  - `s_{i,t}=z(mom)+\lambda_{attn}z(attn)`
- `T1_mom_attn_risk`:
  - `s_{i,t}=z(mom)+\lambda_{attn}z(attn)-\lambda_{risk}z(vol)-\lambda_{down}z(down)`
- `T1_mom_attn_risk_tc`（turnover penalty）:
  - `tcproxy_{i,t}=z_{cs}(|s^{raw}_{i,t}-s^{raw}_{i,t-1}|)`
  - `s_{i,t}=s^{raw}_{i,t}-\lambda_{tc}\,tcproxy_{i,t}`

---

## 3) T2: 因子回帰→残差→スコア + 相関ペナルティ

### 3.1 因子回帰

- 因子集合 `\mathcal{F}`（factor_setで切替）を用いて rolling OLS:
  - `r_{i,\tau}=\alpha_{i,t}+\beta_{i,t}^\top f_{\tau}+\varepsilon_{i,\tau}`
  - `\tau\in[t-W+1,t]`, `W=252`
- 残差:
  - `\varepsilon_{i,\tau}=r_{i,\tau}-(\alpha_{i,t}+\beta_{i,t}^\top f_{\tau})`

### 3.2 residual momentum / downside

- `resMom_{i,t}=\mu_{63}(\varepsilon_{i,\tau})`
- `resRisk_{i,t}=\sigma_{63}(\varepsilon_{i,\tau})`
- `resDown_{i,t}=\sigma_{63}(\min(\varepsilon_{i,\tau},0))`

### 3.3 相関ペナルティ

- `Corr_t(i,j)=Corr(\varepsilon_{i,\tau},\varepsilon_{j,\tau})`（63日窓）
- ペナルティ（平均正相関）:
  - `corrPen_{i,t}=\frac{1}{|\mathcal{I}_t|-1}\sum_{j\neq i}\max(Corr_t(i,j),0)`
- `\rho_0` を明示した閾値版は
  - `\max(Corr_t(i,j)-\rho_0,0)` へ置換可能（実装はgreedy/近似で可）

### 3.4 T2スコア族

- `T2_resid_*`（corr penaltyなし）:
  - `s_{i,t}=z(resMom_{i,t})`
- `T2_resid_corrpen_*`:
  - `s_{i,t}=z(resMom)-\gamma\,z(corrPen)`（`\gamma=\lambda_{corr}`）

---

## 4) T3: Text / Purity

### 4.1 テキスト正規化

- 入力テキスト:
  - `text_i = objective\_strategy\_short_i + index\_name_i`
- 正規化:
  - 小文字化、記号除去、空白正規化、簡易ストップワード除去

### 4.2 類似度（依存追加なし）

- BoWベクトル `v_i`
- テーマ代表 `v_{g}`（同テーマETFの合算）
- `sim(a,b)=\frac{a^\top b}{\|a\|\|b\|}`
- purity:
  - `purity_i = sim(v_i,v_{g(i)}) - \lambda_{amb}\max_{h\neq g(i)} sim(v_i,v_h)`
  - cross-sectional z化して `purityZ_i`

### 4.3 スコア結合

- 乗算補正（mult）:
  - `s'_{i,t}=s_{i,t}\cdot\max(1+\lambda_{text}purityZ_i,\epsilon)`
- キャップ補正（cap）:
  - `cap_{i,t}=Q_q(s_{\cdot,t})\cdot[(1-\lambda_{text})+\lambda_{text}\,rankPct(purityZ_i)]`
  - `s'_{i,t}=\min(s_{i,t},cap_{i,t})`

---

## 5) strategy_id対応表（単一真実）

| strategy_id | mode | 主式 | factor_set | 備考 |
|---|---|---|---|---|
| EQW | benchmark | investable等ウェイト | - | non-investable除外 |
| T1_mom | T1 | `z(mom)` | - | 基準戦略 |
| T1_mom_attn | T1 | `z(mom)+\lambda_attn z(attn)` | - | 価格/出来高attention |
| T1_mom_attn_risk | T1 | `z(mom)+\lambda_attn z(attn)-\lambda_risk z(vol)-\lambda_down z(down)` | - | リスク調整 |
| T1_mom_attn_risk_tc | T1 | 上式 `-\lambda_tc tcproxy` | - | 売買過多抑制 |
| T2_resid_minimal3 | T2 | `z(resMom)` | minimal_3 | [SPY,QQQ,IEF] |
| T2_resid_ext10 | T2 | `z(resMom)` | extended_10 | 10因子 |
| T2_resid_eqw_only | T2 | `z(resMom)` | eqw_only | EQW内生因子 |
| T2_resid_corrpen_minimal3 | T2 | `z(resMom)-\lambda_corr z(corrPen)` | minimal_3 | 相関ペナルティ |
| T3_purity_mult_on_T1 | T3 | T1_mom_attn_risk × purity乗算 | minimal_3 | purity乗算補正 |
| T3_purity_cap_on_T1 | T3 | T1_mom_attn_risk + purity cap | minimal_3 | purityキャップ補正 |
| T3_purity_mult_on_T2* | T3 | T2 + purity乗算 | minimal_3 | 任意追加 |
| T3_purity_cap_on_T2* | T3 | T2 + purity cap | minimal_3 | 任意追加 |

`*` は任意追加だが本実装では有効化済み。

---

## 6) A案: Episodic Factor Pricing ON/OFF overlay

### 6.1 managed score

- 既存baseスコアを `S_{i,t}` とする。
- ON/OFF indicator `I_t \in \{0,1\}`、retention ratio `\eta \in [0,1]` として
  - `S^{managed}_{i,t} = (\eta + (1-\eta)I_t)\,S_{i,t}`
- `I_t=1` なら通常運用、`I_t=0` なら縮小運用（`\eta=0` なら完全OFF）。
- 実装注記:
  - Top-K等ウェイトでは日次の一様スカラー倍は順位を変えないため、実運用では
    `r^{managed}_t = (\eta + (1-\eta)I_t)\,r^{base}_t`
    と同値なエクスポージャ縮小（残りはキャッシュ0%）として反映する。

### 6.2 SED定義（実装簡易版）

- 月次でベース戦略の予測優位を測る代理として
  - `SED_t = r^{base}_t - r^{EQW}_t`
- 学習では demeaned 版 `\tilde{SED}_t = SED_t - \bar{SED}_{1:t}` を使用。

### 6.3 ON/OFF判定

- Step A（lagged SED符号）:
  - `I_t = 1[\tilde{SED}_{t-1} > 0]`
- Step B（状態変数回帰）:
  - 月次ターゲットを `SED_t^{(M)} = MA_M(\tilde{SED}_t)` とする。
  - 市場ボラ正規化付きターゲット（採用）:
    - `y_t = SED_t^{(M)} / vol_{mkt,t}`
    - `vol_{mkt,t} = Std_{12m}(R_t^{EQW})`
  - 説明変数ベクトル（すべて `t-1` 以前を使用）:
    - `Z_{t-1} = [SED_{t-1},SED_{t-3},SED_{t-6},SED_{t-12},R^{EQW}_{t-1},R^{EQW}_{t-3},RV^{EQW}_{12m,t-1},CSVAR_{t-1},DISP_{t-1}, ... ]`
  - expanding OLS:
    - `y_t = a_t + b_t^\top Z_{t-1} + e_t`
    - `\widehat{y}_{t+1|t} = \hat a_t + \hat b_t^\top Z_t`
    - `\widehat{SED}_{t+1|t}^{(M)} = \widehat{y}_{t+1|t} \cdot vol_{mkt,t}`
    - `I_t = 1[\widehat{SED}_{t+1|t}^{(M)} > 0]`
  - optional: `state_model=lasso` を許容（既定は OLS）。
- 学習窓は expanding window（`1...t`）で固定し、`t` でfit→`t+1`予測を徹底（先読み回避）。

### 6.4 ON/OFF追加strategy_id

| strategy_id | base | ON/OFF | \eta |
|---|---|---|---:|
| T1_base_best | 当時点の最良T1 base | なし | - |
| T1_base_best_onoff_eta0 | T1_base_best | あり | 0.0 |
| T1_base_best_onoff_eta0p2 | T1_base_best | あり | 0.2 |
| T1_base_best_onoff_eta0p5 | T1_base_best | あり | 0.5 |
| T1_best_onoff_statepred_M6_eta0 | T1_base_best | StepB | 0.0 |
| T1_best_onoff_statepred_M6_eta0p2 | T1_base_best | StepB | 0.2 |
| T1_best_onoff_statepred_M6_eta0p5 | T1_base_best | StepB | 0.5 |
| T1_best_onoff_statepred_M12_eta0 | T1_base_best | StepB | 0.0 |
| T1_best_onoff_statepred_M12_eta0p2 | T1_base_best | StepB | 0.2 |
| T1_best_onoff_statepred_M12_eta0p5 | T1_base_best | StepB | 0.5 |
