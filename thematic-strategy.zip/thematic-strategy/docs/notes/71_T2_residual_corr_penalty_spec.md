# 71_T2_residual_corr_penalty_spec

## 目的

テーマETFの「因子被り」を回帰で除去し、残差（テーマ固有）に基づく強弱判定を行う。
同時に、選抜銘柄間の相関集中を抑えるペナルティを導入する。

## 入力

- 投資対象18ETFの日次リターン `r_{i,t}`
- 説明変数ETFの日次リターン `f_{k,t}`（non-investable）
- 内生因子 `EQW_t`（必要時）

## factor_set（固定候補）

- `minimal_3`: `[SPY, QQQ, IEF]`
- `minimal_5`: `[SPY, QQQ, IWM, IEF, LQD]`
- `extended_10`: `[SPY, QQQ, IWM, EFA, EEM, IEF, TLT, LQD, HYG, GLD]`
- `extended_12`: `extended_10 + [VNQ, DBC]`
  - DBC取得不可時は `PDBC` へ置換可（ticker差し替えのみ）
- `eqw_only`: `[EQW]`
- `eqw_plus_rates`: `[EQW, IEF]`

## EQW因子の定義（厳守）

- `EQW_t = mean(r_{i,t} for i in I_t)`
- `I_t` はその時点で投資可能なETFのみ。
- ローンチ日前の0埋めは禁止。

## 回帰仕様

- rolling OLS（窓 `L` = 126 or 252）:
  - `r_{i,τ} = α_{i,t} + β_{i,t}^T f_{τ} + ε_{i,τ}` for `τ in [t-L+1, t]`
- 判定に使う残差系列:
  - `eps_{i,τ} = r_{i,τ} - (α_{i,t} + β_{i,t}^T f_{τ})`

## 残差ベーススコア

- `res_trend_{i,t} = mean(eps over 63d)`
- `res_risk_{i,t} = std(eps over 63d)`
- `res_down_{i,t} = std(min(eps,0) over 63d)`

## 相関ペナルティ

- 残差相関行列 `Corr_t`（63d）を作成。
- 候補銘柄 `i` のペナルティ:
  - `corr_pen_{i,t} = mean(Corr(i,j) for j in SelectedPartial_t)`
  - 逐次選抜で相関の高い銘柄を抑制。

## 総合スコア

- `score_{i,t} = z(res_trend) - λ_risk*z(res_risk) - λ_down*z(res_down) - λ_corr*z(corr_pen)`
- `Top-K` 選定後、Phase2は等ウェイト配分。

## 先読み回避・実装規律

- すべての回帰・相関計算は `t-exec_lag` まで。
- factor ETFsは説明変数のみで、NAVには非投資（non-investable）を厳守。
- 欠損日が多い場合はその銘柄を当日ランキング対象から除外。

## Phase 3での比較方針

- まず `minimal_3` / `minimal_5` / `eqw_plus_rates` を優先比較。
- 拡張集合（extended_10/12）はturnoverと過適合を監視しながら採用判断。
