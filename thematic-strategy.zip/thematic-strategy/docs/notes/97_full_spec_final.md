# 97_full_spec_final

## 目的

- 本ノートは「1本で end-to-end（取得→全strategy比較→attribution→dashboard→結論）」を再現する最終仕様を固定する。
- Full Spec の推奨戦略は `T1_best_onoff_statepred_M12_eta0p2` とする（既存比較で Test Sharpe 最大）。

## 前提・仮定（固定）

- 投資対象は 18 thematic ETF のみ。
- 日次データは `Adj Close`, `Volume`, `expense_ratio`, テキスト列 `objective_strategy_short`, `index_name` のみ。
- `split_date = 2021-01-01`、`exec_lag = 1`、`rebalance = M`、`top_k = 4` を標準とする。
- 先読み禁止: 時点 `t` の意思決定は `t` 以前に観測可能な情報のみ。
- ローンチ前は non-investable（missing）であり、0埋めを禁止する。

## Layer-1: Base Rotation（T1）

- 価格トレンド:
  - `trend_{i,t} = P_{i,t-1} / P_{i,t-1-L} - 1`, `L=252`
- クロスセクション標準化:
  - `z_{i,t} = (trend_{i,t} - \mu_t) / \sigma_t`
- ベーススコア:
  - `S^{(1)}_{i,t} = z_{i,t}`
- 銘柄選定・配分:
  - `U_t = {i | investable_{i,t}=1}`
  - `K_t = TopK_i(S^{(1)}_{i,t}, i \in U_t), K=4`
  - `w^{base}_{i,t} = 1/K` if `i \in K_t`, else `0`

## Layer-2: ON/OFF StepB（状態予測 Overlay）

- 日次ベース戦略と EQW の差:
  - `SED_t = r^{base}_t - r^{eqw}_t`
- 月次ターゲット（`M=12` を既定）:
  - `SED^{(M)}_m = MA_M(SED_m)`
  - `y_m = SED^{(M)}_m / vol^{eqw}_{m,12}`（既定はボラ正規化あり）
- 状態変数（lagged）:
  - `Z_m = [SED_{m-1}, SED_{m-3}, SED_{m-6}, SED_{m-12}, R^{EQW}_{m-1}, RV^{EQW}_{m-1}, ...]`
- expanding OLS:
  - `y_m = a_m + b_m^\top Z_{m-1} + e_m`
  - `\hat y_{m+1|m} = \hat a_m + \hat b_m^\top Z_m`
  - `\widehat{SED}_{m+1|m} = \hat y_{m+1|m} \cdot vol^{eqw}_{m,12}`
- indicator:
  - `I_m = 1[\widehat{SED}_{m+1|m} > 0]`
- Overlay（`η=0.2` 既定）:
  - `scale_m = \eta + (1-\eta)I_m`
  - `S^{(2)}_{i,m} = scale_m \cdot S^{(1)}_{i,m}`

## Layer-3: Purity 制約（テキスト整合）

- ETFテキストから純度スコア:
  - `purity_i = sim(text_i, theme_i) - \lambda_{amb}\max_{h \neq theme_i} sim(text_i, h)`
  - `purity^z_i = zscore(purity_i)`
- 制約付き補正（T3有効時）:
  - 乗算型: `S^{(3)}_{i,t} = S^{(2)}_{i,t} \cdot \max(1 + \lambda_{text} purity^z_i, \epsilon)`
  - cap型: `S^{(3)}_{i,t} = \min(S^{(2)}_{i,t}, cap_{i,t})`
- Full Spec 推奨戦略（`T1_best_onoff_statepred_M12_eta0p2`）では purity 補正は非活性だが、純度指標を監視指標として保持する。

## Layer-4: T2診断 + Attribution

### T2 残差診断（診断専用）

- 残差回帰:
  - `r_{i,t} = \alpha_{i,t} + \beta_{i,t}^\top f_t + \varepsilon_{i,t}`
- 残差モメンタム:
  - `m_{i,t} = MA_W(\varepsilon_{i,t})`
- 相関ペナルティ:
  - `pen_{i,t} = mean_j(max(corr(\varepsilon_i,\varepsilon_j), 0))`

### 要因分解（全strategy）

- 月次ローリング回帰（`W=36`, lag=1）:
  - `r_{s,t} = \alpha_{s,t} + \beta_{s,t}^\top f_t + u_{s,t}`
- 因子寄与:
  - `contrib_{s,j,t} = \beta_{s,j,t} f_{j,t}`
- 内部寄与:
  - `R^{sel}_t = mean_{i \in K_t}(r_{i,t})`
  - `R^{wgt}_t = \sum_i w_{i,t}r_{i,t} - R^{sel}_t`
- Overlay寄与:
  - `overlay\_excess_t = R^{managed}_t - R^{base}_t`

## デフォルト設定（固定）

- `M = 12`, `η = 0.2`, `onoff_method = state_pred`, `state_model = ols`
- 評価比較軸:
  - `Train/Test/All` 指標（CAGR, Sharpe, Vol, MDD, Turnover, Cost）
  - 因子寄与（EQW, IEF, OTHER, alpha/resid）
  - internal（selection vs weighting）
  - overlay（managed-base と indicator）

## 出力成果物（最低限）

- `outputs/tables/nav_timeseries_all_with_onoff_stepB.csv`
- `outputs/tables/nav_summary_with_onoff_stepB.csv`
- `outputs/tables/nav_summary_train_test_all_with_onoff_stepB.csv`
- `outputs/figures/nav_all_strategies_ALL.png`
- `outputs/figures/nav_all_strategies_ALL_log.png`
- `outputs/figures/drawdown_all_strategies_ALL.png`
- `outputs/tables/attribution_factor_*`
- `outputs/figures/rolling_beta_eqw.png`
- `outputs/figures/factor_contrib_eqw_plus_rates.png`
- `outputs/figures/attribution_internal_sel_wgt.png`
- `outputs/figures/overlay_excess_vs_indicator.png`
- `outputs/figures/dashboard_{strategy_id}.png`

