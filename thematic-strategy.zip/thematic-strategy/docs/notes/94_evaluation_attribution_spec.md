# 94_evaluation_attribution_spec

## 目的（写経）

- 単一の最終統計値だけでなく、各時点のパフォーマンスを要因分解して評価する。
- 分解レイヤは以下の3つ。
  - (A) 因子寄与分解（rolling `\beta \times` 因子リターン）
  - (B) ローリング `\alpha` / 残差推移
  - (C) 戦略内部寄与（selection / weighting / overlay）

## 対象strategy_id（写経）

- 原則は「現時点の全strategy_id」。
- 計算負荷が高い場合の代表候補:
  - `EQW`, `T1_best_base`, `T1_best_onoff_*`（StepA/StepB）, `T2`代表
- 設計は全strategy_id対応にする。

## (A) 因子寄与分解（写経）

- 因子セット（既定）:
  - `factor_set_eval="eqw_plus_rates"`
  - `f_t = [R_t^{EQW}, R_t^{IEF}]`
- オプション:
  - `extended_5 = [R^{SPY}, R^{QQQ}, R^{IWM}, R^{IEF}, R^{HYG}]`
- 推定頻度:
  - 月次
- 推定窓:
  - `W = 36`ヶ月（不足時は24ヶ月可）
- 回帰（strategy `s`）:
  - `y_{s,u} = \alpha_{s,t} + \beta_{s,t}^{\top} f_u + \varepsilon_{s,u}` for `u=t-W,...,t-1`
- 時点 `t` 寄与:
  - `contrib_{s,j,t} = \beta_{s,j,t} f_{j,t}`
  - `alpha_{s,t} = \alpha_{s,t}`
- 先読み防止:
  - `\beta_{s,t}` は `t-1` までで推定し、`t` の寄与計算にのみ使用。

## (B) ローリングα/残差（写経）

- 残差:
  - `resid_{s,t} = y_{s,t} - (\alpha_{s,t} + \beta_{s,t}^{\top} f_t)`
- オプション:
  - `RS_{s,t} = \mu(resid_{s,u})/\sigma(resid_{s,u})` over `u=t-W,...,t-1`
- 目的:
  - 因子で説明できない成分がいつ発生したかを可視化。

## (C) 戦略内部寄与（写経）

### C-1 Selection vs Weighting

- 採用集合 `S_t`（Top-K）
- `R_t^{sel} = (1/|S_t|)\sum_{i\in S_t} r_{i,t}`
- `R_t^{port} = \sum_i w_{i,t} r_{i,t}`
- `R_t^{wgt} = R_t^{port} - R_t^{sel}`

### C-2 Overlay（ON/OFFのみ）

- `overlay\_excess_t = R_t^{managed} - R_t^{base}`
- `indicator I_t` と同時に保存/可視化。

## 実装方針（写経）

- `src/thematic_strategy/attribution.py` を新設し、以下を提供:
  - `make_monthly_returns_from_nav(nav_series)`
  - `rolling_factor_attribution(returns_by_strategy, factor_returns, window_months, lag=1)`
  - `internal_selection_weighting_attribution(weights, asset_returns, rebalance_dates, top_k)`
  - `overlay_attribution(managed_returns, base_returns, indicator, meta)`
- `main.ipynb` から呼び、`outputs/` 配下へ保存する。

## 出力ファイル（写経）

- `outputs/tables/attribution_factor_betas.csv`
  - `date, strategy_id, factor_name, beta`
- `outputs/tables/attribution_factor_contrib.csv`
  - `date, strategy_id, factor_name, contrib`
- `outputs/tables/attribution_factor_alpha.csv`
  - `date, strategy_id, alpha, resid`
- `outputs/tables/attribution_resid_stats.csv`
  - `date, strategy_id, resid, resid_rolling_sharpe`
- `outputs/tables/attribution_internal_selection_weighting.csv`
  - `date, strategy_id, R_sel, R_port, R_wgt`
- `outputs/tables/attribution_overlay_excess.csv`
  - `date, managed_strategy_id, base_strategy_id, overlay_excess, indicator, eta, M, method`

## 出力図（写経）

- `outputs/figures/rolling_beta_eqw.png`
- `outputs/figures/factor_contrib_eqw_plus_rates.png`
- `outputs/figures/rolling_alpha_resid.png`
- `outputs/figures/attribution_internal_sel_wgt.png`
- `outputs/figures/overlay_excess_vs_indicator.png`

## 制約（写経）

- 先読み禁止（`exec_lag` 厳守）
- ローンチ前は missing（0リターン埋め禁止）
- 欠損を0リターン扱いしない
- 外部センチメント禁止
- 依存追加禁止（matplotlibのみで描画）
