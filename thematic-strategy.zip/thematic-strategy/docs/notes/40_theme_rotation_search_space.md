# 40_theme_rotation_search_space

## 探索の基本原則

- 目的: 18ETF固定ユニバースで、T1/T2/T3の設計候補を比較し、OOSで頑健な1案を採択する。
- 探索対象は「パラメータ・結合方法」に限定し、データ源追加はしない。
- 先読み回避・0リターン禁止・外部センチメント禁止を常に優先。

## Allowed（探索可能）

### T1: Rotation Core
- トレンド窓: `21/63/126/252` 日の単独または加重和。
- リスクペナルティ: 実現ボラ（20/63）・下方半偏差（63）。
- attention proxy: 出来高z-score（20/60）、価格×出来高の異常度。
- 正規化: cross-sectional z-score / rank-normalize。
- 配分: Top-K（3-6）等ウェイト、上限制約は将来拡張。
- リバランス: 月次（基本）+ 四半期（比較のみ）。

### T2: Residual + Correlation Penalty
- 因子回帰窓: `126` or `252` 日。
- 残差シグナル: 残差モメンタム、残差Sharpe、残差下方リスク。
- 相関ペナルティ: 直近63日相関平均、選抜集合との逐次相関。
- factor_set（固定候補）:
  - `minimal_3`: [SPY, QQQ, IEF]
  - `minimal_5`: [SPY, QQQ, IWM, IEF, LQD]
  - `extended_10`: [SPY, QQQ, IWM, EFA, EEM, IEF, TLT, LQD, HYG, GLD]
  - `extended_12`: extended_10 + [VNQ, DBC]（DBC欠損時はPDBC）
  - `eqw_only`: [EQW]
  - `eqw_plus_rates`: [EQW, IEF]

### T3: Text Purity
- テキスト源: `objective_strategy_short` + `index_name`（固定）。
- 前処理: 正規化・ストップワード除去・語幹化なし（依存追加回避）。
- 類似度: Jaccard / cosine（bag-of-words）
- 統合方法: 加点（soft） or 閾値フィルタ（hard）
- 更新頻度: 月次または四半期。

### 評価軸（共通）
- train/test分割: `split_date` 固定。
- サブ期間: 2017-2019 / 2020-2021 / 2022-現在。
- 指標: Sharpe, CAGR, MDD, Turnover, Cost drag。
- 採択条件: test優位 + サブ期間の崩れが小さい + turnover過大でない。

### A案: ON/OFF overlay（Episodic Factor Pricing）

- 既存base strategyのスコア `S_{i,t}` に管理係数を掛ける:
  - `S^{managed}_{i,t} = (\eta + (1-\eta)I_t) S_{i,t}`
  - `I_t \in \{0,1\}` は全体single indicator（初期実装）。
- ON/OFF判定法（探索対象）:
  - Step A（最小）: 過去SEDの符号で `I_t` を決定（`SED_t>0` をON）。
  - Step B（拡張）: 状態変数 `Z_t`（lagged SED, SPY/IEF, ボラproxy）で `SED_{t+1}` を予測し、正ならON。
- retention ratio候補:
  - `\eta \in {0, 0.1, 0.2, 0.3, 0.5}`（まず `0, 0.2, 0.5` を実装）。
- 学習窓:
  - expanding window（推奨）または rolling（比較）。
  - いずれも `t` までで学習し `t+1` を予測（先読み禁止）。

## Forbidden（禁止）

- 外部センチメント（MediaStats/MMS/ニュース感情）導入。
- 将来情報の混入（forward return教師を実運用シグナルに利用）。
- ローンチ日前データの0埋め・0リターン化。
- 依存追加（必要なら提案のみ、即導入しない）。
- MSCI指数構成・スコアの再現配布。

## 候補数・採択ルール

- Phase 3で実装比較する候補は3〜5個。
- 最終1候補を `70_final_spec.md` に固定し、残りは棄却理由を記録する。
