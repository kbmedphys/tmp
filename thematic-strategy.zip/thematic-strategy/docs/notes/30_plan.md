# 30_plan

## Phase 2以降の実装分割（src）

- `config.py`
  - 実験設定（strategy_mode, rebalance, split_date, costs, exec_lag, top_k, lookbacks, factor_set）
  - `01_universe.csv` の読込を単一真実にする
- `data.py`
  - yfinance取得、raw/processedキャッシュ
  - `first_valid_date` と `investable_mask` の生成
  - 価格・出来高・リターン・EQW因子の整形
- `signals/t1.py`
  - 価格/出来高ベースのローテーションスコア（Phase2は最小構成）
- `signals/t2.py`
  - rolling回帰で残差系列を作り、残差モメンタム + 相関ペナルティ
- `signals/t3.py`
  - objective/index text から purity score を作り、T1/T2へ補正入力
- `portfolio.py`
  - score→rank→Top-K→weights
  - 非投資可能銘柄除外、将来の制約拡張点を残す
- `backtest.py`
  - リバランス、exec_lag、turnover、コスト控除、EQW比較
- `metrics.py`
  - NAV/Sharpe/MDD/CAGR/Vol/Turnover/Cost、train/test/サブ期間集計
- `reporting.py`
  - 図表生成、`outputs/figures` `outputs/tables` 保存

## main.ipynb 実行フロー

1. 設定読み込み（strategy_mode等）
2. データロード/整形（キャッシュ優先）
3. シグナル生成（T1/T2/T3）
4. ポートフォリオ構築
5. バックテスト
6. 指標・図表保存
7. 候補比較（Phase3）

## Phase 3探索運用

- `40_theme_rotation_search_space.md` の範囲内で候補3-5を実装。
- `60_experiment_registry.md` に毎回記録。
- 最終採択を `70_final_spec.md` に固定。
