# 72_T3_text_purity_spec

## 目的

`objective_strategy_short` と `index_name` のみを用いて、ETFが所属テーマにどれだけ整合しているか（Text Purity）を定量化し、
T1/T2スコアの補正またはフィルタに利用する。

## 入力

- `theme`
- `objective_strategy_short`
- `index_name`
- いずれも `docs/notes/01_universe.csv` 由来の静的データ

## 前処理

- 小文字化、記号除去、連続空白の正規化。
- 日本語・英語混在を許容した単純トークン分割（依存追加なし）。
- 共通ストップ語（ETF, index, fund, global など）を除外。

## スコア定義

1. ETF文書ベクトル
- `text_i = objective_i + " " + index_name_i`
- bag-of-words頻度ベクトル `v_i`

2. テーマ代表ベクトル
- 同一theme内ETFの `v_i` 平均を `v_theme` とする。

3. 類似度
- `sim_in = cosine(v_i, v_theme)`
- 他テーマ代表との最大類似度 `sim_out = max_{g!=theme_i} cosine(v_i, v_g)`

4. purity
- `purity_i = sim_in - λ_amb*sim_out`
- 正規化後 `purity_z_i` を利用。

## T1/T2との結合方法

- Soft結合（推奨）:
  - `score_final = score_base + λ_text * purity_z`
- Hardフィルタ（補助）:
  - `purity < threshold` の銘柄を選抜対象外

## 更新頻度

- テキストは静的前提のため、月次または四半期で再計算。
- CSVが更新された場合のみ再構築。

## 制約

- 外部ニュース、外部embedding API、外部LLM推論は使用しない。
- 将来情報（forward return等）でpurityを教師化しない。

## 実務的な期待効果

- テーマ定義の曖昧さを抑え、意図しないセクター偏りを低減。
- T2残差スコアが高くてもテーマ整合の低い銘柄を抑制可能。
