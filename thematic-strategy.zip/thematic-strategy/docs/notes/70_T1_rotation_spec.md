# 70_T1_rotation_spec

## 目的

外部センチメント（MediaStats等）を使わず、価格・出来高のみで「テーマ強弱の月次ローテーション」を実装する。
MSCI方式の骨格（ランキング→Top-K→配分）を踏襲しつつ、観測可能データだけで代替proxyを構成する。

## 入力

- `Adj Close_{i,t}`（18ETF）
- `Volume_{i,t}`（18ETF）
- `expense_ratio_i`（静的）
- `investable_mask_{i,t}`（ローンチ日前を除外）

## シグナル定義（一般形）

- トレンド:
  - `trend_{i,t} = w1*ret21 + w2*ret63 + w3*ret126 + w4*ret252`
- attention proxy（出来高異常）:
  - `attn_{i,t} = zscore(log(Volume_{i,t}) - mean_20(log(Volume_i)))`
- リスクペナルティ:
  - `risk_{i,t} = vol63(returns_i)`
  - `down_{i,t} = std(min(returns_i,0))` over 63d
- 総合スコア:
  - `score_{i,t} = z(trend) + λ_attn*z(attn) - λ_risk*z(risk) - λ_down*z(down) - λ_fee*z(expense)`

## ランキングと配分

- 判定日: リバランス日 `t`（月次デフォルト）
- 利用情報: `<= t - exec_lag`
- 投資可能集合: `I_t = {i | investable_mask_{i,t}=1}`
- 選定: `Top-K(score_{i,t}, i in I_t)`
- 配分（baseline）: 等ウェイト
  - `w_{i,t}=1/K` if selected else `0`

## Phase 2 最小構成（必ず動かす仕様）

- `trend = ret252`
- `λ_attn=0, λ_risk=0, λ_down=0, λ_fee=0`（まずは単純）
- `top_k=4`, `rebalance="M"`, `exec_lag=1`

## 拡張余地（Phase 3）

- attention/リスク/下方/経費率の重み最適化
- スコア平滑化によるturnover抑制
- T3 purityを加点/閾値として連結

## 先読み回避チェック

- リターン窓終端は必ず `t-exec_lag`。
- ローンチ日前は missing（0埋めしない）。
- 当日算出・当日約定を禁止。
