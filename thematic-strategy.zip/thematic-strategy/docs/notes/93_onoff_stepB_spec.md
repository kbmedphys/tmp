# 93_onoff_stepB_spec

## 目的（写経）

- A案 ON/OFF overlay を Step A（lagged SED符号）から Step B（状態変数 `Z` による予測）へ拡張する。
- managed score は固定:
  - `S^{managed}_{i,t} = (\eta + (1-\eta) I_t) S_{i,t}`
- Step B の indicator は以下で定義:
  - `I_t = 1[\widehat{SED}^{(M)}_{t+1|t} > 0]`
  - 学習は時点 `t` までの情報のみで `t+1` を予測（先読み禁止）。

## Step B ターゲット定義（写経）

- Step Aで定義済みの monthly `SED_t` を利用する。
- 実装候補:
  - 正規化あり: `y_t := SED_t / vol_mkt_t`
  - 簡略化: `y_t := SED_t`
- `vol_mkt_t` は EQW の月次実現ボラ（過去12ヶ月）を候補とする。

## 特徴量 `Z_t`（写経）

- 必須（内部データ）:
  - lagged SED: `{SED_{t-1}, SED_{t-3}, SED_{t-6}, SED_{t-12}}`
  - lagged EQW return: `{R^{EQW}_{t-1}, R^{EQW}_{t-3}}`
  - lagged EQW realized vol: `{RV^{EQW}_{12m,t-1}}`
  - クロスセクション分散: `CSVAR_{t-1} = Var_i(r_{i,t-1})`（投資可能ETFのみ）
  - 採用集中度 proxy: `DISP_{t-1} = Std_i(S_{i,t-1})`（または上位Kと平均との差）
- 任意（外部ETF価格、yfinance）:
  - SPY 月次リターン、IEF/TLT 月次リターン、`HYG-LQD` 差分など。

## 学習法（写経）

- 基本: expanding window OLS
  - `y_t = a + b' Z_{t-1} + e_t`
- optional: Lasso/ElasticNet（既存依存で可能なら）
- 予測:
  - `\widehat{y}_{t+1|t} = \hat a_t + \hat b_t' Z_t`
  - 正規化ありなら `\widehat{SED}_{t+1|t} = \widehat{y}_{t+1|t} vol_{mkt,t}`
  - `I_t = 1[\widehat{SED}_{t+1|t} > 0]`

## 追加 strategy_id（写経）

- `T1_best_onoff_statepred_M6_eta0`
- `T1_best_onoff_statepred_M6_eta0p2`
- `T1_best_onoff_statepred_M6_eta0p5`
- `T1_best_onoff_statepred_M12_eta0`
- `T1_best_onoff_statepred_M12_eta0p2`
- `T1_best_onoff_statepred_M12_eta0p5`

## 出力物（写経）

- `outputs/tables/onoff_stepB_features.csv`（date, 各Z）
- `outputs/tables/onoff_stepB_pred.csv`（date, y_hat, SED_hat, indicator, M）
- `outputs/tables/onoff_stepB_coef.csv`（date, coef名, 値）
- `outputs/figures/nav_all_strategies_with_onoff_stepB.png`
- `outputs/figures/nav_all_strategies_with_onoff_stepB_log.png`
- `outputs/tables/nav_summary_with_onoff_stepB.csv`

## 実装方針メモ（今回の単一真実）

- Step A（`method="lagged_sed"`）は保持し、Step B は `method="state_pred"` として追加する。
- 先読み防止のため、すべての特徴量は月次で `lag` を入れて時点整合させる。
- 外部センチメントは使わない。任意の外部ETF因子を使う場合は本ファイルに取得条件を追記する。

## 今回の実装採用（記録）

- 採用ターゲット:
  - `y_t = SED_t^{(M)} / vol_{mkt,t}`（`vol_{mkt,t}` は EQW 月次リターンの過去12ヶ月標準偏差）
- `M` は strategy ごとに `6` または `12` を使用。
- 学習モデル:
  - 既定は expanding OLS（`state_model="ols"`）
  - `lasso` は optional 経路として残す。
- 任意の外部ETF特徴量:
  - `SPY/IEF/TLT/HYG/LQD` の月次リターンを利用可能。
  - 取得元は既存 `yfinance` 日次データ（`factor_returns`）を月次集約して作成し、外部センチメントは不使用。
