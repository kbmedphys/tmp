# 50_candidate_log

候補は「実装可能」「先読みなし」「固定データ源のみ」を満たすものに限定する。

## 候補一覧（広めに列挙）

| ID | 系統 | 候補名 | 主要式/定義 | 反映したPDF論点 | 想定リスク/失敗 | 先読みチェック |
|---|---|---|---|---|---|---|
| C01 | T1 | 12-1モメンタム | `mom=ret_252-ret_21` | MSCIの月次順位、Allocatingのtrend活用 | レンジ相場で反転負け | t時点で`<=t-lag`のみ |
| C02 | T1 | マルチホライズントレンド | `0.5*ret126+0.3*ret63+0.2*ret21` | Allocatingの複数因子露出管理 | 窓過多で過学習 | 固定窓のみ比較 |
| C03 | T1 | リスク調整モメンタム | `mom/vol63` | Performance論文のrisk-adjust観点 | ボラ急変で不安定 | volも過去窓限定 |
| C04 | T1 | 下方リスク控除 | `score -= λ*downside63` | Allocatingのdownside管理 | 過度に守りで機会損失 | downsideは過去のみ |
| C05 | T1 | 出来高attention加点 | `+ λ*z(volume/avg20)` | MSCIのattention代替（外部sentiment禁止対応） | 出来高急増ノイズ | 当日値はlagで遅延利用 |
| C06 | T1 | 経費率ペナルティ | `- λ_fee*expense` | Allocatingの実務コスト意識 | 低コスト偏重 | 静的値のみ |
| C07 | T1 | スコア平滑化 | `score_t=0.7*score_{t-1}+0.3*raw_t` | turnover抑制（実務） | 追随遅れ | 前期スコアのみ |
| C08 | T2 | 残差モメンタム(minimal_3) | `eps`回帰後`ret_eps_63` | Allocatingのテーマ固有成分 | 回帰窓不足で不安定 | rolling OLSのみ |
| C09 | T2 | 残差Sharpe(minimal_5) | `mean(eps)/std(eps)` | Performanceのrisk-adjust評価 | 低ボラ偏重 | 過去窓固定 |
| C10 | T2 | 残差下方ペナルティ | `score -= λ*down_eps` | downside管理 | 守り過ぎ | forward不使用 |
| C11 | T2 | 相関クラウディング抑制 | `score -= λ*corr_with_selected` | MSCI集中回避 + Allocating分散 | 過罰で分散しすぎ | 相関は過去63日 |
| C12 | T2 | eqw_only因子 | `r_i ~ EQW` | 内生因子で被り除去 | 因子単純化過多 | EQWは投資可能のみ |
| C13 | T2 | eqw_plus_rates | `r_i ~ [EQW, IEF]` | 株式+金利の最小2軸 | レジーム依存 | lag/窓固定 |
| C14 | T3 | テキスト純度加点 | `purity = sim(theme,text)` | THEMEの意味整合（軽量化） | 文言ノイズ | 静的文書のみ |
| C15 | T3 | 曖昧性控除 | `purity -= max_other_theme_sim` | THEMEの識別性強化 | 過度な排除 | 同時点テキストのみ |
| C16 | T3 | purity閾値フィルタ | `purity<thrなら除外` | テーマ逸脱防止 | 投資可能銘柄減少 | 閾値は事前固定 |
| C17 | Cross | Turnover罰則 | `score -= λ_to*recent_turnover_proxy` | 実装可能性/コスト管理 | 売買不足 | 過去weightsのみ |
| C18 | Cross | Regime-aware λ | `λ_risk`をVIX代替で切替(価格由来) | Allocatingの環境依存 | ルール複雑化 | 外部指数なしで実装 |

## Phase 3で優先実装する候補群（3〜5個）

- P1: C01ベースT1（基準）
- P2: C05+C04を加えたT1拡張
- P3: C08+C11（T2 minimal_3）
- P4: C09+C11（T2 minimal_5）
- P5: P3にC14を加えたT2+T3ハイブリッド

