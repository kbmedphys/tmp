# 70_final_spec

## 採択戦略（最終）

- 採択ID: `P1_T1_baseline`
- 理由: test Sharpeが候補中最大で、turnoverが低く、サブ期間でマイナスSharpe区間がなかったため。
- 方式: T1（価格ベース・月次ローテーション）を最終戦略として固定。

## 採択指標（RobustScore）の定義

- Phase3では候補比較に次式を使用:
  - `RobustScore = TestSharpe - 0.50 * StabilitySharpeStd - 0.30 * AvgTurnover`
- 採択ルール:
  - RobustScore最大の候補を採択（同点時はTest Sharpeが高い方）。
- 実績:
  - `P1_T1_baseline` が `0.2698` で最大のため採択。

## 1. 最終スコア式

- 判定時点 `t` のシグナル（exec_lag=1）:
  - `trend_{i,t} = AdjClose_{i,t-1} / AdjClose_{i,t-1-252} - 1`
  - `score_{i,t} = zscore_cross_section(trend_{i,t})`
- 投資可能集合:
  - `I_t = {i | date >= first_valid_date_i}`
  - ローンチ日前は missing（0埋め禁止）
- 銘柄選定:
  - `Top-K(score_{i,t}, i in I_t)`, `K=4`
- 配分:
  - 選定銘柄を等ウェイト（各25%）

## 2. 取引ルール・コスト

- リバランス: 月次（各月末営業日判定）
- 執行ラグ: `exec_lag=1`（翌営業日約定）
- 取引コスト: `fee_bps=10`, `slippage_bps=1`
- 保有コスト: `expense_ratio` を日割り控除

## 3. 先読み回避の実装ポイント

- すべてのシグナル窓は `t-1` まで（当日データを使わない）
- factor ETFや外部ニュースは最終戦略で不使用
- non-investable期間を厳格に除外し、0リターン補完しない

## 4. 検証結果（Phase 3最終）

### 4.1 train/test（split_date = 2021-01-01）

- Strategy（P1_T1_baseline）
  - Train: Sharpe `0.975`, CAGR `0.210`, MDD `-0.361`, AvgTurnover `0.071`
  - Test: Sharpe `0.437`, CAGR `0.353`, MDD `-0.485`, AvgTurnover `0.114`
- EQW benchmark
  - Train: Sharpe `0.859`, CAGR `0.171`, MDD `-0.369`
  - Test: Sharpe `0.338`, CAGR `0.268`, MDD `-0.382`

### 4.2 サブ期間安定性（Strategy）

- 2017-2019: Sharpe `0.654`
- 2020-2021: Sharpe `1.077`
- 2022-現在: Sharpe `0.589`

## 5. 候補比較と不採択理由（要約）

- P2（T1 attention/downside）: test Sharpeは正だが turnover過大（約0.50）。
- P3（T2 minimal_3）: 2022年以降のSharpe低下が大きい。
- P4（T2 minimal_5 risk-aware）: test SharpeがP1未満。
- P5（T3 hybrid）: MDD改善はあるがtest SharpeでP1に劣後。

## 6. 実行手順（固定）

1. `main.ipynb` を上から実行
2. `phase2_metrics_t1_vs_eqw.csv` / `phase3_candidate_summary.csv` を確認
3. 最終確認は `phase3_best_metrics.csv` と `phase3_best_stability.csv`

出力保存先:
- `outputs/figures/phase3_best_nav_vs_eqw.png`
- `outputs/figures/phase3_best_turnover_vs_eqw.png`
- `outputs/tables/phase3_best_metrics.csv`
- `outputs/tables/phase3_best_stability.csv`
