# 10_requirements

## 1. 固定目的と投資対象

- 運用対象は固定18ETFのみ（AIQ, BOTZ, SMH, WCLD, CIBR, IPAY, ICLN, TAN, DRIV, LIT, UFO, ITA, ARKG, PHO, MOO, PAVE, ESPO, KOMP）。
- 研究系統は T1 → T2 → T3 の順で実装・比較。
- 外部センチメント（MediaStats/MMS/ニュース感情等）は禁止。

## 2. 入力データ要件

- 価格系列: yfinance の日次 Adjusted Close（必須）。
- 売買代金proxy: 日次 Volume（必須）。
- 経費率: `01_universe.csv`（基本）+ yfinance info（取得できれば照合）。
- テキスト: `objective_strategy_short`, `index_name`（`01_universe.csv`）。
- T2説明変数ETF: 指定factor_setの価格（日次、non-investable）。

## 3. データ整合・先読み回避

- 各ETFの `first_valid_date` をローンチ日とみなす。
- ローンチ日前は **missing（非投資可能）** とし、0リターン補完は禁止。
- シグナル計算・ランキングは `t - exec_lag` までの情報のみ使用。
- リターン系列は観測可能な価格対からのみ計算。

## 4. 共通インタフェース（T1/T2/T3）

- 3系統とも以下を統一する。
  - `score(date, asset) -> rank(date) -> weights(date)`
- 形式定義:
  - `raw_signal_{i,t} = f_mode(X_{i,<=t-exec_lag})`
  - `score_{i,t} = normalize(raw_signal_{i,t})`
  - `rank_t = argsort(score_{:,t}, descending=True)`
  - `weights_t = g(rank_t, top_k, constraints)`
- `g` の初期実装は Top-K 等ウェイト、将来は制約付き最適化へ拡張可能。

## 5. リバランス/執行要件

- 既定リバランス頻度: 月次（`rebalance="M"`）。
- 既定選抜数: `top_k=4`。
- `exec_lag=1`（シグナル確定翌営業日執行）を既定。
- 取引不可能銘柄はその時点のランキング対象から除外。

## 6. コスト要件

- 取引コスト: `fee_bps + slippage_bps` をturnoverに乗じて控除。
- 保有コスト: 経費率（年率）を日割りで控除。
- ネット収益:
  - `r_net,t = r_gross,t - tc_t - expense_t`

## 7. 出力要件

- 最低限の出力:
  - 日次/累積NAV（strategy, EQW）
  - 日次turnover
  - 指標表（Sharpe, MDD, CAGR, Vol, 平均turnover, 総コスト）
- 保存先は `outputs/figures`, `outputs/tables`, `outputs/logs`。

## 8. 評価要件

- split_date（既定 `2021-01-01`）で train/test を分割。
- 指標は全期間・train・testで算出。
- サブ期間（例: 2017-2019 / 2020-2021 / 2022-現在）安定性を確認。
- 比較ベンチマークは「投資可能ETFのみ等ウェイトのEQW」。

## 9. 禁止事項（必須）

- 外部センチメント導入、先読み、0リターン埋め、依存追加、MSCI指数再現配布。
