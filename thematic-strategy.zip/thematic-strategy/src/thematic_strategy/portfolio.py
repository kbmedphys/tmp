"""Portfolio construction utilities (score -> rank -> weights)."""

from __future__ import annotations

import numpy as np
import pandas as pd


def make_rebalance_mask(index: pd.DatetimeIndex, freq: str = "M") -> pd.Series:
    """Return True on period-end dates for rebalancing."""
    if freq not in {"M", "Q"}:
        raise ValueError("freq must be 'M' or 'Q'")

    periods = index.to_period(freq)
    mask = periods != periods.shift(-1)
    return pd.Series(mask, index=index, name="rebalance_mask").astype(bool)


def _select_top_k(scores: pd.Series, top_k: int) -> list[str]:
    valid = scores.dropna().sort_values(ascending=False)
    if valid.empty:
        return []
    return list(valid.head(top_k).index)


def build_target_weights(
    score: pd.DataFrame,
    investable_mask: pd.DataFrame,
    top_k: int,
    rebalance_freq: str = "M",
) -> tuple[pd.DataFrame, pd.Series]:
    """Construct target weights at each rebalance date and forward-fill holdings."""
    rebalance_mask = make_rebalance_mask(score.index, freq=rebalance_freq)
    target = pd.DataFrame(np.nan, index=score.index, columns=score.columns)

    for date in score.index[rebalance_mask]:
        row_score = score.loc[date]
        eligible = investable_mask.loc[date] & row_score.notna()
        eligible_scores = row_score.where(eligible)

        selected = _select_top_k(eligible_scores, top_k=top_k)
        row_weight = pd.Series(0.0, index=score.columns)
        if selected:
            equal_weight = 1.0 / len(selected)
            row_weight.loc[selected] = equal_weight

        target.loc[date] = row_weight

    holdings = target.ffill().fillna(0.0)
    holdings = holdings.where(investable_mask, 0.0)

    # Renormalize among investable holdings to avoid numerical drift.
    row_sum = holdings.sum(axis=1)
    holdings = holdings.div(row_sum.where(row_sum > 0.0), axis=0).fillna(0.0)

    return holdings, rebalance_mask
