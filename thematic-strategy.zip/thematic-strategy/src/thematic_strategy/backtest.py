"""Backtest engine with execution lag, turnover, and costs."""

from __future__ import annotations

import pandas as pd

from .portfolio import make_rebalance_mask


def _normalize_weights(weights: pd.DataFrame) -> pd.DataFrame:
    row_sum = weights.sum(axis=1)
    return weights.div(row_sum.where(row_sum > 0.0), axis=0).fillna(0.0)


def _build_eqw_holdings(index: pd.DatetimeIndex, investable_mask: pd.DataFrame, rebalance_freq: str) -> pd.DataFrame:
    rebalance_mask = make_rebalance_mask(index, freq=rebalance_freq)
    eqw_target = pd.DataFrame(index=index, columns=investable_mask.columns, dtype=float)

    for date in index[rebalance_mask]:
        eligible = investable_mask.loc[date]
        row = pd.Series(0.0, index=investable_mask.columns)
        n = int(eligible.sum())
        if n > 0:
            row.loc[eligible[eligible].index] = 1.0 / n
        eqw_target.loc[date] = row

    eqw_holdings = eqw_target.ffill().fillna(0.0)
    eqw_holdings = eqw_holdings.where(investable_mask, 0.0)
    return _normalize_weights(eqw_holdings)


def _compute_portfolio_path(
    holdings: pd.DataFrame,
    returns: pd.DataFrame,
    expense_ratio: pd.Series,
    fee_bps: float,
    slippage_bps: float,
) -> dict[str, pd.Series]:
    holdings = holdings.fillna(0.0)
    ret = returns.copy()

    # Missing return on a day is handled as "not invested that day" (not 0-return imputation).
    available_mask = ret.notna()
    effective_holdings = holdings.where(available_mask, 0.0)
    effective_holdings = _normalize_weights(effective_holdings)

    gross = (effective_holdings * ret).sum(axis=1)

    prev = holdings.shift(1).fillna(0.0)
    turnover = (holdings - prev).abs().sum(axis=1)

    trade_cost = turnover * (fee_bps + slippage_bps) / 10000.0
    expense_daily = (effective_holdings * (expense_ratio.reindex(holdings.columns).fillna(0.0) / 252.0)).sum(axis=1)

    net = gross - trade_cost - expense_daily
    nav = (1.0 + net.fillna(0.0)).cumprod()

    missing_active_mask = holdings.gt(0.0) & ret.isna()
    missing_active_days = missing_active_mask.any(axis=1).astype(int)

    return {
        "gross_returns": gross,
        "net_returns": net,
        "nav": nav,
        "turnover": turnover,
        "trading_cost": trade_cost,
        "expense_cost": expense_daily,
        "effective_holdings": effective_holdings,
        "missing_active_days": missing_active_days,
    }


def run_backtest(
    target_weights: pd.DataFrame,
    returns: pd.DataFrame,
    investable_mask: pd.DataFrame,
    expense_ratio: pd.Series,
    fee_bps: float,
    slippage_bps: float,
    exec_lag: int,
    rebalance_freq: str,
) -> dict[str, pd.DataFrame | pd.Series]:
    """Run strategy and EQW benchmark backtest."""
    executed_weights = target_weights.shift(exec_lag).ffill().fillna(0.0)
    executed_weights = executed_weights.where(investable_mask, 0.0)
    executed_weights = _normalize_weights(executed_weights)

    strategy = _compute_portfolio_path(
        holdings=executed_weights,
        returns=returns,
        expense_ratio=expense_ratio,
        fee_bps=fee_bps,
        slippage_bps=slippage_bps,
    )

    eqw_holdings = _build_eqw_holdings(index=returns.index, investable_mask=investable_mask, rebalance_freq=rebalance_freq)
    eqw = _compute_portfolio_path(
        holdings=eqw_holdings,
        returns=returns,
        expense_ratio=expense_ratio,
        fee_bps=fee_bps,
        slippage_bps=slippage_bps,
    )

    return {
        "target_weights": target_weights,
        "executed_weights": executed_weights,
        "strategy_effective_holdings": strategy["effective_holdings"],
        "strategy_nav": strategy["nav"],
        "strategy_net_returns": strategy["net_returns"],
        "strategy_gross_returns": strategy["gross_returns"],
        "strategy_turnover": strategy["turnover"],
        "strategy_trading_cost": strategy["trading_cost"],
        "strategy_expense_cost": strategy["expense_cost"],
        "strategy_missing_active_days": strategy["missing_active_days"],
        "eqw_weights": eqw_holdings,
        "eqw_effective_holdings": eqw["effective_holdings"],
        "eqw_nav": eqw["nav"],
        "eqw_net_returns": eqw["net_returns"],
        "eqw_turnover": eqw["turnover"],
        "eqw_trading_cost": eqw["trading_cost"],
        "eqw_expense_cost": eqw["expense_cost"],
        "eqw_missing_active_days": eqw["missing_active_days"],
    }
