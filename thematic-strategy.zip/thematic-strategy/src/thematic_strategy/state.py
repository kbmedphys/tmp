"""State/overlay utilities for episodic ON/OFF management."""

from __future__ import annotations

import numpy as np
import pandas as pd


def _normalize_weights(weights: pd.DataFrame) -> pd.DataFrame:
    row_sum = weights.sum(axis=1)
    return weights.div(row_sum.where(row_sum > 0.0), axis=0).fillna(0.0)


def _build_topk_weights(scores: pd.DataFrame, top_k: int) -> pd.DataFrame:
    weights = pd.DataFrame(0.0, index=scores.index, columns=scores.columns)
    for dt in scores.index:
        row = scores.loc[dt].dropna().sort_values(ascending=False)
        if row.empty:
            continue
        selected = row.head(top_k).index
        weights.loc[dt, selected] = 1.0 / len(selected)
    return weights


def _to_monthly_compound(daily: pd.Series) -> pd.Series:
    monthly = (1.0 + daily.fillna(0.0)).groupby(daily.index.to_period("M")).prod() - 1.0
    monthly.index = monthly.index.to_timestamp("M")
    return monthly


def _to_monthly_last(daily: pd.Series) -> pd.Series:
    monthly = daily.groupby(daily.index.to_period("M")).last()
    monthly.index = monthly.index.to_timestamp("M")
    return monthly


def _derive_base_and_benchmark_returns(
    base_scores: pd.DataFrame,
    future_returns: pd.DataFrame,
    top_k: int,
    exec_lag: int,
) -> tuple[pd.Series, pd.Series]:
    base_scores = base_scores.reindex(index=future_returns.index, columns=future_returns.columns)
    weights_target = _build_topk_weights(base_scores, top_k=top_k)
    weights_exec = weights_target.shift(exec_lag).ffill().fillna(0.0)

    available = future_returns.notna()
    eff_w = _normalize_weights(weights_exec.where(available, 0.0))
    base_ret = (eff_w * future_returns).sum(axis=1, min_count=1).fillna(0.0)
    bench_ret = future_returns.mean(axis=1, skipna=True).fillna(0.0)
    return base_ret.rename("base_ret"), bench_ret.rename("bench_ret")


def compute_sed(
    y_true: pd.Series,
    y_pred: pd.Series,
    demean: bool = True,
) -> pd.Series:
    """Compute SED_t = y_true_t - y_pred_t (optional expanding demean)."""
    aligned = pd.concat([y_true.rename("y_true"), y_pred.rename("y_pred")], axis=1).dropna(how="all")
    sed = aligned["y_true"].fillna(0.0) - aligned["y_pred"].fillna(0.0)
    if demean:
        sed = sed - sed.expanding(min_periods=1).mean()
    sed.name = "sed"
    return sed


def _fit_lasso(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_pred: np.ndarray,
    alpha: float,
) -> tuple[float, np.ndarray]:
    try:
        from sklearn.linear_model import Lasso

        model = Lasso(alpha=alpha, fit_intercept=True, max_iter=20000)
        model.fit(x_train, y_train)
        y_hat = float(model.predict(x_pred.reshape(1, -1))[0])
        coef = np.concatenate([[float(model.intercept_)], model.coef_.astype(float)])
        return y_hat, coef
    except Exception:  # noqa: BLE001
        # fallback to OLS
        x_ols = np.column_stack([np.ones(len(x_train)), x_train])
        beta, *_ = np.linalg.lstsq(x_ols, y_train, rcond=None)
        x_pred_ols = np.concatenate([[1.0], x_pred])
        return float(x_pred_ols @ beta), beta.astype(float)


def _fit_ols(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_pred: np.ndarray,
) -> tuple[float, np.ndarray]:
    x_ols = np.column_stack([np.ones(len(x_train)), x_train])
    beta, *_ = np.linalg.lstsq(x_ols, y_train, rcond=None)
    x_pred_ols = np.concatenate([[1.0], x_pred])
    y_hat = float(x_pred_ols @ beta)
    return y_hat, beta.astype(float)


def _build_state_pred_dataset(
    base_scores: pd.DataFrame,
    future_returns: pd.DataFrame,
    factor_returns: pd.DataFrame | None,
    top_k: int,
    exec_lag: int,
    target_m: int,
    use_vol_norm: bool,
    demean: bool,
) -> dict[str, pd.DataFrame | pd.Series]:
    base_ret_daily, eqw_ret_daily = _derive_base_and_benchmark_returns(
        base_scores=base_scores,
        future_returns=future_returns,
        top_k=top_k,
        exec_lag=exec_lag,
    )

    base_m = _to_monthly_compound(base_ret_daily)
    eqw_m = _to_monthly_compound(eqw_ret_daily)
    sed_m = compute_sed(base_m, eqw_m, demean=demean).rename("sed_m")
    sed_target = sed_m.rolling(target_m, min_periods=max(2, target_m // 2)).mean().rename("sed_target")

    vol_mkt = eqw_m.rolling(12, min_periods=6).std().rename("vol_mkt")
    if use_vol_norm:
        y = (sed_target / vol_mkt.replace(0.0, np.nan)).rename("y")
    else:
        y = sed_target.rename("y")

    # Required internal features at month t (to predict t+1 via lag structure).
    features = pd.DataFrame(index=sed_target.index)
    features["SED_lag1"] = sed_target.shift(1)
    features["SED_lag3"] = sed_target.shift(3)
    features["SED_lag6"] = sed_target.shift(6)
    features["SED_lag12"] = sed_target.shift(12)
    features["EQW_ret_lag1"] = eqw_m.shift(1)
    features["EQW_ret_lag3"] = eqw_m.rolling(3, min_periods=3).sum().shift(1)
    features["RV_EQW_12m_lag1"] = vol_mkt.shift(1)

    csvar_daily = future_returns.var(axis=1, skipna=True)
    features["CSVAR_lag1"] = _to_monthly_last(csvar_daily).reindex(features.index).shift(1)

    disp_daily = base_scores.std(axis=1, skipna=True)
    features["DISP_lag1"] = _to_monthly_last(disp_daily).reindex(features.index).shift(1)

    # Optional external ETFs (still price-based; no sentiment).
    if factor_returns is not None and not factor_returns.empty:
        f_monthly = factor_returns.groupby(factor_returns.index.to_period("M")).apply(
            lambda x: (1.0 + x.fillna(0.0)).prod() - 1.0
        )
        if isinstance(f_monthly.index, pd.MultiIndex):
            f_monthly.index = f_monthly.index.get_level_values(0)
        f_monthly.index = pd.PeriodIndex(f_monthly.index, freq="M").to_timestamp("M")
        for col in ("SPY", "IEF", "TLT"):
            if col in f_monthly.columns:
                features[f"{col}_ret_lag1"] = f_monthly[col].reindex(features.index).shift(1)
        if {"HYG", "LQD"} <= set(f_monthly.columns):
            features["HYG_LQD_lag1"] = (
                f_monthly["HYG"].reindex(features.index).shift(1) - f_monthly["LQD"].reindex(features.index).shift(1)
            )

    return {
        "base_ret_daily": base_ret_daily,
        "eqw_ret_daily": eqw_ret_daily,
        "base_m": base_m,
        "eqw_m": eqw_m,
        "sed_m": sed_m,
        "sed_target": sed_target,
        "vol_mkt": vol_mkt,
        "y": y,
        "features": features,
    }


def _run_expanding_state_pred(
    y: pd.Series,
    features: pd.DataFrame,
    vol_mkt: pd.Series,
    target_m: int,
    min_train: int,
    use_vol_norm: bool,
    model: str,
    lasso_alpha: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    y_hat = pd.Series(np.nan, index=y.index, name="y_hat")
    sed_hat = pd.Series(np.nan, index=y.index, name="sed_hat")
    indicator = pd.Series(0.0, index=y.index, name="indicator")

    coef_records: list[dict[str, object]] = []

    for t in range(min_train, len(y.index)):
        y_train = y.iloc[:t]
        x_train_full = features.iloc[:t].copy()
        x_pred_full = features.iloc[t : t + 1].copy()

        train_df = pd.concat([x_train_full, y_train.rename("y")], axis=1).dropna(subset=["y"])
        if train_df.empty:
            continue

        feature_cols = [c for c in x_train_full.columns if train_df[c].notna().sum() >= max(12, min_train // 3)]
        if not feature_cols:
            continue

        x_train = train_df[feature_cols].copy()
        med = x_train.median()
        x_train = x_train.fillna(med)
        y_train_np = train_df["y"].to_numpy(dtype=float)

        x_pred = x_pred_full[feature_cols].copy().fillna(med)
        if x_pred.isna().all(axis=1).iloc[0]:
            continue

        x_train_np = x_train.to_numpy(dtype=float)
        x_pred_np = x_pred.iloc[0].to_numpy(dtype=float)

        if model == "lasso":
            pred, beta = _fit_lasso(
                x_train=x_train_np,
                y_train=y_train_np,
                x_pred=x_pred_np,
                alpha=lasso_alpha,
            )
        else:
            pred, beta = _fit_ols(
                x_train=x_train_np,
                y_train=y_train_np,
                x_pred=x_pred_np,
            )

        date = y.index[t]
        y_hat.iloc[t] = pred
        if use_vol_norm:
            sed_hat.iloc[t] = pred * float(vol_mkt.iloc[t]) if pd.notna(vol_mkt.iloc[t]) else np.nan
        else:
            sed_hat.iloc[t] = pred
        indicator.iloc[t] = float(sed_hat.iloc[t] > 0.0) if pd.notna(sed_hat.iloc[t]) else 0.0

        coef_records.append({"date": date, "coef_name": "intercept", "coef_value": float(beta[0]), "M": int(target_m)})
        for j, col in enumerate(feature_cols, start=1):
            coef_records.append({"date": date, "coef_name": col, "coef_value": float(beta[j]), "M": int(target_m)})

    pred_df = pd.DataFrame(
        {
            "y": y,
            "y_hat": y_hat,
            "sed_hat": sed_hat,
            "indicator": indicator.fillna(0.0),
            "M": int(target_m),
        },
        index=y.index,
    )
    pred_df.index.name = "date"
    coef_df = pd.DataFrame(coef_records)
    return pred_df, coef_df


def compute_onoff_indicator(
    dates: pd.DatetimeIndex | pd.Index,
    base_scores: pd.DataFrame | None = None,
    future_returns: pd.DataFrame | None = None,
    method: str = "lagged_sed",
    *,
    base_returns: pd.Series | None = None,
    benchmark_returns: pd.Series | None = None,
    factor_returns: pd.DataFrame | None = None,
    top_k: int = 4,
    exec_lag: int = 1,
    lookback: int = 63,
    min_train: int = 126,
    demean: bool = True,
    state_features: pd.DataFrame | None = None,
    lasso_alpha: float = 1e-3,
    target_m: int = 6,
    use_vol_norm: bool = True,
    state_model: str = "ols",
) -> pd.DataFrame:
    """
    Estimate ON/OFF indicator I_t without look-ahead.

    - lagged_sed: I_t = 1[ rolling_mean(SED)_{t-1} > 0 ]
    - lasso: expanding-window daily one-step forecast of SED.
    - state_pred: monthly expanding prediction with state variables Z.
    """
    if method not in {"lagged_sed", "lasso", "state_pred"}:
        raise ValueError("method must be one of {'lagged_sed', 'lasso', 'state_pred'}")
    if state_model not in {"ols", "lasso"}:
        raise ValueError("state_model must be one of {'ols', 'lasso'}")

    idx = pd.DatetimeIndex(dates)

    if base_returns is None or benchmark_returns is None:
        if base_scores is None or future_returns is None:
            raise ValueError("Either (base_returns, benchmark_returns) or (base_scores, future_returns) is required.")
        base_ret, bench_ret = _derive_base_and_benchmark_returns(
            base_scores=base_scores,
            future_returns=future_returns,
            top_k=top_k,
            exec_lag=exec_lag,
        )
    else:
        base_ret = base_returns.rename("base_ret")
        bench_ret = benchmark_returns.rename("bench_ret")

    aligned_ret = pd.concat([base_ret, bench_ret], axis=1).reindex(idx)
    sed_raw = (aligned_ret["base_ret"].fillna(0.0) - aligned_ret["bench_ret"].fillna(0.0)).rename("sed_raw")
    sed = compute_sed(aligned_ret["base_ret"], aligned_ret["bench_ret"], demean=demean).reindex(idx)
    sed_roll = sed.rolling(lookback, min_periods=max(10, lookback // 3)).mean().rename("sed_roll")

    pred = pd.Series(np.nan, index=idx, name="sed_pred")
    stepb_features = pd.DataFrame()
    stepb_pred = pd.DataFrame()
    stepb_coef = pd.DataFrame()

    if method == "lagged_sed":
        pred = sed_roll.shift(1)
        indicator = (pred > 0.0).astype(float)

    elif method == "lasso":
        if state_features is None:
            state_features = pd.DataFrame(index=idx)
            state_features["lagged_sed"] = sed.shift(1)
            state_features["lagged_sed_roll"] = sed_roll.shift(1)
            state_features["lagged_sed_vol"] = sed.shift(1).rolling(21, min_periods=10).std()
        else:
            state_features = state_features.reindex(idx).copy()
            for col in state_features.columns:
                state_features[col] = state_features[col].shift(1)
            state_features["lagged_sed"] = sed.shift(1)

        y_next = sed.shift(-1)
        for t in range(min_train, len(idx)):
            x_train = state_features.iloc[:t]
            y_train = y_next.iloc[:t]
            if y_train.dropna().shape[0] < min_train:
                continue
            x_pred = state_features.iloc[t : t + 1]
            if x_pred.dropna(axis=1, how="all").empty:
                continue
            pred.iloc[t] = _fit_lasso(
                x_train=x_train.fillna(0.0).to_numpy(dtype=float),
                y_train=y_train.fillna(0.0).to_numpy(dtype=float),
                x_pred=x_pred.fillna(0.0).iloc[0].to_numpy(dtype=float),
                alpha=lasso_alpha,
            )[0]
        indicator = (pred > 0.0).astype(float)

    else:  # state_pred
        if base_scores is None or future_returns is None:
            raise ValueError("state_pred requires base_scores and future_returns")

        ds = _build_state_pred_dataset(
            base_scores=base_scores,
            future_returns=future_returns,
            factor_returns=factor_returns,
            top_k=top_k,
            exec_lag=exec_lag,
            target_m=target_m,
            use_vol_norm=use_vol_norm,
            demean=demean,
        )
        stepb_features = ds["features"].copy()
        stepb_features["M"] = int(target_m)

        pred_monthly, coef_df = _run_expanding_state_pred(
            y=ds["y"],
            features=ds["features"],
            vol_mkt=ds["vol_mkt"],
            target_m=target_m,
            min_train=min_train,
            use_vol_norm=use_vol_norm,
            model=state_model,
            lasso_alpha=lasso_alpha,
        )
        stepb_pred = pred_monthly.copy()
        stepb_pred["vol_mkt"] = ds["vol_mkt"]
        stepb_pred["sed_target"] = ds["sed_target"]
        stepb_coef = coef_df.copy()

        month_key = idx.to_period("M").to_timestamp("M")
        pred = stepb_pred["sed_hat"].reindex(month_key).set_axis(idx)
        indicator = stepb_pred["indicator"].reindex(month_key).set_axis(idx).fillna(0.0)

    indicator = indicator.reindex(idx).fillna(0.0).rename("indicator")
    out = pd.DataFrame(
        {
            "sed_raw": sed_raw.reindex(idx),
            "sed_demeaned": sed.reindex(idx),
            "sed_roll": sed_roll.reindex(idx),
            "sed_pred": pred.reindex(idx),
            "indicator": indicator,
        },
        index=idx,
    )
    out.index.name = "date"
    out.attrs["stepb_features"] = stepb_features
    out.attrs["stepb_pred"] = stepb_pred
    out.attrs["stepb_coef"] = stepb_coef
    return out
