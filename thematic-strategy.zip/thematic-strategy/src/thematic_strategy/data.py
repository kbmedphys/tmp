"""Data loading, caching, and preprocessing for thematic strategy."""

from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd
import yfinance as yf

from .config import StrategyConfig, ensure_directories


def _read_csv_with_date_index(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, index_col=0, parse_dates=True)
    frame.index = pd.to_datetime(frame.index).tz_localize(None)
    frame = frame.sort_index()
    frame.columns = [str(col) for col in frame.columns]
    return frame


def _write_csv(frame: pd.DataFrame, path: Path) -> None:
    frame.sort_index().to_csv(path)


def _is_valid_price_frame(frame: pd.DataFrame) -> bool:
    return (not frame.empty) and (not frame.dropna(how="all").empty)


def _is_valid_factor_frame(frame: pd.DataFrame, factor_tickers: list[str]) -> bool:
    market_factors = [ticker for ticker in factor_tickers if ticker != "EQW"]
    if not market_factors:
        return True
    if frame.empty or frame.dropna(how="all").empty:
        return False
    available = [
        ticker
        for ticker in market_factors
        if ticker in frame.columns and frame[ticker].dropna().any()
    ]
    return len(available) > 0


def _extract_field(raw: pd.DataFrame, tickers: list[str], field: str) -> pd.DataFrame:
    if raw.empty:
        return pd.DataFrame(columns=tickers)

    if isinstance(raw.columns, pd.MultiIndex):
        if field not in raw.columns.get_level_values(0):
            return pd.DataFrame(index=raw.index, columns=tickers, dtype=float)
        field_df = raw[field].copy()
        if isinstance(field_df, pd.Series):
            # single ticker can still collapse to Series
            field_df = field_df.to_frame(name=tickers[0])
        field_df = field_df.reindex(columns=tickers)
        return field_df

    if field not in raw.columns:
        return pd.DataFrame(index=raw.index, columns=tickers, dtype=float)

    series = raw[field]
    if isinstance(series, pd.Series):
        return series.to_frame(name=tickers[0])
    out = series.copy()
    out.columns = tickers[: out.shape[1]]
    return out


def _download_chunk(tickers: list[str], start: str, end: str | None, retries: int = 3) -> pd.DataFrame:
    last_error: Exception | None = None
    for attempt in range(retries):
        try:
            data = yf.download(
                tickers=tickers,
                start=start,
                end=end,
                interval="1d",
                auto_adjust=False,
                actions=False,
                progress=False,
                group_by="column",
                threads=False,
            )
            if not data.empty:
                return data
        except Exception as exc:  # noqa: BLE001
            last_error = exc
        time.sleep(1.5 * (attempt + 1))

    if last_error is not None:
        raise RuntimeError(f"yfinance download failed for {tickers}: {last_error}")
    return pd.DataFrame()


def download_price_volume(
    tickers: list[str],
    start: str,
    end: str | None,
    chunk_size: int = 8,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Download Adj Close and Volume with chunking to reduce throttling."""
    if not tickers:
        idx = pd.DatetimeIndex([], name="Date")
        return pd.DataFrame(index=idx), pd.DataFrame(index=idx)

    adj_chunks: list[pd.DataFrame] = []
    vol_chunks: list[pd.DataFrame] = []
    for i in range(0, len(tickers), chunk_size):
        chunk = tickers[i : i + chunk_size]
        raw = _download_chunk(chunk, start=start, end=end)
        adj = _extract_field(raw, chunk, "Adj Close")
        vol = _extract_field(raw, chunk, "Volume")
        adj_chunks.append(adj)
        vol_chunks.append(vol)

    adj_close = pd.concat(adj_chunks, axis=1).sort_index()
    volume = pd.concat(vol_chunks, axis=1).sort_index()

    adj_close.index = pd.to_datetime(adj_close.index).tz_localize(None)
    volume.index = pd.to_datetime(volume.index).tz_localize(None)

    adj_close = adj_close.loc[:, ~adj_close.columns.duplicated()].reindex(columns=tickers)
    volume = volume.loc[:, ~volume.columns.duplicated()].reindex(columns=tickers)

    return adj_close.astype(float), volume.astype(float)


def compute_first_valid_dates(adj_close: pd.DataFrame) -> pd.Series:
    first_valid = {}
    for ticker in adj_close.columns:
        first_valid[ticker] = adj_close[ticker].first_valid_index()
    return pd.Series(first_valid, name="first_valid_date")


def build_investable_mask(adj_close: pd.DataFrame, first_valid_dates: pd.Series) -> pd.DataFrame:
    mask = pd.DataFrame(False, index=adj_close.index, columns=adj_close.columns)
    for ticker in adj_close.columns:
        start = first_valid_dates.get(ticker)
        if pd.isna(start) or start is None:
            continue
        mask.loc[mask.index >= pd.Timestamp(start), ticker] = True
    return mask


def compute_returns(adj_close: pd.DataFrame, investable_mask: pd.DataFrame) -> pd.DataFrame:
    returns = adj_close.pct_change(fill_method=None)
    returns = returns.where(investable_mask)
    return returns


def compute_eqw_factor(returns: pd.DataFrame, investable_mask: pd.DataFrame) -> pd.Series:
    valid_returns = returns.where(investable_mask)
    eqw = valid_returns.mean(axis=1, skipna=True)
    eqw.name = "EQW"
    return eqw


def _raw_paths(cfg: StrategyConfig) -> dict[str, Path]:
    raw_dir = cfg.data_dir / "raw"
    ensure_directories([raw_dir])
    return {
        "adj_close": raw_dir / "investable_adj_close.csv",
        "volume": raw_dir / "investable_volume.csv",
        "factor_adj_close": raw_dir / f"factor_adj_close_{cfg.factor_set}.csv",
    }


def _processed_paths(cfg: StrategyConfig) -> dict[str, Path]:
    proc_dir = cfg.data_dir / "processed"
    ensure_directories([proc_dir])
    return {
        "returns": proc_dir / "investable_returns.csv",
        "investable_mask": proc_dir / "investable_mask.csv",
        "first_valid_dates": proc_dir / "first_valid_dates.csv",
        "factor_returns": proc_dir / f"factor_returns_{cfg.factor_set}.csv",
        "eqw": proc_dir / "eqw_factor.csv",
    }


def _load_cached_raw(paths: dict[str, Path]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame] | None:
    required = [paths["adj_close"], paths["volume"], paths["factor_adj_close"]]
    if not all(path.exists() for path in required):
        return None
    adj_close = _read_csv_with_date_index(paths["adj_close"])
    volume = _read_csv_with_date_index(paths["volume"])
    factor_adj_close = _read_csv_with_date_index(paths["factor_adj_close"])

    # Reject corrupted/empty cache files and trigger redownload.
    if adj_close.empty or volume.empty:
        return None
    if adj_close.dropna(how="all").empty:
        return None
    # factor_adj_close may be empty only when factor_set is EQW-only.
    factor_file = paths["factor_adj_close"].name
    if "eqw_only" not in factor_file and factor_adj_close.dropna(how="all").empty:
        return None

    return adj_close, volume, factor_adj_close


def _prepare_factor_prices(
    cfg: StrategyConfig,
    factor_tickers: list[str],
    start: str,
    end: str | None,
) -> pd.DataFrame:
    market_factor_tickers = [ticker for ticker in factor_tickers if ticker != "EQW"]
    factor_adj_close, _ = download_price_volume(market_factor_tickers, start=start, end=end)

    if cfg.factor_set == "extended_12" and "DBC" in market_factor_tickers:
        dbc_missing = "DBC" not in factor_adj_close.columns or factor_adj_close["DBC"].dropna().empty
        if dbc_missing:
            pdbc_close, _ = download_price_volume(["PDBC"], start=start, end=end)
            if not pdbc_close.empty and pdbc_close["PDBC"].dropna().any():
                factor_adj_close["DBC"] = pdbc_close["PDBC"]

    return factor_adj_close


def load_or_prepare_data(
    cfg: StrategyConfig,
    investable_tickers: list[str],
    factor_tickers: list[str],
) -> dict[str, pd.DataFrame | pd.Series]:
    """Load data from cache or download via yfinance, then build processed artifacts."""
    raw_paths = _raw_paths(cfg)
    proc_paths = _processed_paths(cfg)

    cached_backup = _load_cached_raw(raw_paths)
    if cfg.use_cache and not cfg.force_download:
        cached = cached_backup
    else:
        cached = None

    if cached is None:
        adj_downloaded, volume_downloaded = download_price_volume(investable_tickers, start=cfg.start_date, end=cfg.end_date)
        factor_downloaded = _prepare_factor_prices(
            cfg,
            factor_tickers=factor_tickers,
            start=cfg.start_date,
            end=cfg.end_date,
        )

        if _is_valid_price_frame(adj_downloaded) and _is_valid_price_frame(volume_downloaded):
            adj_close, volume = adj_downloaded, volume_downloaded
            _write_csv(adj_close, raw_paths["adj_close"])
            _write_csv(volume, raw_paths["volume"])
        elif cached_backup is not None:
            adj_close, volume, _ = cached_backup
        else:
            raise RuntimeError("Failed to obtain valid investable price/volume data from yfinance and no valid cache exists.")

        if _is_valid_factor_frame(factor_downloaded, factor_tickers):
            factor_adj_close = factor_downloaded
            _write_csv(factor_adj_close, raw_paths["factor_adj_close"])
        elif cached_backup is not None and _is_valid_factor_frame(cached_backup[2], factor_tickers):
            factor_adj_close = cached_backup[2]
        else:
            raise RuntimeError(f"Failed to obtain valid factor prices for factor_set={cfg.factor_set} and no valid cache exists.")
    else:
        adj_close, volume, factor_adj_close = cached

    # Restrict to requested columns and stable order.
    adj_close = adj_close.reindex(columns=investable_tickers)
    volume = volume.reindex(columns=investable_tickers)

    first_valid_dates = compute_first_valid_dates(adj_close)
    investable_mask = build_investable_mask(adj_close, first_valid_dates)
    returns = compute_returns(adj_close, investable_mask)

    factor_returns = factor_adj_close.pct_change(fill_method=None)
    eqw_factor = compute_eqw_factor(returns, investable_mask)

    if "EQW" in factor_tickers:
        factor_returns = factor_returns.copy()
        factor_returns["EQW"] = eqw_factor

    factor_returns = factor_returns.reindex(columns=[c for c in factor_tickers if c in factor_returns.columns or c == "EQW"])

    _write_csv(returns, proc_paths["returns"])
    _write_csv(investable_mask.astype(int), proc_paths["investable_mask"])
    first_valid_dates.to_frame().to_csv(proc_paths["first_valid_dates"])
    _write_csv(factor_returns, proc_paths["factor_returns"])
    eqw_factor.to_frame().to_csv(proc_paths["eqw"])

    return {
        "adj_close": adj_close,
        "volume": volume,
        "returns": returns,
        "investable_mask": investable_mask,
        "first_valid_dates": first_valid_dates,
        "factor_adj_close": factor_adj_close,
        "factor_returns": factor_returns,
        "eqw_factor": eqw_factor,
    }
