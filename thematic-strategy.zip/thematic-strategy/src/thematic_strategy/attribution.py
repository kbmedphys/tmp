"""Attribution utilities for factor, residual, and internal decomposition."""

from __future__ import annotations

import numpy as np
import pandas as pd


def _compound_series(series: pd.Series) -> pd.Series:
    grouped = series.groupby(series.index.to_period("M"))
    out = grouped.apply(lambda x: np.nan if x.dropna().empty else (1.0 + x.dropna()).prod() - 1.0)
    out.index = out.index.to_timestamp("M")
    return out


def make_monthly_returns_from_nav(nav_series: pd.Series) -> pd.Series:
    """Convert daily NAV into monthly returns using month-end NAV."""
    month_end_nav = nav_series.groupby(nav_series.index.to_period("M")).last()
    month_end_nav.index = month_end_nav.index.to_timestamp("M")
    monthly_ret = month_end_nav.pct_change(fill_method=None)
    monthly_ret.name = nav_series.name
    return monthly_ret


def rolling_factor_attribution(
    returns_by_strategy: pd.DataFrame,
    factor_returns: pd.DataFrame,
    window_months: int,
    lag: int = 1,
    min_obs: int | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Rolling factor attribution with time-consistent beta estimation.

    For each date t:
      beta_t estimated with data up to t-lag;
      contrib_t = beta_t * factor_return_t.
    """
    if lag < 1:
        raise ValueError("lag must be >= 1")

    common_idx = returns_by_strategy.index.intersection(factor_returns.index)
    y_all = returns_by_strategy.loc[common_idx].sort_index()
    f_all = factor_returns.loc[common_idx].sort_index()

    min_obs = min_obs or max(24, window_months // 2)
    factor_names = list(f_all.columns)

    beta_rows: list[dict[str, object]] = []
    contrib_rows: list[dict[str, object]] = []
    alpha_rows: list[dict[str, object]] = []

    for sid in y_all.columns:
        y = y_all[sid]
        for pos in range(window_months + lag, len(common_idx)):
            t = common_idx[pos]
            end_train = pos - lag
            start_train = end_train - window_months + 1
            if start_train < 0:
                continue

            y_train = y.iloc[start_train : end_train + 1]
            f_train = f_all.iloc[start_train : end_train + 1]
            train = pd.concat([y_train.rename("y"), f_train], axis=1).dropna()
            if len(train) < min_obs:
                continue

            x = train[factor_names].to_numpy(dtype=float)
            y_np = train["y"].to_numpy(dtype=float)
            x_with_intercept = np.column_stack([np.ones(len(x)), x])
            coef, *_ = np.linalg.lstsq(x_with_intercept, y_np, rcond=None)
            alpha = float(coef[0])
            beta = coef[1:].astype(float)

            f_t = f_all.loc[t, factor_names]
            y_t = y.loc[t]
            if pd.isna(y_t) or f_t.isna().any():
                continue

            y_hat_t = alpha + float(np.dot(beta, f_t.to_numpy(dtype=float)))
            resid_t = float(y_t - y_hat_t)

            for j, fac in enumerate(factor_names):
                beta_rows.append(
                    {
                        "date": t,
                        "strategy_id": sid,
                        "factor_name": fac,
                        "beta": float(beta[j]),
                    }
                )
                contrib_rows.append(
                    {
                        "date": t,
                        "strategy_id": sid,
                        "factor_name": fac,
                        "contrib": float(beta[j] * float(f_t[fac])),
                    }
                )

            alpha_rows.append(
                {
                    "date": t,
                    "strategy_id": sid,
                    "alpha": alpha,
                    "resid": resid_t,
                }
            )

    betas = pd.DataFrame(beta_rows)
    contrib = pd.DataFrame(contrib_rows)
    alpha_df = pd.DataFrame(alpha_rows)

    resid_rows: list[dict[str, object]] = []
    if not alpha_df.empty:
        for sid, grp in alpha_df.sort_values("date").groupby("strategy_id"):
            resid = grp["resid"].astype(float)
            roll_mean = resid.shift(1).rolling(window_months, min_periods=max(12, window_months // 3)).mean()
            roll_std = resid.shift(1).rolling(window_months, min_periods=max(12, window_months // 3)).std()
            rs = (roll_mean / roll_std).replace([np.inf, -np.inf], np.nan) * np.sqrt(12.0)
            tmp = grp.copy()
            tmp["resid_rolling_sharpe"] = rs.values
            resid_rows.append(tmp[["date", "strategy_id", "resid", "resid_rolling_sharpe"]])

    resid_stats = pd.concat(resid_rows, ignore_index=True) if resid_rows else pd.DataFrame(
        columns=["date", "strategy_id", "resid", "resid_rolling_sharpe"]
    )

    return betas, contrib, alpha_df, resid_stats


def internal_selection_weighting_attribution(
    weights: pd.DataFrame,
    asset_returns: pd.DataFrame,
    rebalance_dates: pd.Series | None = None,
    top_k: int = 4,
) -> pd.DataFrame:
    """Compute monthly selection vs weighting attribution from daily weights/returns."""
    idx = weights.index.intersection(asset_returns.index)
    cols = [c for c in weights.columns if c in asset_returns.columns]
    w = weights.loc[idx, cols].copy()
    r = asset_returns.loc[idx, cols].copy()

    r_port_daily = pd.Series(np.nan, index=idx, name="R_port_daily")
    r_sel_daily = pd.Series(np.nan, index=idx, name="R_sel_daily")

    for dt in idx:
        w_row = w.loc[dt]
        r_row = r.loc[dt]

        active = (w_row > 0.0) & r_row.notna()
        if active.any():
            r_port_daily.loc[dt] = float((w_row[active] * r_row[active]).sum())
            r_sel_daily.loc[dt] = float(r_row[active].mean())
            continue

        # Fallback: use top-k by weight if all active positions have missing return.
        candidates = w_row[w_row > 0.0].sort_values(ascending=False).head(top_k).index
        candidates = [c for c in candidates if pd.notna(r_row.get(c))]
        if candidates:
            r_port_daily.loc[dt] = float((w_row[candidates] * r_row[candidates]).sum())
            r_sel_daily.loc[dt] = float(r_row[candidates].mean())

    r_port_m = _compound_series(r_port_daily).rename("R_port")
    r_sel_m = _compound_series(r_sel_daily).rename("R_sel")
    out = pd.concat([r_sel_m, r_port_m], axis=1)
    out["R_wgt"] = out["R_port"] - out["R_sel"]
    out.index.name = "date"
    return out.reset_index()


def overlay_attribution(
    managed_returns: pd.Series,
    base_returns: pd.Series,
    indicator: pd.Series,
    meta: dict[str, object],
) -> pd.DataFrame:
    """Compute monthly overlay excess attribution for ON/OFF managed strategies."""
    idx = managed_returns.index.intersection(base_returns.index).intersection(indicator.index)
    managed = managed_returns.reindex(idx)
    base = base_returns.reindex(idx)
    ind = indicator.reindex(idx)

    overlay_excess_daily = managed - base
    overlay_excess_m = _compound_series(overlay_excess_daily).rename("overlay_excess")
    indicator_m = ind.groupby(ind.index.to_period("M")).last()
    indicator_m.index = indicator_m.index.to_timestamp("M")

    out = pd.DataFrame(
        {
            "date": overlay_excess_m.index,
            "managed_strategy_id": meta.get("managed_strategy_id", ""),
            "base_strategy_id": meta.get("base_strategy_id", ""),
            "overlay_excess": overlay_excess_m.values,
            "indicator": indicator_m.reindex(overlay_excess_m.index).values,
            "eta": meta.get("eta", np.nan),
            "M": meta.get("M", np.nan),
            "method": meta.get("method", ""),
        }
    )
    return out
