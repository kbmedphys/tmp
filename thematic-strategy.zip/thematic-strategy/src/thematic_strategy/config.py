"""Configuration and universe loading utilities."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import pandas as pd

INVESTABLE_TICKERS: tuple[str, ...] = (
    "AIQ",
    "BOTZ",
    "SMH",
    "WCLD",
    "CIBR",
    "IPAY",
    "ICLN",
    "TAN",
    "DRIV",
    "LIT",
    "UFO",
    "ITA",
    "ARKG",
    "PHO",
    "MOO",
    "PAVE",
    "ESPO",
    "KOMP",
)

FACTOR_SETS: dict[str, list[str]] = {
    "minimal_3": ["SPY", "QQQ", "IEF"],
    "minimal_5": ["SPY", "QQQ", "IWM", "IEF", "LQD"],
    "extended_10": ["SPY", "QQQ", "IWM", "EFA", "EEM", "IEF", "TLT", "LQD", "HYG", "GLD"],
    "extended_12": [
        "SPY",
        "QQQ",
        "IWM",
        "EFA",
        "EEM",
        "IEF",
        "TLT",
        "LQD",
        "HYG",
        "GLD",
        "VNQ",
        "DBC",
    ],
    "eqw_only": ["EQW"],
    "eqw_plus_rates": ["EQW", "IEF"],
}

ALLOWED_STRATEGY_MODES = {"T1", "T2", "T3"}


@dataclass
class StrategyConfig:
    """Runtime configuration for data, signal, and backtest pipeline."""

    strategy_mode: str = "T1"
    rebalance: str = "M"
    split_date: str = "2021-01-01"
    fee_bps: float = 10.0
    slippage_bps: float = 1.0
    exec_lag: int = 1
    top_k: int = 4
    lookback_price: int = 252
    factor_set: str = "minimal_3"

    start_date: str = "2015-01-01"
    end_date: str | None = None

    t1_variant: str = "baseline"
    t2_variant: str = "baseline"
    t3_variant: str = "additive_on_t2"

    lambda_attn: float = 0.0
    lambda_risk: float = 0.0
    lambda_down: float = 0.0
    lambda_fee: float = 0.0
    lambda_tc: float = 0.20
    lambda_corr: float = 0.25
    lambda_text: float = 0.20
    lambda_amb: float = 0.50

    t3_cap_quantile: float = 0.85

    onoff_enabled: bool = False
    onoff_method: str = "lagged_sed"
    onoff_eta: float = 0.0
    onoff_lookback: int = 63
    onoff_min_train: int = 126
    onoff_target_m: int = 6
    onoff_use_vol_norm: bool = True
    onoff_state_model: str = "ols"

    regression_lookback: int = 252
    residual_window: int = 63
    corr_window: int = 63

    use_cache: bool = True
    force_download: bool = False

    data_dir: Path = Path("data")
    docs_dir: Path = Path("docs/notes")
    outputs_dir: Path = Path("outputs")

    def validate(self) -> None:
        if self.strategy_mode not in ALLOWED_STRATEGY_MODES:
            raise ValueError(f"strategy_mode must be one of {sorted(ALLOWED_STRATEGY_MODES)}")
        if self.factor_set not in FACTOR_SETS:
            raise ValueError(f"factor_set must be one of {sorted(FACTOR_SETS)}")
        if self.exec_lag < 1:
            raise ValueError("exec_lag must be >= 1")
        if self.top_k < 1:
            raise ValueError("top_k must be >= 1")
        if self.rebalance not in {"M", "Q"}:
            raise ValueError("rebalance must be 'M' or 'Q'")
        if self.lookback_price < 20:
            raise ValueError("lookback_price must be >= 20")
        if self.regression_lookback < 60:
            raise ValueError("regression_lookback must be >= 60")
        if not (0.0 < self.t3_cap_quantile < 1.0):
            raise ValueError("t3_cap_quantile must be in (0, 1)")
        if self.onoff_method not in {"lagged_sed", "lasso", "state_pred"}:
            raise ValueError("onoff_method must be one of {'lagged_sed', 'lasso', 'state_pred'}")
        if not (0.0 <= self.onoff_eta <= 1.0):
            raise ValueError("onoff_eta must be in [0, 1]")
        if self.onoff_lookback < 5:
            raise ValueError("onoff_lookback must be >= 5")
        if self.onoff_min_train < 20:
            raise ValueError("onoff_min_train must be >= 20")
        if self.onoff_target_m < 1:
            raise ValueError("onoff_target_m must be >= 1")
        if self.onoff_state_model not in {"ols", "lasso"}:
            raise ValueError("onoff_state_model must be one of {'ols', 'lasso'}")

    @property
    def universe_csv_path(self) -> Path:
        return self.docs_dir / "01_universe.csv"


def parse_expense_ratio(value: object) -> float:
    """Parse percentage strings like '0.68%' into decimals."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return float("nan")

    text = str(value).strip()
    if not text:
        return float("nan")
    if text.endswith("%"):
        try:
            return float(text[:-1]) / 100.0
        except ValueError:
            return float("nan")

    try:
        parsed = float(text)
    except ValueError:
        return float("nan")

    # If given in percent units already (e.g., 0.68), convert to decimal.
    if parsed > 1.0:
        return parsed / 100.0
    return parsed


def load_universe(universe_csv_path: Path) -> pd.DataFrame:
    """Load universe metadata from a single source of truth CSV."""
    if not universe_csv_path.exists():
        raise FileNotFoundError(f"Universe file not found: {universe_csv_path}")

    universe = pd.read_csv(universe_csv_path)
    if "ticker" not in universe.columns:
        raise ValueError("universe CSV must contain a 'ticker' column")

    universe["ticker"] = universe["ticker"].astype(str).str.upper().str.strip()
    universe = universe.drop_duplicates(subset=["ticker"]).set_index("ticker", drop=False)

    missing = sorted(set(INVESTABLE_TICKERS) - set(universe.index))
    if missing:
        raise ValueError(f"Universe CSV missing investable tickers: {missing}")

    universe = universe.loc[list(INVESTABLE_TICKERS)].copy()
    universe["expense_ratio_dec"] = universe["expense_ratio"].apply(parse_expense_ratio)
    return universe


def get_factor_tickers(factor_set: str, allow_dbc_fallback: bool = True) -> list[str]:
    """Return factor ticker list for a given factor_set."""
    if factor_set not in FACTOR_SETS:
        raise ValueError(f"Unknown factor_set: {factor_set}")

    tickers = list(FACTOR_SETS[factor_set])
    if factor_set == "extended_12" and allow_dbc_fallback:
        # Data layer will attempt DBC first, then PDBC if DBC is unavailable.
        return tickers
    return tickers


def build_config(**overrides: object) -> StrategyConfig:
    """Create config with optional overrides and validation."""
    cfg = StrategyConfig(**overrides)
    cfg.validate()
    return cfg


def ensure_directories(paths: Iterable[Path]) -> None:
    """Create directories if they do not exist."""
    for path in paths:
        path.mkdir(parents=True, exist_ok=True)
