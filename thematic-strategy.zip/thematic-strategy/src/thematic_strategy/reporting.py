"""Reporting utilities for figures and tables."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def ensure_output_dirs(root: Path) -> dict[str, Path]:
    figures = root / "figures"
    tables = root / "tables"
    logs = root / "logs"
    for path in (figures, tables, logs):
        path.mkdir(parents=True, exist_ok=True)
    return {"figures": figures, "tables": tables, "logs": logs}


def plot_nav(strategy_nav: pd.Series, eqw_nav: pd.Series, save_path: Path) -> None:
    plt.figure(figsize=(10, 5))
    plt.plot(strategy_nav.index, strategy_nav.values, label="Strategy", linewidth=2)
    plt.plot(eqw_nav.index, eqw_nav.values, label="EQW", linewidth=1.8)
    plt.title("NAV Comparison")
    plt.xlabel("Date")
    plt.ylabel("NAV")
    plt.legend()
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(save_path, dpi=160)
    plt.close()


def plot_turnover(strategy_turnover: pd.Series, eqw_turnover: pd.Series, save_path: Path) -> None:
    plt.figure(figsize=(10, 4))
    plt.plot(strategy_turnover.index, strategy_turnover.values, label="Strategy Turnover", linewidth=1.6)
    plt.plot(eqw_turnover.index, eqw_turnover.values, label="EQW Turnover", linewidth=1.2)
    plt.title("Daily Turnover")
    plt.xlabel("Date")
    plt.ylabel("Turnover")
    plt.legend()
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(save_path, dpi=160)
    plt.close()


def save_table(table: pd.DataFrame, save_path: Path) -> None:
    table.to_csv(save_path, index=False)
