"""Full-spec end-to-end pipeline for strategy comparison, attribution, and dashboard."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .attribution import (
    internal_selection_weighting_attribution,
    make_monthly_returns_from_nav,
    overlay_attribution,
    rolling_factor_attribution,
)
from .backtest import run_backtest
from .config import build_config, get_factor_tickers, load_universe
from .data import load_or_prepare_data
from .metrics import compute_metrics_table, compute_subperiod_stability
from .portfolio import build_target_weights
from .reporting import ensure_output_dirs
from .signal_dispatch import build_scores
from .signals import apply_onoff_overlay
from .state import compute_onoff_indicator
from .strategy_registry import StrategySpec, get_strategy_specs


DEFAULT_BASE_PARAMS: dict[str, Any] = {
    "rebalance": "M",
    "split_date": "2021-01-01",
    "fee_bps": 10.0,
    "slippage_bps": 1.0,
    "exec_lag": 1,
    "top_k": 4,
    "lookback_price": 252,
    "start_date": "2015-01-01",
}

FULL_SPEC_RECOMMENDED_ID = "T1_best_onoff_statepred_M12_eta0p2"
DEFAULT_REPRESENTATIVE_IDS = [
    "EQW",
    "T1_base_best",
    FULL_SPEC_RECOMMENDED_ID,
    "T2_resid_eqw_only",
]


@dataclass
class PeriodMetrics:
    all_row: pd.Series
    train_row: pd.Series
    test_row: pd.Series


def _monthly_compound_from_daily(series: pd.Series) -> pd.Series:
    out = series.groupby(series.index.to_period("M")).apply(
        lambda x: np.nan if x.dropna().empty else (1.0 + x.dropna()).prod() - 1.0
    )
    out.index = out.index.to_timestamp("M")
    return out


def _plot_nav_panel(nav_df: pd.DataFrame, save_path: Path, title: str, log_scale: bool = False) -> None:
    plt.figure(figsize=(14, 7))
    for sid in nav_df.columns:
        plt.plot(nav_df.index, nav_df[sid], linewidth=1.25, label=sid)
    if log_scale:
        plt.yscale("log")
    plt.title(title)
    plt.xlabel("Date")
    plt.ylabel("NAV" if not log_scale else "NAV (log)")
    plt.grid(alpha=0.25)
    plt.legend(ncol=2, fontsize=8)
    plt.tight_layout()
    plt.savefig(save_path, dpi=180)
    plt.close()


def _plot_drawdown_panel(nav_df: pd.DataFrame, save_path: Path, title: str) -> None:
    drawdown = nav_df.div(nav_df.cummax()).sub(1.0)
    plt.figure(figsize=(14, 7))
    for sid in drawdown.columns:
        plt.plot(drawdown.index, drawdown[sid], linewidth=1.2, label=sid)
    plt.title(title)
    plt.xlabel("Date")
    plt.ylabel("Drawdown")
    plt.grid(alpha=0.25)
    plt.legend(ncol=2, fontsize=8)
    plt.tight_layout()
    plt.savefig(save_path, dpi=180)
    plt.close()


def _extract_period_metrics(metrics: pd.DataFrame, use_eqw_output: bool) -> PeriodMetrics:
    portfolio = "EQW" if use_eqw_output else "Strategy"
    subset = metrics[metrics["Portfolio"] == portfolio].set_index("Period")
    return PeriodMetrics(
        all_row=subset.loc["All"],
        train_row=subset.loc["Train"],
        test_row=subset.loc["Test"],
    )


def _run_single_strategy(
    strategy_id: str,
    strategy_specs: dict[str, StrategySpec],
    base_params: dict[str, Any],
    universe: pd.DataFrame,
    investable_tickers: list[str],
    data_cache: dict[tuple[str, str, str | None], dict[str, pd.DataFrame | pd.Series]],
    extra_overrides: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if strategy_id not in strategy_specs:
        raise ValueError(f"Unknown strategy_id: {strategy_id}")

    spec = strategy_specs[strategy_id]
    overrides: dict[str, Any] = {}
    overrides.update(base_params)
    overrides.update(spec.config_overrides)
    if extra_overrides:
        overrides.update(extra_overrides)

    cfg = build_config(**overrides)

    data_key = (cfg.factor_set, cfg.start_date, cfg.end_date)
    if data_key not in data_cache:
        factor_tickers = get_factor_tickers(cfg.factor_set)
        data_cache[data_key] = load_or_prepare_data(
            cfg=cfg,
            investable_tickers=investable_tickers,
            factor_tickers=factor_tickers,
        )
    bundle = data_cache[data_key]

    score_out = build_scores(
        cfg=cfg,
        universe=universe,
        adj_close=bundle["adj_close"],
        volume=bundle["volume"],
        returns=bundle["returns"],
        investable_mask=bundle["investable_mask"],
        factor_returns=bundle["factor_returns"],
    )
    score = score_out["score"].copy()

    indicator_df = pd.DataFrame(index=score.index, data={"indicator": np.nan})
    state_debug = {
        "stepb_features": pd.DataFrame(),
        "stepb_pred": pd.DataFrame(),
        "stepb_coef": pd.DataFrame(),
    }
    if cfg.onoff_enabled:
        indicator_df = compute_onoff_indicator(
            dates=score.index,
            base_scores=score,
            future_returns=bundle["returns"],
            factor_returns=bundle["factor_returns"],
            method=cfg.onoff_method,
            top_k=cfg.top_k,
            exec_lag=cfg.exec_lag,
            lookback=cfg.onoff_lookback,
            min_train=cfg.onoff_min_train,
            target_m=cfg.onoff_target_m,
            use_vol_norm=cfg.onoff_use_vol_norm,
            state_model=cfg.onoff_state_model,
            demean=True,
        )
        state_debug["stepb_features"] = indicator_df.attrs.get("stepb_features", pd.DataFrame())
        state_debug["stepb_pred"] = indicator_df.attrs.get("stepb_pred", pd.DataFrame())
        state_debug["stepb_coef"] = indicator_df.attrs.get("stepb_coef", pd.DataFrame())
        score = apply_onoff_overlay(score, indicator_df["indicator"], eta=cfg.onoff_eta)

    holdings, rebalance_mask = build_target_weights(
        score=score,
        investable_mask=bundle["investable_mask"],
        top_k=cfg.top_k,
        rebalance_freq=cfg.rebalance,
    )

    bt = run_backtest(
        target_weights=holdings,
        returns=bundle["returns"],
        investable_mask=bundle["investable_mask"],
        expense_ratio=universe["expense_ratio_dec"],
        fee_bps=cfg.fee_bps,
        slippage_bps=cfg.slippage_bps,
        exec_lag=cfg.exec_lag,
        rebalance_freq=cfg.rebalance,
    )

    overlay_scale = pd.Series(1.0, index=bt["strategy_net_returns"].index, name="overlay_scale")
    if cfg.onoff_enabled:
        overlay_scale = cfg.onoff_eta + (1.0 - cfg.onoff_eta) * indicator_df["indicator"].reindex(bt["strategy_net_returns"].index).fillna(0.0)
        overlay_scale = overlay_scale.astype(float)

        bt["strategy_gross_returns"] = bt["strategy_gross_returns"] * overlay_scale
        bt["strategy_trading_cost"] = bt["strategy_trading_cost"] * overlay_scale
        bt["strategy_expense_cost"] = bt["strategy_expense_cost"] * overlay_scale
        bt["strategy_net_returns"] = (
            bt["strategy_gross_returns"]
            - bt["strategy_trading_cost"]
            - bt["strategy_expense_cost"]
        )
        bt["strategy_nav"] = (1.0 + bt["strategy_net_returns"].fillna(0.0)).cumprod()

    metrics = compute_metrics_table(bt, split_date=cfg.split_date)
    period_metrics = _extract_period_metrics(metrics, use_eqw_output=spec.use_eqw_output)
    stability = compute_subperiod_stability(
        net_returns=bt["strategy_net_returns"] if not spec.use_eqw_output else bt["eqw_net_returns"],
        periods=[
            ("2017-2019", "2017-01-01", "2020-01-01"),
            ("2020-2021", "2020-01-01", "2022-01-01"),
            ("2022-now", "2022-01-01", None),
        ],
    )

    nav = bt["eqw_nav"] if spec.use_eqw_output else bt["strategy_nav"]

    row_all = period_metrics.all_row
    row_train = period_metrics.train_row
    row_test = period_metrics.test_row
    summary = {
        "strategy_id": strategy_id,
        "strategy_mode": cfg.strategy_mode,
        "t1_variant": cfg.t1_variant,
        "t2_variant": cfg.t2_variant,
        "t3_variant": cfg.t3_variant,
        "factor_set": cfg.factor_set,
        "rebalance": cfg.rebalance,
        "top_k": cfg.top_k,
        "exec_lag": cfg.exec_lag,
        "split_date": cfg.split_date,
        "onoff_enabled": bool(cfg.onoff_enabled),
        "onoff_method": cfg.onoff_method if cfg.onoff_enabled else "",
        "onoff_eta": float(cfg.onoff_eta) if cfg.onoff_enabled else np.nan,
        "onoff_M": int(cfg.onoff_target_m) if cfg.onoff_enabled else np.nan,
        "CAGR": float(row_all["CAGR"]),
        "Vol": float(row_all["Vol"]),
        "Sharpe": float(row_all["Sharpe"]),
        "MDD": float(row_all["MDD"]),
        "AvgTurnover": float(row_all["AvgTurnover"]),
        "TotalTradingCost": float(row_all["TotalTradingCost"]),
        "TotalExpenseCost": float(row_all["TotalExpenseCost"]),
        "TotalCost": float(row_all["TotalTradingCost"] + row_all["TotalExpenseCost"]),
        "FinalNAV": float(row_all["FinalNAV"]),
        "TrainSharpe": float(row_train["Sharpe"]),
        "TestSharpe": float(row_test["Sharpe"]),
        "TrainMDD": float(row_train["MDD"]),
        "TestMDD": float(row_test["MDD"]),
        "All_CAGR": float(row_all["CAGR"]),
        "All_Sharpe": float(row_all["Sharpe"]),
        "All_Vol": float(row_all["Vol"]),
        "All_MDD": float(row_all["MDD"]),
        "Train_CAGR": float(row_train["CAGR"]),
        "Train_Sharpe": float(row_train["Sharpe"]),
        "Train_Vol": float(row_train["Vol"]),
        "Train_MDD": float(row_train["MDD"]),
        "Test_CAGR": float(row_test["CAGR"]),
        "Test_Sharpe": float(row_test["Sharpe"]),
        "Test_Vol": float(row_test["Vol"]),
        "Test_MDD": float(row_test["MDD"]),
        "Sharpe_2017_2019": float(stability.loc[stability["Subperiod"] == "2017-2019", "Sharpe"].iloc[0]),
        "Sharpe_2020_2021": float(stability.loc[stability["Subperiod"] == "2020-2021", "Sharpe"].iloc[0]),
        "Sharpe_2022_now": float(stability.loc[stability["Subperiod"] == "2022-now", "Sharpe"].iloc[0]),
    }

    period_rows: list[dict[str, Any]] = []
    for period_name, row in (("All", row_all), ("Train", row_train), ("Test", row_test)):
        period_rows.append(
            {
                "strategy_id": strategy_id,
                "period": period_name,
                "CAGR": float(row["CAGR"]),
                "Sharpe": float(row["Sharpe"]),
                "Vol": float(row["Vol"]),
                "MDD": float(row["MDD"]),
                "AvgTurnover": float(row["AvgTurnover"]),
                "TotalTradingCost": float(row["TotalTradingCost"]),
                "TotalExpenseCost": float(row["TotalExpenseCost"]),
                "FinalNAV": float(row["FinalNAV"]),
                "onoff_enabled": bool(cfg.onoff_enabled),
                "onoff_method": cfg.onoff_method if cfg.onoff_enabled else "",
                "onoff_eta": float(cfg.onoff_eta) if cfg.onoff_enabled else np.nan,
                "onoff_M": int(cfg.onoff_target_m) if cfg.onoff_enabled else np.nan,
            }
        )

    return {
        "strategy_id": strategy_id,
        "config": cfg,
        "bundle": bundle,
        "score": score,
        "score_out": score_out,
        "indicator_df": indicator_df,
        "state_debug": state_debug,
        "overlay_scale": overlay_scale,
        "holdings": holdings,
        "rebalance_mask": rebalance_mask,
        "backtest": bt,
        "metrics": metrics,
        "stability": stability,
        "nav": nav,
        "summary": summary,
        "period_rows": period_rows,
    }


def _save_nav_outputs(
    nav_generated: pd.DataFrame,
    strategy_ids: list[str],
    out_dirs: dict[str, Path],
    title_suffix: str,
    reuse_nav_if_exists: bool,
) -> tuple[pd.DataFrame, dict[str, Path]]:
    nav_path = out_dirs["tables"] / "nav_timeseries_all_with_onoff_stepB.csv"
    nav_all_path = out_dirs["tables"] / "nav_timeseries_all.csv"
    fig_linear = out_dirs["figures"] / "nav_all_strategies_ALL.png"
    fig_log = out_dirs["figures"] / "nav_all_strategies_ALL_log.png"
    fig_dd = out_dirs["figures"] / "drawdown_all_strategies_ALL.png"

    nav_df = nav_generated.copy()
    if reuse_nav_if_exists and nav_path.exists():
        cached = pd.read_csv(nav_path, index_col=0, parse_dates=True).sort_index()
        if all(sid in cached.columns for sid in strategy_ids):
            nav_df = cached.reindex(columns=strategy_ids)
        else:
            nav_df = nav_generated
            nav_df.to_csv(nav_path)
    else:
        nav_df.to_csv(nav_path)

    nav_df = nav_df.sort_index()
    nav_df.index.name = "date"
    nav_df = nav_df.reindex(columns=strategy_ids)
    nav_df.to_csv(nav_path)
    nav_df.to_csv(nav_all_path)

    _plot_nav_panel(nav_df, fig_linear, f"All Strategies NAV ({title_suffix})", log_scale=False)
    _plot_nav_panel(nav_df, fig_log, f"All Strategies NAV - Log ({title_suffix})", log_scale=True)
    _plot_drawdown_panel(nav_df, fig_dd, f"All Strategies Drawdown ({title_suffix})")

    return nav_df, {
        "nav": nav_path,
        "nav_all_compat": nav_all_path,
        "nav_linear_fig": fig_linear,
        "nav_log_fig": fig_log,
        "drawdown_fig": fig_dd,
    }


def _compute_factor_monthly(base_bundle: dict[str, pd.DataFrame | pd.Series], target_index: pd.DatetimeIndex) -> pd.DataFrame:
    factor_monthly = pd.DataFrame(index=target_index)
    factor_monthly["EQW"] = _monthly_compound_from_daily(base_bundle["eqw_factor"]).reindex(target_index)
    if "IEF" in base_bundle["factor_returns"].columns:
        factor_monthly["IEF"] = _monthly_compound_from_daily(base_bundle["factor_returns"]["IEF"]).reindex(target_index)
    factor_monthly = factor_monthly.loc[:, factor_monthly.notna().any(axis=0)]
    return factor_monthly


def _select_line_strategy(summary_df: pd.DataFrame, fallback: str) -> str:
    if fallback in summary_df["strategy_id"].values:
        return fallback
    ranked = summary_df.sort_values(["TestSharpe", "Sharpe"], ascending=False)
    if ranked.empty:
        return fallback
    return str(ranked.iloc[0]["strategy_id"])


def _build_dashboard_components(
    sid: str,
    results_all: dict[str, dict[str, Any]],
    factor_contrib_all: pd.DataFrame,
    factor_alpha_all: pd.DataFrame,
    internal_all: pd.DataFrame,
    overlay_all: pd.DataFrame,
) -> pd.DataFrame:
    nav = results_all[sid]["nav"].groupby(results_all[sid]["nav"].index.to_period("M")).last()
    nav.index = nav.index.to_timestamp("M")
    nav_eqw = results_all["EQW"]["nav"].groupby(results_all["EQW"]["nav"].index.to_period("M")).last()
    nav_eqw.index = nav_eqw.index.to_timestamp("M")

    fc = factor_contrib_all[factor_contrib_all["strategy_id"] == sid].copy()
    if not fc.empty:
        fp = fc.pivot_table(index="date", columns="factor_name", values="contrib", aggfunc="sum").sort_index()
    else:
        fp = pd.DataFrame(index=nav.index)

    contrib_eqw = fp["EQW"] if "EQW" in fp.columns else pd.Series(0.0, index=fp.index)
    contrib_ief = fp["IEF"] if "IEF" in fp.columns else pd.Series(0.0, index=fp.index)
    contrib_other = fp.sum(axis=1, min_count=1).fillna(0.0) - contrib_eqw.reindex(fp.index, fill_value=0.0) - contrib_ief.reindex(fp.index, fill_value=0.0)

    fa = factor_alpha_all[factor_alpha_all["strategy_id"] == sid].copy()
    if not fa.empty:
        fa = fa.set_index("date").sort_index()
        alpha_or_resid = fa["alpha"] if "alpha" in fa.columns else fa.get("resid", pd.Series(index=fa.index, dtype=float))
    else:
        alpha_or_resid = pd.Series(dtype=float)

    inter = internal_all[internal_all["strategy_id"] == sid].copy()
    if not inter.empty:
        inter = inter.set_index("date").sort_index()

    if "managed_strategy_id" in overlay_all.columns:
        ov = overlay_all[overlay_all["managed_strategy_id"] == sid].copy()
    else:
        ov = pd.DataFrame(columns=overlay_all.columns)
    if not ov.empty:
        ov = ov.set_index("date").sort_index()

    idx = nav.index.union(nav_eqw.index).union(fp.index).sort_values()
    if not inter.empty:
        idx = idx.union(inter.index).sort_values()
    if not ov.empty:
        idx = idx.union(ov.index).sort_values()

    comp = pd.DataFrame(index=idx)
    comp.index.name = "date"
    comp["nav"] = nav.reindex(idx)
    comp["nav_eqw"] = nav_eqw.reindex(idx)
    comp["contrib_EQW"] = contrib_eqw.reindex(idx)
    comp["contrib_IEF"] = contrib_ief.reindex(idx)
    comp["contrib_OTHER"] = contrib_other.reindex(idx)
    comp["alpha_or_resid"] = alpha_or_resid.reindex(idx)

    for c in ["R_sel", "R_wgt", "R_port"]:
        comp[c] = inter[c].reindex(idx) if (not inter.empty and c in inter.columns) else np.nan

    if not ov.empty and "overlay_excess" in ov.columns:
        comp["overlay_excess"] = ov["overlay_excess"].reindex(idx)
        comp["indicator"] = ov["indicator"].reindex(idx) if "indicator" in ov.columns else np.nan
    else:
        comp["overlay_excess"] = np.nan
        comp["indicator"] = np.nan

    return comp


def run_full_spec_pipeline(
    *,
    base_params: dict[str, Any] | None = None,
    include_optional_t3_on_t2: bool = True,
    reuse_nav_if_exists: bool = True,
    representative_ids: list[str] | None = None,
    recommended_strategy_id: str = FULL_SPEC_RECOMMENDED_ID,
) -> dict[str, Any]:
    params = dict(DEFAULT_BASE_PARAMS)
    if base_params:
        params.update(base_params)

    base_cfg = build_config(**params)
    out_dirs = ensure_output_dirs(base_cfg.outputs_dir)
    universe = load_universe(base_cfg.universe_csv_path)
    investable_tickers = list(universe.index)

    strategy_specs = get_strategy_specs(include_optional_t3_on_t2=include_optional_t3_on_t2)
    strategy_ids = list(strategy_specs.keys())
    onoff_ids = [
        sid
        for sid, spec in strategy_specs.items()
        if spec.config_overrides.get("onoff_enabled")
    ]

    data_cache: dict[tuple[str, str, str | None], dict[str, pd.DataFrame | pd.Series]] = {}
    results_all: dict[str, dict[str, Any]] = {}
    for sid in strategy_ids:
        results_all[sid] = _run_single_strategy(
            strategy_id=sid,
            strategy_specs=strategy_specs,
            base_params=params,
            universe=universe,
            investable_tickers=investable_tickers,
            data_cache=data_cache,
        )

    nav_generated = pd.concat([results_all[sid]["nav"].rename(sid) for sid in strategy_ids], axis=1).sort_index()
    nav_generated.index.name = "date"

    title_suffix = (
        f"rebalance={base_cfg.rebalance}, top_k={base_cfg.top_k}, "
        f"exec_lag={base_cfg.exec_lag}, split_date={base_cfg.split_date}"
    )
    nav_df, nav_paths = _save_nav_outputs(
        nav_generated=nav_generated,
        strategy_ids=strategy_ids,
        out_dirs=out_dirs,
        title_suffix=title_suffix,
        reuse_nav_if_exists=reuse_nav_if_exists,
    )

    summary_df = pd.DataFrame([results_all[sid]["summary"] for sid in strategy_ids]).sort_values(
        ["TestSharpe", "Sharpe"], ascending=False
    )
    summary_df.to_csv(out_dirs["tables"] / "nav_summary_with_onoff_stepB.csv", index=False)
    summary_df.to_csv(out_dirs["tables"] / "nav_summary_with_onoff.csv", index=False)

    summary_period_df = pd.DataFrame(
        row for sid in strategy_ids for row in results_all[sid]["period_rows"]
    ).sort_values(["strategy_id", "period"])
    summary_period_df.to_csv(out_dirs["tables"] / "nav_summary_train_test_all_with_onoff_stepB.csv", index=False)

    indicator_rows = []
    stepb_feature_rows = []
    stepb_pred_rows = []
    stepb_coef_rows = []
    for sid in onoff_ids:
        ind = results_all[sid]["indicator_df"].copy()
        ind.attrs = {}
        if not ind.empty:
            ind["scale"] = results_all[sid]["overlay_scale"].reindex(ind.index)
            ind = ind.reset_index().rename(columns={"index": "date", "Date": "date"})
            ind["strategy_id"] = sid
            ind["eta"] = results_all[sid]["summary"].get("onoff_eta", np.nan)
            ind["M"] = results_all[sid]["summary"].get("onoff_M", np.nan)
            indicator_rows.append(ind)

        dbg = results_all[sid]["state_debug"]
        feat = dbg.get("stepb_features", pd.DataFrame())
        if feat is not None and not feat.empty:
            feat_out = feat.copy().reset_index().rename(columns={"index": "date", "Date": "date"})
            feat_out.attrs = {}
            feat_out["strategy_id"] = sid
            stepb_feature_rows.append(feat_out)

        pred = dbg.get("stepb_pred", pd.DataFrame())
        if pred is not None and not pred.empty:
            pred_out = pred.copy().reset_index().rename(columns={"index": "date", "Date": "date"})
            pred_out.attrs = {}
            pred_out["strategy_id"] = sid
            stepb_pred_rows.append(pred_out)

        coef = dbg.get("stepb_coef", pd.DataFrame())
        if coef is not None and not coef.empty:
            coef_out = coef.copy()
            coef_out.attrs = {}
            coef_out["strategy_id"] = sid
            stepb_coef_rows.append(coef_out)

    onoff_indicator_df = pd.concat(indicator_rows, ignore_index=True) if indicator_rows else pd.DataFrame()
    onoff_indicator_df.to_csv(out_dirs["tables"] / "onoff_indicator.csv", index=False)

    stepb_features_df = pd.concat(stepb_feature_rows, ignore_index=True) if stepb_feature_rows else pd.DataFrame()
    stepb_pred_df = pd.concat(stepb_pred_rows, ignore_index=True) if stepb_pred_rows else pd.DataFrame()
    if "sed_hat" in stepb_pred_df.columns:
        stepb_pred_df["SED_hat"] = stepb_pred_df["sed_hat"]
    stepb_coef_df = pd.concat(stepb_coef_rows, ignore_index=True) if stepb_coef_rows else pd.DataFrame()
    stepb_features_df.to_csv(out_dirs["tables"] / "onoff_stepB_features.csv", index=False)
    stepb_pred_df.to_csv(out_dirs["tables"] / "onoff_stepB_pred.csv", index=False)
    stepb_coef_df.to_csv(out_dirs["tables"] / "onoff_stepB_coef.csv", index=False)

    returns_by_strategy = pd.concat(
        [make_monthly_returns_from_nav(nav_df[sid]).rename(sid) for sid in strategy_ids],
        axis=1,
    ).sort_index()
    base_bundle = results_all["T1_mom"]["bundle"] if "T1_mom" in results_all else results_all[strategy_ids[0]]["bundle"]
    factor_monthly = _compute_factor_monthly(base_bundle=base_bundle, target_index=returns_by_strategy.index)
    betas_df, contrib_df, alpha_df, resid_stats_df = rolling_factor_attribution(
        returns_by_strategy=returns_by_strategy,
        factor_returns=factor_monthly,
        window_months=36,
        lag=1,
    )
    betas_df.to_csv(out_dirs["tables"] / "attribution_factor_betas.csv", index=False)
    contrib_df.to_csv(out_dirs["tables"] / "attribution_factor_contrib.csv", index=False)
    contrib_df.to_csv(out_dirs["tables"] / "attribution_factor_contrib_all.csv", index=False)
    alpha_df.to_csv(out_dirs["tables"] / "attribution_factor_alpha.csv", index=False)
    alpha_df.to_csv(out_dirs["tables"] / "attribution_factor_alpha_all.csv", index=False)
    resid_stats_df.to_csv(out_dirs["tables"] / "attribution_resid_stats.csv", index=False)

    line_sid = _select_line_strategy(summary_df, fallback=recommended_strategy_id)

    fig_beta = out_dirs["figures"] / "rolling_beta_eqw.png"
    plt.figure(figsize=(14, 7))
    if not betas_df.empty and (betas_df["factor_name"] == "EQW").any():
        beta_eqw = betas_df[betas_df["factor_name"] == "EQW"].pivot(index="date", columns="strategy_id", values="beta").sort_index()
        for sid in beta_eqw.columns:
            plt.plot(beta_eqw.index, beta_eqw[sid], linewidth=1.0, label=sid)
        plt.legend(ncol=2, fontsize=8)
    else:
        plt.text(0.05, 0.5, "No EQW beta data", transform=plt.gca().transAxes)
    plt.title("Rolling Beta to EQW (eqw_plus_rates, W=36, lag=1)")
    plt.xlabel("Date")
    plt.ylabel("beta_EQW")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(fig_beta, dpi=180)
    plt.close()

    fig_contrib = out_dirs["figures"] / "factor_contrib_eqw_plus_rates.png"
    plt.figure(figsize=(14, 7))
    if not contrib_df.empty and not alpha_df.empty and line_sid in set(contrib_df["strategy_id"]):
        c_rep = contrib_df[contrib_df["strategy_id"] == line_sid].pivot(index="date", columns="factor_name", values="contrib").sort_index()
        a_rep = alpha_df[alpha_df["strategy_id"] == line_sid].set_index("date").sort_index()
        eqw_contrib = c_rep["EQW"] if "EQW" in c_rep.columns else pd.Series(0.0, index=c_rep.index)
        ief_contrib = c_rep["IEF"] if "IEF" in c_rep.columns else pd.Series(0.0, index=c_rep.index)
        other_contrib = c_rep.sum(axis=1, min_count=1).fillna(0.0) - eqw_contrib.reindex(c_rep.index, fill_value=0.0) - ief_contrib.reindex(c_rep.index, fill_value=0.0)
        plt.plot(eqw_contrib.index, eqw_contrib, label="contrib_EQW", linewidth=1.2)
        plt.plot(ief_contrib.index, ief_contrib, label="contrib_IEF", linewidth=1.2)
        plt.plot(other_contrib.index, other_contrib, label="contrib_OTHER", linewidth=1.2, linestyle="--")
        if "alpha" in a_rep.columns:
            plt.plot(a_rep.index, a_rep["alpha"], label="alpha", linewidth=1.2)
        if "resid" in a_rep.columns:
            plt.plot(a_rep.index, a_rep["resid"], label="resid", linewidth=1.0, alpha=0.6)
        plt.legend(fontsize=8, ncol=2)
    else:
        plt.text(0.05, 0.5, "No factor contribution data", transform=plt.gca().transAxes)
    plt.title(f"Factor Contribution (EQW/IEF/OTHER + alpha/resid) - {line_sid}")
    plt.xlabel("Date")
    plt.ylabel("Monthly contribution")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(fig_contrib, dpi=180)
    plt.close()

    internal_rows = []
    for sid in strategy_ids:
        if sid == "EQW":
            w_sid = results_all[sid]["backtest"]["eqw_effective_holdings"]
        else:
            w_sid = results_all[sid]["backtest"]["strategy_effective_holdings"]
        internal_sid = internal_selection_weighting_attribution(
            weights=w_sid,
            asset_returns=results_all[sid]["bundle"]["returns"],
            rebalance_dates=results_all[sid]["rebalance_mask"],
            top_k=results_all[sid]["config"].top_k,
        )
        internal_sid["strategy_id"] = sid
        internal_rows.append(internal_sid)
    internal_attr_df = pd.concat(internal_rows, ignore_index=True) if internal_rows else pd.DataFrame(
        columns=["date", "strategy_id", "R_sel", "R_port", "R_wgt"]
    )
    if not internal_attr_df.empty:
        internal_attr_df = internal_attr_df[["date", "strategy_id", "R_sel", "R_port", "R_wgt"]]
    internal_attr_df.to_csv(out_dirs["tables"] / "attribution_internal_selection_weighting.csv", index=False)

    fig_internal = out_dirs["figures"] / "attribution_internal_sel_wgt.png"
    plt.figure(figsize=(14, 7))
    if not internal_attr_df.empty and line_sid in set(internal_attr_df["strategy_id"]):
        irep = internal_attr_df[internal_attr_df["strategy_id"] == line_sid].copy()
        irep["date"] = pd.to_datetime(irep["date"])
        irep = irep.sort_values("date")
        plt.plot(irep["date"], irep["R_sel"], label="R_sel", linewidth=1.2)
        plt.plot(irep["date"], irep["R_wgt"], label="R_wgt", linewidth=1.2)
        plt.plot(irep["date"], irep["R_port"], label="R_port", linewidth=1.0, alpha=0.5)
        plt.legend(fontsize=8)
    else:
        plt.text(0.05, 0.5, "No internal attribution", transform=plt.gca().transAxes)
    plt.title(f"Internal Attribution (Selection vs Weighting) - {line_sid}")
    plt.xlabel("Date")
    plt.ylabel("Monthly return")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(fig_internal, dpi=180)
    plt.close()

    overlay_rows = []
    for sid in onoff_ids:
        if sid not in results_all or "T1_base_best" not in results_all:
            continue
        method_name = "stepB" if "statepred" in sid.lower() else "stepA"
        ov = overlay_attribution(
            managed_returns=results_all[sid]["backtest"]["strategy_net_returns"],
            base_returns=results_all["T1_base_best"]["backtest"]["strategy_net_returns"],
            indicator=results_all[sid]["indicator_df"]["indicator"],
            meta={
                "managed_strategy_id": sid,
                "base_strategy_id": "T1_base_best",
                "eta": results_all[sid]["summary"].get("onoff_eta", np.nan),
                "M": results_all[sid]["summary"].get("onoff_M", np.nan),
                "method": method_name,
            },
        )
        overlay_rows.append(ov)
    overlay_attr_df = pd.concat(overlay_rows, ignore_index=True) if overlay_rows else pd.DataFrame(
        columns=["date", "managed_strategy_id", "base_strategy_id", "overlay_excess", "indicator", "eta", "M", "method"]
    )
    overlay_attr_df.to_csv(out_dirs["tables"] / "attribution_overlay_excess.csv", index=False)

    fig_overlay = out_dirs["figures"] / "overlay_excess_vs_indicator.png"
    plt.figure(figsize=(14, 7))
    if not overlay_attr_df.empty:
        sid_overlay = line_sid if line_sid in set(overlay_attr_df["managed_strategy_id"]) else str(overlay_attr_df["managed_strategy_id"].iloc[0])
        orep = overlay_attr_df[overlay_attr_df["managed_strategy_id"] == sid_overlay].copy()
        orep["date"] = pd.to_datetime(orep["date"])
        orep = orep.sort_values("date")

        ax = plt.gca()
        ax.plot(orep["date"], orep["overlay_excess"], label="overlay_excess", linewidth=1.2)
        ax.set_ylabel("overlay_excess")
        ax.grid(alpha=0.25)
        ax2 = ax.twinx()
        ax2.plot(orep["date"], orep["indicator"], label="indicator", linewidth=1.0, alpha=0.7)
        ax2.set_ylabel("indicator")
        l1, lab1 = ax.get_legend_handles_labels()
        l2, lab2 = ax2.get_legend_handles_labels()
        ax.legend(l1 + l2, lab1 + lab2, fontsize=8, loc="upper left")
        plt.title(f"Overlay Excess vs Indicator ({sid_overlay})")
    else:
        plt.text(0.05, 0.5, "No overlay strategies", transform=plt.gca().transAxes)
        plt.title("Overlay Excess vs Indicator")
    plt.xlabel("Date")
    plt.tight_layout()
    plt.savefig(fig_overlay, dpi=180)
    plt.close()

    rep_ids = representative_ids if representative_ids is not None else list(DEFAULT_REPRESENTATIVE_IDS)
    rep_ids = [sid for sid in rep_ids if sid in results_all]

    selected_rows = []
    for sid in rep_ids:
        role = sid
        if sid == "EQW":
            role = "EQW"
        elif sid == "T1_base_best":
            role = "T1_base_best"
        elif sid == FULL_SPEC_RECOMMENDED_ID:
            role = "FullSpec_recommended"
        elif sid == "T2_resid_eqw_only":
            role = "T2_reference"
        test_sharpe = np.nan
        row = summary_df[summary_df["strategy_id"] == sid]
        if not row.empty:
            test_sharpe = float(row.iloc[0]["TestSharpe"])
        selected_rows.append({"role": role, "strategy_id": sid, "TestSharpe": test_sharpe})
    dashboard_selected_df = pd.DataFrame(selected_rows)
    dashboard_selected_df.to_csv(out_dirs["tables"] / "dashboard_selected_strategies.csv", index=False)

    dashboard_paths: list[Path] = []
    for sid in rep_ids:
        comp = _build_dashboard_components(
            sid=sid,
            results_all=results_all,
            factor_contrib_all=contrib_df,
            factor_alpha_all=alpha_df,
            internal_all=internal_attr_df,
            overlay_all=overlay_attr_df,
        )
        comp_path = out_dirs["tables"] / f"dashboard_components_{sid}.csv"
        comp.reset_index().to_csv(comp_path, index=False)

        fig, axes = plt.subplots(4, 1, figsize=(14, 14), sharex=True)

        axes[0].plot(comp.index, comp["nav"], label=sid, linewidth=1.8)
        axes[0].plot(comp.index, comp["nav_eqw"], label="EQW", linewidth=1.5)
        axes[0].set_title(
            f"{sid} | rebalance={base_cfg.rebalance}, top_k={base_cfg.top_k}, "
            f"exec_lag={base_cfg.exec_lag}, split={base_cfg.split_date}"
        )
        axes[0].set_ylabel("NAV")
        axes[0].grid(alpha=0.25)
        axes[0].legend(fontsize=8)

        axes[1].plot(comp.index, comp["contrib_EQW"], label="EQW", linewidth=1.2)
        axes[1].plot(comp.index, comp["contrib_IEF"], label="IEF", linewidth=1.2)
        axes[1].plot(comp.index, comp["contrib_OTHER"], label="OTHER", linewidth=1.2, linestyle="--")
        axes[1].plot(comp.index, comp["alpha_or_resid"], label="alpha_or_resid", linewidth=1.1)
        axes[1].set_ylabel("Factor contrib")
        axes[1].grid(alpha=0.25)
        axes[1].legend(fontsize=8, ncol=2)

        if comp[["R_sel", "R_wgt"]].notna().any().any():
            axes[2].plot(comp.index, comp["R_sel"], label="R_sel", linewidth=1.2)
            axes[2].plot(comp.index, comp["R_wgt"], label="R_wgt", linewidth=1.2)
            axes[2].plot(comp.index, comp["R_port"], label="R_port", linewidth=1.0, alpha=0.4)
            axes[2].legend(fontsize=8)
        else:
            axes[2].text(0.02, 0.5, "N/A", transform=axes[2].transAxes)
        axes[2].set_ylabel("Internal")
        axes[2].grid(alpha=0.25)

        if comp["indicator"].notna().any():
            ax4 = axes[3]
            ax4.plot(comp.index, comp["overlay_excess"], label="overlay_excess", linewidth=1.2)
            ax4.set_ylabel("Overlay excess")
            ax4.grid(alpha=0.25)
            ax4b = ax4.twinx()
            ax4b.plot(comp.index, comp["indicator"], label="indicator", linewidth=1.0, alpha=0.7)
            ax4b.set_ylabel("indicator")
            l1, lab1 = ax4.get_legend_handles_labels()
            l2, lab2 = ax4b.get_legend_handles_labels()
            ax4.legend(l1 + l2, lab1 + lab2, fontsize=8, loc="upper left")
        else:
            axes[3].text(0.02, 0.5, "No overlay", transform=axes[3].transAxes, fontsize=11)
            axes[3].set_axis_off()

        plt.tight_layout()
        fig_path = out_dirs["figures"] / f"dashboard_{sid}.png"
        plt.savefig(fig_path, dpi=180)
        plt.close()
        dashboard_paths.append(fig_path)

    best_row = summary_df.sort_values(["TestSharpe", "Sharpe"], ascending=False).iloc[0]
    best_sid = str(best_row["strategy_id"])
    split_ts = pd.Timestamp(params["split_date"])

    beta_eqw = betas_df[betas_df["factor_name"] == "EQW"].copy()
    beta_eqw["date"] = pd.to_datetime(beta_eqw["date"])
    beta_test = beta_eqw[beta_eqw["date"] >= split_ts]
    beta_best = float(beta_test[beta_test["strategy_id"] == best_sid]["beta"].mean()) if not beta_test.empty else np.nan
    beta_base = float(beta_test[beta_test["strategy_id"] == "T1_base_best"]["beta"].mean()) if not beta_test.empty else np.nan

    alpha_df2 = alpha_df.copy()
    alpha_df2["date"] = pd.to_datetime(alpha_df2["date"])
    alpha_test = alpha_df2[alpha_df2["date"] >= split_ts]
    alpha_best = float(alpha_test[alpha_test["strategy_id"] == best_sid]["alpha"].mean()) if not alpha_test.empty else np.nan
    alpha_base = float(alpha_test[alpha_test["strategy_id"] == "T1_base_best"]["alpha"].mean()) if not alpha_test.empty else np.nan

    internal_test = internal_attr_df.copy()
    if not internal_test.empty:
        internal_test["date"] = pd.to_datetime(internal_test["date"])
        internal_test = internal_test[(internal_test["strategy_id"] == best_sid) & (internal_test["date"] >= split_ts)]
    sel_sum = float(internal_test["R_sel"].sum()) if not internal_test.empty else np.nan
    wgt_sum = float(internal_test["R_wgt"].sum()) if not internal_test.empty else np.nan

    overlay_test = overlay_attr_df.copy()
    if not overlay_test.empty:
        overlay_test["date"] = pd.to_datetime(overlay_test["date"])
        overlay_test = overlay_test[
            (overlay_test["managed_strategy_id"] == best_sid) & (overlay_test["date"] >= split_ts)
        ]
    overlay_sum = float(overlay_test["overlay_excess"].sum()) if not overlay_test.empty else 0.0

    base_row = summary_df[summary_df["strategy_id"] == "T1_base_best"]
    base_turnover = float(base_row.iloc[0]["AvgTurnover"]) if not base_row.empty else np.nan
    base_total_cost = float(base_row.iloc[0]["TotalCost"]) if not base_row.empty else np.nan

    conclusion = {
        "best_strategy_id": best_sid,
        "recommended_strategy_id": recommended_strategy_id,
        "recommended_is_best": bool(best_sid == recommended_strategy_id),
        "best_train_metrics": summary_period_df[
            (summary_period_df["strategy_id"] == best_sid) & (summary_period_df["period"] == "Train")
        ].iloc[0].to_dict(),
        "best_test_metrics": summary_period_df[
            (summary_period_df["strategy_id"] == best_sid) & (summary_period_df["period"] == "Test")
        ].iloc[0].to_dict(),
        "best_all_metrics": summary_period_df[
            (summary_period_df["strategy_id"] == best_sid) & (summary_period_df["period"] == "All")
        ].iloc[0].to_dict(),
        "beta_eqw_best_test_mean": beta_best,
        "beta_eqw_t1base_test_mean": beta_base,
        "alpha_best_test_mean": alpha_best,
        "alpha_t1base_test_mean": alpha_base,
        "beta_change_vs_t1base": beta_best - beta_base if pd.notna(beta_best) and pd.notna(beta_base) else np.nan,
        "alpha_change_vs_t1base": alpha_best - alpha_base if pd.notna(alpha_best) and pd.notna(alpha_base) else np.nan,
        "selection_sum_test": sel_sum,
        "weighting_sum_test": wgt_sum,
        "overlay_sum_test": overlay_sum,
        "avg_turnover_best": float(best_row["AvgTurnover"]),
        "avg_turnover_t1base": base_turnover,
        "total_cost_best": float(best_row["TotalCost"]),
        "total_cost_t1base": base_total_cost,
    }

    return {
        "base_cfg": base_cfg,
        "strategy_ids": strategy_ids,
        "strategy_specs": strategy_specs,
        "results_all": results_all,
        "nav_all": nav_df,
        "summary_all": summary_df,
        "summary_period": summary_period_df,
        "onoff_indicator": onoff_indicator_df,
        "stepb_features": stepb_features_df,
        "stepb_pred": stepb_pred_df,
        "stepb_coef": stepb_coef_df,
        "attribution_betas": betas_df,
        "attribution_contrib": contrib_df,
        "attribution_alpha": alpha_df,
        "attribution_resid": resid_stats_df,
        "attribution_internal": internal_attr_df,
        "attribution_overlay": overlay_attr_df,
        "dashboard_selected": dashboard_selected_df,
        "best_strategy_id": best_sid,
        "recommended_strategy_id": recommended_strategy_id,
        "conclusion": conclusion,
        "output_paths": {
            **nav_paths,
            "summary": out_dirs["tables"] / "nav_summary_with_onoff_stepB.csv",
            "summary_period": out_dirs["tables"] / "nav_summary_train_test_all_with_onoff_stepB.csv",
            "attribution_beta_fig": fig_beta,
            "attribution_contrib_fig": fig_contrib,
            "attribution_internal_fig": fig_internal,
            "attribution_overlay_fig": fig_overlay,
            "dashboard_paths": dashboard_paths,
            "dashboard_selected": out_dirs["tables"] / "dashboard_selected_strategies.csv",
        },
    }
