"""Single source of truth for strategy_id definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class StrategySpec:
    strategy_id: str
    description: str
    config_overrides: dict[str, Any]
    use_eqw_output: bool = False


def get_strategy_specs(include_optional_t3_on_t2: bool = True) -> dict[str, StrategySpec]:
    """Return ordered strategy specifications keyed by strategy_id."""
    specs: dict[str, StrategySpec] = {
        "EQW": StrategySpec(
            strategy_id="EQW",
            description="Investable-universe equal-weight benchmark",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
            },
            use_eqw_output=True,
        ),
        "T1_mom": StrategySpec(
            strategy_id="T1_mom",
            description="T1 momentum-only baseline",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
            },
        ),
        "T1_base_best": StrategySpec(
            strategy_id="T1_base_best",
            description="Best current T1 base (alias of baseline momentum)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
            },
        ),
        "T1_base_best_onoff_eta0": StrategySpec(
            strategy_id="T1_base_best_onoff_eta0",
            description="T1 base + ON/OFF overlay (eta=0.0, full off)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
                "onoff_enabled": True,
                "onoff_method": "lagged_sed",
                "onoff_eta": 0.0,
                "onoff_lookback": 63,
                "onoff_min_train": 126,
            },
        ),
        "T1_base_best_onoff_eta0p2": StrategySpec(
            strategy_id="T1_base_best_onoff_eta0p2",
            description="T1 base + ON/OFF overlay (eta=0.2)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
                "onoff_enabled": True,
                "onoff_method": "lagged_sed",
                "onoff_eta": 0.2,
                "onoff_lookback": 63,
                "onoff_min_train": 126,
            },
        ),
        "T1_base_best_onoff_eta0p5": StrategySpec(
            strategy_id="T1_base_best_onoff_eta0p5",
            description="T1 base + ON/OFF overlay (eta=0.5)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
                "onoff_enabled": True,
                "onoff_method": "lagged_sed",
                "onoff_eta": 0.5,
                "onoff_lookback": 63,
                "onoff_min_train": 126,
            },
        ),
        "T1_best_onoff_statepred_M6_eta0": StrategySpec(
            strategy_id="T1_best_onoff_statepred_M6_eta0",
            description="T1 best base + StepB state prediction ON/OFF (M=6, eta=0.0)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
                "onoff_enabled": True,
                "onoff_method": "state_pred",
                "onoff_eta": 0.0,
                "onoff_target_m": 6,
                "onoff_use_vol_norm": True,
                "onoff_state_model": "ols",
                "onoff_min_train": 36,
            },
        ),
        "T1_best_onoff_statepred_M6_eta0p2": StrategySpec(
            strategy_id="T1_best_onoff_statepred_M6_eta0p2",
            description="T1 best base + StepB state prediction ON/OFF (M=6, eta=0.2)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
                "onoff_enabled": True,
                "onoff_method": "state_pred",
                "onoff_eta": 0.2,
                "onoff_target_m": 6,
                "onoff_use_vol_norm": True,
                "onoff_state_model": "ols",
                "onoff_min_train": 36,
            },
        ),
        "T1_best_onoff_statepred_M6_eta0p5": StrategySpec(
            strategy_id="T1_best_onoff_statepred_M6_eta0p5",
            description="T1 best base + StepB state prediction ON/OFF (M=6, eta=0.5)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
                "onoff_enabled": True,
                "onoff_method": "state_pred",
                "onoff_eta": 0.5,
                "onoff_target_m": 6,
                "onoff_use_vol_norm": True,
                "onoff_state_model": "ols",
                "onoff_min_train": 36,
            },
        ),
        "T1_best_onoff_statepred_M12_eta0": StrategySpec(
            strategy_id="T1_best_onoff_statepred_M12_eta0",
            description="T1 best base + StepB state prediction ON/OFF (M=12, eta=0.0)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
                "onoff_enabled": True,
                "onoff_method": "state_pred",
                "onoff_eta": 0.0,
                "onoff_target_m": 12,
                "onoff_use_vol_norm": True,
                "onoff_state_model": "ols",
                "onoff_min_train": 36,
            },
        ),
        "T1_best_onoff_statepred_M12_eta0p2": StrategySpec(
            strategy_id="T1_best_onoff_statepred_M12_eta0p2",
            description="T1 best base + StepB state prediction ON/OFF (M=12, eta=0.2)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
                "onoff_enabled": True,
                "onoff_method": "state_pred",
                "onoff_eta": 0.2,
                "onoff_target_m": 12,
                "onoff_use_vol_norm": True,
                "onoff_state_model": "ols",
                "onoff_min_train": 36,
            },
        ),
        "T1_best_onoff_statepred_M12_eta0p5": StrategySpec(
            strategy_id="T1_best_onoff_statepred_M12_eta0p5",
            description="T1 best base + StepB state prediction ON/OFF (M=12, eta=0.5)",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "baseline",
                "factor_set": "minimal_3",
                "onoff_enabled": True,
                "onoff_method": "state_pred",
                "onoff_eta": 0.5,
                "onoff_target_m": 12,
                "onoff_use_vol_norm": True,
                "onoff_state_model": "ols",
                "onoff_min_train": 36,
            },
        ),
        "T1_mom_attn": StrategySpec(
            strategy_id="T1_mom_attn",
            description="T1 momentum + attention proxy",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "momentum_attention",
                "factor_set": "minimal_3",
                "lambda_attn": 0.35,
            },
        ),
        "T1_mom_attn_risk": StrategySpec(
            strategy_id="T1_mom_attn_risk",
            description="T1 momentum + attention - risk/downside",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "momentum_attention_risk",
                "factor_set": "minimal_3",
                "lambda_attn": 0.35,
                "lambda_risk": 0.20,
                "lambda_down": 0.20,
            },
        ),
        "T1_mom_attn_risk_tc": StrategySpec(
            strategy_id="T1_mom_attn_risk_tc",
            description="T1 momentum + attention - risk/downside - turnover penalty",
            config_overrides={
                "strategy_mode": "T1",
                "t1_variant": "momentum_attention_risk_tc",
                "factor_set": "minimal_3",
                "lambda_attn": 0.35,
                "lambda_risk": 0.20,
                "lambda_down": 0.20,
                "lambda_tc": 0.20,
            },
        ),
        "T2_resid_minimal3": StrategySpec(
            strategy_id="T2_resid_minimal3",
            description="T2 residual momentum (minimal_3, no corr penalty)",
            config_overrides={
                "strategy_mode": "T2",
                "t2_variant": "baseline",
                "factor_set": "minimal_3",
                "lambda_corr": 0.0,
            },
        ),
        "T2_resid_ext10": StrategySpec(
            strategy_id="T2_resid_ext10",
            description="T2 residual momentum (extended_10, no corr penalty)",
            config_overrides={
                "strategy_mode": "T2",
                "t2_variant": "baseline",
                "factor_set": "extended_10",
                "lambda_corr": 0.0,
            },
        ),
        "T2_resid_eqw_only": StrategySpec(
            strategy_id="T2_resid_eqw_only",
            description="T2 residual momentum (eqw_only, no corr penalty)",
            config_overrides={
                "strategy_mode": "T2",
                "t2_variant": "baseline",
                "factor_set": "eqw_only",
                "lambda_corr": 0.0,
            },
        ),
        "T2_resid_corrpen_minimal3": StrategySpec(
            strategy_id="T2_resid_corrpen_minimal3",
            description="T2 residual + correlation penalty (minimal_3)",
            config_overrides={
                "strategy_mode": "T2",
                "t2_variant": "baseline",
                "factor_set": "minimal_3",
                "lambda_corr": 0.25,
            },
        ),
        "T3_purity_mult_on_T1": StrategySpec(
            strategy_id="T3_purity_mult_on_T1",
            description="T3 purity multiplicative adjustment on T1_mom_attn_risk",
            config_overrides={
                "strategy_mode": "T3",
                "t3_variant": "mult_on_t1",
                "factor_set": "minimal_3",
                "lambda_attn": 0.35,
                "lambda_risk": 0.20,
                "lambda_down": 0.20,
                "lambda_text": 0.20,
                "lambda_amb": 0.50,
            },
        ),
        "T3_purity_cap_on_T1": StrategySpec(
            strategy_id="T3_purity_cap_on_T1",
            description="T3 purity cap adjustment on T1_mom_attn_risk",
            config_overrides={
                "strategy_mode": "T3",
                "t3_variant": "cap_on_t1",
                "factor_set": "minimal_3",
                "lambda_attn": 0.35,
                "lambda_risk": 0.20,
                "lambda_down": 0.20,
                "lambda_text": 0.20,
                "lambda_amb": 0.50,
                "t3_cap_quantile": 0.85,
            },
        ),
    }

    if include_optional_t3_on_t2:
        specs["T3_purity_mult_on_T2"] = StrategySpec(
            strategy_id="T3_purity_mult_on_T2",
            description="(Optional) T3 purity multiplicative adjustment on T2",
            config_overrides={
                "strategy_mode": "T3",
                "t3_variant": "mult_on_t2",
                "t2_variant": "baseline",
                "factor_set": "minimal_3",
                "lambda_corr": 0.25,
                "lambda_text": 0.20,
                "lambda_amb": 0.50,
            },
        )
        specs["T3_purity_cap_on_T2"] = StrategySpec(
            strategy_id="T3_purity_cap_on_T2",
            description="(Optional) T3 purity cap adjustment on T2",
            config_overrides={
                "strategy_mode": "T3",
                "t3_variant": "cap_on_t2",
                "t2_variant": "baseline",
                "factor_set": "minimal_3",
                "lambda_corr": 0.25,
                "lambda_text": 0.20,
                "lambda_amb": 0.50,
                "t3_cap_quantile": 0.85,
            },
        )

    return specs


def list_strategy_ids(include_optional_t3_on_t2: bool = True) -> list[str]:
    return list(get_strategy_specs(include_optional_t3_on_t2=include_optional_t3_on_t2).keys())
