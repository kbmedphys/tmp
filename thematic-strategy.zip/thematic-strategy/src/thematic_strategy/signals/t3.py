"""T3 text-purity utilities based on static ETF metadata."""

from __future__ import annotations

import math
import re
from collections import Counter

import numpy as np
import pandas as pd

_STOPWORDS = {
    "etf",
    "index",
    "indices",
    "fund",
    "global",
    "us",
    "u.s",
    "the",
    "and",
    "of",
    "to",
    "in",
    "for",
    "related",
    "企業",
    "投資",
    "関連",
    "指数",
    "連動",
}


def normalize_text(text: str) -> str:
    text = (text or "").lower()
    text = re.sub(r"[^0-9a-zA-Z\u3040-\u30ff\u3400-\u9fff\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def tokenize(text: str) -> list[str]:
    normalized = normalize_text(text)
    tokens = [tok for tok in normalized.split(" ") if tok and tok not in _STOPWORDS]
    return tokens


def vectorize_tokens(tokens: list[str]) -> Counter[str]:
    return Counter(tokens)


def cosine_counter(a: Counter[str], b: Counter[str]) -> float:
    if not a or not b:
        return 0.0
    dot = sum(a[k] * b.get(k, 0.0) for k in a)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    if na == 0.0 or nb == 0.0:
        return 0.0
    return dot / (na * nb)


def compute_text_purity(universe: pd.DataFrame, lambda_amb: float = 0.5) -> pd.Series:
    """Compute static text purity score per ticker."""
    required = {"theme", "objective_strategy_short", "index_name"}
    missing = required - set(universe.columns)
    if missing:
        raise ValueError(f"Universe missing columns for T3 purity: {sorted(missing)}")

    text_map: dict[str, Counter[str]] = {}
    for ticker, row in universe.iterrows():
        text = f"{row.get('objective_strategy_short', '')} {row.get('index_name', '')}"
        text_map[ticker] = vectorize_tokens(tokenize(text))

    theme_groups = universe.groupby("theme").groups
    theme_vectors: dict[str, Counter[str]] = {}
    for theme, tickers in theme_groups.items():
        merged = Counter()
        for ticker in tickers:
            merged.update(text_map[ticker])
        theme_vectors[theme] = merged

    purity = {}
    for ticker, row in universe.iterrows():
        own_theme = row["theme"]
        own_vec = text_map[ticker]

        in_score = cosine_counter(own_vec, theme_vectors[own_theme])
        out_scores = []
        for theme, theme_vec in theme_vectors.items():
            if theme == own_theme:
                continue
            out_scores.append(cosine_counter(own_vec, theme_vec))
        out_score = max(out_scores) if out_scores else 0.0

        purity[ticker] = in_score - lambda_amb * out_score

    purity_series = pd.Series(purity, name="text_purity").reindex(universe.index)
    std = purity_series.std(skipna=True)
    if std and not np.isclose(std, 0.0):
        purity_series = (purity_series - purity_series.mean(skipna=True)) / std
    else:
        purity_series = purity_series - purity_series.mean(skipna=True)
    purity_series.name = "text_purity_z"
    return purity_series


def apply_text_purity_to_scores(
    base_scores: pd.DataFrame,
    purity_by_ticker: pd.Series,
    lambda_text: float = 0.2,
    threshold: float | None = None,
) -> pd.DataFrame:
    """Apply static text purity to dynamic score matrix."""
    aligned_purity = purity_by_ticker.reindex(base_scores.columns)
    score = base_scores.add(lambda_text * aligned_purity, axis=1)
    if threshold is not None:
        mask = aligned_purity >= threshold
        score = score.where(mask, np.nan)
    return score


def apply_text_purity_multiplicative(
    base_scores: pd.DataFrame,
    purity_by_ticker: pd.Series,
    lambda_text: float = 0.2,
    min_multiplier: float = 0.1,
) -> pd.DataFrame:
    """Apply multiplicative purity correction to score matrix."""
    aligned_purity = purity_by_ticker.reindex(base_scores.columns).fillna(0.0)
    multiplier = (1.0 + lambda_text * aligned_purity).clip(lower=min_multiplier)
    return base_scores.mul(multiplier, axis=1)


def apply_text_purity_cap(
    base_scores: pd.DataFrame,
    purity_by_ticker: pd.Series,
    lambda_text: float = 0.2,
    cap_quantile: float = 0.85,
) -> pd.DataFrame:
    """Apply purity-dependent cap to score matrix."""
    aligned_purity = purity_by_ticker.reindex(base_scores.columns)
    purity_rank = aligned_purity.rank(pct=True).fillna(0.5)
    cap_scale = (1.0 - lambda_text) + lambda_text * purity_rank

    row_cap = base_scores.quantile(cap_quantile, axis=1)
    cap_matrix = pd.DataFrame(
        np.outer(row_cap.to_numpy(dtype=float), cap_scale.to_numpy(dtype=float)),
        index=base_scores.index,
        columns=base_scores.columns,
    )
    return base_scores.where(base_scores <= cap_matrix, cap_matrix)
