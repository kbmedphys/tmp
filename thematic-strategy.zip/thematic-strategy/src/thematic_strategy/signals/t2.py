"""T2 residual momentum + correlation penalty signals."""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import StrategyConfig


def _cross_sectional_zscore(frame: pd.DataFrame, mask: pd.DataFrame) -> pd.DataFrame:
    masked = frame.where(mask)
    mean = masked.mean(axis=1, skipna=True)
    std = masked.std(axis=1, skipna=True).replace(0.0, np.nan)
    return masked.sub(mean, axis=0).div(std, axis=0)


def estimate_residuals(
    returns: pd.DataFrame,
    factor_returns: pd.DataFrame,
    cfg: StrategyConfig,
    min_obs: int | None = None,
) -> pd.DataFrame:
    """Estimate one-step residuals with rolling OLS using available information only."""
    lookback = cfg.regression_lookback
    min_obs = min_obs or max(40, lookback // 2)

    aligned = returns.join(factor_returns, how="inner", lsuffix="_ret")
    idx = aligned.index

    asset_cols = list(returns.columns)
    factor_cols = [col for col in factor_returns.columns if col in aligned.columns]

    r_avail = aligned[asset_cols].shift(cfg.exec_lag)
    f_avail = aligned[factor_cols].shift(cfg.exec_lag)

    residuals = pd.DataFrame(np.nan, index=idx, columns=asset_cols)

    for t in range(lookback - 1, len(idx)):
        w0 = t - lookback + 1
        w1 = t + 1

        x_window_all = f_avail.iloc[w0:w1]
        if x_window_all.dropna(how="all").empty:
            continue

        x_t = f_avail.iloc[t]
        if x_t.isna().any():
            continue

        x_t_vec = np.concatenate(([1.0], x_t.to_numpy(dtype=float)))

        for asset in asset_cols:
            y_window = r_avail[asset].iloc[w0:w1]
            reg_df = pd.concat([y_window.rename("y"), x_window_all], axis=1).dropna()
            if len(reg_df) < min_obs:
                continue

            y = reg_df["y"].to_numpy(dtype=float)
            x = reg_df[factor_cols].to_numpy(dtype=float)
            x = np.column_stack([np.ones(len(x)), x])

            beta, *_ = np.linalg.lstsq(x, y, rcond=None)
            y_t = r_avail.iloc[t][asset]
            if pd.isna(y_t):
                continue

            residuals.iat[t, residuals.columns.get_loc(asset)] = y_t - float(x_t_vec @ beta)

    return residuals


def compute_corr_penalty(
    residuals: pd.DataFrame,
    investable_mask: pd.DataFrame,
    window: int,
) -> pd.DataFrame:
    """Compute average positive pairwise correlation penalty for each asset/date."""
    penalty = pd.DataFrame(np.nan, index=residuals.index, columns=residuals.columns)
    min_periods = max(20, window // 2)

    for t in range(window - 1, len(residuals.index)):
        date = residuals.index[t]
        win = residuals.iloc[t - window + 1 : t + 1]
        corr = win.corr(min_periods=min_periods)

        eligible = investable_mask.loc[date]
        assets = [asset for asset in residuals.columns if bool(eligible.get(asset, False))]
        if len(assets) <= 1:
            continue

        for asset in assets:
            peers = [p for p in assets if p != asset]
            vals = corr.loc[asset, peers].dropna()
            if vals.empty:
                continue
            penalty.loc[date, asset] = vals.clip(lower=0.0).mean()

    return penalty


def compute_t2_scores(
    returns: pd.DataFrame,
    factor_returns: pd.DataFrame,
    investable_mask: pd.DataFrame,
    cfg: StrategyConfig,
    variant: str | None = None,
) -> dict[str, pd.DataFrame]:
    """Compute T2 score matrix and diagnostics."""
    variant = variant or cfg.t2_variant

    residuals = estimate_residuals(returns=returns, factor_returns=factor_returns, cfg=cfg)
    trend = residuals.rolling(cfg.residual_window, min_periods=max(20, cfg.residual_window // 2)).mean()
    risk = residuals.rolling(cfg.residual_window, min_periods=max(20, cfg.residual_window // 2)).std()
    down = residuals.clip(upper=0.0).rolling(cfg.residual_window, min_periods=max(20, cfg.residual_window // 2)).std()

    corr_pen = compute_corr_penalty(
        residuals=residuals,
        investable_mask=investable_mask,
        window=cfg.corr_window,
    )

    z_trend = _cross_sectional_zscore(trend, investable_mask)
    z_risk = _cross_sectional_zscore(risk, investable_mask)
    z_down = _cross_sectional_zscore(down, investable_mask)
    z_corr = _cross_sectional_zscore(corr_pen, investable_mask)

    if variant == "baseline":
        score = z_trend - cfg.lambda_corr * z_corr
    elif variant == "risk_aware":
        score = z_trend - cfg.lambda_risk * z_risk - cfg.lambda_down * z_down - cfg.lambda_corr * z_corr
    else:
        raise ValueError(f"Unsupported T2 variant: {variant}")

    score = score.where(investable_mask)

    return {
        "score": score,
        "residuals": residuals,
        "corr_penalty": corr_pen,
    }
