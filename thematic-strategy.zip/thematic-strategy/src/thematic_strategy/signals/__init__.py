"""Signal submodules for T1/T2/T3."""

from .t1 import apply_onoff_overlay, compute_t1_scores
from .t2 import compute_t2_scores
from .t3 import (
    apply_text_purity_cap,
    apply_text_purity_multiplicative,
    apply_text_purity_to_scores,
    compute_text_purity,
)

__all__ = [
    "compute_t1_scores",
    "apply_onoff_overlay",
    "compute_t2_scores",
    "compute_text_purity",
    "apply_text_purity_to_scores",
    "apply_text_purity_multiplicative",
    "apply_text_purity_cap",
]
