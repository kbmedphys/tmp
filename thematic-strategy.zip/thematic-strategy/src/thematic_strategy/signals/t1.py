"""T1 price/volume-based thematic rotation signals."""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import StrategyConfig


def _cross_sectional_zscore(frame: pd.DataFrame, mask: pd.DataFrame) -> pd.DataFrame:
    masked = frame.where(mask)
    mean = masked.mean(axis=1, skipna=True)
    std = masked.std(axis=1, skipna=True)
    std = std.replace(0.0, np.nan)
    z = masked.sub(mean, axis=0).div(std, axis=0)
    return z


def _trend_return(adj_close: pd.DataFrame, lookback: int, exec_lag: int) -> pd.DataFrame:
    lagged_price = adj_close.shift(exec_lag)
    base_price = adj_close.shift(exec_lag + lookback)
    trend = lagged_price.div(base_price).sub(1.0)
    return trend


def _attention_proxy(volume: pd.DataFrame, exec_lag: int, window: int = 20) -> pd.DataFrame:
    log_vol = np.log(volume.shift(exec_lag))
    mean = log_vol.rolling(window=window, min_periods=max(5, window // 2)).mean()
    std = log_vol.rolling(window=window, min_periods=max(5, window // 2)).std()
    std = std.replace(0.0, np.nan)
    return log_vol.sub(mean).div(std)


def _downside_std(returns: pd.DataFrame, exec_lag: int, window: int = 63) -> pd.DataFrame:
    downside = returns.shift(exec_lag).clip(upper=0.0)
    return downside.rolling(window=window, min_periods=max(20, window // 2)).std()


def _volatility(returns: pd.DataFrame, exec_lag: int, window: int = 63) -> pd.DataFrame:
    return returns.shift(exec_lag).rolling(window=window, min_periods=max(20, window // 2)).std()


def _turnover_proxy(score_like: pd.DataFrame, investable_mask: pd.DataFrame) -> pd.DataFrame:
    delta = score_like.diff().abs()
    return _cross_sectional_zscore(delta, investable_mask)


def compute_t1_scores(
    adj_close: pd.DataFrame,
    volume: pd.DataFrame,
    returns: pd.DataFrame,
    investable_mask: pd.DataFrame,
    cfg: StrategyConfig,
    variant: str | None = None,
) -> pd.DataFrame:
    """Compute T1 score matrix."""
    variant = variant or cfg.t1_variant

    trend = _trend_return(adj_close, lookback=cfg.lookback_price, exec_lag=cfg.exec_lag)
    attention = _attention_proxy(volume, exec_lag=cfg.exec_lag, window=20)
    vol = _volatility(returns, exec_lag=cfg.exec_lag, window=63)
    down = _downside_std(returns, exec_lag=cfg.exec_lag, window=63)

    z_trend = _cross_sectional_zscore(trend, investable_mask)
    z_attention = _cross_sectional_zscore(attention, investable_mask)
    z_vol = _cross_sectional_zscore(vol, investable_mask)
    z_down = _cross_sectional_zscore(down, investable_mask)

    if variant == "baseline":
        score = z_trend
    elif variant == "momentum_attention":
        score = z_trend + cfg.lambda_attn * z_attention
    elif variant == "momentum_attention_risk":
        score = z_trend + cfg.lambda_attn * z_attention - cfg.lambda_risk * z_vol - cfg.lambda_down * z_down
    elif variant == "momentum_attention_risk_tc":
        raw = z_trend + cfg.lambda_attn * z_attention - cfg.lambda_risk * z_vol - cfg.lambda_down * z_down
        z_tc = _turnover_proxy(raw, investable_mask)
        score = raw - cfg.lambda_tc * z_tc
    elif variant == "attention_downside":
        score = (
            z_trend
            + cfg.lambda_attn * z_attention
            - cfg.lambda_down * z_down
            - cfg.lambda_risk * z_vol
        )
    elif variant == "risk_adjusted":
        score = z_trend - cfg.lambda_risk * z_vol - cfg.lambda_down * z_down
    else:
        raise ValueError(f"Unsupported T1 variant: {variant}")

    score = score.where(investable_mask)
    return score


def apply_onoff_overlay(
    scores: pd.DataFrame,
    indicator: pd.Series,
    eta: float,
) -> pd.DataFrame:
    """Apply global ON/OFF overlay scale to score matrix."""
    if not (0.0 <= eta <= 1.0):
        raise ValueError("eta must be in [0, 1]")

    ind = indicator.reindex(scores.index).fillna(0.0).astype(float)
    scale = eta + (1.0 - eta) * ind
    return scores.mul(scale, axis=0)
