"""Thematic strategy research package."""

from .attribution import (
    internal_selection_weighting_attribution,
    make_monthly_returns_from_nav,
    overlay_attribution,
    rolling_factor_attribution,
)
from .backtest import run_backtest
from .config import StrategyConfig, build_config, get_factor_tickers, load_universe
from .data import load_or_prepare_data
from .full_spec import (
    DEFAULT_BASE_PARAMS,
    DEFAULT_REPRESENTATIVE_IDS,
    FULL_SPEC_RECOMMENDED_ID,
    run_full_spec_pipeline,
)
from .metrics import compute_metrics_table, compute_missing_return_summary, compute_subperiod_stability
from .portfolio import build_target_weights
from .reporting import ensure_output_dirs, plot_nav, plot_turnover, save_table
from .signal_dispatch import build_scores
from .signals import apply_onoff_overlay
from .state import compute_onoff_indicator, compute_sed
from .strategy_registry import get_strategy_specs, list_strategy_ids

__all__ = [
    "StrategyConfig",
    "make_monthly_returns_from_nav",
    "rolling_factor_attribution",
    "internal_selection_weighting_attribution",
    "overlay_attribution",
    "DEFAULT_BASE_PARAMS",
    "FULL_SPEC_RECOMMENDED_ID",
    "DEFAULT_REPRESENTATIVE_IDS",
    "run_full_spec_pipeline",
    "build_config",
    "load_universe",
    "get_factor_tickers",
    "load_or_prepare_data",
    "build_scores",
    "apply_onoff_overlay",
    "build_target_weights",
    "run_backtest",
    "compute_sed",
    "compute_onoff_indicator",
    "compute_metrics_table",
    "compute_missing_return_summary",
    "compute_subperiod_stability",
    "ensure_output_dirs",
    "plot_nav",
    "plot_turnover",
    "save_table",
    "get_strategy_specs",
    "list_strategy_ids",
]
