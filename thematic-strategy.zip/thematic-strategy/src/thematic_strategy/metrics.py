"""Performance metric calculations."""

from __future__ import annotations

import numpy as np
import pandas as pd


def annualized_return(nav: pd.Series) -> float:
    nav = nav.dropna()
    if nav.empty:
        return np.nan
    years = len(nav) / 252.0
    if years <= 0:
        return np.nan
    return float(nav.iloc[-1] ** (1.0 / years) - 1.0)


def annualized_volatility(returns: pd.Series) -> float:
    r = returns.dropna()
    if len(r) < 2:
        return np.nan
    return float(r.std(ddof=1) * np.sqrt(252.0))


def sharpe_ratio(returns: pd.Series) -> float:
    r = returns.dropna()
    if len(r) < 2:
        return np.nan
    vol = r.std(ddof=1)
    if np.isclose(vol, 0.0):
        return np.nan
    return float((r.mean() / vol) * np.sqrt(252.0))


def max_drawdown(nav: pd.Series) -> float:
    nav = nav.dropna()
    if nav.empty:
        return np.nan
    roll_max = nav.cummax()
    drawdown = nav / roll_max - 1.0
    return float(drawdown.min())


def summarize_period(
    net_returns: pd.Series,
    nav: pd.Series,
    turnover: pd.Series,
    trading_cost: pd.Series,
    expense_cost: pd.Series,
) -> dict[str, float]:
    return {
        "CAGR": annualized_return(nav),
        "Sharpe": sharpe_ratio(net_returns),
        "Vol": annualized_volatility(net_returns),
        "MDD": max_drawdown(nav),
        "AvgTurnover": float(turnover.dropna().mean()) if not turnover.dropna().empty else np.nan,
        "TotalTradingCost": float(trading_cost.dropna().sum()) if not trading_cost.dropna().empty else np.nan,
        "TotalExpenseCost": float(expense_cost.dropna().sum()) if not expense_cost.dropna().empty else np.nan,
        "FinalNAV": float(nav.dropna().iloc[-1]) if not nav.dropna().empty else np.nan,
    }


def _slice_period(series: pd.Series, start: pd.Timestamp | None, end: pd.Timestamp | None) -> pd.Series:
    if start is not None and end is not None:
        return series.loc[(series.index >= start) & (series.index < end)]
    if start is not None:
        return series.loc[series.index >= start]
    if end is not None:
        return series.loc[series.index < end]
    return series


def compute_metrics_table(backtest_result: dict[str, pd.Series], split_date: str) -> pd.DataFrame:
    split_ts = pd.Timestamp(split_date)

    items = {
        "Strategy": {
            "returns": backtest_result["strategy_net_returns"],
            "nav": backtest_result["strategy_nav"],
            "turnover": backtest_result["strategy_turnover"],
            "trading_cost": backtest_result["strategy_trading_cost"],
            "expense_cost": backtest_result["strategy_expense_cost"],
        },
        "EQW": {
            "returns": backtest_result["eqw_net_returns"],
            "nav": backtest_result["eqw_nav"],
            "turnover": backtest_result["eqw_turnover"],
            "trading_cost": backtest_result["eqw_trading_cost"],
            "expense_cost": backtest_result["eqw_expense_cost"],
        },
    }

    rows = []
    period_defs = {
        "All": (None, None),
        "Train": (None, split_ts),
        "Test": (split_ts, None),
    }

    for name, bundle in items.items():
        for period, (start, end) in period_defs.items():
            row = summarize_period(
                net_returns=_slice_period(bundle["returns"], start, end),
                nav=_slice_period(bundle["nav"], start, end),
                turnover=_slice_period(bundle["turnover"], start, end),
                trading_cost=_slice_period(bundle["trading_cost"], start, end),
                expense_cost=_slice_period(bundle["expense_cost"], start, end),
            )
            row["Portfolio"] = name
            row["Period"] = period
            rows.append(row)

    table = pd.DataFrame(rows)
    cols = ["Portfolio", "Period", "CAGR", "Sharpe", "Vol", "MDD", "AvgTurnover", "TotalTradingCost", "TotalExpenseCost", "FinalNAV"]
    return table[cols]


def compute_subperiod_stability(
    net_returns: pd.Series,
    periods: list[tuple[str, str, str | None]],
) -> pd.DataFrame:
    rows = []
    for label, start, end in periods:
        start_ts = pd.Timestamp(start)
        end_ts = pd.Timestamp(end) if end is not None else None
        sliced = _slice_period(net_returns, start_ts, end_ts)
        rows.append(
            {
                "Subperiod": label,
                "Sharpe": sharpe_ratio(sliced),
                "Vol": annualized_volatility(sliced),
                "MeanDailyRet": float(sliced.mean()) if not sliced.dropna().empty else np.nan,
                "Obs": int(sliced.dropna().shape[0]),
            }
        )
    return pd.DataFrame(rows)


def compute_missing_return_summary(
    returns: pd.DataFrame,
    investable_mask: pd.DataFrame,
) -> pd.DataFrame:
    """
    Summarize missing return occurrences during investable periods.

    Note:
    - pre-launch (non-investable) missing values are excluded.
    - summary is reported per ETF and one TOTAL row.
    """
    investable = investable_mask.astype(bool)
    missing = returns.isna() & investable

    investable_days = investable.sum(axis=0)
    missing_days = missing.sum(axis=0)
    ratio = (missing_days / investable_days.replace(0, np.nan)).fillna(0.0)

    out = pd.DataFrame(
        {
            "ticker": investable.columns,
            "investable_days": investable_days.values.astype(int),
            "missing_days": missing_days.values.astype(int),
            "missing_ratio": ratio.values.astype(float),
        }
    )

    total_row = pd.DataFrame(
        [
            {
                "ticker": "__TOTAL__",
                "investable_days": int(investable_days.sum()),
                "missing_days": int(missing_days.sum()),
                "missing_ratio": float(missing_days.sum() / investable_days.sum()) if investable_days.sum() > 0 else 0.0,
                "dates_with_any_missing": int(missing.any(axis=1).sum()),
            }
        ]
    )

    out["dates_with_any_missing"] = np.nan
    out = pd.concat([out, total_row], ignore_index=True)
    out["dates_with_any_missing"] = out["dates_with_any_missing"].fillna(0).astype(int)
    return out
