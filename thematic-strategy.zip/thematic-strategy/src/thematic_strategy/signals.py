"""Signal dispatcher for T1/T2/T3 modes."""

from __future__ import annotations

import pandas as pd

from .config import StrategyConfig
from .signals.t1 import compute_t1_scores
from .signals.t2 import compute_t2_scores
from .signals.t3 import apply_text_purity_to_scores, compute_text_purity


def build_scores(
    cfg: StrategyConfig,
    universe: pd.DataFrame,
    adj_close: pd.DataFrame,
    volume: pd.DataFrame,
    returns: pd.DataFrame,
    investable_mask: pd.DataFrame,
    factor_returns: pd.DataFrame,
) -> dict[str, pd.DataFrame | pd.Series]:
    """Build score matrix according to strategy_mode."""
    if cfg.strategy_mode == "T1":
        score = compute_t1_scores(
            adj_close=adj_close,
            volume=volume,
            returns=returns,
            investable_mask=investable_mask,
            cfg=cfg,
        )
        return {"score": score}

    if cfg.strategy_mode == "T2":
        t2_out = compute_t2_scores(
            returns=returns,
            factor_returns=factor_returns,
            investable_mask=investable_mask,
            cfg=cfg,
        )
        return t2_out

    if cfg.strategy_mode == "T3":
        # T3 uses T2 core score then applies static text purity.
        t2_out = compute_t2_scores(
            returns=returns,
            factor_returns=factor_returns,
            investable_mask=investable_mask,
            cfg=cfg,
            variant="risk_aware",
        )
        purity = compute_text_purity(universe=universe, lambda_amb=cfg.lambda_amb)
        score_t3 = apply_text_purity_to_scores(
            base_scores=t2_out["score"],
            purity_by_ticker=purity,
            lambda_text=cfg.lambda_text,
            threshold=None,
        )
        t2_out["score_base_t2"] = t2_out["score"]
        t2_out["score"] = score_t3
        t2_out["text_purity"] = purity
        return t2_out

    raise ValueError(f"Unsupported strategy_mode: {cfg.strategy_mode}")
