"""Signal dispatcher for T1/T2/T3 modes."""

from __future__ import annotations

import pandas as pd

from .config import StrategyConfig
from .signals.t1 import compute_t1_scores
from .signals.t2 import compute_t2_scores
from .signals.t3 import (
    apply_text_purity_cap,
    apply_text_purity_multiplicative,
    apply_text_purity_to_scores,
    compute_text_purity,
)


def build_scores(
    cfg: StrategyConfig,
    universe: pd.DataFrame,
    adj_close: pd.DataFrame,
    volume: pd.DataFrame,
    returns: pd.DataFrame,
    investable_mask: pd.DataFrame,
    factor_returns: pd.DataFrame,
) -> dict[str, pd.DataFrame | pd.Series]:
    """Build score matrix according to strategy_mode."""
    if cfg.strategy_mode == "T1":
        score = compute_t1_scores(
            adj_close=adj_close,
            volume=volume,
            returns=returns,
            investable_mask=investable_mask,
            cfg=cfg,
        )
        return {"score": score}

    if cfg.strategy_mode == "T2":
        t2_out = compute_t2_scores(
            returns=returns,
            factor_returns=factor_returns,
            investable_mask=investable_mask,
            cfg=cfg,
        )
        return t2_out

    if cfg.strategy_mode == "T3":
        # Choose T1 or T2 as base score and then apply purity correction.
        if cfg.t3_variant in {"mult_on_t1", "cap_on_t1"}:
            base_out = {
                "score": compute_t1_scores(
                    adj_close=adj_close,
                    volume=volume,
                    returns=returns,
                    investable_mask=investable_mask,
                    cfg=cfg,
                    variant="momentum_attention_risk",
                )
            }
        else:
            base_out = compute_t2_scores(
                returns=returns,
                factor_returns=factor_returns,
                investable_mask=investable_mask,
                cfg=cfg,
                variant=cfg.t2_variant,
            )

        purity = compute_text_purity(universe=universe, lambda_amb=cfg.lambda_amb)
        if cfg.t3_variant in {"additive_on_t2", "purity_boost"}:
            score_t3 = apply_text_purity_to_scores(
                base_scores=base_out["score"],
                purity_by_ticker=purity,
                lambda_text=cfg.lambda_text,
                threshold=None,
            )
        elif cfg.t3_variant in {"mult_on_t1", "mult_on_t2"}:
            score_t3 = apply_text_purity_multiplicative(
                base_scores=base_out["score"],
                purity_by_ticker=purity,
                lambda_text=cfg.lambda_text,
            )
        elif cfg.t3_variant in {"cap_on_t1", "cap_on_t2"}:
            score_t3 = apply_text_purity_cap(
                base_scores=base_out["score"],
                purity_by_ticker=purity,
                lambda_text=cfg.lambda_text,
                cap_quantile=cfg.t3_cap_quantile,
            )
        else:
            raise ValueError(f"Unsupported T3 variant: {cfg.t3_variant}")

        base_out["score_base"] = base_out["score"]
        base_out["score"] = score_t3
        base_out["text_purity"] = purity
        return base_out

    raise ValueError(f"Unsupported strategy_mode: {cfg.strategy_mode}")
