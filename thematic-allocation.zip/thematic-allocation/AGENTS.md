# Project Rules: thematic-allocation

このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。
このプロジェクトの Prefer explicit python path は 
- envs/nlp/.venv/bin/python

---

## Source of truth
- ref/CodeSpec.md : 実装仕様書
- ref/thematic_residual_momentum_allocation.ipynb : 実装プログラム（完全版）
  
---

## 0. 目的
本プロジェクトは実装仕様書および実装プログラムに基づきプログラムの解説をする。
実際に使用するデータは特殊な仕様になっているため、プログラム(thematic_residual_momentum_allocation.ipynb)の動作確認を実施したい。
動作確認はユーザが行うため、補助に徹すること。

---

## 1. 進め方
### Phase A: レビューのみ（実装禁止）
- 仕様書を精読、プログラムを確認する。

### Phase B: プログラムの動作確認
主に以下の項目について順番に手元データ形式に合わせた動作確認を実施する。
実装仕様書記載内容をもとに、必要に応じて動作確認項目を増やすことを許可する。
1. テーマ・エクスポージャの構築
2. Barra既知因子からのテーマ純化
3. コヒーレント・テーマ判定
4. 純化テーマ・リターンの推定
5. リスク調整済み残差モメンタム
6. ロングオンリー・テーマ重要度
7. 拡張共分散行列
8. Lee–Liu型テーマバスケット・アロケーション(制約なしの場合の解析解)
9. 残差モメンタムを直接alphaとして使う拡張

動作確認はユーザが行うため、各項目についてプログラム(thematic_residual_momentum_allocation.ipynb)から該当部分を切り出し、１つの項目ごと１つのjupyter notebook で実行できるようにする。
許可なく次の項目へは進まないこと。

---

## 2. 注意
- 許可のない実装は禁止
- 計算ロジックは thematic_residual_momentum_allocation.ipynb に準拠