"""
Replication utilities for:
Candès, Hastie, Hogan, Kahn, Luo, Spector, "Thematic Investing: A Risk-based Perspective".

Purpose
-------
Use LSEG/Refinitiv time-series data to reproduce the paper's core workflow:
1. Build stock return panel.
2. Estimate a cross-sectional risk model and residual returns.
3. Compute average pairwise residual correlation (APC) for broker/theme baskets.
4. Bootstrap a null distribution and z-score for APC.
5. Test whether significant coherent themes show residual-return trending.

This file is intentionally written as a research scaffold. It does not require
lseg.data at import time; LSEG functions import lseg.data only when called.

Important
---------
The paper's exact Mosaic + bootstrap test is technically involved. This module
implements:
- a paper-faithful cross-sectional residualization framework;
- a basic residual permutation bootstrap;
- a block permutation bootstrap approximation that preserves short residual
autocorrelation better than iid shuffling.

For production-grade exact Mosaic+bootstrap, adapt `bootstrap_apc_zscore` to
re-run cross-sectional regressions inside randomized stock/time tiles.
"""
from __future__ import annotations

import math
import os
import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

@dataclass
class RiskModelConfig:
    """Cross-sectional risk model configuration."""
    use_intercept: bool = True
    industry_col: str = "trbc_industry"
    style_cols: Tuple[str, ...] = ("log_mcap", "value", "momentum", "volatility", "liquidity")
    min_obs: int = 50
    ridge_lambda: float = 1e-6
    winsor_z: float = 5.0


@dataclass
class APCConfig:
    """APC and bootstrap configuration."""
    apc_window_days: int = 60           # calendar/event window in paper; for trading-day matrix use rows in chosen window
    min_names: int = 5
    n_boot: int = 1000
    random_state: int = 42
    bootstrap_method: str = "block"     # "iid" or "block"
    block_size: int = 10                # aligns with paper's 10-observation time batches concept


@dataclass
class TrendTestConfig:
    """Residual-return persistence test configuration."""
    lookback_days: int = 60
    horizon_days: int = 60
    z_threshold: float = 2.0


# -----------------------------------------------------------------------------
# LSEG data acquisition helpers
# -----------------------------------------------------------------------------

def normalize_japan_equity_ric(x) -> Optional[str]:
    """Convert Japan stock code/Bloomberg-like ticker/RIC to RIC.

    Examples
    --------
    7203 -> 7203.T
    "7203" -> 7203.T
    "7203 JT Equity" -> 7203.T
    "7203.T" -> 7203.T
    "7203.T^A" -> unchanged
    "JPY=" -> unchanged
    """
    if pd.isna(x):
        return None
    s = str(x).strip()
    if not s:
        return None
    if s.endswith(".T") or ".T^" in s or s.startswith(".") or s.endswith("="):
        return s
    m = re.match(r"^(\d{4})\s+JT\s+Equity$", s, flags=re.IGNORECASE)
    if m:
        return f"{m.group(1)}.T"
    m = re.match(r"^(\d{4})$", s)
    if m:
        return f"{m.group(1)}.T"
    return s


def open_lseg_session():
    """Open an LSEG data session. Requires Workspace/Eikon/Platform config."""
    import lseg.data as ld
    ld.open_session()
    return ld


def _extract_history_field(df: pd.DataFrame, rics: Sequence[str], field: str) -> pd.DataFrame:
    """Normalize ld.get_history output to a wide matrix."""
    if df is None or len(df) == 0:
        return pd.DataFrame()
    out = df.copy()
    if isinstance(out.columns, pd.MultiIndex):
        for level in range(out.columns.nlevels):
            labels = set(out.columns.get_level_values(level))
            if field in labels:
                out = out.xs(field, axis=1, level=level)
                break
        if isinstance(out.columns, pd.MultiIndex):
            # Keep the remaining RIC-like component.
            out.columns = [str(tuple([x for x in c if x != field])[-1]) for c in out.columns]
    else:
        if len(rics) == 1 and out.shape[1] == 1:
            out.columns = [rics[0]]
    out.columns = [str(c) for c in out.columns]
    out.index = pd.to_datetime(out.index)
    return out.sort_index()


def get_history_matrix_lseg(
    rics: Sequence[str],
    start: str,
    end: Optional[str] = None,
    field: str = "TRDPRC_1",
    interval: str = "daily",
    batch_size: int = 80,
) -> pd.DataFrame:
    """Fetch historical time series from LSEG as a wide matrix.

    Parameters are passed to ld.get_history. Field TRDPRC_1 is a common traded
    price/close-like field; replace with an adjusted price/total return field if
    available under your entitlement.
    """
    import lseg.data as ld
    rics = list(dict.fromkeys([str(r) for r in rics if pd.notna(r)]))
    parts: List[pd.DataFrame] = []
    for i in range(0, len(rics), batch_size):
        batch = rics[i:i + batch_size]
        raw = ld.get_history(universe=batch, fields=[field], interval=interval, start=start, end=end)
        mat = _extract_history_field(raw, batch, field)
        parts.append(mat)
        print(f"Downloaded history {min(i + batch_size, len(rics))}/{len(rics)}")
    if not parts:
        return pd.DataFrame()
    out = pd.concat(parts, axis=1)
    out = out.loc[:, ~out.columns.duplicated()]
    return out.sort_index()


def get_reference_data_lseg(rics: Sequence[str], fields: Sequence[str], batch_size: int = 100) -> pd.DataFrame:
    """Fetch reference/fundamental fields from LSEG with ld.get_data."""
    import lseg.data as ld
    rics = list(dict.fromkeys([str(r) for r in rics if pd.notna(r)]))
    parts: List[pd.DataFrame] = []
    for i in range(0, len(rics), batch_size):
        batch = rics[i:i + batch_size]
        df = ld.get_data(universe=batch, fields=list(fields))
        parts.append(df)
        print(f"Downloaded ref data {min(i + batch_size, len(rics))}/{len(rics)}")
    return pd.concat(parts, axis=0) if parts else pd.DataFrame()


# -----------------------------------------------------------------------------
# Data preparation
# -----------------------------------------------------------------------------

def prices_to_returns(prices: pd.DataFrame, log: bool = False) -> pd.DataFrame:
    """Convert price matrix to simple or log returns."""
    x = prices.sort_index().replace([np.inf, -np.inf], np.nan).astype(float)
    return np.log(x).diff() if log else x.pct_change(fill_method=None)


def read_constituents(path: str) -> pd.DataFrame:
    """Read broker theme constituents.

    Expected columns:
    - date or release_date/effective_date
    - theme
    - ticker/ric/symbol/code
    - weight
    """
    df = pd.read_csv(path)
    cols = {c.lower(): c for c in df.columns}
    date_col = cols.get("date") or cols.get("release_date") or cols.get("effective_date")
    theme_col = cols.get("theme")
    weight_col = cols.get("weight") or cols.get("wgt")
    id_col = cols.get("ric") or cols.get("ticker") or cols.get("symbol") or cols.get("code")
    if theme_col is None or weight_col is None or id_col is None:
        raise ValueError("constituents requires theme, weight, and ticker/ric/symbol/code")
    out = pd.DataFrame({
        "date": pd.to_datetime(df[date_col]) if date_col else pd.Timestamp("1900-01-01"),
        "theme": df[theme_col].astype(str),
        "ric": df[id_col].map(normalize_japan_equity_ric),
        "weight": pd.to_numeric(df[weight_col], errors="coerce"),
    })
    out = out.dropna(subset=["date", "theme", "ric", "weight"])
    out = out[out["weight"] > 0].copy()
    out["weight"] = out.groupby(["date", "theme"])["weight"].transform(lambda x: x / x.sum())
    return out.sort_values(["theme", "date", "ric"]).reset_index(drop=True)


def latest_constituents_asof(constituents: pd.DataFrame, dt: pd.Timestamp, theme: str) -> pd.DataFrame:
    """Latest constituent set for a theme as of date dt."""
    sub = constituents[(constituents["theme"] == theme) & (constituents["date"] <= dt)]
    if sub.empty:
        return sub
    last = sub["date"].max()
    return sub[sub["date"] == last].copy()


def zscore_cross_section(x: pd.Series, winsor: float = 5.0) -> pd.Series:
    """Cross-sectional z-score of a Series."""
    s = x.astype(float).replace([np.inf, -np.inf], np.nan)
    mu, sd = s.mean(skipna=True), s.std(skipna=True, ddof=0)
    z = (s - mu) / sd if sd and np.isfinite(sd) else s * np.nan
    return z.clip(-winsor, winsor)


def build_dynamic_style_exposures(
    returns: pd.DataFrame,
    market_cap: Optional[pd.DataFrame] = None,
    volume_or_adv: Optional[pd.DataFrame] = None,
    book_to_price: Optional[pd.DataFrame] = None,
    asof_dates: Optional[Sequence[pd.Timestamp]] = None,
) -> pd.DataFrame:
    """Build simple style exposures from LSEG time-series panels.

    Output is MultiIndex (date, ric) with columns:
    log_mcap, value, momentum, volatility, liquidity.
    """
    returns = returns.sort_index()
    dates = pd.DatetimeIndex(asof_dates) if asof_dates is not None else returns.index
    # 12m-1m momentum using daily returns. Uses past data only.
    mom = returns.shift(21).rolling(252, min_periods=126).sum()
    vol = returns.rolling(126, min_periods=63).std(ddof=0)
    exposures = []
    for dt in dates:
        if dt not in returns.index:
            prev = returns.index[returns.index <= dt]
            if len(prev) == 0:
                continue
            dt0 = prev[-1]
        else:
            dt0 = dt
        df = pd.DataFrame(index=returns.columns)
        df["momentum"] = mom.loc[dt0]
        df["volatility"] = vol.loc[dt0]
        if market_cap is not None:
            mcap = market_cap.reindex(returns.index).ffill().loc[dt0]
            df["log_mcap"] = np.log(mcap.replace(0, np.nan))
        else:
            df["log_mcap"] = np.nan
        if volume_or_adv is not None:
            adv = volume_or_adv.reindex(returns.index).ffill().loc[dt0]
            df["liquidity"] = np.log(adv.replace(0, np.nan))
        else:
            df["liquidity"] = np.nan
        if book_to_price is not None:
            df["value"] = book_to_price.reindex(returns.index).ffill().loc[dt0]
        else:
            df["value"] = np.nan
        df["date"] = dt0
        df["ric"] = df.index
        exposures.append(df.reset_index(drop=True))
    if not exposures:
        return pd.DataFrame()
    out = pd.concat(exposures, axis=0).set_index(["date", "ric"]).sort_index()
    # Cross-sectional standardize per date.
    for c in ["log_mcap", "value", "momentum", "volatility", "liquidity"]:
        out[c] = out.groupby(level=0)[c].transform(lambda s: zscore_cross_section(s))
    return out


def merge_static_industry(exposures: pd.DataFrame, industry_map: pd.Series, industry_col: str = "trbc_industry") -> pd.DataFrame:
    """Add static industry code/name to MultiIndex exposure panel."""
    out = exposures.copy()
    rics = out.index.get_level_values("ric")
    out[industry_col] = rics.map(industry_map.astype(str))
    return out


# -----------------------------------------------------------------------------
# Cross-sectional risk model residuals
# -----------------------------------------------------------------------------

def _build_x_matrix(exposure_df: pd.DataFrame, cfg: RiskModelConfig) -> Tuple[pd.DataFrame, List[str]]:
    """Create design matrix with industry dummies + style exposures."""
    x_parts = []
    names: List[str] = []
    if cfg.use_intercept:
        x_parts.append(pd.DataFrame({"intercept": 1.0}, index=exposure_df.index))
        names.append("intercept")
    if cfg.industry_col in exposure_df.columns:
        dummies = pd.get_dummies(exposure_df[cfg.industry_col].astype(str), prefix="ind", dummy_na=False)
        # Drop one dummy if intercept to avoid exact collinearity; ridge can handle but this is cleaner.
        if cfg.use_intercept and dummies.shape[1] > 0:
            dummies = dummies.iloc[:, 1:]
        x_parts.append(dummies.astype(float))
        names += list(dummies.columns)
    for c in cfg.style_cols:
        if c in exposure_df.columns:
            x_parts.append(exposure_df[[c]].astype(float))
            names.append(c)
    if not x_parts:
        raise ValueError("No exposures available for risk model")
    X = pd.concat(x_parts, axis=1)
    X = X.replace([np.inf, -np.inf], np.nan)
    return X, list(X.columns)


def cross_sectional_residuals(
    returns: pd.DataFrame,
    exposures: pd.DataFrame,
    cfg: Optional[RiskModelConfig] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Daily cross-sectional ridge regression residualization.

    Parameters
    ----------
    returns:
        Date x RIC return matrix.
    exposures:
        MultiIndex (date, ric) exposure panel. Exposures at date t are used for
        returns at t. In production, use prior close/month-end exposures for t.
    cfg:
        RiskModelConfig.

    Returns
    -------
    residuals:
        Date x RIC matrix of idiosyncratic returns.
    factor_returns:
        Date x estimated factor-return matrix.
    """
    cfg = cfg or RiskModelConfig()
    returns = returns.sort_index().replace([np.inf, -np.inf], np.nan)
    residuals = pd.DataFrame(np.nan, index=returns.index, columns=returns.columns)
    factor_rows = []
    for dt in returns.index:
        if dt not in exposures.index.get_level_values(0):
            continue
        exp_dt = exposures.xs(dt, level=0)
        common = returns.columns.intersection(exp_dt.index)
        y = returns.loc[dt, common].astype(float)
        exp_sub = exp_dt.loc[common]
        X, cols = _build_x_matrix(exp_sub, cfg)
        df = pd.concat([y.rename("y"), X], axis=1).dropna()
        if df.shape[0] < cfg.min_obs or df.shape[1] <= 1:
            continue
        yv = df["y"].to_numpy(float)
        Xm = df[cols].to_numpy(float)
        lam = cfg.ridge_lambda
        ridge = np.eye(Xm.shape[1]) * lam
        if cfg.use_intercept and "intercept" in cols:
            ridge[cols.index("intercept"), cols.index("intercept")] = 0.0
        try:
            beta = np.linalg.solve(Xm.T @ Xm + ridge, Xm.T @ yv)
        except np.linalg.LinAlgError:
            beta = np.linalg.pinv(Xm.T @ Xm + ridge) @ Xm.T @ yv
        resid = yv - Xm @ beta
        residuals.loc[dt, df.index] = resid
        factor_rows.append(pd.Series(beta, index=cols, name=dt))
    factor_returns = pd.DataFrame(factor_rows).sort_index()
    return residuals, factor_returns


# -----------------------------------------------------------------------------
# APC statistic and bootstrap
# -----------------------------------------------------------------------------

def average_pairwise_correlation(residual_window: pd.DataFrame, min_names: int = 5) -> float:
    """Average pairwise correlation of residual returns in a window."""
    U = residual_window.dropna(axis=1, thresh=max(5, int(0.5 * len(residual_window))))
    if U.shape[1] < min_names:
        return np.nan
    corr = U.corr(min_periods=max(5, int(0.5 * len(U)))).to_numpy(float)
    if corr.shape[0] < min_names:
        return np.nan
    iu = np.triu_indices_from(corr, k=1)
    vals = corr[iu]
    vals = vals[np.isfinite(vals)]
    return float(vals.mean()) if vals.size else np.nan


def _iid_permute_columns(U: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    out = np.empty_like(U)
    for j in range(U.shape[1]):
        out[:, j] = rng.permutation(U[:, j])
    return out


def _block_permute_columns(U: np.ndarray, rng: np.random.Generator, block_size: int = 10) -> np.ndarray:
    T, N = U.shape
    blocks = [np.arange(i, min(i + block_size, T)) for i in range(0, T, block_size)]
    out = np.empty_like(U)
    for j in range(N):
        order = rng.permutation(len(blocks))
        perm_idx = np.concatenate([blocks[k] for k in order])
        out[:, j] = U[perm_idx[:T], j]
    return out


def bootstrap_apc_zscore(
    residual_window: pd.DataFrame,
    n_boot: int = 1000,
    min_names: int = 5,
    method: str = "block",
    block_size: int = 10,
    random_state: int = 42,
) -> Dict[str, float]:
    """Bootstrap null distribution and z-score for APC.

    Basic null: break cross-stock residual correlations while preserving each
    stock's empirical residual distribution. Block version permutes time blocks
    within each column, preserving short-run autocorrelation inside blocks.
    """
    Udf = residual_window.dropna(axis=1, thresh=max(5, int(0.5 * len(residual_window))))
    if Udf.shape[1] < min_names:
        return {"apc": np.nan, "z": np.nan, "p_upper": np.nan, "null_mean": np.nan, "null_std": np.nan, "n_names": Udf.shape[1]}
    # Fill isolated missing residuals with column means (near zero) for permutation.
    Udf = Udf.apply(lambda s: s.fillna(s.mean()), axis=0)
    apc_obs = average_pairwise_correlation(Udf, min_names=min_names)
    if not np.isfinite(apc_obs):
        return {"apc": np.nan, "z": np.nan, "p_upper": np.nan, "null_mean": np.nan, "null_std": np.nan, "n_names": Udf.shape[1]}
    U = Udf.to_numpy(float)
    rng = np.random.default_rng(random_state)
    null = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        if method == "iid":
            Ub = _iid_permute_columns(U, rng)
        elif method == "block":
            Ub = _block_permute_columns(U, rng, block_size=block_size)
        else:
            raise ValueError("method must be 'iid' or 'block'")
        null[b] = average_pairwise_correlation(pd.DataFrame(Ub, index=Udf.index, columns=Udf.columns), min_names=min_names)
    null = null[np.isfinite(null)]
    mu, sd = float(null.mean()), float(null.std(ddof=1))
    z = (apc_obs - mu) / sd if sd > 0 else np.nan
    p_upper = float((1.0 + np.sum(null >= apc_obs)) / (len(null) + 1.0)) if len(null) else np.nan
    return {"apc": apc_obs, "z": z, "p_upper": p_upper, "null_mean": mu, "null_std": sd, "n_names": Udf.shape[1]}


def compute_basket_apc_table(
    residuals: pd.DataFrame,
    constituents: pd.DataFrame,
    analysis_dates: Sequence[pd.Timestamp],
    cfg: Optional[APCConfig] = None,
) -> pd.DataFrame:
    """Compute APC and bootstrap z-scores by theme and analysis date.

    Uses latest constituents as of analysis date. The window is the trailing
    `apc_window_days` trading rows ending at the analysis date.
    """
    cfg = cfg or APCConfig()
    residuals = residuals.sort_index()
    rows = []
    for dt in pd.DatetimeIndex(analysis_dates):
        dates = residuals.index[residuals.index <= dt]
        if len(dates) == 0:
            continue
        end_dt = dates[-1]
        loc = residuals.index.get_loc(end_dt)
        if not isinstance(loc, (int, np.integer)):
            loc = int(np.asarray(loc).ravel()[-1])
        win = residuals.iloc[max(0, loc - cfg.apc_window_days + 1):loc + 1]
        for theme in sorted(constituents["theme"].unique()):
            c = latest_constituents_asof(constituents, end_dt, theme)
            rics = [r for r in c["ric"].tolist() if r in win.columns]
            if len(rics) < cfg.min_names:
                continue
            res = bootstrap_apc_zscore(
                win[rics],
                n_boot=cfg.n_boot,
                min_names=cfg.min_names,
                method=cfg.bootstrap_method,
                block_size=cfg.block_size,
                random_state=cfg.random_state + hash((str(theme), str(end_dt))) % 1_000_000,
            )
            rows.append({"date": end_dt, "theme": theme, **res})
    return pd.DataFrame(rows).sort_values(["date", "theme"]).reset_index(drop=True)


# -----------------------------------------------------------------------------
# Residual basket returns and trend tests
# -----------------------------------------------------------------------------

def basket_residual_return_panel(
    residuals: pd.DataFrame,
    constituents: pd.DataFrame,
) -> pd.DataFrame:
    """Build date x theme panel of weighted residual returns."""
    residuals = residuals.sort_index()
    themes = sorted(constituents["theme"].unique())
    out = pd.DataFrame(np.nan, index=residuals.index, columns=themes)
    for dt in residuals.index:
        for theme in themes:
            c = latest_constituents_asof(constituents, dt, theme)
            if c.empty:
                continue
            rics = [r for r in c["ric"].tolist() if r in residuals.columns]
            if not rics:
                continue
            w = c.set_index("ric").loc[rics, "weight"].astype(float)
            r = residuals.loc[dt, rics].astype(float)
            valid = r.notna()
            if valid.sum() == 0:
                continue
            wv = w.loc[valid.index[valid]]
            wv = wv / wv.sum()
            out.loc[dt, theme] = float((wv * r.loc[valid]).sum())
    return out


def trend_test_from_apc_table(
    basket_resid_returns: pd.DataFrame,
    apc_table: pd.DataFrame,
    cfg: Optional[TrendTestConfig] = None,
) -> pd.DataFrame:
    """Replicate Exhibit 9/10-style trend regression.

    For each row in apc_table, calculate past 60-day and future 60-day cumulative
    basket residual returns. Split by APC z-score >= threshold and regress future
    on past separately.
    """
    cfg = cfg or TrendTestConfig()
    rows = []
    for _, row in apc_table.iterrows():
        dt = pd.Timestamp(row["date"])
        theme = row["theme"]
        if theme not in basket_resid_returns.columns:
            continue
        idx = basket_resid_returns.index
        if dt not in idx:
            prev = idx[idx <= dt]
            if len(prev) == 0:
                continue
            dt = prev[-1]
        loc = idx.get_loc(dt)
        if not isinstance(loc, (int, np.integer)):
            loc = int(np.asarray(loc).ravel()[-1])
        past = basket_resid_returns[theme].iloc[max(0, loc - cfg.lookback_days + 1):loc + 1].sum()
        future = basket_resid_returns[theme].iloc[loc + 1:loc + 1 + cfg.horizon_days].sum()
        if np.isfinite(past) and np.isfinite(future):
            rows.append({"date": dt, "theme": theme, "z": row["z"], "past_resid_ret": past, "future_resid_ret": future})
    panel = pd.DataFrame(rows)
    if panel.empty:
        return pd.DataFrame()

    def _ols_stats(df: pd.DataFrame) -> pd.Series:
        x = df["past_resid_ret"].to_numpy(float)
        y = df["future_resid_ret"].to_numpy(float)
        X = np.column_stack([np.ones(len(x)), x])
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
        resid = y - X @ beta
        n, p = X.shape
        s2 = (resid @ resid) / max(1, n - p)
        cov = s2 * np.linalg.pinv(X.T @ X)
        se = np.sqrt(np.diag(cov))
        t = beta[1] / se[1] if se[1] > 0 else np.nan
        ybar = y.mean()
        r2 = 1 - (resid @ resid) / np.sum((y - ybar) ** 2) if np.sum((y - ybar) ** 2) > 0 else np.nan
        return pd.Series({"coef": beta[1], "t_stat": t, "obs": n, "r2": r2})

    panel["significant"] = panel["z"] >= cfg.z_threshold
    res_sig = _ols_stats(panel[panel["significant"]]) if panel["significant"].any() else pd.Series(dtype=float)
    res_nsig = _ols_stats(panel[~panel["significant"]]) if (~panel["significant"]).any() else pd.Series(dtype=float)
    summary = pd.DataFrame({"z>=threshold": res_sig, "z<threshold": res_nsig}).T
    return summary


# -----------------------------------------------------------------------------
# Recommended LSEG field templates
# -----------------------------------------------------------------------------

LSEG_REF_FIELDS_JP = [
    "TR.RIC",
    "TR.CommonName",
    "TR.TRBCEconomicSector",
    "TR.TRBCBusinessSector",
    "TR.TRBCIndustryGroup",
    "TR.TRBCIndustry",
    "TR.TRBCActivity",
    "TR.TRBCIndustryCode",
    "TR.CompanyMarketCap",
    "TR.FreeFloatPct",
]

# Use these as starting points. Confirm field names/availability in Data Item Browser.
LSEG_TS_FIELDS_CANDIDATES = {
    "close": "TRDPRC_1",
    "volume": "ACVOL_UNS",
    "market_cap": "TR.CompanyMarketCap",
    "book_to_price": "TR.BookValuePerShare",  # usually combine with price; confirm entitlement/field availability
}


if __name__ == "__main__":
    print("This is a library. Import functions into a notebook/script for replication.")

# -----------------------------------------------------------------------------
# Crowded Trades overlay (Kinlaw, Kritzman, Turkington) and RRG utilities
# -----------------------------------------------------------------------------

from typing import Literal


@dataclass
class CentralityConfig:
    """Asset centrality configuration.

    This follows the JPM crowded-trades paper at a practical level:
    - rolling covariance of asset/theme returns;
    - optional sqrt(size/capacity weight) adjustment;
    - exponential decay;
    - top eigenvectors;
    - centrality = sum(abs(eigenvector loading) * eigenvalue share).
    """
    lookback_days: int = 504          # approx. 2 years of daily data
    min_obs: int = 252
    halflife_days: int = 252          # approx. 1 year half-life
    n_eigs: int = 2
    sqrt_weight_returns: bool = True
    demean: bool = True


@dataclass
class CrowdedOverlayConfig:
    """Crowded-trades overlay / strategy configuration."""
    centrality_shift_window: int = 756       # approx. 3 years
    centrality_shift_min_obs: int = 252
    crowded_top_quantile: float = 0.20
    overvalued_top_quantile: float = 0.20
    relative_value_min_history: int = 756
    momentum_lookback_days: int = 252
    apc_z_threshold: float = 2.0
    rebalance: str = "M"                    # M/ME or W-FRI
    max_theme_weight: float = 0.20
    top_n: Optional[int] = 5
    runup_multiplier: float = 1.50
    neutral_multiplier: float = 1.00
    selloff_multiplier: float = 0.00
    cost_bps_per_turnover: float = 5.0
    score_mode: Literal["hard", "soft"] = "hard"


@dataclass
class RRGConfig:
    """Relative Rotation Graph configuration.

    This implements a transparent RRG-like approximation. It is not the
    proprietary JdK RS-Ratio / RS-Momentum formula.
    """
    rs_smoothing_window: int = 10
    momentum_window: int = 10
    normalization_window: int = 252
    min_obs: int = 126
    scale: float = 10.0
    center: float = 100.0


def _rolling_zscore_df(x: pd.DataFrame, window: int, min_obs: int, winsor: Optional[float] = 5.0) -> pd.DataFrame:
    x = x.sort_index().astype(float).replace([np.inf, -np.inf], np.nan)
    mu = x.rolling(window, min_periods=min_obs).mean()
    sd = x.rolling(window, min_periods=min_obs).std(ddof=0).replace(0.0, np.nan)
    z = (x - mu) / sd
    return z.clip(-winsor, winsor) if winsor is not None else z


def _weighted_covariance(X: pd.DataFrame, weights: np.ndarray, demean: bool = True) -> np.ndarray:
    """Weighted covariance for T x N matrix."""
    A = X.to_numpy(dtype=float)
    mask_rows = np.isfinite(A).all(axis=1)
    A = A[mask_rows]
    w = weights[mask_rows]
    if A.shape[0] == 0 or np.nansum(w) <= 0:
        return np.full((X.shape[1], X.shape[1]), np.nan)
    w = w / np.sum(w)
    if demean:
        mu = np.sum(A * w[:, None], axis=0)
        A = A - mu
    return (A * w[:, None]).T @ A


def _exp_weights(n: int, halflife: int) -> np.ndarray:
    """Oldest to newest exponential weights."""
    if n <= 0:
        return np.array([])
    lam = np.log(2.0) / max(1, halflife)
    age = np.arange(n - 1, -1, -1)  # newest age = 0
    w = np.exp(-lam * age)
    return w / w.sum()


def compute_asset_centrality(
    returns: pd.DataFrame,
    market_weights: Optional[pd.DataFrame] = None,
    cfg: Optional[CentralityConfig] = None,
) -> Tuple[pd.DataFrame, pd.Series]:
    """Compute rolling asset/theme centrality.

    Parameters
    ----------
    returns:
        Date x asset/theme return matrix. For theme use, pass basket residual
        returns or theme total returns.
    market_weights:
        Optional Date x asset/theme size/capacity weights. If supplied and
        cfg.sqrt_weight_returns=True, each return is multiplied by sqrt(weight).
        Use theme market-cap weight, ADV/capacity weight, or equal weights.
    cfg:
        CentralityConfig.

    Returns
    -------
    centrality:
        Date x asset/theme centrality score.
    absorption_ratio:
        Date-indexed absorption ratio using the top n_eigs eigenvalues.
    """
    cfg = cfg or CentralityConfig()
    R = returns.sort_index().replace([np.inf, -np.inf], np.nan).astype(float)
    cols = list(R.columns)
    centrality = pd.DataFrame(np.nan, index=R.index, columns=cols)
    ar = pd.Series(np.nan, index=R.index, name="absorption_ratio")

    if market_weights is not None:
        W = market_weights.reindex(R.index).ffill().reindex(columns=cols).astype(float)
    else:
        W = None

    for loc, dt in enumerate(R.index):
        if loc + 1 < cfg.min_obs:
            continue
        start = max(0, loc - cfg.lookback_days + 1)
        X = R.iloc[start:loc + 1].copy()
        X = X.dropna(axis=1, thresh=cfg.min_obs)
        if X.shape[1] < max(2, cfg.n_eigs):
            continue

        if W is not None and cfg.sqrt_weight_returns:
            Wwin = W.loc[X.index, X.columns].ffill().replace([np.inf, -np.inf], np.nan)
            # Normalize weights cross-sectionally each date. Missing => equal-ish fallback.
            Wnorm = Wwin.div(Wwin.sum(axis=1), axis=0)
            X = X * np.sqrt(Wnorm)

        # Drop rows with missing after choosing available columns.
        X = X.dropna(axis=0, how="any")
        if len(X) < cfg.min_obs:
            continue
        ew = _exp_weights(len(X), cfg.halflife_days)
        cov = _weighted_covariance(X, ew, demean=cfg.demean)
        if not np.isfinite(cov).all():
            continue
        try:
            eigvals, eigvecs = np.linalg.eigh(cov)
        except np.linalg.LinAlgError:
            continue
        order = np.argsort(eigvals)[::-1]
        eigvals = np.maximum(eigvals[order], 0.0)
        eigvecs = eigvecs[:, order]
        total_var = eigvals.sum()
        if total_var <= 0:
            continue
        n = min(cfg.n_eigs, len(eigvals))
        top_vals = eigvals[:n]
        top_vecs = eigvecs[:, :n]
        top_sum = top_vals.sum()
        if top_sum <= 0:
            continue
        eig_importance = top_vals / top_sum
        c = np.abs(top_vecs) @ eig_importance
        centrality.loc[dt, X.columns] = c
        ar.loc[dt] = top_sum / total_var

    return centrality, ar


def compute_centrality_shift(
    centrality: pd.DataFrame,
    window: int = 756,
    min_obs: int = 252,
    winsor: Optional[float] = 5.0,
) -> pd.DataFrame:
    """Standardized centrality shift versus each theme's own history."""
    return _rolling_zscore_df(centrality, window=window, min_obs=min_obs, winsor=winsor)


def cross_sectional_percentile_rank(x: pd.DataFrame) -> pd.DataFrame:
    """Row-wise percentile ranks in [0, 1]."""
    return x.rank(axis=1, pct=True)


def apc_table_to_matrix(apc_table: pd.DataFrame, value_col: str = "z") -> pd.DataFrame:
    """Convert long apc_table with date/theme/value to Date x Theme matrix."""
    if apc_table is None or apc_table.empty:
        return pd.DataFrame()
    df = apc_table.copy()
    df["date"] = pd.to_datetime(df["date"])
    return df.pivot_table(index="date", columns="theme", values=value_col, aggfunc="last").sort_index()


def weighted_theme_feature_panel(
    feature_panel: pd.DataFrame,
    constituents: pd.DataFrame,
    inverse_input: bool = False,
    min_weight_sum: float = 1e-12,
) -> pd.DataFrame:
    """Aggregate a stock-level feature panel to themes using PIT constituents.

    Parameters
    ----------
    feature_panel:
        Date x RIC matrix, e.g. book-to-price, market cap, ADV.
    constituents:
        Output of read_constituents(), with date/theme/ric/weight.
    inverse_input:
        If True, input is P/B and will be inverted to B/P before aggregation.
        This is useful because aggregating B/P then inverting is more stable
        than directly averaging P/B.
    """
    F = feature_panel.sort_index().replace([np.inf, -np.inf], np.nan).astype(float)
    if inverse_input:
        F = 1.0 / F.replace(0.0, np.nan)
    themes = sorted(constituents["theme"].unique())
    out = pd.DataFrame(np.nan, index=F.index, columns=themes)
    for dt in F.index:
        for theme in themes:
            c = latest_constituents_asof(constituents, dt, theme)
            if c.empty:
                continue
            rics = [r for r in c["ric"].tolist() if r in F.columns]
            if not rics:
                continue
            vals = F.loc[dt, rics].astype(float)
            valid = vals.notna() & np.isfinite(vals)
            if valid.sum() == 0:
                continue
            w = c.set_index("ric").loc[valid.index[valid], "weight"].astype(float)
            if w.sum() <= min_weight_sum:
                continue
            w = w / w.sum()
            out.loc[dt, theme] = float((w * vals.loc[valid]).sum())
    return out


def compute_theme_relative_value(
    constituents: pd.DataFrame,
    book_to_price: Optional[pd.DataFrame] = None,
    price_to_book: Optional[pd.DataFrame] = None,
    value_window_days: int = 2520,
    min_window_days: int = 1260,
) -> Dict[str, pd.DataFrame]:
    """Compute theme relative value using P/B normalized by history and peers.

    Use either stock-level book_to_price or price_to_book. If price_to_book is
    supplied, the function inverts it to book-to-price before aggregation.

    Returns dict with theme_bp, theme_pb, normalized_pb, relative_value.
    """
    if book_to_price is None and price_to_book is None:
        raise ValueError("Supply either book_to_price or price_to_book panel")
    if book_to_price is not None:
        theme_bp = weighted_theme_feature_panel(book_to_price, constituents, inverse_input=False)
    else:
        theme_bp = weighted_theme_feature_panel(price_to_book, constituents, inverse_input=True)
    theme_pb = 1.0 / theme_bp.replace(0.0, np.nan)
    hist_mean = theme_pb.rolling(value_window_days, min_periods=min_window_days).mean()
    normalized_pb = theme_pb / hist_mean
    peer_mean = (normalized_pb.sum(axis=1, skipna=True).to_frame("sum").values - normalized_pb.values) / (
        normalized_pb.notna().sum(axis=1).to_frame("n").values - 1
    )
    peer_mean = pd.DataFrame(peer_mean, index=normalized_pb.index, columns=normalized_pb.columns)
    relative_value = normalized_pb / peer_mean.replace(0.0, np.nan)
    return {
        "theme_bp": theme_bp,
        "theme_pb": theme_pb,
        "normalized_pb": normalized_pb,
        "relative_value": relative_value,
    }


def classify_crowded_theme_regimes(
    centrality_shift: pd.DataFrame,
    relative_value: pd.DataFrame,
    theme_returns: pd.DataFrame,
    apc_z: Optional[pd.DataFrame] = None,
    cfg: Optional[CrowdedOverlayConfig] = None,
) -> Dict[str, pd.DataFrame]:
    """Classify crowded-theme regimes: run-up / sell-off / neutral.

    The implementation translates Kinlaw-Kritzman-Turkington to themes:
    crowded = high centrality shift cross-sectionally;
    overvalued = high relative value cross-sectionally;
    run_up = coherent & crowded & not overvalued & price/momentum up;
    sell_off = coherent & crowded & overvalued.
    """
    cfg = cfg or CrowdedOverlayConfig()
    idx = centrality_shift.index.intersection(relative_value.index).intersection(theme_returns.index)
    cols = centrality_shift.columns.intersection(relative_value.columns).intersection(theme_returns.columns)
    C = centrality_shift.loc[idx, cols]
    RV = relative_value.loc[idx, cols]
    R = theme_returns.loc[idx, cols]

    crowded_rank = cross_sectional_percentile_rank(C)
    value_rank = cross_sectional_percentile_rank(RV)
    crowded = crowded_rank >= (1.0 - cfg.crowded_top_quantile)
    overvalued = value_rank >= (1.0 - cfg.overvalued_top_quantile)
    momentum = R.rolling(cfg.momentum_lookback_days, min_periods=max(20, cfg.momentum_lookback_days // 2)).sum()
    price_up = momentum > 0

    if apc_z is not None and not apc_z.empty:
        Z = apc_z.reindex(index=idx, columns=cols).ffill()
        coherent = Z >= cfg.apc_z_threshold
    else:
        Z = pd.DataFrame(np.nan, index=idx, columns=cols)
        coherent = pd.DataFrame(True, index=idx, columns=cols)

    run_up = coherent & crowded & (~overvalued) & price_up
    sell_off = coherent & crowded & overvalued
    neutral = ~(run_up | sell_off)

    # Soft diagnostic score: positive = run-up tendency, negative = sell-off risk.
    soft_score = C.rank(axis=1, pct=True) - RV.rank(axis=1, pct=True)
    soft_score = soft_score.where(coherent)

    return {
        "crowded_rank": crowded_rank,
        "relative_value_rank": value_rank,
        "crowded": crowded,
        "overvalued": overvalued,
        "momentum": momentum,
        "price_up": price_up,
        "apc_z": Z,
        "coherent": coherent,
        "run_up": run_up,
        "sell_off": sell_off,
        "neutral": neutral,
        "soft_score": soft_score,
    }


def make_rebalance_dates(index: pd.DatetimeIndex, rule: str = "M") -> pd.DatetimeIndex:
    """Return last available trading date in each rebalance bucket."""
    if len(index) == 0:
        return index
    s = pd.Series(np.arange(len(index)), index=index)
    try:
        locs = s.resample(rule).last().dropna().astype(int).values
    except ValueError:
        if rule == "ME":
            locs = s.resample("M").last().dropna().astype(int).values
        elif rule == "M":
            locs = s.resample("ME").last().dropna().astype(int).values
        else:
            raise
    return pd.DatetimeIndex(index[locs])


def normalize_long_weights(score: pd.Series, max_weight: float = 0.20, top_n: Optional[int] = 5) -> pd.Series:
    """Long-only score-proportional weights with simple max weight cap."""
    s = score.replace([np.inf, -np.inf], np.nan).dropna()
    s = s[s > 0]
    if top_n is not None:
        s = s.nlargest(top_n)
    if s.empty:
        return pd.Series(dtype=float)
    w = s / s.sum()
    if max_weight is not None and max_weight > 0:
        cap = max_weight
        for _ in range(20):
            over = w > cap
            if not over.any():
                break
            excess = (w[over] - cap).sum()
            w[over] = cap
            under = ~over
            if w[under].sum() <= 0 or excess <= 1e-12:
                break
            w[under] += w[under] / w[under].sum() * excess
    return w / w.sum() if w.sum() > 0 else w


def backtest_long_only_scores(
    returns: pd.DataFrame,
    scores: pd.DataFrame,
    rebalance: str = "M",
    top_n: Optional[int] = 5,
    max_weight: float = 0.20,
    cost_bps_per_turnover: float = 5.0,
) -> Dict[str, pd.DataFrame | pd.Series]:
    """Simple long-only strategy backtest from theme scores."""
    idx = returns.index.intersection(scores.index)
    cols = returns.columns.intersection(scores.columns)
    R = returns.loc[idx, cols].fillna(0.0)
    S = scores.loc[idx, cols]
    rebal = make_rebalance_dates(pd.DatetimeIndex(idx), rebalance)
    w_rebal = pd.DataFrame(0.0, index=rebal, columns=cols)
    for dt in rebal:
        w = normalize_long_weights(S.loc[dt], max_weight=max_weight, top_n=top_n)
        if not w.empty:
            w_rebal.loc[dt, w.index] = w
    w_daily = w_rebal.reindex(idx).ffill().fillna(0.0)
    gross = (w_daily.shift(1).fillna(0.0) * R).sum(axis=1)
    turnover = w_daily.diff().abs().sum(axis=1).fillna(w_daily.abs().sum(axis=1))
    cost = turnover * cost_bps_per_turnover / 10000.0
    strat_ret = gross - cost
    nav = (1.0 + strat_ret.fillna(0.0)).cumprod()
    metrics = pd.Series({
        "ann_return": nav.iloc[-1] ** (252 / max(1, len(nav))) - 1 if len(nav) else np.nan,
        "ann_vol": strat_ret.std(ddof=0) * np.sqrt(252),
        "sharpe": np.nan,
        "max_drawdown": (nav / nav.cummax() - 1.0).min() if len(nav) else np.nan,
        "turnover_ann": turnover.mean() * 252,
        "final_nav": nav.iloc[-1] if len(nav) else np.nan,
    })
    if metrics["ann_vol"] and metrics["ann_vol"] > 0:
        metrics["sharpe"] = metrics["ann_return"] / metrics["ann_vol"]
    return {
        "weights_rebalance": w_rebal,
        "weights_daily": w_daily,
        "strategy_returns": strat_ret,
        "nav": nav,
        "turnover": turnover,
        "metrics": metrics,
    }


def jpm_crowded_theme_overlay_strategy(
    basket_returns: pd.DataFrame,
    centrality_shift: pd.DataFrame,
    relative_value: pd.DataFrame,
    apc_z: Optional[pd.DataFrame] = None,
    cfg: Optional[CrowdedOverlayConfig] = None,
) -> Dict[str, object]:
    """Run a JPM crowded-trades overlay strategy on theme returns.

    Recommended use: pass basket residual returns from basket_residual_return_panel.
    The strategy buys themes that are coherent, crowded, not overvalued, and
    have positive momentum. It excludes crowded + overvalued sell-off candidates.
    """
    cfg = cfg or CrowdedOverlayConfig()
    regimes = classify_crowded_theme_regimes(
        centrality_shift=centrality_shift,
        relative_value=relative_value,
        theme_returns=basket_returns,
        apc_z=apc_z,
        cfg=cfg,
    )
    idx = basket_returns.index.intersection(regimes["run_up"].index)
    cols = basket_returns.columns.intersection(regimes["run_up"].columns)
    R = basket_returns.loc[idx, cols]
    momentum = regimes["momentum"].loc[idx, cols]
    central = centrality_shift.reindex(index=idx, columns=cols)
    rv = relative_value.reindex(index=idx, columns=cols)
    run_up = regimes["run_up"].loc[idx, cols]
    sell_off = regimes["sell_off"].loc[idx, cols]
    coherent = regimes["coherent"].loc[idx, cols]

    if cfg.score_mode == "hard":
        # Score is positive momentum, multiplied by regime multipliers.
        base = momentum.clip(lower=0.0).where(coherent)
        multiplier = pd.DataFrame(cfg.neutral_multiplier, index=idx, columns=cols)
        multiplier = multiplier.where(~run_up, cfg.runup_multiplier)
        multiplier = multiplier.where(~sell_off, cfg.selloff_multiplier)
        scores = base * multiplier
    else:
        # Soft score combines momentum, centrality and negative relative value.
        c_z = _rolling_zscore_df(central, cfg.centrality_shift_window, cfg.centrality_shift_min_obs)
        rv_z = _rolling_zscore_df(rv, cfg.relative_value_min_history, max(63, cfg.relative_value_min_history // 3))
        scores = (momentum.rank(axis=1, pct=True) + c_z.rank(axis=1, pct=True) - rv_z.rank(axis=1, pct=True)).where(coherent)
        scores = scores.where(~sell_off, np.nan)

    bt = backtest_long_only_scores(
        returns=R,
        scores=scores,
        rebalance=cfg.rebalance,
        top_n=cfg.top_n,
        max_weight=cfg.max_theme_weight,
        cost_bps_per_turnover=cfg.cost_bps_per_turnover,
    )
    return {
        "scores": scores,
        "regimes": regimes,
        **bt,
    }


# -----------------------------------------------------------------------------
# RRG: Relative Rotation Graph-like calculations
# -----------------------------------------------------------------------------

def _to_price_index(data: pd.DataFrame | pd.Series, input_type: Literal["price", "return"] = "price"):
    if input_type == "price":
        return data.sort_index().astype(float)
    if input_type == "return":
        return (1.0 + data.sort_index().astype(float).fillna(0.0)).cumprod()
    raise ValueError("input_type must be 'price' or 'return'")


def compute_rrg(
    asset_prices_or_returns: pd.DataFrame,
    benchmark_prices_or_returns: Optional[pd.Series] = None,
    input_type: Literal["price", "return"] = "price",
    cfg: Optional[RRGConfig] = None,
) -> Dict[str, pd.DataFrame]:
    """Compute transparent RRG-like RS-Ratio and RS-Momentum.

    Parameters
    ----------
    asset_prices_or_returns:
        Date x theme/asset price or return matrix.
    benchmark_prices_or_returns:
        Date-indexed benchmark price or return. If None, equal-weighted
        average of the asset price indexes is used as benchmark.
    input_type:
        'price' if inputs are price indexes; 'return' if simple returns.
    cfg:
        RRGConfig.

    Returns
    -------
    dict with relative_strength, rs_ratio, rs_momentum, quadrant.

    Notes
    -----
    This is an RRG-like approximation:
    - RS = log(asset price / benchmark price)
    - RS-Ratio = 100 + scale * rolling_zscore(smoothed RS)
    - RS-Momentum = 100 + scale * rolling_zscore(change in smoothed RS)
    It is designed for transparent research, not as a clone of proprietary JdK
    calculations.
    """
    cfg = cfg or RRGConfig()
    P = _to_price_index(asset_prices_or_returns, input_type=input_type)
    if benchmark_prices_or_returns is None:
        B = P.mean(axis=1)
    else:
        B = _to_price_index(benchmark_prices_or_returns, input_type=input_type)
        if isinstance(B, pd.DataFrame):
            B = B.iloc[:, 0]
    P, B = P.align(B, join="inner", axis=0)
    rel = P.div(B, axis=0).replace([np.inf, -np.inf], np.nan)
    log_rs = np.log(rel)
    rs_smooth = log_rs.rolling(cfg.rs_smoothing_window, min_periods=max(2, cfg.rs_smoothing_window // 2)).mean()
    rs_z = _rolling_zscore_df(rs_smooth, cfg.normalization_window, cfg.min_obs)
    rs_ratio = cfg.center + cfg.scale * rs_z
    rs_delta = rs_smooth.diff(cfg.momentum_window)
    mom_z = _rolling_zscore_df(rs_delta, cfg.normalization_window, cfg.min_obs)
    rs_momentum = cfg.center + cfg.scale * mom_z

    quadrant = pd.DataFrame("", index=P.index, columns=P.columns)
    leading = (rs_ratio >= cfg.center) & (rs_momentum >= cfg.center)
    weakening = (rs_ratio >= cfg.center) & (rs_momentum < cfg.center)
    lagging = (rs_ratio < cfg.center) & (rs_momentum < cfg.center)
    improving = (rs_ratio < cfg.center) & (rs_momentum >= cfg.center)
    quadrant = quadrant.mask(leading, "Leading")
    quadrant = quadrant.mask(weakening, "Weakening")
    quadrant = quadrant.mask(lagging, "Lagging")
    quadrant = quadrant.mask(improving, "Improving")
    quadrant = quadrant.mask(rs_ratio.isna() | rs_momentum.isna(), np.nan)

    return {
        "relative_strength": rel,
        "log_relative_strength": log_rs,
        "rs_ratio": rs_ratio,
        "rs_momentum": rs_momentum,
        "quadrant": quadrant,
    }


def rrg_latest_table(rrg: Dict[str, pd.DataFrame], asof: Optional[pd.Timestamp] = None) -> pd.DataFrame:
    """Latest RRG table with RS-Ratio, RS-Momentum and quadrant."""
    ratio = rrg["rs_ratio"]
    mom = rrg["rs_momentum"]
    quad = rrg["quadrant"]
    if asof is None:
        asof = ratio.dropna(how="all").index[-1]
    else:
        prev = ratio.index[ratio.index <= pd.Timestamp(asof)]
        asof = prev[-1]
    out = pd.DataFrame({
        "rs_ratio": ratio.loc[asof],
        "rs_momentum": mom.loc[asof],
        "quadrant": quad.loc[asof],
    })
    return out.sort_values(["quadrant", "rs_ratio", "rs_momentum"], ascending=[True, False, False])


def rrg_trails(rrg: Dict[str, pd.DataFrame], themes: Optional[Sequence[str]] = None, trail_days: int = 20) -> Dict[str, pd.DataFrame]:
    """Return per-theme RRG trails for plotting."""
    ratio = rrg["rs_ratio"]
    mom = rrg["rs_momentum"]
    if themes is None:
        themes = list(ratio.columns)
    trails = {}
    for th in themes:
        if th not in ratio.columns:
            continue
        trails[th] = pd.DataFrame({
            "rs_ratio": ratio[th].tail(trail_days),
            "rs_momentum": mom[th].tail(trail_days),
        }).dropna()
    return trails


def plot_rrg(
    rrg: Dict[str, pd.DataFrame],
    themes: Optional[Sequence[str]] = None,
    trail_days: int = 20,
    title: str = "Relative Rotation Graph",
):
    """Plot RRG-like trails. Requires matplotlib."""
    import matplotlib.pyplot as plt
    trails = rrg_trails(rrg, themes=themes, trail_days=trail_days)
    fig, ax = plt.subplots(figsize=(9, 7))
    ax.axhline(100, linewidth=1, linestyle="--")
    ax.axvline(100, linewidth=1, linestyle="--")
    for th, df in trails.items():
        if df.empty:
            continue
        ax.plot(df["rs_ratio"], df["rs_momentum"], marker="o", linewidth=1, label=th)
        ax.text(df["rs_ratio"].iloc[-1], df["rs_momentum"].iloc[-1], th, fontsize=8)
    ax.set_xlabel("RS-Ratio (approx.)")
    ax.set_ylabel("RS-Momentum (approx.)")
    ax.set_title(title)
    ax.grid(True)
    ax.legend(loc="best", fontsize=8)
    return fig, ax
