# Review QC Checklist（Phase A）

- 実施日時: 2026-02-24 21:55 JST
- 対象:
  - `docs/notes/review.md`
  - `outputs/phase_a/source_map.md`
  - `outputs/phase_a/extraction_log.md`

## 1) 構造テスト

- [x] `review.md` に12節（指定章立て）が存在する
  - 確認: `rg '^## ' docs/notes/review.md`
  - 結果: `## 1` から `## 12` を確認
- [x] `outputs/phase_a/` に証跡3ファイルが存在する
  - `source_map.md`
  - `extraction_log.md`
  - `review_qc_checklist.md`

## 2) 内容テスト

- [x] PPO主要パラメータを全て記載
  - `total_timesteps=7.5M`
  - `n_envs=10`
  - `n_steps=756`
  - `batch_size=1260`
  - `n_epochs=16`
  - `gamma=0.9`
  - `gae_lambda=0.9`
  - `clip_range=0.25`
  - `learning_rate=3e-4 -> 1e-5`
- [x] データ分割（10窓、5/1/1年）を記載
- [x] MVOの60日窓・Ledoit-Wolf・PSD補正を記載
- [x] 評価期間2012-2021と主要評価指標を記載
- [x] 初期資金 `$100,000`、整数株制約、deterministic評価を記載

## 3) リーク防止テスト

- [x] 特徴量計算時点が `t` までであることを明記
- [x] `t+1` 実現収益への時点整合を明記
- [x] 標準化統計を expanding window で推定することを明記
- [x] 学習/検証/テスト境界と burn year の分離を明記

## 4) 参照根拠テスト

- [x] ページ根拠（`p.x`）が全セクションに付与されている
  - 集計: `section_1..12` の全てで `p.x` を検出
  - 総ページ根拠数: `50`
  - 判定: 参照ページ付与率 `12/12 sections = 100%`

## 5) 変更安全性テスト

- [x] 既存ファイルの破壊的変更なし（新規作成中心）
- [x] 既存ファイル更新時はバックアップ作成
  - `docs/notes/review.md.bak.20260224_215330`

## 6) 判定

- [x] Phase A成果物は計画で定義した受け入れ条件を満たす
- [x] Phase B（Notebook実装）へ受け渡し可能
