# Extraction Log（Phase A）

- 対象原本: `docs/sources/Deep Reinforcement Learning for Optimal Portfolio Allocation A Comparative Study with Mean-Variance Optimization.pdf`
- 抽出環境: `/Users/kencharoff/workspace/envs/rl/.venv/bin/python`
- 使用ツール: `pypdf`（`PdfReader.extract_text()`）
- 作業日時: 2026-02-24 JST

## ログ 1: 原本の全体構造確認

- 実行時刻: 2026-02-24 21:46-21:48 +0900
- 抽出対象ページ: 1-9（全ページ）
- 実施内容:
  - 総ページ数確認（9ページ）
  - ページ単位でテキスト抽出
  - Outline（章見出し）抽出
- 抽出要約:
  - 章立ては `Introduction -> Related Work -> Background -> Problem Setup -> Experiments -> Results -> Conclusion`。
  - 実験設定・ハイパーパラメータ・結果表は主に p.5-6 に集中。
- 判断メモ:
  - `review.md` は原本の章構造を基礎にしつつ、再現実装で必要な粒度に再編（12節）する方針を採用。

## ログ 2: 比較設計・背景（DRL vs MVO）

- 実行時刻: 2026-02-24 21:48-21:49 +0900
- 抽出対象ページ: p.1-3
- 抽出要約:
  - 既存研究での比較不公平性（目的関数不一致、DRL側のみ追加情報）を問題化。
  - 本研究はリスク調整後リターン（Sharpe系）で比較整合を取る。
- 判断メモ:
  - `review.md` 第1節で、比較の公平条件を「再現時の必須要件」として明文化。

## ログ 3: 状態・行動・報酬

- 実行時刻: 2026-02-24 21:49-21:50 +0900
- 抽出対象ページ: p.3-4
- 抽出要約:
  - 行動: `sum(w)=1`, `0<=w<=1`, long-only、softmax制約。
  - 状態: `[(n+1) x T]`, `T=60`, 過去リターン+市場ボラ特徴。
  - 報酬: Differential Sharpe Ratio（`A_t`,`B_t`,`D_t`, `eta≈1/252`）。
- 判断メモ:
  - `review.md` 第3-5節に数式・実装変数候補を併記。
  - DSR分母の数値安定化は論文明記外だが、実装上の必要補助として要注意点に採用。

## ログ 4: 環境仕様・時点整合

- 実行時刻: 2026-02-24 21:50-21:51 +0900
- 抽出対象ページ: p.4
- 抽出要約:
  - market replay + ブローカー処理。
  - `port_val_t` 計算後に重み再配分、整数株化、残余現金化。
  - `S_{t+1}` 生成後、`P_{t+1}` で報酬 `R_t=D_t` を算出。
- 判断メモ:
  - `review.md` 第6節・第11節に時点整合（`t`情報で意思決定、`t+1`で実現）を明記。

## ログ 5: 実験設計（データ分割・PPO設定・MVO設定）

- 実行時刻: 2026-02-24 21:51-21:52 +0900
- 抽出対象ページ: p.5-6
- 抽出要約:
  - 10スライディング窓、各窓7年（5 train / 1 burn / 1 test）。
  - 各窓5 seeds、合計50エージェント。
  - PPO主要ハイパーパラメータ（`timesteps=7.5M`, `n_envs=10`, `n_steps=756`, `batch=1260`, `epochs=16`, `gamma=0.9`, `gae_lambda=0.9`, `clip=0.25`, `lr:3e-4->1e-5`）。
  - MVOは60日窓、Ledoit-Wolf、PSD補正、Sharpe最大化（PyPortfolioOpt）。
- 判断メモ:
  - `review.md` 第7-9節に固定仕様として採用。

## ログ 6: 評価・結果・未記載項目整理

- 実行時刻: 2026-02-24 21:52-21:53 +0900
- 抽出対象ページ: p.6-8
- 抽出要約:
  - 10バックテスト（2012-2021）、各期初期資金$100,000、整数株制約。
  - Table 2の主要指標群でDRL優位。
  - `Δp_w` でturnover比較。
  - 将来拡張としてコスト/スリッページ導入提案。
- 判断メモ:
  - `review.md` 第10節に評価手順と指標を固定。
  - 第12節で論文未記載事項（ticker一覧、欠損処理、seed具体値等）を仮定項目として整理。

## 除外・非採用情報

- 参考文献一覧（p.8-9）は直接の再現仕様に使わないため、`review.md` 本文では必要最小限のみ参照。
- 図の視覚的読み取り値（Figure 2-4の細部数値）は本文記載が優先のため、グラフ目視の推定は不採用。
