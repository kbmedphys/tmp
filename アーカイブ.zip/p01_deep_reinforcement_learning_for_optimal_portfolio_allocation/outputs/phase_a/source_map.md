# Source Map（原本 -> review.md 対応表）

- 作成日時: 2026-02-24 21:52:03 +0900
- 対象原本: `docs/sources/Deep Reinforcement Learning for Optimal Portfolio Allocation A Comparative Study with Mean-Variance Optimization.pdf`
- 対応先: `docs/notes/review.md`

| 原本セクション | ページ | `review.md` 対応節 | 抽出した再現要点 |
|---|---:|---|---|
| Abstract / 1 Introduction | 1 | 1 | 研究目的、DRL vs MVOの比較主旨、評価軸の全体像 |
| 2 Related Work | 2 | 1 | 既存比較の不公平性（報酬関数不一致等）と本研究の比較方針 |
| 3 Background / 3.1 MVO | 2-3 | 1, 8 | MVO目的、Sharpe最適化、重み制約、比較の理論背景 |
| 3.2 Reinforcement Learning | 3 | 1 | MDP/PPO選定の背景（実装上は概要のみ参照） |
| 4 Problem Setup / 4.1 Actions | 3 | 4 | 行動重み制約 `sum=1`, `0<=w<=1`, long-only, softmax |
| 4.2 States | 3 | 3 | `[(n+1) x T]` 状態行列、`T=60`、重み列とリターン履歴 |
| 4.3 Reward | 4 | 5 | Differential Sharpe Ratio の式、`A_t`,`B_t`,`D_t`,`eta` |
| 4.4 Learning Algorithm | 4 | 7 | PPO採用根拠 |
| 4.5 RL Environment Specifics | 4 | 6, 11 | market replay、整数株化、現金処理、時点整合 |
| 5.1 Data & Features | 4-5 | 2, 3, 11 | データ期間・銘柄群・`vol20`,`vol60`,`vol20/vol60`,`VIX`、expanding標準化 |
| 5.2 Deep RL Approach | 5 | 7, 9 | 10スライディング窓、5/1/1分割、5 seeds、PPOハイパーパラメータ |
| 5.3 MVO Approach | 5-6 | 8 | 60日窓、サンプル平均、Ledoit-Wolf、PSD補正、PyPortfolioOpt |
| 5.4 Evaluation & Backtesting | 6 | 9, 10, 11 | 2012-2021の10バックテスト、$100k開始、deterministic評価 |
| 6 Results / Table 2 | 6-7 | 10 | 指標セット、DRL優位の要点、`Δp_w` によるturnover比較 |
| 7 Conclusion / 7.1 Future Work | 8 | 10, 12 | 成果要約、将来拡張（コスト・スリッページ・レジーム切替） |

## 備考

- 参考文献ページ（9）は再現実装仕様の直接根拠としては使わず、手法出典確認用の補助参照とした。
