# Phase A 証跡ログ（最小）

- 作成日: 2026-02-24
- 対象プロジェクト: /Users/kencharoff/workspace/projects/rl/p02_risk-adjusted_deep_reinforcement_learning
- 参照原本:
  - /Users/kencharoff/workspace/projects/rl/p02_risk-adjusted_deep_reinforcement_learning/docs/sources/Risk-Adjusted Deep Reinforcement Learning for Portfolio Optimization A Multi-reward Approach.pdf
- 抽出方式: `pypdf` による本文抽出 + 原本ページ参照（`pdftoppm` は未導入）

## 1. 抽出根拠一覧（ページ・要約・確信度）

| 項目 | 根拠ページ | 要約 | 確信度 |
|---|---|---|---|
| 論文情報（タイトル、著者、誌名、DOI） | p.1 | 書誌情報を確認。 | 高 |
| 主要主張（3報酬統合 + CNN + 4市場評価） | p.1-3 | Abstract/Introductionで主張を確認。 | 高 |
| MDP定式化 | p.5 | \((S,A,P,R,\gamma)\) と累積報酬最大化を確認。 | 高 |
| 状態特徴量（共分散+8指標） | p.5 | 8テクニカル指標の列挙を確認。 | 高 |
| 行動制約（long-only, sum=1, softmax） | p.5 | \(\sum w_i=1, 0\le w_i\le1\) とsoftmax適用を確認。 | 高 |
| Log return報酬 | p.5 | \(\log(P_t/P_{t-1})\) を確認。 | 高 |
| DSR報酬 | p.5-6 | DSR導出と更新式記載を確認（式記号に抽出崩れあり）。 | 中 |
| MDD報酬 | p.6 | MDD定義とオンライン設定の説明を確認。 | 高 |
| PPO目的関数 | p.6-7 | クリップ付き目的関数とAdvantage説明を確認。 | 高 |
| RA-DRL統合構造 | p.7-8 | 3 PPO行動をCNN(kernel=(1,3))→FCで統合。 | 高 |
| 教師あり統合式（式(1)） | p.8 | \(w_{i,t}=\frac{e^{\rho_{i,t}c}}{\sum_i e^{\rho_{i,t}c}}\), \(c\in[1,5]\)。 | 高 |
| データ仕様（市場、期間、分割） | p.8 | 4市場、2011-01-01〜2024-03-31、train/test境界確認。 | 高 |
| ハイパーパラメータ探索 | p.8-9 | Bayesian optimization + Hyperopt、探索レンジ確認。 | 高 |
| 取引コスト式 | p.9 | \(\delta_t=\beta P_t |w_t-w_{t-1}|\), \(\beta=0.05\%\)。 | 高 |
| 評価指標8種 | p.9-10 | CR, AR, SR, CAR, SOR, OR, AV, Stabilityを確認。 | 高 |
| ベンチマーク | p.11 | Market Index, MVO, 1/n, Single objective reward。 | 高 |

## 2. 不確実箇所（原本確認必要）

1. DSRの最終式の記号
- 該当: p.6
- 状況: 抽出テキストで \(\Delta\) 付近の数式が崩れている。
- 対応: 実装前に原本PDFの該当式を目視で転記する。

2. CNN-MLPの詳細構成
- 該当: p.7-9（Fig.2, Fig.3周辺）
- 状況: kernelサイズは明記されるが、チャネル数・全層構成の詳細が本文抽出だけでは不足。
- 対応: 図と本文を目視照合して実装仕様を固定する。

3. Single objective rewardの重み
- 該当: p.11
- 状況: ベンチマークの定性的説明はあるが、重みの具体値は本文抽出から特定できない。
- 対応: 補足資料/実験設定の追跡が必要。

4. リスクフリー金利 \(r_f\) の実験値
- 該当: p.10
- 状況: 指標式には \(r_f\) があるが、実験使用値が明示されない。
- 対応: 再現時は仮定値を明示し、感度分析を実施する。

5. 約定時点（open/close）の厳密定義
- 該当: p.8-11
- 状況: 日次データ利用は記載あるが、執行タイミングは明確でない。
- 対応: 再現実装では「tで決定、t+1で適用」を固定しリーク防止する。

## 3. 作業ステップ要約

1. `workspace/AGENTS.md` とプロジェクト `AGENTS.md` を確認。
2. リポジトリ現状を確認し、`docs/notes` と `outputs` を作成。
3. 既存成果物がある場合に備え、バックアップ手順を実行（今回は対象なし）。
4. 明示Pythonパス `/Users/kencharoff/workspace/envs/rl/.venv/bin/python` でPDF本文を抽出。
5. `docs/notes/review.md` を再現仕様重視で作成。
6. 本ログを作成し、主要根拠と不確実点を記録。
