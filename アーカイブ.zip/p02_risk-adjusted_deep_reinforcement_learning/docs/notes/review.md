# Risk-Adjusted Deep Reinforcement Learning for Portfolio Optimization: A Multi-reward Approach

## 1. 論文基本情報と主張
- タイトル: Risk-Adjusted Deep Reinforcement Learning for Portfolio Optimization: A Multi-reward Approach（根拠: p.1）
- 著者: Himanshu Choudhary, Arishi Orra, Kartik Sahoo, Manoj Thakur（根拠: p.1）
- 掲載: International Journal of Computational Intelligence Systems, 2025, 18:126（根拠: p.1）
- DOI: 10.1007/s44196-025-00875-8（根拠: p.1）
- 中核主張:
  - 3つの報酬（Log return / DSR / MDD）で学習した3つのPPOエージェントの行動をCNNで統合し、単一報酬よりもリスク調整後パフォーマンスを改善する（根拠: p.1-3, p.7-8）
  - 実験対象はSensex, Dow, TWSE, IBEXの日次データ（根拠: p.1, p.8）
- 論文の主要貢献（要約）:
  1. 複数投資目的を同時に扱うRA-DRLフレームワーク提案
  2. 複数エージェント行動をCNNで重み付け統合
  3. DRL枠組みに教師あり学習を組み込む訓練方式
  （根拠: p.3）

## 2. MDP定式化（状態・行動・報酬）
- 問題はMDP \((S, A, P, R, \gamma)\) として定式化（根拠: p.5）
- 方策 \(\pi\) は状態 \(s\) に対する行動 \(\pi(s)\) を与える（根拠: p.5）
- 目的は期待割引累積報酬の最大化:

```math
\max_\pi \; \mathbb{E}\left[\sum_{t=0}^{\infty} \gamma^t R(s_t, a_t)\right]
```

（根拠: p.5）

## 3. 状態特徴量（共分散 + 8テクニカル指標）
- 状態 \(s_t\) は、資産終値の共分散行列 + 各資産の8テクニカル指標（根拠: p.5）
- 記載された指標:
  - SMA(30), SMA(60)
  - MACD
  - Bollinger Bands（Upper, Lower）
  - RSI
  - CCI
  - ADX
  （根拠: p.5）

## 4. 行動制約（softmax, long-only, sum=1）
- 行動はポートフォリオウェイトベクトル \(w=[w_1,\dots,w_n]\)（根拠: p.5）
- 制約:

```math
\sum_{i=1}^{n} w_i = 1, \quad 0 \le w_i \le 1
```

- 連続行動出力にsoftmaxを適用して制約を満たす（根拠: p.5）

## 5. 3報酬（Log Return / DSR / MDD）の式と変数定義
### 5.1 Log Return

```math
r(t) = \log\left(\frac{P_t}{P_{t-1}}\right)
```

- \(P_t\): 時刻 \(t\) のポートフォリオ価値（根拠: p.5）

### 5.2 Differential Sharpe Ratio (DSR)
- 論文記載（抽出ベース）:

```math
SR_t \approx SR_{t-1} + \eta \cdot DSR_t\rvert_{\eta=0} + O(\eta^2)
```

```math
DSR_t = \frac{Y_{t-1}\Delta X_t - \frac{1}{2}X_{t-1}\Delta Y_t}{(Y_{t-1}-X_{t-1}^2)^{3/2}}
```

```math
X_t = X_{t-1} + \eta(r_t - X_{t-1}), \quad
Y_t = Y_{t-1} + \eta(r_t^2 - Y_{t-1})
```

- 初期値: \(X_0=Y_0=0\)
- 適応率: \(\eta \approx 1/252\)
- 注意: PDF抽出で数式記号に欠損があるため、実装前に原本p.6の式を目視確認する（根拠: p.5-6）

### 5.3 Maximum Drawdown (MDD)

```math
MDD = \max_{t:\tau>t} \left[\frac{P_t - P_\tau}{P_t}\right]
```

- 論文ではオンライン設定で「現在ポートフォリオ価値を谷（trough）」として扱う旨を記載（根拠: p.6）

## 6. PPO目的関数と学習上の意味
- 採用アルゴリズム: PPO（Actor-Critic）（根拠: p.6）
- 目的関数（クリップ付き）:

```math
L(\theta) = \hat{E}_t\left[\min\left(r_t(\theta)\hat{A}_t,
\operatorname{clip}(r_t(\theta), 1-\epsilon, 1+\epsilon)\hat{A}_t\right)\right]
```

```math
r_t(\theta)=\frac{\pi_\theta(a_t\mid s_t)}{\pi_{\theta_{old}}(a_t\mid s_t)}
```

- クリッピングにより方策更新の急変を抑制し、学習安定性を向上（根拠: p.6-7）
- Advantageの定義:

```math
\hat{A}^\pi(s_t,a_t)=Q^\pi(s_t,a_t)-V^\pi(s_t)
```

（根拠: p.7）

## 7. RA-DRL統合構造（3 PPO出力→CNN(kernel=(1,3))→FC）
- 3つのPPO（Log/DSR/MDD報酬）を独立に学習（根拠: p.7）
- 各時点で3エージェント行動をスタックし、2D CNN（kernel=(1,3)）で統合表現を抽出（根拠: p.7）
- その後FC層で最終ポートフォリオウェイトを出力（根拠: p.7-8）
- 学習では最終ウェイトから計算したポートフォリオ収益とground truthの差を最小化（根拠: p.7-8）

## 8. 教師あり統合部（式(1): `w_{i,t}` と `c, ρ_{i,t}`）
- 歴史データから訓練時の教師ウェイトを以下で計算（式(1)）:

```math
w_{i,t} = \frac{e^{\rho_{i,t} \times c}}{\sum_i e^{\rho_{i,t} \times c}}
```

- \(\rho_{i,t}\): i番目銘柄の時刻\(t\)における価格変化率
- \(c\): 1〜5を取る定数
- これを使って計算したポートフォリオリターンを教師信号（ground truth）として使用（根拠: p.8）

## 9. データ仕様（市場、期間、train/test split）
- 市場: Sensex(India), Dow(USA), TWSE(Taiwan), IBEX(Spain)（根拠: p.8）
- データ: 各市場の時価総額上位30銘柄の日次OHLC（Yahoo Finance由来）（根拠: p.8）
- 期間: 2011-01-01 〜 2024-03-31（根拠: p.8）
- 銘柄数例外: Dowは29銘柄、IBEXは28銘柄（根拠: p.8）
- 学習/評価分割:
  - In-sample(train): 2011-01-01 〜 2020-12-31
  - Out-of-sample(test): 2021-01-01 〜 2024-03-31
  （根拠: p.8）

## 10. 実験設定（Bayesian optimization, Hyperopt, 取引コスト β=0.05%）
- ハイパーパラメータ探索: Bayesian optimization + Hyperopt
- 探索データ: trainの10%
- PPO共通設定（記載範囲）:
  - Hidden layers: [1, 8]
  - Hidden layer dim: [2, 512]
  - Learning rate: [1e-8, 1e-1]
  - Discount factor \(\gamma\): [0, 1]
  - Activation: ReLU / Sigmoid / Tanh
  - Dropout: [0, 0.5]
  - Entropy coefficient: [0.01, 0.1]
  - Value function coefficient: [0.5, 1]
  - PPO epochs: [5, 50]
  - \(\epsilon\)-clip: 0.2
  - Episodes: 500
  （根拠: p.8-9, Table 1）
- 取引コスト:

```math
\delta_t = \beta \times P_t \times |w_t - w_{t-1}|
```

- \(\beta = 0.05\%\)（根拠: p.9）

## 11. 評価指標8種とベンチマーク
### 11.1 評価指標（8種）
- CR, AR, SR, CAR, SOR, OR, Annual Volatility, Stability（根拠: p.9-10）
- 論文本文に記載された代表式:

```math
SR = \frac{r_p-r_f}{\sigma_p}, \quad
CAR = \frac{r_p-r_f}{MDD}, \quad
SOR = \frac{r_p-r_f}{DR}
```

```math
OR = \frac{\int_{\theta}^{b}(1-F(r))dr}{\int_{a}^{\theta}F(r)dr}
```

- 年率ボラティリティは \(\sigma_p\sqrt{T}\) で \(T=252\)（根拠: p.10）

### 11.2 ベンチマーク
- Market Index（BSESN, DJIA, IBEX35, TWII）
- MVO
- 1/n等金額配分
- Single objective reward（重み付き単一目的化）
（根拠: p.11）

## 12. リーク防止チェック（`t`情報で特徴量、`t+1`リターン評価、リバランス時点整合）
この論文を再現する際、以下を実装要件として固定する。

1. 特徴量時点:
- 共分散・テクニカル指標は必ず時点\(t\)までの観測値のみで計算する（未来データ禁止）。

2. 意思決定と適用時点:
- 状態\(s_t\)から決定したウェイトは、最低でも次時点\(t+1\)のリターンに対して評価する。
- 実装上は「\(t\)終値までで特徴量計算→\(t\)時点でウェイト決定→\(t+1\)で約定/リターン計上」を採用する。

3. 取引コストの時点整合:
- \(|w_t-w_{t-1}|\) はリバランス時点でのみ計算し、同じ時点のポートフォリオ価値 \(P_t\) に掛ける。

4. スプリット境界のリーク防止:
- 2020-12-31以前のみで学習し、2021-01-01以降の評価期間情報をハイパーパラメータ探索に使わない。

注記: 論文本文では執行価格（open/close）や厳密な約定時点の説明が十分でないため、上記は再現時の防御的実装仕様として明示する。

## 13. 再現実装ToDo（Phase Bに引き渡す仕様）
1. データ取得と銘柄ユニバース定義
- 4市場の銘柄リスト作成ルール（時価総額上位30の基準日）を固定する。
- 欠損銘柄（Dow/IBEX）の扱いを明文化する。

2. 特徴量パイプライン
- 共分散行列の計算窓長を定義。
- 8指標のパラメータ（各期間）をコード定数として固定。

3. 3つのPPO学習器
- 報酬関数Log/DSR/MDDを独立実装。
- DSRの数式は原本p.6目視で最終確定。

4. 統合ネットワーク（CNN-MLP）
- 入出力テンソル形状、チャネル数、FC層次元、損失関数を実装前に確定。

5. バックテスト基盤
- 取引コスト、初期資本、リバランス頻度、評価指標8種の実装を統一。

6. 評価
- ベンチマーク4種を同一条件で比較。
- train/test分割とハイパーパラメータ探索境界を固定。

## 14. 不明点・原本確認要項
以下は再現時に必ず原本PDFを目視確認して確定する。

1. DSR式の記号（特に分子の \(\Delta X_t\), \(\Delta Y_t\) の係数関係）
- 理由: 抽出テキストで数式の一部が崩れている（p.6）。

2. CNN-MLP詳細アーキテクチャ
- 理由: kernel=(1,3)は明記されるが、フィルタ数・層サイズ・活性化の全詳細は本文だけでは不十分（p.7-9）。

3. Single objective rewardの重み
- 理由: ベンチマークとして言及されるが、具体重み設定が本文で十分に開示されない（p.11）。

4. 指標計算時のリスクフリー金利 \(r_f\)
- 理由: SR/CAR/SOR式はあるが、実験で使った \(r_f\) の具体値が本文から明確でない（p.10）。

5. 実売買時点（open/close）とリバランス実装の詳細
- 理由: 日次データ利用は明記されるが、執行タイミングの厳密定義が不足（p.8-11）。
