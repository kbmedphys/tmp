# Residual-return strategy module usage

This file accompanies `residual_return_strategies.py`.

## Assumed objects from the previous notebook

```python
residuals_wide        # DataFrame: index=date, columns=ticker, values=residual return
theme_constituents    # DataFrame: theme_id, theme_name, ticker, weight, as_of_date, release_date
tradable_results      # optional: theme_id, analysis_date, z_score, is_coherent, apwc, ...
```

## Import

```python
from residual_return_strategies import *
```

If the file is placed outside the notebook directory:

```python
import sys
sys.path.append("/path/to/module_directory")
from residual_return_strategies import *
```

## Example analysis date

```python
analysis_date = tradable_results["analysis_date"].max()
```

## 1. Coherent theme residual momentum

```python
w_theme, diag_theme = coherent_theme_residual_momentum_weights(
    residuals_wide=residuals_wide,
    theme_constituents=theme_constituents,
    analysis_date=analysis_date,
    theme_signal_table=tradable_results,
    lookback=60,
    z_threshold=2.0,
    gross_target=1.0,
)
```

## 2. Coherent theme long-only tilt

```python
# benchmark_weights is optional.
w_longonly, diag_tilt = coherent_theme_long_only_tilt_weights(
    residuals_wide=residuals_wide,
    theme_constituents=theme_constituents,
    analysis_date=analysis_date,
    benchmark_weights=None,
    theme_signal_table=tradable_results,
    active_budget=0.05,
)
```

## 3. Theme risk overlay

```python
base_weights = pd.Series(1 / residuals_wide.shape[1], index=residuals_wide.columns)

w_overlay, diag_overlay = theme_risk_overlay_adjustment(
    residuals_wide=residuals_wide,
    base_weights=base_weights,
    theme_constituents=theme_constituents,
    analysis_date=analysis_date,
    theme_signal_table=tradable_results,
    max_risk_understatement_ratio=1.5,
)
```

## 4. Stock-level residual reversal

```python
w_reversal, score_reversal = residual_reversal_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    lookback=20,
    quantile=0.20,
)
```

## 5. Stock-level residual momentum

```python
w_stock_mom, score_stock_mom = residual_momentum_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    lookback=60,
    quantile=0.20,
)
```

## 6. Residual pair trading

```python
w_pair, diag_pair = residual_pair_trading_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    lookback=120,
    corr_threshold=0.60,
    entry_z=1.50,
)
```

## 7. Residual cluster relative value

```python
w_cluster_rv, diag_cluster_rv = residual_cluster_relative_value_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    theme_constituents=theme_constituents,
    lookback=60,
)
```

## 8. Emerging theme discovery

```python
clusters, cluster_info = discover_residual_correlation_clusters(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    lookback=60,
    corr_threshold=0.35,
    min_cluster_size=5,
)

w_emerging, diag_emerging = emerging_theme_discovery_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    lookback=60,
    corr_threshold=0.35,
    min_cluster_size=5,
)
```

## 9. Residual dispersion regime strategy

```python
w_dispersion, diag_dispersion = residual_dispersion_regime_weights(
    residuals_wide=residuals_wide,
    theme_constituents=theme_constituents,
    analysis_date=analysis_date,
    theme_signal_table=tradable_results,
    high_apwc_allocation=0.50,
    low_apwc_allocation=0.50,
)
```

## 10. Residual risk-adjusted alpha

```python
# Example: use stock residual momentum score as expected residual alpha.
_, alpha = residual_momentum_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    lookback=60,
)

w_alpha, raw_alpha = residual_risk_adjusted_alpha_weights(
    residuals_wide=residuals_wide,
    expected_residual_alpha=alpha,
    analysis_date=analysis_date,
    lookback=60,
    covariance_mode="diag",
)
```

## Integrated strategy

```python
w_integrated, diag_integrated = integrated_residual_strategy_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    theme_constituents=theme_constituents,
    theme_signal_table=tradable_results,
    leg_allocations={
        "theme_momentum": 0.35,
        "stock_momentum": 0.20,
        "stock_reversal": 0.20,
        "pair_reversion": 0.15,
        "cluster_relative_value": 0.10,
    },
)
```

## Quick diagnostics

```python
strategy_weight_summary(w_integrated)
```

## Simple realized residual-return check

```python
weights_by_date = {
    analysis_date: w_integrated,
}
realized_residual_returns = portfolio_residual_return_series(
    residuals_wide=residuals_wide,
    weights_by_date=weights_by_date,
)
```

## Notes

- The module does not re-estimate residuals. It assumes residual returns are already calculated.
- Theme strategies can use `tradable_results` from the previous notebook. The expected key columns are `theme_id`, `analysis_date`, `z_score`, and `is_coherent`.
- If no z-score table is supplied, theme-level functions compute APWC and past residual returns but cannot classify themes as coherent unless `require_coherent=False`.
- Returned weights are signal weights, not a full production portfolio. Production use should add transaction costs, borrow constraints, liquidity constraints, factor exposure checks, and turnover controls.
