# 実装レビュー依頼

**User:** Anonymous  
**Created:** 5/20/2026 23:25:35  
**Updated:** 5/21/2026 23:59:00  
**Exported:** 5/22/2026 0:01:41  
**Link:** [https://chatgpt.com/c/6a0dc407-def4-8320-b734-6e898ab59360](https://chatgpt.com/c/6a0dc407-def4-8320-b734-6e898ab59360)  

## Response:
2026/5/20 23:32:35

> **ノートブックの内容確認**
>
>
> **ノートブックコードの出力と行番号の表示**
>
>
> **ノートブックセルのソースを番号付きで保存**
>
>
> **指定範囲のテキストを抽出**
>
>
> **指定範囲のテキスト抽出**
>
>
> **出力の一部を小分けに表示**
>
>
> **出力の一部を抽出**
>
>
> **実行ノートブックのセル出力確認**
>
>
> **ノートブックのメタデータ解析**
>
>
> **指定されたJupyterセルの出力抽出**
>
>
> **レビュー構成と分析**
>
> まず、コードの要件と文献を深く理解する必要があります。文献では、リスクモデルによるテーマの定義や、残差の相関の伝播性といった詳細が含まれています。データとしては、1999-2024年の米国株とバーラGEM3業界・スタイルファクターを使っており、補正方法に関する問題もあるかもしれません。
>
> **アプローチと統計手法の確認**
>
> 基本的な手法は、列をシャッフルしてr*=Xb+u*を生成し、回帰を再実行してu**を得て、zスコアを計算します。また、Mosaic+Bootstrapでは、株と時間に分割して残差選別し、時間の自己相関を保持します。展示7では、リリース前後のzス
>
> **合成データと問題点の整理**
>
> 合成データは、総リターン、曝露、ファクターリターン、共通ショックを使っています。市場曝露と切片が完全に重なっているため、共線性の問題があります。残差は問題ないものの、ファクターリターンの予測には解釈できない部分があるかもしれません。実データでの市場ファクターも問題になりそうですね。
>
> **文献とコードの整合性の確認**
>
> 文献ではリスクモデルの要因が示されていますが、OLSに切片を含めるべきかもしれません。GEM3には市場が含まれていない可能性があります。
>
> **データ分割とパーマネーションの方法**
>
> データセットを非重複パネルに分割し、各パネル内で独立して残差処理を行う方法を考えています。それぞれのバッチ内で資産のグループを変動させ、ブートストラップを使って誤差をランダム化し、相関を再計算することになりそうです。
>
> **コード実装と問題点の整理**
>
> ノートブックの実装は、論文とは異なり、パネルを1回だけ定義し、ランダムに10日のバッチを作成していません。残差処理や回帰分析もグローバルに行っており、それぞれのパネルやタイムタイル内で分離していません！これが主な問題です。ブートストラップ処理も全体に適用されており、論文と一致していない可能性があります。
>
> **合成データと結果の問題**
>
> コードはプレリリースの処理を含まず、合成データの結果は文献の予測と逆になっています。例えば、z<2グループが著しく正の係数を示しますが、これは合成データの小さいサンプルサイズによるものです。トレンドがないものの、追加のユニットテストでデータを改善できると思います。
>
> **テスト生成の修正とリスク予測の注意点**
>
> テスト生成を修正しないと、持続性を証拠として報告すべきでないかもしれません。リスクの過小評価問題として、コードはリスクモデル予測の残差分散でなく、経験的な残差共分散を比較しています。ポートフォリオの構築で均等ウェイトを使用するか、提供者ウェイトに従うべきです。
>
> **パフォーマンスと再サンプリングの最適化**
>
> 現在の設定では、データフレームやループが遅いため、ベクトル化やキャッシュの利用が必要です。合成リターンを計算する中で、欠損データがあると再残差化が適切に行われません。また、ブートストラップの影響で共通シックを保持している可能性があり、これを検討すべきです。
>
> **ブートストラップ結果の不確実性**
>
> ブートストラップでの平均が0からずれているのは、回帰による負の影響や他の要因から来るかもしれませんが、0.1近い場合は気になるところです。サンプル内のARショックで相関を切り離せていない可能性があります。この原因をさらに調査すべきかもしれません。
>
> **最終的な参照とフォーマットについて**
>
> 引用は十分あるので、簡単なファイル引用マーカーを使用し、ページや図に言及するだけで十分かもしれません。PDFページの画像を表示する必要はないけれども、埋め込まれたチャートについて触れるべきかもしれません。最終的に「確認した notebook: ...」の形で言及する感じです。
>
> 思考時間: 7m 42s

## Response:
2026/5/20 23:40:18

レビュー対象のNotebookは、文献の中核アイデアである「リスクモデル残差の平均ペアワイズ相関で coherent theme を検出する」という方向性は概ね捉えています。一方で、**文献の再現実装としてはまだ “最小デモ” の段階**です。特に、Mosaic + bootstrap の実装、リリース日前後60日分析、使用リターン、ファクターモデル仕様、リターン持続性検証の扱いに、文献との差分があります。

## 総評

文献は、テーマを「伝統的リスクモデルでは説明されない、短期・局所的な残差リターン相関」として定義し、残差相関の平均ペアワイズ相関、すなわち APWC を検定統計量として使います。文献では、テーマは既存ファクターとは異なり、狭く、かつ週から月単位で一時的に現れるものと位置づけられています。`ssrn-5336504.pdf` また、APWC はリスクモデル残差の相関行列の上三角平均であり、大きい値が残差間の相関、つまり未捕捉のテーマ性を示す統計量です。`ssrn-5336504.pdf`

Notebookはこの発想を反映し、日次クロスセクションOLSで残差を推定し、テーマ構成銘柄のAPWCを計算し、ブートストラップ帰無分布から z-score を出しています。この点は文献の大枠に沿っています。

ただし、文献が強調する Mosaic + bootstrap は、通常の残差シャッフルではなく、回帰残差の人工的な相関・分散縮小・時変エクスポージャー・残差とファクターの直交性を扱うための方法です。文献は、単純なブートストラップは z-score を過大評価し得るため、時間・銘柄方向の非重複パネルで別々に残差化し、10日ブロックと銘柄グループを使う Mosaic + bootstrap を採用しています。`ssrn-5336504.pdf``ssrn-5336504.pdf` この点で、Notebookの実装は**厳密なMosaic + bootstrapではなく、簡略版の residual block shuffle + 再残差化**です。

## 良い点

まず、`fit_residual_wide_from_returns_wide` で各営業日のクロスセクション回帰を行い、ファクターリターンと残差を推定している点は、文献の式 $ r = Xb + u $ に対応しています。文献でも、観測リターンとファクターエクスポージャーから日次クロスセクション回帰でファクターリターンと残差を推定すると説明されています。`ssrn-5336504.pdf`

次に、`average_pairwise_corr` は、相関行列の上三角成分を平均する実装になっており、APWC の定義と整合的です。文献も、残差相関行列を作り、そのペアワイズ相関の平均を検定統計量として使います。`ssrn-5336504.pdf`

また、`synthetic_returns = predicted + shuffled_residual` を作り、それを再度クロスセクション回帰して `boot_resid` を得る流れは、文献の基本ブートストラップ説明、すなわちシャッフルした残差を元に $ r^* = Xb + u^* $ を作り、再回帰して $ u^{**} $ を得る考え方に近いです。`ssrn-5336504.pdf`

時点整合についても、Notebookは `analysis_date` までを特徴量期間、翌営業日以降を将来ラベルとしており、実運用を意識したリーケージ回避になっています。これは文献の ex post 分析をそのまま再現するというより、投資可能性を意識した良い設計です。

## 主要な不一致・修正すべき点

### 1. Mosaic + bootstrap が文献どおりではない

最大の論点です。Notebookの `mosaic_bootstrap_apwc` は、全ユニバースに対して静的な銘柄パネルを一度作り、各銘柄の10営業日ブロックを独立にシャッフルし、その後に全ユニバースで再回帰しています。

文献の Mosaic + bootstrap は、単に「10日ブロックで残差をシャッフルする」方法ではありません。文献では、データを時間方向・銘柄方向の非重複パネルに分け、**各パネル内で別々に残差化**し、さらに時間方向は10連続観測のバッチに分け、各10日バッチ内で、少なくともファクター数の5倍の銘柄を含むような銘柄グループをランダムに作る、と説明されています。`ssrn-5336504.pdf`

Notebookでは、次の点が文献と違います。

| 項目 | 文献 | Notebook |
|---|---|---|
| 残差化 | 銘柄×時間のパネルごとに別々に回帰 | 全ユニバースで一括回帰 |
| 銘柄グループ | 10日バッチごとにランダムに変わる | 全期間で固定パネル |
| 回帰アーティファクト対策 | パネル内残差化で軽減 | 単純再回帰に近く、対策が不完全 |
| z-score の信頼性 | Mosaic + bootstrap 前提 | 簡略版なので過大評価リスクあり |

したがって、現状の z-score は「文献の Mosaic + bootstrap z-score」とは呼ばない方がよいです。`mosaic_bootstrap_apwc` という関数名も、正確には `block_bootstrap_apwc_simplified` などに変更すべきです。

### 2. 60日ウィンドウの扱いが文献と異なる

文献の Exhibit 7 では、Goldman Sachs のテーマバスケットについて、**リリース日前60カレンダー日**と**リリース後60カレンダー日**の APWC z-score を計算しています。文献は、リリース日前後の z-score を比較し、リリース後にも有意な相関が残ることを投資可能性の根拠にしています。`ssrn-5336504.pdf` また、145バスケット中、リリース前は61本、リリース後は60本が z-score 2以上であり、pre/post z-score の相関も49%と報告しています。`ssrn-5336504.pdf`

Notebookでは、`release_date + 60営業日` 以降の分析日を複数選び、その分析日までの過去60営業日を特徴量にしています。これは実運用向けには筋がよいものの、文献の Exhibit 7 の再現ではありません。

文献再現用には、少なくとも次のモードを分けるべきです。

```text
mode = "paper_pre_release"   : [release_date - 60 calendar days, release_date)
mode = "paper_post_release"  : [release_date, release_date + 60 calendar days]
mode = "tradable_rolling"    : public_only=True, analysis_dateまでの過去60営業日
```

現状の Notebook は `tradable_rolling` に近く、`paper_pre_release` と `paper_post_release` がありません。

### 3. 使用リターンが「excess return」ではなく「total_return」

文献では、日次の**超過リターン**を使って、Barra GEM3 の業種・スタイルファクターに対するクロスセクションOLSを実行しています。`ssrn-5336504.pdf` Notebookの入力スキーマは `stock_total_returns.total_return` であり、リスクフリーレート、ローカル市場リターン、通貨、ベンチマーク控除などが明示されていません。

日本株データへ適用するなら、少なくとも次を明確にすべきです。

```text
stock_excess_return = total_return - cash_return
または
stock_active_return = stock_return - benchmark_return
```

文献再現という観点では、`total_return` という列名は不正確です。`excess_return` に変更するか、変換セルを追加した方がよいです。

### 4. ファクターモデル仕様が文献よりかなり簡略化されている

文献は、Barra GEM3 の34業種ダミーと11スタイルファクターを使い、平均約1,100銘柄の米国大型流動性ユニバースで分析しています。`ssrn-5336504.pdf` Notebookの合成データは120銘柄、5ファクターであり、実データスキーマも `factor, exposure` の縦持ち形式だけです。

簡略化自体は問題ありませんが、レビュー上は次の点を明記すべきです。

- 現状は「論文再現」ではなく「論文の方法論デモ」。
- Barra GEMLTL を使うなら、業種ダミー、国・市場、スタイルファクター、制約、標準化、欠損処理を本番仕様に合わせる必要がある。
- `market` exposure を全銘柄1.0にしている合成データで、さらに回帰に intercept を入れているため、設計行列が完全共線的になる。残差自体は `lstsq` で得られるものの、ファクターリターンの解釈は不安定になる。

特に `static_exposure["market"] = 1.0` と `x = [1, x_factor]` の併用は避けるべきです。実データでも market factor が定数列なら、intercept を落とすか market factor を落とすべきです。

### 5. リスク過小評価の検証は方向性は正しいが、文献のリスクモデル検証とはまだ違う

文献は、リスクモデルが残差共分散の非対角要素をゼロと置くため、coherent theme では残差リスクを過小評価すると述べています。`ssrn-5336504.pdf` また、平均ペアワイズ相関が0.06程度でも、50銘柄等ウェイトバスケットでは残差リスク予測が実際の約半分になり得る例を示しています。`ssrn-5336504.pdf`

Notebookの `residual_risk_comparison` は、過去窓のサンプル残差共分散を使い、対角だけを使ったリスクとフル共分散を使ったリスクを比較しています。これは説明用には有効です。

ただし、本格検証では次が必要です。

- 対角リスクはサンプル分散ではなく、リスクモデルの idiosyncratic variance $ \Delta $ を使う。
- フル共分散は同じ過去窓の in-sample だけでなく、将来窓で out-of-sample 実現リスクと比較する。
- coherent / non-coherent 群別に、リスク過小評価倍率を集計する。
- サンプル共分散の推定誤差、とくに銘柄数が多く期間が短い場合の不安定性を扱う。

### 6. リターン持続性の検証結果が、文献と逆方向になっている

文献では、APWC z-score が有意なバスケットでは、過去残差リターンと将来残差リターンの間に有意なトレンドがあり、z-score が有意でないバスケットではトレンドがない、と報告されています。Exhibit 10 では、z>=2 群の係数が0.126、t値が2.11、z<2群の係数が0.028、t値が0.47です。`ssrn-5336504.pdf`

一方、Notebookの実行済み出力では、合成データ上で次のようになっています。

```text
z < 2   : coefficient 7.000955, t = 4.465757
z >= 2  : coefficient -0.000090, t = -0.000079
```

これは文献の結論と逆です。しかも観測数は z<2 群が4、z>=2群が5しかなく、統計的解釈はできません。

したがって、`persistence_regression` は実装部品としてはよいですが、現状の合成データ結果を「文献再現」として表示するのは危険です。合成データでは、APWC検出用の共通ショックは入っていますが、「coherent theme に残差リターン持続性が出る」DGPにはなっていません。合成データを使うなら、APWC検出テストとリターン持続性テストを分け、後者には明示的に momentum を持つ共通ショックを入れる必要があります。

## 優先度付き修正案

**最優先**は、Mosaic + bootstrap の名称と実装の整合です。現状の処理は簡略版として扱い、文献どおりにするなら、10日バッチごとに銘柄をランダム分割し、各 time × stock tile 内で別々に残差化する実装へ変更してください。文献はこの部分を、単純ブートストラップの z-score 過大評価を避けるための中核手法として位置づけています。`ssrn-5336504.pdf`

次に、文献再現モードとして、リリース日前後60カレンダー日の pre/post z-score を実装してください。現状の `choose_analysis_dates` は運用向けローリング分析として残してよいですが、文献の Exhibit 7 とは別物です。`ssrn-5336504.pdf`

第三に、`total_return` を `excess_return` に置き換え、ファクターモデルの設計行列に rank check を入れてください。特に定数 market exposure と intercept の同時投入は避けるべきです。

第四に、合成データモードの出力は「smoke test」と明示し、リターン持続性の実証結果としては扱わない方がよいです。現状の合成結果は、APWC検出については期待どおりですが、文献のリターン持続性とは一致していません。

第五に、実データ検証ではランダムバスケットの負例テストを追加してください。文献では、ランダムバスケットの z-score は概ね0中心で -2 から 2 程度に収まると説明されています。`ssrn-5336504.pdf` これは実装のキャリブレーション確認として有効です。

## 判定

現状のNotebookは、**文献のコンセプトを理解するためのプロトタイプとしては良好**です。APWC、残差化、ブートストラップ帰無分布、リスク過小評価、将来残差リターン回帰という主要パーツは揃っています。

ただし、**文献再現実装としては未完成**です。特に、Mosaic + bootstrap の厳密性、リリース日前後60日の検証設計、excess return の使用、Barra型ファクターモデル仕様、リターン持続性の検証が文献と一致していません。

実務向けに仕上げるなら、Notebookを次の二層に分けるのがよいです。

```text
1. paper_replication_mode
   - 米国大型株または対象ユニバース
   - excess return
   - Barra型ファクター
   - release前後60 calendar days
   - 文献準拠の Mosaic + bootstrap

2. tradable_signal_mode
   - public_only=True
   - analysis_date時点までの過去窓
   - 翌営業日以降に適用
   - risk forecast / return forecast の out-of-sample 評価
```

この切り分けを入れれば、文献再現と投資シグナル開発の両方で、実装の意味が明確になります。

## Response:
2026/5/20 23:45:58

> **考慮中: Codex用指示書作成の方向性**
>
> ユーザーがCodexに仕事を指示するための指示書を作りたいとのこと。以前のレビューに基づいて、ノートブックの修正作業仕様を日本語での指示に落とし込む必要がありそう。ファイルからの引用が必要かもしれませんが、ウェブ検索は必要ないかもしれません。
>
> **指示書作成の方向性を調整中**
>
> ユーザーがCodex用の指示書を作成したいとのことですが、正確な関数や内容を確認するために、アップロードされたipynbをチェックする必要がありそうです。ウェブ検索は必要ないかもしれませんが、Codexに関する情報を手元で確認しておくべきかも…
>
> **指示書作成について再確認**
>
> Codexに作業をさせるための指示書は、最新のドキュメントが必要か迷っています。最終的にはプロンプトとして指示を作成すれば良いのですが、ドキュメントに関する情報は、OpenAIの製品に関する使い方についてであればウェブ検索が必要かもしれません。
>
> **Searching Web for Codex task instructions**
>
> [Using Codex with your ChatGPT plan](https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan)
>
> **指示書作成と参照元の確認**
>
> ユーザーが指示書を作成したいとのことですが、もし特定の論文や内容に言及する場合は、適切に引用を含める必要がありそうです。それには、ファイル内容を確認するために `file_search` を使うか、既に提供されたスニペットを活用する方法が考えられます。
>
> **指示書作成と引用の整理**
>
> ユーザーはCodexに添付プログラムを修正させる指示書を作成したいようです。ノートブックの関数名や論文の詳細を確認する必要がありますが、最終的な指示書には引用が不要かもしれません。ただし、必要があれば、論文の一部には `file_search` を使用して引用します。
>
> **Codex指示書作成のためのノートブック確認**
>
> Codexに適切な指示を出すために、ノートブックの内容を詳しく確認する必要があります。そのためにPythonを使ってノートブックを読み込んで、必要な情報を抽出し、指示書を調整していきます。
>
> **Pythonでノートブックの内容を解析**
>
>
> **関数の詳細確認**
>
> セル9、11、13にある関数の詳細を確認する必要があります。これらの関数をしっかりと理解することで、指示書に反映させることができ、より適切な内容を提供できると思います。
>
> **インスペクトセルの関数詳細**
>
>
> **インストラクションシート作成**
>
> 指示書は、テキストのセクションとして作成する必要があります。"Codexにそのまま貼り付けるプロンプト"と受け入れ基準を含めるべきです。Codexはコードの作成やレビューを手伝うエージェントですが、ウェブ情報を引用する必要がある場合は、Citationを使うべきです。
>
> 思考時間: 5m 21s

## Response:
2026/5/20 23:51:20

以下をそのまま Codex のタスク欄に貼り付けて使える形で作成しました。Codex はコードの読解・編集・実行に使えるコーディングエージェントで、リポジトリ内の `AGENTS.md` に作業方針やテストコマンドを置く運用もできます。([OpenAI Developers](https://developers.openai.com/codex/cloud?utm_source=chatgpt.com))

文献上、今回の実装で必ず合わせるべき点は、日次クロスセクション回帰で excess return をリスクモデル残差に分解すること、テーマを既存ファクターでは説明されない一時的な残差相関として扱うこと、APWC を残差相関行列の平均ペアワイズ相関として計算すること、Mosaic + bootstrap で z-score を評価すること、さらにリリース前後60カレンダー日の分析を分けることです。`ssrn-5336504.pdf` `ssrn-5336504.pdf` `ssrn-5336504.pdf` `ssrn-5336504.pdf` `ssrn-5336504.pdf`

---

## Codex 作業指示書

```text
# 作業目的

添付Notebook `thematic_investing_risk_based_perspective(1).ipynb` を、文献 `ssrn-5336504(2).pdf` の方法論により忠実な実装へ修正する。

現状Notebookは、リスクモデル残差、APWC、簡易ブートストラップ、リスク過小評価、残差リターン持続性を一通り実装しているが、文献の厳密な再現としては以下に差分がある。

1. Mosaic + bootstrap が文献どおりではなく、簡略化された residual block shuffle になっている。
2. 文献の Exhibit 7 に対応する release 前後60カレンダー日の pre/post z-score が未実装。
3. 使用リターンが `total_return` 前提で、文献の `excess return` とずれている。
4. ファクターモデルの設計行列に rank check がなく、intercept と定数 market exposure が共線的になり得る。
5. リスク過小評価検証がサンプル共分散ベースで、リスクモデルの idiosyncratic variance との切り分けが弱い。
6. 残差リターン持続性の検証が合成データ結果と文献結果の区別を十分に明示していない。
7. ランダムバスケットによるキャリブレーション確認が不足している。

この作業では、Notebookを「文献再現モード」と「投資可能ローリング分析モード」に明確に分け、文献との整合性をレビュー可能な形にする。

# 対象ファイル

- 主対象:
  - `thematic_investing_risk_based_perspective(1).ipynb`

- 参照文献:
  - `ssrn-5336504(2).pdf`

- 追加してよいファイル:
  - `docs/implementation_alignment.md`
  - `AGENTS.md`
  - `README.md` または `docs/runbook.md`

ただし、Notebook内で完結するという既存方針は尊重する。外部 `.py` モジュールへの大規模分割は行わない。補助的なドキュメントやテスト実行手順の追加は可。

# 実装要件

## 1. Notebookの分析モードを分離する

現在の `choose_analysis_dates` は、release 後に公開済み構成銘柄を使い、過去60営業日を特徴量、将来60営業日をラベルにする実運用寄りの設計になっている。

これを以下の3モードに分ける。

### mode = "paper_pre_release"

- 目的:
  - 文献 Exhibit 7 の pre-release z-score 再現。
- ウィンドウ:
  - `release_date - 60 calendar days` から `release_date` の直前まで。
- 注意:
  - これは ex post 分析であり、release 前にテーマ構成銘柄が公開されていたとは仮定しない。
  - `public_only=False` としてよいが、出力に `is_ex_post=True` を明記する。

### mode = "paper_post_release"

- 目的:
  - 文献 Exhibit 7 の post-release z-score 再現。
- ウィンドウ:
  - `release_date` から `release_date + 60 calendar days` まで。
- 注意:
  - 60営業日ではなく60カレンダー日を使う。
  - 実際に計算対象とする日は、そのカレンダー期間内に存在する取引日のみ。

### mode = "tradable_rolling"

- 目的:
  - 実運用・シグナル開発用。
- ウィンドウ:
  - `analysis_date` までの過去 `cfg.window` 営業日。
  - 将来ラベルは `analysis_date` の翌営業日以降。
- 注意:
  - `public_only=True` を維持する。
  - 特徴量とラベルの日付が重ならないことを assert する。

## 2. リターン列を excess return 前提に修正する

現在のスキーマは `stock_total_returns.total_return` である。文献は excess return を使うので、以下のように改修する。

- 新しい推奨入力:
  - `stock_excess_returns`
  - 必須列: `date`, `ticker`, `excess_return`

- 後方互換:
  - `stock_total_returns.total_return` しかない場合は読み込みを許す。
  - ただし `RETURN_TYPE = "total_return"` と明示し、validation report に以下を表示する。
    - `paper_replication_ready = False`
    - `reason = "Using total_return, not excess_return"`

- 変換オプション:
  - `cash_return` または `benchmark_return` が存在する場合のみ、明示的に
    - `excess_return = total_return - cash_return`
    - または `active_return = total_return - benchmark_return`
    を作る。
  - どちらを使ったかを `return_construction` として出力する。

- 合成データ:
  - 列名を `excess_return` に変更する。
  - 合成データの説明には「APWC検出の smoke test であり、文献の実証結果ではない」と明記する。

## 3. ファクターモデル回帰の rank check を追加する

`fit_residual_wide_from_returns_wide` を修正する。

必須要件:

- 各日付の設計行列について、以下を実行する。
  - 欠損 exposure の除外。
  - 銘柄数がファクター数に対して十分か確認。
  - 定数列を検出する。
  - intercept と定数 market exposure の同時投入による完全共線性を防ぐ。
  - `np.linalg.matrix_rank(X)` を確認する。
  - rank deficient の場合は、定数列または完全共線列を落とす。
  - 落とした列名を `regression_diagnostics` に記録する。

- `sm.add_constant` を使う場合は `has_constant` の扱いを明示する。
- 回帰残差について、日次で以下を検査する。
  - 残差平均が十分小さい。
  - 残差と使用ファクター exposure の内積が十分小さい。
- `factor_returns` の解釈不能な列、つまり rank 落ちで推定不能な列は NaN にするか、diagnostics に明示する。

## 4. APWC実装の検査を追加する

`average_pairwise_corr` は相関行列の上三角平均として実装されているが、以下の単体検査をNotebook内に追加する。

- 2銘柄だけのケースで、APWCがその2銘柄の相関に等しい。
- 完全同一系列の複数銘柄で、APWCが1に近い。
- 独立乱数系列で、APWCが0近傍になる。
- 欠損が多すぎる銘柄は除外される。
- 有効銘柄数が2未満なら NaN を返す。

## 5. Mosaic + bootstrap を2段階に分ける

現在の `mosaic_bootstrap_apwc` は文献の厳密な Mosaic + bootstrap ではない。以下のように修正する。

### 5.1 既存実装の名称変更

現在の関数を以下のように rename する。

- 旧: `mosaic_bootstrap_apwc`
- 新: `block_bootstrap_apwc_simplified`

この関数のdocstringに以下を明記する。

- 「文献のMosaic + bootstrapの簡易版」
- 「全ユニバース一括残差化を使うため、文献のtile別残差化とは異なる」
- 「z-scoreを過大評価する可能性がある」
- 「本番の文献再現値としては使わない」

### 5.2 文献準拠版の追加

新関数を追加する。

- `mosaic_bootstrap_apwc_paper_like(...)`

実装方針:

- 入力:
  - `returns_wide`
  - `exposure_by_date`
  - `universe_by_date`
  - `factor_names`
  - `basket_tickers`
  - `window_start`
  - `window_end`
  - `block_size=10`
  - `n_bootstrap`
  - `seed`
  - `min_obs_ratio`
  - `min_stocks_per_factor_multiplier=5`

- 手順:
  1. `window_start` から `window_end` までの取引日を抽出。
  2. 時間方向を10連続観測のdisjoint batchに分割。
  3. 各10日batchごとに、その時点の有効ユニバース銘柄をランダムに並べ替える。
  4. ファクター数を `p` として、各stock groupの銘柄数が少なくとも `5 * p` になる最大の `K` を選ぶ。
  5. 各batch内で `K` 個のdisjoint stock groupを作る。
  6. 各 time × stock tile 内で、日次クロスセクション回帰を別々に実行してtile residualを得る。
  7. 観測APWCは、対象basketの銘柄だけを取り出し、tile residualから相関行列を作って計算する。
  8. bootstrap replicateでは、tile/block単位で残差の同時相関を壊すようにscrambleする。
  9. scramble後の残差から synthetic return を作る。
  10. 同じtile構造で再残差化する。
  11. 対象basketのAPWCを再計算する。
  12. `z = (observed_apwc - mean(null_apwc)) / std(null_apwc)` を返す。

- 出力:
  - `observed_apwc`
  - `z_score`
  - `null_mean`
  - `null_std`
  - `n_bootstrap`
  - `n_valid_dates`
  - `n_valid_basket_tickers`
  - `method = "mosaic_bootstrap_paper_like"`
  - `tile_diagnostics`
  - `warnings`

重要:
- 文献完全再現が困難な部分はdocstringと出力の `warnings` に明記する。
- 「Mosaic + bootstrap」と名乗る関数は、tile別残差化を行うものだけに限定する。
- 簡易版と文献準拠版を混同しない。

## 6. release 前後60カレンダー日の z-score テーブルを追加する

文献 Exhibit 7 に対応する関数を追加する。

- `compute_release_window_zscores(...)`

出力列:

- `theme_id`
- `theme_name`
- `release_date`
- `n_constituents`
- `pre_start`
- `pre_end`
- `post_start`
- `post_end`
- `pre_apwc`
- `pre_z_score`
- `post_apwc`
- `post_z_score`
- `pre_is_coherent`
- `post_is_coherent`
- `method`
- `is_ex_post`
- `warnings`

仕様:

- `pre_start = release_date - pd.Timedelta(days=60)`
- `pre_end = release_date - 1 calendar day`
- `post_start = release_date`
- `post_end = release_date + pd.Timedelta(days=60)`
- 計算に使う実日付は、その期間内の取引日に限定する。
- `z_threshold = 2.0` を coherent 判定のデフォルトにする。
- pre/post z-score の相関を集計する。
- pre/post で `z >= 2` の本数と比率を集計する。

## 7. tradable_rolling 分析は既存の良い点を残す

現在の `choose_analysis_dates` の思想は、実運用上は有用である。削除せず、以下のように改名・整理する。

- 旧: `choose_analysis_dates`
- 新: `choose_tradable_analysis_dates`

仕様:

- release後に公開済み構成銘柄のみ使う。
- feature window は `analysis_date` まで。
- label window は `analysis_date` の翌営業日以降。
- `feature_max_date <= analysis_date`
- `label_min_date > analysis_date`
- 上記を assert する。
- 出力に `mode = "tradable_rolling"` を付ける。

## 8. リスク過小評価検証を整理する

`residual_risk_comparison` を以下のように拡張する。

- 入力に `idio_var_source` を追加する。
  - `"sample_diag"`: 過去窓の残差サンプル分散の対角を使う。
  - `"risk_model"`: 実データに idiosyncratic variance がある場合に使う。
- 現状は `"sample_diag"` でよいが、出力に明示する。
- 出力列:
  - `model_residual_risk`
  - `empirical_full_residual_risk`
  - `risk_understatement_ratio = empirical_full_residual_risk / model_residual_risk`
  - `diag_source`
  - `annualized = True`
- coherent / non-coherent 群ごとにリスク過小評価倍率を集計する。
- in-sample であることを明記し、将来窓で out-of-sample 実現リスクを比較する拡張余地をdocstringに書く。

## 9. 残差リターン持続性の解釈を修正する

`persistence_regression` は残すが、次を修正する。

- 合成データのデフォルトDGPでは、文献のExhibit 9/10に相当する結論を期待しない。
- validation report に以下を追加する。
  - `persistence_interpretation_ready = not USING_SYNTHETIC_DATA`
- 合成データで文献型の持続性を検査したい場合は、オプションDGPを追加する。
  - `generate_synthetic_tables(cfg, dgp="apwc_only")`
  - `generate_synthetic_tables(cfg, dgp="apwc_with_momentum")`
- `apwc_only` ではAPWC検出だけを検査する。
- `apwc_with_momentum` では共通テーマショックにAR成分またはdriftを入れ、past residual return と future residual return の正の関係を検査できるようにする。
- 実データ未配置時の出力には「研究結果ではない」と明記する。

## 10. ランダムバスケットの負例テストを追加する

文献では、ランダムバスケットの z-score は概ね0中心で、-2から2程度に収まることがキャリブレーション確認として使われている。これに対応する検査を追加する。

新関数:

- `random_basket_calibration(...)`

仕様:

- 実ユニバースからテーマと同じ銘柄数のランダムバスケットを複数生成する。
- 各ランダムバスケットについて APWC z-score を計算する。
- 出力:
  - mean z-score
  - std z-score
  - min / max
  - share_abs_z_gt_2
- 合成データでは、coherent shockを含まない銘柄群を使った負例も作る。
- validation report に calibration summary を入れる。

## 11. Notebook末尾の validation_report を強化する

最後の validation report に以下を含める。

- `using_synthetic_data`
- `return_type`
- `return_construction`
- `paper_replication_ready`
- `n_themes`
- `n_tickers`
- `n_return_dates`
- `factor_model_rank_issues`
- `max_abs_daily_residual_mean`
- `max_abs_factor_residual_inner_product`
- `apwc_unit_tests_passed`
- `release_window_mode_available`
- `tradable_rolling_timing_ok`
- `mosaic_method_used`
- `simplified_bootstrap_used_only_for_demo`
- `random_basket_calibration_mean_z`
- `random_basket_calibration_share_abs_z_gt_2`
- `persistence_interpretation_ready`
- `notebook_scope`

## 12. 文献対応表を追加する

Notebook内または `docs/implementation_alignment.md` に、次の表を作る。

列:

- `Literature requirement`
- `Paper location / section`
- `Notebook implementation`
- `Status`
- `Notes`

最低限入れる項目:

1. Factor model: `r = Xb + u`
2. Use of daily excess returns
3. Theme as transient residual correlation
4. APWC definition
5. Bootstrap z-score definition
6. Mosaic + bootstrap tiling
7. Release pre/post 60 calendar day analysis
8. z >= 2 coherent threshold
9. Risk underestimation from nonzero residual correlations
10. Future residual return regression by coherent vs non-coherent groups
11. Random basket calibration

## 13. 実行・検証

Notebook修正後、以下を実行する。

```bash
jupyter nbconvert --to notebook --execute "thematic_investing_risk_based_perspective(1).ipynb" --output "thematic_investing_risk_based_perspective.executed.ipynb"
```

実行に失敗した場合:

- エラーセルを特定する。
- 依存パッケージ不足なら、必要最小限の依存をREADMEに記載する。
- データ未配置が原因なら、合成データモードで完走するようにする。
- 実データ前提のセルは、実データ未配置時にスキップまたは明示的に synthetic mode に切り替える。

## 14. 受け入れ基準

以下を満たしたら作業完了とする。

- Notebookが合成データモードで最後まで実行できる。
- `paper_pre_release`, `paper_post_release`, `tradable_rolling` の3モードが明確に分かれている。
- 文献準拠版の `mosaic_bootstrap_apwc_paper_like` と簡易版の `block_bootstrap_apwc_simplified` が区別されている。
- 60カレンダー日と60営業日の違いがコード上も説明上も明確。
- `total_return` と `excess_return` の違いがvalidation reportに出る。
- rank deficient な設計行列を検出できる。
- APWCの単体検査がNotebook内で通る。
- ランダムバスケット calibration が実行される。
- 合成データ結果を文献の実証結果と誤解させる記述がない。
- `docs/implementation_alignment.md` またはNotebook内の対応表で、文献要件と実装状態が確認できる。
- 実行済みNotebook、または実行ログに、成功・失敗・未検証項目が明記されている。

# 禁止事項

- 文献と異なる簡易実装を「文献準拠」または「厳密なMosaic + bootstrap」と呼ばない。
- 合成データの結果を実証結果として解釈しない。
- release前に公開されていない構成銘柄を使う分析を、投資可能分析として扱わない。
- 60営業日を、文献の60カレンダー日分析として表示しない。
- `total_return` を文献の `excess return` と同一視しない。
- PDFや元データを変更しない。
- 乱数seedなしの非再現的な結果をvalidationに使わない。

# 期待する最終報告

作業完了時に、以下を簡潔に報告する。

1. 変更したファイル一覧。
2. 追加・変更した主要関数。
3. 文献との整合性が改善された点。
4. まだ完全再現でない点。
5. 実行したコマンド。
6. 実行結果。
7. validation_report の主要値。
```

---

## 追加で置く `AGENTS.md` 案

Codex に継続的にこの方針で作業させるなら、リポジトリ直下に以下を置くとよいです。

```md
# AGENTS.md

## Project context

This project implements and reviews a notebook replication of “Thematic Investing: A Risk-based Perspective”.

The main deliverable is a self-contained Jupyter notebook:

- `thematic_investing_risk_based_perspective(1).ipynb`

The reference document is:

- `ssrn-5336504(2).pdf`

## Working agreements

- Keep the notebook self-contained unless explicitly instructed otherwise.
- Do not modify the PDF or raw data files.
- Use deterministic random seeds for all bootstrap and synthetic-data experiments.
- Do not treat synthetic-data outputs as empirical findings.
- Clearly distinguish:
  - paper replication mode,
  - tradable rolling signal mode,
  - simplified demo mode.
- Never label a simplified residual block bootstrap as exact Mosaic + bootstrap.
- Preserve time alignment:
  - features must use data no later than `analysis_date`;
  - labels must start strictly after `analysis_date`.
- For paper pre-release analysis, explicitly mark the analysis as ex post.

## Statistical implementation standards

- Use excess returns for paper replication.
- If only total returns are available, mark paper replication as not ready.
- Check factor design matrix rank on each cross-section.
- Detect and handle intercept / constant factor collinearity.
- Report regression diagnostics.
- Report bootstrap method and limitations in output tables.
- Keep z-score threshold configurable; default is `z >= 2`.

## Test command

After modifying the notebook, run:

```bash
jupyter nbconvert --to notebook --execute "thematic_investing_risk_based_perspective(1).ipynb" --output "thematic_investing_risk_based_perspective.executed.ipynb"
```

If this fails, identify the failing cell and fix it or document why it cannot be executed in the current environment.

## Final response format

Report:

1. Files changed.
2. Main functions changed or added.
3. Tests or notebook execution performed.
4. Validation summary.
5. Remaining limitations.
```

文献の完全再現と投資シグナル開発は目的が異なるので、この指示書では両者を明示的に分けています。これにより、Codex が「実運用向けには良いが文献再現ではない」部分を誤って文献準拠として扱うリスクを下げられます。

---

**Sources:**

- [Codex web](https://developers.openai.com/codex/cloud?utm_source=chatgpt.com)

## Response:
2026/5/20 23:52:52

> **考慮中: ファイル作成方法**
>
> ユーザーが「指示書はファイルとして出力して」と言っているので、ファイル形式を作成する必要があります。Markdownやテキストの形式でファイルを作成し、リンクを提供するのが適切かもしれません。特に.docxや.pdfではなく、テキストファイルが求められているようです。
>
> **決定: ファイル生成方法**
>
> ユーザーが「指示書はファイルとして出力して」と言っているので、ひとつのMarkdownファイルに主要な指示と、必要であればAGENTS.mdも追加してファイル化する予定です。指示書自体は1つで、AGENTS.mdはオプションとして取り扱います。
>
> 思考時間: 3m 14s

## Response:
2026/5/20 23:56:07

指示書ファイルを作成しました。

[Codex作業指示書をダウンロード](sandbox:/mnt/data/codex_work_instructions_thematic_investing.md)

## Response:
2026/5/21 0:15:48

新しいNotebookを、前回のCodex指示書と文献要件に照らしてレビューします。まず主要関数・検証セル・実行結果を確認し、差分と未達点を優先度付きで整理します。

## Response:
2026/5/21 0:16:06

構成・関数名はかなり指示書に沿っていますが、デフォルト実行では `compute_release_window_zscores` 周辺が重く、5〜10分で完走せず受け入れ基準未達です。

## Response:
2026/5/21 0:19:47

保存状態も未実行で、合成データでもまず実行可能性の確保が必要です。主因は統計ロジック以前に paper-like bootstrap の計算量にあります。

## Response:
2026/5/21 0:28:40

> **確認と最終レビューに関する考察**
>
> ツールは「終了」と表示しましたが、原因はコンテナではなくプロセスが終了したためかもしれません。重い処理を続ける必要はないので、コードベースの発見を最終レビューで示すべきです。ノートブックコードについては、ライン番号を参照することで対応できそうです。
>
> **最終確認と参考資料の取り扱い**
>
> PDFやノートブックを生成されたソース行番号で参照を付けることは可能ですね。リンクは後で共有する必要がないかもしれませんが、進行確認だけなら行番号を記載できます。ファイル検索や生成されたソースへのリンクを含める必要はないかもしれません。重要なのは、プロセス中のタイムアウトを正
>
> **Syntheticデータと検証に関する考察**
>
> 合成データがTrueを返すのは問題ないかもしれませんが、合成データは本物のデータと異なるため、間違った印象を与える可能性があります。合成データ使用時には、paper_replication_readyをFalseに設定する方が良いかもしれません。検証が行われない場合、論文準備が必要ないとも言えます。
>
> **Mosaic タイルとブートストラップの考察**
>
> `make_mosaic_tiles`では、もし最小グループサイズ未満の株式があると警告し、小さなグループで残差処理が続行されるが、これが文書の要件を満たさない可能性がある。少ない株式を使用するのは危険かも。`block_permute_columns_by_time`の動作も確かめる必要があり、残差が
>
> **ブローカーバスケットとリリース前後のデータについて**
>
> PDFでは、合成データのブートストラップが特定のブローカーバスケットの株のみを使用するとありますが、以前の方法論では広範な銘柄群を使って残差処理をしていました。合成データのn_bootstrap=8は結果に不安定さをもたらす可能性があり、最適化が必要です。
>
> **コードの改善とリスク比較**
>
> `tradable_results`が空かどうかを確認せずにカラムにアクセスしてしまうので、データが少ない場合に失敗する可能性があります。合成データでは行があるので問題ありませんが、ガードを追加すべきです。`risk_understatement_ratio`の名前が誤解を生むかもしれませんが、問題ないです。
>
> **データの処理と検証について**
>
> ランダムなバスケットでは、全てのテーマのティッカーが除外されると、サンプル数は適切に減少します。合成データではバスケットが少ないため要約に意味がないですが、これはスモークテストとして問題なしです。ドキュメントに関しては、指示が明記された通りに扱って問題ないと考えます
>
> **計算効率と合成データ設定の最適化**
>
> 現在のアプローチではモザイク残差を繰り返し計算しており、キャッシュがないかもしれません。合成データの反復回数を減らし、重い処理をスキップするオプションを使用することが有効です。簡略化された実装の再回帰については、文書内で言及する必要があるかもしれません。
>
> **データの安定性とドキュメントの確認**
>
> イベント前ウィンドウには共通スケールが含まれ、問題はなさそうですが、合成データのAPWCが高めという点に注意。また、ブートストラップのzスコア計算について、デフォルト設定で不安定な値が出たりするため、再サンプリング回数を増やすなどの改善が必要です。
>
> **最終レビューと構成要素の整理**
>
> 最終的な結果を日本語でまとめ、適切な文献を引用する必要があります。APWCやモザイク統計、リリースウィンドウ、リスク/リターンに関する討論については、ノートブック内の行番号を参考にする一方で、個別のツールに関する詳細な説明は避けます。また、修正指示を明確に伝える必要があります。
>
> 思考時間: 18m 35s

## Response:
2026/5/21 0:34:23

対象: [`thematic_investing_risk_based_perspective 2.ipynb`](sandbox:/mnt/data/thematic_investing_risk_based_perspective%202.ipynb)

## 判定

**前回版からはかなり改善されていますが、まだ受け入れ不可です。**

理由は主に2つです。

1. **Notebookがデフォルト設定で完走しません。**  
   `jupyter nbconvert --to notebook --execute "thematic_investing_risk_based_perspective 2.ipynb"` を実行しましたが、600秒でタイムアウトしました。また、アップロードされたNotebook自体も全コードセルの `execution_count` が `None` で、実行済みNotebookではありません。

2. **文献再現readyの判定が誤解を招きます。**  
   実データ未配置の合成データモードでも `PAPER_REPLICATION_READY = True` になっています。これは「excess_return列を使っている」という意味では正しいですが、「文献再現としてready」という意味では不正確です。

実装方針は前回指示にかなり沿っています。ただし、このままでは「合成データで完走」「文献再現モードとしての信頼性」「実データ投入時のスケーラビリティ」の3点で不足があります。

---

## 良くなった点

今回のNotebookでは、前回指摘した大項目の多くが反映されています。

| 項目 | 評価 |
|---|---|
| `paper_pre_release` / `paper_post_release` / `tradable_rolling` の分離 | 良い |
| 60カレンダー日と60営業日の区別 | 良い |
| `stock_excess_returns` 優先、`total_return` fallback | 良い |
| rank check付きの日次クロスセクションOLS | 良い |
| APWC単体テスト | 良い |
| `block_bootstrap_apwc_simplified` と `mosaic_bootstrap_apwc_paper_like` の分離 | 良い |
| 合成データを smoke test と明記 | 良い |
| ランダムバスケット calibration の追加 | 良い |
| validation report と文献対応表の追加 | 良い |

文献は、daily excess return を $ r = Xb + u $ に分解し、伝統的ファクターで説明されない残差相関をテーマ性として扱う枠組みです。今回のNotebookは、この大枠にはかなり近づいています。`ssrn-5336504.pdf`

---

## 重大な修正点

### 1. Notebookが完走しない

これは最優先です。

前回の受け入れ基準は「合成データモードで最後まで実行できる」でしたが、現在のNotebookはデフォルト設定のままでは少なくとも私の環境で600秒以内に完走しませんでした。

原因は、おそらく `mosaic_bootstrap_apwc_paper_like` の中で、各bootstrap replicateごとに tile 別OLSを繰り返しているためです。小さい合成データでも重く、実データではさらに厳しくなります。

現在の構造では、実データで `bootstrap_reps_real = 200`、テーマ数が多い場合、現実的な実行時間にならない可能性が高いです。

**修正方針:**

- synthetic smoke test 用のデフォルト `bootstrap_reps_synthetic` は 2 または 3 に落とす。
- 実証用 rep 数は設定だけ残し、Notebook標準実行では使わない。
- `mosaic_bootstrap_apwc_paper_like` 内で、tileごとの設計行列、使用列、射影行列、または least-squares solver を事前計算して再利用する。
- validation report に `runtime_mode = "smoke_test"` / `"research_run"` を追加する。
- 実行済みNotebookを生成して添付する。

---

### 2. `PAPER_REPLICATION_READY=True` が不正確

合成データモードでは、`stock_excess_returns` が生成されるため、現在のNotebookは次のように表示します。

```text
USING_SYNTHETIC_DATA = True
RETURN_TYPE = excess_return
PAPER_REPLICATION_READY = True
```

これは危険です。文献再現に必要なのは、単に `excess_return` 列があることではなく、実データ、対象ユニバース、実際のファクターエクスポージャー、テーマバスケット、release date が揃っていることです。

文献ではGoldman Sachsテーマバスケットを用いて、release前後60カレンダー日のAPWC z-scoreを計算しています。z-score 2以上を有意とし、pre-releaseで61/145、post-releaseで60/145のバスケットが有意だったと報告しています。`ssrn-5336504.pdf`

**修正方針:**

```python
PAPER_REPLICATION_READY = (
    not USING_SYNTHETIC_DATA
    and RETURN_TYPE == "excess_return"
    and required_real_tables_present
)
```

さらに、validation report には次の2つを分けて出してください。

```python
return_input_ready = RETURN_TYPE == "excess_return"
paper_replication_ready = not USING_SYNTHETIC_DATA and return_input_ready
```

---

### 3. `mosaic_bootstrap_apwc_paper_like` は良いが、まだ “paper-like” の範囲

現在の実装は、10日batch、stock group、tile別残差化を導入しており、前回版より大きく改善しています。ただし、文献の厳密な Mosaic + bootstrap とはまだ一致しません。

文献は、単純な残差bootstrapには、回帰が残差に人工的な相関を作る、残差分散を下げる、エクスポージャー $X$ が時変する、bootstrap後も残差とファクターエクスポージャーの直交性を保ちたい、という問題があると説明しています。`ssrn-5336504.pdf` そのため、単なる列シャッフルではなく、Mosaic + bootstrap による補正を使っています。

Notebookでは warning に「完全な Spector et al. 実装ではない」と明記している点は良いです。ただし、現在のbootstrapは `block_permute_columns_by_time(tile_resid, ...)` で、全window上の各銘柄列を独立にblock shuffleしています。これは「tile内でのlocal exchangeability」を厳密に実装したものではありません。

**修正方針:**

- 関数名の `paper_like` は維持してよい。
- 出力テーブルの `method` も `mosaic_bootstrap_paper_like` のままでよい。
- ただし、alignment table の Status は `Implemented` ではなく `Paper-like / not exact` にする。
- `warnings` に、現在の permutation が「column-wise block permutation」であり「exact Mosaic permutationではない」と明記する。
- 厳密実装でない限り、本文中で「文献準拠」ではなく「文献に近づけた実装」と表現する。

文献の基本bootstrapでは、シャッフル残差から synthetic return を作り、再回帰して $ u^{**} $ を得たうえで z-score を作る流れが説明されています。今回のpaper-like実装はこの再残差化を入れている点では改善されています。`ssrn-5336504.pdf`

---

### 4. release window の出力情報が不足

`compute_release_window_zscores` は pre/post のAPWCとz-scoreを返していますが、文献再現・検証用には情報が足りません。

現在出ている主な列:

```text
pre_apwc
pre_z_score
post_apwc
post_z_score
pre_is_coherent
post_is_coherent
warnings
```

不足している列:

```text
pre_null_mean
pre_null_std
post_null_mean
post_null_std
pre_n_bootstrap
post_n_bootstrap
pre_n_valid_dates
post_n_valid_dates
pre_n_valid_basket_tickers
post_n_valid_basket_tickers
```

これらがないと、z-scoreがNaNになった理由、bootstrapが十分に回っているか、basket構成銘柄がどれだけ有効だったかをレビューできません。

**修正方針:**

`mosaic_bootstrap_apwc_paper_like` の返却値を `compute_release_window_zscores` の行に展開してください。

---

### 5. z-scoreの解釈が危うい

合成データでは `bootstrap_reps_synthetic = 8` です。これは smoke test としては問題ありませんが、z-scoreの統計的解釈には不十分です。

特に `null_std` の推定が不安定になり、z-scoreが大きく振れます。文献のように z >= 2 を coherent theme 判定に使うなら、実データ検証では十分なbootstrap回数が必要です。

**修正方針:**

validation report に以下を追加してください。

```python
z_score_interpretation_ready = (
    not USING_SYNTHETIC_DATA
    and n_bootstrap >= 100
)
```

合成データでは `is_coherent` を計算してよいですが、表示上は `coherent_smoke_test_flag` のように区別した方が安全です。

---

### 6. tradable rolling の空データ耐性がない

`tradable_calendar` が空の場合、次の部分で落ちます。

```python
tradable_results = pd.DataFrame([...])
tradable_results["feature_max_date"] = tradable_results["past_end"]
```

テーマのrelease dateが遅い、データ期間が短い、future_windowが長い、といった実データでは普通に起きます。

**修正方針:**

```python
if tradable_calendar.empty:
    tradable_results = pd.DataFrame(columns=[...])
    tradable_rolling_timing_ok = True
else:
    ...
```

同様に、`risk_table`、`persistence_table`、`simplified_demo` も空データに耐えるようにしてください。

---

### 7. `latest_constituents(..., release_date, public_only=False)` が実データで壊れ得る

`compute_release_window_zscores` では、release date時点の構成銘柄を次のように取っています。

```python
basket = latest_constituents(constituents, theme_id, release_date, public_only=False)
```

ただし、実データで `as_of_date` が release date より後のスナップショットしかない場合、この関数は空を返します。文献再現では「release時点の構成」または「文献が使ったbasket構成」を使う必要がありますが、現実のデータベンダー形式では `as_of_date` が後日になっていることがあります。

**修正方針:**

- `constituent_snapshot_policy` を追加する。
  - `"asof_release"`: release date 以下の最新構成を使う。
  - `"first_available"`: release date 以降の最初の構成を使う。
  - `"latest_available"`: 最新構成を使う。ただし文献再現ではなく感応度分析扱い。
- validation report に policy を出す。
- `paper_replication_ready` は `"asof_release"` が可能な場合だけ True にする。

---

### 8. risk / persistence は global residual、APWCは tile residual になっている

現在、APWC z-score は `mosaic_bootstrap_apwc_paper_like` の tile residual から計算しています。一方で、basket residual return や risk comparison は、Notebook前半で作った `residuals_wide`、つまり全ユニバース一括回帰の残差を使っています。

これは必ずしも誤りではありません。文献でも、統計検定のためのMosaic処理と、経済的な残差リターン分析は概念的に分けられます。ただし、Notebook上では残差ソースが混在しているため、レビュー時に混乱します。

**修正方針:**

出力に次を追加してください。

```python
apwc_residual_source = "tile_residuals_paper_like"
return_residual_source = "global_cross_sectional_residuals"
risk_residual_source = "global_cross_sectional_residuals"
```

また、文献対応表にもこの違いを明記してください。

文献は、coherent themeではリスクモデルが残差共分散の非対角成分を無視するため、リスクを過小評価し、さらにz>=2群では残差リターンのトレンドが有意だったと報告しています。`ssrn-5336504.pdf`

---

## 中程度の修正点

### 9. `block_bootstrap_apwc_simplified` は再残差化していない

前回指示では、既存の簡易版を名称変更する意図でした。今回の `block_bootstrap_apwc_simplified` は、残差をblock shuffleしてAPWCを再計算するだけで、synthetic returnを作って再回帰していません。

ただし、この関数は「demo用」「not for paper replication」と明記されており、本計算には使っていないので、重大ではありません。

**修正方針:**

docstringにさらに一文追加してください。

```text
This simplified demo does not reconstruct synthetic returns or re-residualize.
```

---

### 10. `random_basket_calibration` が fragile

次の行は、`release_window_results` が空の場合に落ちます。

```python
reference_release = release_window_results.iloc[-1]
```

また、`exclude_tickers` を使った後にeligible銘柄が足りない場合、ランダムバスケットのサイズが意図より小さくなります。

**修正方針:**

- `release_window_results.empty` をチェックする。
- `eligible_n` と `requested_basket_size` を summary に出す。
- `actual_basket_size < requested_basket_size` の場合は warning を出す。

文献では、ランダムバスケットのz-scoreが概ね0中心、だいたい -2 から 2 の範囲に収まることを負例確認として使っています。このvalidationは有用なので、堅牢化した方がよいです。

---

### 11. real data 用の計算量見積もりがない

実データでは、テーマ数、ユニバース銘柄数、ファクター数、bootstrap回数が増えます。現在の実装は、実データ投入時に非常に重くなる可能性があります。

**修正方針:**

Notebook冒頭またはvalidation reportに以下を追加してください。

```python
estimated_regression_count
estimated_bootstrap_residualizations
estimated_runtime_mode
```

さらに、実データ時は最初に `dry_run=True` で計算量だけ出せるとよいです。

---

## 軽微な修正点

- `alignment_table` の `Mosaic + bootstrap tiling` は `Implemented` ではなく `Paper-like` のままにしてください。現在の表では Status が `Paper-like` になっており、この点は良いです。
- `PAPER_REPLICATION_REASON` は return construction だけでなく、synthetic / real data の状態も含めた理由にしてください。
- `max_abs_factor_residual_inner_product` は used factors についての検査なので、列名を `max_abs_used_factor_residual_inner_product` にすると正確です。
- `fit_residual_wide_from_returns_wide` のメイン呼び出しでは `min_stocks_per_factor_multiplier` を明示した方がよいです。
- `PROJECT_ROOT = Path.cwd()` は、Notebook起動ディレクトリに依存します。必要ならNotebookファイル位置基準にするか、`DATA_RAW` を設定セルで明示してください。

---

## Codexに渡す追加修正指示

以下をそのまま渡せます。

```text
追加レビュー結果に基づき、Notebookを修正してください。

最優先:
1. デフォルト設定の合成データモードで `jupyter nbconvert --execute` が完走するようにする。
   - synthetic smoke test の bootstrap reps を軽くする。
   - `runtime_mode = "smoke_test"` を追加する。
   - heavy research run 用のrep数は別設定に分離する。
   - 実行済みNotebookを作成できる状態にする。

2. `PAPER_REPLICATION_READY` の定義を修正する。
   - 合成データモードでは必ず False にする。
   - `return_input_ready` と `paper_replication_ready` を分ける。
   - 理由に synthetic / real data の状態を含める。

3. `compute_release_window_zscores` の出力に以下を追加する。
   - pre_null_mean, pre_null_std, post_null_mean, post_null_std
   - pre_n_bootstrap, post_n_bootstrap
   - pre_n_valid_dates, post_n_valid_dates
   - pre_n_valid_basket_tickers, post_n_valid_basket_tickers

4. `mosaic_bootstrap_apwc_paper_like` のwarningを強化する。
   - 現在のpermutationはcolumn-wise block permutationであり、exact Mosaic permutationではないと明記する。
   - Statusは `Paper-like / not exact` とする。

5. tradable_calendar / tradable_results / risk_table / persistence_table / random_basket_calibration が空でもNotebookが落ちないようにする。

6. `latest_constituents` に constituent snapshot policy を追加する。
   - asof_release
   - first_available
   - latest_available
   - validation reportにpolicyを表示する。

7. APWC、return、riskで使っている残差ソースを明示する。
   - apwc_residual_source
   - return_residual_source
   - risk_residual_source

8. `random_basket_calibration` を堅牢化する。
   - release_window_results が空の場合に落ちない。
   - eligible_n, requested_basket_size, actual_basket_size を出す。
   - eligible銘柄不足時にwarningを出す。

9. 実データ投入時の計算量を見積もる dry_run summary を追加する。
   - estimated_regression_count
   - estimated_bootstrap_residualizations
   - estimated_runtime_mode

完了条件:
- 合成データモードでNotebookが最後まで実行できる。
- 実行済みNotebookを生成できる。
- validation_reportで `using_synthetic_data=True` の場合、`paper_replication_ready=False` になる。
- release window tableでbootstrap診断列が確認できる。
- exact Mosaicではなくpaper-likeであることが明示されている。
```

---

## 結論

今回のNotebookは、**設計面では前回より大きく前進**しています。特に、分析モードの分離、excess return対応、rank check、APWCテスト、paper-like Mosaic、release前後60カレンダー日、validation report の追加は良いです。

ただし、現時点では **「レビュー用プロトタイプ」から「検証済み実装」にはまだ届いていません**。次の作業は、理論面の追加よりも、**完走性・診断出力・paper_replication_ready判定・計算量制御**を固めることです。

## Response:
2026/5/21 0:37:31

Notebookの設定・スキーマ・回帰ロジックを確認し、GEMLTLを実際に投入できる仕様かを見ます。あわせて、論文のGEM3前提との差分も分けて整理します。

## Response:
2026/5/21 0:37:45

確認した範囲では、GEMLTLのエクスポージャーを前処理済みのロング形式で渡せば動く受け皿はあります。ただし、ネイティブな商用モデル出力をそのまま完全活用する仕様ではありません。

## Response:
2026/5/21 0:43:40

## 結論

現状Notebookは、**Barra GEMLTLのエクスポージャーを「ファクター行列 $X$」として使う仕様にはなっています**。ただし、**Barra GEMLTLのリスクモデルそのものを完全に使う仕様にはなっていません**。

つまり、次の区別が重要です。

```text
できる:
  GEMLTL exposure を date × ticker × factor の外生ファクターとして読み込み、
  日次クロスセクション回帰で residual を作り、APWC / z-score を計算する。

まだできない:
  GEMLTLの公式factor covariance、specific risk、推奨制約、推定ウェイト、
  モデルID・バージョン・as-of管理まで含めた「GEMLTLリスクモデル予測」を使う。
```

したがって、現在の実装は **“GEMLTL exposure-based residual analysis” としては可**、**“full Barra GEMLTL risk model replication” としては不可** です。

---

## 1. Notebook側のGEMLTL対応状況

Notebookでは、実データ入力として次のテーブル名を想定しています。

```text
data/raw/barra_gemltl_exposures.parquet
または
data/raw/barra_gemltl_exposures.csv
```

必須スキーマは以下です。

```text
date
ticker
factor
exposure
```

この設計は、GEMLTLのファクター数やファクター名をハードコードせず、`factor` 列に入っている任意のファクターをピボットして使う形です。そのため、GEMLTLの style factor、industry factor、country factor、currency factor などをすべて同じ形式に正規化できれば、実装上は読み込めます。

また、Notebook内では `factor_names = sorted(exposures["factor"].unique())` のようにファクター名を動的に取得し、日次クロスセクションOLSで

```text
model_return = intercept + exposures × factor_returns + residual
```

を推定しています。これは、文献の $ r = Xb + u $ という基本構造には沿っています。文献も、伝統的リスクモデルで説明されない残差相関をテーマ性として扱っています。`ssrn-5336504.pdf`

---

## 2. GEMLTLを使うために最低限必要なデータ

GEMLTLを実データで使うには、少なくとも以下が必要です。

```text
theme_constituents
  as_of_date
  theme_id
  theme_name
  release_date
  ticker
  weight

stock_excess_returns
  date
  ticker
  excess_return

barra_gemltl_exposures
  date
  ticker
  factor
  exposure

universe
  date
  ticker
  in_universe
```

この4表が揃えば、現状NotebookはGEMLTL exposureを使って残差を推定できます。

ただし、GEMLTLの生データがMSCI/Barraの標準配信形式のままなら、Notebookへ直接投入できるとは限りません。現在のNotebookは、SQL配信やベンダー固有ID体系を直接読む仕様ではなく、**CSVまたはParquetに正規化済みの long-format exposure table** を前提にしています。公開情報上、Barra/MSCIモデルはSQLなどで提供される場合があるため、実運用ではETLが必要です。([LSEG](https://www.lseg.com/en/data-analytics/financial-data/company-data/quantitative-models/msci-barra-models))

---

## 3. 現状仕様でGEMLTLを使う場合の注意点

### 3.1 ファクター名は柔軟だが、factor type がない

GEMLTLでは、style、industry、country、currency など複数種類のファクターがあり得ます。現状Notebookはすべてを単なる `factor` として扱います。

これは計算上は動きますが、次の問題があります。

```text
style factor と industry factor の区別がない
country / currency factor の定数性チェックが雑になる
industry dummy / multi-industry exposure の制約処理が明示されない
どのファクターが落とされたかは diagnostics で見るしかない
```

本番仕様では、次のような列を追加した方がよいです。

```text
model_name
model_version
factor_type       # style / industry / country / currency / market など
factor
exposure
exposure_date
as_of_date または effective_date
```

### 3.2 rank check はあるが、Barraの制約体系ではない

現状Notebookは、interceptと完全共線なファクターや、日次断面で定数になっているファクターを落とします。これはGEMLTLを使う上で必要な防御です。

ただし、これは**数値的なrank修復**であって、Barraの公式な制約体系ではありません。

GEMLTLでは、country / industry exposure が複数ファクターにまたがる可能性があり、countryやindustry exposureの合計がinterceptと共線的になることがあります。現状コードはその場合に列をヒューリスティックに落としますが、どの業種・国ファクターを落とすかが経済的に一貫しているとは限りません。

本番では、例えば以下のどちらかを明示すべきです。

```text
A. interceptを落として、Barra exposure群をそのまま使う
B. interceptを残し、country / industryの基準ファクターを明示的に1つ落とす
C. sum-to-zero制約を明示的に入れる
```

### 3.3 日本株だけでGEMLTLを使う場合、global factorの一部は退化する

Notebookの冒頭は「日本株テーマバスケット + Barra GEMLTL形式」を想定しています。日本株だけの断面でGEMLTLを使う場合、Japan country factor、JPY currency factor、market-like factor などは定数またはほぼ定数になり得ます。

そのため、現状コードではそれらが rank check で落とされます。これは数値的には妥当ですが、結果として「GEMLTL global model全体を使った残差」というより、**日本株断面で識別可能なGEMLTL exposureだけを使った残差**になります。

この点はvalidation reportに明示した方がよいです。

```text
risk_model_name = "Barra GEMLTL"
risk_model_scope = "Japan-only cross-sectional residualization"
n_factors_input
n_factors_used_median
n_factors_dropped_median
dropped_factor_examples
```

### 3.4 Mosaic grouping がGEMLTLのファクター数で重くなる

Notebookの `make_mosaic_tiles` は、文献に合わせて「1グループあたり少なくとも 5 × ファクター数」の銘柄数を要求しています。

論文ではGEM3の34業種ダミー + 11スタイル、つまり45ファクター程度なので、平均約1,100銘柄の米国大型株ユニバースでは成立しやすい設計です。`ssrn-5336504.pdf`

一方、GEMLTLはファクター構造がGEM3と異なります。公開資料では、GEM LTは2015年に導入されたLong Term Investors向けモデルで、16個のstyle factorを41 descriptorから構成し、quality factor群、multi-industry exposure、dynamic country / industry exposureを含むと説明されています。([MSCI](https://www.msci.com/downloads/documents/indexes/consultations/equity/1ac786c2-430b-4f10-87e4-2a6b94e8cf49.pdf))

そのため、GEMLTLの全ファクターを入れると、`5 × p` の必要銘柄数が増えます。日本株だけ、あるいは小さいテーマ分析ユニバースだけで回すと、Mosaic tileが粗くなり、warningが多発する可能性があります。

ここは修正した方がよいです。`p = len(factor_names) + 1` ではなく、実際に各batchで使われる full-rank factor 数から `p_effective` を計算する設計が望ましいです。

---

## 4. 論文で使われたモデルとの相違点

論文はGEMLTLではなく、**Barra GEM3**を使っています。具体的には、米国大型流動株の日次excess returnに対して、Barra GEM3のindustry factorとstyle factorを用いた日次クロスセクションOLSを実行しています。論文脚注では、GEM3には34個のindustry dummyと11個のstyle variableが含まれると説明されています。`ssrn-5336504.pdf`

GEMLTLを使う場合、主な相違点は以下です。

| 論点 | 論文 | GEMLTL使用時 |
|---|---|---|
| リスクモデル | Barra GEM3 | Barra GEMLTL / GEM LT |
| 対象ユニバース | 米国大型流動株、平均約1,100銘柄 | Notebookでは任意。日本株なら論文と異なる |
| industry exposure | GEM3の34 industry dummy | GEM LTはmulti-industry exposureを持つ可能性 |
| style factor | 11 style variables | GEM LTは16 style factors / 41 descriptorsとされる |
| country / industry exposure | GEM3仕様 | GEM LTはcountry / industry exposureを動的調整 |
| モデルホライズン | GEM3を使った日次残差分析 | GEM LTはLong-Term Investors向けモデル |
| 数値再現性 | 論文のz-scoreと比較可能 | 直接比較不可。モデルロバストネス検証扱い |
| リスク予測 | GEM3/BFREで頑健性を確認 | GEMLTLでの頑健性は論文では未報告 |

GEM LTはLong-Term Investors向けのモデルであり、公開情報では、Long-term modelsはportfolio construction / reportingに焦点を置き、Trading modelsはshort-term trading、hedging、daily risk monitoring向けと説明されています。([LSEG](https://www.lseg.com/en/data-analytics/financial-data/company-data/quantitative-models/msci-barra-models)) したがって、論文のように60カレンダー日前後の短期的なテーマ残差相関を調べる場合、GEMLTLを使うこと自体は可能ですが、**短期イベントの残差検出感度はGEM3やTrading系モデルとは変わり得ます**。

---

## 5. GEMLTLを使った場合、APWC結果はどう変わり得るか

論文のAPWCは、リスクモデル残差の相関行列から上三角の平均を取る統計量です。`ssrn-5336504.pdf` したがって、どのリスクモデルで残差を作るかによってAPWCは変わります。

GEMLTLを使うと、次のような変化が起き得ます。

### 5.1 テーマ相関が小さく見える場合

GEMLTLがGEM3より細かいquality、earnings yield、residual volatility、multi-industry exposureなどを持っている場合、従来なら残差に残っていた共通変動がファクター側で吸収される可能性があります。

この場合、

```text
observed APWC が低下する
z-score が低下する
coherent theme と判定されるテーマ数が減る
```

可能性があります。

### 5.2 逆にテーマ相関が大きく見える場合

GEMLTLのLong-Term向けファクター構造が短期イベントへの追随を抑える場合、短期的なイベントショックは残差に残りやすくなります。この場合、

```text
短期テーマショックが residual に残る
APWC が上がる
post-release 60日のcoherent判定が増える
```

可能性があります。

どちらになるかは、対象市場、テーマ、ユニバース、GEMLTL exposureの構造に依存します。

---

## 6. 論文との一番大きな差分: 「GEMLTL使用」は再現ではなく拡張

GEMLTLを使う場合、これは論文の数値再現ではありません。位置づけは次のようにすべきです。

```text
paper_replication:
  false

methodology_replication:
  true

risk_model_used:
  Barra GEMLTL

interpretation:
  論文の方法論をGEMLTL exposureに適用したロバストネス検証または日本株応用
```

論文はGEM3で分析し、別モデルとしてBlackRock Fundamental Equity Risk modelでも結論が大きく変わらないことを示していますが、GEMLTLでの検証は報告していません。`ssrn-5336504.pdf`

したがって、GEMLTLで得たz-scoreやcoherent theme数を、論文のExhibit 7の値と直接比較するのは不適切です。論文のExhibit 7は、Goldman Sachsテーマバスケットについて、release前後60カレンダー日のz-scoreをMosaic + bootstrapで計算したものです。`ssrn-5336504.pdf`

---

## 7. 現状Notebookに追加すべきGEMLTL用チェック

GEMLTL投入を本番仕様にするなら、以下を追加してください。

```text
1. risk_model_name / model_version / horizon の明示
   例: Barra GEMLTL, long-term, model_version=...

2. factor_type列の追加
   style / industry / country / currency / market などを識別する。

3. stable asset_idの導入
   tickerではなく、Barra ID, SEDOL, ISIN等の安定IDを使う。

4. exposureのpoint-in-time検証
   return dateに対して未来のexposureを使っていないことを検査する。

5. full-rank設計の明示制約
   interceptを使うか、どのcountry/industry factorを落とすかを固定する。

6. p_effectiveベースのMosaic grouping
   入力factor数ではなく、実際に識別可能なfactor数で5p条件を判定する。

7. GEMLTL specific risk / factor covarianceの任意入力
   APWCには不要だが、リスク過小評価をGEMLTL risk forecastとして検証するには必要。

8. validation_reportへの追加
   n_factors_input
   n_factors_used_median
   n_factors_dropped_median
   constant_factor_count
   rank_deficient_dates
   factor_covariance_available
   specific_risk_available
   paper_numeric_replication_ready = False if model != GEM3
```

特に、現在の `residual_risk_comparison` は `sample_diag` を使っており、GEMLTLの公式specific riskを使っていません。論文のリスク議論は $ V = XFX' + \Delta $ というリスクモデル構造を前提にしているため、GEMLTLのリスク予測として検証したいなら、factor covariance $F$ とspecific variance $\Delta$ の入力が必要です。`ssrn-5336504.pdf`

---

## 最終判定

**GEMLTL exposureを使った残差相関分析には対応しています。**

ただし、現在の実装は以下の位置づけです。

```text
Barra GEMLTL-ready:
  条件付きで Yes

Full Barra GEMLTL risk model-ready:
  No

論文GEM3数値再現:
  No

論文方法論をGEMLTLへ適用する拡張実装:
  Yes, ただしfactor制約・point-in-time・specific risk周りの補強が必要
```

最も重要な修正は、**GEMLTLのfactor universeをそのまま入れたときのrank処理とMosaic groupingの安定化**です。ここを補強すれば、GEMLTLを使った日本株テーマ分析としては十分に実務検証へ進められます。

## Response:
2026/5/21 22:02:29

論文ベースの戦略案と実務実装しやすい派生案に分け、APWC、テーマ性、残差リターン予測、リスク過小評価の観点で整理します。

## Response:
2026/5/21 22:02:35

> **Strategies for residual returns**
>
> ユーザーが残差リターンを活用する戦略を尋ねています。まずは、税onomies（分類）を議論し、投資アドバイスではないことも触れましょう。残差モメンタムやリスク対応戦略、「ペア・トリプル」、「セクター・フォクス・因子ニュートラル」といった他の戦略も挙げます。残差リターンは予測に基づくものなので、実行可能性や制約に注意が必要です。
>
> 思考時間: 2m 51s

## Response:
2026/5/21 22:05:21

残差リターン $u_{i,t}=r_{i,t}-X_{i,t}b_t$ を使う戦略は、大きく分けると **「ファクター中立化したリターン予測」** と **「リスクモデルが見落とす残差相関の利用」** です。今回の論文に最も近いのは、後者の **coherent theme momentum** です。

## 1. Coherent theme residual momentum

これは論文の中心的な戦略候補です。

手順は次のようになります。

```text
1. 各銘柄の日次リターンをリスクモデルで残差化する。
2. テーマバスケット内の残差リターン相関を計算する。
3. APWC z-score >= 2 のバスケットを coherent theme とみなす。
4. そのバスケットの過去60日累積残差リターンを見る。
5. 過去残差リターンが正ならロング、負ならショート、または既存ポジションを調整する。
6. 20〜60営業日程度でリバランスする。
```

論文では、z-score 2以上を統計的に有意な平均ペアワイズ残差相関として扱い、145テーマ中、リリース前60カレンダー日で61本、リリース後60カレンダー日で60本が有意だったと報告しています。さらに、pre/post z-score の相関は49%で、リリース後にも相関がある程度持続すると述べています。`ssrn-5336504.pdf`

この戦略の直感は、**「個別銘柄の残差リターンが同時に動いているテーマでは、投資家の注意・フロー・ナラティブが一時的なトレンドを作りやすい」** というものです。論文でも、APWC z-score が有意なバスケットでは、過去残差リターンから将来残差リターンへの回帰係数が有意で、z>=2群の係数は0.126、t値は2.11です。一方、z<2群では係数0.028、t値0.47で有意ではありません。`ssrn-5336504.pdf`

実装するなら、シグナルは例えば以下です。

```text
theme_signal_j,t
  = 1{APWC_z_j,t >= 2}
    × sign(past_60d_residual_return_j,t)
    × f(|past_60d_residual_return_j,t|)
```

ポートフォリオは、テーマ内の等ウェイト、流動性ウェイト、または broker basket weight を使います。よりクオンツ的には、テーマバスケットの残差リスクでスケーリングします。

---

## 2. Coherent theme long-only tilt

ロングオンリー運用なら、ショートを使わずに **既存ポートフォリオのテーマ・ティルト** として使えます。

```text
APWC z-score >= 2
かつ
過去残差リターン > 0
なら、そのテーマ構成銘柄をオーバーウェイト
```

逆に、

```text
APWC z-score >= 2
かつ
過去残差リターン < 0
なら、そのテーマ構成銘柄をアンダーウェイト
```

この形は、ファクター、業種、市場ベータをコントロールした後のテーマ固有の動きだけを見るため、通常のテーマETFやテーマバスケットへの単純投資より洗練されています。

論文でも、単にすべてのテーマバスケットに投資する戦略は支持されません。テーマバスケットの平均残差リターンは負だが統計的には有意でなく、「すべてのテーマに投資する」のではなく、より選別的である必要があると述べています。`ssrn-5336504.pdf`

---

## 3. Theme risk-overlay strategy

これはリターン獲得ではなく、**リスク管理・ポジションサイズ調整**としての戦略です。

リスクモデルは通常、個別銘柄の残差リターンが互いに無相関だと仮定します。しかし、coherent theme では残差間に一時的な相関が生じるため、通常のリスクモデルはテーマバスケットの残差リスクを過小評価します。論文は、平均ペアワイズ相関が0.06になると、50銘柄等ウェイトバスケットでは予測残差リスク3.5%に対して実際は7.0%となり、約2倍の過小評価になる例を示しています。`ssrn-5336504.pdf`

戦略としては次のようになります。

```text
APWC z-score が高いテーマへの総エクスポージャーを測る
→ 残差相関を加味してリスクを再計算する
→ ポジションサイズ、VaR、TE、gross/net exposure を調整する
```

これはアルファ戦略というより、**hidden crowding / hidden thematic beta の検出**です。特にマルチマネージャー、ロングショート、マーケットニュートラルでは重要です。

---

## 4. Residual reversal / statistical arbitrage

これは伝統的な残差リターン戦略です。

手順は次の通りです。

```text
1. 各銘柄のリターンをリスクモデルで残差化する。
2. 短期の残差リターン z-score を計算する。
3. 残差が大きく上がった銘柄をショート。
4. 残差が大きく下がった銘柄をロング。
5. ファクター、業種、ベータ、市場を中立化する。
```

典型的には、1日〜20日程度の短期で使います。

```text
signal_i,t = - zscore(residual_return_i,t-k:t)
```

これは **「ファクターでは説明されない一時的なミスプライシングは平均回帰する」** という考えです。テーマ戦略とは逆で、テーマ的な coherent residual correlation が強い局面では mean reversion が効きにくくなる可能性があります。したがって、APWC z-score が高い銘柄群では reversal を弱める、または除外する、という応用が考えられます。

---

## 5. Residual momentum at stock level

残差リターンを個別銘柄ごとに累積し、通常のモメンタムからファクター成分を取り除いたものです。

```text
signal_i,t = cumulative residual return over past 3M / 6M / 12M
```

通常の価格モメンタムは、市場、業種、サイズ、バリュー、クオリティなどの影響を含みます。一方、residual momentum はそれらを除いた、より純粋な銘柄固有モメンタムです。

運用上は以下の制約を入れるのが自然です。

```text
market beta neutral
sector neutral
style factor neutral
liquidity filter
turnover control
idiosyncratic volatility scaling
```

論文のテーマ戦略は、これを個別銘柄ではなく **テーマバスケット単位** に拡張したものと見なせます。ただし論文の新規性は、単なる残差モメンタムではなく、APWC z-score という二次統計量で「どのバスケットの残差モメンタムが効きやすいか」を識別する点です。論文も、二次統計量である相関が一次統計量であるリターンを予測し得ると述べています。`ssrn-5336504.pdf`

---

## 6. Residual pair trading / cluster relative value

ペアトレードを、価格やリターンではなく残差で行う戦略です。

```text
1. リスクモデルで各銘柄を残差化する。
2. 残差リターン、または残差価格系列の相関が高いペアを選ぶ。
3. ペアの残差スプレッドを作る。
4. スプレッドが拡大したら、割安側ロング・割高側ショート。
5. スプレッドが平均回帰したらクローズ。
```

テーマバスケットに拡張すると、ペアではなく **residual cluster trade** になります。

```text
同じ residual correlation cluster 内で、
過去残差リターンが相対的に低い銘柄をロング、
高い銘柄をショート。
```

これは、テーマ全体の方向性を取るというより、テーマ内の相対価値を取る戦略です。

例:

```text
AIテーマ内で、全体テーマはニュートラル。
その中で残差的に出遅れている銘柄をロングし、
過熱している銘柄をショートする。
```

---

## 7. Emerging theme discovery strategy

これは論文が将来研究として示唆している方向です。

ブローカーや外部テーマバスケットに頼らず、残差相関からテーマを発見します。

```text
1. 全銘柄の残差リターン相関行列をローリングで計算。
2. 残差相関が急上昇した銘柄群を検出。
3. グラフクラスタリング、community detection、spectral clustering などで銘柄群を形成。
4. そのクラスターのAPWC z-scoreを計算。
5. クラスター名は後からニュース、業種、アナリストレポート、LLMで解釈する。
6. APWCが有意で、過去残差リターンが正ならロング候補。
```

論文は、既存のGoldman Sachsテーマバスケットを出発点にした ex post 分析ですが、将来研究として、観測された残差相関から新しい coherent theme を発見できるかを検討すると述べています。`ssrn-5336504.pdf`

これは実務的にはかなり魅力があります。なぜなら、ブローカーのテーマ公開を待たずに、**市場内部の残差共動からテーマの発生を先に検出できる可能性**があるからです。

---

## 8. Residual dispersion strategy

これはテーマ内の残差相関や残差ボラティリティを使った分散・相関戦略です。

基本発想は次です。

```text
APWCが上昇しているテーマ:
  銘柄間の独立性が低下している。
  個別銘柄分散効果が効きにくい。
  テーマ全体の一方向リスクが増える。

APWCが低下しているテーマ:
  個別銘柄固有要因が支配的。
  テーマバスケットより銘柄選択が重要。
```

現物ロングショートであれば、

```text
高APWCテーマ:
  basket-level directional trade または risk reduction

低APWCテーマ:
  stock selection / relative value
```

オプション市場が使えるなら、single-name vol と basket/index vol の関係を見る dispersion trade に近い発想も可能です。ただし、これは残差リターンそのものというより、残差相関を用いたボラティリティ・相関戦略です。

---

## 9. Residual risk-adjusted alpha strategy

通常のアルファを、残差リスクで正規化して使う戦略です。

```text
score_i,t = expected_residual_return_i,t / idiosyncratic_risk_i,t
```

またはテーマ単位で、

```text
theme_score_j,t
  = expected_residual_return_j,t / corrected_residual_risk_j,t
```

ここで重要なのは、coherent theme では通常の idiosyncratic risk だけではリスクが過小評価されることです。そのため、APWCを反映した corrected residual risk を使います。

等ウェイトバスケットで単純化すると、

```text
corrected_residual_risk
  ≈ average_idio_vol × sqrt((1 + ρ̄ × (N - 1)) / N)
```

この考え方は、論文の Exhibit 8 のリスク過小評価の議論と整合的です。`ssrn-5336504.pdf`

---

## 10. Practical integrated strategy

実務で最も自然なのは、以下の統合型です。

```text
Universe:
  公開済みテーマバスケット、または自前で検出した residual correlation cluster

Step 1: 残差化
  Barra GEMLTL/GEM3等で日次リターンを残差化

Step 2: coherent 判定
  過去60日で APWC z-score を計算
  z >= 2 を coherent theme とする

Step 3: 方向判定
  過去60日 basket residual return が正なら long
  負なら short / underweight

Step 4: リスク調整
  APWCを使って residual risk を補正
  risk parity または volatility target

Step 5: ポートフォリオ構築
  factor neutral
  sector neutral
  liquidity-aware
  turnover constraint
  single-name cap
  theme concentration cap

Step 6: Exit
  APWC z-score が2未満に低下
  residual momentum が反転
  holding period 上限
  drawdown stop
```

数式で書くと、テーマ $j$ のスコアは例えば以下です。

```text
S_j,t
= 1{z_APWC,j,t >= 2}
  × sign(R^resid_j,t-60:t)
  × |R^resid_j,t-60:t| / σ^corrected_j,t
```

さらに保守的にするなら、

```text
S_j,t
= max(z_APWC,j,t - 2, 0)
  × R^resid_j,t-60:t / σ^corrected_j,t
```

とすれば、APWCの有意度が高いテーマほど強く賭ける形になります。

---

## 私なら優先して検証する順番

第一候補は、**coherent theme residual momentum** です。論文の実証に最も近く、APWC z-score と将来残差リターンの関係が明示されています。`ssrn-5336504.pdf`

第二候補は、**theme risk-overlay** です。これはアルファが出なくても有用です。coherent theme では通常のリスクモデルが残差リスクを過小評価するため、リスク管理上の価値があります。`ssrn-5336504.pdf`

第三候補は、**emerging theme discovery** です。これは論文の外部テーマバスケット依存を超える拡張で、実務上の差別化余地が大きいです。ただし、クラスタリング、テーマ命名、イベント説明、過剰探索バイアスの管理が必要です。

結論として、残差リターン戦略の中で今回の文脈に最も合うのは、**「APWCでcoherent themeを選別し、そのテーマの過去残差リターン方向に賭ける、リスク補正済みテーマ・モメンタム戦略」**です。

## Response:
2026/5/21 23:44:37

前回Notebookに接続しやすい形にするため、既存の関数名・データ構造を確認し、残差wide入力専用の戦略モジュールとして実装します。

## Response:
2026/5/21 23:44:56

APWCの厳密な推定は前段Notebookの出力を受け取り、未入力時は残差wideだけで動くフォールバックを用意します。出力は日付×銘柄のweight wideと診断テーブルに統一します。

## Response:
2026/5/21 23:49:45

> **実装戦略とAPWCスコア計算**
>
> `coherent_theme_residual_momentum`戦略では、テーマの重みを計算し、日付ごとのAPWCスコアを適用します。`_lookup_apwc_score`関数を作成し、指定された日付で適切なスコアを取得する必要があります。APWCスコアがない場合は、`apwc_min`を代わりに使用できるようにします。この戦略は、テーマごとのモメンタム分析に使用されます。
>
> **テーマ別モメンタムとリスクオーバーレイ戦略**
>
> まず、テーマごとに信号を計算し、スコアに基づいて株式のウェイトを設定します。その後、テーマのスコアをティッカーのウェイトに変換し、正規化します。次に、`long_only_theme_tilt`戦略でポジティブなシグナルだけを使用して、オーバーレイを再正規化しましょう。最後に、`theme_risk_overlay`関数でリスク診断を行い、適切にウェイトを調整します。
>
> **戦略の整理と検討**
>
> まず、クラスタごとの相関グラフを使用して、テーマごとのシグナルを作成します。次に、"emerging theme discovery strategy"で、指定された基準に基づきクラスタ内でウェイトを計算します。また、APWCが高い場合にはディレクショナルモメンタムを、低い場合には相対的価値を使用してアプローチします。それから、リスク調整後のアルファの計算も組み込みます。
>
> **モジュールの設計とテスト**
>
> 大きなループを避けるために関数を使ってみるのが良いかもしれません。合成データでテストし、エクスポート用の`.py`ファイルも作成するべきかも。ユーザーから直接見えないPythonコードを使ってコンテナ内で生成し、最終的なリンクを提供する形にします。そして、静的に型ヒントを用いて慎重にモジュールを作成し、スモークテストを通します。
>
> **Evaluating sentiment trends in product reviews**
>
>
> **データクラスのインポートエラーとテスト**
>
> sys.modulesでモジュールがロードされていないため、データクラスのインポートエラーが発生しているようですね。実際の構文の問題ではなく、sys.pathを経由してインポートする必要がありそうです。スモークテストを実行し、`import warnings`が未使用でも問題ないことを確認します。PYTHONPATHも使用してテストします。
>
> **Testing module import via PYTHONPATH**
>
>
> **スモークテストと合成データの使用**
>
> 全ての戦略についてスモークテストを実行する必要がありますね。合成残差データやテーマ構成要素、APWCスコアを作成して、このモジュールでテストします。そのテストがうまくいくか確認して、必要な調整ができるか見ていきます。
>
> **煙テストおよび戦略の評価**
>
>
> **戦略の調整とドルニュートラルの考慮**
>
> 一部はロングサイドのみだから0.5、ドルニュートラルのためサイン付き正規化ではショートがないとロンググロスが半分になる。テーマ信号が全てポジティブなら戦略がドルニュートラルでない。`dollar_neutral`パラメータを追加すべきか考えている。
>
> **戦略におけるドルニュートラル設定とコード整理**
>
> テーマ関数や統合的戦略で、`dollar_neutral`パラメータの追加が適切かもしれない。ロングテーマモメンタム戦略ではドルニュートラルでない方が良いかも。最終的にREADMEやコードサンプルを使って、モジュールや戦略の使用例をまとめましょう。
>
> **関数の順序とパッチ修正**
>
> `correlation_clusters`が`__all__`に含まれていないけど、ユーザーや新しい機能で使うかもしれないので追加するべきかもしれません。また、`basket_return_series`や`portfolio_residual_returns`も現状含まれていないので、追加するのが良いかもしれません。`dollar_neutral`の修正も必要だと思います。
>
> **パラメータ追加と戦略調整**
>
>
> **修正の確認**
>
> `dollar_neutral`が`stock_residual_momentum`に誤って追加されたかどうかを確認する必要があります。署名を調べるために`grep`で確認すべきかな。
>
> **パッチの確認とシグネチャ検索**
>
>
> **確認とテスト実行**
>
> `long_only`で置き換えた呼び出しにより、関数内の構文に問題がないか確認する必要があるかも。`coherent_theme`呼び出しに`dollar_neutral`が不足しているかも。動作確認のため、すぐにスモークテストを再実行したほうが良さそう。
>
> **実行戦略の煙テスト**
>
>
> **FutureWarningの修正**
>
> `DataFrame`オブジェクトの`fill`に関する`FutureWarning`が発生しているかも。致命的ではないけれど、改善できるかも。`theme_risk_overlay`の出力_weightsに関して、現状の記述を`pd.DataFrame(0.0, index=..., columns=...)`に置き換えた方が良いと思う。
>
> **修正未来警告のデータフレーム更新**
>
>
> **統合ドキュメントの追加**
>
> README.mdを作成して、使用方法を記載する必要がありそう。戦略マッピングについても簡潔に含めるべきかも。あまり多くの詳細を入れすぎない方が良さそうだけど、重要な部分は盛り込むようにして、ファイルを作らなきゃ。
>
> **Creating strategy documentation and usage guide**
>
>
> **ファイル整理と完全な実装ドキュメントの作成**
>
> ユーザーが `.py` ファイルを好むかもしれないので、コードを添付するかもしれません。zipファイルは必須ではないけど、リンクも考えた方が良さそう。最後に、研究用コードに関する説明、引用、インポート例、スモークテストの結果を含めるべきですね。
>
> 思考時間: 14m 15s

## Response:
2026/5/21 23:58:53

実装ファイルを作成しました。前回Notebookの `residuals_wide`、`theme_constituents`、`tradable_results` にそのまま接続して使える構成です。

- [実装モジュール: residual_return_strategies.py](sandbox:/mnt/data/residual_return_strategies.py)
- [使用例メモ: residual_strategy_usage.md](sandbox:/mnt/data/residual_strategy_usage.md)

合成データで主要関数の smoke test も実行し、各関数が weight vector と診断テーブルを返すことを確認しました。

## 実装した戦略

| 戦略 | 関数 |
|---|---|
| Coherent theme residual momentum | `coherent_theme_residual_momentum_weights` |
| Coherent theme long-only tilt | `coherent_theme_long_only_tilt_weights` |
| Theme risk overlay | `theme_risk_overlay_adjustment` |
| Stock-level residual reversal | `residual_reversal_weights` |
| Stock-level residual momentum | `residual_momentum_weights` |
| Residual pair trading | `residual_pair_trading_weights` |
| Residual cluster relative value | `residual_cluster_relative_value_weights` |
| Emerging theme discovery | `discover_residual_correlation_clusters`, `emerging_theme_discovery_weights` |
| Residual dispersion regime strategy | `residual_dispersion_regime_weights` |
| Residual risk-adjusted alpha | `residual_risk_adjusted_alpha_weights` |
| 統合型 residual strategy | `integrated_residual_strategy_weights` |

## 前回Notebookへの接続例

前回Notebookと同じディレクトリ、または `sys.path` に入る場所に `residual_return_strategies.py` を置いてください。

```python
from residual_return_strategies import *

analysis_date = tradable_results["analysis_date"].max()

w_theme, diag_theme = coherent_theme_residual_momentum_weights(
    residuals_wide=residuals_wide,
    theme_constituents=theme_constituents,
    analysis_date=analysis_date,
    theme_signal_table=tradable_results,
    lookback=60,
    z_threshold=2.0,
    gross_target=1.0,
)
```

`theme_signal_table` は前回Notebookの `tradable_results` を想定しています。最低限、以下の列があると coherent theme 判定に使えます。

```text
theme_id
analysis_date
z_score
is_coherent
```

## 返却値の基本形

多くの関数は次の形式です。

```python
weights, diagnostics = strategy_function(...)
```

`weights` は銘柄を index に持つ `pd.Series` です。

```python
strategy_weight_summary(w_theme)
```

で、gross、net、long gross、short gross、最大ウェイトなどを確認できます。

## 例: 残差リバーサル

```python
w_reversal, score_reversal = residual_reversal_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    lookback=20,
    quantile=0.20,
    gross_target=1.0,
)
```

これは過去20営業日の残差リターンが低い銘柄をロング、高い銘柄をショートする短期平均回帰戦略です。

## 例: 残差モメンタム

```python
w_momentum, score_momentum = residual_momentum_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    lookback=60,
    quantile=0.20,
    gross_target=1.0,
)
```

これは過去60営業日の残差リターンが高い銘柄をロング、低い銘柄をショートする銘柄別 residual momentum 戦略です。

## 例: テーマ・リスクオーバーレイ

```python
base_weights = pd.Series(1 / residuals_wide.shape[1], index=residuals_wide.columns)

w_overlay, diag_overlay = theme_risk_overlay_adjustment(
    residuals_wide=residuals_wide,
    base_weights=base_weights,
    theme_constituents=theme_constituents,
    analysis_date=analysis_date,
    theme_signal_table=tradable_results,
    max_risk_understatement_ratio=1.5,
)
```

これは coherent theme 内の残差相関によって、対角リスクモデルがリスクを過小評価している場合に、そのテーマ構成銘柄の既存ポジションを縮小するオーバーレイです。

## 例: 統合型戦略

```python
w_integrated, diag_integrated = integrated_residual_strategy_weights(
    residuals_wide=residuals_wide,
    analysis_date=analysis_date,
    theme_constituents=theme_constituents,
    theme_signal_table=tradable_results,
    leg_allocations={
        "theme_momentum": 0.35,
        "stock_momentum": 0.20,
        "stock_reversal": 0.20,
        "pair_reversion": 0.15,
        "cluster_relative_value": 0.10,
    },
    gross_target=1.0,
)
```

## 注意点

このモジュールは **残差リターン系列を受け取ってシグナル・ウェイトを作る部分**だけを実装しています。リスクモデルの再推定、GEMLTL exposure の処理、APWC z-score の Mosaic bootstrap 推定は前回Notebook側の役割です。

実運用・本格検証では、さらに以下を追加してください。

```text
transaction cost
turnover control
borrow / short availability
liquidity cap
single-name cap
sector / industry / factor exposure check
rebalance lag
out-of-sample backtest
```

今回の実装は、前回Notebookの出力を受けて「残差リターンをどう戦略化するか」を切り出した追加モジュールです。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)