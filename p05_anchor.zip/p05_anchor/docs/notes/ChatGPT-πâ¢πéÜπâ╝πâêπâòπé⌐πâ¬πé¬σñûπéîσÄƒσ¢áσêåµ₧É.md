# ポートフォリオ外れ原因分析

**User:** Anonymous (kencharoffx@gmail.com)  
**Created:** 2/25/2026 19:51:48  
**Updated:** 2/25/2026 20:27:19  
**Exported:** 2/25/2026 20:31:46  
**Link:** [https://chatgpt.com/c/699ed3cb-2430-83a5-b836-045f4a45116c](https://chatgpt.com/c/699ed3cb-2430-83a5-b836-045f4a45116c)  

## Prompt:
short-term momentum や dual momentum 戦略でポートフォリオに選ばれていた銘柄がどのようにポートフォリオから外れるのか特定したいです。混雑度の高まりや有効なファクターの減衰が原因と考えられるが、どのようにアンカーを作成すべきか調査が必要です。また、結果をどのように可視化すれば定性的にわかりやすいか調査したい

## Response:
思考時間: 28s

目的を「**(A) “外れ方”を機械的に特定（exit attribution）**」と「**(B) その原因仮説（混雑・ファクター減衰）を“アンカー指標”で可観測化**」の2段に分けるのが一番早いです。以下は、そのための設計図です（short-term momentum / dual momentum 両対応）。

* * *

1) まず“外れ方”を定義する（Exit taxonomy）
------------------------------

ポートフォリオから外れる理由を、**ロジック上のトリガー**に落として分類します。最低限これだけで「何が起きたか」が100%特定できます。

### Exit の代表パターン

1.  **Rank-out（相対モメンタム負け）**  
    同ユニバース内ランキングが閾値以下になり除外（top-kから外れる）。
2.  **Abs-filter fail（絶対モメンタム負け）**  
    リスクフリー/0%/MAなど、絶対条件を割ったのでキャッシュ/債券へ退避（dual momentumで典型）。[SSRN+1](https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID2495252_code1556771.pdf?abstractid=2244633&utm_source=chatgpt.com)
3.  **Risk/constraint-out（制約で押し出し）**  
    max weight、セクター上限、流動性、最小ロット、ターンオーバー制約で押し出される。
4.  **Tiebreak/Buffer の影響**  
    同点処理、リバランス頻度、\*\*バッファ（入替を抑えるルール）\*\*有無で“外れ”が増減。
5.  **Data/availability-out**  
    欠損・上場廃止・指数除外等（運用上の現実要因）。

**最重要：** ここまでをやると「外れた銘柄」を、必ず _ロジック由来の理由_ にタグ付けできます。原因分析（混雑/減衰）はその次です。

* * *

2) “原因仮説”のアンカーを作る（Crowding / Factor decay）
------------------------------------------

あなたの仮説（混雑度の高まり、有効ファクターの減衰）を**観測可能な指標群**にし、Exit と同じ時間軸で並べます。

### 2.1 Crowding（混雑）アンカー：3系統で持つ

混雑は1指標で取り切れないので、**(i) ポジションの集中**、**(ii) 同時に動く度合い（comovement）**、\*\*(iii) 需給（フロー）\*\*の3本立てが堅いです。

**(i) 混雑＝“同じものを持っている”**

*   代表例：MSCI の「crowded strategies」系の考え方（crowding scorecardの発想）。[MSCI](https://www.msci.com/downloads/web/msci-com/research-and-insights/paper/research-spotlight-lost-in-the-crowd-identifying-and-measuring-crowded-strategies-and-trades/research-spotlight-lost-in-the-crowd.pdf?utm_source=chatgpt.com)  
    _実装アンカー案（ETFでも近似可）_：
    *   選抜ポートフォリオの **上位ウェイト集中（HHI）**
    *   似たテーマ/セクターへの **AUM集中**（同カテゴリETFのAUM合算比率）

**(ii) 混雑＝“一緒に動きすぎる（comomentum/comovement）”**

*   momentumの混雑がテールリスクや将来リターンに繋がる、という方向の研究（13F由来プロキシなど）。Pedro Barroso らの系統。[Runi+1](https://www.runi.ac.il/media/zdel5xt3/moments-momentum.pdf?utm_source=chatgpt.com)  
    _実装アンカー案_：
    *   Winner集合（当月採用群）の **相関の平均 / 上位固有値比率（λ1/trace）**
    *   Winner集合の **残差相関**（市場・セクターを回帰で落としてから相関）
    *   「勝ち組が同時に崩れる」兆候としての **共分散急騰**

**(iii) 混雑＝“フローが偏る（需給）”**

*   ETFなら特に効きます：
    *   選抜銘柄（ETF）への **資金流入（flow）/AUM成長率**
    *   売買代金・回転率の急増（“みんなが出入りしている”）  
        ※この系統はデータ入手性に左右されるので、取れる範囲で。

* * *

### 2.2 Factor decay（効きの減衰）アンカー：ICと分布で見る

「効かなくなった」は、リターンそのものより \*\*“予測の構造”\*\*が崩れたかで判断した方が速いです。

**アンカー（必須）**

*   **Rolling IC / Rank IC**（スコアと将来リターンの相関）
*   \*\*分位スプレッド（top–bottom）\*\*のrolling推移
*   **スコア分布の圧縮**（dispersion低下）
    *   例：上位と下位の差が縮む／上位が団子化 → 入替がノイズ化

この“効きの減衰”が、\*\*Kent Daniel–Tobias Moskowitz 系の「モメンタムのクラッシュ／局面依存」の話とも整合します（クラッシュ局面は「予測が効かない」＋「一斉崩れ」が起きる）。[finance.business.uconn.edu](https://finance.business.uconn.edu/wp-content/uploads/sites/723/2014/08/10-15-Kent-Daniel-mom12.pdf?utm_source=chatgpt.com)  
（短期モメンタムでも、同じ診断が使えます。）

* * *

3) Exit attribution × アンカーを結合する（分析の芯）
-------------------------------------

実務で効く“芯”はこれです：

### 3.1 銘柄ごとに「外れた日の直前状態」を固定長で切り出す

*   例：exit日の **\-60〜0営業日** をイベントウィンドウ化
*   その間の
    *   rank推移、abs momentum、リスク指標
    *   crowdingアンカー（相関/固有値、フロー、集中）
    *   factor decayアンカー（IC、dispersion）  
        を並べます。

### 3.2 Exit を「説明」するのではなく「タグ付け」する

回帰で無理に説明する前に、まずは

*   **Rank-out**：rankが閾値を割った
*   **Abs-filter**：abs条件を割った
*   **Constraint-out**：制約に当たった  
    を機械的に確定し、  
    その上で **“混雑が高い局面でのRank-outが増えているか？”** のように集計します。

* * *

4) 可視化：定性的に一発でわかる“鉄板”5つ
-----------------------

「外れ方」が直感で掴める順に並べます（ETFでも個別株でもOK）。

1.  **Rankヒートマップ（銘柄×時間、色=rank/score）**
    *   採用中は枠線、exit日に印  
        → _“じわじわ負けて外れる” vs “急落で外れる”_ が一目で分かる。
2.  **Alluvial / Sankey（採用→除外の遷移）**
    *   状態：{採用, 候補, 除外, キャッシュ(dual)} の遷移を太さで表示  
        → _入替の多い時期_ が視覚化できる。
3.  **Survival curve（在籍期間の生存分析）**
    *   「採用されてから何ヶ月残るか」分布  
        → 混雑期に在籍期間が短くなる、などが見える。
4.  **Event study（exit日前後の平均パス）**
    *   exit銘柄の価格・ボラ・相関（固有値比率）を平均化  
        → _exitが“原因”か“結果”か_ を切り分けやすい。
5.  **2D regime map（横=dispersion / 縦=crowding）に exit頻度を重ねる**
    *   4象限で「外れやすい局面」を定性的に説明できる  
        例：**低dispersion×高crowding** で rank-out増、など。

* * *

5) 実装上の“アンカー”最小セット（これだけ作れば回り始める）
--------------------------------

データ制約があっても回る、ミニマム構成です。

*   **Exit reasonタグ**（Rank-out / Abs-filter / Constraint-out）
*   **Crowding proxy**：Winner集合の平均相関 or λ1/trace（可能なら残差）[科学UCP+1](https://ciencia.ucp.pt/files/43638782/SSRN_id3045019.pdf?utm_source=chatgpt.com)
*   **Factor efficacy**：Rolling Rank IC と dispersion（IQRやstd）
*   **可視化**：rankヒートマップ＋regime map＋event study

* * *

必要なら、あなたの現在の戦略設定（short-term momentumのホライズン、top-k、dual側のabs条件、リバランス頻度、バッファ有無）を“前提として”置いたうえで、上の **Exit taxonomy → アンカー計算 → 可視化** を、そのまま研究ノートの章立て（図表番号まで）に落としたテンプレも作れます。

## Prompt:
お願いします

## Response:
了解です。\*\*「外れ方の特定（exit attribution）」→「原因アンカー（crowding / factor decay）の時系列同定」→「可視化」\*\*まで、すぐ実装に落ちる形で“固定版”の設計を出します。  
（short-term momentum / dual momentum 両対応、ETFでも個別でも同じ枠組みです）

* * *

0) 前提：最低限必要な入力データ（これだけで開始可能）
----------------------------

*   `prices[d, i]`：日次 or 月次の価格（できればTotal Return）
*   `rf[d]`：無ければ0でもよい（dualの絶対条件用）
*   `universe_mask[d, i]`：その日に取引可能か（欠損/上場/売買停止を含む）

任意（あれば強い）

*   `flows[d, i]`：ETFフローやAUM（crowdingの需給アンカー）
*   `volume[d, i]` / `turnover[d, i]`：流動性制約・混雑 proxy

* * *

1) “外れた”を100%特定する：Exit taxonomy（機械タグ付け）
---------------------------------------

**各リバランス日 t** について、銘柄 i の状態を次の3つで確定します。

### 1.1 状態定義

*   `in_port[t, i]`：t時点でポートフォリオ構成に含まれるか（True/False）
*   `score[t, i]`：モメンタムスコア（短期 or dualで統一表現）
*   `rank[t, i]`：スコア順位（高いほど良い）

### 1.2 Exitイベント定義

銘柄 i が **t-1 で採用、tで非採用**なら `exit[t, i]=1`

### 1.3 Exit理由タグ（優先順位つき）

exitが起きたとき、以下の順で **単一理由**に落とします（競合しないようにするのがコツ）：

1.  `DATA_OUT`：tで取引不可能（maskがFalse、欠損など）
2.  `ABS_FAIL`：dualの絶対条件を割った（例：score\_abs < 0、or price < MA 等）
3.  `RANK_OUT`：相対ランキングがtop-kから外れた
4.  `CONSTRAINT_OUT`：リスク/流動性/上限/ターンオーバー制約で押し出された
5.  `TIE_BREAK`：同点・バッファルール等の実務的要因

> これで「外れ方」自体は完全に再現できます。原因分析はこのタグに紐づけてやります。

* * *

2) 原因仮説を“観測可能”にする：アンカー指標セット（最小構成）
---------------------------------

あなたの仮説は大きく2系統なので、アンカーも **2つのダッシュボード**に切ります。

* * *

### 2.1 Crowdingアンカー（混雑）

**最小セット（まずこれだけ作る）**

*   `crowd_corr[t]`：その月の“Winner集合”の平均相関
    *   Winner集合 = t時点でスコア上位（採用候補、もしくは実採用銘柄）
    *   相関はリターンで（例：過去L日）
*   `crowd_eig1_share[t] = λ1 / trace`：Winner集合の共分散の第一固有値比率
    *   “一緒に動いている度合い”を1本で表す鉄板

**可能なら追加（精度UP）**

*   `resid_corr[t]`：市場（+セクター）を落とした残差で相関（真の混雑に寄る）
*   `flow_z[t]`：フロー/AUMや出来高の急増z（需給混雑）

**実装ポイント**

*   L=60営業日くらいでRolling（短期モメンタムなら 20〜60）
*   Winner集合サイズが小さいなら相関より `eig1_share` を優先

* * *

### 2.2 Factor decayアンカー（効きの減衰）

**最小セット**

*   `rank_ic[t]`：`score[t, i]` と **次期リターン** `fwd_ret[t→t+1, i]` の Spearman 相関
*   `spread[t]`：上位分位（例 top20%）−下位分位（bottom20%）の次期平均リターン差
*   `dispersion[t]`：スコアの分散 or IQR（スコアが団子化すると入替がノイズ化）

> ここが崩れているのに入替が増えると、負けやすい“地合い”が可視化できます。

* * *

3) 結合：Exit × アンカーで「何が原因っぽいか」を固定する
---------------------------------

ここは回帰よりも **集計→層別** が最初に効きます。

### 3.1 まず見るべき集計（最重要）

*   `exit_rate[t] = exits[t] / holdings[t-1]`
*   `exit_rate_by_reason[t, reason]`

これに対して：

*   `crowding` が上位分位の月 vs 下位分位の月で **exit\_rate** 比較
*   `rank_ic` が悪い月（例えば負 or 下位分位）で **RANK\_OUT** が増えているか

### 3.2 ルール化（アンカーから“状態”へ）

説明用に **2軸レジーム** に切ると、定性的説明が一気に楽になります。

*   横軸：`dispersion`（低い＝団子化）
*   縦軸：`crowding_eig1_share`（高い＝一斉同調）

4象限：

1.  低dispersion × 高crowding：**最悪**（入替多・一斉崩れ・効かない）
2.  低dispersion × 低crowding：効き弱いが分散はある
3.  高dispersion × 高crowding：テーマが強く同方向（トレンド局面）
4.  高dispersion × 低crowding：健全（選別が効く）

* * *

4) 可視化：定性的に“一発で分かる”テンプレ（優先順）
----------------------------

ここからは**そのまま図表セット**として固定できます。

### 図1：Rank/Scoreヒートマップ（銘柄×時間）

*   色：rank（またはscore）
*   枠線：in\_port=1
*   マーカー：exitイベント（理由別に形を変える）

→ **「じわじわ落ちて外れた」 vs 「急落で外れた」** が一目。

### 図2：Sankey（状態遷移）

状態：`IN` / `CANDIDATE` / `OUT` / `CASH(dual)`  
→ 入替が増える月が可視化される。

### 図3：Survival curve（在籍期間）

*   採用からexitまでの期間分布
*   crowding高/低で2本比較

→ 混雑期に “持続しない” を直感で説明可能。

### 図4：Exit event study（exit日前後の平均パス）

exit日を0として

*   score, rank
*   realized vol
*   crowding proxy（eig1\_share）
*   fwd return（0→+1 など）

→ exitが“原因”か“結果”か（後追いか）を切り分け。

### 図5：2D regime map（dispersion×crowding）に exit率を重ねる

*   点＝月
*   点サイズ＝exit\_rate
*   色＝rank\_ic

→ これがプレゼン最強です。「外れる局面」が説明できます。

* * *

5) 実装の“最小完成形”チェックリスト（この順で作ると速い）
-------------------------------

1.  `signal/score`（短期モメ / dualモメ）計算
2.  `portfolio construction`（top-k, abs filter, constraints）
3.  `in_port` と `exit` の抽出
4.  `exit_reason` の単一タグ付け
5.  `crowding`（avg corr / eig1\_share）
6.  `rank_ic / spread / dispersion`
7.  図1〜図5の生成
8.  “混雑期×効きの減衰期”での exit率層別集計

* * *

6) すぐ作れる“成果物の形”（レポートの骨格）
------------------------

*   **1章：戦略定義**（short-term / dual）
*   **2章：Exit taxonomy**（理由別比率、時系列）
*   **3章：Crowdingアンカー**（eig1\_share、corr、必要ならflow）
*   **4章：Factor decayアンカー**（rankIC、spread、dispersion）
*   **5章：結合分析**（regime map、event study、survival）
*   **6章：示唆**（改善案：バッファ、再ランク頻度、abs条件、混雑回避フィルタ）

* * *

次の一手（あなたの条件で“そのまま固定”して良い推奨デフォルト）
--------------------------------

不明点があっても進められるよう、デフォルトを置きます：

*   リバランス：月次
*   crowding計算窓：60営業日
*   short-term momentum：1M（or 3M）リターン
*   dual：相対=12M-1M、絶対=12M-1M > 0（または rf 超え）
*   dispersion：scoreのIQR
*   factor efficacy：Spearman rank IC

* * *

必要なら、次のメッセージで **(A) short-term momentum** と **(B) dual momentum** を同じインターフェースに揃えた「関数設計（I/O固定）」と、図1〜図5までの**プロット関数の雛形**（Python想定、pandas+matplotlib中心）をそのまま貼れる形で出します。  
あなたの現状戦略が「月次・top-k・abs条件あり/なし・バッファあり/なし」のどれに近いかだけ書いてくれれば、その設定に合わせて“固定版”に落とし込みます。

## Prompt:
p00\_dualmom.ipynb

ファイル

p01\_stmom.ipynb

ファイル

添付のプログラムと整合的に計画してください

## Response:
思考時間: 1m 30s

了解です。添付の2本（`p00_dualmom.ipynb` / `p01_stmom.ipynb`）の\*\*“形成→保有”のタイミング**と、そこで作られている `StrategyResult.weights`（W）に**完全整合\*\*する形で、  
「(1) どの銘柄がどう外れるか（Exit attribution）」と「(2) 混雑/効きの減衰アンカー」および「(3) 可視化」を **同じ月次インデックスで**設計します。

* * *

1) まず「このノートブックが何をしているか」を固定（整合の芯）
================================

1.1 月次パネルの作り方（両ノート共通）
---------------------

*   `monthly_price = adj_close.resample('ME').last()`
*   `monthly_ret = monthly_price.pct_change()`
*   “月末3営業日除外”版も用意（`monthly_excluding_last_3_days`）  
    ※ただし戦略構築には現状 \*\*`monthly_ret`（通常EOM）\*\*を使っています。

1.2 形成月 m → 保有月 h のルール（両戦略共通）
-----------------------------

各ループで必ず：

*   形成月：`m = months[i]`
*   保有月：`h = months[i+1]`
*   形成情報：`r_form = monthly_ret.loc[m]`（＋信号）
*   実現リターン：`r_hold = monthly_ret.loc[h]`
*   ウェイト `w` は **保有月 h の列に timestamp を付けて保存**：`w.rename(h)`
*   売買回転：`t = 0.5 * |w - prev_w|_1`（片道ターンオーバー）
*   コスト：`ret_net = ret_gross - turn * cost`

### 重要な整合ポイント

*   **意思決定は m の情報**で行い、**実現は次の月 h**で評価。
*   よって「入替（exit）」は **h のリバランスで起きた**出来事として定義するのが最も整合的です。

* * *

2) Exit の定義（weightsに完全整合）
=========================

2.1 対象データ（必須）
-------------

*   各戦略の `StrategyResult.weights`（DataFrame `W`）
    *   index：保有月 `h`（月末 timestamp）
    *   columns：資産（ETF）
    *   値：ウェイト（0 か等ウェイト配分）

2.2 “外れる”イベント（Exit event）
-------------------------

保有月 `h`（= リバランスで新ポートが確定した月）における銘柄 i の exit を：

*   `in_prev = (W.loc[h_prev, i] > 0)`
*   `in_curr = (W.loc[h, i] > 0)`
*   `exit[h, i] = 1` iff `in_prev==True` and `in_curr==False`

ここで `h_prev` は `W.index` の直前月。

* * *

3) Exit reason（外れ方のタグ付け）— 戦略ロジックに合わせて作る
=======================================

「混雑/減衰」は後段でやるので、まずは**ロジック上の外れ方**を100%確定させます。  
添付コードの意思決定ルールをそのまま再計算して、exit を理由分解します。

* * *

3.1 DualMoM（`p00_dualmom.ipynb`）の exit reason
---------------------------------------------

戦略の核は `build_mom_strategy()` 内のこれです：

*   `m_form = momentum_signal.loc[m]`
*   `abs_score = m_form`
*   `score = abs_score.where(abs_score > 0)` （**絶対条件：>0**）
*   上位：`w_assets = score.sort_values(desc).dropna().head(top_k)`
*   下位：`l_assets = ...tail(top_k)`（※ただし `momentum_high=False` の時に使う）

### 結果として、DualMoMの exit は最低でもこの2分類が可能

1.  **ABS\_FAIL**
    *   前月まで採用されていたが、当月の `abs_score<=0` になって候補集合から消えた
2.  **RANK\_OUT**
    *   `abs_score>0` には残るが、上位 `TOP_K` から外れた

（データ欠損で候補に入れない等があれば `DATA_OUT` を追加）

> 実装整合のコツ：exit を起こした月は `h` ですが、**その exit を決めた形成月は m=h\_prev** です。  
> つまり **exit\[h\] の reason は m=h\_prev の信号で評価**します。

* * *

3.2 ST-MOM（`p01_stmom.ipynb`）の exit reason
------------------------------------------

`build_stmom_strategy()` は “top-k” ではなく **中央値で2×2分割**です：

*   winners / losers：`rv >= median(rv)` で二分
*   high\_turn / low\_turn：`tv >= median(tv)` で二分
*   `turnover_high` により (winners∩high\_turn) などを選ぶ
*   `momentum_high` により winners側か losers側かを等ウェイト

### ST-MOMの exit reason はこの3分類が自然

1.  **MOM\_BUCKET\_FLIP**
    *   winners↔losers の境界を跨いだ（形成月 m の `rv` が中央値を跨ぐ）
2.  **TURN\_BUCKET\_FLIP**
    *   high\_turn↔low\_turn の境界を跨いだ（形成月 m の `tv` が中央値を跨ぐ）
3.  **BOTH\_FLIP**
    *   両方跨いだ（入替の強い局面）

（同様に `DATA_OUT` があれば追加）

> ST-MOMではランキングではなく“閾値（中央値）”なので、exit の主要因は **境界跨ぎ**として整理すると説明力が高いです。

* * *

4) 原因仮説アンカー（混雑/効きの減衰）— 既存の月次パネルにそのまま乗せる
=======================================

ここも **形成月 m（= h\_prev）** に揃えます。  
理由：あなたのノートブックは m の情報で決めているから。

* * *

4.1 Crowding（混雑）アンカー：まずは「採用集合の同調」を作る
------------------------------------

両戦略で共通に使える、実装負担が小さいアンカーはこれです：

### (A) 採用集合の平均相関（formation window）

*   定義（月 m ごと）：
    *   `S_m = {i | selected at formation m }`（Dualなら top-k、STなら該当セル集合）
    *   日次 or 月次のリターン系列で、直近L期間の相関平均
*   まず月次で良い（`monthly_ret` を使って過去L=12ヶ月など）

### (B) 第一固有値比率（λ1 / trace）

*   `Cov(S_m)` の固有値で `eig1_share = λ1 / sum(λ)`
*   “みんな同じ方向に動く”が強いほど上がる

> これらは「外れる月（exitが増える月）」に、同調が上がっているかを見るのに向きます。  
> データ追加無しで成立します（priceだけでOK）。

（もし volume/flow/AUM があれば次段で需給混雑も載せられますが、ここでは整合優先で最小構成に留めます）

* * *

4.2 Factor decay（効きの減衰）アンカー：スコアの予測構造を見る
---------------------------------------

これも月次で、形成月 m に揃えます。

### (A) Rank IC（Spearman）

*   `IC[m] = SpearmanCorr(score[m, i], monthly_ret[h, i])`  
    ※ここで `h = next_month(m)`（コードと同じ）

DualMoM：

*   `score = momentum_proxy.loc[m]`（ただし absフィルタ前の raw と after の両方を保存推奨）  
    ST-MOM：
*   “スコア”が明示的でないので、まずは `r_form`（=月次リターン）をスコアとしてICを見る  
    （ST-MOMはそもそも r\_form と turnover の 2軸なので、`IC_ret`, `IC_turn` の2本にするのが自然）

### (B) Dispersion（団子化）

*   Dual：`disp[m] = std(score_raw[m, :])` or IQR
*   ST：`disp_ret[m] = std(r_form)`、`disp_turn[m]=std(t_form)`  
    → 分布が縮むと境界近辺が増え、境界跨ぎ（exit）が増えやすい、という説明ができます。

* * *

5) 可視化（あなたのweights・月次indexに完全整合）— 図の作り方を固定
==========================================

以下は「すべて W.index（保有月 h）を時間軸」にして描けます。

図1：Holdings matrix（最重要）
-----------------------

*   行：保有月 h
*   列：銘柄 i
*   値：`W[h,i]`（0/正）
*   上に重ねる：`exit[h,i]` をマーカー（理由別に記号を変える）

→ 「どの銘柄が、どのタイミングで抜けたか」が一発で見える。

図2：Exit reason の時系列スタック
-----------------------

*   `count_exit_by_reason[h, reason]` を積み上げ
*   同じ図に `turnover[h]`（戦略出力）を線で重ねる

→ “入替が増えたのは何の理由か” を定性的に説明可能。

図3：Regime map（dispersion × crowding） + exit率
--------------------------------------------

*   点：形成月 m（= h\_prev）
*   x：`disp[m]`
*   y：`eig1_share[m]`（または avg corr）
*   点サイズ：`exit_rate[h]`（h=next(m)）
*   点色：`IC[m]`

→ 「混雑×効きの低下」の象限で外れが増える、が見える。

図4：Exit event study（平均パス）
-------------------------

*   exitが起きた保有月 h を0として
*   指標系列（turnover、eig1\_share、IC等）を `h-12…h+12` で平均

→ “外れは事前兆候か、後追いか” を示せる。

* * *

6) 作業の配置（ノートブック整合の計画）
=====================

既存2本は戦略生成までできているので、整合性を壊さない最短は：

案A：新規ノート `p02_exit_attribution.ipynb` を作る（推奨）
---------------------------------------------

*   最初のセルで `p00_dualmom` / `p01_stmom` の関数定義を **コピペで再利用**（同じスタイル）
*   同じ `data/us_sector_etf_9_ohlc.csv` を読んで
*   両戦略を実行して `StrategyResult` を得る
*   そこから **Exit / reason / anchors / plots** を作る

> こうすると既存ノートに手を入れずに、結果が一貫します（検証・差分管理が楽）。

案B：既存2本の末尾に「Exit分析セクション」を追加
---------------------------

*   ただし同じコードが2回入るので保守性は落ちます。

* * *

7) 追加で“最低限”取っておく中間生成物（後で効く）
===========================

Exit reason とアンカー整合を強くするため、戦略ループの外（形成月 m ベース）で以下を保存するのが良いです：

*   Dual：
    *   `raw_mom[m,i]`（フィルタ前）
    *   `eligible[m,i] = raw_mom>0`
    *   `rank[m,i]`（eligible内）
    *   `selected[m,i]`（top\_k）
*   ST：
    *   `r_form[m,i]`, `t_form[m,i]`
    *   `is_winner[m,i] = r_form >= median`
    *   `is_high_turn[m,i] = t_form >= median`
    *   `selected[m,i]`

これがあると exit reason を「推定」ではなく「確定」できます。

* * *

必要なら、上の計画をそのまま \*\*“実装手順（セル単位）”\*\*にして、`p02_exit_attribution.ipynb` の章立て（セル見出し、保存するCSV/PNGのファイル名規約まで）も固定して出します。  
この2本は `TOP_K=3`、コスト `COST_BPS=10`、データは `us_sector_etf_9_ohlc.csv` で揃っているので、その前提で一気に固められます。

## Prompt:
お願いします

## Response:
思考時間: 1m 17s

了解です。添付の `p00_dualmom.ipynb` / `p01_stmom.ipynb` の **「形成月 m → 保有月 h（=次月）」** というタイミング、`StrategyResult.weights (W)` の **index=保有月** という設計に **完全整合**する形で、Exit（外れ方）特定・原因アンカー・可視化までを **1本の追加ノート**として固定化します。

以下は **そのまま `p02_exit_attribution.ipynb` を作って実装に移せる**セル単位の計画です（既存ノートに手を入れない方針）。

* * *

1) 整合の前提（添付ノートで確定している仕様）
========================

1.1 月次パネル（両ノート共通）
-----------------

*   日次→月次：`resample("ME").last()`（価格）と `pct_change()`（リターン）
*   保有月 `h` のリターンは `monthly_ret.loc[h]`
*   **意思決定は形成月 `m` の情報**で行い、\*\*評価は次の月 `h=m+1`\*\*で行う

1.2 Strategy の出力
----------------

両ノートとも `StrategyResult` を返し、その中に：

*   `weights: W`（DataFrame）
    *   **index = 保有月 h（月末）**
    *   columns = 銘柄
    *   値 = ウェイト（0 or 等ウェイト）
*   `turnover: turn[h]`（片道turnover）
*   `ret_gross[h]`, `ret_net[h]`

* * *

2) 新規ノート `p02_exit_attribution.ipynb` の設計（最短・整合優先）
==================================================

2.1 目的（このノートが出すもの）
------------------

1.  **Exit event**：どの銘柄がいつポートフォリオから外れたか（`exit[h, i]`）
2.  **Exit reason**：なぜ外れたか（戦略ロジックに基づく単一タグ）
3.  **アンカー**：混雑（crowding）と効きの減衰（factor decay）を **形成月 m** に揃えて計測
4.  **可視化（図1〜図5）**：定性的に“一発で”説明できる図を自動生成
5.  **CSV/PNG 出力**：再現性のため `outputs/` に固定命名で保存

* * *

3) セル構成（そのままノートにコピペできる粒度）
=========================

Cell 0: Constants / Imports
---------------------------

*   `COST_BPS=10`, `TOP_K=3`, `START_DATE=df.index[0]`（既存と同じ）
*   依存：numpy / pandas / matplotlib（既存と同じ）

Cell 1: Load data（既存ノートと同一）
---------------------------

*   `df = pd.read_csv("data/us_sector_etf_9_ohlc.csv", header=[0,1], index_col=0)`
*   `adj_close = df["Adj Close"].ffill()`
*   `volume = df["Volume"].astype(float)`  
    （※ stmom側で turnover proxy を作るのに使う）

Cell 2: Monthly builders（既存の関数を**そのまま**コピー）
-------------------------------------------

*   `monthly_from_daily()`
    *   dual: `monthly_mom = price.shift(2)/price.shift(12)-1`
*   `monthly_excluding_last_3_days()`（dualノートにあるが、exit分析の比較用に残す）
*   stmom側：`rolling_zscore()` と `turnover_proxy`

> ここは **p00/p01 から関数をコピペして同じ出力**にする（整合の核）。

Cell 3: Strategy builders（既存関数を**そのまま**コピー）
-------------------------------------------

*   `StrategyResult` dataclass
*   `build_mom_strategy()`（p00\_dualmomのもの）
*   `build_stmom_strategy()`（p01\_stmomのもの）

> これで「戦略のWの作られ方」が完全一致します。

Cell 4: Run strategies（Dual / ST-MOMを両方回す）
------------------------------------------

*   `monthly_price, monthly_ret, monthly_vol_sum, monthly_mom = monthly_from_daily(...)`
*   Dual：
    *   `res_dual = build_mom_strategy(monthly_ret, monthly_mom, strategy_name="DualMoM", top_k=TOP_K, cost_bps=COST_BPS)`
*   ST-MOM：
    *   `turnover_base = np.log(monthly_vol_sum.replace(0,np.nan))`
    *   `turnover_proxy = rolling_zscore(turnover_base, window=12, min_periods=12)`
    *   `res_st = build_stmom_strategy(monthly_ret, turnover_proxy, strategy_name="STMoM", momentum_high=True, turnover_high=True, cost_bps=COST_BPS)`

出力として `W_dual = res_dual.weights`, `W_st = res_st.weights`

* * *

4) Exit event の定義（Wに厳密整合）
=========================

Cell 5: Exit events
-------------------

`W` の index は **保有月 h** なので、exit は `h` で定義します：

*   `in_port[h,i] = (W.loc[h,i] > 0)`
*   `exit[h,i] = 1` iff `in_port[h_prev,i]==True` and `in_port[h,i]==False`

派生系列：

*   `exit_count[h] = exit[h,:].sum()`
*   `holdings_prev[h] = in_port[h_prev,:].sum()`
*   `exit_rate[h] = exit_count[h] / holdings_prev[h]`

これで「どの銘柄がどう外れたか」の“事実”が確定します。

* * *

5) Exit reason（戦略ロジックに厳密整合）— 形成月 m=h\_prev を使う
==============================================

ここが最重要です。**exitが起きた保有月 h の理由は、形成月 m=h\_prev の情報で判定**します（添付ノートがそうだから）。

5.1 DualMoM の reason（Cell 6A）
-----------------------------

p00\_dualmom の内部ロジック：

*   `score = m_form.where(m_form > 0)` → **abs条件**
*   上位 `top_k` を採用

よって reason は以下の単一タグに落ちます（優先順）：

1.  `DATA_OUT`：形成月 m または保有月 h のどちらかで valid 条件から外れた
    *   `valid = r_form.notna() & m_form.notna() & r_hold.notna()`
2.  `ABS_FAIL`：前月まで採用されていたが、形成月 m で `m_form<=0` になり eligible から消えた
3.  `RANK_OUT`：`m_form>0` には残るが、`top_k` から外れた

実装上は、形成月 m ごとに以下を保存しておくと reason が“確定”します：

*   `m_form_raw[m,i] = monthly_mom.loc[m,i]`
*   `eligible[m,i] = (m_form_raw>0)`
*   `rank[m,i]`（eligible内で降順順位）
*   `selected[m,i]`（top\_k）

そして exit\[h,i\] が立っている銘柄 i に対して：

*   if `eligible[m,i]==False` → `ABS_FAIL`
*   else if `selected[m,i]==False` → `RANK_OUT`
*   else（ここに来るなら）何か不整合 → 検知用タグ（例 `UNEXPECTED`）

5.2 ST-MOM の reason（Cell 6B）
----------------------------

p01\_stmom は

*   `rv = r_form`（形成月リターン）
*   `tv = t_form`（形成月turnover proxy）
*   `r_med = median(rv)`, `t_med=median(tv)`
*   winners/losers と high/low\_turn の **2×2セル**で採用集合が決まる

よって reason は「境界を跨いだか」で分解するのが最も整合的：

形成月 m に対し、各銘柄 i で

*   `is_winner[m,i] = (rv[i] >= r_med)`
*   `is_high_turn[m,i] = (tv[i] >= t_med)`

exit\[h,i\]==1 のとき（m=h\_prev）に

*   `MOM_BUCKET_FLIP`：is\_winner が前回形成月から反転（True↔False）
*   `TURN_BUCKET_FLIP`：is\_high\_turn が反転
*   `BOTH_FLIP`：両方反転
*   `DATA_OUT`：valid条件外

※「前回形成月からの反転」を見たい場合は、形成月系列を `m_prev` として比較します。  
ただし最初は単純に「形成月 m におけるセル条件を満たさない」でも理由付けできます（より堅いのは “反転” 判定）。

* * *

6) 原因アンカー（crowding / factor decay）— 形成月 m で計測し、exit\[h\] と結合
============================================================

Cell 7: Anchors (m-based)
-------------------------

### 6.1 Crowding（混雑）アンカー：価格だけで作れる最小セット

形成月 m ごとに、**その月に採用された集合 `S_m`**（Dualはtop\_k、STはセル集合）を使い：

*   `crowd_avg_corr[m]`：`S_m` の相関平均
    *   入力系列：月次リターンの rolling window（例 12ヶ月）を推奨
*   `crowd_eig1_share[m] = λ1 / trace`：共分散の第一固有値比率
    *   同調が強いほど上がる

**整合の注意**：`S_m` は「形成月 m のルールで決めた採用集合」。  
Wの `h` とずらさず、`m=h_prev` に合わせます。

### 6.2 Factor decay（効きの減衰）アンカー：予測構造の崩れ

形成月 m におけるスコア（戦略内部の “並べ替え変数”）と、次月リターン `r_hold` の関係を見る：

*   Dual：
    *   `score_raw[m,i] = monthly_mom.loc[m,i]`（abs前）
    *   `rank_ic[m] = Spearman(score_raw[m,*], monthly_ret.loc[h,*])`（h=m+1）
    *   `dispersion[m] = IQR(score_raw[m,*])`（団子化の指標）
*   ST：
    *   `score_ret[m,i] = r_form[i]`
    *   `score_turn[m,i] = t_form[i]`
    *   `rank_ic_ret[m] = Spearman(score_ret[m,*], r_hold[*])`
    *   `disp_ret[m] = IQR(score_ret[m,*])`
    *   `disp_turn[m] = IQR(score_turn[m,*])`

* * *

7) 可視化（W/exitに厳密整合、説明力最大の5図）
============================

Cell 8: Plots + exports（outputs固定）
----------------------------------

**出力先**は両ノート方針と同様に `outputs/` を切って保存（新規作成）：

### 図1 Holdings matrix（保有月×銘柄）

*   行：`h`（W.index）
*   列：銘柄
*   値：`W[h,i]`
*   exitマーカー：`exit[h,i]`（reason別に記号）

**ファイル**：

*   `outputs/fig01_holdings_matrix_dual.png`
*   `outputs/fig01_holdings_matrix_st.png`

### 図2 Exit reason の時系列（積み上げ）＋ turnover重ね

*   x：保有月 h
*   stacked bars：`count_exit_by_reason[h, reason]`
*   line：`res.turnover[h]`

**ファイル**：

*   `outputs/fig02_exit_reason_timeseries_dual.png`
*   `outputs/fig02_exit_reason_timeseries_st.png`

### 図3 Regime map（dispersion × crowding）に exit率を重ねる

*   点：形成月 m（=W.indexのひとつ前）
*   x：`dispersion[m]`
*   y：`crowd_eig1_share[m]`
*   サイズ：`exit_rate[h]`（h=m+1）
*   色：`rank_ic[m]`

**ファイル**：

*   `outputs/fig03_regime_map_dual.png`
*   `outputs/fig03_regime_map_st.png`

### 図4 Exit event study（exitの前後で平均パス）

*   exitが起きた保有月 h を0として ±12ヶ月
*   平均系列：`crowding`, `IC`, `turnover`, `ret` など

**ファイル**：

*   `outputs/fig04_exit_event_study_dual.png`
*   `outputs/fig04_exit_event_study_st.png`

### 図5 Survival（在籍期間の分布）

*   各銘柄の“採用開始→exitまで”の期間分布
*   crowding高/低で層別して2本（可能なら）

**ファイル**：

*   `outputs/fig05_survival_dual.png`
*   `outputs/fig05_survival_st.png`

* * *

8) CSV出力（再現性のための固定成果物）
======================

最低限この4つを保存しておくと、後で検証・比較が崩れません：

*   `outputs/exit_events_dual.csv`（index=h, columns=tickers, 0/1）
*   `outputs/exit_reasons_dual.csv`（index=h, columns=tickers, reason string）
*   `outputs/anchors_dual.csv`（index=m, crowding/IC/dispersionなど）
*   `outputs/summary_dual.csv`（index=h, exit\_count/exit\_rate/turnover/retなど）

STも同様に `_st` を付ける。

* * *

9) 実装時の“整合性チェック”（この4つは必ずassert）
===============================

最後に、整合が崩れていないことを機械検知します。

1.  `W.index` が **monthly\_ret.index の部分列**になっている
2.  各 `w.rename(h)` の `h` が `m` より後（既存にも assertあり）
3.  `exit[h]` は `W[h_prev]>0` かつ `W[h]==0` で定義されている
4.  `reason[h,i]` 判定に使う信号は **形成月 m=h\_prev** の値だけ

* * *

この計画が「添付プログラムと整合的」である理由（要点）
---------------------------

*   Exit を \*\*Wのindex（保有月 h）\*\*で定義し、reason は **形成月 m=h\_prev** の信号で判定する  
    → 添付ノートの for-loop と完全に同じ時間関係
*   Dualは `score = m_form.where(m_form>0)` と `top_k` による採用なので、reasonは `ABS_FAIL / RANK_OUT` がロジック上の最小完全分解
*   STは中央値で2×2に分けるので、reasonは「境界跨ぎ（bucket flip）」が最も自然で、しかも説明しやすい

* * *

次にやるべきことは明確で、**`p02_exit_attribution.ipynb` を新規作成し、p00/p01から関数をコピペして上記セル順に追加**です。  
もし「デュアルは momentum\_high=False も比較したい」「STは turnover\_high=False も比較したい」などバリエーションも同時にやるなら、Cell 4 で `configs = [...]` にしてループする構造に拡張するのが最小変更です。

## Prompt:
作成してください

## Response:
思考時間: 6m 8s

作成しました。こちらからダウンロードできます：

Download p02\_exit\_attribution.ipynb

このノートは、添付の `p00_dualmom.ipynb` / `p01_stmom.ipynb` と **形成月→保有月（m→h）のタイミング**および `StrategyResult.weights (W)` の **index=保有月** 仕様に整合するように作ってあります。  
実行すると `outputs/` 配下に **CSV（exit/reason/anchors/summary）** と **PNG（図1〜図5）** が保存されます。

## Prompt:
ZeroDivisionError                         Traceback (most recent call last)
Cell In[38], line 24
     14     summary = pd.DataFrame({
     15         "holdings_prev": holdings_prev,
     16         "exit_count": exit_count,
   (...)     20         "ret_net": res.ret_net.reindex(W.index),
     21     })
     22     return summary
---> 24 summary_dual = make_summary(W_dual, exit_dual, res_dual)
     25 summary_st = make_summary(W_st, exit_st, res_st)
     27 # Save (facts)

Cell In[38], line 13
     11 holdings_prev = in_port.shift(1).sum(axis=1)
     12 exit_count = exit_df.sum(axis=1)
---> 13 exit_rate = (exit_count / holdings_prev).replace([np.inf, -np.inf], np.nan)
     14 summary = pd.DataFrame({
     15     "holdings_prev": holdings_prev,
     16     "exit_count": exit_count,
   (...)     20     "ret_net": res.ret_net.reindex(W.index),
     21 })
     22 return summary

File ~/workspace/envs/base/.venv/lib/python3.12/site-packages/pandas/core/ops/common.py:85, in _unpack_zerodim_and_defer.<locals>.new_method(self, other)
...
     72 if _TEST_MODE:
     73     _store_test_result(False)
---> 74 return op(left_op, right_op)

ZeroDivisionError: division by zero

## Response:
原因はシンプルで、`holdings_prev`（前月の保有銘柄数）が **0 の月が存在**していて、そこで `exit_count / holdings_prev` が **ゼロ割り**になっています（pandasが `ZeroDivisionError` を投げるケース）。

添付ノートの整合性（W.index=保有月）を維持したまま直すなら、**0 のときは exit\_rate を NaN（または0）に落とす**のが正解です。

* * *

修正（推奨）：0 を NaN にして安全に割る
-----------------------

Cell\[38\] の `make_summary` をこの形に置き換えてください。

```
def make_summary(W: pd.DataFrame, exit_df: pd.DataFrame, res) -> pd.DataFrame:
    in_port = (W > 0).astype(int)

    holdings_prev = in_port.shift(1).sum(axis=1)
    exit_count = exit_df.sum(axis=1)

    # SAFE: holdings_prev==0 の月は exit_rate を NaN にする
    denom = holdings_prev.replace(0, np.nan)
    exit_rate = (exit_count / denom).astype(float)

    summary = pd.DataFrame({
        "holdings_prev": holdings_prev,
        "exit_count": exit_count,
        "exit_rate": exit_rate,
        "turnover": res.turnover.reindex(W.index),
        "ret_gross": res.ret_gross.reindex(W.index),
        "ret_net": res.ret_net.reindex(W.index),
    })
    return summary
```

これで `ZeroDivisionError` は止まります。

* * *

代替：0 のとき exit\_rate を 0 扱いにしたい場合
--------------------------------

（「前月ポジションゼロなら exit も定義しない＝0」としたい時）

```
denom = holdings_prev.replace(0, np.nan)
exit_rate = (exit_count / denom).fillna(0.0).astype(float)
```

* * *

なぜ `holdings_prev==0` が起きる？
---------------------------

*   DualMoM：形成月で `abs_score > 0` が **1つもない** → `w` が全ゼロ → 次月 `holdings_prev==0`
*   ST-MOM：valid銘柄が少ない/欠損 → セルに誰も入らない → 同様

これは戦略としてあり得るので、**exit\_rate の分母ゼロは仕様として扱う**のが正しいです。

* * *

追加の整合チェック（任意・デバッグ用）
-------------------

同じセルの直後にこれを入れると、どの月が0だったか見えます：

```
zeros = holdings_prev[holdings_prev == 0]
print("holdings_prev==0 months:", list(zeros.index))
```

* * *

この修正を入れたあとに再実行すれば、以降のCSV/図生成は走るはずです。もし次に落ちる場合は、エラー箇所（セル番号とトレース）をそのまま貼ってください。そこも同じく、ノートのタイミング整合（m→h）を崩さずに直します。

## Prompt:
fig. 3 は何を表しているか

## Response:
Fig.3 は、\*\*「外れ（exit）が増える局面が、混雑（crowding）と“効きの減衰（factor decay）”のどこに位置するか」\*\*を、**2次元のレジーム図**として可視化したものです。  
このノートでは、添付プログラムのタイミングに合わせて \*\*形成月 m（=保有月 h の1つ前）\*\*でアンカーを計測し、次月の exit と結びつけています。

* * *

Fig.3 の各要素（軸・色・サイズ）
-------------------

### 横軸：Dispersion（分布の広がり＝団子化の逆）

*   **DualMoM**：形成月 m の `momentum_raw`（absフィルタ前）の IQR/標準偏差など
*   **ST-MOM**：形成月 m の `r_form`（月次リターン）や `turnover_proxy` の IQR/標準偏差など  
    意味：
*   **低い** → スコアが団子化（差がつかない）＝ランキング/閾値判定がノイズ化しやすい
*   **高い** → スコアに差がある＝選別が効きやすい

### 縦軸：Crowding（同調＝混雑）

*   採用集合  $S_m$ （形成月 m で選ばれた銘柄群）の
    *   `eig1_share = λ1 / trace`（共分散の第一固有値比率）や
    *   平均相関（avg corr）  
        意味：
*   **高い** → 採用集合が“同じ方向に動く”＝混雑（クラッシュ時に同時崩れしやすい）
*   **低い** → 動きが分散＝混雑度は低め

### 点のサイズ：Exit rate（次月の外れやすさ）

*   **サイズは保有月 h における exit\_rate**（ただしアンカーは m=h\_prev）  
    意味：
*   大きいほど「その次のリバランスで、前月採用銘柄がポートフォリオから外れた割合」が高い

### 点の色：Rank IC（効き）

*   形成月 m のスコアと、次月リターン（h=m+1）の Spearman 相関  
    意味：
*   **色が良い方向（正）** → “スコアが次月を当てている”＝効いている
*   **悪い方向（負）** → “逆に当たっている/効いていない”＝減衰・反転局面

* * *

どう解釈するか（典型パターン）
---------------

Fig.3 は、ざっくり以下の読み方ができます：

### ① 右下（高dispersion × 低crowding）

*   選別が効いていて、混雑も低い
*   **exitは穏やか**になりやすい（点が小さい）

### ② 左上（低dispersion × 高crowding）＝危険域

*   スコアが団子化して差がつかないのに、採用集合は同調している
*   **exitが増えやすい**（点が大きい）＋ **ICも悪化しやすい**
*   あなたの仮説（混雑＋効きの減衰）が出やすい象限

### ③ 右上（高dispersion × 高crowding）

*   テーマ全体が強く同方向に走る局面
*   勝ち続けるなら exit は少ないが、崩れると一斉に外れる“イベント”が出ることも

### ④ 左下（低dispersion × 低crowding）

*   全体的に差がつかない＝シグナルが弱い
*   exit が増えるなら「閾値またぎ（ST）」や「top-k押し出し（Dual）」でノイズ入替が増える

* * *

この図が「アンカー」になっている理由
------------------

*   Fig.1/2 は「何が起きたか（どの銘柄がどう外れたか）」の事実
*   Fig.3 は「それが \*\*どんな局面（混雑×効き）\*\*で起きたか」を、**定性的に一目で**示す

つまり Fig.3 は、あなたが言う

> 混雑度の高まりや有効なファクターの減衰が原因では？  
> を、\*\*観測可能な2軸（crowding・dispersion）と1指標（IC）\*\*に落として検証するための “地図” です。

* * *

もし今の Fig.3 が「読みづらい/説得力が弱い」なら、次の改善が効きます（整合性は維持したまま）：

*   crowding を \*\*残差相関（市場・セクターを落とした後）\*\*に置換
*   dispersion を **スコアのIQR**に統一（Dual: mom\_raw, ST: rv と tv）
*   点のラベルとして、\*\*exit\_reason の内訳（ABS\_FAIL多い月など）\*\*を注釈で出す

必要なら、現在のノートの Fig.3 の実装（どの列をx/y/色/サイズに使っているか）に合わせて、解釈コメントを図中に自動で付ける形にもできます。

## Prompt:
rank_ic_retとは

## Response:
`rank_ic_ret` は、**形成月 m の「リターン系スコア（= その月のモメンタム指標）」が、次の月 h=m+1 の銘柄リターンの順位をどれだけ当てているか**を表す指標です。  
IC = Information Coefficient の \*\*Rank版（Spearman）\*\*なので `rank_ic_ret` という名前にしています。

* * *

定義（ST-MOM側の “ret” 版）
--------------------

ST-MOM の形成月  $m$  で、各銘柄  $i$  について

*   スコア（説明変数）：
    $$
    s_i(m) = r_i(m)
    $$
    （= 形成月の月次リターン。あなたの `p01_stmom.ipynb` では `rv = r_form` がこれ）
*   目的変数（予測対象）：
    $$
    y_i(m) = r_i(h),\quad h = m+1
    $$
    （= 次月の月次リターン）

そして

$$
\text{rank\_ic\_ret}(m) = \rho_{\text{Spearman}}\left(\{s_i(m)\}_i,\ \{y_i(m)\}_i\right)
$$

つまり、\*\*「今月強かった銘柄ほど来月も強いか？」\*\*のクロスセクション相関です。

* * *

解釈
--

*   `rank_ic_ret` が **高い（+）**  
    → 形成月のリターン順位が、次月のリターン順位に“持続”している（短期モメンタムが効きやすい）
*   **0 付近**  
    → 予測力なし（シグナルが効いていない）
*   **負（−）**  
    → 逆相関（短期リバーサル寄り）。この局面では **winners が落ちやすく、exit が増えがち**になり得ます。

* * *

なぜ “ret” と付けるのか
---------------

ST-MOM は2軸（ret と turnover proxy）なので、同様に

*   `rank_ic_ret`：ret軸の効き
*   `rank_ic_turn`：turnover軸の効き（turnover proxy と次月リターンの順位相関）  
    を区別するためです。

* * *

実装のイメージ（概念）
-----------

*   `score = r_form.loc[m]`
*   `future = monthly_ret.loc[h]`
*   `rank_ic_ret[m] = score.corr(future, method="spearman")`

（欠損は `dropna()` してから相関）

* * *

必要なら、あなたのノートの実装（実際に `rank_ic_ret` をどう計算しているセル）に合わせて、「欠損処理」「同点（ties）」「除外ユニバース」「形成月mと保有月hの整合」を点検し、ICがブレないように固定化します。

## Prompt:
exit rate とは

## Response:
`exit rate` は、このノートで定義した \*\*「前月ポートフォリオに入っていた銘柄のうち、今月のリバランスでポートフォリオから外れた銘柄の割合」\*\*です。  
（添付ノートの仕様に合わせて、\*\*保有月 h（=weightsのindex）\*\*で計算しています。）

* * *

定義（このノートの式）
-----------

各保有月  $h$  と銘柄  $i$  について、ウェイト行列  $W[h,i]$  から

*   前月保有フラグ： $\text{in\_prev}_i = \mathbf{1}\{W[h_{-1},i] > 0\}$ 
*   今月保有フラグ： $\text{in\_curr}_i = \mathbf{1}\{W[h,i] > 0\}$ 

**Exitイベント**：

$$
\text{exit}_i(h) = \mathbf{1}\{\text{in\_prev}_i = 1 \ \land\ \text{in\_curr}_i = 0\}
$$
*   前月の保有銘柄数：
    
$$
H_{\text{prev}}(h) = \sum_i \mathbf{1}\{W[h_{-1},i] > 0\}
$$
*   今月の exit 数：
    
$$
E(h) = \sum_i \text{exit}_i(h)
$$

**Exit rate**：

$$
\text{exit\_rate}(h) = \frac{E(h)}{H_{\text{prev}}(h)}
$$

* * *

直感的な意味
------

*   `exit_rate(h)=0.0`：前月の保有銘柄が全て残留（入替なし）
*   `exit_rate(h)=0.33`（例：TOP\_K=3 の DualMoM でよく出る）  
    → 前月の3銘柄のうち1銘柄が外れた
*   `exit_rate(h)=1.0`  
    → 前月の保有銘柄が全て外れた（全面入替 or 前月→今月で全銘柄が変わった）

* * *

注意点（あなたのエラーとも関係）
----------------

前月の保有銘柄数  $H_{\text{prev}}(h)=0$  の月があり得ます（Dualで eligible がゼロ、STで有効銘柄が少ない等）。  
その場合は分母ゼロなので、このノートでは \*\*NaN（または0扱い）\*\*にしています。

* * *

turnover との違い
-------------

*   `exit_rate`：**銘柄の入替“本数”の比率**（0/1のイベント）
*   `turnover`（ノートの `res.turnover`）：**ウェイト差の総量**
    $$
    \text{turnover}(h)=\frac{1}{2}\sum_i |W[h,i]-W[h_{-1},i]|
    $$
    同じ銘柄でもウェイトが変われば turnover は増えますが、exit\_rate は増えません。

* * *

必要なら、`entry_rate`（新規採用割合）や `replaced_by`（外れた銘柄が何に置き換わったか）も同じWから整合的に定義できます。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)