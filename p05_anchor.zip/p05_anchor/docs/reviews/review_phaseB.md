# Phase B Review: 戦略雛形（p00/p01/p02）読解

## 1. 目的
- `notebooks/p00_dualmom.ipynb`、`notebooks/p01_stmom.ipynb`、`notebooks/p02_exit_attribution.ipynb` を読み、現行ロジックを時点整合の観点で整理する。
- Phase C/Dで使う「変更してよい領域」と「保持すべき設計原則」を明確化する。

## 2. notebook別ロジック要約

### 2.1 p00_dualmom.ipynb（Dual Momentum雛形）
- データ:
  - `data/us_sector_etf_9_ohlc.csv` を読込。
  - `Adj Close` から月次価格・月次収益を作成。
- シグナル:
  - `monthly_mom = price.shift(2) / price.shift(12) - 1`
  - 直近1か月を除外した12-2型モメンタム。
- ポートフォリオ:
  - 形成月 `m` のシグナルで上位 `TOP_K=3` を選抜。
  - 保有は翌月 `h=m+1`、等金額ウェイト、片道turnover課金（10bps）。
- 重要点:
  - `m` の情報のみで `h` を決めるため、基本的な先読みリークは抑制されている。

### 2.2 p01_stmom.ipynb（Short-term momentum + turnover bucket）
- データ:
  - 同じく `us_sector_etf_9_ohlc.csv`。
- シグナル:
  - 収益バケット（当月収益の中央値でwinner/loser）。
  - turnover proxy（`log(monthly volume)` のrolling z-score）で高回転/低回転を分割。
- ポートフォリオ:
  - `winner/loser × high/low turnover` の組み合わせで選抜集合を定義。
  - 翌月保有、等金額、取引コスト控除。
- 重要点:
  - バケット判定が明確で、Exit理由をbucket flipとして分解しやすい。

### 2.3 p02_exit_attribution.ipynb（Exit attribution雛形）
- 目的:
  - Dual/ST戦略を再構築し、exit event・exit reason・anchorを計算し、図表化する。
- 実装要素:
  - `compute_exit_events`, `dual_exit_reasons`, `st_exit_reasons`
  - `compute_anchors_dual`, `compute_anchors_st`
  - 可視化: holdings matrix, reason時系列, regime map, event study, survival
- 確認した注意点:
  - `build_stmom_strategy` 呼び出しで引数名の不整合（`turnover_proxy=`）が見えるため、セル順・改版差分依存で実行エラー化しうる。
  - `outputs/` へCSV/PNG保存する設計は、今回方針（証跡はdocs/reviews）と不整合。

## 3. 現行処理フロー（共通）
1. 日次OHLCVを月次へ集約。
2. 形成月 `m` のシグナルを生成（mom, turnover）。
3. 選抜ロジックでウェイト `w_m` を決定。
4. 翌月 `h=m+1` の収益へ適用。
5. `turnover = 0.5 * |w_h - w_prev|` でコスト控除。
6. 追加分析（p02）でexitタグとアンカー計算。

## 4. 時点整合チェック（リーク防止）

| 項目 | 判定 | コメント |
|---|---|---|
| 形成月→翌月適用 | OK | `for i in range(len(months)-1): m=months[i], h=months[i+1]` |
| dual signal計算 | OK | `shift(2)/shift(12)` で直近月を避ける構造 |
| ST bucket計算 | OK | `m` 時点の `r_form`, `t_form` で `h` を決定 |
| 取引コスト計算 | OK | 片道turnoverにbps課金 |
| 欠損処理 | 注意 | valid判定で除外されるが、データ不足月の理由分類は実装依存 |
| notebook再実行安定性 | 注意 | p02は引数名不整合・保存先固定で壊れやすい |

## 5. Phase C/Dへ持ち込む設計原則
- 維持すべき原則:
  - 形成月情報のみで翌月ポジション決定。
  - 月次単位のweights/turnover整合。
  - dual: `ABS_FAIL`（mom<=0）を明示できる構造。
  - st: bucket flipを理由分解できる構造。
- 見直すべき点:
  - p02依存を避け、新規p03で再実装して実行安定性を確保。
  - 出力先を `outputs/` から外し、レビュー文書中心に証跡化。

## 6. Phase Cへの引き継ぎ
- Exit taxonomyは以下を最小セットとする:
  - Dual: `RANK_OUT / ABS_FAIL / DATA_OUT / CONSTRAINT_OR_TIE`
  - ST: `MOM_BUCKET_FLIP / TURN_BUCKET_FLIP / BOTH_FLIP / BUCKET_CHANGE / DATA_OUT`
- アンカーは、データ制約下で計算可能な以下を優先:
  - `crowd_avg_corr`, `crowd_eig1_share`, `rank_ic`, `spread_top_bottom`, `dispersion_iqr`
