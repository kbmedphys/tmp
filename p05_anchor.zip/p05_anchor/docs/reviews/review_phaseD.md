# Phase D Review: 原因仮説アンカー分析（p03実装・実行結果）

## 1. 実施内容
- 新規Notebookを作成し、実装・実行:
  - `notebooks/p03_anchor_analysis.ipynb`
- 実装範囲:
  - DualMoM / STMoM_WH の再構築（`p00/p01`の時点整合を維持）
  - Exit taxonomy算出
  - Crowding / Factor decayアンカー算出
  - 可視化（5種×2戦略）
- ファイル出力:
  - `outputs/` には保存せず、Notebook表示と本レビューで結果を記録。

## 2. 実行検証
- 実行手順（検証時）:
  - `nbclient` で `p03_anchor_analysis.ipynb` を先頭から実行し、完走を確認。
- 実行時データ:
  - 日次 3,806行
  - 月次 182行
  - 銘柄 9（`XLB/XLE/XLF/XLI/XLK/XLP/XLU/XLV/XLY`）

## 3. 戦略パフォーマンス（実測）

| strategy | n_months | CAGR | Vol | Sharpe | MaxDD | HitRate |
|---|---:|---:|---:|---:|---:|---:|
| DualMoM_W | 169 | 0.1312 | 0.1393 | 0.9592 | -0.1965 | 0.6568 |
| STMoM_WH | 170 | 0.1111 | 0.1464 | 0.7957 | -0.2870 | 0.6059 |

## 4. Exit理由の集計

### 4.1 DualMoM_W
- `RANK_OUT`: 93
- `ABS_FAIL`: 15

### 4.2 STMoM_WH
- `MOM_BUCKET_FLIP`: 135
- `TURN_BUCKET_FLIP`: 86
- `BOTH_FLIP`: 55

## 5. アンカー診断（仮説判定）

| strategy | corr_crowd_exit_rate | corr_rankic_exit_rate | exit_rate_high_crowd | exit_rate_low_crowd | rank_ic_mean | dispersion_mean |
|---|---:|---:|---:|---:|---:|---:|
| DualMoM_W | -0.1551 | -0.0614 | 0.1905 | 0.2619 | -0.0107 | 0.1164 |
| STMoM_WH | -0.0251 | 0.0044 | 0.6188 | 0.5854 | -0.0250 | 0.0326 |

### 解釈
- Crowd仮説（「crowding↑でexit↑」）:
  - 今回データでは明確支持なし。
  - Dualで `corr(crowd, exit_rate)<0`、高crowding群のexit率も低め。
  - STはほぼ無相関。
- Factor decay仮説:
  - `rank_ic_mean` はDual/STとも負で、シグナルの効きが弱い局面が多い。
  - ただし `corr(rank_ic, exit_rate)` は強くないため、単独説明力は限定的。
- Exit構造:
  - Dualは `RANK_OUT` 優勢で、相対順位劣化型が中心。
  - STはbucket flip起因が中心で、レジーム遷移型の離脱が多い。

## 6. 可視化確認（Notebook内表示）
- 生成済み:
  - Holdings matrix（Exit marker付き）×2
  - Exit reason stacked timeseries ×2
  - Regime map ×2
  - Event study（高crowdingイベント）×2
  - Survival curve ×2
- 目的達成:
  - 離脱理由の時系列と、crowding/dispersion/ICの同時観察が可能。

## 7. 制約と改善余地
- 制約:
  - ETFフロー実測（AUM/creation-redemption）が無く、需給は出来高proxyで代替。
  - 銘柄数9のため、相関・固有値系は推定誤差が残る。
- 改善候補:
  - ユニバース拡張（テーマETF群の増加）
  - 外生因子（市場、バリュー、ボラ）に対する残差相関でcrowding再定義
  - crowding閾値制約付きポートフォリオ最適化（文献に沿った実装）

## 8. 再実行手順
- 推奨コマンド:
  - `/Users/kencharoff/workspace/envs/base/.venv/bin/python -m jupyter nbconvert --to notebook --execute notebooks/p03_anchor_analysis.ipynb --output /tmp/p03_anchor_analysis.executed.ipynb`
- 代替:
  - Jupyter Labで `notebooks/p03_anchor_analysis.ipynb` を上から順に実行。
