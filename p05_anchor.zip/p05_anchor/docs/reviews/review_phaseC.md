# Phase C Review: 原因仮説アンカー候補の整理

## 1. 目的
- Phase A（文献）とPhase B（雛形戦略）を統合し、**「なぜポートフォリオから外れるか」** を観測可能なアンカーへ写像する。
- ここでは実装せず、Phase Dでそのまま実装できる仕様に落とす。

## 2. Exit taxonomy（採用）

### 2.1 DualMoM
- `ABS_FAIL`: 形成月モメンタムが閾値（0）以下
- `RANK_OUT`: positive momの中でtop_kから外れる
- `DATA_OUT`: 必要データ欠損
- `CONSTRAINT_OR_TIE`: 上記以外（同値処理、制約等）

### 2.2 STMoM（Winner × High Turnover採用を想定）
- `MOM_BUCKET_FLIP`: winner/loser側が反転
- `TURN_BUCKET_FLIP`: high/low turnover側が反転
- `BOTH_FLIP`: 両方反転
- `BUCKET_CHANGE`: 前期比較不能または選抜セル外へ遷移
- `DATA_OUT`: 欠損

## 3. Exit理由とアンカーの対応表

| Exit理由 | 主アンカー | 補助アンカー | 解釈 |
|---|---|---|---|
| `RANK_OUT` | `rank_ic` 低下 | `dispersion_iqr` 低下, `spread_top_bottom` 縮小 | 予測効きの低下で順位優位が消失 |
| `ABS_FAIL` | `momentum_signal` 負値化 | `crowd_eig1_share` 高止まり | 過熱後の反転やトレンド失速 |
| `MOM_BUCKET_FLIP` | `rank_ic` 低下 | `ret_net` 低下 | winner地位の喪失 |
| `TURN_BUCKET_FLIP` | `turnover_signal` 急変 | `crowd_avg_corr` 変化 | 需給レジーム移行 |
| `BOTH_FLIP` | `crowd_eig1_share` 上昇 | `dispersion_iqr` 低下 | 同調化かつ選別力低下の悪化局面 |
| `DATA_OUT` | データ品質指標 | 欠損頻度 | シグナル要因ではない運用要因 |

## 4. アンカー定義（Phase D実装仕様）

### 4.1 Crowding系
- `crowd_avg_corr(t)`:
  - 形成月 `m=t-1` 時点までのローリング窓（12か月）で、選抜集合の平均オフ対角相関。
- `crowd_eig1_share(t)`:
  - 同窓の共分散行列で `lambda_max / trace(cov)`。
  - 高いほど「同じ方向に動く比率」が高い。

### 4.2 Factor efficacy系
- `rank_ic(t)`:
  - 形成時スコア `score_m` と翌月実現収益 `ret_t` のSpearman相関。
- `spread_top_bottom(t)`:
  - スコア上位30%平均翌月収益 - 下位30%平均翌月収益。
- `dispersion_iqr(t)`:
  - 形成時スコアのIQR。
  - 低下は「上位下位差の圧縮」を示唆。

### 4.3 需給proxy
- `turnover_signal`:
  - `log(monthly_volume)` の12か月rolling z-score。
  - 直接フローが無い環境での代替指標。

## 5. 可視化仕様（Phase Dで固定）

### 図1: Holdings matrix + Exit marker
- 行: 保有月、列: 銘柄、色: weight
- marker形状でExit理由を区別
- 目的: 「どの銘柄がどの理由で外れたか」を時系列で即時確認

### 図2: Exit reason stacked bars + turnover line
- 棒: 理由別exit件数、折線: turnover
- 目的: 入替急増期の理由構成を把握

### 図3: Regime map（dispersion × crowding）
- x: `dispersion_iqr`, y: `crowd_eig1_share`
- 点サイズ: `exit_rate`, 点色: `rank_ic`
- 目的: exit多発レジームの位置を可視化

### 図4: Event study（高crowdingイベント）
- イベント月: `crowd_eig1_share` 上位四分位
- 窓: ±12か月
- 系列: `exit_rate`, `ret_net`, `crowd_eig1_share`, `rank_ic`
- 目的: 高crowding前後での挙動変化確認

### 図5: Survival curve
- 連続保有月数の生存曲線
- 目的: 戦略ごとのポジション持続性比較

## 6. 判定ロジック（Phase D結果の読み方）
- Crowd仮説支持の最小条件:
  - `corr(crowd_eig1_share, exit_rate) > 0` または高crowding群のexit率が低crowding群を上回る。
- Factor decay仮説支持の最小条件:
  - `rank_ic` 平均が低く、かつ `corr(rank_ic, exit_rate) < 0`。
- 需給ショック仮説支持の補助条件:
  - `TURN_BUCKET_FLIP` または `BOTH_FLIP` が高回転局面で増える。

## 7. Phase Dへの実装入力
- 新規Notebook: `notebooks/p03_anchor_analysis.ipynb`
- 入力データ: `data/us_sector_etf_9_ohlc.csv`
- 出力方針:
  - ファイル保存は行わずNotebook表示。
  - 主要数値は `review_phaseD.md` に記録。
