# Phase A Review: 文献・ノート精読

## 1. 目的と範囲
- 目的: テーマETFモメンタム戦略に対する「原因仮説アンカー」を、既存研究の根拠に基づいて候補化する。
- 対象:
  - `docs/sources/Comomentum.pdf`（54 pages）
  - `docs/sources/Factor Momentum Everywhere JPM Quant 19.pdf`（26 pages）
  - `docs/sources/Fund Flows and Underlying Returns The Case of ETFs.pdf`（30 pages）
  - `docs/sources/MSCI Integrated Factor Crowding Model.pdf`（24 pages）
  - `docs/sources/Crowd Control, Momentum and Concentrated Markets _ MSCI.pdf`（12 pages）
  - `docs/notes/ChatGPT-テーマETFモメンタム戦略.md`
  - `docs/notes/ChatGPT-ポートフォリオ外れ原因分析.md`

## 2. 論文レビュー（仮説・根拠・制約・転用）

### 2.1 Comomentum（Lou & Polk, 2014）
- 仮説:
  - モメンタム戦略の混雑度（comomentum）が高い局面では、裁定が不安定化しやすく、将来リターンの反転やクラッシュが起こりやすい。
- 根拠:
  - `Abstract` で「high comomentum局面はcrash/reversion」と明記。
  - 高comomentum期は、低comomentum期対比で1年先リターンが大きく悪化（本文で年次差分の実測値を提示）。
  - skewness悪化・volatility上昇を同時に予見。
  - value側（covalue）は逆方向で、アンカー（value spread）を持つ戦略では安定化しやすい。
- 制約:
  - 株式クロスセクション研究であり、ETFユニバースへは直接移植でなくproxy化が必要。
  - comomentum算出に部分相関や因子コントロールが必要で、データ要求が高い。
- 本プロジェクトへの転用:
  - ETF銘柄同士の「選抜集合内相関」「第1固有値比率」をcrowding proxyとして利用可能。
  - 高crowding局面でexit率・負の先行指標（低IC/低スプレッド）を検証すべき。

### 2.2 Factor Momentum Everywhere（Gupta & Kelly, 2019）
- 仮説:
  - モメンタムは個別銘柄固有ではなく、ファクター収益系列にも時系列モメンタムとして頑健に存在する。
- 根拠:
  - 65因子のAR(1)平均が正（本文では平均0.11を報告）。
  - TSFM（time-series factor momentum）は単純因子平均やUMDを超える情報を保持。
  - 取引コスト控除後も相対優位が維持される。
  - US外でも類似結果を確認。
- 制約:
  - 論文は株式因子基盤で、ETF本数9銘柄という小ユニバースでは推定分散が大きい。
- 本プロジェクトへの転用:
  - 「ファクター効きの減衰」をRank IC、Top-Bottom spread、score dispersionで監視する設計が妥当。

### 2.3 Fund Flows and Underlying Returns: The Case of ETFs（Staer, 2017）
- 仮説:
  - ETFフローは同時点で基礎資産へ価格圧力を与え、短期で部分反転（transitory price pressure）する。
- 根拠:
  - 286本ETF（2000-2010）で、同時点price impact + 事後reversalを確認。
  - VARではflow shockに伴う価格変化の一部が数日で反転（本文は反転比率を提示）。
  - 上位ETF群で価格圧力が強い。
- 制約:
  - 日次フローデータ品質・報告ラグ問題がある。
  - 本プロジェクトにはAUM/creation-redemption実測がない。
- 本プロジェクトへの転用:
  - 直接フローが無い場合、`log(volume)` のz-scoreやturnover proxyを需給アンカー代替として利用。
  - 「短期で反転する異常な流動性ショック」をbucket flip頻度と併せて監視。

### 2.4 MSCI Integrated Factor Crowding Model（MSCI, 2018）
- 仮説:
  - crowdingは単一指標ではなく、valuation/short-interest/correlation/volatility/reversalの複合で測る方が将来リスク把握に有効。
- 根拠:
  - 高crowdingスコアで将来の低リターン・高ボラ・大きなdrawdown頻度上昇を報告。
  - 特に6-12か月先で関係が強いと整理。
  - モメンタム因子は歴史的イベント時に高crowding化しやすい。
- 制約:
  - 13Fやshort-interest等の追加データ前提が多く、ETF9本データだけで完全再現は不可。
- 本プロジェクトへの転用:
  - 利用可能な最小セットは `pairwise corr` と `eig1 share` と `reversal/dispersion proxy`。
  - 「統合スコア」よりもまず個別proxyの方向性を検証する段階が妥当。

### 2.5 Crowd Control, Momentum and Concentrated Markets（MSCI blog, 2024/2026取得）
- 仮説:
  - 高モメンタム銘柄でもcrowding制約を課すことで、de-ratingリスクを抑え、リスク/リターンを改善できる。
- 根拠:
  - time-series crowding score制約を使ったモメンタム設計の改善例を提示。
  - 予見期間は次月だけでなく2-3か月にも有効性があると主張。
- 制約:
  - ブログ形式で再現詳細は限定的。モデル内製化には追加仕様が必要。
- 本プロジェクトへの転用:
  - 「crowding高い銘柄を同一モメンタム順位でも抑制する」ルール候補が有効。

## 3. notes文書レビュー

### 3.1 ChatGPT-テーマETFモメンタム戦略
- 主張の中核:
  - 戦略収益を「市場β」「既知因子」「テーマ共通因子」「残差α」に分解し、テーマ因子の追加でα縮小を検証すべき。
- 実務的に有効な点:
  - 選抜ポートフォリオ由来の因子候補（selection factor）をOOSで評価する枠組み。
  - 既知因子への残差化（orthogonalization）を明示しており、解釈上の混同を避けやすい。

### 3.2 ChatGPT-ポートフォリオ外れ原因分析
- 主張の中核:
  - Exit taxonomyを先に確定し、その後でcrowding/factor decayアンカーを重ねる2段階設計が妥当。
- 実務的に有効な点:
  - `Rank-out / Abs-fail / Constraint-out / Data-out` の分類方針。
  - 可視化テンプレ（ヒートマップ、regime map、event study、survival）が具体的。

## 4. 統合した示唆（Phase B/Cに渡す要点）

### 4.1 主要仮説
- H1: 選抜集合の同調性（crowding）が高い局面で、翌月のexit率または負の歪みが増える。
- H2: 因子効き（Rank IC、Top-Bottom spread、dispersion）が悪化した局面で、`RANK_OUT` が増える。
- H3: 流動性ショックproxy（turnover z-score）が急変した局面で、bucket flip由来のexitが増える。

### 4.2 利用可能データに対する最小アンカー
- Crowding:
  - `crowd_avg_corr`: 選抜集合の平均相関
  - `crowd_eig1_share`: 共分散行列の第1固有値比率
- Factor decay:
  - `rank_ic`: 形成時スコアと翌月リターンのSpearman相関
  - `spread_top_bottom`: スコア上位-下位分位の翌月リターンスプレッド
  - `dispersion_iqr`: 形成時スコアIQR
- 需給proxy:
  - `turnover_signal`: `log(volume)` のrolling z-score

## 5. 文献レビュー上の制約
- PDFはテキスト抽出ベースで精読し、図版の視覚確認（Poppler）を行っていない。
- MSCI系資料は実装詳細が非公開な部分があり、厳密再現よりproxy設計が中心。
- 本プロジェクトのデータは価格・出来高中心で、AUM/short-interest/保有開示データは未導入。

## 6. Phase Bへの引き継ぎ
- 既存notebookから以下を検証する:
  - 時点整合（m形成→h保有）
  - Exit reasonの実装可能性
  - 上記最小アンカーが計算可能か
