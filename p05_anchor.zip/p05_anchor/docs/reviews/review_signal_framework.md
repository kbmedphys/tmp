# review_signal_framework

## 1. 目的と成果物
- 目的: テーマETF戦略で、ユーザ定義シグナルを差し替えて比較評価し、採択から離脱までの挙動を視覚的に説明できる枠組みを作る。
- 実装成果物:
  - `notebooks/p04_signal_lab.ipynb`（新規）
  - 本レビュー `docs/reviews/review_signal_framework.md`
- 非変更保証: `p00_dualmom.ipynb` / `p01_stmom.ipynb` / `p02_exit_attribution.ipynb` は未編集。

## 2. 実装した公開インターフェース
`p04_signal_lab.ipynb` で以下のIFを実装。

- `SignalContext`
  - `monthly_price`, `monthly_ret`, `monthly_vol`, `base_features`
- `SignalSpec`
  - `name`, `description`, `params_schema`, `score_fn`, `eligibility_fn`
- `SelectionConfig`
  - `top_k`, `long_only`, `rebalance`, `cost_bps`
- `BacktestResult`
  - `weights`, `ret_gross`, `ret_net`, `turnover`, `exits`, `exit_reasons`, `anchors`, `summary`
- `EvaluationConfig`
  - `benchmark_names`, `objective_weights`, `corr_window`, `seed`
- `EvaluationResult`
  - `metrics_table`, `objective_score`, `visuals`

追加機能:
- シグナルレジストリ: `register_signal(...)`
- 探索ランナー:
  - `run_grid_search(...)`
  - `run_random_search(...)`

## 3. 時点整合（リーク防止）
- 形成月 `m` の `score/eligibility` で、保有月 `h=m+1` の銘柄を決定。
- 実装は `for i in range(len(months)-1): m=months[i], h=months[i+1]` の固定フロー。
- `m` 時点で `h` の欠損銘柄は除外 (`valid_h` マスク)。
- 月次リターンは `h` で評価し、コスト控除後 `ret_net` を計算。

## 4. 評価ロジック（総合スコア）
一次指標:
- 予測: `rank_ic_mean`, `spread_top_bottom_mean`
- 運用: `Sharpe`, `CAGR`, `MaxDD`, `turnover_mean`
- 安定: `rank_ic_std`, `exit_rate_vol`
- 説明性: `explain_consistency`（`crowd_bucket_gap` と `-corr_rankic_exit_rate` の平均）

合成方法:
- 各指標をロバストz変換 (`median/MAD` ベース)
- 悪化指標は符号反転して加点
- デフォルト重み:
  - predictive 0.35
  - operational 0.35
  - stability 0.20
  - explainability 0.10
- `delta_vs_best_benchmark` でベンチマーク最良との差分を算出

## 5. 可視化パック（6種）
実装済み:
1. Entry-to-Exit Performance Cohort（アンカーバケット別）
2. Exit Hazard by Anchor Bucket（保有月数ごとの離脱率）
3. Holdings Matrix + Exit Reason Marker
4. Reason Timeseries + Turnover
5. Regime Map（dispersion × crowding, size=exit_rate, color=rank_ic）
6. Event Study（high crowding / low rank_ic）

## 6. 実行結果サマリ（`us_sector_etf_9_ohlc.csv`）
### 6.1 ベース比較（Dual / ST / User例）
| name | objective_score | CAGR | Sharpe | MaxDD | rank_ic_mean | turnover_mean | explain_consistency | delta_vs_best_benchmark |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| dual_baseline | 0.489 | 0.131 | 0.959 | -0.197 | -0.0107 | 0.231 | -0.0050 | 0.000 |
| user_mom_turn_blend | -0.883 | 0.142 | 1.030 | -0.172 | -0.0222 | 0.278 | -0.0386 | -1.372 |
| st_wh_baseline | -1.105 | 0.110 | 0.790 | -0.287 | -0.0137 | 0.698 | -0.0013 | -1.594 |

観察:
- User例は `CAGR/Sharpe/MaxDD` は改善だが、予測系・説明性のスコアが低く総合で劣後。
- ST雛形は回転率が高く、運用次元で不利。

### 6.2 離脱理由の内訳（件数）
- dual_baseline: `RANK_OUT=93`, `ELIG_FAIL=15`
- st_wh_baseline: `ELIG_FAIL=267`, `RANK_OUT=6`
- user_mom_turn_blend: `RANK_OUT=113`, `ELIG_FAIL=19`

### 6.3 探索ランナー（雛形）
Grid上位（抜粋）:
- `user_mom_turn_blend[12]`: objective 0.558, CAGR 0.144, Sharpe 1.058
- `user_mom_turn_blend[21]`: objective 0.416, CAGR 0.142, Sharpe 1.047

Random上位（抜粋）:
- `user_mom_turn_blend[rand_12]`: objective 0.911, CAGR 0.143, Sharpe 1.050
- `user_mom_turn_blend[rand_18]`: objective 0.859, CAGR 0.137, Sharpe 1.010

## 7. テストケース結果
- IF検証:
  - `score_fn` 列不整合で明示エラーを確認（PASS）
  - 高NaN比率で明示エラーを確認（PASS）
- 時点整合検証:
  - `m -> m+1` の固定フローで実装（PASS）
- 境界条件:
  - 定数シグナル: 実行継続を確認（PASS）
  - `top_k > available` を処理（PASS）
- 可視化妥当性:
  - 6図すべて描画確認（PASS）

## 8. 再実行手順
プロジェクトルートで実行:

```bash
/Users/kencharoff/workspace/envs/base/.venv/bin/python -m jupyter nbconvert --to notebook --execute --inplace /Users/kencharoff/workspace/projects/momentum/p05_anchor/notebooks/p04_signal_lab.ipynb
```

補足:
- この環境ではJupyterカーネル起動時にポート権限が必要な場合がある。

## 9. 自走化に向けた設計メモ（次フェーズ）
- 探索runnerの永続化IF（leaderboardの履歴管理）
- 失敗試行ログ（NaN過多・空ポートフォリオ理由）の体系化
- 目的関数重みのメタ探索（predictive vs explainability の重み最適化）
- ユニバース抽象化（複数CSV/銘柄群切替）

## 10. 銘柄別4段時系列パネル（今回追加）
### 10.1 追加IF
- `BacktestResult` に以下を追加:
  - `score_hold`, `eligibility_hold`, `selected_hold`, `rank_hold`, `rank_pct_hold`, `form_month_by_hold`
- `PanelConfig` を追加:
  - `tickers`, `start`, `end`, `tickers_per_page`, `tie_method`, `normalize_price`
- 追加関数:
  - `build_rank_frames(score_hold, eligibility_hold, tie_method='min')`
  - `build_asset_panel_frame(result, context, panel_cfg)`
  - `plot_asset_quad_pages(panel_df, panel_cfg, title_prefix)`
  - `run_signal_panel(signal_name, params, context, selection_cfg, eval_cfg, panel_cfg)`

### 10.2 表示仕様（固定）
- x軸は保有月 `h` に統一。
- 1行目: 価格（`monthly_price` を `weights.index` に揃えて表示）
- 2行目: シグナル（`score_hold`）
- 3行目: 採択0/1（`selected_hold.astype(int)`）
- 4行目: 適格銘柄内ランク（`rank_hold`、上位=1を上側表示）
- ランク百分位（`rank_pct_hold`）は補助列として保持（デフォルト表示OFF）。

### 10.3 時点整合
- 形成月 `m` のシグナルを、保有月 `h=m+1` に整列して `score_hold` として保持。
- `form_month_by_hold[h] = m` を保存し、後から対応関係を検証可能。

### 10.4 Notebookでの利用手順
1. `panel_signal_name` と `panel_params` を設定。
2. `panel_cfg = PanelConfig(...)` を設定（`tickers=None` で全銘柄）。
3. `run_signal_panel(...)` を実行。
4. `panel_df` で元データ確認、図で価格/シグナル/採択/ランクを同時解釈。

### 10.5 解釈例
- 採択0/1が 1->0 に変化する直前で、ランクが悪化（数字が増加）しているかを確認。
- ランク劣化が起きずに離脱している場合、`eligibility` 条件側の失敗（`ELIG_FAIL`）を疑う。
- 価格とシグナルが乖離する局面を時系列で確認し、離脱理由の前兆として扱う。

### 10.6 追加検証結果
- `score/eligibility/selected/rank` の index/columns 整合を確認（PASS）。
- `form_month_by_hold` を使った `score_hold[h] == score[m]` を確認（PASS）。
- `selected_hold == (weights > 0)` を確認（PASS）。
- 非適格銘柄のランク `NaN`、適格銘柄ランク `>=1` を確認（PASS）。
- 同点シグナル境界（`tie_method='min'`）でランク1付与を確認（PASS）。
- 欠損シグナルを含むパネルでも描画継続を確認（PASS）。
- 全銘柄モードでページ出力が空でないことを確認（PASS）。
- `dual_baseline / st_wh_baseline / user_mom_turn_blend` の3戦略で `run_signal_panel` 再利用を確認（PASS）。
