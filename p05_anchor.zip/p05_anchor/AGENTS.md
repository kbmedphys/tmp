# Project Rules: p05_anchor

このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。
このプロジェクトの Prefer explicit python path は 
- envs/base/.venv/bin/python

---

## Source of truth
- docs/sources/*.pdf : authoritative documents
- docs/notes/*.md    : 検討中のアイデア（参考情報）
- notebooks/p00_dualmom.ipynb   : 戦略の雛形
- notebooks/p01_stmom.ipynb   : 戦略の雛形
- notebooks/p02_exit_attribution.ipynb   : 原因仮説アンカー分析の雛形
- *.ipynb            : single source of execution & inspection
  
---

## 0. 目的
本プロジェクトはテーマETF投資における原因仮説アンカーの候補を調査する
### 文献
- docs/sources
### アイデア（参考）
- docs/notes

---

## 1. 進め方
### Phase A: 文献レビューのみ（実装禁止）
- docs/sources/ の論文をレビューせよ
- docs/reviews/ に論文を精読し、必要な情報を日本語で1本のMarkdownに整理した review.md を作成
- docs/notes/ のドキュメントをレビューせよ
- docs/reviews/ にドキュメントを精読し、必要な情報を日本語で1本のMarkdownに整理した review.md を作成

### Phase B: 戦略雛形のレビュー(実装禁止)
- notebooks/ の内容を精読し、現在の戦略がどのように作られているか整理した review.md を作成

### Phase C: 原因仮説アンカーの候補(実装禁止)
- docs/ の内容を踏まえ、雛形戦略でポートフォリオに選ばれていた銘柄がどのようにポートフォリオから外れるのか特定し、どのようにアンカーを作成すべきか候補を整理した review.md を作成

### Phase D: 原因仮説アンカーの実装
- 原因仮説アンカーの分析を実施
- 結果の可視化を必ず行う

---

## 2. 注意（リーク防止）
- 特徴量は t までの情報で計算し、t+1 のリターン予測に使う
- 月次リバランスなら「月末で決めたwを翌営業日から適用」など実装上の時点整合を厳密化
- notebooks/ のファイルを編集するのは禁止
- レビューの際、必要に応じてリンク元の情報を参照せよ