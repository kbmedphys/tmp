"""CLI for classical Hawkes simulation runs."""

from __future__ import annotations

import argparse
import logging

import numpy as np

from qctsp.classical.hawkes_exp import simulate_hawkes_exp_ogata


LOGGER = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    """Build the command-line parser for the simulation entry point."""

    parser = argparse.ArgumentParser(description="Run classical Hawkes simulation.")
    parser.add_argument("--T", type=float, default=25.0, help="Simulation horizon.")
    parser.add_argument("--mu", type=float, default=0.6, help="Baseline intensity.")
    parser.add_argument("--alpha", type=float, default=0.3, help="Excitation weight.")
    parser.add_argument("--beta", type=float, default=1.2, help="Exponential decay.")
    parser.add_argument("--seed", type=int, default=7, help="Random seed.")
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Parse CLI arguments and run simulation workflow."""

    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    times = simulate_hawkes_exp_ogata(
        T=args.T,
        mu=args.mu,
        alpha=args.alpha,
        beta=args.beta,
        seed=args.seed,
    )
    count = int(times.size)
    if count > 0:
        inter_arrivals = np.diff(np.concatenate(([0.0], times)))
        mean_interarrival = float(np.mean(inter_arrivals))
        mean_interarrival_text = f"{mean_interarrival:.6f}"
    else:
        mean_interarrival_text = "n/a"

    LOGGER.info(
        "Simulated Hawkes events: count=%d, T=%.3f, mu=%.3f, alpha=%.3f, beta=%.3f, seed=%d",
        count,
        args.T,
        args.mu,
        args.alpha,
        args.beta,
        args.seed,
    )
    LOGGER.info("Mean inter-arrival (including start at t=0): %s", mean_interarrival_text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
