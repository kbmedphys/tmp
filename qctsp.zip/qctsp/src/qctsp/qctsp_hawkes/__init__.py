"""QCTSP-oriented Hawkes discretization and transition table interfaces."""

from .discretization import (
    build_eta_grid,
    build_tau_edges,
    build_tau_midpoints,
    tau_bin_representative_condexp,
    tau_bin_representative_midpoint,
)
from .transition_tables import (
    TransitionEntry,
    build_p_tau_given_x,
    build_transition_table,
    table_to_lookup,
)

__all__ = [
    "TransitionEntry",
    "build_eta_grid",
    "build_tau_edges",
    "build_tau_midpoints",
    "tau_bin_representative_condexp",
    "tau_bin_representative_midpoint",
    "build_p_tau_given_x",
    "build_transition_table",
    "table_to_lookup",
]
