"""Lookup-based transition-oracle helpers for QCTSP Hawkes circuits."""

from __future__ import annotations

from typing import Sequence

import numpy as np
from numpy.typing import NDArray
from qiskit import QuantumCircuit
from qiskit.circuit import Qubit

from qctsp.qctsp_hawkes.transition_tables import TransitionEntry


IntArray = NDArray[np.int64]


def _require_positive_int(name: str, value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise ValueError(f"{name} must be an integer.")
    if int(value) <= 0:
        raise ValueError(f"{name} must be > 0.")
    return int(value)


def _required_qubits(n_states: int) -> int:
    _require_positive_int(name="n_states", value=n_states)
    return int(np.ceil(np.log2(n_states)))


def _bits_little_endian(index: int, width: int) -> list[int]:
    return [(index >> bit) & 1 for bit in range(width)]


def _validate_transition_table(table: np.ndarray) -> IntArray:
    arr = np.asarray(table)
    if arr.ndim != 2:
        raise ValueError("transition_table must be a 2D array with shape [S, R].")
    if arr.shape[0] < 2 or arr.shape[1] < 2:
        raise ValueError("transition_table must have shape [S, R] with S>=2 and R>=2.")
    if not np.issubdtype(arr.dtype, np.integer):
        rounded = np.rint(arr).astype(np.int64)
        if not np.allclose(arr, rounded):
            raise ValueError("transition_table must contain integer indices.")
        arr = rounded
    arr_int = arr.astype(np.int64)
    if np.any(arr_int < 0) or np.any(arr_int >= arr_int.shape[0]):
        raise ValueError("transition_table entries must be in [0, S-1].")
    return arr_int


def _apply_control_pattern(circuit: QuantumCircuit, controls: Sequence[Qubit], pattern: Sequence[int]) -> None:
    if len(controls) != len(pattern):
        raise ValueError("control qubits and control bit pattern lengths must match.")
    for qubit, bit in zip(controls, pattern):
        if bit == 0:
            circuit.x(qubit)


def build_transition_lookup(entries: Sequence[TransitionEntry]) -> dict[str, float]:
    """Build a classical lookup keyed by 'source->target' from transition entries."""

    lookup: dict[str, float] = {}
    for entry in entries:
        source = int(entry["source_state"])
        target = int(entry["target_state"])
        probability = float(entry["probability"])
        lookup[f"{source}->{target}"] = probability
    return lookup


def append_transition_update(
    circuit: QuantumCircuit,
    x_prev_qubits: Sequence[Qubit],
    tau_qubits: Sequence[Qubit],
    x_next_qubits: Sequence[Qubit],
    transition_table: np.ndarray,
) -> None:
    """Append deterministic map |x>|tau>|0> -> |x>|tau>|x'(x,tau)>.

    This uses a straightforward lookup decomposition with multi-controlled X gates.
    It is correct for small S/R but scales as O(S * R * log2(S)).
    """

    table = _validate_transition_table(table=transition_table)
    controls_x = list(x_prev_qubits)
    controls_tau = list(tau_qubits)
    targets = list(x_next_qubits)

    n_x_required = _required_qubits(n_states=table.shape[0])
    n_tau_required = _required_qubits(n_states=table.shape[1])
    if len(controls_x) != n_x_required:
        raise ValueError(f"x_prev register size must be {n_x_required} qubits.")
    if len(controls_tau) != n_tau_required:
        raise ValueError(f"tau register size must be {n_tau_required} qubits.")
    if len(targets) != n_x_required:
        raise ValueError(f"x_next register size must be {n_x_required} qubits.")

    controls = controls_x + controls_tau

    for x_idx in range(table.shape[0]):
        x_bits = _bits_little_endian(index=x_idx, width=n_x_required)
        for tau_idx in range(table.shape[1]):
            tau_bits = _bits_little_endian(index=tau_idx, width=n_tau_required)
            control_pattern = x_bits + tau_bits
            _apply_control_pattern(circuit=circuit, controls=controls, pattern=control_pattern)

            x_next_idx = int(table[x_idx, tau_idx])
            for out_bit, out_value in enumerate(_bits_little_endian(x_next_idx, n_x_required)):
                if out_value == 1:
                    circuit.mcx(control_qubits=controls, target_qubit=targets[out_bit])

            _apply_control_pattern(circuit=circuit, controls=controls, pattern=control_pattern)


__all__ = ["append_transition_update", "build_transition_lookup"]
