"""Circuit-oriented lookup helpers for QCTSP table-driven construction."""

from .state_prep_lookup import append_conditional_tau_preparation, build_state_prep_lookup
from .transition_lookup import append_transition_update, build_transition_lookup
from .unroll import (
    ParsedQCTSPSample,
    QCTSPMeasurementLayout,
    build_qctsp_unroll_circuit,
    build_unroll_plan,
    encode_qctsp_sample,
    parse_qctsp_bitstring,
    parse_qctsp_counts,
    sample_qctsp_classically,
    samples_to_counts,
)

__all__ = [
    "ParsedQCTSPSample",
    "QCTSPMeasurementLayout",
    "append_conditional_tau_preparation",
    "append_transition_update",
    "build_qctsp_unroll_circuit",
    "build_state_prep_lookup",
    "build_transition_lookup",
    "build_unroll_plan",
    "encode_qctsp_sample",
    "parse_qctsp_bitstring",
    "parse_qctsp_counts",
    "sample_qctsp_classically",
    "samples_to_counts",
]
