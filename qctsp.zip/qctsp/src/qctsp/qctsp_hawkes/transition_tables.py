"""Transition/distribution table builders for the Hawkes QCTSP prototype."""

from __future__ import annotations

from typing import Sequence, TypedDict

import numpy as np
from numpy.typing import NDArray


FloatArray = NDArray[np.float64]
IntArray = NDArray[np.int64]


class TransitionEntry(TypedDict):
    """Compatibility type for circuit lookup stubs."""

    source_state: int
    target_state: int
    probability: float


def _validate_eta_grid(eta_grid: np.ndarray) -> FloatArray:
    eta = np.asarray(eta_grid, dtype=np.float64)
    if eta.ndim != 1:
        raise ValueError("eta_grid must be a 1D array.")
    if eta.size < 2:
        raise ValueError("eta_grid must contain at least 2 bins.")
    if not np.all(np.isfinite(eta)):
        raise ValueError("eta_grid must contain finite values.")
    if np.any(eta < 0.0):
        raise ValueError("eta_grid must be non-negative.")
    if np.any(np.diff(eta) <= 0.0):
        raise ValueError("eta_grid must be strictly increasing.")
    return eta


def _validate_tau_edges(tau_edges: np.ndarray) -> FloatArray:
    edges = np.asarray(tau_edges, dtype=np.float64)
    if edges.ndim != 1:
        raise ValueError("tau_edges must be a 1D array.")
    if edges.size < 3:
        raise ValueError("tau_edges must have length >= 3 (R+1 with R>=2).")
    if not np.all(np.isfinite(edges[:-1])):
        raise ValueError("All tau edges except the last must be finite.")
    if not np.isinf(edges[-1]):
        raise ValueError("The last tau edge must be +inf for the tail-bin convention.")
    if np.any(np.diff(edges[:-1]) <= 0.0):
        raise ValueError("Finite tau edges must be strictly increasing.")
    if edges[0] < 0.0:
        raise ValueError("tau_edges must start from a non-negative value.")
    return edges


def _validate_tau_midpoints(tau_mid: np.ndarray) -> FloatArray:
    mids = np.asarray(tau_mid, dtype=np.float64)
    if mids.ndim != 1:
        raise ValueError("tau_mid must be a 1D array.")
    if mids.size < 2:
        raise ValueError("tau_mid must contain at least 2 bins.")
    if not np.all(np.isfinite(mids)):
        raise ValueError("tau_mid must contain finite values.")
    if np.any(mids < 0.0):
        raise ValueError("tau_mid must be non-negative.")
    if np.any(np.diff(mids) <= 0.0):
        raise ValueError("tau_mid must be strictly increasing.")
    return mids


def _validate_mu_alpha(mu: float, alpha: float) -> tuple[float, float]:
    if not np.isfinite(mu) or mu <= 0.0:
        raise ValueError("mu must be a finite positive float.")
    if not np.isfinite(alpha) or alpha < 0.0:
        raise ValueError("alpha must be a finite non-negative float.")
    return float(mu), float(alpha)


def _validate_alpha_beta(alpha: float, beta: float) -> tuple[float, float]:
    if not np.isfinite(alpha) or alpha < 0.0:
        raise ValueError("alpha must be a finite non-negative float.")
    if not np.isfinite(beta) or beta <= 0.0:
        raise ValueError("beta must be a finite positive float.")
    return float(alpha), float(beta)


def _quantize_to_nearest_bin(values: FloatArray, grid: FloatArray) -> IntArray:
    """Quantize each value to the nearest grid index (ties go to lower index)."""

    flat_values = np.asarray(values, dtype=np.float64).reshape(-1)
    insert_idx = np.searchsorted(grid, flat_values, side="left")
    insert_idx = np.clip(insert_idx, 1, grid.size - 1)

    left_idx = insert_idx - 1
    right_idx = insert_idx
    left_dist = np.abs(flat_values - grid[left_idx])
    right_dist = np.abs(flat_values - grid[right_idx])
    choose_right = right_dist < left_dist
    nearest = np.where(choose_right, right_idx, left_idx)
    return nearest.astype(np.int64)


def build_p_tau_given_x(
    eta_grid: np.ndarray,
    tau_edges: np.ndarray,
    mu: float,
    alpha: float,
) -> FloatArray:
    """Build p_tau_given_x[S, R] from Exp(lambda(x)) with a tail last bin.

    We use lambda(x) = mu + alpha * eta(x), with tau bins:
    [e_0, e_1), ..., [e_{R-2}, e_{R-1}), [e_{R-1}, +inf).
    This guarantees each row sums to 1 up to floating-point error.
    """

    eta = _validate_eta_grid(eta_grid=eta_grid)
    edges = _validate_tau_edges(tau_edges=tau_edges)
    baseline, excitation = _validate_mu_alpha(mu=mu, alpha=alpha)

    rates = baseline + excitation * eta
    n_states = eta.size
    n_tau_bins = edges.size - 1
    probs = np.empty((n_states, n_tau_bins), dtype=np.float64)

    if n_tau_bins > 1:
        lower_finite = edges[:-2][None, :]
        upper_finite = edges[1:-1][None, :]
        rates_col = rates[:, None]
        probs[:, :-1] = np.exp(-rates_col * lower_finite) - np.exp(-rates_col * upper_finite)

    probs[:, -1] = np.exp(-rates * edges[-2])
    np.maximum(probs, 0.0, out=probs)
    return probs


def build_transition_table(
    eta_grid: np.ndarray,
    tau_mid: np.ndarray,
    alpha: float,
    beta: float,
) -> IntArray:
    """Build trans[S, R] mapping state index x and tau-bin r to next index x'.

    Update rule:
      eta_next = eta(x) * exp(-beta * tau_mid(r)) + 1
    and x' is the nearest eta-bin index.

    Note: alpha is validated but not used in this eta-only transition map.
    Quantization can create plateaus in r -> x' even when eta_next strictly decreases.
    """

    eta = _validate_eta_grid(eta_grid=eta_grid)
    mids = _validate_tau_midpoints(tau_mid=tau_mid)
    _, decay = _validate_alpha_beta(alpha=alpha, beta=beta)

    eta_next = eta[:, None] * np.exp(-decay * mids[None, :]) + 1.0
    quantized = _quantize_to_nearest_bin(values=eta_next, grid=eta)
    return quantized.reshape(eta.size, mids.size)


def table_to_lookup(entries: Sequence[TransitionEntry]) -> dict[tuple[int, int], float]:
    """Convert TransitionEntry items into a (source, target) -> probability dict."""

    lookup: dict[tuple[int, int], float] = {}
    for entry in entries:
        key = (int(entry["source_state"]), int(entry["target_state"]))
        lookup[key] = float(entry["probability"])
    return lookup


__all__ = [
    "TransitionEntry",
    "build_p_tau_given_x",
    "build_transition_table",
    "table_to_lookup",
]
