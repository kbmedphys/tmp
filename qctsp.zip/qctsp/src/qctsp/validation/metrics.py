"""Validation metrics for classical-vs-qctsp Hawkes comparisons."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

import numpy as np
from numpy.typing import NDArray

from qctsp.classical.hawkes_exp import hawkes_ks_test_exp1, hawkes_time_rescaling_z


FloatArray = NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class ValidationSummary:
    """Container for aggregate validation metrics on paired samples."""

    mae: float
    rmse: float
    divergence: float


@dataclass(frozen=True, slots=True)
class PathMetrics:
    """Per-path scalar metrics used for distribution-level comparison."""

    N_T: int
    inter_arrival_mean: float | None
    inter_arrival_var: float | None
    ks_pvalue: float | None
    I_eta: float
    I_lambda: float


def _to_1d_float_array(values: Sequence[float], name: str) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float64)
    if arr.ndim != 1:
        raise ValueError(f"{name} must be 1D.")
    if not np.all(np.isfinite(arr)):
        raise ValueError(f"{name} must contain finite values.")
    return arr


def _to_json_float(value: float) -> float:
    return float(value)


def _validate_eta_tau_sequences(eta_seq: np.ndarray, tau_seq: np.ndarray) -> tuple[FloatArray, FloatArray]:
    eta = np.asarray(eta_seq, dtype=np.float64)
    tau = np.asarray(tau_seq, dtype=np.float64)
    if eta.ndim != 1 or tau.ndim != 1:
        raise ValueError("eta_seq and tau_seq must be 1D arrays.")
    if eta.size != tau.size:
        raise ValueError("eta_seq and tau_seq must have the same length.")
    if not np.all(np.isfinite(eta)) or not np.all(np.isfinite(tau)):
        raise ValueError("eta_seq and tau_seq must contain finite values.")
    if np.any(eta < 0.0):
        raise ValueError("eta_seq must be non-negative.")
    if np.any(tau < 0.0):
        raise ValueError("tau_seq must be non-negative.")
    return eta, tau


def integral_eta_rect(eta_seq: np.ndarray, tau_seq: np.ndarray) -> float:
    """Rectangle-rule approximation of integral eta(t) dt from stepwise sequences."""

    eta, tau = _validate_eta_tau_sequences(eta_seq=eta_seq, tau_seq=tau_seq)
    if eta.size == 0:
        return 0.0
    return float(np.sum(eta * tau, dtype=np.float64))


def integral_lambda_rect(mu: float, alpha: float, eta_seq: np.ndarray, tau_seq: np.ndarray) -> float:
    """Rectangle-rule approximation of integral lambda(t) dt with lambda=mu+alpha*eta."""

    if not np.isfinite(mu) or mu <= 0.0:
        raise ValueError("mu must be a finite positive float.")
    if not np.isfinite(alpha) or alpha < 0.0:
        raise ValueError("alpha must be a finite non-negative float.")

    eta, tau = _validate_eta_tau_sequences(eta_seq=eta_seq, tau_seq=tau_seq)
    if eta.size == 0:
        return 0.0
    return float(np.sum((mu + alpha * eta) * tau, dtype=np.float64))


def _classical_rect_sequences_from_times(times: np.ndarray, T: float, beta: float) -> tuple[FloatArray, FloatArray]:
    """Build rectangle sequences on [0,T] from event times.

    Convention:
    - Interval [0, t1): eta=0
    - For each event at t_i, use eta just after event i on [t_i, t_{i+1})
      and on [t_n, T] for the final segment.
    This yields tau segments that cover [0,T].
    """

    arr = np.asarray(times, dtype=np.float64)
    if arr.ndim != 1:
        raise ValueError("times must be a 1D array.")
    if not np.isfinite(T) or T <= 0.0:
        raise ValueError("T must be a finite positive float.")
    if not np.isfinite(beta) or beta <= 0.0:
        raise ValueError("beta must be a finite positive float.")

    if arr.size == 0:
        return np.asarray([0.0], dtype=np.float64), np.asarray([float(T)], dtype=np.float64)

    arr = np.sort(arr)
    arr = arr[(arr > 0.0) & (arr <= T)]
    if arr.size == 0:
        return np.asarray([0.0], dtype=np.float64), np.asarray([float(T)], dtype=np.float64)

    n_events = int(arr.size)
    eta_after = np.empty(n_events, dtype=np.float64)
    prev_time = 0.0
    eta_after_prev = 0.0
    for idx, t_i in enumerate(arr):
        dt = t_i - prev_time
        eta_before = eta_after_prev * np.exp(-beta * dt)
        eta_after[idx] = eta_before + 1.0
        prev_time = float(t_i)
        eta_after_prev = eta_after[idx]

    tau = np.empty(n_events + 1, dtype=np.float64)
    eta = np.empty(n_events + 1, dtype=np.float64)
    tau[0] = arr[0]
    eta[0] = 0.0
    if n_events > 1:
        tau[1:n_events] = np.diff(arr)
    tau[n_events] = max(float(T - arr[-1]), 0.0)
    eta[1:] = eta_after
    return eta, tau


def _summarize_scalar_samples(samples: Sequence[float | int]) -> dict[str, Any]:
    if len(samples) == 0:
        return {"mean": None, "var": None, "samples": []}
    arr = np.asarray(samples, dtype=np.float64)
    return {
        "mean": _to_json_float(np.mean(arr)),
        "var": _to_json_float(np.var(arr)),
        "samples": [float(v) for v in arr.tolist()],
    }


def _summarize_integer_samples(samples: Sequence[int]) -> dict[str, Any]:
    summary = _summarize_scalar_samples(samples=samples)
    summary["samples"] = [int(v) for v in samples]
    return summary


def _summarize_optional_samples(samples: Sequence[float | None]) -> dict[str, Any]:
    valid = [float(v) for v in samples if v is not None]
    base = _summarize_scalar_samples(samples=valid)
    base["n_valid"] = int(len(valid))
    base["n_total"] = int(len(samples))
    return base


def compute_validation_summary(
    reference: Sequence[float], candidate: Sequence[float]
) -> ValidationSummary:
    """Compute simple paired-sequence comparison metrics."""

    ref = _to_1d_float_array(values=reference, name="reference")
    cand = _to_1d_float_array(values=candidate, name="candidate")
    if ref.size != cand.size:
        raise ValueError("reference and candidate must have the same length.")

    diff = cand - ref
    mae = float(np.mean(np.abs(diff)))
    rmse = float(np.sqrt(np.mean(diff * diff)))
    divergence = float(abs(np.mean(cand) - np.mean(ref)))
    return ValidationSummary(mae=mae, rmse=rmse, divergence=divergence)


def compute_path_metrics(
    times: np.ndarray,
    T: float,
    mu: float,
    alpha: float,
    beta: float,
    eta_seq: np.ndarray | None = None,
    tau_seq: np.ndarray | None = None,
) -> PathMetrics:
    """Compute per-path Hawkes metrics used in comparison reports."""

    arr = np.asarray(times, dtype=np.float64)
    if arr.ndim != 1:
        raise ValueError("times must be a 1D array.")
    if arr.size > 0:
        arr = np.sort(arr)
        arr = arr[(arr > 0.0) & (arr <= T)]

    N_T = int(arr.size)
    if N_T >= 2:
        inter = np.diff(arr)
        inter_mean = float(np.mean(inter))
        inter_var = float(np.var(inter))
    else:
        inter_mean = None
        inter_var = None

    zs = hawkes_time_rescaling_z(times=arr, mu=mu, alpha=alpha, beta=beta)
    ks = hawkes_ks_test_exp1(zs=zs)
    ks_pvalue = None if ks is None else float(ks[1])

    if (eta_seq is None) != (tau_seq is None):
        raise ValueError("eta_seq and tau_seq must be provided together.")
    if eta_seq is None or tau_seq is None:
        rect_eta, rect_tau = _classical_rect_sequences_from_times(times=arr, T=T, beta=beta)
    else:
        rect_eta, rect_tau = _validate_eta_tau_sequences(eta_seq=eta_seq, tau_seq=tau_seq)
    I_eta = integral_eta_rect(eta_seq=rect_eta, tau_seq=rect_tau)
    I_lambda = integral_lambda_rect(mu=mu, alpha=alpha, eta_seq=rect_eta, tau_seq=rect_tau)

    return PathMetrics(
        N_T=N_T,
        inter_arrival_mean=inter_mean,
        inter_arrival_var=inter_var,
        ks_pvalue=ks_pvalue,
        I_eta=I_eta,
        I_lambda=I_lambda,
    )


def summarize_path_metrics(
    path_metrics: Sequence[PathMetrics],
    count_key: str,
) -> dict[str, Any]:
    """Aggregate per-path metrics into a JSON-serializable summary."""

    n_value = int(len(path_metrics))
    return {
        count_key: n_value,
        "N_T": _summarize_integer_samples([m.N_T for m in path_metrics]),
        "inter_arrival_mean": _summarize_optional_samples([m.inter_arrival_mean for m in path_metrics]),
        "inter_arrival_var": _summarize_optional_samples([m.inter_arrival_var for m in path_metrics]),
        "ks_pvalue": _summarize_optional_samples([m.ks_pvalue for m in path_metrics]),
        "I_eta": _summarize_scalar_samples([m.I_eta for m in path_metrics]),
        "I_lambda": _summarize_scalar_samples([m.I_lambda for m in path_metrics]),
    }


__all__ = [
    "PathMetrics",
    "ValidationSummary",
    "compute_path_metrics",
    "compute_validation_summary",
    "integral_eta_rect",
    "integral_lambda_rect",
    "summarize_path_metrics",
]
