"""Validation helpers for comparing classical and qctsp outputs."""

from .compare import (
    ComparisonArtifacts,
    ComparisonConfig,
    build_comparison_report,
    build_qctsp_tau_debug,
    compare_samples,
    run_validation_comparison,
    save_comparison_report,
    save_json_artifact,
)
from .metrics import (
    PathMetrics,
    ValidationSummary,
    compute_path_metrics,
    compute_validation_summary,
    integral_eta_rect,
    integral_lambda_rect,
    summarize_path_metrics,
)

__all__ = [
    "ComparisonArtifacts",
    "ComparisonConfig",
    "PathMetrics",
    "ValidationSummary",
    "build_comparison_report",
    "build_qctsp_tau_debug",
    "compute_path_metrics",
    "compare_samples",
    "compute_validation_summary",
    "integral_eta_rect",
    "integral_lambda_rect",
    "run_validation_comparison",
    "save_comparison_report",
    "save_json_artifact",
    "summarize_path_metrics",
]
