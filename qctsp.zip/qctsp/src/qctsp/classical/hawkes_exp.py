"""Classical 1D Hawkes process with exponential kernel."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray
from scipy.optimize import OptimizeResult, minimize


FloatArray = NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class HawkesParams:
    """Parameters for a 1D exponential Hawkes process."""

    mu: float
    alpha: float
    beta: float


def _validate_horizon(T: float) -> float:
    if not np.isfinite(T) or T <= 0.0:
        raise ValueError("T must be a finite positive float.")
    return float(T)


def _validate_params(mu: float, alpha: float, beta: float) -> None:
    if not np.isfinite(mu) or mu <= 0.0:
        raise ValueError("mu must be a finite positive float.")
    if not np.isfinite(alpha) or alpha < 0.0:
        raise ValueError("alpha must be a finite non-negative float.")
    if not np.isfinite(beta) or beta <= 0.0:
        raise ValueError("beta must be a finite positive float.")


def _validate_times(times: np.ndarray, T: float | None = None) -> FloatArray:
    arr = np.asarray(times, dtype=np.float64)
    if arr.ndim != 1:
        raise ValueError("times must be a 1D array.")
    if arr.size == 0:
        return arr
    if not np.all(np.isfinite(arr)):
        raise ValueError("times must contain only finite values.")
    if np.any(arr <= 0.0):
        raise ValueError("times must be in (0, T].")
    if np.any(np.diff(arr) <= 0.0):
        raise ValueError("times must be strictly increasing.")
    if T is not None and arr[-1] > T:
        raise ValueError("times must be in (0, T].")
    return arr


def _stability_penalty(alpha: float, beta: float) -> float:
    ratio = alpha / beta
    slope = 25.0
    strength = 1.0e4
    soft_hinge = np.logaddexp(0.0, slope * (ratio - 1.0)) / slope
    return float(strength * soft_hinge * soft_hinge)


def simulate_hawkes_exp_ogata(
    T: float,
    mu: float,
    alpha: float,
    beta: float,
    seed: int | None = None,
) -> FloatArray:
    """Simulate event times with Ogata's thinning algorithm."""

    horizon = _validate_horizon(T)
    _validate_params(mu=mu, alpha=alpha, beta=beta)

    rng = np.random.default_rng(seed)
    t = 0.0
    eta = 0.0
    events: list[float] = []

    while True:
        lambda_upper = mu + alpha * eta
        wait = rng.exponential(scale=1.0 / lambda_upper)
        t_candidate = t + wait
        if t_candidate > horizon:
            break

        eta_candidate = eta * np.exp(-beta * wait)
        lambda_candidate = mu + alpha * eta_candidate
        if rng.random() <= (lambda_candidate / lambda_upper):
            events.append(t_candidate)
            t = t_candidate
            eta = eta_candidate + 1.0
        else:
            t = t_candidate
            eta = eta_candidate

    return np.asarray(events, dtype=np.float64)


def hawkes_loglik_exp_1d(
    times: np.ndarray,
    T: float,
    mu: float,
    alpha: float,
    beta: float,
) -> float:
    """Compute log-likelihood of observed times under exponential Hawkes."""

    horizon = _validate_horizon(T)
    _validate_params(mu=mu, alpha=alpha, beta=beta)
    obs = _validate_times(times=times, T=horizon)

    if obs.size == 0:
        return float(-mu * horizon)

    log_intensity_sum = 0.0
    prev_time = 0.0
    eta_after_prev = 0.0
    for t_i in obs:
        dt = t_i - prev_time
        eta_before = eta_after_prev * np.exp(-beta * dt)
        lambda_i = mu + alpha * eta_before
        log_intensity_sum += np.log(lambda_i)

        eta_after_prev = eta_before + 1.0
        prev_time = float(t_i)

    compensator = mu * horizon + (alpha / beta) * np.sum(
        1.0 - np.exp(-beta * (horizon - obs)),
        dtype=np.float64,
    )
    return float(log_intensity_sum - compensator)


def fit_hawkes_exp_mle(
    times: np.ndarray,
    T: float,
    init: HawkesParams,
) -> tuple[HawkesParams, OptimizeResult]:
    """Fit exponential Hawkes parameters by MLE with log-parameterization."""

    horizon = _validate_horizon(T)
    obs = _validate_times(times=times, T=horizon)
    _validate_params(mu=init.mu, alpha=init.alpha, beta=init.beta)

    eps = 1.0e-12
    x0 = np.log(
        np.array(
            [
                max(init.mu, eps),
                max(init.alpha, eps),
                max(init.beta, eps),
            ],
            dtype=np.float64,
        )
    )

    def objective(theta: FloatArray) -> float:
        mu_hat = float(np.exp(theta[0]))
        alpha_hat = float(np.exp(theta[1]))
        beta_hat = float(np.exp(theta[2]))
        loglik = hawkes_loglik_exp_1d(
            times=obs,
            T=horizon,
            mu=mu_hat,
            alpha=alpha_hat,
            beta=beta_hat,
        )
        if not np.isfinite(loglik):
            return 1.0e20
        penalty = _stability_penalty(alpha=alpha_hat, beta=beta_hat)
        return float(-loglik + penalty)

    result = minimize(
        objective,
        x0=x0,
        method="L-BFGS-B",
    )

    fitted = HawkesParams(
        mu=float(np.exp(result.x[0])),
        alpha=float(np.exp(result.x[1])),
        beta=float(np.exp(result.x[2])),
    )
    return fitted, result


def hawkes_time_rescaling_z(
    times: np.ndarray,
    mu: float,
    alpha: float,
    beta: float,
) -> FloatArray:
    """Return compensator increments z_i used by the time-rescaling theorem."""

    _validate_params(mu=mu, alpha=alpha, beta=beta)
    obs = _validate_times(times=times, T=None)
    if obs.size == 0:
        return np.asarray([], dtype=np.float64)

    zs = np.empty(obs.size, dtype=np.float64)
    prev_time = 0.0
    eta_after_prev = 0.0
    for idx, t_i in enumerate(obs):
        dt = t_i - prev_time
        decay = np.exp(-beta * dt)
        zs[idx] = mu * dt + (alpha / beta) * eta_after_prev * (1.0 - decay)

        eta_before = eta_after_prev * decay
        eta_after_prev = eta_before + 1.0
        prev_time = float(t_i)

    return zs


def hawkes_ks_test_exp1(zs: np.ndarray) -> tuple[float, float] | None:
    """Run a one-sample KS test against Exp(1) on time-rescaled samples."""

    from scipy.stats import kstest

    arr = np.asarray(zs, dtype=np.float64)
    if arr.ndim != 1:
        raise ValueError("zs must be a 1D array.")
    if arr.size < 2:
        return None
    if not np.all(np.isfinite(arr)):
        raise ValueError("zs must contain only finite values.")
    if np.any(arr < 0.0):
        raise ValueError("zs must contain only non-negative values.")

    result = kstest(arr, "expon")
    return float(result.statistic), float(result.pvalue)


__all__ = [
    "HawkesParams",
    "fit_hawkes_exp_mle",
    "hawkes_ks_test_exp1",
    "hawkes_loglik_exp_1d",
    "hawkes_time_rescaling_z",
    "simulate_hawkes_exp_ogata",
]
