"""Typed configuration models used across the qctsp project."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class HawkesConfig:
    """Configuration for exponential Hawkes process simulation and fitting."""

    baseline: float
    alpha: float
    beta: float
    horizon: float
    seed: int | None = None


@dataclass(frozen=True, slots=True)
class DiscretizationConfig:
    """Configuration for mapping continuous process states onto discrete bins."""

    n_time_bins: int
    n_intensity_bins: int
    max_intensity: float


@dataclass(frozen=True, slots=True)
class QCTSPConfig:
    """Top-level configuration shared by scripts, notebooks, and tests."""

    hawkes: HawkesConfig
    discretization: DiscretizationConfig
    outputs_dir: Path = Path("outputs")
