# qctsp

qctsp is a scaffold for comparing a classical exponential Hawkes process baseline against a quantum-compatible CTSP formulation.

## Purpose

- Provide a clear module layout for classical simulation, QCTSP table construction, and validation.
- Keep algorithms separated from orchestration scripts and notebooks.
- Reserve `outputs/` for generated artifacts.

## Setup

1. Use the shared environment at `../../envs/qc`.
2. Sync dependencies with uv (no direct pip):

```bash
uv sync --project ../../envs/qc
```

3. Run commands with the qc interpreter:

```bash
../../envs/qc/.venv/bin/python --version
```

## Quickstart

```bash
../../envs/qc/.venv/bin/python scripts/run_simulate_classical.py --help
../../envs/qc/.venv/bin/python scripts/run_fit_classical.py --help
../../envs/qc/.venv/bin/python scripts/run_build_tables.py --help
../../envs/qc/.venv/bin/python scripts/run_sample_qctsp.py --help
../../envs/qc/.venv/bin/python scripts/run_compare.py --help
../../envs/qc/.venv/bin/python -m pytest
```

## Acceptance Criteria (placeholders)

- [ ] Classical Hawkes simulation produces reproducible trajectories from fixed seeds.
- [ ] QCTSP transition/state-preparation tables are generated and validated.
- [ ] Qiskit sampling flow runs end-to-end for a smoke-size problem.
- [ ] Validation report compares classical and QCTSP outputs with agreed metrics.
