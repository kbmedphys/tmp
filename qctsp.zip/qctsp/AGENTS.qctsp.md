# AGENTS.qctsp.md

This file defines project-specific rules for `qctsp` and inherits all workspace rules from `../../AGENTS.md`.

## Environment

- Use `../../envs/qc/.venv/bin/python` for Python commands.
- Use `uv` for dependency management.
- Do not run `pip install` directly.
- If a new dependency is required, propose adding it in `../../envs/qc` via `uv add`.

## Outputs

- Save figures, tables, logs, and generated reports under `outputs/`.
- Keep source-controlled scaffolding lightweight; do not commit bulky generated artifacts unless requested.

## Module responsibilities

- `src/qctsp/config.py`: typed configuration models shared across scripts.
- `src/qctsp/classical/hawkes_exp.py`: classical exponential Hawkes simulation and fitting APIs.
- `src/qctsp/qctsp_hawkes/discretization.py`: map continuous process states to discrete bins.
- `src/qctsp/qctsp_hawkes/transition_tables.py`: build lookup-friendly transition/state tables.
- `src/qctsp/qctsp_hawkes/circuits/`: quantum-circuit lookup and unrolling utilities.
- `src/qctsp/validation/`: metric computation and classical-vs-qctsp comparison helpers.
- `scripts/`: thin CLI entry points for reproducible runs.
- `notebooks/`: exploratory and reporting notebooks.
- `tests/`: focused unit and smoke tests.
