# 10 Hawkes Classical

## Goal

Describe the classical exponential Hawkes baseline interface and expected data flow.

## Planned API

- `simulate_hawkes_exp(config) -> list[float]`
- `fit_hawkes_exp(events, horizon) -> HawkesFitResult`

## Notes

Implementation is intentionally deferred; this document tracks assumptions and validation checks.
