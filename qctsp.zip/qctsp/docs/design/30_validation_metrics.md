# 30 Validation Metrics

## Goal

Define metrics for comparing classical and QCTSP sample behavior.

## Candidate metrics

- Mean absolute error (MAE)
- Root mean squared error (RMSE)
- Divergence metrics (placeholder)

## Reporting

Metrics are aggregated into a typed summary object and surfaced by compare scripts/notebooks.
