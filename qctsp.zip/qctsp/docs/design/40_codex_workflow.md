# 40 Codex Workflow

## Loop

1. Fill algorithm stubs in small increments.
2. Add/adjust tests before broad refactors.
3. Run scripts/notebooks for smoke validation.
4. Save generated outputs under `outputs/`.

## Guardrails

- Keep package APIs typed and documented.
- Keep scripts as thin orchestrators.
- Keep implementation details inside `src/qctsp/`.
