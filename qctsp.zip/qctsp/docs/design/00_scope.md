# 00 Scope

## Objective

Define the first implementation slice for the classical Hawkes baseline and QCTSP pipeline scaffold.

## In scope

- Project structure and module boundaries.
- API stubs with type hints.
- Script/notebook entry points.

## Out of scope

- Full Hawkes estimation implementation.
- Full quantum circuit implementation.
- Benchmark-quality experiments.
