# 20 Hawkes QCTSP Spec

## Goal

Specify how Hawkes process states are discretized and encoded for QCTSP lookup tables.

## Planned components

- State discretization bins.
- Transition probability table generation.
- Circuit lookup helpers for state preparation and transitions.

## Open questions

- Bin-count selection strategy.
- Error bounds from discretization.
