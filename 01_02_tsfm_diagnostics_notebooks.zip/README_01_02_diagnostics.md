# Updated diagnostics for 01/02 Theme Factor Momentum notebooks

## Files

- `01_binary_tsfm_12m_diagnostics.ipynb`: Binary 12M TSFM with Barra orthogonality and autocorrelation diagnostics.
- `02_vol_scaled_tsfm_diagnostics.ipynb`: Vol-scaled 12M TSFM with the same diagnostics and Gupta-Kelly continuous TSFM windows.

## Real data input

Set `use_synthetic_data=False` in the configuration cell and provide either:

### Preferred: `data/theme_factor_inputs.pkl`

A dictionary with:

```python
{
    'purified_theme_factor_returns': DataFrame,  # required, monthly returns, month-end index
    'barra_factor_returns': DataFrame,           # optional, monthly Barra factor returns
    'B_by_date': dict[Timestamp, DataFrame],     # optional but required for strict orthogonality diagnostics
    'X_by_date': dict[Timestamp, DataFrame],     # optional raw theme exposures
    'Z_by_date': dict[Timestamp, DataFrame],     # optional purified theme exposures
    'M_by_date': dict[Timestamp, DataFrame],     # optional mimicking portfolio weights
}
```

### CSV fallback

- `data/purified_theme_factor_returns.csv`
- optional `data/barra_factor_returns.csv`
- optional `data/barra_orthogonality_inputs.pkl` containing `B_by_date`, `X_by_date`, `Z_by_date`, optional `M_by_date`.

## Diagnostics implemented

1. Exposure-level Barra orthogonality:
   \(B_t'W_tZ_t \approx 0\), shown as raw-vs-purified weighted cosine heatmaps.
2. Mimicking portfolio neutrality:
   \(m_k'B_t\approx0\), \(m_k'Z_t\approx e_k'\), \(\mathbf{1}'m_k\approx0\).
3. Final strategy portfolio Barra exposure:
   \((w_t^{stock})'B_t\) through time.
4. Return-level auxiliary Barra spanning regression:
   \(g_{k,t}=\alpha_k+\beta_k'F_t^{Barra}+\epsilon_{k,t}\).
5. Gupta-Kelly-style AR(1):
   \(g_{k,t}=a_k+\rho_k g_{k,t-1}+\epsilon_{k,t}\).
6. Ehsani-Linnainmaa return-on-sign:
   \(g_{k,t}=\alpha_k+\beta_k\mathbf{1}[M_{k,t-1}^{12}>0]+\epsilon_{k,t}\).
7. Ehsani-Linnainmaa return-on-return:
   \(g_{k,t}=\alpha_k+\beta_k\bar g_{k,t-12:t-1}+\epsilon_{k,t}\).
8. Binary and vol-scaled TSFM realized returns.
9. Gupta-Kelly continuous TSFM windows in the 02 notebook.

The notebooks are self-contained and have been executed on synthetic data so all step outputs and charts are visible.