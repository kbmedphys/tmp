from __future__ import annotations

import json
import math
import pickle
import warnings
from pathlib import Path
from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Markdown

pd.options.display.max_rows = 30
pd.options.display.max_columns = 40
warnings.filterwarnings("ignore", category=RuntimeWarning)


@dataclass
class Config:
    # Data
    input_pickle: str = "data/theme_factor_inputs.pkl"
    output_dir: str = "theme_factor_momentum_outputs"
    use_synthetic_if_missing: bool = True
    random_seed: int = 42
    n_months: int = 120
    n_stocks: int = 160
    n_barra: int = 6
    n_themes: int = 14
    start_date: str = "2010-01-31"

    # Estimation
    ridge: float = 1e-6
    pinv_rcond: float = 1e-10
    include_intercept_in_barra: bool = True
    theme_return_ridge_alpha: float = 1e-6
    min_history_months: int = 24
    risk_lookback_months: int = 36

    # Momentum formation
    formation_months: int = 12
    skip_recent_months_for_stock_mom: int = 1
    stock_mom_lookback_months: int = 11
    continuous_clip: float = 2.0

    # Existing stock-level implementation
    mimicking_mode: str = "coefficient"
    target_stock_gross: float = 1.0
    transaction_cost_bps_one_way: float = 10.0
    annualization: int = 12
    top_n_pc: int = 5
    max_weight_table_rows: int = 10

    # Tradeable theme-basket input
    theme_basket_weights_key: str = "theme_basket_weights_by_date"
    basket_fallback_to_theme_exposures: bool = True  # Demo/backward compatibility only
    basket_require_long_only_base: bool = True
    basket_column_sum_target: float = 1.0
    basket_min_constituents: int = 5
    basket_min_return_coverage: float = 0.98

    # Basket L/S replication
    basket_replication_mode: str = "constrained_risk_projection"
    basket_ridge_alpha: float = 1e-6
    basket_risk_model: str = "diagonal_variance"
    basket_enforce_neutrality: bool = True
    basket_enforce_target_exposure: bool = True
    basket_target_exposure: float = 1.0
    basket_soft_neutrality_penalty: float = 1e4
    basket_soft_target_penalty: float = 1e4
    basket_offtheme_penalty: float = 0.0

    # Optional investable constraints; disabled for the main coefficient-scale comparison
    basket_require_own_theme_long: bool = False
    basket_min_own_theme_weight: float = 0.0
    basket_gross_cap: float | None = None
    basket_max_abs_weight: float | None = None

    # Numerical controls
    basket_rank_tolerance: float = 1e-10
    basket_constraint_tolerance: float = 1e-6
    basket_identity_tolerance: float = 1e-10
    basket_condition_number_warning: float = 1e10
    basket_fallback_mode: str = "soft_penalty"  # "soft_penalty" or "skip"
    stock_replication_tolerance: float = 1e-7

    # Comparison and persistence
    comparison_rolling_months: int = 36
    save_lookthrough_stock_weights: bool = False
    missing_return_policy: str = "coverage_threshold"
    max_plotted_themes: int = 4





def _as_timestamp_keyed_dict(d):
    return {pd.Timestamp(k): v.copy() for k, v in d.items()}


@dataclass
class ExposureSnapshot:
    date: pd.Timestamp
    barra_exposures: pd.DataFrame
    neutralization_exposures: pd.DataFrame
    raw_theme_exposures: pd.DataFrame
    purified_theme_exposures: pd.DataFrame


@dataclass
class BasketReplicationArtifacts:
    diagnostics: pd.DataFrame
    basis_diagnostics: pd.DataFrame
    basket_weights_long: pd.DataFrame
    lookthrough_stock_weights_long: pd.DataFrame
    return_coverage: pd.DataFrame
    raw_basket_returns: pd.DataFrame


def add_barra_intercept(B: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    B = B.copy().astype(float)
    if cfg.include_intercept_in_barra and "INTERCEPT" not in B.columns:
        B.insert(0, "INTERCEPT", 1.0)
    return B


def residualize_df(A: pd.DataFrame, X: pd.DataFrame, ridge: float = 1e-8) -> pd.DataFrame:
    """Return residuals from the cross-sectional regression X = A beta + residual."""
    A = A.astype(float)
    X = X.astype(float)
    common = A.index.intersection(X.index)
    A = A.loc[common]
    X = X.loc[common]
    av = A.to_numpy()
    xv = X.to_numpy()
    gram = av.T @ av + ridge * np.eye(av.shape[1])
    beta = np.linalg.pinv(gram) @ av.T @ xv
    resid = xv - av @ beta
    return pd.DataFrame(resid, index=common, columns=X.columns)


def normalize_l2(X: pd.DataFrame, eps: float = 1e-12) -> pd.DataFrame:
    X = X.copy().astype(float)
    norm = np.sqrt((X ** 2).sum(axis=0))
    keep = norm[norm > eps].index
    return X[keep].divide(norm[keep], axis=1)


def prior_stock_momentum(stock_returns: pd.DataFrame, date, cfg: Config) -> pd.Series:
    """Prior stock return r_{i,t-12:t-2}, approximated at monthly frequency."""
    date = pd.Timestamp(date)
    idx = stock_returns.index.get_loc(date)
    end = idx - cfg.skip_recent_months_for_stock_mom
    start = end - cfg.stock_mom_lookback_months
    if start < 0 or end <= start:
        return pd.Series(np.nan, index=stock_returns.columns, name="PRIOR_STOCK_MOM")
    window = stock_returns.iloc[start:end]
    return ((1.0 + window).prod(axis=0) - 1.0).rename("PRIOR_STOCK_MOM")


def generate_synthetic_inputs(cfg: Config) -> dict:
    """Generate point-in-time synthetic stock, Barra, theme, and tradeable basket data."""
    rng = np.random.default_rng(cfg.random_seed)
    dates = pd.date_range(cfg.start_date, periods=cfg.n_months, freq="ME")
    stocks = [f"S{i:04d}" for i in range(1, cfg.n_stocks + 1)]
    barra_cols = ["BETA", "SIZE", "VALUE", "PROFIT", "INVEST", "VOL"][: cfg.n_barra]
    themes = [f"Theme_{i:02d}" for i in range(1, cfg.n_themes + 1)]

    # Stable long-only theme baskets. These are used both as raw theme exposures
    # and, in the synthetic example, as directly tradeable basket weights.
    base_X = np.zeros((cfg.n_stocks, cfg.n_themes))
    for k in range(cfg.n_themes):
        basket_size = int(rng.integers(max(12, cfg.n_stocks // 12), max(16, cfg.n_stocks // 4)))
        selected = rng.choice(cfg.n_stocks, size=basket_size, replace=False)
        w = rng.lognormal(mean=0.0, sigma=0.7, size=basket_size)
        base_X[selected, k] = w / w.sum()

    barra_by_date = {}
    theme_by_date = {}
    basket_by_date = {}
    B_prev = rng.normal(size=(cfg.n_stocks, cfg.n_barra))
    f_prev = np.zeros(cfg.n_barra)
    g_prev = np.zeros(cfg.n_themes)
    returns = []

    for date in dates:
        B_now = 0.97 * B_prev + 0.03 * rng.normal(size=(cfg.n_stocks, cfg.n_barra))
        B_now = (B_now - B_now.mean(axis=0)) / B_now.std(axis=0)
        B_df = pd.DataFrame(B_now, index=stocks, columns=barra_cols)
        barra_by_date[pd.Timestamp(date)] = B_df

        X_now = base_X * rng.lognormal(mean=0.0, sigma=0.02, size=base_X.shape)
        X_now = X_now / np.maximum(X_now.sum(axis=0, keepdims=True), 1e-12)
        X_df = pd.DataFrame(X_now, index=stocks, columns=themes)
        theme_by_date[pd.Timestamp(date)] = X_df
        basket_by_date[pd.Timestamp(date)] = X_df.copy()

        B_aug = add_barra_intercept(B_df, cfg)
        Z = normalize_l2(residualize_df(B_aug, X_df, cfg.ridge))
        f_now = 0.15 * f_prev + rng.normal(loc=0.0, scale=0.012, size=cfg.n_barra)
        g_now = 0.35 * g_prev + rng.normal(loc=0.0015, scale=0.015, size=cfg.n_themes)
        eps = rng.normal(loc=0.0, scale=0.035, size=cfg.n_stocks)
        r = B_df.to_numpy() @ f_now + Z.to_numpy() @ g_now + eps
        returns.append(r)
        B_prev, f_prev, g_prev = B_now, f_now, g_now

    stock_returns = pd.DataFrame(returns, index=dates, columns=stocks)
    cash_returns = pd.Series(0.0, index=dates, name="cash_return")
    return {
        "stock_returns": stock_returns,
        "barra_exposures_by_date": barra_by_date,
        "theme_exposures_by_date": theme_by_date,
        cfg.theme_basket_weights_key: basket_by_date,
        "cash_returns": cash_returns,
        "metadata": {
            "source": "synthetic",
            "note": "Replace with data/theme_factor_inputs.pkl for production use.",
        },
    }


def load_or_generate_inputs(cfg: Config) -> dict:
    path = Path(cfg.input_pickle)
    if path.exists():
        with open(path, "rb") as f:
            data = pickle.load(f)
        required = ["stock_returns", "barra_exposures_by_date", "theme_exposures_by_date"]
        missing = [k for k in required if k not in data]
        if missing:
            raise KeyError(f"Input pickle is missing required keys: {missing}")
        data["stock_returns"] = data["stock_returns"].copy()
        data["stock_returns"].index = pd.to_datetime(data["stock_returns"].index)
        data["stock_returns"] = data["stock_returns"].sort_index()
        data["barra_exposures_by_date"] = _as_timestamp_keyed_dict(data["barra_exposures_by_date"])
        data["theme_exposures_by_date"] = _as_timestamp_keyed_dict(data["theme_exposures_by_date"])
        for optional_key in [cfg.theme_basket_weights_key, "specific_variances_by_date", "specific_risks_by_date"]:
            if optional_key in data:
                data[optional_key] = _as_timestamp_keyed_dict(data[optional_key])
        data.setdefault("metadata", {})["source"] = str(path)
        return data
    if not cfg.use_synthetic_if_missing:
        raise FileNotFoundError(f"Input pickle not found: {path}")
    return generate_synthetic_inputs(cfg)


def exposure_snapshot_for_date(
    data: dict,
    date,
    cfg: Config,
    momentum_neutral: bool = False,
) -> ExposureSnapshot:
    """Build one internally consistent point-in-time exposure snapshot."""
    date = pd.Timestamp(date)
    stock_returns = data["stock_returns"]
    if date not in data["barra_exposures_by_date"] or date not in data["theme_exposures_by_date"]:
        raise KeyError(f"Exposure data is unavailable on {date.date()}")

    B = data["barra_exposures_by_date"][date].copy()
    X = data["theme_exposures_by_date"][date].copy()
    common = stock_returns.columns.intersection(B.index).intersection(X.index)
    B = B.loc[common].replace([np.inf, -np.inf], np.nan).dropna(axis=0, how="any").astype(float)
    X = X.loc[B.index].replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    B_aug = add_barra_intercept(B, cfg)

    if momentum_neutral:
        p = prior_stock_momentum(stock_returns, date, cfg).reindex(B_aug.index)
        A = pd.concat([B_aug, p], axis=1).dropna(axis=0, how="any")
        if len(A) < A.shape[1] + X.shape[1] + 5:
            raise ValueError(
                f"Insufficient stocks with prior momentum on {date.date()} "
                "for momentum-neutral purification"
            )
        X = X.loc[A.index]
        B_aug = B_aug.loc[A.index]
    else:
        A = B_aug.copy()

    Z = normalize_l2(residualize_df(A, X, cfg.ridge))
    if Z.empty:
        raise ValueError(f"No non-degenerate purified theme exposure on {date.date()}")
    idx = Z.index
    cols = Z.columns
    return ExposureSnapshot(
        date=date,
        barra_exposures=B_aug.loc[idx],
        neutralization_exposures=A.loc[idx],
        raw_theme_exposures=X.loc[idx, cols],
        purified_theme_exposures=Z,
    )


def snapshot_for_date(data: dict, date, cfg: Config, momentum_neutral: bool = False):
    """Backward-compatible wrapper returning (Barra, raw theme, purified theme)."""
    snap = exposure_snapshot_for_date(data, date, cfg, momentum_neutral=momentum_neutral)
    return snap.barra_exposures, snap.raw_theme_exposures, snap.purified_theme_exposures


def _return_vector_with_policy(
    data: dict,
    return_date,
    stocks: pd.Index,
    cfg: Config,
) -> tuple[pd.Series, dict]:
    """Apply one explicit missing-return policy and return a zero-filled calculation vector."""
    return_date = pd.Timestamp(return_date)
    raw = data["stock_returns"].loc[return_date].reindex(stocks).astype(float)
    finite = np.isfinite(raw.to_numpy())
    coverage = float(finite.mean()) if len(raw) else 0.0
    n_missing = int((~finite).sum())

    policy = cfg.missing_return_policy
    if policy not in {"error", "coverage_threshold", "zero_with_flag"}:
        raise ValueError("missing_return_policy must be 'error', 'coverage_threshold', or 'zero_with_flag'")
    if policy == "error" and n_missing:
        raise ValueError(f"{n_missing} missing stock returns on {return_date.date()}")
    if policy == "coverage_threshold" and coverage < cfg.basket_min_return_coverage:
        raise ValueError(
            f"Stock-return coverage {coverage:.3%} is below "
            f"{cfg.basket_min_return_coverage:.3%} on {return_date.date()}"
        )
    calc = raw.where(np.isfinite(raw), 0.0)
    return calc, {
        "return_date": return_date,
        "stock_return_coverage": coverage,
        "n_missing_stock_returns": n_missing,
        "missing_return_policy": policy,
        "missing_mask": pd.Series(~finite, index=stocks),
    }


def _portfolio_return_coverage(weights: pd.DataFrame, missing_mask: pd.Series) -> pd.Series:
    missing_mask = missing_mask.reindex(weights.index).fillna(True)
    gross = weights.abs().sum(axis=0)
    missing_gross = weights.loc[missing_mask].abs().sum(axis=0)
    coverage = 1.0 - missing_gross.divide(gross.replace(0.0, np.nan))
    return coverage.fillna(1.0).clip(lower=0.0, upper=1.0)


def estimate_theme_returns(data: dict, cfg: Config, momentum_neutral: bool = False):
    """Estimate next-month purified theme factor returns using only prior-month exposures."""
    stock_returns = data["stock_returns"]
    dates = list(stock_returns.index)
    rows = []
    diag_rows = []
    for i in range(1, len(dates)):
        exposure_date = dates[i - 1]
        return_date = dates[i]
        try:
            snap = exposure_snapshot_for_date(data, exposure_date, cfg, momentum_neutral=momentum_neutral)
            r, rdiag = _return_vector_with_policy(data, return_date, snap.purified_theme_exposures.index, cfg)
        except Exception as e:
            diag_rows.append({
                "return_date": return_date,
                "exposure_date": exposure_date,
                "status": f"skipped: {type(e).__name__}: {e}",
            })
            continue

        A = snap.neutralization_exposures.to_numpy()
        y = r.to_numpy()
        beta_neutral = (
            np.linalg.pinv(A.T @ A + cfg.ridge * np.eye(A.shape[1]), rcond=cfg.pinv_rcond)
            @ A.T
            @ y
        )
        u = y - A @ beta_neutral
        Z = snap.purified_theme_exposures
        Zv = Z.to_numpy()
        g = (
            np.linalg.pinv(
                Zv.T @ Zv + cfg.theme_return_ridge_alpha * np.eye(Zv.shape[1]),
                rcond=cfg.pinv_rcond,
            )
            @ Zv.T
            @ u
        )
        rows.append(pd.Series(g, index=Z.columns, name=return_date))

        sst = float(np.sum((y - y.mean()) ** 2))
        fit_neutral = A @ beta_neutral
        fit_full = fit_neutral + Zv @ g
        r2_neutral = np.nan if sst <= 0 else 1.0 - float(np.sum((y - fit_neutral) ** 2)) / sst
        r2_full = np.nan if sst <= 0 else 1.0 - float(np.sum((y - fit_full) ** 2)) / sst
        diag_rows.append({
            "return_date": return_date,
            "exposure_date": exposure_date,
            "n_stocks": len(Z.index),
            "n_themes": len(Z.columns),
            "n_neutralization_factors": A.shape[1],
            "r2_barra": r2_neutral,
            "r2_barra_plus_theme": r2_full,
            "stock_return_coverage": rdiag["stock_return_coverage"],
            "n_missing_stock_returns": rdiag["n_missing_stock_returns"],
            "status": "ok",
        })
    theme_returns = pd.DataFrame(rows).sort_index()
    diag = pd.DataFrame(diag_rows)
    if "return_date" in diag.columns:
        diag = diag.set_index("return_date").sort_index()
    return theme_returns, diag


def diagonal_specific_variance(
    data: dict,
    date,
    stocks: pd.Index,
    cfg: Config,
) -> tuple[pd.Series, str]:
    """Return point-in-time diagonal stock variance and its source label."""
    date = pd.Timestamp(date)
    for key, values_are_std in [("specific_variances_by_date", False), ("specific_risks_by_date", True)]:
        by_date = data.get(key)
        if by_date is not None and date in by_date:
            raw = by_date[date]
            if isinstance(raw, pd.DataFrame):
                if raw.shape[1] != 1:
                    raise ValueError(f"{key}[date] must be a Series or one-column DataFrame")
                raw = raw.iloc[:, 0]
            v = pd.Series(raw, dtype=float).reindex(stocks)
            if values_are_std:
                v = v ** 2
            finite_positive = v[np.isfinite(v) & (v > 0)]
            fallback = float(finite_positive.median()) if len(finite_positive) else 1.0
            return v.where(np.isfinite(v) & (v > 0), fallback).clip(lower=1e-8), key

    stock_returns = data["stock_returns"]
    idx = stock_returns.index.get_loc(date)
    hist = stock_returns.iloc[max(0, idx - cfg.risk_lookback_months):idx].reindex(columns=stocks)
    v = hist.var(axis=0, ddof=1)
    finite_positive = v[np.isfinite(v) & (v > 0)]
    if len(finite_positive):
        fallback = float(finite_positive.median())
        source = "trailing_stock_return_variance"
    else:
        # Unit variance is scale-neutral in the projection objective and avoids future-data fallback.
        fallback = 1.0
        source = "unit_variance_no_history"
    v = v.where(np.isfinite(v) & (v > 0), fallback).clip(lower=1e-8)
    return v, source


def specific_risk_diag(data: dict, date, stocks, cfg: Config) -> pd.Series:
    """Backward-compatible alias; the returned object is a variance, not a standard deviation."""
    return diagonal_specific_variance(data, date, pd.Index(stocks), cfg)[0]


def construct_stock_mimicking_portfolios(
    data: dict,
    cfg: Config,
    date,
    momentum_neutral: bool = False,
    mode: str | None = None,
):
    """Construct stock-level coefficient or minimum-risk purified-theme mimicking portfolios."""
    mode = mode or cfg.mimicking_mode
    snap = exposure_snapshot_for_date(data, date, cfg, momentum_neutral=momentum_neutral)
    B_aug = snap.barra_exposures
    A_neutral = snap.neutralization_exposures
    Z = snap.purified_theme_exposures
    Zv = Z.to_numpy()
    risk_source = None

    if mode == "coefficient":
        gram = Zv.T @ Zv + cfg.theme_return_ridge_alpha * np.eye(Zv.shape[1])
        Mv = Zv @ np.linalg.pinv(gram, rcond=cfg.pinv_rcond)
        constraint_matrix = pd.concat([A_neutral, Z], axis=1)
        target = None
    elif mode == "min_risk":
        constraint_matrix = pd.concat([A_neutral, Z], axis=1)
        q, risk_source = diagonal_specific_variance(data, date, constraint_matrix.index, cfg)
        weighted_A = constraint_matrix.mul(1.0 / q, axis=0)
        Av = constraint_matrix.to_numpy()
        C = np.zeros((Av.shape[1], Z.shape[1]))
        C[-Z.shape[1]:, :] = np.eye(Z.shape[1])
        middle = np.linalg.pinv(
            constraint_matrix.T.to_numpy() @ weighted_A.to_numpy()
            + cfg.ridge * np.eye(Av.shape[1]),
            rcond=cfg.pinv_rcond,
        )
        Mv = weighted_A.to_numpy() @ middle @ C
        target = pd.DataFrame(C, index=constraint_matrix.columns, columns=Z.columns)
    else:
        raise ValueError("mode must be 'coefficient' or 'min_risk'")

    M = pd.DataFrame(Mv, index=Z.index, columns=Z.columns)
    constraints_actual = pd.DataFrame(
        constraint_matrix.to_numpy().T @ M.to_numpy(),
        index=constraint_matrix.columns,
        columns=M.columns,
    )
    neutral_exp = pd.DataFrame(
        A_neutral.to_numpy().T @ M.to_numpy(),
        index=A_neutral.columns,
        columns=M.columns,
    )
    barra_exp = pd.DataFrame(
        B_aug.to_numpy().T @ M.to_numpy(),
        index=B_aug.columns,
        columns=M.columns,
    )
    theme_exp = pd.DataFrame(
        Z.to_numpy().T @ M.to_numpy(),
        index=Z.columns,
        columns=M.columns,
    )
    gross = M.abs().sum(axis=0).rename("gross")
    net = M.sum(axis=0).rename("net")
    diagnostics = {
        "date": pd.Timestamp(date),
        "mode": mode,
        "risk_model_source": risk_source,
        "constraints_actual": constraints_actual,
        "target": target,
        "neutralization_exposure": neutral_exp,
        "barra_exposure": barra_exp,
        "theme_exposure": theme_exp,
        "portfolio_summary": pd.concat(
            [gross, net, M.max().rename("max_weight"), M.min().rename("min_weight")], axis=1
        ),
        "snapshot": snap,
    }
    return M, diagnostics


def construct_mimicking_portfolios(
    data: dict,
    cfg: Config,
    date,
    momentum_neutral: bool = False,
    mode: str | None = None,
):
    """Backward-compatible alias for construct_stock_mimicking_portfolios."""
    return construct_stock_mimicking_portfolios(
        data,
        cfg,
        date,
        momentum_neutral=momentum_neutral,
        mode=mode,
    )


def stock_replicated_theme_returns(
    data: dict,
    cfg: Config,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool = False,
    mode: str = "coefficient",
    return_diagnostics: bool = False,
):
    rows = []
    diag_rows = []
    for return_date in theme_returns.index:
        pos = data["stock_returns"].index.get_loc(return_date)
        if pos == 0:
            continue
        exposure_date = data["stock_returns"].index[pos - 1]
        try:
            M, _ = construct_stock_mimicking_portfolios(
                data,
                cfg,
                exposure_date,
                momentum_neutral=momentum_neutral,
                mode=mode,
            )
            r, rdiag = _return_vector_with_policy(data, return_date, M.index, cfg)
            coverage = _portfolio_return_coverage(M, rdiag["missing_mask"])
            values = pd.Series(M.T @ r, index=M.columns, name=return_date)
            if cfg.missing_return_policy == "coverage_threshold":
                values = values.where(coverage >= cfg.basket_min_return_coverage)
            rows.append(values)
            for theme in M.columns:
                diag_rows.append({
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "theme": theme,
                    "mode": mode,
                    "return_coverage": float(coverage[theme]),
                    "status": "ok" if pd.notna(values[theme]) else "insufficient_return_coverage",
                })
        except Exception as e:
            diag_rows.append({
                "return_date": return_date,
                "exposure_date": exposure_date,
                "theme": None,
                "mode": mode,
                "status": f"skipped: {type(e).__name__}: {e}",
            })
    returns = pd.DataFrame(rows).sort_index()
    diagnostics = pd.DataFrame(diag_rows)
    return (returns, diagnostics) if return_diagnostics else returns


def coefficient_replicated_theme_returns(
    data: dict,
    cfg: Config,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool = False,
):
    return stock_replicated_theme_returns(
        data,
        cfg,
        theme_returns,
        momentum_neutral=momentum_neutral,
        mode="coefficient",
        return_diagnostics=False,
    )


def prepare_theme_basket_weights(
    data: dict,
    date,
    stock_index: pd.Index,
    theme_columns: pd.Index,
    cfg: Config,
) -> tuple[pd.DataFrame, dict]:
    """Prepare the point-in-time tradeable base-basket matrix P (stock x basket)."""
    date = pd.Timestamp(date)
    source_key = cfg.theme_basket_weights_key
    source = "explicit"
    by_date = data.get(source_key)
    if by_date is None or date not in by_date:
        if not cfg.basket_fallback_to_theme_exposures:
            raise KeyError(f"{source_key} is unavailable on {date.date()}")
        by_date = data.get("theme_exposures_by_date")
        if by_date is None or date not in by_date:
            raise KeyError(f"No basket input or fallback theme exposure on {date.date()}")
        source = "theme_exposures_fallback"

    raw = by_date[date].copy()
    if not isinstance(raw, pd.DataFrame):
        raise TypeError(f"Basket weights on {date.date()} must be a DataFrame")
    missing_columns = [c for c in theme_columns if c not in raw.columns]
    if missing_columns:
        raise ValueError(f"Missing tradeable basket columns on {date.date()}: {missing_columns[:8]}")

    raw = raw.reindex(index=stock_index, columns=theme_columns)
    n_input_nan = int(raw.isna().sum().sum())
    P = raw.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    if not np.isfinite(P.to_numpy()).all():
        raise ValueError(f"Non-finite basket weights remain on {date.date()}")

    min_weight = P.min(axis=0)
    negative_count = (P < -cfg.basket_rank_tolerance).sum(axis=0)
    if (source == "theme_exposures_fallback" or cfg.basket_require_long_only_base) and int(negative_count.sum()) > 0:
        bad = negative_count[negative_count > 0].index.tolist()
        raise ValueError(f"Base baskets are not long-only on {date.date()}: {bad[:8]}")

    colsum_before = P.sum(axis=0)
    bad_sum = colsum_before[~np.isfinite(colsum_before) | (colsum_before <= cfg.basket_rank_tolerance)]
    if len(bad_sum):
        raise ValueError(f"Non-positive basket column sums on {date.date()}: {bad_sum.index.tolist()[:8]}")

    P = P.divide(colsum_before, axis=1) * cfg.basket_column_sum_target
    constituent_count = (P.abs() > cfg.basket_rank_tolerance).sum(axis=0)
    too_small = constituent_count[constituent_count < cfg.basket_min_constituents]
    if len(too_small):
        raise ValueError(
            f"Baskets below basket_min_constituents={cfg.basket_min_constituents} on {date.date()}: "
            f"{too_small.to_dict()}"
        )

    hhi = (P ** 2).sum(axis=0)
    summary = pd.DataFrame({
        "column_sum_before": colsum_before,
        "column_sum_after": P.sum(axis=0),
        "n_constituents": constituent_count,
        "max_weight": P.max(axis=0),
        "min_weight": min_weight,
        "hhi": hhi,
        "negative_weight_count": negative_count,
    })
    summary.index.name = "base_basket"
    diagnostics = {
        "date": date,
        "source": source,
        "n_input_nan_filled_as_zero": n_input_nan,
        "n_stocks": P.shape[0],
        "n_baskets": P.shape[1],
        "input_summary": summary,
    }
    return P, diagnostics


def _svd_rank(a: np.ndarray, rtol: float) -> tuple[int, np.ndarray, float]:
    a = np.asarray(a, dtype=float)
    if a.size == 0:
        return 0, np.array([], dtype=float), 0.0
    s = np.linalg.svd(a, compute_uv=False)
    if len(s) == 0 or s[0] == 0:
        return 0, s, 0.0
    tol = rtol * max(a.shape) * s[0]
    return int((s > tol).sum()), s, float(tol)


def _nullspace(a: np.ndarray, rtol: float) -> tuple[np.ndarray, int, np.ndarray, float]:
    a = np.asarray(a, dtype=float)
    n_cols = a.shape[1]
    if a.shape[0] == 0:
        return np.eye(n_cols), 0, np.array([], dtype=float), 0.0
    _, s, vt = np.linalg.svd(a, full_matrices=True)
    if len(s) == 0 or (len(s) and s[0] == 0):
        rank = 0
        tol = 0.0
    else:
        tol = rtol * max(a.shape) * s[0]
        rank = int((s > tol).sum())
    return vt[rank:].T.copy(), rank, s, float(tol)


def _condition_number(a: np.ndarray, rtol: float) -> float:
    a = np.asarray(a, dtype=float)
    if a.size == 0:
        return np.nan
    s = np.linalg.svd(a, compute_uv=False)
    if len(s) == 0 or s[0] == 0:
        return np.inf
    tol = rtol * max(a.shape) * s[0]
    positive = s[s > tol]
    if len(positive) < min(a.shape):
        return np.inf
    return float(positive[0] / positive[-1])


def basket_basis_diagnostics(
    P: pd.DataFrame,
    A: pd.DataFrame,
    Z: pd.DataFrame,
    cfg: Config,
) -> tuple[dict, np.ndarray, pd.DataFrame]:
    """Diagnose the rank of the tradeable basket basis and its neutral subspace."""
    Pv = P.to_numpy()
    F = A.to_numpy().T @ Pv if cfg.basket_enforce_neutrality else np.zeros((0, P.shape[1]))
    constraint_names = list(A.columns) if cfg.basket_enforce_neutrality else []
    if not cfg.include_intercept_in_barra and "DOLLAR_NET" not in constraint_names:
        F = np.vstack([F, np.ones((1, P.shape[0])) @ Pv])
        constraint_names.append("DOLLAR_NET")
    N, rank_F, s_F, tol_F = _nullspace(F, cfg.basket_rank_tolerance)
    rank_P, s_P, tol_P = _svd_rank(Pv, cfg.basket_rank_tolerance)
    E_neutral = Z.to_numpy().T @ Pv @ N
    rank_theme_neutral, s_E, tol_E = _svd_rank(E_neutral, cfg.basket_rank_tolerance)
    diag = {
        "rank_basket_matrix": rank_P,
        "rank_neutralization_exposure_on_baskets": rank_F,
        "neutral_nullspace_dimension": int(N.shape[1]),
        "rank_theme_exposure_in_neutral_space": rank_theme_neutral,
        "n_stocks": P.shape[0],
        "n_base_baskets": P.shape[1],
        "n_target_themes": Z.shape[1],
        "condition_number_basket_matrix": _condition_number(Pv, cfg.basket_rank_tolerance),
        "condition_number_neutralization_on_baskets": _condition_number(F, cfg.basket_rank_tolerance),
        "rank_tolerance_basket": tol_P,
        "rank_tolerance_neutralization": tol_F,
        "rank_tolerance_theme_neutral": tol_E,
        "min_singular_value_basket": float(s_P[-1]) if len(s_P) else np.nan,
        "min_singular_value_neutralization": float(s_F[-1]) if len(s_F) else np.nan,
        "min_singular_value_theme_neutral": float(s_E[-1]) if len(s_E) else np.nan,
    }
    F_df = pd.DataFrame(F, index=constraint_names, columns=P.columns)
    return diag, N, F_df


def _solve_projection_hard_or_soft(
    Q: np.ndarray,
    c: np.ndarray,
    F: np.ndarray,
    target_row: np.ndarray,
    target_value: float,
    cfg: Config,
    basket_mode: str,
) -> tuple[np.ndarray, dict]:
    """Solve the basket projection with redundant neutrality constraints removed through a null space."""
    Q = 0.5 * (np.asarray(Q, dtype=float) + np.asarray(Q, dtype=float).T)
    c = np.asarray(c, dtype=float)
    F = np.asarray(F, dtype=float)
    target_row = np.asarray(target_row, dtype=float).reshape(-1)
    n = Q.shape[0]
    N, rank_F, _, _ = _nullspace(F, cfg.basket_rank_tolerance)
    target_strength = float(np.linalg.norm(target_row @ N)) if N.size else 0.0
    requested_hard = basket_mode == "constrained_risk_projection"
    reason = None
    h = np.zeros(n)
    cond_kkt = np.nan
    hard_residual = np.inf

    if requested_hard:
        if N.shape[1] == 0:
            reason = "no_neutral_degrees_of_freedom"
        elif cfg.basket_enforce_target_exposure and target_strength <= cfg.basket_rank_tolerance:
            reason = "infeasible_target_exposure"
        else:
            Qn = N.T @ Q @ N
            cn = N.T @ c
            if cfg.basket_enforce_target_exposure:
                gn = (target_row @ N).reshape(1, -1)
                KKT = np.block([
                    [Qn, gn.T],
                    [gn, np.zeros((1, 1))],
                ])
                rhs = np.concatenate([cn, [target_value]])
                cond_kkt = _condition_number(KKT, cfg.basket_rank_tolerance)
                sol = np.linalg.pinv(KKT, rcond=cfg.pinv_rcond) @ rhs
                y = sol[: N.shape[1]]
            else:
                cond_kkt = _condition_number(Qn, cfg.basket_rank_tolerance)
                y = np.linalg.pinv(Qn, rcond=cfg.pinv_rcond) @ cn
            h = N @ y
            neutral_resid = float(np.max(np.abs(F @ h))) if F.size else 0.0
            target_resid = (
                abs(float(target_row @ h) - target_value)
                if cfg.basket_enforce_target_exposure
                else 0.0
            )
            hard_residual = max(neutral_resid, target_resid)
            if not np.isfinite(h).all():
                reason = "non_finite_hard_solution"
            elif hard_residual > cfg.basket_constraint_tolerance:
                reason = "hard_constraint_residual"

    if requested_hard and reason is None:
        status = "hard_solved"
        if (not np.isfinite(cond_kkt)) or cond_kkt > cfg.basket_condition_number_warning:
            status = "hard_solved_condition_warning"
        return h, {
            "solver_status": status,
            "applied_mode": "constrained_risk_projection",
            "fallback_reason": None,
            "condition_number_kkt": cond_kkt,
            "target_strength_in_neutral_space": target_strength,
            "neutral_constraint_rank": rank_F,
            "constraint_feasibility_residual": hard_residual,
        }

    if basket_mode not in {"constrained_risk_projection", "soft_penalty"}:
        raise ValueError("basket_mode must be 'constrained_risk_projection' or 'soft_penalty'")
    if requested_hard and cfg.basket_fallback_mode == "skip":
        raise ValueError(reason or "hard_projection_failed")
    if requested_hard and cfg.basket_fallback_mode != "soft_penalty":
        raise ValueError("basket_fallback_mode must be 'soft_penalty' or 'skip'")

    Qs = Q.copy()
    cs = c.copy()
    if F.size and cfg.basket_enforce_neutrality:
        Qs += cfg.basket_soft_neutrality_penalty * (F.T @ F)
    if cfg.basket_enforce_target_exposure:
        Qs += cfg.basket_soft_target_penalty * np.outer(target_row, target_row)
        cs += cfg.basket_soft_target_penalty * target_value * target_row
    cond_kkt = _condition_number(Qs, cfg.basket_rank_tolerance)
    h = np.linalg.pinv(Qs, rcond=cfg.pinv_rcond) @ cs
    if not np.isfinite(h).all():
        raise FloatingPointError("Soft-penalty solver produced non-finite basket weights")
    neutral_resid = float(np.max(np.abs(F @ h))) if F.size else 0.0
    target_resid = (
        abs(float(target_row @ h) - target_value)
        if cfg.basket_enforce_target_exposure
        else 0.0
    )
    return h, {
        "solver_status": "soft_penalty" if not requested_hard else f"soft_fallback:{reason}",
        "applied_mode": "soft_penalty",
        "fallback_reason": reason,
        "condition_number_kkt": cond_kkt,
        "target_strength_in_neutral_space": target_strength,
        "neutral_constraint_rank": rank_F,
        "constraint_feasibility_residual": max(neutral_resid, target_resid),
    }


def _apply_optional_investable_constraints(
    h0: np.ndarray,
    Q: np.ndarray,
    c: np.ndarray,
    F: np.ndarray,
    target_row: np.ndarray,
    target_value: float,
    own_index: int | None,
    cfg: Config,
) -> tuple[np.ndarray, str | None]:
    """Optionally refine the solution with SLSQP. Disabled in the diagnostic default."""
    needs_slsqp = (
        cfg.basket_require_own_theme_long
        or cfg.basket_gross_cap is not None
        or cfg.basket_max_abs_weight is not None
    )
    if not needs_slsqp:
        return h0, None
    try:
        from scipy.optimize import minimize
    except Exception as e:
        raise ImportError("SciPy is required for optional investable basket constraints") from e

    Q = 0.5 * (Q + Q.T)

    def objective(h):
        return 0.5 * float(h @ Q @ h) - float(c @ h)

    def gradient(h):
        return Q @ h - c

    constraints = []
    if F.size:
        constraints.append({"type": "eq", "fun": lambda h: F @ h, "jac": lambda h: F})
    if cfg.basket_enforce_target_exposure:
        constraints.append({
            "type": "eq",
            "fun": lambda h: np.array([target_row @ h - target_value]),
            "jac": lambda h: target_row.reshape(1, -1),
        })
    if cfg.basket_require_own_theme_long:
        if own_index is None:
            raise ValueError("Own-theme-long constraint requested but target has no matching base basket")
        constraints.append({
            "type": "ineq",
            "fun": lambda h, j=own_index: np.array([h[j] - cfg.basket_min_own_theme_weight]),
        })
    if cfg.basket_gross_cap is not None:
        constraints.append({
            "type": "ineq",
            "fun": lambda h: np.array([cfg.basket_gross_cap - np.abs(h).sum()]),
        })
    bounds = None
    if cfg.basket_max_abs_weight is not None:
        cap = float(cfg.basket_max_abs_weight)
        bounds = [(-cap, cap)] * len(h0)

    result = minimize(
        objective,
        h0,
        jac=gradient,
        method="SLSQP",
        bounds=bounds,
        constraints=constraints,
        options={"ftol": 1e-12, "maxiter": 2000, "disp": False},
    )
    if not result.success:
        raise ValueError(f"Investable-constraint solver failed: {result.message}")
    return np.asarray(result.x, dtype=float), "slsqp_investable_constraints"


def construct_basket_mimicking_portfolios(
    data: dict,
    cfg: Config,
    date,
    momentum_neutral: bool = False,
    stock_target_mode: str = "coefficient",
    basket_mode: str | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Return H_basket, M_lookthrough=P@H, and comprehensive diagnostics."""
    date = pd.Timestamp(date)
    basket_mode = basket_mode or cfg.basket_replication_mode
    M_stock, stock_diag = construct_stock_mimicking_portfolios(
        data,
        cfg,
        date,
        momentum_neutral=momentum_neutral,
        mode=stock_target_mode,
    )
    snap = stock_diag["snapshot"]
    A = snap.neutralization_exposures.loc[M_stock.index]
    Z = snap.purified_theme_exposures.loc[M_stock.index, M_stock.columns]
    P, input_diag = prepare_theme_basket_weights(
        data,
        date,
        stock_index=M_stock.index,
        theme_columns=M_stock.columns,
        cfg=cfg,
    )
    if cfg.basket_risk_model == "diagonal_variance":
        q, risk_source = diagonal_specific_variance(data, date, P.index, cfg)
    elif cfg.basket_risk_model == "unit":
        q = pd.Series(1.0, index=P.index)
        risk_source = "unit_variance"
    else:
        raise ValueError("basket_risk_model must be 'diagonal_variance' or 'unit'")

    basis_diag, neutral_basis, F_df = basket_basis_diagnostics(P, A, Z, cfg)
    basis_diag.update({
        "exposure_date": date,
        "basket_input_source": input_diag["source"],
        "risk_model_source": risk_source,
    })
    F = F_df.to_numpy()
    Pv = P.to_numpy()
    Zv = Z.to_numpy()
    Msv = M_stock.to_numpy()
    qv = q.reindex(P.index).to_numpy()

    Q_base = P.T.to_numpy() @ (qv[:, None] * Pv)
    Q_base = 0.5 * (Q_base + Q_base.T) + cfg.basket_ridge_alpha * np.eye(P.shape[1])
    C = P.T.to_numpy() @ (qv[:, None] * Msv)
    theme_on_baskets = Zv.T @ Pv

    H = pd.DataFrame(index=P.columns, columns=Z.columns, dtype=float)
    per_theme_rows = []
    for k, target_theme in enumerate(Z.columns):
        Q = Q_base.copy()
        if cfg.basket_offtheme_penalty > 0 and Z.shape[1] > 1:
            off = np.delete(theme_on_baskets, k, axis=0)
            Q += cfg.basket_offtheme_penalty * (off.T @ off)
        c = C[:, k]
        target_row = theme_on_baskets[k, :]
        h, solver_diag = _solve_projection_hard_or_soft(
            Q=Q,
            c=c,
            F=F,
            target_row=target_row,
            target_value=cfg.basket_target_exposure,
            cfg=cfg,
            basket_mode=basket_mode,
        )
        own_index = P.columns.get_loc(target_theme) if target_theme in P.columns else None
        h, optional_status = _apply_optional_investable_constraints(
            h,
            Q,
            c,
            F,
            target_row,
            cfg.basket_target_exposure,
            own_index,
            cfg,
        )
        if optional_status:
            solver_diag["solver_status"] += f"+{optional_status}"
        H[target_theme] = h

        m = Pv @ h
        m_stock = Msv[:, k]
        neutral_exp = A.to_numpy().T @ m
        theme_exp = Zv.T @ m
        off_theme = np.delete(theme_exp, k)
        diff = m - m_stock
        risk_distance = float(np.sqrt(max(0.0, np.sum(qv * diff ** 2))))
        denom = float(np.linalg.norm(m) * np.linalg.norm(m_stock))
        cosine = np.nan if denom <= 0 else float(m @ m_stock / denom)
        basket_gross = float(np.abs(h).sum())
        row = {
            "exposure_date": date,
            "target_theme": target_theme,
            **basis_diag,
            **solver_diag,
            "max_abs_neutralization_exposure": float(np.max(np.abs(neutral_exp))) if len(neutral_exp) else 0.0,
            "target_theme_exposure": float(theme_exp[k]),
            "target_theme_exposure_error": float(theme_exp[k] - cfg.basket_target_exposure),
            "off_target_theme_exposure_l1": float(np.abs(off_theme).sum()),
            "off_target_theme_exposure_l2": float(np.sqrt(np.sum(off_theme ** 2))),
            "off_target_theme_exposure_max": float(np.max(np.abs(off_theme))) if len(off_theme) else 0.0,
            "basket_gross": basket_gross,
            "basket_net": float(h.sum()),
            "basket_long_gross": float(h[h > 0].sum()),
            "basket_short_gross": float(-h[h < 0].sum()),
            "max_abs_basket_weight": float(np.max(np.abs(h))),
            "n_long_baskets": int((h > cfg.basket_rank_tolerance).sum()),
            "n_short_baskets": int((h < -cfg.basket_rank_tolerance).sum()),
            "own_theme_basket_weight": float(h[own_index]) if own_index is not None else np.nan,
            "lookthrough_stock_gross": float(np.abs(m).sum()),
            "lookthrough_stock_net": float(m.sum()),
            "risk_weighted_distance_to_stock_target": risk_distance,
            "cosine_similarity_to_stock_target": cosine,
            "ex_ante_tracking_error_to_stock_target": risk_distance,
        }
        per_theme_rows.append(row)

    M_basket = P @ H
    neutral_exp_df = pd.DataFrame(A.to_numpy().T @ M_basket.to_numpy(), index=A.columns, columns=H.columns)
    theme_exp_df = pd.DataFrame(Z.to_numpy().T @ M_basket.to_numpy(), index=Z.columns, columns=H.columns)
    diagnostics = {
        "date": date,
        "per_theme": pd.DataFrame(per_theme_rows),
        "basis": pd.DataFrame([basis_diag]),
        "basket_input_summary": input_diag["input_summary"],
        "basket_input_metadata": {k: v for k, v in input_diag.items() if k != "input_summary"},
        "neutralization_exposure": neutral_exp_df,
        "theme_exposure": theme_exp_df,
        "basket_weights": H,
        "lookthrough_weights": M_basket,
        "base_basket_weights": P,
        "stock_target_weights": M_stock,
        "stock_target_diagnostics": stock_diag,
        "neutral_basis": pd.DataFrame(neutral_basis, index=P.columns),
    }
    return H, M_basket, diagnostics


def basket_replicated_theme_returns(
    data: dict,
    cfg: Config,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool = False,
    return_artifacts: bool = False,
):
    """Generate next-month theme-basket L/S replicated returns and diagnostics."""
    return_rows = []
    raw_basket_return_rows = []
    diag_frames = []
    basis_frames = []
    coverage_rows = []
    H_long_frames = []
    M_long_frames = []
    prev_H = None
    prev_M = None

    for return_date in theme_returns.index:
        pos = data["stock_returns"].index.get_loc(return_date)
        if pos == 0:
            continue
        exposure_date = data["stock_returns"].index[pos - 1]
        try:
            H, M, diag = construct_basket_mimicking_portfolios(
                data,
                cfg,
                exposure_date,
                momentum_neutral=momentum_neutral,
                stock_target_mode="coefficient",
                basket_mode=cfg.basket_replication_mode,
            )
            r, rdiag = _return_vector_with_policy(data, return_date, M.index, cfg)
            P = diag["base_basket_weights"]
            raw_basket_returns = pd.Series(P.T @ r, index=P.columns, name=return_date)
            via_baskets = pd.Series(H.T @ raw_basket_returns, index=H.columns, name=return_date)
            via_lookthrough = pd.Series(M.T @ r, index=M.columns, name=return_date)
            identity_error = float((via_baskets - via_lookthrough).abs().max())
            if identity_error > cfg.basket_identity_tolerance:
                raise AssertionError(
                    f"Basket-return identity error {identity_error:.3e} exceeds "
                    f"{cfg.basket_identity_tolerance:.3e} on {return_date.date()}"
                )

            coverage = _portfolio_return_coverage(M, rdiag["missing_mask"])
            if cfg.missing_return_policy == "coverage_threshold":
                via_baskets = via_baskets.where(coverage >= cfg.basket_min_return_coverage)
            return_rows.append(via_baskets)
            raw_basket_return_rows.append(raw_basket_returns)

            per_theme = diag["per_theme"].copy()
            per_theme["return_date"] = return_date
            per_theme["identity_error"] = identity_error
            per_theme["stock_return_coverage"] = rdiag["stock_return_coverage"]
            per_theme["n_missing_stock_returns"] = rdiag["n_missing_stock_returns"]
            per_theme["basket_replication_return_coverage"] = per_theme["target_theme"].map(coverage)
            per_theme["return_status"] = np.where(
                per_theme["basket_replication_return_coverage"] >= cfg.basket_min_return_coverage,
                "ok",
                "insufficient_return_coverage",
            )

            if prev_H is None:
                basket_turnover = pd.Series(np.nan, index=H.columns)
                lookthrough_turnover = pd.Series(np.nan, index=M.columns)
            else:
                idx_h = prev_H.index.union(H.index)
                cols_h = prev_H.columns.union(H.columns)
                basket_turnover = 0.5 * (
                    H.reindex(index=idx_h, columns=cols_h, fill_value=0.0)
                    - prev_H.reindex(index=idx_h, columns=cols_h, fill_value=0.0)
                ).abs().sum(axis=0)
                idx_m = prev_M.index.union(M.index)
                cols_m = prev_M.columns.union(M.columns)
                lookthrough_turnover = 0.5 * (
                    M.reindex(index=idx_m, columns=cols_m, fill_value=0.0)
                    - prev_M.reindex(index=idx_m, columns=cols_m, fill_value=0.0)
                ).abs().sum(axis=0)
            per_theme["basket_weight_turnover"] = per_theme["target_theme"].map(basket_turnover)
            per_theme["lookthrough_stock_turnover"] = per_theme["target_theme"].map(lookthrough_turnover)
            diag_frames.append(per_theme)
            basis = diag["basis"].copy()
            basis["return_date"] = return_date
            basis_frames.append(basis)

            coverage_rows.extend([
                {
                    "return_date": return_date,
                    "exposure_date": exposure_date,
                    "target_theme": theme,
                    "return_coverage": float(coverage[theme]),
                    "stock_return_coverage": rdiag["stock_return_coverage"],
                }
                for theme in H.columns
            ])

            h_long = (
                H.rename_axis(index="base_basket", columns="target_theme")
                .reset_index()
                .melt(id_vars="base_basket", var_name="target_theme", value_name="weight")
            )
            h_long.insert(0, "exposure_date", exposure_date)
            H_long_frames.append(h_long)
            if cfg.save_lookthrough_stock_weights:
                m_long = (
                    M.rename_axis(index="stock", columns="target_theme")
                    .reset_index()
                    .melt(id_vars="stock", var_name="target_theme", value_name="weight")
                )
                m_long.insert(0, "exposure_date", exposure_date)
                M_long_frames.append(m_long)
            prev_H = H
            prev_M = M
        except Exception as e:
            diag_frames.append(pd.DataFrame([{
                "exposure_date": exposure_date,
                "return_date": return_date,
                "target_theme": None,
                "solver_status": f"skipped:{type(e).__name__}",
                "return_status": f"skipped: {e}",
            }]))

    returns = pd.DataFrame(return_rows).sort_index()
    diagnostics = pd.concat(diag_frames, ignore_index=True) if diag_frames else pd.DataFrame()
    if not return_artifacts:
        return returns, diagnostics
    artifacts = BasketReplicationArtifacts(
        diagnostics=diagnostics,
        basis_diagnostics=pd.concat(basis_frames, ignore_index=True) if basis_frames else pd.DataFrame(),
        basket_weights_long=pd.concat(H_long_frames, ignore_index=True) if H_long_frames else pd.DataFrame(),
        lookthrough_stock_weights_long=(
            pd.concat(M_long_frames, ignore_index=True) if M_long_frames else pd.DataFrame()
        ),
        return_coverage=pd.DataFrame(coverage_rows),
        raw_basket_returns=pd.DataFrame(raw_basket_return_rows).sort_index(),
    )
    return returns, diagnostics, artifacts


def _pair_metrics(target: pd.Series, replica: pd.Series, annualization: int) -> dict:
    target, replica = target.align(replica, join="outer")
    target_available = int(target.notna().sum())
    replica_available = int(replica.notna().sum())
    pair = pd.concat({"target": target, "replica": replica}, axis=1).dropna()
    n = len(pair)
    total_periods = len(target.index)
    out = {
        "n_obs": n,
        "n_periods": total_periods,
        "coverage_ratio": np.nan if total_periods == 0 else n / total_periods,
        "target_coverage_ratio": np.nan if total_periods == 0 else target_available / total_periods,
        "replica_coverage_ratio": np.nan if total_periods == 0 else replica_available / total_periods,
    }
    if n == 0:
        return out
    t = pair["target"].astype(float)
    r = pair["replica"].astype(float)
    e = r - t
    out.update({
        "correlation": t.corr(r),
        "rank_correlation": t.corr(r, method="spearman"),
        "tracking_error_monthly": e.std(ddof=1),
        "tracking_error_annualized": e.std(ddof=1) * np.sqrt(annualization),
        "bias_monthly": e.mean(),
        "bias_annualized": e.mean() * annualization,
        "rmse": float(np.sqrt(np.mean(e.to_numpy() ** 2))),
        "mae": float(np.mean(np.abs(e.to_numpy()))),
        "vol_ratio": np.nan if t.std(ddof=1) == 0 else r.std(ddof=1) / t.std(ddof=1),
        "sign_hit_rate": float((np.sign(r) == np.sign(t)).mean()),
        "max_cumulative_deviation": float(e.cumsum().abs().max()),
    })
    if n >= 2 and float(np.var(t.to_numpy())) > 0:
        X = np.column_stack([np.ones(n), t.to_numpy()])
        coef = np.linalg.lstsq(X, r.to_numpy(), rcond=None)[0]
        fitted = X @ coef
        sst = float(np.sum((r.to_numpy() - r.mean()) ** 2))
        sse = float(np.sum((r.to_numpy() - fitted) ** 2))
        out["alpha_monthly"] = float(coef[0])
        out["alpha_annualized"] = float(coef[0] * annualization)
        out["beta"] = float(coef[1])
        out["r_squared"] = np.nan if sst <= 0 else 1.0 - sse / sst
    else:
        out.update({"alpha_monthly": np.nan, "alpha_annualized": np.nan, "beta": np.nan, "r_squared": np.nan})
    return out


def compare_replication_methods(
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    basket_rep: pd.DataFrame,
    diagnostics: pd.DataFrame,
    cfg: Config,
) -> dict:
    """Compare purified, stock-replicated, and basket-replicated returns on common samples."""
    purified = purified.sort_index()
    stock_rep = stock_rep.sort_index()
    basket_rep = basket_rep.sort_index()
    all_dates = purified.index.union(stock_rep.index).union(basket_rep.index).sort_values()
    all_themes = purified.columns.union(stock_rep.columns).union(basket_rep.columns)
    frames = {
        "purified": purified.reindex(index=all_dates, columns=all_themes),
        "stock_coefficient": stock_rep.reindex(index=all_dates, columns=all_themes),
        "basket_ls": basket_rep.reindex(index=all_dates, columns=all_themes),
    }
    pair_specs = [
        ("purified_vs_stock_coefficient", "purified", "stock_coefficient"),
        ("purified_vs_basket_ls", "purified", "basket_ls"),
        ("stock_coefficient_vs_basket_ls", "stock_coefficient", "basket_ls"),
    ]

    metric_rows = []
    rolling_rows = []
    cross_sectional_rows = []
    for pair_name, target_name, replica_name in pair_specs:
        target_df = frames[target_name]
        replica_df = frames[replica_name]
        for theme in all_themes:
            m = _pair_metrics(target_df[theme], replica_df[theme], cfg.annualization)
            metric_rows.append({
                "pair": pair_name,
                "target_series": target_name,
                "replica_series": replica_name,
                "theme": theme,
                **m,
            })
            pair = pd.concat({"target": target_df[theme], "replica": replica_df[theme]}, axis=1)
            rolling_corr = pair["target"].rolling(cfg.comparison_rolling_months).corr(pair["replica"])
            rolling_te = (pair["replica"] - pair["target"]).rolling(cfg.comparison_rolling_months).std(ddof=1)
            roll = pd.DataFrame({
                "date": all_dates,
                "pair": pair_name,
                "theme": theme,
                "rolling_correlation": rolling_corr.to_numpy(),
                "rolling_tracking_error_monthly": rolling_te.to_numpy(),
                "rolling_tracking_error_annualized": rolling_te.to_numpy() * np.sqrt(cfg.annualization),
            })
            rolling_rows.append(roll)

        for date in all_dates:
            x = pd.concat({"target": target_df.loc[date], "replica": replica_df.loc[date]}, axis=1).dropna()
            cross_sectional_rows.append({
                "date": date,
                "pair": pair_name,
                "n_themes": len(x),
                "cross_sectional_correlation": x["target"].corr(x["replica"]) if len(x) >= 2 else np.nan,
                "cross_sectional_rmse": (
                    float(np.sqrt(np.mean((x["replica"] - x["target"]) ** 2))) if len(x) else np.nan
                ),
            })

    metrics_by_theme = pd.DataFrame(metric_rows)
    numeric_cols = [
        c for c in metrics_by_theme.columns
        if c not in {"pair", "target_series", "replica_series", "theme"}
        and pd.api.types.is_numeric_dtype(metrics_by_theme[c])
    ]
    agg_rows = []
    for pair_name, grp in metrics_by_theme.groupby("pair", sort=False):
        for metric in numeric_cols:
            s = grp[metric].dropna()
            if len(s):
                agg_rows.append({
                    "pair": pair_name,
                    "metric": metric,
                    "mean": s.mean(),
                    "median": s.median(),
                    "q25": s.quantile(0.25),
                    "q75": s.quantile(0.75),
                    "min": s.min(),
                    "max": s.max(),
                    "n_themes": len(s),
                })
        target_name = grp["target_series"].iloc[0]
        replica_name = grp["replica_series"].iloc[0]
        target_values = frames[target_name].to_numpy().ravel()
        replica_values = frames[replica_name].to_numpy().ravel()
        pooled_mask = np.isfinite(target_values) & np.isfinite(replica_values)
        pooled_rmse = (
            float(np.sqrt(np.mean((replica_values[pooled_mask] - target_values[pooled_mask]) ** 2)))
            if pooled_mask.any() else np.nan
        )
        agg_rows.append({
            "pair": pair_name,
            "metric": "pooled_rmse",
            "mean": pooled_rmse,
            "median": np.nan,
            "q25": np.nan,
            "q75": np.nan,
            "min": np.nan,
            "max": np.nan,
            "n_themes": grp["theme"].nunique(),
        })
    metrics_aggregate = pd.DataFrame(agg_rows)

    long_parts = []
    for series_name, frame in frames.items():
        part = (
            frame.rename_axis(index="date", columns="theme")
            .reset_index()
            .melt(id_vars="date", var_name="theme", value_name="return")
        )
        part.insert(0, "series", series_name)
        long_parts.append(part)
    returns_long = pd.concat(long_parts, ignore_index=True)
    coverage = pd.DataFrame({
        name: frame.notna().sum(axis=0) / max(len(frame), 1)
        for name, frame in frames.items()
    }).rename_axis("theme").reset_index()

    solver_summary = pd.DataFrame()
    if diagnostics is not None and not diagnostics.empty and "solver_status" in diagnostics.columns:
        solver_summary = (
            diagnostics.groupby(["solver_status"], dropna=False)
            .size()
            .rename("count")
            .reset_index()
        )
    return {
        "aligned_returns": frames,
        "returns_long": returns_long,
        "metrics_by_theme": metrics_by_theme,
        "metrics_aggregate": metrics_aggregate,
        "rolling_metrics": pd.concat(rolling_rows, ignore_index=True) if rolling_rows else pd.DataFrame(),
        "cross_sectional_monthly": pd.DataFrame(cross_sectional_rows),
        "coverage": coverage,
        "solver_summary": solver_summary,
    }


def plot_three_way_replication(
    comparison: dict,
    themes: list[str] | None = None,
    max_themes: int = 4,
):
    frames = comparison["aligned_returns"]
    all_themes = list(frames["purified"].columns)
    themes = themes or all_themes[:max_themes]
    for theme in themes[:max_themes]:
        comp = pd.concat({name: frame[theme] for name, frame in frames.items()}, axis=1).dropna(how="all")
        fig, ax = plt.subplots(figsize=(9, 3.5))
        comp.cumsum().plot(ax=ax)
        ax.set_title(f"Three-way cumulative arithmetic return: {theme}")
        ax.set_ylabel("Cumulative arithmetic return")
        ax.axhline(0.0, linewidth=0.7)
        plt.show()


def plot_replication_metric_bars(comparison: dict):
    metrics = comparison["metrics_by_theme"]
    chosen = metrics[metrics["pair"].isin(["purified_vs_stock_coefficient", "purified_vs_basket_ls"])]
    if chosen.empty:
        return
    corr = chosen.pivot(index="theme", columns="pair", values="correlation")
    fig, ax = plt.subplots(figsize=(10, 4))
    corr.plot(kind="bar", ax=ax)
    ax.set_title("Theme-level replication correlation")
    ax.set_ylabel("Correlation")
    ax.set_ylim(-1.0, 1.05)
    plt.show()

    te = chosen.pivot(index="theme", columns="pair", values="tracking_error_annualized")
    fig, ax = plt.subplots(figsize=(10, 4))
    te.plot(kind="bar", ax=ax)
    ax.set_title("Theme-level annualized tracking error")
    ax.set_ylabel("Annualized tracking error")
    plt.show()


def plot_basket_snapshot_diagnostics(diag: dict):
    theme_exp = diag["theme_exposure"]
    neutral_exp = diag["neutralization_exposure"]
    H = diag["basket_weights"]

    fig, ax = plt.subplots(figsize=(8, 6))
    im = ax.imshow(theme_exp.to_numpy(), aspect="auto")
    ax.set_title("Purified-theme exposure Z' M_basket")
    ax.set_xlabel("Target theme")
    ax.set_ylabel("Exposure theme")
    ax.set_xticks(range(len(theme_exp.columns)))
    ax.set_xticklabels(theme_exp.columns, rotation=90, fontsize=7)
    ax.set_yticks(range(len(theme_exp.index)))
    ax.set_yticklabels(theme_exp.index, fontsize=7)
    fig.colorbar(im, ax=ax)
    plt.show()

    fig, ax = plt.subplots(figsize=(8, 3.5))
    im = ax.imshow(neutral_exp.to_numpy(), aspect="auto")
    ax.set_title("Neutralization exposure A' M_basket")
    ax.set_xlabel("Target theme")
    ax.set_ylabel("Neutralization factor")
    ax.set_xticks(range(len(neutral_exp.columns)))
    ax.set_xticklabels(neutral_exp.columns, rotation=90, fontsize=7)
    ax.set_yticks(range(len(neutral_exp.index)))
    ax.set_yticklabels(neutral_exp.index, fontsize=7)
    fig.colorbar(im, ax=ax)
    plt.show()

    fig, ax = plt.subplots(figsize=(8, 6))
    im = ax.imshow(H.to_numpy(), aspect="auto")
    ax.set_title("Base-basket L/S weights H")
    ax.set_xlabel("Target purified theme")
    ax.set_ylabel("Base theme basket")
    ax.set_xticks(range(len(H.columns)))
    ax.set_xticklabels(H.columns, rotation=90, fontsize=7)
    ax.set_yticks(range(len(H.index)))
    ax.set_yticklabels(H.index, fontsize=7)
    fig.colorbar(im, ax=ax)
    plt.show()


def _safe_to_parquet(df: pd.DataFrame, path: Path) -> dict:
    try:
        df.to_parquet(path, index=False)
        return {"path": str(path), "format": "parquet", "status": "ok"}
    except Exception as e:
        fallback = path.with_suffix(".csv")
        df.to_csv(fallback, index=False)
        return {
            "path": str(fallback),
            "format": "csv_fallback",
            "status": f"parquet unavailable: {type(e).__name__}: {e}",
        }


def save_replication_outputs(
    out_dir: Path,
    cfg: Config,
    theme_returns: pd.DataFrame,
    stock_rep: pd.DataFrame,
    min_risk_rep: pd.DataFrame,
    basket_rep: pd.DataFrame,
    comparison: dict,
    basket_artifacts: BasketReplicationArtifacts,
    stock_summary: pd.DataFrame,
    min_risk_summary: pd.DataFrame,
) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    theme_returns.to_csv(out_dir / "purified_theme_returns.csv")
    stock_rep.to_csv(out_dir / "coefficient_replicated_theme_returns.csv")
    stock_rep.to_csv(out_dir / "stock_coefficient_replicated_theme_returns.csv")
    min_risk_rep.to_csv(out_dir / "min_risk_replicated_theme_returns.csv")
    stock_summary.to_csv(out_dir / "coefficient_replication_summary.csv")
    min_risk_summary.to_csv(out_dir / "min_risk_replication_summary.csv")

    basket_rep.to_csv(out_dir / "basket_ls_replicated_theme_returns.csv")
    comparison["metrics_by_theme"].to_csv(out_dir / "replication_metrics_by_theme.csv", index=False)
    comparison["metrics_aggregate"].to_csv(out_dir / "replication_metrics_aggregate.csv", index=False)
    comparison["rolling_metrics"].to_csv(out_dir / "replication_rolling_metrics.csv", index=False)
    comparison["cross_sectional_monthly"].to_csv(out_dir / "replication_cross_sectional_monthly.csv", index=False)
    comparison["coverage"].to_csv(out_dir / "replication_coverage.csv", index=False)
    comparison["solver_summary"].to_csv(out_dir / "basket_solver_status_summary.csv", index=False)
    basket_artifacts.diagnostics.to_csv(out_dir / "basket_mimicking_diagnostics.csv", index=False)
    basket_artifacts.basis_diagnostics.to_csv(out_dir / "basket_basis_rank_diagnostics.csv", index=False)
    basket_artifacts.return_coverage.to_csv(out_dir / "basket_return_coverage.csv", index=False)
    basket_artifacts.raw_basket_returns.to_csv(out_dir / "raw_theme_basket_returns.csv")

    manifest = {
        "three_way_replication_returns_long": _safe_to_parquet(
            comparison["returns_long"], out_dir / "three_way_replication_returns_long.parquet"
        ),
        "basket_weights_long": _safe_to_parquet(
            basket_artifacts.basket_weights_long, out_dir / "basket_weights_long.parquet"
        ),
    }
    if cfg.save_lookthrough_stock_weights and not basket_artifacts.lookthrough_stock_weights_long.empty:
        manifest["basket_lookthrough_stock_weights_long"] = _safe_to_parquet(
            basket_artifacts.lookthrough_stock_weights_long,
            out_dir / "basket_lookthrough_stock_weights_long.parquet",
        )

    with open(out_dir / "comparison_config.json", "w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, indent=2, ensure_ascii=False)
    with open(out_dir / "config.json", "w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, indent=2, ensure_ascii=False)
    with open(out_dir / "save_manifest.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    return manifest


def run_basket_replication_self_tests(cfg: Config) -> pd.DataFrame:
    """Small deterministic tests for the core hard/soft projection solver."""
    rows = []

    # 1) Exact-span case: P=I, dollar-neutral constraint, target direction is feasible.
    n = 4
    P = np.eye(n)
    m = np.array([0.5, -0.5, 0.25, -0.25])
    F = np.ones((1, n))
    target_row = m / float(m @ m)
    Q = P.T @ P + cfg.basket_ridge_alpha * np.eye(n)
    c = P.T @ m
    h, d = _solve_projection_hard_or_soft(Q, c, F, target_row, 1.0, cfg, "constrained_risk_projection")
    exact_error = float(np.max(np.abs(h - m)))
    rows.append({
        "test": "exact_span",
        "status": "pass" if exact_error < 1e-5 and d["solver_status"].startswith("hard_solved") else "fail",
        "value": exact_error,
        "solver_status": d["solver_status"],
    })

    # 2) Infeasible target in the neutral space: target row is identical to neutrality row.
    h, d = _solve_projection_hard_or_soft(
        np.eye(3),
        np.zeros(3),
        np.ones((1, 3)),
        np.ones(3),
        1.0,
        cfg,
        "constrained_risk_projection",
    )
    rows.append({
        "test": "rank_deficient_infeasible_target",
        "status": "pass" if "soft_fallback" in d["solver_status"] else "fail",
        "value": d["constraint_feasibility_residual"],
        "solver_status": d["solver_status"],
    })

    # 3) Strongly overlapping basket basis generates a large condition number.
    eps = 1e-12
    P_overlap = np.array([[1.0, 1.0], [0.0, eps]])
    cond = _condition_number(P_overlap, cfg.basket_rank_tolerance)
    rows.append({
        "test": "overlapping_baskets_condition_number",
        "status": "pass" if (np.isinf(cond) or cond > cfg.basket_condition_number_warning) else "fail",
        "value": cond,
        "solver_status": "diagnostic",
    })

    # 4) Explicit dollar-neutral constraint when no intercept is present.
    net = np.ones((1, 2)) @ np.eye(2)
    h, d = _solve_projection_hard_or_soft(
        np.eye(2),
        np.array([1.0, -1.0]),
        net,
        np.array([1.0, -1.0]),
        1.0,
        cfg,
        "constrained_risk_projection",
    )
    rows.append({
        "test": "explicit_dollar_neutrality",
        "status": "pass" if abs(h.sum()) < cfg.basket_constraint_tolerance else "fail",
        "value": float(abs(h.sum())),
        "solver_status": d["solver_status"],
    })

    # 5) Missing-return policy records and zero-fills only under an explicit policy.
    cfg_missing = Config(**asdict(cfg))
    cfg_missing.missing_return_policy = "zero_with_flag"
    tiny_data = {
        "stock_returns": pd.DataFrame(
            [[0.01, np.nan, -0.02]],
            index=[pd.Timestamp("2020-01-31")],
            columns=["A", "B", "C"],
        )
    }
    rv, rdiag = _return_vector_with_policy(
        tiny_data, pd.Timestamp("2020-01-31"), pd.Index(["A", "B", "C"]), cfg_missing
    )
    missing_ok = (rdiag["n_missing_stock_returns"] == 1 and rv.loc["B"] == 0.0)
    rows.append({
        "test": "missing_return_policy_zero_with_flag",
        "status": "pass" if missing_ok else "fail",
        "value": float(rdiag["stock_return_coverage"]),
        "solver_status": "policy_diagnostic",
    })
    return pd.DataFrame(rows)


def save_replication_figures(
    out_dir: Path,
    comparison: dict,
    basket_artifacts: BasketReplicationArtifacts,
    sample_basket_diag: dict | None = None,
    max_themes: int = 4,
) -> list[str]:
    """Persist the main diagnostic figures and return their filenames."""
    figure_dir = Path(out_dir) / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    written = []
    frames = comparison["aligned_returns"]
    metrics = comparison["metrics_by_theme"]

    basket_metrics = metrics[metrics["pair"].eq("purified_vs_basket_ls")].sort_values(
        "correlation", ascending=False
    )
    selected = basket_metrics["theme"].dropna().head(max_themes).tolist()
    if not selected:
        selected = list(frames["purified"].columns[:max_themes])

    for theme in selected:
        comp = pd.concat({name: frame[theme] for name, frame in frames.items()}, axis=1).dropna(how="all")
        fig, ax = plt.subplots(figsize=(9, 3.5))
        comp.cumsum().plot(ax=ax)
        ax.set_title(f"Three-way cumulative arithmetic return: {theme}")
        ax.set_ylabel("Cumulative arithmetic return")
        ax.axhline(0.0, linewidth=0.7)
        fig.tight_layout()
        path = figure_dir / f"three_way_cumulative_{theme}.png"
        fig.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        written.append(str(path))

        pair = pd.concat(
            {"purified": frames["purified"][theme], "basket_ls": frames["basket_ls"][theme]},
            axis=1,
        ).dropna()
        if len(pair):
            fig, ax = plt.subplots(figsize=(4.5, 4.5))
            ax.scatter(pair["purified"], pair["basket_ls"], s=16, alpha=0.7)
            lo = float(min(pair.min()))
            hi = float(max(pair.max()))
            ax.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1.0)
            ax.set_xlabel("Purified theme return")
            ax.set_ylabel("Basket L/S replica")
            ax.set_title(f"Purified vs basket L/S: {theme}")
            fig.tight_layout()
            path = figure_dir / f"scatter_purified_vs_basket_{theme}.png"
            fig.savefig(path, dpi=150, bbox_inches="tight")
            plt.close(fig)
            written.append(str(path))

    chosen = metrics[metrics["pair"].isin(["purified_vs_stock_coefficient", "purified_vs_basket_ls"])]
    if not chosen.empty:
        corr = chosen.pivot(index="theme", columns="pair", values="correlation")
        fig, ax = plt.subplots(figsize=(11, 4.5))
        corr.plot(kind="bar", ax=ax)
        ax.set_title("Theme-level replication correlation")
        ax.set_ylabel("Correlation")
        ax.set_ylim(-1.0, 1.05)
        fig.tight_layout()
        path = figure_dir / "theme_replication_correlation.png"
        fig.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        written.append(str(path))

        te = chosen.pivot(index="theme", columns="pair", values="tracking_error_annualized")
        fig, ax = plt.subplots(figsize=(11, 4.5))
        te.plot(kind="bar", ax=ax)
        ax.set_title("Theme-level annualized tracking error")
        ax.set_ylabel("Annualized tracking error")
        fig.tight_layout()
        path = figure_dir / "theme_replication_tracking_error.png"
        fig.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        written.append(str(path))

    rolling = comparison["rolling_metrics"]
    if selected and not rolling.empty:
        theme = selected[0]
        roll = rolling[
            rolling["theme"].eq(theme)
            & rolling["pair"].eq("purified_vs_basket_ls")
        ].set_index("date")
        if len(roll):
            fig, ax = plt.subplots(figsize=(9, 3.5))
            roll["rolling_correlation"].plot(ax=ax)
            ax.set_title(f"Rolling correlation: purified vs basket L/S — {theme}")
            ax.set_ylabel("Correlation")
            fig.tight_layout()
            path = figure_dir / f"rolling_correlation_{theme}.png"
            fig.savefig(path, dpi=150, bbox_inches="tight")
            plt.close(fig)
            written.append(str(path))

            fig, ax = plt.subplots(figsize=(9, 3.5))
            roll["rolling_tracking_error_annualized"].plot(ax=ax)
            ax.set_title(f"Rolling annualized tracking error — {theme}")
            ax.set_ylabel("Annualized tracking error")
            fig.tight_layout()
            path = figure_dir / f"rolling_tracking_error_{theme}.png"
            fig.savefig(path, dpi=150, bbox_inches="tight")
            plt.close(fig)
            written.append(str(path))

    diag = basket_artifacts.diagnostics.copy()
    basis = basket_artifacts.basis_diagnostics.copy()
    if not diag.empty:
        ts = diag.groupby("exposure_date").agg(
            median_basket_gross=("basket_gross", "median"),
            median_max_abs_weight=("max_abs_basket_weight", "median"),
            max_condition_number=("condition_number_kkt", "max"),
        )
        for col, title in [
            ("median_basket_gross", "Median basket gross by exposure date"),
            ("median_max_abs_weight", "Median maximum absolute basket weight"),
            ("max_condition_number", "Maximum KKT condition number"),
        ]:
            fig, ax = plt.subplots(figsize=(9, 3.5))
            ts[col].plot(ax=ax)
            ax.set_title(title)
            ax.set_ylabel(col)
            if col == "max_condition_number":
                ax.set_yscale("log")
            fig.tight_layout()
            path = figure_dir / f"{col}.png"
            fig.savefig(path, dpi=150, bbox_inches="tight")
            plt.close(fig)
            written.append(str(path))
    if not basis.empty and "neutral_nullspace_dimension" in basis:
        fig, ax = plt.subplots(figsize=(9, 3.5))
        basis.set_index("exposure_date")["neutral_nullspace_dimension"].plot(ax=ax)
        ax.set_title("Neutral basket null-space dimension")
        ax.set_ylabel("Dimension")
        fig.tight_layout()
        path = figure_dir / "neutral_nullspace_dimension.png"
        fig.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        written.append(str(path))

    if sample_basket_diag is not None:
        for matrix_name, title in [
            ("theme_exposure", "Purified-theme exposure Z' M_basket"),
            ("neutralization_exposure", "Neutralization exposure A' M_basket"),
            ("basket_weights", "Base-basket L/S weights H"),
        ]:
            matrix = sample_basket_diag[matrix_name]
            fig, ax = plt.subplots(figsize=(8, 6 if matrix_name != "neutralization_exposure" else 3.5))
            im = ax.imshow(matrix.to_numpy(), aspect="auto")
            ax.set_title(title)
            ax.set_xticks(range(len(matrix.columns)))
            ax.set_xticklabels(matrix.columns, rotation=90, fontsize=7)
            ax.set_yticks(range(len(matrix.index)))
            ax.set_yticklabels(matrix.index, fontsize=7)
            fig.colorbar(im, ax=ax)
            fig.tight_layout()
            path = figure_dir / f"sample_{matrix_name}.png"
            fig.savefig(path, dpi=150, bbox_inches="tight")
            plt.close(fig)
            written.append(str(path))

    return written


# Existing strategy helpers are retained for backward compatibility.
def normalize_factor_weights(w: pd.Series, gross: float = 1.0) -> pd.Series:
    w = w.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
    s = w.abs().sum()
    if s <= 0:
        return w
    return gross * w / s


def stock_weights_from_factor_weights(M: pd.DataFrame, factor_weights: pd.Series, cfg: Config) -> tuple[pd.Series, float, float]:
    wF = factor_weights.reindex(M.columns).fillna(0.0)
    stock_w = M.dot(wF)
    pre_gross = float(stock_w.abs().sum())
    if pre_gross > 0:
        scale = cfg.target_stock_gross / pre_gross
        stock_w = stock_w * scale
    else:
        scale = 0.0
    return stock_w, pre_gross, scale


def one_way_turnover(prev: pd.Series, curr: pd.Series) -> float:
    idx = prev.index.union(curr.index)
    delta = curr.reindex(idx, fill_value=0.0) - prev.reindex(idx, fill_value=0.0)
    return 0.5 * float(delta.abs().sum())


def performance_metrics(returns: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    rows = []
    for col in ["gross_return", "net_return"]:
        r = returns[col].dropna()
        if len(r) == 0:
            continue
        ann_mean = r.mean() * cfg.annualization
        ann_vol = r.std(ddof=1) * np.sqrt(cfg.annualization)
        sharpe = np.nan if ann_vol == 0 else ann_mean / ann_vol
        tstat = np.nan if r.std(ddof=1) == 0 else r.mean() / r.std(ddof=1) * np.sqrt(len(r))
        cum = (1 + r).cumprod()
        dd = cum / cum.cummax() - 1.0
        rows.append({
            "series": col,
            "n_months": len(r),
            "ann_mean": ann_mean,
            "ann_vol": ann_vol,
            "sharpe": sharpe,
            "t_stat_mean": tstat,
            "max_drawdown": dd.min(),
            "hit_rate": (r > 0).mean(),
        })
    out = pd.DataFrame(rows).set_index("series")
    if "turnover" in returns.columns and len(returns):
        out["avg_annual_turnover"] = returns["turnover"].mean() * cfg.annualization
    return out


def run_factor_strategy_backtest(data: dict, cfg: Config, theme_returns: pd.DataFrame, signal_func, strategy_name: str, momentum_neutral: bool = False):
    theme_returns = theme_returns.dropna(axis=1, how="all").sort_index()
    records = []
    factor_weight_rows = []
    prev_stock_w = pd.Series(dtype=float)
    stored_weight_tables = {}
    dates = list(theme_returns.index)

    for i in range(cfg.min_history_months, len(dates) - 1):
        signal_date = dates[i]
        next_date = dates[i + 1]
        hist = theme_returns.loc[:signal_date]
        wF, signal_info = signal_func(hist, signal_date, cfg)
        wF = normalize_factor_weights(wF, gross=1.0)
        if wF.abs().sum() <= 0:
            continue
        try:
            M, mim_diag = construct_mimicking_portfolios(data, cfg, signal_date, momentum_neutral=momentum_neutral, mode=cfg.mimicking_mode)
        except Exception as e:
            print(f"Skipped {signal_date.date()}: {e}")
            continue
        wF = wF.reindex(M.columns).fillna(0.0)
        stock_w, pre_gross, scale = stock_weights_from_factor_weights(M, wF, cfg)
        r_next = data["stock_returns"].loc[next_date, stock_w.index].fillna(0.0)
        gross_ret = float(stock_w.dot(r_next))
        turnover = one_way_turnover(prev_stock_w, stock_w)
        tc = turnover * cfg.transaction_cost_bps_one_way / 10000.0
        net_ret = gross_ret - tc
        records.append({
            "date": next_date,
            "signal_date": signal_date,
            "gross_return": gross_ret,
            "net_return": net_ret,
            "turnover": turnover,
            "transaction_cost": tc,
            "pre_scale_stock_gross": pre_gross,
            "stock_weight_scale": scale,
            "n_long_factors": int((wF > 0).sum()),
            "n_short_factors": int((wF < 0).sum()),
        })
        factor_weight_rows.append(wF.rename(signal_date))
        if len(stored_weight_tables) < 3:
            order = stock_w.abs().sort_values(ascending=False).index[: cfg.max_weight_table_rows]
            stored_weight_tables[pd.Timestamp(signal_date)] = stock_w.reindex(order).rename("stock_weight").to_frame()
        prev_stock_w = stock_w

    returns = pd.DataFrame(records).set_index("date").sort_index() if records else pd.DataFrame()
    factor_weights = pd.DataFrame(factor_weight_rows).sort_index() if factor_weight_rows else pd.DataFrame()
    metrics = performance_metrics(returns, cfg) if len(returns) else pd.DataFrame()
    return {
        "strategy_name": strategy_name,
        "returns": returns,
        "factor_weights": factor_weights,
        "metrics": metrics,
        "sample_stock_weight_tables": stored_weight_tables,
    }


def plot_strategy_outputs(result: dict):
    returns = result["returns"]
    if returns.empty:
        print("No strategy returns to plot.")
        return
    fig, ax = plt.subplots(figsize=(9, 4))
    (1 + returns["gross_return"]).cumprod().plot(ax=ax, label="gross")
    (1 + returns["net_return"]).cumprod().plot(ax=ax, label="net")
    ax.set_title(result["strategy_name"] + ": cumulative return")
    ax.set_ylabel("Growth of 1")
    ax.legend()
    plt.show()

    fig, ax = plt.subplots(figsize=(9, 3))
    returns["turnover"].plot(ax=ax)
    ax.set_title(result["strategy_name"] + ": one-way turnover")
    ax.set_ylabel("Turnover")
    plt.show()


def save_strategy_outputs(result: dict, cfg: Config, subdir: str):
    out_dir = Path(cfg.output_dir) / subdir
    out_dir.mkdir(parents=True, exist_ok=True)
    if not result["returns"].empty:
        result["returns"].to_csv(out_dir / "strategy_returns.csv")
    if not result["factor_weights"].empty:
        result["factor_weights"].to_csv(out_dir / "factor_weights.csv")
    if not result["metrics"].empty:
        result["metrics"].to_csv(out_dir / "metrics.csv")
    with open(out_dir / "config.json", "w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, indent=2, ensure_ascii=False)
    return out_dir
