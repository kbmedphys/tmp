# Theme-basket L/S replication implementation

## Main deliverables

- `00_mimicking_portfolio_diagnostics_theme_basket_implemented_executed.ipynb`
  - Executed notebook with synthetic data.
  - Implements purified theme returns, stock coefficient replication, stock minimum-risk proxy, and theme-basket L/S replication.
- `theme_basket_mimicking.py`
  - Standalone implementation of the Config, exposure snapshots, solvers, diagnostics, comparison metrics, plotting, and persistence functions.
- `theme_factor_momentum_outputs/00_mimicking_portfolio_diagnostics/`
  - Executed output files and figures.

## Production input

Add the following point-in-time input to the pickle:

```python
"theme_basket_weights_by_date": dict[pd.Timestamp, pd.DataFrame]
```

Each DataFrame is stock × tradeable theme basket. Columns must correspond to the active theme columns. In production, set:

```python
cfg.basket_fallback_to_theme_exposures = False
```

so that factor-construction scores are not implicitly treated as tradeable basket weights.

## Main functions

```python
construct_basket_mimicking_portfolios(...)
basket_replicated_theme_returns(...)
compare_replication_methods(...)
save_replication_outputs(...)
```

The hard solver projects each stock coefficient-replicating portfolio into the neutral theme-basket span subject to:

- neutralization exposure = 0;
- target purified-theme exposure = 1.

Rank deficiency and infeasibility are recorded and can fall back to a soft-penalty solution.

## Executed validation results

- Stock coefficient-replica max absolute error: `1.07e-09`.
- Basket-return identity max absolute error: `1.39e-16`.
- Hard-solved maximum neutrality exposure: `5.77e-15`.
- Hard-solved maximum target-exposure error: `1.78e-15`.
- All five synthetic solver/policy self-tests passed.
