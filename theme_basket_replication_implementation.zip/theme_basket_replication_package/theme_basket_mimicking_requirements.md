# 純化テーマファクターのテーマバスケット・ロングショート複製：実装要件定義書

- 対象ノートブック: `00_mimicking_portfolio_diagnostics(2).ipynb`
- 作成日: 2026-07-13
- 目的: 純化テーマファクターリターン、個別銘柄ロングショートによる複製リターン、テーマバスケットロングショートによる複製リターンを、同一条件で比較可能にする。

## 1. 結論・推奨方式

現行の個別銘柄方式は、純化テーマエクスポージャーを \(Z_t\) とすると、

\[
M^{\mathrm{stock}}_t
=Z_t\left(Z_t'Z_t+\alpha I\right)^{+}
\]

を個別銘柄ウェイトとして用い、

\[
\tilde g^{\mathrm{stock}}_{t+1}
={M^{\mathrm{stock}}_t}'r_{t+1}
\]

により推定された純化テーマファクターリターン \(\hat g_{t+1}\) を数値誤差の範囲で再現する設計である。

追加するテーマバスケット方式では、売買可能なテーマバスケットの構成銘柄ウェイト行列を \(P_t\in\mathbb{R}^{N\times K}\)、各純化テーマを複製するためのバスケット配分行列を \(H_t\in\mathbb{R}^{K\times K}\) とし、

\[
M^{\mathrm{basket}}_t=P_tH_t,
\qquad
\tilde g^{\mathrm{basket}}_{t+1}
={H_t}'P_t'r_{t+1}
={M^{\mathrm{basket}}_t}'r_{t+1}
\]

を計算する。

MVPの推奨方式は、各対象テーマ \(k\) について、個別銘柄複製ポートフォリオ \(m^{\mathrm{stock}}_{k,t}\) をテーマバスケット空間へ制約付きリスク射影する方式である。

\[
\min_h
\left(P_th-m^{\mathrm{stock}}_{k,t}\right)'
D_t
\left(P_th-m^{\mathrm{stock}}_{k,t}\right)
+\lambda_H h'R_Hh
\]

subject to

\[
A_t'P_th=0,
\qquad
z_{k,t}'P_th=1.
\]

ここで、\(A_t\) は切片、Barraエクスポージャー、必要に応じて個別銘柄モメンタムを含む中立化行列、\(D_t\) は対角リスク行列、\(z_{k,t}\) は対象純化テーマエクスポージャーである。

この方式により、以下を同時に満たす。

1. 個別銘柄方式と同じ純化テーマを複製対象とする。
2. バスケットの組合せのみで実装する。
3. 切片を含むBarra中立性を保ち、ドルニュートラルなロングショートとする。
4. 対象テーマの単位エクスポージャーを維持し、回帰係数と同じリターン単位で比較する。
5. バスケット空間に含まれない個別銘柄ヘッジ部分を最小化し、その残差をトラッキングエラーとして計測する。

## 2. 現行ノートブックの理解

現行ノートブックは以下の処理を行う。

1. `stock_returns`、`barra_exposures_by_date`、`theme_exposures_by_date` を読み込む。
2. 各時点でテーマエクスポージャー \(X_t\) をBarraエクスポージャーに対して残差化し、列ごとにL2正規化して \(Z_t\) を作る。
3. 翌月リターン \(r_{t+1}\) をBarra部分とテーマ部分に分け、純化テーマファクターリターン \(\hat g_{t+1}\) を推定する。
4. `mode="coefficient"` で係数複製ポートフォリオを作り、\(\hat g_{t+1}\) を機械的に再現する。
5. `mode="min_risk"` でBarra中立・単位テーマエクスポージャーを満たす個別銘柄ベースの低リスクproxyを作る。
6. 純化テーマリターンと個別銘柄複製リターンの相関、月次トラッキングエラー、エクスポージャー、グロス等を出力する。

今回の必須比較系列は以下の3系列とする。

- `purified_theme_returns`: 純化テーマファクターリターン
- `stock_coefficient_replicated_theme_returns`: 個別銘柄ロングショートによる係数複製
- `basket_ls_replicated_theme_returns`: テーマバスケットロングショートによる複製

現行の `min_risk_replicated_theme_returns` は補足系列として残すが、必須3系列の主比較には混在させない。

## 3. 構造上の制約

テーマバスケットだけで全純化テーマを完全複製できるとは限らない。

テーマバスケットのBarraエクスポージャーを \(A_t'P_t\) とすると、Barra中立なバスケット配分は

\[
\mathcal{N}_t=\ker(A_t'P_t)
\]

に属する。その次元は

\[
d_t=K-\operatorname{rank}(A_t'P_t)
\]

である。したがって、Barra中立なテーマバスケットポートフォリオが張れる独立方向は最大でも \(d_t\) 本である。

添付ノートブックの合成データ設定では、テーマ数14、Barra因子数6、切片ありである。\(A_t'P_t\) が通常のフル行ランク7であれば、中立バスケット空間の次元は7であり、14個の独立な純化テーマ方向を同時に完全複製することはできない。各テーマについて個別に近似ポートフォリオは作成できるが、オフテーマエクスポージャーや系列間の線形従属性が残る。

この差は実装不良ではなく、テーマバスケット空間の表現力の限界である。実装では必ずランク、条件数、制約残差、オフテーマ汚染を出力する。

## 4. データ要件

### 4.1 既存入力

| キー | 形状 | 用途 |
|---|---:|---|
| `stock_returns` | date × stock | 翌期の個別銘柄単純リターン |
| `barra_exposures_by_date` | stock × Barra factor | 純化、中立化、診断 |
| `theme_exposures_by_date` | stock × theme | 純化テーマ \(Z_t\) の構築 |
| `cash_returns` | date | 非ゼロネット系列を作る場合の資金調達。主比較では原則未使用 |

### 4.2 新規入力

新規キーとして、以下を追加する。

```python
"theme_basket_weights_by_date": dict[pd.Timestamp, pd.DataFrame]
```

各DataFrameは以下を満たす。

- 行: 個別銘柄
- 列: テーマバスケット
- 値: exposure date時点で実際に保有するロングオンリー構成ウェイト
- 各列の合計: 原則1.0
- 各要素: 原則0以上
- ルックアヘッドを含まないpoint-in-timeデータ
- テーマ名は `theme_exposures_by_date` の列名と明示的に対応づける

`theme_exposures_by_date` はファクター構築用スコア、所属フラグ、時価総額ウェイトなどを含み得るため、売買可能なバスケットウェイトと同一であるとは限らない。したがって、本番環境では両者を別入力とする。

`theme_basket_weights_by_date` が存在しない場合に `theme_exposures_by_date` を代用できるのは、以下の全条件を満たすデモ・後方互換モードに限定する。

- 全要素が非負
- 各列合計が正
- 列を合計1に正規化しても経済的意味が変わらない
- `basket_fallback_to_theme_exposures=True`

条件を満たさない場合は暗黙変換せずエラーまたは `status="invalid_basket_input"` とする。

### 4.3 データ整合性

各 exposure date について以下を検証する。

- stock return universe、Barra universe、theme exposure universe、basket universeの共通銘柄数
- 各バスケットの構成銘柄数、最大構成比、HHI、ウェイト合計、負ウェイト件数
- 各テーマの存在期間と列名対応
- exposure dateとreturn dateの対応が必ず1期ラグであること
- 欠損リターンのカバレッジ
- 休止・上場廃止・企業行動を調整済みのリターンであること

現行コードの `fillna(0.0)` は、本番比較では原則として無条件に使用しない。欠損リターン処理は3系列で統一し、以下から設定する。

- `error`: 欠損があれば当該日・テーマを無効化
- `coverage_threshold`: ウェイトカバレッジが閾値以上なら利用し、欠損影響を診断出力
- `zero_with_flag`: デモ互換用。ゼロ補完し、必ず欠損ウェイト比率を出力

## 5. 数理仕様

### 5.1 純化テーマファクターリターン

中立化行列を \(A_t\)、テーマエクスポージャーを \(X_t\) とする。

\[
\tilde Z_t
=X_t-A_t(A_t'A_t+\lambda I)^{+}A_t'X_t
\]

各列をL2正規化して \(Z_t\) を得る。

\[
u_{t+1}=r_{t+1}-A_t\hat\beta_{t+1}
\]

\[
\hat g_{t+1}
=(Z_t'Z_t+\alpha I)^{+}Z_t'u_{t+1}
\]

この計算は現行ロジックを変更しない。

### 5.2 個別銘柄ロングショート複製

\[
M^{\mathrm{stock}}_t
=Z_t(Z_t'Z_t+\alpha I)^{+}
\]

\[
\tilde g^{\mathrm{stock}}_{t+1}
={M^{\mathrm{stock}}_t}'r_{t+1}
\]

主比較では `coefficient` modeを使用する。`min_risk` modeは補足比較とする。

### 5.3 テーマバスケット・ロングショート複製

テーマバスケット構成ウェイトを \(P_t\) とする。各対象テーマ \(k\) の個別銘柄複製ウェイトを \(m^{\mathrm{stock}}_{k,t}\) とし、テーマバスケット配分 \(h_{k,t}\) を求める。

#### 推奨デフォルト: `constrained_risk_projection`

\[
\min_h
\frac12 h'Q_{H,t}h-c_{k,t}'h
\]

ここで、

\[
Q_{H,t}=P_t'D_tP_t+\lambda_HR_H,
\qquad
c_{k,t}=P_t'D_tm^{\mathrm{stock}}_{k,t}.
\]

制約行列と目標を

\[
G_{k,t}=
\begin{bmatrix}
A_t'P_t\\
z_{k,t}'P_t
\end{bmatrix},
\qquad
 d_k=
\begin{bmatrix}
0\\
1
\end{bmatrix}
\]

とし、KKT系

\[
\begin{bmatrix}
Q_{H,t} & G_{k,t}'\\
G_{k,t} & 0
\end{bmatrix}
\begin{bmatrix}
h_{k,t}\\
\nu_{k,t}
\end{bmatrix}
=
\begin{bmatrix}
c_{k,t}\\
d_k
\end{bmatrix}
\]

をSVDまたは擬似逆行列で解く。

- \(A_t\) に切片が含まれる場合、\(A_t'P_th=0\) はドルニュートラルを含む。
- 切片を含めない設定では、\(\mathbf 1'P_th=0\) を別制約として必ず追加する。
- `momentum_neutral=True` の場合、個別銘柄モメンタムを \(A_t\) に含める。
- \(D_t\) は本番ではBarra specific variance等を優先する。現行 `specific_risk_diag` は実際には過去個別銘柄リターンの対角分散proxyであり、名称と定義を一致させる。
- \(R_H\) のデフォルトは単位行列。バスケットリスクまたは流動性ペナルティを用いる拡張を許容する。

#### 制約が不可能または不安定な場合

以下を順に実施する。

1. SVD/QRで冗長な中立化制約を除く。
2. `constraint_feasibility_residual` を計算する。
3. 対象テーマの中立部分空間内エクスポージャーが閾値未満なら `status="infeasible_target_exposure"` とする。
4. 設定によりsoft-penaltyへフォールバックする。

Soft-penalty例:

\[
\min_h
(P_th-m_k)'D_t(P_th-m_k)
+\rho_A\|A_t'P_th\|_2^2
+\rho_T(z_{k,t}'P_th-1)^2
+\rho_C\|(Z_t'P_th-e_k)_{-k}\|_2^2
+\lambda_H\|h\|_2^2.
\]

フォールバックを行った場合、hard制約系列と混同しないよう `solver_status`、制約残差、適用モードを保存する。例外を握りつぶして無言でスキップしてはならない。

### 5.4 診断モードと投資可能モードの分離

主比較は回帰係数と同じ単位で行うため、以下を適用する。

- 個別銘柄複製ウェイトをグロス1へ再スケーリングしない。
- バスケット配分をグロス1へ再スケーリングしない。
- 対象テーマの単位エクスポージャーを維持する。
- 取引コスト控除前のgross returnを主比較とする。

別途、投資可能性を確認する `investable` モードを設けてもよい。

- バスケットグロス上限
- バスケット別絶対ウェイト上限
- 対象テーマの元バスケットをロングにする制約
- 最小ロング・ショート本数
- 取引コスト
- ターンオーバーペナルティ

この系列はスケールが変わるため、純化テーマファクターリターンとの主比較には使用せず、別パネルで報告する。

## 6. 機能要件

### FR-01 現行推定結果の維持

- `estimate_theme_returns` の推定ロジック、ラグ、正規化、ridge設定を変更しない。
- 同一入力・同一Configで既存 `purified_theme_returns` が再現されること。

### FR-02 個別銘柄複製の参照系列化

- `construct_mimicking_portfolios(..., mode="coefficient")` を参照系列とする。
- 関数名を `construct_stock_mimicking_portfolios` に明確化してもよいが、後方互換ラッパーを残す。
- `min_risk` は補足系列として維持する。

### FR-03 売買可能バスケット行列の生成

新規関数:

```python
def prepare_theme_basket_weights(
    data: dict,
    date: pd.Timestamp,
    stock_index: pd.Index,
    theme_columns: pd.Index,
    cfg: Config,
) -> tuple[pd.DataFrame, dict]:
    ...
```

要件:

- Point-in-timeの \(P_t\) を返す。
- stock/themeの並びを明示的に合わせる。
- 列和、非負性、構成銘柄数、集中度、欠損を検証する。
- 正規化前後の情報を診断として返す。

### FR-04 中立化行列の一元化

現行 `snapshot_for_date` は、`momentum_neutral=True` の場合に実際の残差化行列と返却する `B_aug` が異なる。バスケット制約との整合性を保つため、以下のいずれかを実施する。

- `snapshot_for_date` が `neutralization_exposures=A_t` を返す。
- `ExposureSnapshot` dataclassを新設し、`B_aug`、`neutralization_exposures`、`X`、`Z`、active universeを保持する。

純化に使用した行列とポートフォリオ中立化に使用する行列は完全に一致させる。

### FR-05 バスケット複製ポートフォリオの構築

新規関数:

```python
def construct_basket_mimicking_portfolios(
    data: dict,
    cfg: Config,
    date: pd.Timestamp,
    momentum_neutral: bool = False,
    stock_target_mode: str = "coefficient",
    basket_mode: str = "constrained_risk_projection",
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Return H_basket, M_lookthrough=P@H, diagnostics."""
```

返却値:

- `H_basket`: base basket × target purified theme
- `M_lookthrough`: stock × target purified theme
- `diagnostics`: ランク、条件数、制約、エクスポージャー、グロス等

実装上、\(N\times N\) の対角行列を明示的に生成せず、`P.mul(q, axis=0).T @ P` 等で計算する。

### FR-06 バスケット複製リターンの生成

新規関数:

```python
def basket_replicated_theme_returns(
    data: dict,
    cfg: Config,
    theme_returns: pd.DataFrame,
    momentum_neutral: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    ...
```

各 return date \(t+1\) について、必ず直前の exposure date \(t\) のデータだけを使う。

以下の恒等式を毎回検証する。

\[
H_t'(P_t'r_{t+1})=(P_tH_t)'r_{t+1}.
\]

差が許容誤差を超えた場合はエラーとする。

### FR-07 3系列比較

新規関数:

```python
def compare_replication_methods(
    purified: pd.DataFrame,
    stock_rep: pd.DataFrame,
    basket_rep: pd.DataFrame,
    diagnostics: pd.DataFrame,
    cfg: Config,
) -> dict:
    ...
```

比較は同一theme・同一dateの共通サンプルで行う。ただし、各方式のcoverageも別途保存し、共通サンプル化による情報消失を見える化する。

### FR-08 可視化

最低限、以下を出力する。

1. 各テーマの3系列累積算術リターン
2. 純化テーマ対個別銘柄複製、純化テーマ対バスケット複製の散布図と45度線
3. テーマ別相関の棒グラフ
4. テーマ別月次・年率トラッキングエラーの棒グラフ
5. 36か月rolling correlationとrolling tracking error
6. `Z' M_basket` のテーマエクスポージャーヒートマップ
7. `A' M_basket` の中立化エクスポージャーヒートマップ
8. バスケットグロス、最大絶対ウェイト、条件数、null-space次元の時系列

ファクターリターン比較では累積和を主表示とし、投資可能ポートフォリオ表示では複利累積を別表示する。

### FR-09 保存

既存出力を維持し、以下を追加する。

- `basket_ls_replicated_theme_returns.csv`
- `three_way_replication_returns_long.parquet`
- `replication_metrics_by_theme.csv`
- `replication_metrics_aggregate.csv`
- `basket_weights_long.parquet`
- `basket_lookthrough_stock_weights_long.parquet`（設定で任意）
- `basket_mimicking_diagnostics.csv`
- `basket_basis_rank_diagnostics.csv`
- `comparison_config.json`
- 図表一式

## 7. 比較指標

### 7.1 リターン複製精度

各テーマについて、以下のペアを比較する。

- purified vs stock coefficient replica
- purified vs basket L/S replica
- stock coefficient replica vs basket L/S replica

必須指標:

| 指標 | 定義 |
|---|---|
| `n_obs` | 共通有効月数 |
| `coverage_ratio` | 対象期間に対する有効月比率 |
| `correlation` | Pearson相関 |
| `rank_correlation` | Spearman相関 |
| `tracking_error_monthly` | \(\operatorname{std}(replica-target)\) |
| `tracking_error_annualized` | 月次TE × \(\sqrt{12}\) |
| `bias_monthly` | \(\operatorname{mean}(replica-target)\) |
| `bias_annualized` | 月次bias × 12 |
| `rmse` | 複製誤差の二乗平均平方根 |
| `mae` | 複製誤差の絶対値平均 |
| `beta` | `replica = alpha + beta * target + error` のbeta |
| `alpha_annualized` | 上記回帰alpha × 12 |
| `r_squared` | 上記回帰の決定係数 |
| `vol_ratio` | replica vol / target vol |
| `sign_hit_rate` | 符号一致率 |
| `max_cumulative_deviation` | 累積算術誤差の最大絶対値 |

集計指標:

- テーマ別指標の平均、中央値、25/75パーセンタイル、最悪値
- 各月のテーマ横断相関
- 全テーマ・全月のpooled RMSE
- rolling 36か月相関・TEの分布

### 7.2 ポートフォリオ診断

各 exposure date・target themeについて、以下を保存する。

- `rank_basket_matrix`
- `rank_neutralization_exposure_on_baskets`
- `neutral_nullspace_dimension`
- `rank_theme_exposure_in_neutral_space`
- `condition_number_kkt`
- `solver_status`
- `constraint_feasibility_residual`
- `max_abs_neutralization_exposure`
- `target_theme_exposure`
- `off_target_theme_exposure_l1`
- `off_target_theme_exposure_l2`
- `off_target_theme_exposure_max`
- `basket_gross`
- `basket_net`
- `basket_long_gross`
- `basket_short_gross`
- `max_abs_basket_weight`
- `n_long_baskets`
- `n_short_baskets`
- `own_theme_basket_weight`
- `lookthrough_stock_gross`
- `lookthrough_stock_net`
- `risk_weighted_distance_to_stock_target`
- `cosine_similarity_to_stock_target`
- `ex_ante_tracking_error_to_stock_target`

### 7.3 ターンオーバーとコスト

主比較はコスト控除前とする。補足診断として以下を分けて出す。

1. バスケット配分ターンオーバー

\[
\frac12\sum_j|h_{j,t}-h_{j,t-1}|
\]

2. ルックスルー個別銘柄ターンオーバー

\[
\frac12\sum_i|(P_tH_t)_{i,k}-(P_{t-1}H_{t-1})_{i,k}|
\]

3. テーマバスケットがETF・スワップ等の単一商品として売買される場合のinstrument-level cost
4. 構成銘柄を直接売買する場合のlook-through stock-level cost

実装形態が異なるため、両者を同じ取引コスト率で混ぜない。

## 8. Config追加要件

```python
@dataclass
class Config:
    # Existing fields remain unchanged

    # Basket data
    theme_basket_weights_key: str = "theme_basket_weights_by_date"
    basket_fallback_to_theme_exposures: bool = True   # Demo only
    basket_require_long_only_base: bool = True
    basket_column_sum_target: float = 1.0
    basket_min_constituents: int = 5
    basket_min_return_coverage: float = 0.98

    # Basket replication
    basket_replication_mode: str = "constrained_risk_projection"
    basket_ridge_alpha: float = 1e-6
    basket_risk_model: str = "diagonal_variance"
    basket_enforce_neutrality: bool = True
    basket_enforce_target_exposure: bool = True
    basket_target_exposure: float = 1.0
    basket_soft_neutrality_penalty: float = 1e4
    basket_soft_target_penalty: float = 1e4
    basket_offtheme_penalty: float = 0.0

    # Optional investable constraints
    basket_require_own_theme_long: bool = False
    basket_min_own_theme_weight: float = 0.0
    basket_gross_cap: float | None = None
    basket_max_abs_weight: float | None = None

    # Numerical controls
    basket_rank_tolerance: float = 1e-10
    basket_constraint_tolerance: float = 1e-6
    basket_identity_tolerance: float = 1e-10
    basket_condition_number_warning: float = 1e10
    basket_fallback_mode: str = "soft_penalty"  # or "skip"

    # Comparison
    comparison_rolling_months: int = 36
    save_lookthrough_stock_weights: bool = False
    missing_return_policy: str = "coverage_threshold"
```

## 9. 受入基準

### 9.1 後方互換

- 同一入力・同一Configで `purified_theme_returns` が変更前と数値一致する。
- `stock_coefficient_replicated_theme_returns` と `purified_theme_returns` の相関が各テーマでほぼ1となる。
- 月次TEが設定した数値許容誤差以下となる。
- 既存CSV名を削除または意味変更しない。

### 9.2 バスケット計算の数値整合性

各有効時点・テーマについて以下を満たす。

- `H.T @ (P.T @ r)` と `(P @ H).T @ r` の最大絶対差が `basket_identity_tolerance` 以下
- hard制約使用時、`max(abs(A.T @ P @ h))` が `basket_constraint_tolerance` 以下
- hard制約使用時、`abs(z_k.T @ P @ h - 1)` が `basket_constraint_tolerance` 以下
- NaN、inf、無限大ウェイトを出力しない
- rank不足、制約不可能、条件数超過を `solver_status` に記録する
- 例外を無言で握りつぶさない

### 9.3 時系列整合性

- exposure dateのウェイトで次のreturn dateを評価する。
- future basket constituents、future Barra exposure、future returnsを利用しない。
- 共通サンプル比較と方式別coverageを同時に出力する。
- テーマ誕生・消滅時はゼロではなくNaNまたは明示的statusとする。

### 9.4 経済的評価

バスケット方式の相関やTEに一律の合否閾値は設けない。達成可能な精度はテーマバスケット空間のランクと重複度に依存するためである。合否は計算恒等式、制約、時点整合性、診断完全性で判定し、複製精度は分析結果として報告する。

ただし、テスト用合成データでは以下を用意する。

1. `P` が `M_stock` を完全に張るケース: basket replicaがtargetを数値誤差内で再現する。
2. `P` がrank deficientなケース: 正しくinfeasibleまたはsoft fallbackとなる。
3. バスケットが強く重複するケース: 条件数警告が出る。
4. 切片なしケース: 明示的ドルニュートラル制約が入る。
5. missing returnケース: 指定した欠損ポリシーが3系列に一貫して適用される。

## 10. ノートブック改修箇所

### Cell 2: Config

- バスケット入力、最適化、数値許容差、比較、保存に関する設定を追加する。
- 主比較用の診断モードと投資可能モードを分ける。

### Cell 3: 関数群

追加・変更:

- `ExposureSnapshot` または中立化行列返却
- `prepare_theme_basket_weights`
- `basket_basis_diagnostics`
- `construct_basket_mimicking_portfolios`
- `basket_replicated_theme_returns`
- `compare_replication_methods`
- `plot_three_way_replication`
- `save_replication_outputs`

既存 `specific_risk_diag` は定義を明確化し、可能なら実際のspecific variance入力を受け付ける。

### Step 1

- 純化テーマファクターリターン推定は変更しない。
- 追加で有効テーマ・有効銘柄・中立化行列の診断を保存する。

### Step 2

以下の順序に再構成する。

1. `2A`: 個別銘柄 coefficient replica
2. `2B`: 個別銘柄 min-risk proxy（補足）
3. `2C`: テーマバスケット L/S replica
4. `2D`: 3系列比較
5. `2E`: ランク、エクスポージャー、ウェイト、ターンオーバー診断

### Step 3

- 既存出力を維持する。
- バスケット複製、3系列比較、バスケットウェイト、ランク診断を追加保存する。

## 11. 実装フロー擬似コード

```python
for return_date in theme_returns.index:
    exposure_date = previous_month(return_date)

    snap = snapshot_for_date(...)
    A = snap.neutralization_exposures
    Z = snap.purified_theme_exposures

    M_stock, stock_diag = construct_stock_mimicking_portfolios(
        ..., date=exposure_date, mode="coefficient"
    )

    P, basket_input_diag = prepare_theme_basket_weights(
        ..., date=exposure_date,
        stock_index=M_stock.index,
        theme_columns=M_stock.columns,
    )

    H, M_basket, basket_diag = construct_basket_mimicking_portfolios(
        ..., date=exposure_date,
        stock_target_mode="coefficient",
        basket_mode="constrained_risk_projection",
    )

    r = validated_stock_returns(return_date, M_stock.index)

    g_stock = M_stock.T @ r
    raw_basket_returns = P.T @ r
    g_basket_1 = H.T @ raw_basket_returns
    g_basket_2 = M_basket.T @ r

    assert max_abs(g_basket_1 - g_basket_2) <= tolerance

    store_returns_and_diagnostics(...)

comparison = compare_replication_methods(
    purified=theme_returns,
    stock_rep=stock_rep_returns,
    basket_rep=basket_rep_returns,
    diagnostics=basket_diagnostics,
    cfg=cfg,
)
```

## 12. 推奨デフォルト決定

| 論点 | 推奨デフォルト |
|---|---|
| 複製対象 | stock coefficient-replicating portfolio |
| バスケット入力 | `theme_basket_weights_by_date` を新設 |
| バスケット方式 | constrained risk projection |
| 中立化 | 切片＋Barraをhard制約 |
| 対象テーマ尺度 | target purified-theme exposure = 1をhard制約 |
| オフテーマ | hard制約にせず最小化・診断 |
| リスク | 対角specific varianceまたは対角分散proxy |
| グロス制約 | 主比較では設定しない |
| 対象元バスケットのロング制約 | 主比較では設定しない。投資可能モードのみ任意 |
| 取引コスト | 主比較から除外し、補足で別計算 |
| 欠損リターン | coverage threshold + flag |
| rank不足 | soft fallbackまたはskipを明示し、status保存 |
| 比較系列 | purified / stock coefficient / basket L/S の3系列 |

## 13. 将来拡張

バスケットだけでは表現力が不足する場合、テーマバスケットに市場・業種・Barra factor-mimicking hedgeを追加した

\[
\tilde P_t=[P_t, H^{\mathrm{hedge}}_t]
\]

を用いる `basket_plus_hedge` モードを追加できる。この場合、純粋な「テーマバスケットのみ」の結果とは別系列にし、主比較を上書きしない。
