# Project Rules: trend-stories

このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。
このプロジェクトの Prefer explicit python path は 
- envs/nlp/.venv/bin/python

---
## Source of truth
- *.ipynb            : single source of execution & inspection
  
---

## 0. 目的
本プロジェクトは以下の参考情報に基づきレビュー・再現実装する。
- https://towardsdatascience.com/extract-trending-stories-in-news-29f0e7d3316a/
- https://github.com/steveyx/trending-stories
  
---

## 1. 進め方
### Phase A: レビューのみ（実装禁止）
- 再現実装に必要な情報を日本語で1本のMarkdownに整理した review.md を作成

### Phase B: 再現実装
- １つのipynbファイルで完結させること

---

## 2. 注意
- 参考としたGitHubリポジトリの実装を可能な限り使って実装すること