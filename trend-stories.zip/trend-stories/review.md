# trend-stories 再現レビュー（Phase A）

## 1. 背景と目的

本レビューは、以下の 2 つの参照情報を基に、`trend-stories` の再現実装（Phase B）に必要な仕様を日本語で整理する。

- 参考記事: https://towardsdatascience.com/extract-trending-stories-in-news-29f0e7d3316a/
- 参考実装: https://github.com/steveyx/trending-stories

本プロジェクトのルールに従い、Phase A では**実装を行わず**、再現に必要な設計情報のみを文書化する。

---

## 2. 再現対象の全体パイプライン

参照実装の処理フローは次の 5 段階で構成される。

1. `clean`
- タイトル/本文からノイズ語や非ASCII文字を除去し、キーワード抽出しやすい形に整形する。

2. `keyword extraction`
- spaCy ベースで固有表現と名詞句を抽出し、タイトル側に重みを付けて記事キーワードを作る。

3. `post-process`
- 同義語・表記揺れ（例: `United States` と `US`）をリンクテーブルで統合する。

4. `clustering`
- 重み付きキーワードから文書間コサイン距離を作成し、DBSCAN（必要時は再帰で `eps` を縮小）でクラスタリングする。

5. `visualization`
- 14日窓ごとにクラスタサイズ上位ストーリーを抽出し、バブル可視化する。

---

## 3. モジュール別仕様（参照実装ベース）

### 3.1 `news_cleaner.py`

役割:
- タイトル/本文の前処理。

主要処理:
- 非ASCII除去、ラテン文字正規化、`U.S.` -> `US` 置換。
- タイトル定型句除去（`BREAKING:`、`Exclusive:`、`: WSJ` など）。
- 本文の短文除去（30文字以下、単語数3以下の行を除去）。

入出力:
- 入力: `title: str`, `content: str`
- 出力: `cleaned_title: str`, `cleaned_content: str`

### 3.2 `keywords_extraction.py`

役割:
- 記事テキストからキーワードを抽出して重み付け。

主要パラメータ:
- `title_entity_weight=4`
- `title_noun_chunk_weight=2`
- スコア閾値 `score_threshold=0.05`

主要処理:
- `en_core_web_lg` で NER + noun chunk 抽出。
- 許可エンティティ型（`PERSON`, `GPE`, `ORG`, `EVENT` など）のみ採用。
- 不要語/不要エンティティ除去。
- 類似語統合（コサイン類似度閾値 `th=0.4`）。

出力形式:
- `kwords: list[dict]`
- 各要素は `{"keyword": <str>, "weight": <int>}`

### 3.3 `keywords_post_process.py`

役割:
- 記事ごとの `kwords` をリンクテーブルで正規化し、統合後JSONを保存。

主要処理:
- 例: `United States -> US`, `Federal Reserve -> Fed`, `Wall Street Journal -> WSJ`
- 出力ファイル名は入力JSON名に `_post_processed` を付与。

### 3.4 `news_clustering.py`

役割:
- キーワード空間でニュースをクラスタリングし、クラスタメタ情報を付与。

主要パラメータ:
- `cluster_news_by_weighted_keywords(..., eps=0.35, max_size=500)`
- 再帰分割時: `eps` を `0.05` 刻みで減らす。

主要処理:
- 重み付きキーワード文字列を作成。
- コサイン類似度 -> 距離行列（`1 - similarity`）を計算。
- DBSCAN（`metric="precomputed"`, `min_samples=1`）でクラスタリング。
- 各クラスタの代表記事 (`core_news`) とクラスタキーワード集約を算出。

### 3.5 `stories_visualizer.py`

役割:
- 時系列（14日窓）でトレンドストーリーを可視化。

主要パラメータ:
- `period_days = 14`
- 描画対象: 各期間の上位 `top_stories = 3`

主要処理:
- 各期間内ニュースを `cluster_id` で集約。
- `cluster_size` 降順で上位クラスタを選択。
- キーワード文字列とサイズでバブル図を生成し、`data/trending_stories.png` に保存。

### 3.6 `main.py`

役割:
- 処理全体の実行エントリ。

既定フロー:
1. `KeywordsPostProcessor.post_process_article_keywords()`
2. `reuters_cleaned_with_keywords_post_processed.json` を読み込み
3. 期間フィルタ（`pubDate > 2019-11-15`）
4. `eps=0.35`, `max_size=500` でクラスタリング
5. 未クラスタ記事除外後に可視化

補足:
- キーワード抽出部分（CSV -> JSON）はコメントアウトされており、再実行時に有効化する想定。

---

## 4. データ仕様

### 4.1 入力CSV（参照リポジトリ `data/`）

- `reuters_headlines.csv`
  - 列: `Headlines`, `Time`, `Description`
  - レコード数: `32770`

- `guardian_headlines.csv`
  - 列: `Time`, `Headlines`
  - レコード数: `17800`

- `cnbc_headlines.csv`
  - 列: `Headlines`, `Time`, `Description`
  - レコード数: `3080`

注意:
- 参照コードの `load_news_csv` は実質 Reuters 形式向け（`reuters` 文字列判定で列名再マップ）で実装されている。

### 4.2 中間成果物JSON

参照実装に含まれる中間データ:
- `data/reuters_cleaned_with_keywords.json`（約 41MB, 32770件）

スキーマ（1記事）:
```json
{
  "title": "...",
  "pubDate": "YYYY-MM-DDTHH:MM:SS",
  "content": "...",
  "_id": "reuters_<index>",
  "provider": "reuters",
  "cleanedTitle": "...",
  "cleanedContent": "...",
  "kwords": [
    {"keyword": "...", "weight": 4}
  ]
}
```

補足:
- `reuters_cleaned_with_keywords_post_processed.json` はリポジトリ初期状態では未同梱で、`post_process_article_keywords()` 実行時に生成される。

---

## 5. 現行環境との差分と最小移植方針

前提環境（本ワークスペース）:
- Python: `envs/nlp/.venv/bin/python` -> `3.14.2`
- 既存依存（主要）: `numpy`, `pandas`, `matplotlib`, `ipykernel`
- 未導入: `spacy`, `scikit-learn`, `seaborn`

参照実装の `requirements.txt`:
- `pandas==1.1.5`
- `spacy==2.3.5`
- `scikit-learn==0.21.3`
- `matplotlib==3.3.4`
- `numpy==1.18.5`
- `seaborn==0.11.1`

### 5.1 差分ポイント

1. spaCy 2 系前提コード
- `Lemmatizer` / `Lookups` 利用や `lemma_exc` テーブル編集など、spaCy 2 系の書き方が含まれる。
- 現行 spaCy では API 互換差分があるため、同等処理を保つ最小修正が必要。

2. pandas 互換差分
- 参照コードの `DataFrame.append` は現行 pandas では非推奨/削除系のため、`pd.concat` 置換が必要。

3. Python 3.14 の警告
- 参照の正規表現文字列に無効エスケープ（`\-` など）警告が出るため、raw文字列化またはエスケープ修正が必要。

4. 未導入依存
- `sklearn` 未導入のため現状 `main.py` は `ModuleNotFoundError` で停止。

### 5.2 最小移植の原則

- ロジック順序・主要関数名・パラメータ（例: `title_entity_weight=4`, `eps=0.35`, `period_days=14`）は維持。
- 変更は「実行不能箇所の互換修正」に限定。
- 意味的挙動を変えるリファクタ（アルゴリズム変更、大幅抽象化）は行わない。

### 5.3 依存導入方針（workspaceルール準拠）

- `pip install` は使用しない。
- `envs/nlp` で `uv add` を使用して追加する。
- 例（Phase B で実施）:
  - `cd /Users/kencharoff/workspace/envs/nlp`
  - `uv add spacy scikit-learn seaborn`
  - spaCy モデルは `envs/nlp/.venv/bin/python -m spacy download en_core_web_lg` で取得可否確認

---

## 6. Phase B 実装設計（1本 ipynb 完結）

`*.ipynb` を唯一の実行・検証ソースとし、1ノートブックで以下セル順に実装する。

### セル構成案

1. `00_setup`
- 目的: ライブラリ import、乱数seed、表示設定、パス設定。
- 出力: 実行環境情報（Python/主要パッケージバージョン）。

2. `01_config`
- 目的: 再現パラメータを一元定義。
- 必須パラメータ: `title_entity_weight=4`, `title_noun_chunk_weight=2`, `eps=0.35`, `max_size=500`, `period_days=14`。

3. `02_data_loading`
- 目的: Reuters CSV の読み込みと参照実装互換の列整形。
- 出力: 記事dictリスト（`title`, `pubDate`, `content`, `_id`, `provider`）。

4. `03_cleaning_and_keyword_extraction`
- 目的: `NewsCleaner` と `KeywordsExtract` 相当ロジックを移植し、`kwords` 生成。
- 出力: `cleanedTitle`, `cleanedContent`, `kwords` を持つ記事リスト。

5. `04_keyword_post_process`
- 目的: リンクテーブルで表記揺れ統合。
- 出力: post-process 後 `kwords`。

6. `05_clustering`
- 目的: コサイン距離 + DBSCAN + 再帰分割でクラスタ生成。
- 出力: 各記事に `cluster_id` と `core_news` を付与。

7. `06_visualization`
- 目的: 14日窓で上位クラスタを可視化。
- 出力: `trending_stories.png` 相当の図表示/保存。

8. `07_validation`
- 目的: 再現確認（件数、欠損、未クラスタ件数、上位クラスタ）を表示。
- 出力: 受け入れ判定に使うチェック結果。

### 実装上の明示ルール

- 参照GitHubの処理を可能な限り保持し、互換修正のみ差し込む。
- 補助関数は notebook 内セルで完結（外部 `.py` 新規作成はしない）。
- 実行成果の確認も notebook 上で完結させる。

---

## 7. 受け入れ条件（Phase A 完了判定）

1. `review.md` が日本語で作成され、参照URL 2件を明記している。
2. パイプラインと主要パラメータ（例: keyword重み、`eps=0.35`、`period_days=14`）を記載している。
3. 入力CSV仕様と中間JSONスキーマを再現可能な粒度で記載している。
4. Phase B を1本 ipynb で実装開始できるセル設計を記載している。
5. 依存導入方針が `uv` 前提であり、`pip install` 非使用を明記している。

---

## 8. 前提・仮定

- 実施範囲は Phase A（レビュー文書作成）のみ。
- 互換戦略は「最小移植で再現」。
- 記事本文の取得に制約があるため、再現仕様の主ソースは GitHub 実装とし、TDS記事URLは参考として併記する。
