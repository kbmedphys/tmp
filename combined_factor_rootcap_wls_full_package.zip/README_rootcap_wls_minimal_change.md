# 00 / 01 / 02 root-cap WLS 最小変更版

## 対象ノートブック

| ファイル | 内容 |
|---|---|
| `00_combined_factor_mimicking_diagnostics.ipynb` | root-cap制約付きWLS、テーマ純化、共同ファクターリターン、mimicking portfolioの診断 |
| `01_binary_combined_factor_tsfm_12m.ipynb` | 既存因子 + 純化テーマ因子の12カ月Binary TSFM |
| `02_vol_scaled_combined_factor_tsfm_12m.ipynb` | 同じ統合因子の12カ月Vol-scaled TSFM |

各ノートブックは合成データで実行済みです。全コードセルに出力があり、エラー出力はありません。

## 既存プログラムからの最小変更

戦略シグナル、形成期間、比較ユニバース、ファクター配分、個別銘柄への展開、ターンオーバー・コスト計算は維持しています。変更は回帰層に限定しています。

1. 等ウェイトOLSをroot-cap WLSへ変更。

   \[
   w_{i,t}=\sqrt{\mathrm{FFMCap}_{i,t-1}}
   \]

   数値安定性のため、ウェイトは断面平均1へ正規化しています。この正規化は回帰係数を変えません。

2. 同じウェイト行列 `W_t` を次の全段階で使用。

   - Barra/controlファクターリターン推定
   - 生テーマエクスポージャーの純化
   - 既存因子 + 純化テーマ因子の共同ファクターリターン推定
   - WLS係数を個別銘柄で複製するmimicking portfolio

3. 切片と国・通貨・業種など完全ダミー集合を併用できるよう、時価総額加重ゼロ和制約をKKT方式で実装。

4. 等ウェイトOLSは削除せず、最新断面の感応度比較だけに残した。

5. HuberロバストWLSはオプションとして実装したが、推奨ベースではOFF。全段階で厳密に同じ `W_t` を使うため。

## 推定式

制約付きroot-cap WLS:

\[
\hat f_t
=\arg\min_f
(r_t-X_{t-1}f)'W_t(r_t-X_{t-1}f)
\quad \mathrm{s.t.}\quad C f=0
\]

テーマ純化:

\[
Z_t=A_t-X_t\hat\Theta_t,
\qquad
\hat\Theta_t
=\arg\min_\Theta
(A_t-X_t\Theta)'W_t(A_t-X_t\Theta)
\]

共同ファクターモデル:

\[
r_{t+1}=C_t b_{t+1}+[E_t,Z_t]g_{t+1}+u_{t+1}
\]

WLS係数を複製する個別銘柄ポートフォリオ:

\[
g_{t+1}=M_t'r_{t+1}
\]

最終戦略ウェイト:

\[
w_t^{stock}=M_t w_t^F
\]

## 実データ入力

各ノートブックの `use_synthetic_data=False` に変更し、ノートブック実行ディレクトリの `data/combined_factor_inputs.pkl` に次を保存します。

```python
{
    "stock_returns": DataFrame,
    "free_float_market_cap": DataFrame,  # 推奨
    # または "market_cap": DataFrame,
    "barra_exposures": dict | DataFrame,
    "barra_factor_metadata": DataFrame,
    "existing_factor_exposures": dict | DataFrame,
    "theme_basket_weights": DataFrame,
    "factor_metadata": DataFrame,
    "cash_returns": Series,              # 任意
}
```

### `barra_factor_metadata`

最低限、次の列を想定します。

| 列 | 説明 |
|---|---|
| `factor_id` | `barra_exposures` の列名 |
| `factor_kind` | `style` または `category` |
| `constraint_group` | 国なら `COUNTRY`、通貨なら `CURRENCY`、業種なら `INDUSTRY`。連続スタイル因子は欠損可 |

同じ `constraint_group` のカテゴリー因子には、グループ時価総額に基づくゼロ和制約が課されます。

## 重要な運用上の挙動

- `free_float_market_cap` を優先し、なければ `market_cap` を使います。
- root-cap WLSを指定した状態で両方がなければエラーにします。等ウェイトへの黙示的フォールバックは行いません。
- 時価総額はエクスポージャー日 `t` の値を使い、次期 `t+1` のリターンを説明します。
- 制約付きWLSでは `X'Wu` 全列がゼロとは限りません。ノートブックでは、KKTの `projected_stationarity` と `constraint_violation` を検証します。
- 合成データのパフォーマンスは動作確認専用です。

## 自動検証結果

`rootcap_wls_validation_summary.csv` に検証結果を保存しています。主な最大誤差は次の通りです。

- WLS係数とmimicking portfolioリターンの恒等誤差: 約 `7e-17`
- 同一Wを使ったFWL二段階推定誤差: 約 `3e-11`
- KKT projected stationarity: 約 `8e-15`
- カテゴリー制約違反: 約 `1e-15`
- テーマ純化後の `X'WZ`: 約 `5e-11`
- 既存因子P&L + テーマ因子P&Lと総P&Lの差: 約 `1e-16`
