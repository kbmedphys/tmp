from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence
import math
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Markdown

pd.set_option('display.max_columns', 160)
pd.set_option('display.width', 260)
pd.set_option('display.float_format', lambda x: f'{x:,.6f}')


@dataclass
class CombinedFactorWLSConfig:
    """Combined existing + purified-theme factor model with root-cap WLS."""

    use_synthetic_data: bool = True
    seed: int = 42
    start_month: str = '2018-01-31'
    end_month: str = '2024-12-31'
    n_stocks: int = 80
    n_themes: int = 5
    n_theme_members: int = 22
    data_dir: Path = Path('./data')
    output_dir: Path = Path('./outputs/combined_factor_rootcap_wls')

    # Recommended base specification.
    regression_weight_mode: str = 'root_cap'  # root_cap / equal
    market_cap_preference: tuple[str, ...] = ('free_float_market_cap', 'market_cap')
    require_market_cap_for_wls: bool = True
    allow_equal_weight_fallback: bool = False
    normalize_regression_weights_to_mean_one: bool = True
    weight_winsor_lower_quantile: Optional[float] = None
    weight_winsor_upper_quantile: Optional[float] = None

    # Optional robustness. Off by default so the exact same W is used in
    # Barra WLS, theme purification, theme return estimation, and mimicking.
    robust_wls: bool = False
    huber_c: float = 1.345
    huber_iterations: int = 2

    include_intercept: bool = True
    theme_purification_ridge: float = 1e-10
    factor_return_ridge: float = 1e-10
    mimicking_ridge: float = 1e-10
    pinv_rcond: float = 1e-12

    exclude_momentum_related_from_signal: bool = True
    include_excluded_momentum_as_control: bool = True

    formation_months: int = 12
    skip_recent_months: int = 0
    min_history_months: int = 12
    volatility_lookback_months: int = 36
    factor_gross_target: float = 1.0
    transaction_cost_bps_one_way: float = 5.0
    weighting_mode: str = 'factor_equal'  # factor_equal / block_equal

    def __post_init__(self):
        self.data_dir = Path(self.data_dir)
        self.output_dir = Path(self.output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)


def display_step(title: str, obj: Any = None, n: int = 6) -> None:
    display(Markdown(f'### {title}'))
    if obj is None:
        return
    if isinstance(obj, (pd.DataFrame, pd.Series)):
        display(obj.head(n))
        if len(obj) > n:
            display(Markdown('末尾:'))
            display(obj.tail(n))
    else:
        display(obj)


def normalize_security_id(x: Any) -> str:
    if pd.isna(x):
        return x
    s = str(x).strip()
    if s.endswith('.T'):
        return s
    if s.endswith('.0'):
        s = s[:-2]
    if s.isdigit():
        return f'{int(s):04d}.T'
    return s


def month_ends(start: str, end: str) -> pd.DatetimeIndex:
    try:
        return pd.date_range(start=start, end=end, freq='ME')
    except ValueError:
        return pd.date_range(start=start, end=end, freq='M')


def to_month_end_index(index: Sequence[Any]) -> pd.DatetimeIndex:
    return pd.DatetimeIndex(pd.to_datetime(index)).tz_localize(None).to_period('M').to_timestamp('M')


def to_monthly_returns(ret: pd.DataFrame) -> pd.DataFrame:
    out = ret.copy()
    out.index = pd.DatetimeIndex(pd.to_datetime(out.index)).tz_localize(None)
    try:
        out = (1.0 + out).resample('ME').prod(min_count=1) - 1.0
    except ValueError:
        out = (1.0 + out).resample('M').prod(min_count=1) - 1.0
    out.index = to_month_end_index(out.index)
    out.columns = [normalize_security_id(c) for c in out.columns]
    return out.sort_index()


def standardize_columns(df: pd.DataFrame, center: bool = True, l2: bool = True) -> pd.DataFrame:
    x = df.astype(float).copy()
    if center:
        x = x.sub(x.mean(axis=0), axis=1)
    sd = x.std(axis=0, ddof=0).replace(0.0, np.nan)
    x = x.div(sd, axis=1).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    if l2:
        norm = np.sqrt((x ** 2).sum(axis=0)).replace(0.0, np.nan)
        x = x.div(norm, axis=1).fillna(0.0)
    return x


def l2_normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    x = df.astype(float).copy()
    norm = np.sqrt((x ** 2).sum(axis=0)).replace(0.0, np.nan)
    return x.div(norm, axis=1).fillna(0.0)


def asof_key(mapping: Mapping[pd.Timestamp, Any], asof: pd.Timestamp) -> pd.Timestamp:
    keys = pd.DatetimeIndex(sorted(pd.Timestamp(k).to_period('M').to_timestamp('M') for k in mapping.keys()))
    target = pd.Timestamp(asof).to_period('M').to_timestamp('M')
    pos = keys.searchsorted(target, side='right') - 1
    if pos < 0:
        raise KeyError(f'No point-in-time snapshot at or before {target.date()}')
    return pd.Timestamp(keys[pos])


def _normalize_snapshot_dict(obj: Mapping[Any, Any], securities: Sequence[str], standardize: bool = False) -> dict[pd.Timestamp, pd.DataFrame]:
    out: dict[pd.Timestamp, pd.DataFrame] = {}
    for d, value in obj.items():
        x = value.copy()
        if isinstance(x, pd.Series):
            x = x.to_frame(x.name or 'value')
        x.index = [normalize_security_id(i) for i in x.index]
        x = x.reindex([normalize_security_id(s) for s in securities])
        x.columns = [str(c) for c in x.columns]
        if standardize:
            x = standardize_columns(x.dropna(how='all'), center=True, l2=True)
        out[pd.Timestamp(d).to_period('M').to_timestamp('M')] = x.astype(float)
    return out


def _long_to_snapshot_dict(df: pd.DataFrame, date_col: str, security_col: str, value_col: Optional[str] = None, factor_col: Optional[str] = None) -> dict[pd.Timestamp, pd.DataFrame]:
    x = df.copy()
    x[date_col] = pd.to_datetime(x[date_col]).dt.to_period('M').dt.to_timestamp('M')
    x[security_col] = x[security_col].map(normalize_security_id)
    out: dict[pd.Timestamp, pd.DataFrame] = {}
    if factor_col and value_col:
        for d, g in x.groupby(date_col):
            out[pd.Timestamp(d)] = g.pivot_table(index=security_col, columns=factor_col, values=value_col, aggfunc='mean')
    else:
        cols = [c for c in x.columns if c not in [date_col, security_col]]
        for d, g in x.groupby(date_col):
            out[pd.Timestamp(d)] = g.set_index(security_col)[cols]
    return out


def _market_cap_to_frame(obj: Any, stock_index: pd.DatetimeIndex, securities: Sequence[str]) -> pd.DataFrame:
    if isinstance(obj, pd.DataFrame):
        x = obj.copy()
        if {'date', 'security_id'}.issubset(x.columns):
            value_candidates = [c for c in x.columns if c not in ['date', 'security_id']]
            if len(value_candidates) != 1:
                raise ValueError('Long market cap table must have exactly one value column in addition to date/security_id')
            x['date'] = pd.to_datetime(x['date']).dt.to_period('M').dt.to_timestamp('M')
            x['security_id'] = x['security_id'].map(normalize_security_id)
            x = x.pivot_table(index='date', columns='security_id', values=value_candidates[0], aggfunc='last')
        else:
            if not isinstance(x.index, pd.DatetimeIndex):
                date_col = 'date' if 'date' in x.columns else x.columns[0]
                x[date_col] = pd.to_datetime(x[date_col])
                x = x.set_index(date_col)
            x.index = to_month_end_index(x.index)
            x.columns = [normalize_security_id(c) for c in x.columns]
    elif isinstance(obj, Mapping):
        rows = []
        for d, s in obj.items():
            if isinstance(s, pd.DataFrame):
                if s.shape[1] != 1:
                    raise ValueError('Market cap snapshot DataFrame must have one column')
                s = s.iloc[:, 0]
            if not isinstance(s, pd.Series):
                raise TypeError('Market cap mapping values must be Series or one-column DataFrame')
            row = pd.Series(s.to_dict(), name=pd.Timestamp(d).to_period('M').to_timestamp('M'))
            rows.append(row)
        x = pd.DataFrame(rows)
        x.columns = [normalize_security_id(c) for c in x.columns]
    else:
        raise TypeError('market cap input must be DataFrame or mapping')
    return x.sort_index().reindex(index=stock_index, columns=[normalize_security_id(s) for s in securities]).ffill()


def resolve_market_cap_input(data: Mapping[str, Any], cfg: CombinedFactorWLSConfig) -> pd.DataFrame:
    for key in cfg.market_cap_preference:
        if key in data and data[key] is not None:
            return _market_cap_to_frame(data[key], data['stock_returns'].index, data['stock_returns'].columns)
    if cfg.require_market_cap_for_wls and cfg.regression_weight_mode == 'root_cap' and not cfg.allow_equal_weight_fallback:
        raise KeyError(f'Root-cap WLS requires one of {cfg.market_cap_preference}')
    return pd.DataFrame(1.0, index=data['stock_returns'].index, columns=data['stock_returns'].columns)


def make_synthetic_data(cfg: CombinedFactorWLSConfig) -> dict[str, Any]:
    rng = np.random.default_rng(cfg.seed)
    dates = month_ends(cfg.start_month, cfg.end_month)
    securities = [f'{i:04d}.T' for i in range(1, cfg.n_stocks + 1)]

    # Free-float market caps: persistent lognormal cross section.
    log_cap0 = rng.normal(10.5, 1.35, size=cfg.n_stocks)
    cap = np.empty((len(dates), cfg.n_stocks))
    cap[0] = np.exp(log_cap0)
    for t in range(1, len(dates)):
        cap[t] = cap[t - 1] * np.exp(rng.normal(0.002, 0.06, size=cfg.n_stocks))
    free_float_market_cap = pd.DataFrame(cap, index=dates, columns=securities)

    # Barra: continuous styles + complete country dummies. Intercept plus all countries is rank deficient;
    # the country-zero-sum constraint identifies the country returns.
    countries = np.array(['JP', 'US', 'EU'])[rng.integers(0, 3, size=cfg.n_stocks)]
    base_style = pd.DataFrame({
        'BETA': 1.0 + rng.normal(0, 0.20, size=cfg.n_stocks),
        'SIZE': (log_cap0 - log_cap0.mean()) / log_cap0.std(),
        'VALUE': rng.normal(size=cfg.n_stocks),
        'QUALITY': rng.normal(size=cfg.n_stocks),
    }, index=securities)
    country_dummies = pd.get_dummies(pd.Series(countries, index=securities), prefix='COUNTRY', dtype=float)
    barra_by_date: dict[pd.Timestamp, pd.DataFrame] = {}
    for d in dates:
        B = pd.concat([base_style + rng.normal(0, 0.03, size=base_style.shape), country_dummies], axis=1)
        # Keep category dummies as 0/1; standardize only styles.
        B.loc[:, base_style.columns] = standardize_columns(B[base_style.columns], center=True, l2=True)
        barra_by_date[pd.Timestamp(d)] = B

    barra_factor_metadata = pd.DataFrame([
        {'factor_id': 'BETA', 'factor_kind': 'style', 'constraint_group': None},
        {'factor_id': 'SIZE', 'factor_kind': 'style', 'constraint_group': None},
        {'factor_id': 'VALUE', 'factor_kind': 'style', 'constraint_group': None},
        {'factor_id': 'QUALITY', 'factor_kind': 'style', 'constraint_group': None},
        {'factor_id': 'COUNTRY_EU', 'factor_kind': 'category', 'constraint_group': 'COUNTRY'},
        {'factor_id': 'COUNTRY_JP', 'factor_kind': 'category', 'constraint_group': 'COUNTRY'},
        {'factor_id': 'COUNTRY_US', 'factor_kind': 'category', 'constraint_group': 'COUNTRY'},
    ])

    # Existing investable factors not identical to Barra controls.
    existing_names = ['LOWVOL', 'PROFIT', 'MOM12']
    E0 = pd.DataFrame({
        'LOWVOL': -base_style['BETA'] + rng.normal(0, 0.6, cfg.n_stocks),
        'PROFIT': 0.6 * base_style['QUALITY'] + rng.normal(0, 0.8, cfg.n_stocks),
        'MOM12': rng.normal(size=cfg.n_stocks),
    }, index=securities)
    existing_by_date = {}
    for d in dates:
        existing_by_date[pd.Timestamp(d)] = standardize_columns(E0 + rng.normal(0, 0.05, size=E0.shape), center=True, l2=True)
    factor_metadata = pd.DataFrame([
        {'factor_id': 'LOWVOL', 'factor_type': 'existing', 'role': 'investable_signal', 'is_momentum_related': False},
        {'factor_id': 'PROFIT', 'factor_type': 'existing', 'role': 'investable_signal', 'is_momentum_related': False},
        {'factor_id': 'MOM12', 'factor_type': 'existing', 'role': 'investable_signal', 'is_momentum_related': True},
    ])

    # Theme basket snapshots.
    themes = [f'THEME_{i:02d}' for i in range(1, cfg.n_themes + 1)]
    rows = []
    members = {th: rng.choice(securities, size=cfg.n_theme_members, replace=False) for th in themes}
    for ti, d in enumerate(dates):
        for th in themes:
            current = members[th]
            if ti and ti % 9 == 0:
                replace_n = max(1, cfg.n_theme_members // 6)
                keep = current[:-replace_n]
                pool = [s for s in securities if s not in keep]
                current = np.concatenate([keep, rng.choice(pool, size=replace_n, replace=False)])
                members[th] = current
            raw = rng.lognormal(0.0, 0.55, size=len(current))
            weights = raw / raw.sum()
            for sec, wt in zip(current, weights):
                rows.append({'knowledge_date': d, 'effective_date': d, 'theme_id': th, 'security_id': sec, 'weight': float(wt)})
    theme_basket_weights = pd.DataFrame(rows)

    # Generate returns with persistent target factors and heteroskedastic specific risk.
    stock_returns = pd.DataFrame(np.nan, index=dates, columns=securities)
    stock_returns.iloc[0] = rng.normal(0.004, 0.05, cfg.n_stocks)
    prev_target = np.zeros(2 + cfg.n_themes)  # LOWVOL, PROFIT + themes
    prev_barra = np.zeros(7)
    for i in range(len(dates) - 1):
        d = pd.Timestamp(dates[i])
        d_next = pd.Timestamp(dates[i + 1])
        B = barra_by_date[d]
        E = existing_by_date[d][['LOWVOL', 'PROFIT']]
        A = raw_theme_matrix_for_date(theme_basket_weights, d, securities)
        w = root_cap_weights(free_float_market_cap.loc[d], cfg)
        C = pd.concat([pd.Series(1.0, index=securities, name='INTERCEPT'), B], axis=1)
        constraints = build_category_constraints(B, barra_factor_metadata, free_float_market_cap.loc[d], include_intercept=True)
        Z, _, _ = weighted_residualize(A, pd.concat([C, E], axis=1), w, cfg, constraints=_extend_constraints(constraints, list(C.columns), list(E.columns)))
        Z = l2_normalize_columns(Z)
        barra_ret = 0.08 * prev_barra + rng.normal(0, 0.018, len(prev_barra))
        target_ret = 0.22 * prev_target + rng.normal(0.0015, 0.026, len(prev_target))
        prev_barra = barra_ret
        prev_target = target_ret
        # Specific standard deviation decreases with market cap, consistent with root-cap WLS motivation.
        cap_rel = free_float_market_cap.loc[d] / free_float_market_cap.loc[d].median()
        specific_sd = 0.055 / np.power(cap_rel.clip(lower=0.05), 0.25)
        r = C.to_numpy() @ np.r_[0.003, barra_ret] + E.to_numpy() @ target_ret[:2] + Z.to_numpy() @ target_ret[2:] + rng.normal(0, specific_sd.to_numpy())
        stock_returns.loc[d_next] = np.clip(r, -0.80, 1.00)

    return {
        'stock_returns': stock_returns.astype(float),
        'free_float_market_cap': free_float_market_cap.astype(float),
        'barra_exposures': barra_by_date,
        'barra_factor_metadata': barra_factor_metadata,
        'existing_factor_exposures': existing_by_date,
        'theme_basket_weights': theme_basket_weights,
        'factor_metadata': factor_metadata,
        'cash_returns': pd.Series(0.0, index=dates, name='cash_return'),
        'meta': {
            'mode': 'synthetic', 'n_months': len(dates), 'n_stocks': cfg.n_stocks,
            'n_barra_columns': len(barra_factor_metadata), 'n_existing': len(existing_names),
            'n_themes': cfg.n_themes,
        },
    }


def load_real_data(cfg: CombinedFactorWLSConfig) -> dict[str, Any]:
    path = cfg.data_dir / 'combined_factor_inputs.pkl'
    if not path.exists():
        raise FileNotFoundError(path)
    raw = pd.read_pickle(path)
    required = ['stock_returns', 'barra_exposures', 'existing_factor_exposures', 'theme_basket_weights']
    missing = [k for k in required if k not in raw]
    if missing:
        raise KeyError(f'Missing keys in combined_factor_inputs.pkl: {missing}')
    stock_returns = to_monthly_returns(raw['stock_returns'])
    securities = list(stock_returns.columns)

    barra_raw = raw['barra_exposures']
    if isinstance(barra_raw, Mapping):
        barra = _normalize_snapshot_dict(barra_raw, securities, standardize=False)
    else:
        barra = _normalize_snapshot_dict(_long_to_snapshot_dict(barra_raw, 'date', 'security_id', 'exposure' if 'exposure' in barra_raw.columns else None, 'factor_id' if 'factor_id' in barra_raw.columns else None), securities, standardize=False)

    existing_raw = raw['existing_factor_exposures']
    if isinstance(existing_raw, Mapping):
        existing = _normalize_snapshot_dict(existing_raw, securities, standardize=False)
    else:
        existing = _normalize_snapshot_dict(_long_to_snapshot_dict(existing_raw, 'date', 'security_id', 'exposure' if 'exposure' in existing_raw.columns else None, 'factor_id' if 'factor_id' in existing_raw.columns else None), securities, standardize=False)

    basket = raw['theme_basket_weights'].copy()
    if 'knowledge_date' not in basket.columns:
        if 'available_date' in basket.columns:
            basket['knowledge_date'] = pd.to_datetime(basket[['effective_date', 'available_date']].max(axis=1))
        else:
            basket['knowledge_date'] = pd.to_datetime(basket['effective_date'])
    basket['knowledge_date'] = pd.to_datetime(basket['knowledge_date']).dt.to_period('M').dt.to_timestamp('M')
    basket['effective_date'] = pd.to_datetime(basket.get('effective_date', basket['knowledge_date'])).dt.to_period('M').dt.to_timestamp('M')
    basket['security_id'] = basket['security_id'].map(normalize_security_id)

    data = {
        'stock_returns': stock_returns,
        'barra_exposures': barra,
        'existing_factor_exposures': existing,
        'theme_basket_weights': basket,
        'factor_metadata': raw.get('factor_metadata', infer_factor_metadata(sorted(set().union(*[set(x.columns) for x in existing.values()])))),
        'barra_factor_metadata': raw.get('barra_factor_metadata', infer_barra_metadata(sorted(set().union(*[set(x.columns) for x in barra.values()])))),
        'cash_returns': raw.get('cash_returns', pd.Series(0.0, index=stock_returns.index)),
        'meta': {'mode': 'real', 'path': str(path), 'n_months': len(stock_returns), 'n_stocks': stock_returns.shape[1]},
    }
    for key in cfg.market_cap_preference:
        if key in raw:
            data[key] = raw[key]
            break
    data['free_float_market_cap'] = resolve_market_cap_input(data, cfg)
    return data


def load_or_make_data(cfg: CombinedFactorWLSConfig) -> dict[str, Any]:
    data = make_synthetic_data(cfg) if cfg.use_synthetic_data else load_real_data(cfg)
    if 'free_float_market_cap' not in data:
        data['free_float_market_cap'] = resolve_market_cap_input(data, cfg)
    return data


def infer_factor_metadata(factor_ids: Sequence[str]) -> pd.DataFrame:
    rows = []
    for fid in factor_ids:
        up = str(fid).upper()
        is_mom = any(k in up for k in ['MOM', 'REVERSAL', 'STR', '52W'])
        rows.append({'factor_id': str(fid), 'factor_type': 'existing', 'role': 'investable_signal', 'is_momentum_related': is_mom})
    return pd.DataFrame(rows)


def infer_barra_metadata(factor_ids: Sequence[str]) -> pd.DataFrame:
    return pd.DataFrame([{'factor_id': str(fid), 'factor_kind': 'style', 'constraint_group': None} for fid in factor_ids])


def factor_metadata_effective(data: Mapping[str, Any], cfg: CombinedFactorWLSConfig) -> pd.DataFrame:
    m = data['factor_metadata'].copy()
    m['factor_id'] = m['factor_id'].astype(str)
    if 'factor_type' not in m.columns:
        m['factor_type'] = 'existing'
    if 'role' not in m.columns:
        m['role'] = 'investable_signal'
    if 'is_momentum_related' not in m.columns:
        m['is_momentum_related'] = m['factor_id'].str.upper().str.contains('MOM|REVERSAL|STR|52W')
    m['excluded_from_signal'] = cfg.exclude_momentum_related_from_signal & m['is_momentum_related'].astype(bool)
    m['effective_role'] = m['role']
    if cfg.include_excluded_momentum_as_control:
        mask = m['excluded_from_signal'] & (m['role'] == 'investable_signal')
        m.loc[mask, 'effective_role'] = 'purification_basis'
    else:
        m.loc[m['excluded_from_signal'], 'effective_role'] = 'excluded'
    return m


def raw_theme_matrix_for_date(basket: pd.DataFrame, asof: pd.Timestamp, securities: Sequence[str]) -> pd.DataFrame:
    d = pd.Timestamp(asof).to_period('M').to_timestamp('M')
    bw = basket.copy()
    bw['knowledge_date'] = pd.to_datetime(bw['knowledge_date']).dt.to_period('M').dt.to_timestamp('M')
    eligible = bw.loc[bw['knowledge_date'] <= d]
    if eligible.empty:
        raise ValueError(f'No theme basket available by {d.date()}')
    rows = []
    for theme, g in eligible.groupby('theme_id'):
        latest = g['knowledge_date'].max()
        rows.append(g.loc[g['knowledge_date'] == latest])
    latest = pd.concat(rows, ignore_index=True)
    latest['security_id'] = latest['security_id'].map(normalize_security_id)
    A = latest.pivot_table(index='security_id', columns='theme_id', values='weight', aggfunc='sum')
    A = A.reindex([normalize_security_id(s) for s in securities]).fillna(0.0)
    A = A.div(A.abs().sum(axis=0).replace(0.0, np.nan), axis=1).fillna(0.0)
    A.columns = [c if str(c).startswith('THEME__') else f'THEME__{c}' for c in A.columns]
    return A


def root_cap_weights(market_cap: pd.Series, cfg: CombinedFactorWLSConfig) -> pd.Series:
    cap = pd.to_numeric(market_cap, errors='coerce').astype(float)
    if cfg.regression_weight_mode == 'equal':
        w = pd.Series(1.0, index=cap.index)
    elif cfg.regression_weight_mode == 'root_cap':
        valid = cap.where((cap > 0.0) & np.isfinite(cap))
        if valid.notna().sum() == 0:
            if cfg.allow_equal_weight_fallback:
                w = pd.Series(1.0, index=cap.index)
            else:
                raise ValueError('No valid positive market caps for root-cap WLS')
        else:
            w = np.sqrt(valid)
    else:
        raise ValueError(f'Unsupported regression_weight_mode: {cfg.regression_weight_mode}')
    if cfg.weight_winsor_lower_quantile is not None:
        lo = w.quantile(cfg.weight_winsor_lower_quantile)
        w = w.clip(lower=lo)
    if cfg.weight_winsor_upper_quantile is not None:
        hi = w.quantile(cfg.weight_winsor_upper_quantile)
        w = w.clip(upper=hi)
    w = w.replace([np.inf, -np.inf], np.nan)
    if cfg.normalize_regression_weights_to_mean_one:
        mean = w.mean(skipna=True)
        if mean > 0:
            w = w / mean
    return w


def regression_weight_diagnostics(w: pd.Series, market_cap: pd.Series) -> pd.Series:
    valid = w.dropna()
    total = valid.sum()
    normalized_share = valid / total if total > 0 else valid * np.nan
    effective_n = (total ** 2 / np.square(valid).sum()) if np.square(valid).sum() > 0 else np.nan
    return pd.Series({
        'n_valid': len(valid), 'weight_min': valid.min(), 'weight_p25': valid.quantile(0.25),
        'weight_median': valid.median(), 'weight_p75': valid.quantile(0.75), 'weight_max': valid.max(),
        'max_normalized_weight_share': normalized_share.max(), 'effective_n': effective_n,
        'market_cap_min': market_cap.where(market_cap > 0).min(), 'market_cap_median': market_cap.where(market_cap > 0).median(),
        'market_cap_max': market_cap.where(market_cap > 0).max(),
    })


def build_category_constraints(B: pd.DataFrame, barra_meta: pd.DataFrame, market_cap: pd.Series, include_intercept: bool) -> pd.DataFrame:
    """Rows are linear constraints C beta = 0. Category returns are cap-weighted zero sum."""
    meta = barra_meta.copy()
    if 'constraint_group' not in meta.columns:
        return pd.DataFrame(columns=(['INTERCEPT'] if include_intercept else []) + list(B.columns), dtype=float)
    cap = market_cap.reindex(B.index).fillna(0.0).clip(lower=0.0)
    rows = []
    names = []
    columns = (['INTERCEPT'] if include_intercept else []) + list(B.columns)
    for group, g in meta.dropna(subset=['constraint_group']).groupby('constraint_group'):
        factors = [f for f in g['factor_id'].astype(str) if f in B.columns]
        if len(factors) <= 1:
            continue
        coeff = pd.Series(0.0, index=columns)
        group_caps = {}
        for f in factors:
            exposure = B[f].clip(lower=0.0)
            group_caps[f] = float((cap * exposure).sum())
        denom = sum(group_caps.values())
        if denom <= 0:
            group_caps = {f: 1.0 for f in factors}
            denom = float(len(factors))
        for f in factors:
            coeff[f] = group_caps[f] / denom
        rows.append(coeff)
        names.append(str(group))
    if not rows:
        return pd.DataFrame(columns=columns, dtype=float)
    return pd.DataFrame(rows, index=names).reindex(columns=columns, fill_value=0.0)


def _extend_constraints(constraints: pd.DataFrame, existing_columns: Sequence[str], added_columns: Sequence[str]) -> pd.DataFrame:
    if constraints is None or constraints.empty:
        return pd.DataFrame(columns=list(existing_columns) + list(added_columns), dtype=float)
    return constraints.reindex(columns=list(existing_columns) + list(added_columns), fill_value=0.0)


def constrained_wls_operator(X: pd.DataFrame, w: pd.Series, cfg: CombinedFactorWLSConfig, constraints: Optional[pd.DataFrame] = None, ridge: Optional[float] = None) -> np.ndarray:
    """Return K such that beta_hat = K y for zero-RHS constrained WLS.

    The implementation uses the augmented KKT system directly.  This is more
    stable than applying a Schur-complement formula to a rank-deficient design
    containing an intercept plus complete category dummies.
    """
    ridge = cfg.factor_return_ridge if ridge is None else float(ridge)
    Xv = X.to_numpy(dtype=float)
    wv = w.reindex(X.index).to_numpy(dtype=float)
    p, n = Xv.shape[1], Xv.shape[0]
    XtW = Xv.T * wv[None, :]
    A = XtW @ Xv + ridge * np.eye(p)

    if constraints is None or constraints.empty:
        return np.linalg.pinv(A, rcond=cfg.pinv_rcond) @ XtW

    C = constraints.reindex(columns=X.columns, fill_value=0.0).to_numpy(dtype=float)
    q = C.shape[0]
    kkt = np.block([
        [A, C.T],
        [C, np.zeros((q, q), dtype=float)],
    ])
    rhs = np.vstack([XtW, np.zeros((q, n), dtype=float)])
    solution = np.linalg.pinv(kkt, rcond=cfg.pinv_rcond) @ rhs
    return solution[:p, :]


def _constraint_nullspace(constraints: Optional[pd.DataFrame], columns: Sequence[str], rcond: float) -> np.ndarray:
    """Orthonormal basis for feasible coefficient directions C d = 0."""
    p = len(columns)
    if constraints is None or constraints.empty:
        return np.eye(p)
    C = constraints.reindex(columns=list(columns), fill_value=0.0).to_numpy(dtype=float)
    if C.size == 0:
        return np.eye(p)
    _, s, vt = np.linalg.svd(C, full_matrices=True)
    tol = max(C.shape) * (s[0] if len(s) else 0.0) * rcond
    rank = int(np.sum(s > tol))
    return vt[rank:, :].T


def fit_wls(X: pd.DataFrame, y: pd.Series, w: pd.Series, cfg: CombinedFactorWLSConfig, constraints: Optional[pd.DataFrame] = None, ridge: Optional[float] = None) -> dict[str, Any]:
    common = X.index.intersection(y.index).intersection(w.index)
    Xc = X.loc[common].astype(float)
    yc = pd.to_numeric(y.loc[common], errors='coerce')
    wc = pd.to_numeric(w.loc[common], errors='coerce')
    valid = yc.notna() & wc.notna() & (wc > 0) & Xc.notna().all(axis=1)
    Xv = Xc.loc[valid]
    yv = yc.loc[valid]
    base_w = wc.loc[valid]
    if len(yv) <= Xv.shape[1]:
        raise ValueError('Insufficient cross-sectional observations for WLS')
    effective_w = base_w.copy()
    beta = None
    for it in range(max(1, cfg.huber_iterations if cfg.robust_wls else 1)):
        K = constrained_wls_operator(Xv, effective_w, cfg, constraints=constraints, ridge=ridge)
        beta = K @ yv.to_numpy(dtype=float)
        resid = yv.to_numpy(dtype=float) - Xv.to_numpy(dtype=float) @ beta
        if not cfg.robust_wls or it == cfg.huber_iterations - 1:
            break
        med = np.median(resid)
        mad = np.median(np.abs(resid - med))
        scale = max(1.4826 * mad, 1e-12)
        z = np.abs((resid - med) / scale)
        huber = np.where(z <= cfg.huber_c, 1.0, cfg.huber_c / np.maximum(z, 1e-12))
        effective_w = base_w * huber
    fitted = pd.Series(Xv.to_numpy(dtype=float) @ beta, index=Xv.index, name='fitted')
    residual = yv - fitted
    beta_series = pd.Series(beta, index=Xv.columns)
    weighted_score = Xv.T @ (effective_w * residual)
    unweighted_score = Xv.T @ residual
    ridge_used = cfg.factor_return_ridge if ridge is None else float(ridge)
    feasible_basis = _constraint_nullspace(constraints, Xv.columns, cfg.pinv_rcond)
    stationarity_vector = weighted_score.to_numpy(dtype=float) - ridge_used * beta_series.to_numpy(dtype=float)
    projected_stationarity = feasible_basis.T @ stationarity_vector
    if constraints is None or constraints.empty:
        constraint_violation = pd.Series(dtype=float)
    else:
        C = constraints.reindex(columns=Xv.columns, fill_value=0.0)
        constraint_violation = C @ beta_series
    result = {
        'beta': beta_series, 'fitted': fitted, 'residual': residual,
        'base_weights': base_w, 'effective_weights': effective_w,
        # Retain legacy names for backward compatibility.  Under constrained
        # WLS X'Wu need not itself be zero; projected_stationarity is the
        # relevant first-order-condition diagnostic.
        'weighted_orthogonality': weighted_score,
        'unweighted_orthogonality': unweighted_score,
        'projected_stationarity': pd.Series(projected_stationarity),
        'constraint_violation': constraint_violation,
        'n_obs': len(yv), 'coverage': float(len(yv) / len(common)),
    }
    return result


def weighted_residualize(Y: pd.DataFrame, X: pd.DataFrame, w: pd.Series, cfg: CombinedFactorWLSConfig, constraints: Optional[pd.DataFrame] = None) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    common = Y.index.intersection(X.index).intersection(w.index)
    Xc = X.loc[common].astype(float)
    Yc = Y.loc[common].astype(float)
    wc = w.loc[common].astype(float)
    valid = wc.notna() & (wc > 0) & Xc.notna().all(axis=1) & Yc.notna().all(axis=1)
    Xv, Yv, wv = Xc.loc[valid], Yc.loc[valid], wc.loc[valid]
    K = constrained_wls_operator(Xv, wv, cfg, constraints=constraints, ridge=cfg.theme_purification_ridge)
    beta = K @ Yv.to_numpy(dtype=float)
    fitted = pd.DataFrame(Xv.to_numpy(dtype=float) @ beta, index=Xv.index, columns=Yv.columns)
    residual = Yv - fitted
    return residual, fitted, pd.DataFrame(beta, index=Xv.columns, columns=Yv.columns)


def build_snapshot(data: Mapping[str, Any], cfg: CombinedFactorWLSConfig, asof: pd.Timestamp) -> dict[str, Any]:
    d = pd.Timestamp(asof).to_period('M').to_timestamp('M')
    securities = list(data['stock_returns'].columns)
    B_key = asof_key(data['barra_exposures'], d)
    E_key = asof_key(data['existing_factor_exposures'], d)
    B = data['barra_exposures'][B_key].copy().reindex(securities)
    E_all = data['existing_factor_exposures'][E_key].copy().reindex(securities)
    B.index = [normalize_security_id(i) for i in B.index]
    E_all.index = [normalize_security_id(i) for i in E_all.index]
    B = B.reindex(securities)
    E_all = E_all.reindex(securities)

    meta = factor_metadata_effective(data, cfg)
    investable_ids = meta.loc[meta['effective_role'] == 'investable_signal', 'factor_id'].astype(str).tolist()
    control_ids = meta.loc[meta['effective_role'].isin(['purification_basis', 'risk_control_only']), 'factor_id'].astype(str).tolist()
    investable_ids = [c for c in investable_ids if c in E_all.columns]
    control_ids = [c for c in control_ids if c in E_all.columns and c not in investable_ids]
    E = E_all[investable_ids].copy()
    E.columns = [f'EXISTING__{c}' for c in E.columns]
    E_control = E_all[control_ids].copy()
    E_control.columns = [f'CONTROL_EXISTING__{c}' for c in E_control.columns]

    market_cap = data['free_float_market_cap'].loc[d].reindex(securities)
    w = root_cap_weights(market_cap, cfg)
    valid_index = B.index[B.notna().all(axis=1) & E.notna().all(axis=1) & E_control.notna().all(axis=1) & w.notna() & (w > 0)]
    B, E, E_control, market_cap, w = B.loc[valid_index], E.loc[valid_index], E_control.loc[valid_index], market_cap.loc[valid_index], w.loc[valid_index]

    control_parts = []
    if cfg.include_intercept:
        control_parts.append(pd.Series(1.0, index=valid_index, name='INTERCEPT'))
    control_parts.append(B)
    if not E_control.empty:
        control_parts.append(E_control)
    C = pd.concat(control_parts, axis=1)

    A = raw_theme_matrix_for_date(data['theme_basket_weights'], d, valid_index)
    purification_basis = pd.concat([C, E], axis=1)
    barra_meta = data.get('barra_factor_metadata', infer_barra_metadata(B.columns))
    constraints_C = build_category_constraints(B, barra_meta, market_cap, include_intercept=cfg.include_intercept)
    constraints_basis = _extend_constraints(constraints_C, C.columns, E.columns)
    Z_raw, Z_fitted, purif_beta = weighted_residualize(A, purification_basis, w, cfg, constraints=constraints_basis)
    Z = l2_normalize_columns(Z_raw)
    F = pd.concat([E.loc[Z.index], Z], axis=1)
    C = C.loc[Z.index]
    w = w.loc[Z.index]
    market_cap = market_cap.loc[Z.index]
    constraints_full = _extend_constraints(constraints_C, C.columns, F.columns)

    # WLS-consistent coefficient mimicking matrix for target factors.
    X_full = pd.concat([C, F], axis=1)
    K_full = constrained_wls_operator(X_full, w, cfg, constraints=constraints_full, ridge=cfg.mimicking_ridge)
    target_rows = [X_full.columns.get_loc(c) for c in F.columns]
    M = pd.DataFrame(K_full[target_rows, :].T, index=X_full.index, columns=F.columns)
    exposure_matrix = M.T @ X_full

    # Theme diagnostics under the same W.
    WZ = Z.mul(w, axis=0)
    theme_orth = purification_basis.loc[Z.index].T @ WZ
    purif_rows = []
    for col in A.columns:
        if col not in Z.columns:
            continue
        y = A.loc[Z.index, col]
        yhat = Z_fitted.loc[Z.index, col]
        weighted_mean = np.average(y, weights=w)
        sst = float(np.sum(w * np.square(y - weighted_mean)))
        sse = float(np.sum(w * np.square(y - yhat)))
        purif_rows.append({
            'theme_id': col,
            'weighted_purification_r2': np.nan if sst <= 0 else 1 - sse / sst,
            'pure_l2': float(np.sqrt(np.square(Z[col]).sum())),
            'max_abs_weighted_basis_exposure': float(theme_orth[col].abs().max()),
        })
    purif_diag = pd.DataFrame(purif_rows).set_index('theme_id')

    factor_meta_rows = []
    for c in F.columns:
        factor_meta_rows.append({'factor_id': c, 'factor_type': 'existing' if c.startswith('EXISTING__') else 'theme_purified'})
    factor_meta = pd.DataFrame(factor_meta_rows).set_index('factor_id')

    mdiag = []
    for c in F.columns:
        expo = exposure_matrix.loc[c]
        other = expo.reindex(F.columns).drop(index=c)
        control = expo.reindex(C.columns)
        mdiag.append({
            'factor_id': c, 'factor_type': factor_meta.loc[c, 'factor_type'],
            'gross': float(M[c].abs().sum()), 'long_gross': float(M[c].clip(lower=0).sum()),
            'short_gross': float(-M[c].clip(upper=0).sum()), 'net': float(M[c].sum()),
            'max_abs_weight': float(M[c].abs().max()),
            'target_exposure_error': float(expo[c] - 1.0),
            'max_abs_other_factor_exposure': float(other.abs().max()) if len(other) else 0.0,
            'max_abs_control_exposure': float(control.abs().max()) if len(control) else 0.0,
        })
    mimicking_diag = pd.DataFrame(mdiag).set_index('factor_id')

    return {
        'asof': d, 'market_cap': market_cap, 'regression_weights': w,
        'B': B.loc[Z.index], 'E': E.loc[Z.index], 'existing_controls': E_control.loc[Z.index],
        'C': C, 'A': A.loc[Z.index], 'Z': Z, 'F': F, 'X_full': X_full,
        'constraints_control': constraints_C, 'constraints_full': constraints_full,
        'purification_beta': purif_beta, 'purification_diagnostics': purif_diag,
        'theme_weighted_orthogonality': theme_orth,
        'M': M, 'mimicking_exposure_matrix': exposure_matrix,
        'mimicking_diagnostics': mimicking_diag,
        'factor_metadata_current': factor_meta,
        'weight_diagnostics': regression_weight_diagnostics(w, market_cap),
    }


def estimate_returns_for_period(stock_return: pd.Series, snapshot: Mapping[str, Any], cfg: CombinedFactorWLSConfig) -> dict[str, Any]:
    r = stock_return.reindex(snapshot['X_full'].index)
    full_fit = fit_wls(snapshot['X_full'], r, snapshot['regression_weights'], cfg, constraints=snapshot['constraints_full'], ridge=cfg.factor_return_ridge)
    target_beta = full_fit['beta'].reindex(snapshot['F'].columns)
    replicated = snapshot['M'].T @ r.fillna(0.0)

    # Barra/control-only residual for downstream diagnostics.
    control_fit = fit_wls(snapshot['C'], r, snapshot['regression_weights'], cfg, constraints=snapshot['constraints_control'], ridge=cfg.factor_return_ridge)
    residual_barra = control_fit['residual']

    # Two-stage Frisch-Waugh-Lovell check using exactly the same root-cap W.
    # Both returns and target exposures are residualized against the same
    # constrained Barra/control design before the second-stage WLS.
    F_resid, _, _ = weighted_residualize(
        snapshot['F'], snapshot['C'], snapshot['regression_weights'], cfg,
        constraints=snapshot['constraints_control'],
    )
    fwl_index = residual_barra.index.intersection(F_resid.index)
    stage2 = fit_wls(
        F_resid.loc[fwl_index], residual_barra.loc[fwl_index],
        snapshot['regression_weights'].loc[fwl_index], cfg,
        constraints=None, ridge=cfg.factor_return_ridge,
    )
    fwl_beta = stage2['beta'].reindex(snapshot['F'].columns)

    return {
        'model_factor_return': target_beta,
        'replicated_factor_return': replicated.reindex(target_beta.index),
        'full_specific_return': full_fit['residual'],
        'barra_residual_return': residual_barra,
        'full_fit': full_fit, 'control_fit': control_fit,
        'fwl_factor_return': fwl_beta,
        'replication_identity_error': float((replicated.reindex(target_beta.index) - target_beta).abs().max()),
        'fwl_identity_error': float((fwl_beta - target_beta).abs().max()),
    }


def compute_factor_return_history(data: Mapping[str, Any], cfg: CombinedFactorWLSConfig) -> tuple[pd.DataFrame, dict[pd.Timestamp, dict[str, Any]], pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    returns = data['stock_returns'].sort_index()
    dates = pd.DatetimeIndex(returns.index)
    rep_rows, model_rows, diag_rows = [], [], []
    snapshots: dict[pd.Timestamp, dict[str, Any]] = {}
    latest_residuals = []
    for i in range(len(dates) - 1):
        asof, hold = pd.Timestamp(dates[i]), pd.Timestamp(dates[i + 1])
        try:
            snap = build_snapshot(data, cfg, asof)
            est = estimate_returns_for_period(returns.loc[hold], snap, cfg)
            rep = est['replicated_factor_return'].rename(hold)
            model = est['model_factor_return'].rename(hold)
            rep_rows.append(rep)
            model_rows.append(model)
            snap['return_estimation'] = est
            snapshots[asof] = snap
            diag_rows.append({
                'asof': asof, 'holding_month': hold,
                'n_stocks': len(snap['X_full']), 'n_controls': snap['C'].shape[1], 'n_targets': snap['F'].shape[1],
                'regression_weight_mode': cfg.regression_weight_mode,
                'weight_effective_n': snap['weight_diagnostics']['effective_n'],
                'max_weight_share': snap['weight_diagnostics']['max_normalized_weight_share'],
                'replication_identity_error': est['replication_identity_error'],
                'fwl_identity_error': est['fwl_identity_error'],
                'max_abs_projected_stationarity_full': float(est['full_fit']['projected_stationarity'].abs().max()) if len(est['full_fit']['projected_stationarity']) else 0.0,
                'max_abs_constraint_violation_full': float(est['full_fit']['constraint_violation'].abs().max()) if len(est['full_fit']['constraint_violation']) else 0.0,
                'max_abs_Xtu_full': float(est['full_fit']['unweighted_orthogonality'].abs().max()),
                'max_abs_projected_stationarity_barra': float(est['control_fit']['projected_stationarity'].abs().max()) if len(est['control_fit']['projected_stationarity']) else 0.0,
                'max_abs_constraint_violation_barra': float(est['control_fit']['constraint_violation'].abs().max()) if len(est['control_fit']['constraint_violation']) else 0.0,
                'median_mimicking_gross': float(snap['mimicking_diagnostics']['gross'].median()),
                'max_mimicking_gross': float(snap['mimicking_diagnostics']['gross'].max()),
            })
            if i == len(dates) - 2:
                latest_residuals = [est['barra_residual_return'].rename('barra_residual'), est['full_specific_return'].rename('full_specific')]
        except Exception as exc:
            warnings.warn(f'Skipped {asof.date()} -> {hold.date()}: {type(exc).__name__}: {exc}')
    rep_df = pd.DataFrame(rep_rows).sort_index()
    model_df = pd.DataFrame(model_rows).sort_index()
    diag_df = pd.DataFrame(diag_rows).set_index('asof').sort_index()
    residual_df = pd.concat(latest_residuals, axis=1) if latest_residuals else pd.DataFrame()
    return rep_df, snapshots, diag_df, model_df, residual_df


def compare_latest_equal_vs_rootcap(data: Mapping[str, Any], cfg: CombinedFactorWLSConfig, snapshot: Mapping[str, Any], return_date: pd.Timestamp) -> pd.DataFrame:
    y = data['stock_returns'].loc[return_date]
    root_fit = fit_wls(snapshot['X_full'], y, snapshot['regression_weights'], cfg, constraints=snapshot['constraints_full'])
    cfg_equal = CombinedFactorWLSConfig(**{**cfg.__dict__, 'regression_weight_mode': 'equal', 'require_market_cap_for_wls': False, 'allow_equal_weight_fallback': True, 'output_dir': cfg.output_dir})
    equal_w = pd.Series(1.0, index=snapshot['X_full'].index)
    equal_fit = fit_wls(snapshot['X_full'], y, equal_w, cfg_equal, constraints=snapshot['constraints_full'])
    comp = pd.DataFrame({
        'rootcap_wls_return': root_fit['beta'],
        'equal_ols_return': equal_fit['beta'],
        'difference_rootcap_minus_equal': root_fit['beta'] - equal_fit['beta'],
    })
    return comp


def normalize_factor_weights(raw: pd.Series, meta: pd.DataFrame, cfg: CombinedFactorWLSConfig, weighting_mode: Optional[str] = None) -> pd.Series:
    mode = weighting_mode or cfg.weighting_mode
    raw = raw.replace([np.inf, -np.inf], np.nan).dropna().astype(float)
    out = pd.Series(0.0, index=meta.index, dtype=float)
    raw = raw.reindex(meta.index).dropna()
    if raw.abs().sum() <= 0:
        return out
    if mode == 'factor_equal':
        out.loc[raw.index] = raw / raw.abs().sum() * cfg.factor_gross_target
    elif mode == 'block_equal':
        blocks = meta.loc[raw.index, 'factor_type'].replace({'theme_purified': 'theme'})
        unique = list(blocks.dropna().unique())
        block_gross = cfg.factor_gross_target / max(len(unique), 1)
        for b in unique:
            idx = blocks.index[blocks == b]
            denom = raw.loc[idx].abs().sum()
            if denom > 0:
                out.loc[idx] = raw.loc[idx] / denom * block_gross
    else:
        raise ValueError(mode)
    return out


def compute_tsfm_signal(factor_returns: pd.DataFrame, meta: pd.DataFrame, cfg: CombinedFactorWLSConfig, asof: pd.Timestamp, mode: str, allowed_factor_types: Optional[Sequence[str]] = None, weighting_mode: Optional[str] = None) -> tuple[pd.Series, pd.DataFrame]:
    hist = factor_returns.loc[factor_returns.index <= asof]
    if cfg.skip_recent_months > 0:
        hist_signal = hist.iloc[:-cfg.skip_recent_months]
    else:
        hist_signal = hist
    window = hist_signal.tail(cfg.formation_months)
    min_count = max(1, math.ceil(cfg.formation_months * 0.6))
    formation = (1.0 + window).prod(min_count=min_count) - 1.0
    vol = hist.tail(cfg.volatility_lookback_months).std(ddof=1) * math.sqrt(12)
    base_meta = meta.copy()
    if allowed_factor_types is not None:
        base_meta = base_meta.loc[base_meta['factor_type'].isin(set(allowed_factor_types))]
    valid = base_meta.index.intersection(formation.dropna().index)
    direction = np.sign(formation.reindex(valid)).replace(0.0, np.nan)
    if mode == 'binary':
        raw = direction
    elif mode == 'vol_scaled':
        raw = direction / vol.reindex(valid).replace(0.0, np.nan)
    else:
        raise ValueError(mode)
    weights = normalize_factor_weights(raw, base_meta.loc[valid], cfg, weighting_mode)
    full = pd.Series(0.0, index=meta.index)
    full.loc[weights.index] = weights
    table = pd.DataFrame({
        'factor_type': meta['factor_type'], 'formation_return': formation.reindex(meta.index),
        'signal': direction.reindex(meta.index), 'ann_vol': vol.reindex(meta.index),
        'raw_weight': raw.reindex(meta.index), 'factor_weight': full,
    })
    table['position'] = np.where(table['factor_weight'] > 0, 'long', np.where(table['factor_weight'] < 0, 'short', 'flat'))
    return full, table


def run_strategy_backtest(data: Mapping[str, Any], cfg: CombinedFactorWLSConfig, factor_returns: pd.DataFrame, snapshots: Mapping[pd.Timestamp, dict[str, Any]], mode: str, weighting_mode: str, allowed_factor_types: Optional[Sequence[str]], strategy_name: str) -> dict[str, Any]:
    stock_returns = data['stock_returns'].sort_index()
    returns_rows, factor_rows, stock_rows = [], [], []
    signal_tables = {}
    prev_stock = pd.Series(0.0, index=stock_returns.columns)
    for asof in factor_returns.index:
        if asof not in snapshots:
            continue
        hist = factor_returns.loc[:asof]
        if len(hist.dropna(how='all')) < cfg.min_history_months:
            continue
        idx = stock_returns.index.searchsorted(asof, side='right')
        if idx >= len(stock_returns.index):
            continue
        hold = pd.Timestamp(stock_returns.index[idx])
        snap = snapshots[asof]
        fw, table = compute_tsfm_signal(factor_returns, snap['factor_metadata_current'], cfg, asof, mode, allowed_factor_types, weighting_mode)
        fw = fw.reindex(snap['M'].columns).fillna(0.0)
        if fw.abs().sum() <= 0:
            continue
        sw = (snap['M'] @ fw).reindex(stock_returns.columns).fillna(0.0)
        r = stock_returns.loc[hold].fillna(0.0)
        gross = float(sw @ r)
        turnover = float((sw - prev_stock).abs().sum() / 2.0)
        cost = turnover * cfg.transaction_cost_bps_one_way / 10000.0
        existing_cols = [c for c in fw.index if c.startswith('EXISTING__')]
        theme_cols = [c for c in fw.index if c.startswith('THEME__')]
        sw_existing = snap['M'][existing_cols] @ fw.reindex(existing_cols).fillna(0.0) if existing_cols else pd.Series(0.0, index=snap['M'].index)
        sw_theme = snap['M'][theme_cols] @ fw.reindex(theme_cols).fillna(0.0) if theme_cols else pd.Series(0.0, index=snap['M'].index)
        returns_rows.append({
            'holding_month': hold, 'asof': asof, 'strategy': strategy_name,
            'gross_return': gross, 'net_return': gross - cost,
            'factor_space_return': float((fw * factor_returns.loc[hold].reindex(fw.index).fillna(0.0)).sum()) if hold in factor_returns.index else np.nan,
            'existing_factor_pnl': float(sw_existing.reindex(r.index).fillna(0.0) @ r),
            'theme_factor_pnl': float(sw_theme.reindex(r.index).fillna(0.0) @ r),
            'turnover': turnover, 'transaction_cost': cost,
            'stock_gross': float(sw.abs().sum()), 'stock_net': float(sw.sum()),
            'factor_gross': float(fw.abs().sum()),
            'existing_factor_gross': float(fw.reindex(existing_cols).abs().sum()),
            'theme_factor_gross': float(fw.reindex(theme_cols).abs().sum()),
            'n_long_factors': int((fw > 1e-12).sum()), 'n_short_factors': int((fw < -1e-12).sum()),
        })
        factor_rows.append(fw.rename(asof))
        stock_rows.append(sw.rename(asof))
        signal_tables[asof] = table
        prev_stock = sw
    rets = pd.DataFrame(returns_rows).set_index('holding_month').sort_index() if returns_rows else pd.DataFrame()
    fws = pd.DataFrame(factor_rows).sort_index() if factor_rows else pd.DataFrame()
    sws = pd.DataFrame(stock_rows).sort_index() if stock_rows else pd.DataFrame()
    return {'returns': rets, 'factor_weights': fws, 'stock_weights': sws, 'signal_tables': signal_tables}


def performance_stats(returns: pd.Series | pd.DataFrame, periods_per_year: int = 12) -> pd.DataFrame:
    if isinstance(returns, pd.Series):
        returns = returns.to_frame(returns.name or 'return')
    rows = []
    for c in returns.columns:
        r = returns[c].dropna().astype(float)
        if len(r) == 0:
            continue
        ann_ret = r.mean() * periods_per_year
        ann_vol = r.std(ddof=1) * math.sqrt(periods_per_year)
        wealth = (1 + r).cumprod()
        dd = wealth / wealth.cummax() - 1
        rows.append({'series': c, 'n': len(r), 'ann_return': ann_ret, 'ann_vol': ann_vol,
                     'sharpe': ann_ret / ann_vol if ann_vol > 0 else np.nan,
                     'mean_t_value': r.mean() / (r.std(ddof=1) / math.sqrt(len(r))) if len(r) > 1 and r.std(ddof=1) > 0 else np.nan,
                     'max_drawdown': dd.min(), 'hit_rate': (r > 0).mean()})
    return pd.DataFrame(rows).set_index('series')


def factor_return_diagnostics(factor_returns: pd.DataFrame, meta: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for c in factor_returns.columns:
        r = factor_returns[c].dropna()
        rows.append({'factor_id': c, 'factor_type': meta.loc[c, 'factor_type'] if c in meta.index else None,
                     'n': len(r), 'mean_monthly': r.mean(), 'ann_vol': r.std(ddof=1) * math.sqrt(12),
                     'sharpe': (r.mean() * 12) / (r.std(ddof=1) * math.sqrt(12)) if r.std(ddof=1) > 0 else np.nan,
                     'ar1': r.autocorr(1) if len(r) >= 3 else np.nan})
    return pd.DataFrame(rows).set_index('factor_id')


def plot_cumulative_returns(df: pd.DataFrame, title: str) -> None:
    if df.empty:
        return
    ax = (1 + df.fillna(0.0)).cumprod().plot(figsize=(10, 4), title=title)
    ax.set_ylabel('Growth of 1')
    ax.grid(True, alpha=0.3)
    plt.show()


def plot_factor_weight_heatmap(weights: pd.DataFrame, title: str) -> None:
    if weights.empty:
        return
    fig, ax = plt.subplots(figsize=(11, max(3, 0.28 * weights.shape[1])))
    im = ax.imshow(weights.T.to_numpy(), aspect='auto')
    ax.set_title(title)
    ax.set_yticks(range(weights.shape[1]))
    ax.set_yticklabels(weights.columns)
    step = max(1, len(weights) // 8)
    ax.set_xticks(range(0, len(weights), step))
    ax.set_xticklabels([pd.Timestamp(d).strftime('%Y-%m') for d in weights.index[::step]], rotation=45, ha='right')
    fig.colorbar(im, ax=ax, label='factor weight')
    plt.tight_layout()
    plt.show()


def save_strategy_outputs(result: Mapping[str, Any], cfg: CombinedFactorWLSConfig, slug: str, extra: Optional[Mapping[str, Any]] = None) -> list[Path]:
    cfg.output_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for name in ['returns', 'factor_weights', 'stock_weights']:
        obj = result.get(name)
        if isinstance(obj, pd.DataFrame):
            p = cfg.output_dir / f'{slug}_{name}.csv'; obj.to_csv(p); paths.append(p)
    if extra:
        for name, obj in extra.items():
            if isinstance(obj, pd.DataFrame):
                p = cfg.output_dir / f'{slug}_{name}.csv'; obj.to_csv(p); paths.append(p)
            elif isinstance(obj, pd.Series):
                p = cfg.output_dir / f'{slug}_{name}.csv'; obj.to_frame('value').to_csv(p); paths.append(p)
    print('Saved:')
    for p in paths:
        print(' -', p)
    return paths
