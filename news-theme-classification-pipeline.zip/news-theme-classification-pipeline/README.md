# ニューステーマ分類パイプライン

## 目的
大量ニュース記事に対して、既知テーマの安定追跡と未知テーマの発見を両立するための最小構成パイプラインを提供します。

本リポジトリは以下の 5 段階を 1 本の notebook (`notebooks/main.ipynb`) で end-to-end 実行できる構成です。

1. Sentence Transformers で記事 embedding を生成
2. テーマ説明文との類似度で多ラベル付与
3. 閾値未満（residual）のみ BERTopic でクラスタリング
4. BERTopic outlier を保持し、週次で再クラスタリング
5. SetFit multilabel 学習へ移行しやすいラベルストアを保存

## パイプライン概要
- 入力: `data/raw/news_sample.csv`（CSV）
- 既知テーマ: `data/raw/theme_definitions.yaml`
- 中間生成物: `data/processed/*.parquet`
- 結果: `outputs/tables/*.parquet`, `outputs/figures/*.png`

### 処理フロー
1. 前処理で `text_for_embedding` を生成（`title + summary + body_short`）
2. 記事・テーマ embedding を作成しキャッシュ保存
3. コサイン類似度を計算してテーマごとの閾値で多ラベル付与
4. 未分類記事のみ BERTopic 実行、topic / keyword / representative / outlier を保存
5. outlier を週次バケット化して再クラスタリング
6. SetFit 向け教師データを long / wide 形式で保存
7. 表・時系列図を出力

## 入力データ仕様
`data/raw/news_sample.csv` は最低限以下カラムを持つ必要があります。

- `article_id`
- `published_at`
- `source`
- `title`
- `summary`
- `body`
- `url`

`text_for_embedding` は下記優先順で作成します。

- `title`
- `summary`（存在時）
- `body_short`（長文を設定文字数で切り詰め）

## テーマ定義ファイル仕様
`data/raw/theme_definitions.yaml` は次のフィールドを必須とします。

- `theme_id`
- `name_ja`
- `description`
- `threshold`

`description` の embedding をテーマプロトタイプとして使います。

## 実行手順
### 1. 依存関係（envs/nlp）
このプロジェクトでは明示 Python パスを使用します。

- Python: `envs/nlp/.venv/bin/python`

依存追加が必要な場合は `pip install` ではなく `envs/nlp` 配下で `uv add` を使います。

例:

```bash
cd ~/workspace/envs/nlp
uv add sentence-transformers bertopic pyyaml pyarrow
```

### 2. Notebook 実行

```bash
cd ~/workspace/projects/news-theme-classification-pipeline/notebooks
~/workspace/envs/nlp/.venv/bin/python -m jupyter nbconvert --to notebook --inplace --execute main.ipynb
```

または JupyterLab で `main.ipynb` を上から順に実行してください。

## 生成物一覧
### data/processed
- `article_embeddings.parquet`
- `theme_embeddings.parquet`
- `labels_long.parquet`
- `labels_wide.parquet`

### outputs/tables
- `article_theme_scores.parquet`
- `article_theme_assignments.parquet`
- `residual_topics.parquet`
- `residual_topic_keywords.parquet`
- `residual_topic_representative_docs.parquet`
- `residual_outliers.parquet`
- `outlier_weekly_recluster_topics.parquet`
- `theme_article_counts.parquet`
- `unclassified_rate.parquet`
- `residual_topic_counts.parquet`
- `outlier_weekly_counts.parquet`

### outputs/figures
- `known_theme_counts_timeseries.png`
- `unclassified_rate_timeseries.png`
- `residual_topic_count_timeseries.png`
- `outlier_reclustered_theme_count_timeseries.png`
- `outlier_topic_count_by_week.png`

## SetFit への将来移行方針
- `labels_long.parquet` でラベルソース付き教師データを保持
- `labels_wide.parquet` で multilabel 学習へ直接投入しやすい行列形式を保持
- `label_source` は `manual` / `similarity_high_conf` / `bertopic_promoted` を扱う
- BERTopic で得たクラスタに人手でテーマを付与した結果を `bertopic_promoted` として昇格可能

## チューニングポイント（人手確認推奨）
- 埋め込みモデル: `EMBEDDING_MODEL_NAME`
- 閾値設計: `DEFAULT_THRESHOLD`, テーマ別 `threshold`
- BERTopic 粒度: `BERTOPIC_MIN_TOPIC_SIZE`, `BERTOPIC_NR_TOP_WORDS`
- outlier 再クラスタリング戦略: `OUTLIER_RECLUSTER_MODE`, `OUTLIER_RECLUSTER_LOOKBACK_WEEKS`
- 疑似ラベル厳しさ: `MIN_HIGH_CONFIDENCE_FOR_PSEUDO_LABEL`

## 参照文献
詳細は `docs/notes/40_references.md` を参照してください。
