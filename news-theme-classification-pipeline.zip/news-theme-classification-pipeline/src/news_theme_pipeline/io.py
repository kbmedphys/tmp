"""入出力処理。"""

from __future__ import annotations

from pathlib import Path
import json

import pandas as pd
import yaml


REQUIRED_ARTICLE_COLUMNS = [
    "article_id",
    "published_at",
    "source",
    "title",
    "summary",
    "body",
    "url",
]

REQUIRED_THEME_COLUMNS = ["theme_id", "name_ja", "description", "threshold"]



def load_articles_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = sorted(set(REQUIRED_ARTICLE_COLUMNS) - set(df.columns))
    if missing:
        raise ValueError(f"入力CSVに必須カラムが不足しています: {missing}")

    out = df.copy()
    out["published_at"] = pd.to_datetime(out["published_at"], errors="coerce")
    if out["published_at"].isna().any():
        invalid_count = int(out["published_at"].isna().sum())
        raise ValueError(f"published_at を datetime へ変換できない行があります: {invalid_count} 件")

    for col in ["article_id", "source", "title", "summary", "body", "url"]:
        out[col] = out[col].fillna("").astype(str)
    return out



def load_theme_definitions(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()

    if suffix in {".yml", ".yaml"}:
        with path.open("r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)
    elif suffix == ".json":
        with path.open("r", encoding="utf-8") as f:
            raw = json.load(f)
    else:
        raise ValueError(f"未対応のテーマ定義ファイル拡張子です: {suffix}")

    if not isinstance(raw, dict) or "themes" not in raw:
        raise ValueError("テーマ定義は {themes: [...]} 形式である必要があります。")

    themes = raw["themes"]
    if not isinstance(themes, list):
        raise ValueError("themes は配列である必要があります。")

    df = pd.DataFrame(themes)
    missing = sorted(set(REQUIRED_THEME_COLUMNS) - set(df.columns))
    if missing:
        raise ValueError(f"テーマ定義に必須項目が不足しています: {missing}")

    out = df.copy()
    out["theme_id"] = out["theme_id"].astype(str)
    out["name_ja"] = out["name_ja"].astype(str)
    out["description"] = out["description"].fillna("").astype(str)
    out["threshold"] = pd.to_numeric(out["threshold"], errors="coerce")

    if out["threshold"].isna().any():
        invalid_count = int(out["threshold"].isna().sum())
        raise ValueError(f"threshold に数値変換できない値があります: {invalid_count} 件")

    return out



def load_optional_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)



def save_parquet(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)



def read_parquet_if_exists(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_parquet(path)
