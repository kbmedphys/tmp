"""前処理。"""

from __future__ import annotations

import pandas as pd



def _truncate_text(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars]



def build_text_for_embedding(df: pd.DataFrame, max_body_chars: int = 1200) -> pd.DataFrame:
    out = df.copy()

    out["title"] = out["title"].fillna("").astype(str)
    out["summary"] = out["summary"].fillna("").astype(str)
    out["body"] = out["body"].fillna("").astype(str)

    out["body_short"] = out["body"].map(lambda x: _truncate_text(x, max_body_chars))

    out["text_for_embedding"] = (
        out["title"].str.strip()
        + "\n"
        + out["summary"].str.strip()
        + "\n"
        + out["body_short"].str.strip()
    ).str.strip()

    return out
