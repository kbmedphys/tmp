"""類似度計算と多ラベル付与。"""

from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd



def build_similarity_scores(
    article_ids: Iterable[str],
    article_embeddings: np.ndarray,
    theme_df: pd.DataFrame,
    theme_embeddings: np.ndarray,
    default_threshold: float,
    use_theme_specific_threshold: bool,
    top_k: int,
) -> pd.DataFrame:
    article_ids_list = list(article_ids)
    if article_embeddings.ndim != 2 or theme_embeddings.ndim != 2:
        raise ValueError("embedding 行列は 2 次元である必要があります。")

    score_matrix = np.matmul(article_embeddings, theme_embeddings.T)

    rows: list[dict[str, object]] = []
    for article_idx, article_id in enumerate(article_ids_list):
        similarities = score_matrix[article_idx]
        ranking = np.argsort(-similarities)

        for rank, theme_idx in enumerate(ranking, start=1):
            theme_id = str(theme_df.iloc[theme_idx]["theme_id"])
            threshold = float(default_threshold)
            if use_theme_specific_threshold:
                threshold = float(theme_df.iloc[theme_idx]["threshold"])

            similarity = float(similarities[theme_idx])
            rows.append(
                {
                    "article_id": article_id,
                    "theme_id": theme_id,
                    "theme_name_ja": str(theme_df.iloc[theme_idx]["name_ja"]),
                    "similarity": similarity,
                    "similarity_rank": rank,
                    "threshold": threshold,
                    "over_threshold": similarity >= threshold,
                    "is_top_k": rank <= int(top_k),
                }
            )

    return pd.DataFrame(rows)



def assign_multilabels(scores_df: pd.DataFrame) -> pd.DataFrame:
    if scores_df.empty:
        return pd.DataFrame(columns=["article_id", "theme_ids", "max_similarity", "unclassified", "assigned_by"])

    def collect_theme_ids(group: pd.DataFrame) -> list[str]:
        over = group[group["over_threshold"]].sort_values("similarity", ascending=False)
        return over["theme_id"].astype(str).tolist()

    theme_ids_series = scores_df.groupby("article_id", as_index=True).apply(collect_theme_ids)
    max_similarity = scores_df.groupby("article_id")["similarity"].max()

    assignments = pd.DataFrame(
        {
            "article_id": theme_ids_series.index,
            "theme_ids": theme_ids_series.values,
            "max_similarity": max_similarity.reindex(theme_ids_series.index).values,
        }
    )
    assignments["unclassified"] = assignments["theme_ids"].map(lambda x: len(x) == 0)
    assignments["assigned_by"] = "similarity"
    return assignments.reset_index(drop=True)



def apply_assignment_overrides(
    assignments_df: pd.DataFrame,
    bertopic_promoted_df: pd.DataFrame | None = None,
    manual_labels_df: pd.DataFrame | None = None,
) -> pd.DataFrame:
    out = assignments_df.copy()

    if bertopic_promoted_df is not None and not bertopic_promoted_df.empty:
        required = {"article_id", "theme_id"}
        if required.issubset(bertopic_promoted_df.columns):
            promoted_map = (
                bertopic_promoted_df.groupby("article_id")["theme_id"]
                .apply(lambda s: sorted(set(s.astype(str).tolist())))
                .to_dict()
            )

            mask = out["article_id"].isin(promoted_map.keys())
            out.loc[mask, "theme_ids"] = out.loc[mask, "article_id"].map(promoted_map)
            out.loc[mask, "unclassified"] = False
            out.loc[mask, "assigned_by"] = "bertopic"

    if manual_labels_df is not None and not manual_labels_df.empty:
        required = {"article_id", "theme_id"}
        if required.issubset(manual_labels_df.columns):
            manual_positive = manual_labels_df.copy()
            if "label" in manual_positive.columns:
                manual_positive = manual_positive[manual_positive["label"].astype(int) == 1]

            manual_map = (
                manual_positive.groupby("article_id")["theme_id"]
                .apply(lambda s: sorted(set(s.astype(str).tolist())))
                .to_dict()
            )
            mask = out["article_id"].isin(manual_map.keys())
            out.loc[mask, "theme_ids"] = out.loc[mask, "article_id"].map(manual_map)
            out.loc[mask, "unclassified"] = False
            out.loc[mask, "assigned_by"] = "manual"

    return out
