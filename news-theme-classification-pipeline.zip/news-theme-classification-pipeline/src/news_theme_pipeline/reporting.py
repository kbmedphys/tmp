"""集計と可視化。"""

from __future__ import annotations

import matplotlib.pyplot as plt
import pandas as pd



def build_theme_article_counts(assignments_df: pd.DataFrame) -> pd.DataFrame:
    exploded = assignments_df.explode("theme_ids")
    exploded = exploded[exploded["theme_ids"].notna() & (exploded["theme_ids"] != "")]
    if exploded.empty:
        return pd.DataFrame(columns=["theme_id", "article_count"])

    return (
        exploded.groupby("theme_ids", as_index=False)["article_id"]
        .nunique()
        .rename(columns={"theme_ids": "theme_id", "article_id": "article_count"})
        .sort_values("article_count", ascending=False)
    )



def build_unclassified_rate(assignments_df: pd.DataFrame, articles_df: pd.DataFrame) -> pd.DataFrame:
    merged = assignments_df.merge(articles_df[["article_id", "published_at"]], on="article_id", how="left")
    merged["date"] = pd.to_datetime(merged["published_at"]).dt.date

    out = (
        merged.groupby("date", as_index=False)["unclassified"]
        .mean()
        .rename(columns={"unclassified": "unclassified_rate"})
        .sort_values("date")
    )
    return out



def build_known_theme_timeseries(assignments_df: pd.DataFrame, articles_df: pd.DataFrame) -> pd.DataFrame:
    merged = assignments_df.merge(articles_df[["article_id", "published_at"]], on="article_id", how="left")
    exploded = merged.explode("theme_ids")
    exploded = exploded[exploded["theme_ids"].notna() & (exploded["theme_ids"] != "")].copy()
    if exploded.empty:
        return pd.DataFrame(columns=["date", "theme_id", "article_count"])

    exploded["date"] = pd.to_datetime(exploded["published_at"]).dt.date

    return (
        exploded.groupby(["date", "theme_ids"], as_index=False)["article_id"]
        .nunique()
        .rename(columns={"theme_ids": "theme_id", "article_id": "article_count"})
        .sort_values(["date", "theme_id"])
    )



def build_residual_topic_counts(residual_topics_df: pd.DataFrame, articles_df: pd.DataFrame) -> pd.DataFrame:
    if residual_topics_df.empty:
        return pd.DataFrame(columns=["date", "topic_count"])

    merged = residual_topics_df.merge(articles_df[["article_id", "published_at"]], on="article_id", how="left")
    merged = merged[merged["topic_id"] != -1].copy()
    if merged.empty:
        return pd.DataFrame(columns=["date", "topic_count"])

    merged["date"] = pd.to_datetime(merged["published_at"]).dt.date

    return (
        merged.groupby("date", as_index=False)["topic_id"]
        .nunique()
        .rename(columns={"topic_id": "topic_count"})
        .sort_values("date")
    )



def build_outlier_weekly_counts(outliers_df: pd.DataFrame) -> pd.DataFrame:
    if outliers_df.empty:
        return pd.DataFrame(columns=["week_start", "outlier_count"])

    work = outliers_df.copy()
    work["week_start"] = pd.to_datetime(work["published_at"]).dt.to_period("W").apply(lambda p: p.start_time)

    return (
        work.groupby("week_start", as_index=False)["article_id"]
        .nunique()
        .rename(columns={"article_id": "outlier_count"})
        .sort_values("week_start")
    )



def build_outlier_recluster_timeseries(recluster_df: pd.DataFrame) -> pd.DataFrame:
    if recluster_df.empty:
        return pd.DataFrame(columns=["processing_week", "topic_count"])

    work = recluster_df[recluster_df["recluster_topic_id"] != -1].copy()
    if work.empty:
        return pd.DataFrame(columns=["processing_week", "topic_count"])

    return (
        work.groupby("processing_week", as_index=False)["recluster_topic_id"]
        .nunique()
        .rename(columns={"recluster_topic_id": "topic_count"})
        .sort_values("processing_week")
    )



def plot_known_theme_timeseries(df: pd.DataFrame, output_path) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    if not df.empty:
        for theme_id, group in df.groupby("theme_id"):
            ax.plot(group["date"], group["article_count"], marker="o", label=str(theme_id))
        ax.legend(loc="best")
    ax.set_title("既知テーマ別件数の時系列")
    ax.set_xlabel("date")
    ax.set_ylabel("article_count")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)



def plot_unclassified_rate(df: pd.DataFrame, output_path) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    if not df.empty:
        ax.plot(df["date"], df["unclassified_rate"], marker="o")
    ax.set_title("未分類率の時系列")
    ax.set_xlabel("date")
    ax.set_ylabel("unclassified_rate")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)



def plot_residual_topic_timeseries(df: pd.DataFrame, output_path) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    if not df.empty:
        ax.plot(df["date"], df["topic_count"], marker="o")
    ax.set_title("residual topic 件数の時系列")
    ax.set_xlabel("date")
    ax.set_ylabel("topic_count")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)



def plot_outlier_recluster_timeseries(df: pd.DataFrame, output_path) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    if not df.empty:
        ax.plot(df["processing_week"], df["topic_count"], marker="o")
    ax.set_title("outlier 再クラスタリング後のテーマ件数の時系列")
    ax.set_xlabel("processing_week")
    ax.set_ylabel("topic_count")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)



def plot_outlier_count_by_week(df: pd.DataFrame, output_path) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    if not df.empty:
        ax.bar(df["week_start"].astype(str), df["outlier_count"])
        ax.tick_params(axis="x", rotation=45)
    ax.set_title("outlier 件数の週次推移")
    ax.set_xlabel("week_start")
    ax.set_ylabel("outlier_count")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
