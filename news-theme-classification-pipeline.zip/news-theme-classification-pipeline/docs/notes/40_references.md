# 参照文献・実装参考

## Sentence Transformers
- Sentence Transformers 公式サイト  
  URL: https://sbert.net/  
  用途: ライブラリ全体仕様、埋め込み生成の基礎確認

- Semantic Search Example  
  URL: https://sbert.net/examples/sentence_transformer/applications/semantic-search/README.html  
  用途: 正規化埋め込みとコサイン類似度計算の実装方針

- Clustering Example  
  URL: https://sbert.net/examples/sentence_transformer/applications/clustering/README.html  
  用途: 埋め込み空間でのクラスタリング活用の参考

## BERTopic
- BERTopic Documentation  
  URL: https://maartengr.github.io/BERTopic/index.html  
  用途: BERTopic の基本概念、fit/transform 仕様

- BERTopic API  
  URL: https://maartengr.github.io/BERTopic/api/bertopic.html  
  用途: `BERTopic` クラス引数、`get_topic_info` 等 API 参照

- Outlier Reduction  
  URL: https://maartengr.github.io/BERTopic/getting_started/outlier_reduction/outlier_reduction.html  
  用途: `reduce_outliers` のオプション実装方針

## SetFit
- SetFit Documentation  
  URL: https://huggingface.co/docs/setfit/index  
  用途: SetFit 全体仕様と将来移行の前提整理

- SetFit Multilabel How-to  
  URL: https://huggingface.co/docs/setfit/how_to/multilabel  
  用途: multilabel 学習時のデータ形式と設定確認

- SetFit Multilabel Notebook  
  URL: https://github.com/huggingface/setfit/blob/main/notebooks/text-classification_multilabel.ipynb  
  用途: 将来 notebook 化時の実装テンプレート参照

## multilabel 保存形式
- OneVsRestClassifier API  
  URL: https://scikit-learn.org/stable/modules/generated/sklearn.multiclass.OneVsRestClassifier.html  
  用途: 二値指標行列（wide）形式の一般的取り扱い確認

- Multiclass / Multilabel ユーザーガイド  
  URL: https://scikit-learn.org/stable/modules/multiclass.html  
  用途: multilabel データ表現（long/wide）整理の参考
