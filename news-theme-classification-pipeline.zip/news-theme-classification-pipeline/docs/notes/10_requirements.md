# 要求事項整理

## 目的
- 既知テーマの安定追跡
- 未知テーマ・新興テーマの発見

## 必須パイプライン
1. Sentence Transformers による記事 embedding
2. テーマ description との類似度による多ラベル付与
3. 未分類記事のみ BERTopic 実行
4. BERTopic outlier の別保存と週次再クラスタリング
5. SetFit 移行用ラベルストア保存

## 入力仕様
- CSV を標準入力
- 必須カラム: `article_id`, `published_at`, `source`, `title`, `summary`, `body`, `url`
- embedding 用本文: `title + "\n" + summary + "\n" + body_short`

## テーマ定義仕様
- YAML/JSON 対応
- 必須項目: `theme_id`, `name_ja`, `description`, `threshold`

## 保存要件
- `data/processed/article_embeddings.parquet`
- `data/processed/theme_embeddings.parquet`
- `outputs/tables/article_theme_scores.parquet`
- `outputs/tables/article_theme_assignments.parquet`
- `outputs/tables/residual_topics.parquet`
- `outputs/tables/residual_topic_keywords.parquet`
- `outputs/tables/residual_topic_representative_docs.parquet`
- `outputs/tables/residual_outliers.parquet`
- `outputs/tables/outlier_weekly_recluster_topics.parquet`
- `outputs/figures/outlier_topic_count_by_week.png`
- `data/processed/labels_long.parquet`
- `data/processed/labels_wide.parquet`

## config 必須項目
- `EMBEDDING_MODEL_NAME`
- `THEME_DEF_PATH`
- `SIMILARITY_TOP_K`
- `DEFAULT_THRESHOLD`
- `USE_THEME_SPECIFIC_THRESHOLD`
- `BERTOPIC_MIN_TOPIC_SIZE`
- `BERTOPIC_NR_TOP_WORDS`
- `BERTOPIC_USE_REDUCE_OUTLIERS`
- `OUTLIER_RECLUSTER_MODE`
- `OUTLIER_RECLUSTER_LOOKBACK_WEEKS`
- `MIN_HIGH_CONFIDENCE_FOR_PSEUDO_LABEL`

## ノートブック要件
- `notebooks/main.ipynb` で end-to-end 実行
- 指定 16 セル構成

## 受け入れ条件
1. notebook 単体で一連実行可能
2. 類似度による多ラベル付与
3. residual のみ BERTopic 入力
4. outlier 別保存
5. outlier 週次再クラスタリング
6. SetFit 用 long/wide 保存
7. 結果を `outputs/` に保存
8. README と references に引用元整理
