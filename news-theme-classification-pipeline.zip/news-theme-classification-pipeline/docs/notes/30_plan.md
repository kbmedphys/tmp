# 実装・検証・拡張計画

## 実装順序
1. README と docs/notes を整備
2. `src/news_theme_pipeline` 最小モジュール実装
3. `data/raw` にサンプル入力 CSV とテーマ YAML を配置
4. `notebooks/main.ipynb` に 16 セルの実行フロー実装
5. 保存先ディレクトリへの出力を確認

## テスト順序
1. 入力検証テスト（必須カラム不足時に失敗）
2. 前処理テスト（`text_for_embedding` 生成確認）
3. embedding キャッシュ再利用テスト（再計算回避）
4. 類似度多ラベル付与テスト（`unclassified` 判定含む）
5. BERTopic residual 限定テスト
6. outlier 別保存テスト
7. 週次再クラスタリングの `rolling_4w` / `cumulative` 両モード確認
8. labels long/wide 保存確認
9. 図表・Parquet 出力存在確認

## 将来拡張
- manual ラベル UI/運用フロー追加
- BERTopic topic を既知テーマへ昇格する半自動ルール追加
- SetFit 学習 notebook (`notebooks/setfit_train.ipynb`) 追加
- テーマ定義のバージョニング運用
- 推論バッチのスケジューラ化
