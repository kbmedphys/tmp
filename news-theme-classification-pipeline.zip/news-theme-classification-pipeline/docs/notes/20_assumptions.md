# 前提・仮定

## データ形式
- 入力は UTF-8 CSV を想定
- `published_at` は pandas で datetime へ変換可能な形式を想定
- `summary` は欠損を許容し、空文字補完する

## 言語
- ニュース本文は日本語中心だが英語混在を許容
- 埋め込みモデルは多言語モデルを初期値に採用

## embedding モデル
- 初期値: `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`
- `normalize_embeddings=True` を前提にコサイン類似度を内積で計算

## threshold 初期値
- 全体既定値: `0.42`
- テーマごとに `threshold` を上書き可能
- 高信頼疑似ラベルの既定閾値: `0.60`

## BERTopic 設定仮定
- `min_topic_size=2`（サンプルデータでもクラスタが出る値）
- `nr_top_words=8`
- outlier 削減は既定 OFF（必要時にフラグで ON）

## 週次再クラスタリング仮定
- 週次は `published_at` を基準に Monday start の週バケット
- モードは `rolling_4w` / `cumulative` を切替
- `rolling_4w` の窓幅は `OUTLIER_RECLUSTER_LOOKBACK_WEEKS` で可変
