# Project Rules: news-theme-classification-pipeline

このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。
このプロジェクトの Prefer explicit python path は 
- envs/nlp/.venv/bin/python

---
# 最優先
このファイルは workspace/AGENTS.md に次ぐ優先度で適用される。
最初に必ず workspace/AGENTS.md を読み、すべて遵守すること。

このプロジェクトで使う Python は明示パスで統一すること。
- envs/nlp/.venv/bin/python

追加パッケージが必要なら pip install は使わず、envs/nlp/ 配下で uv add を提案すること。
既存ファイルは破壊的変更を避けること。
出力物は outputs/ 配下へ保存すること。
説明・コメント・ドキュメントは日本語で記述すること。

# プロジェクト目的
大量のニュース記事を対象に、以下の 5 段階パイプラインを実装する。

1. Sentence Transformers で記事 embedding を作る
2. テーマ説明文との類似度で多ラベル付与する
3. 閾値未満の記事のみ BERTopic に流して新規テーマ候補を抽出する
4. BERTopic の outlier は別バケットとして保持し、週次で再クラスタリングする
5. 十分なラベル付きデータが蓄積したら SetFit の multilabel 分類器へ移行可能な形にする

目的は、
- 既知テーマの安定追跡
- 未知テーマ・新興テーマの発見
を両立すること。

# 実装スコープ
1つの notebook で end-to-end 実行可能な最小構成を実装すること。
実行主体は notebooks/main.ipynb に置くこと。

必要に応じて以下の最小モジュール分割を行ってよい。
- src/news_theme_pipeline/config.py
- src/news_theme_pipeline/io.py
- src/news_theme_pipeline/preprocess.py
- src/news_theme_pipeline/embed.py
- src/news_theme_pipeline/theme_assign.py
- src/news_theme_pipeline/topic_model.py
- src/news_theme_pipeline/label_store.py
- src/news_theme_pipeline/reporting.py

# 推奨ディレクトリ構成
projects/news-theme-classification-pipeline/
├─ AGENTS.md
├─ README.md
├─ docs/
│  ├─ notes/
│  │  ├─ 00_doc_index.md
│  │  ├─ 10_requirements.md
│  │  ├─ 20_assumptions.md
│  │  ├─ 30_plan.md
│  │  └─ 40_references.md
├─ notebooks/
│  └─ main.ipynb
├─ src/
│  └─ news_theme_pipeline/
│     ├─ __init__.py
│     ├─ config.py
│     ├─ io.py
│     ├─ preprocess.py
│     ├─ embed.py
│     ├─ theme_assign.py
│     ├─ topic_model.py
│     ├─ label_store.py
│     └─ reporting.py
├─ data/
│  ├─ raw/
│  └─ processed/
└─ outputs/
   ├─ figures/
   ├─ tables/
   └─ logs/

# 入力データ仕様
まずは CSV を標準入力とする。
最低限、以下のカラムを想定すること。
- article_id
- published_at
- source
- title
- summary
- body
- url

記事テキストは以下の優先順位で embedding 用に構築すること。
text_for_embedding =
    title
    + "\n"
    + summary (存在すれば)
    + "\n"
    + body_short (body が長すぎる場合は適切に切る)

タイトル単独ではなく、少なくとも title + summary を使うこと。

# テーマ定義ファイル
既知テーマは YAML または JSON で定義すること。
必須フィールド:
- theme_id
- name_ja
- description
- threshold

description の embedding をテーマプロトタイプとして使うこと。

サンプルテーマ定義ファイルも作成すること。例えば以下のような形式を採用せよ。

themes:
  - theme_id: ai
    name_ja: AI
    description: >
      生成AI、LLM、推論需要、学習需要、GPU、AI半導体、AIサーバー、
      データセンター、電力需要増加、AIソフトウェア普及に関する話題
    threshold: 0.42

  - theme_id: semiconductors
    name_ja: 半導体
    description: >
      半導体製造、ロジック、メモリ、GPU、半導体製造装置、EUV、
      ファウンドリ、先端パッケージングに関する話題
    threshold: 0.45

# 実装要件 1: 記事 embedding
- Sentence Transformers を利用して記事 embedding を生成すること
- embedding モデル名は config で切替可能にすること
- embedding 結果は再利用のためキャッシュ保存すること
- normalize_embeddings=True 相当を基本とし、コサイン類似度計算を簡潔にすること
- 同一記事の再計算を避けること

保存物:
- data/processed/article_embeddings.parquet
- data/processed/theme_embeddings.parquet

# 実装要件 2: 類似度による多ラベル付与
各記事 embedding と各テーマ description embedding のコサイン類似度を計算し、
テーマごとの threshold を超えたものをその記事のラベルとすること。

必須仕様:
- 多ラベル付与を前提とする
- テーマごとに threshold を持てる
- 類似度スコアを保存する
- どのテーマにも閾値未満なら unclassified=True とする

保存物:
- outputs/tables/article_theme_scores.parquet
- outputs/tables/article_theme_assignments.parquet

article_theme_assignments の最低限カラム:
- article_id
- theme_ids
- max_similarity
- unclassified
- assigned_by

assigned_by は少なくとも以下を取りうること。
- similarity
- bertopic
- manual

# 実装要件 3: BERTopic による residual clustering
類似度ベースで unclassified=True になった記事のみを BERTopic に流すこと。

要件:
- BERTopic を使う
- 入力は residual 記事のみ
- topic ごとに代表語・代表記事を出す
- topic 情報を表形式で保存する
- 文書が -1 topic になった場合は outlier として保存する

保存物:
- outputs/tables/residual_topics.parquet
- outputs/tables/residual_topic_keywords.parquet
- outputs/tables/residual_topic_representative_docs.parquet
- outputs/tables/residual_outliers.parquet

まずは outlier をすぐ再割当せず、別バケットとして保持することを優先する。
ただし将来オプションとして reduce_outliers を試せるよう、フラグで ON/OFF できるようにすること。

# 実装要件 4: outlier の週次再クラスタリング
outlier は破棄せず保持し、週次で再クラスタリング可能にすること。

仕様:
- published_at を基準に週次バケットを作る
- 各週について、その週までの累積 outlier または直近 N 週 outlier を対象に再クラスタリングできるようにする
- 再クラスタリング設定は config で切替可能にすること

最低限のモード:
- weekly_mode="rolling_4w"
- weekly_mode="cumulative"

保存物:
- outputs/tables/outlier_weekly_recluster_topics.parquet
- outputs/figures/outlier_topic_count_by_week.png

# 実装要件 5: SetFit 移行のためのラベルストア
将来の SetFit multilabel 学習のため、教師データを保存すること。

形式A: long format
- article_id
- text
- theme_id
- label
- label_source
- created_at

label_source は少なくとも以下を取りうること。
- manual
- similarity_high_conf
- bertopic_promoted

形式B: indicator matrix 相当
- article_id
- text
- 各テーマ列が 0/1

保存物:
- data/processed/labels_long.parquet
- data/processed/labels_wide.parquet

必須仕様:
- 類似度が高い自動付与結果を暫定教師ラベルとして保存できる
- BERTopic クラスタに対し人手でテーマ名を付与した後、その結果を教師データへ昇格できる
- 将来的に SetFit notebook を追加するだけで学習に入れるようにしておくこと

# config で切り替え可能にする項目
最低限、以下を config に持たせること。
- EMBEDDING_MODEL_NAME
- THEME_DEF_PATH
- SIMILARITY_TOP_K
- DEFAULT_THRESHOLD
- USE_THEME_SPECIFIC_THRESHOLD
- BERTOPIC_MIN_TOPIC_SIZE
- BERTOPIC_NR_TOP_WORDS
- BERTOPIC_USE_REDUCE_OUTLIERS
- OUTLIER_RECLUSTER_MODE
- OUTLIER_RECLUSTER_LOOKBACK_WEEKS
- MIN_HIGH_CONFIDENCE_FOR_PSEUDO_LABEL

# Notebook 構成
notebooks/main.ipynb は少なくとも以下のセル構成にすること。
1. 環境確認・import
2. config 読み込み
3. 入力ニュース読み込み
4. 前処理
5. 記事 embedding 生成
6. テーマ embedding 生成
7. 類似度計算
8. 多ラベル付与
9. residual 抽出
10. BERTopic 実行
11. outlier 保存
12. 週次再クラスタリング
13. 結果統合
14. 教師データ保存
15. 可視化
16. まとめと次ステップ

# 可視化要件
最低限、以下の図表を出すこと。

表:
- テーマ別記事件数
- 未分類率
- BERTopic で抽出された topic 一覧
- outlier 件数の週次推移

図:
- 既知テーマ別件数の時系列
- 未分類率の時系列
- residual topic 件数の時系列
- outlier 再クラスタリング後のテーマ件数の時系列

出力先:
- outputs/figures/
- outputs/tables/

# README に記載すべき内容
- 目的
- 実装パイプラインの概要
- 入力データ仕様
- テーマ定義ファイル仕様
- 実行手順
- 生成物一覧
- SetFit への将来移行方針
- 参照文献一覧

# docs/notes に記載すべき内容
docs/notes/10_requirements.md
- 本指示書の要求事項を整理

docs/notes/20_assumptions.md
- ニュースデータ形式
- 言語
- embedding モデル
- threshold 初期値
- BERTopic 設定の仮定

docs/notes/30_plan.md
- 実装順序
- テスト順序
- 将来拡張

docs/notes/40_references.md
- 参照文献・実装参考元を、タイトル・URL・何に使ったか付きで整理すること

# 受け入れ条件
以下をすべて満たしたら完了。
1. main.ipynb だけで一通り実行できる
2. 既知テーマ description との類似度で多ラベル付与できる
3. 未分類記事だけ BERTopic に流せる
4. BERTopic outlier を別保存できる
5. outlier の週次再クラスタリングができる
6. SetFit 用教師データを long / wide 形式で保存できる
7. 結果が outputs/ に保存される
8. README と docs/notes/40_references.md に引用元が整理されている

# 実装上の注意
- テーマ付与は単一ラベルではなく多ラベル前提とすること
- どれかに無理やり入れる設計にしないこと
- residual / outlier を重要な信号候補として残すこと
- 後で教師あり学習へ移行しやすいよう、ラベル保存形式を整えること
- 閾値やトピック設定はハードコードせず config 管理すること
- ノートブックでも再現性を保つため、乱数シードを固定すること

# 具体的な作業順序
1. workspace/AGENTS.md を読み、遵守事項を整理する
2. README.md と docs/notes/ 一式を先に作る
3. src/news_theme_pipeline/ に最小限のモジュールを実装する
4. notebooks/main.ipynb に end-to-end 実行フローを実装する
5. サンプルテーマ定義ファイルを作る
6. サンプル入力データを想定して動作確認可能な形にする
7. outputs/ に結果を書き出す
8. docs/notes/40_references.md に引用元を整理する
9. 最後に、人手でどこをチューニングすべきかを README に明記する

# 参照元として必ず docs/notes/40_references.md に残すこと
Sentence Transformers:
- https://sbert.net/
- https://sbert.net/examples/sentence_transformer/applications/semantic-search/README.html
- https://sbert.net/examples/sentence_transformer/applications/clustering/README.html

BERTopic:
- https://maartengr.github.io/BERTopic/index.html
- https://maartengr.github.io/BERTopic/api/bertopic.html
- https://maartengr.github.io/BERTopic/getting_started/outlier_reduction/outlier_reduction.html

SetFit:
- https://huggingface.co/docs/setfit/index
- https://huggingface.co/docs/setfit/how_to/multilabel
- https://github.com/huggingface/setfit/blob/main/notebooks/text-classification_multilabel.ipynb

multilabel 保存形式:
- https://scikit-learn.org/stable/modules/generated/sklearn.multiclass.OneVsRestClassifier.html
- https://scikit-learn.org/stable/modules/multiclass.html

# 最終成果物
以下を作成すること。
- README.md
- docs/notes/00_doc_index.md
- docs/notes/10_requirements.md
- docs/notes/20_assumptions.md
- docs/notes/30_plan.md
- docs/notes/40_references.md
- src/news_theme_pipeline/*.py
- notebooks/main.ipynb

実装を開始せよ。