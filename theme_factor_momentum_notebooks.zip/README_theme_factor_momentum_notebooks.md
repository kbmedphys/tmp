# Barra-purified Theme Factor Momentum Notebooks

## 生成物

- `00_mimicking_portfolio_diagnostics.ipynb`: 純化テーマファクターリターンを個別銘柄ロングショートで複製できるかを確認するノートブック。
- `01_binary_tsfm_12m.ipynb`: Ehsani-Linnainmaa型の過去12カ月 sign TSFM。
- `02_vol_scaled_tsfm.ipynb`: sign TSFMをテーマファクター・ボラティリティでスケール。
- `03_continuous_tsfm_gupta_kelly.ipynb`: Gupta-Kelly式(1)の連続スケーリングTSFM。複数形成窓を比較。
- `04_high_eigenvalue_pc_tsfm.ipynb`: 高固有値PCテーマファクターに対するTSFM。
- `05_momentum_neutral_tsfm.ipynb`: Barraに加えて個別株過去リターンにも直交化したmomentum-neutral TSFM。
- `06_csfm_benchmark.ipynb`: CSFMベンチマーク。文献上は主戦略ではなく比較対象。
- `07_long_only_theme_overlay_non_literature_extension.ipynb`: ロングオンリー制約用の非文献コア拡張。純化ファクター・ロングショートとは別物。

## 実データ用の推奨pickleスキーマ

各ノートブックは、カレントディレクトリから `data/theme_factor_inputs.pkl` を探します。存在しない場合は合成データで実行されます。

pickleは以下のdictを想定します。

```python
{
    "stock_returns": pd.DataFrame,              # index: monthly dates, columns: security_id, values: returns
    "barra_exposures_by_date": dict,            # {pd.Timestamp: DataFrame(index=security_id, columns=Barra factors)}
    "theme_exposures_by_date": dict,            # {pd.Timestamp: DataFrame(index=security_id, columns=theme_id)}
    "cash_returns": pd.Series,                  # optional
    "metadata": dict                            # optional
}
```

`theme_exposures_by_date` は raw theme basket weights または raw theme characteristic exposure です。ノートブック内でBarra純化されます。

## 注意

文献準拠の主実装は、純化テーマファクターのロングショートです。ロングオンリー版は実務制約用の拡張であり、文献の中心戦略とは分けて評価してください。