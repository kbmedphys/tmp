"""入出力とスキーマ検証。"""

from __future__ import annotations

from pathlib import Path

import pandas as pd


THEME_REQUIRED_COLUMNS = [
    "theme_id",
    "theme_name",
    "theme_description",
    "positive_drivers",
    "negative_drivers",
    "related_keywords",
    "excluded_keywords",
    "constituent_names",
    "constituent_descriptions",
    "gics_industries",
    "trbc_industries",
]


HOLDINGS_REQUIRED_COLUMNS = ["date", "theme_id", "ticker", "weight"]
PRICES_REQUIRED_COLUMNS = ["date", "ticker", "close"]



def _load_table(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {path}")
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path)
    if suffix == ".csv":
        return pd.read_csv(path)
    raise ValueError(f"未対応の入力形式です: {path}")



def load_theme_definitions(path: Path) -> pd.DataFrame:
    df = _load_table(path)
    missing = sorted(set(THEME_REQUIRED_COLUMNS) - set(df.columns))
    if missing:
        raise ValueError(f"theme_definitions の必須カラム不足: {missing}")
    out = df.copy()
    for col in THEME_REQUIRED_COLUMNS:
        out[col] = out[col].fillna("").astype(str)
    return out



def load_theme_holdings(path: Path) -> pd.DataFrame:
    df = _load_table(path)
    missing = sorted(set(HOLDINGS_REQUIRED_COLUMNS) - set(df.columns))
    if missing:
        raise ValueError(f"theme_holdings の必須カラム不足: {missing}")
    out = df.copy()
    out["date"] = pd.to_datetime(out["date"], errors="coerce").dt.normalize()
    if out["date"].isna().any():
        raise ValueError("theme_holdings.date に datetime 変換不可の値があります。")
    out["theme_id"] = out["theme_id"].astype(str)
    out["ticker"] = out["ticker"].astype(str)
    out["weight"] = pd.to_numeric(out["weight"], errors="coerce")
    if out["weight"].isna().any():
        raise ValueError("theme_holdings.weight に数値変換不可の値があります。")
    return out



def load_prices(path: Path) -> pd.DataFrame:
    df = _load_table(path)
    missing = sorted(set(PRICES_REQUIRED_COLUMNS) - set(df.columns))
    if missing:
        raise ValueError(f"prices の必須カラム不足: {missing}")
    out = df.copy()
    out["date"] = pd.to_datetime(out["date"], errors="coerce").dt.normalize()
    if out["date"].isna().any():
        raise ValueError("prices.date に datetime 変換不可の値があります。")
    out["ticker"] = out["ticker"].astype(str)
    out["close"] = pd.to_numeric(out["close"], errors="coerce")
    if out["close"].isna().any():
        raise ValueError("prices.close に数値変換不可の値があります。")
    if "turnover" in out.columns:
        out["turnover"] = pd.to_numeric(out["turnover"], errors="coerce")
    return out



def load_market_turnover(path: Path | None) -> pd.DataFrame:
    if path is None:
        return pd.DataFrame(columns=["date", "market_turnover"])
    df = _load_table(path)
    required = ["date", "market_turnover"]
    missing = sorted(set(required) - set(df.columns))
    if missing:
        raise ValueError(f"market_turnover の必須カラム不足: {missing}")
    out = df.copy()
    out["date"] = pd.to_datetime(out["date"], errors="coerce").dt.normalize()
    out["market_turnover"] = pd.to_numeric(out["market_turnover"], errors="coerce")
    return out



def save_parquet(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)



def save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
