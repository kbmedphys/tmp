# PA：四半期末＋2か月で選定・次の3か月を保有

最新版の統合main.ipynbに、合意したPA選定日程を追加しました。
例：6月までのマクロ→8月末選定→9〜11月保有。選定対象は3か月固定し、同じ目標ウェイトへ月次リバランスします。
BB・FT/PT・NewsOnly、月次C案、Economic Trend、既存net wealthは維持しています。

## 実行
ZIPは新しい空のフォルダへ展開し、main.ipynbをカーネル再起動後に全セル実行してください。
必要な環境・依存は元版と同じです。新しいパッケージや外部Pythonファイルは不要。
依存追加が必要な場合は既存uv環境で `uv add numpy pandas scipy statsmodels matplotlib ipykernel`。
入力の更新は元版と同じ provider/canonical_csv および assets_monthly.csv を使います。

## 変更を見る場所
- **22節**：新しいPA選定日程、目的変数、学習締切、バックテストとレポート。
- **outputs/latest/pressure_assets_2m/report.html**：新日程の主レポート。
- 19E/pressure_assets/ は従来3か月待ちPAの比較用として維持。
- 月次C案・Economic Trendの選定日程は今回変更しません。

## 公表カレンダーがない場合
新たに inputs/pa_release_calendar.csv と inputs/pa_trade_calendar.csv を追加しました。
どちらも空のテンプレートで、実際の公表日や取引日を捏造していません。
主系統は公表確認必須です。未登録・既知の遅延・不足期はEQWへ戻し、評価期間を削除しません。
そのため、空の公表カレンダーでは主系統はEQWのみになります。
別に「未確認の公表日は2か月後までに間に合った」と仮定する研究系統を計算します。
研究版のリターンを実行可能な厳密バックテストとして解釈しないでください。

## 公表日時の登録
pa_release_calendar.csv の列：source_quarter,input_group,available_at,source,notes。
input_group は cpi / wages_hours_headcounts / labor_market / gdp / expectations / shortage。
必要入力を全て確認した時点をまとめる場合だけ all_required_inputs を使用できます。
日時はISO形式で時刻・タイムゾーン付き推奨。日付だけなら翌日00:00と保守的に解釈します。
登録日時が判断締切より後なら、仮定研究版でも当該期をブロックします。

pa_trade_calendar.csv の列：decision_month,selection_cutoff_at,execution_at。
各月の正しい市場最終取引日のcutoffと組入れ境界を時刻付きで登録してください。
未登録時は最終平日00:00をcutoff、月末価格による組入れを近似します。
日本市場の祝日・正確な引け約定まで検証したものではありません。

## 学習の締切
目的変数は新しい保有窓で全て再生成します。
月末組入れ前に確定していない当月末終値を学習へ使わないため、学習ラベルは判断月より前に終了したものだけ。
2023Q2→8月末選定なら、2023Q1源泉の6〜8月ラベルを除外し、最新学習ラベルは2022Q4源泉の3〜5月です。
最低32四半期の拡大型学習・Top4・片道10bp等は元PAの初期条件を維持。

## 比較
1. two_month_confirmed：公表確認を要求する新しい主系統。
2. two_month_research：未確認日時を仮定する2か月ラグ研究版。
3. three_month_preclose_research：同じ学習締切での3か月ラグ比較。
4. original_3m_legacy：以前のPA結果を一切変更せず表示。

旧版は学習締切が異なるため、旧版との差の全てを日程の効果とは呼びません。
また、新版は最後の保有窓が未完了でも観測済み月だけ損益を計上するので、同じ期間の比較表を参照してください。

## 重要な留保
公表日時を登録しても最新CSVの過去改定を取り除けません。GDPの1次速報を使った数値の再現を保証しません。
真の時点検証には当時利用できた値と、実商品価格・約定条件が必要です。production_eligible=Falseを維持します。

詳細は PA_TWO_MONTH_SCHEDULE_ja.md、検証結果は PA_TWO_MONTH_VALIDATION_ja.md。
実行用ZIPは必要な前回比較状態を維持した軽量構成です。実行するとCSV・HTML・図・スナップショットが再生成され、容量は増えます。
