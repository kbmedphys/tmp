# BB品質ゲート除去：PA投資配分の比較

## 追加内容
23節で、BBレジームの品質がlowでも、元の正予測上位4資産を保有した場合を検証します。
主比較は停止条件だけのON/OFF。BB・予測・保有日程・費用・原始データを変えません。
全正予測を等ウェイトにする補助比較も保存。これは銘柄数ルールも変える別仕様です。

## 実行
新しい空の場所へZIPを展開し、main.ipynbのカーネルを再起動して全実行。
元の原CSV/Excel更新手順は同じです。追加ライブラリ不要、外部Pythonファイル不要。
必要な場合は既存uv環境で依存を追加します。

```bash
uv add numpy pandas scipy statsmodels matplotlib ipykernel
```

主結果は `outputs/latest/quality_gate_ablation/report.html`。
旧BB・月次C・Economic Trend・PA2か月版の出力も維持します。
追加設定は23節冒頭GA_CFG。比較を分離し、旧版の公表確認主系統を無断で書き換えません。

## 品質以外の条件
公表不可・学習不足・非有限予測・価格欠損は引き続き停止／EQW。
公表カレンダー未登録のtwo_month_confirmedはゲートを外してもEQWです。
収益比較は元から未登録日時を仮定するtwo_month_researchを使用。
正予測とは3か月EQW対比であり、絶対リターンのプラスや有意性ではありません。

## 主要ファイル
|ファイル|内容|
|---|---|
|performance_common_period.csv|ゲートON/OFF・全正予測の収益とリスク|
|decision_audit_gate_on_vs_off.csv|各回の旧理由・品質・新しい対象・正予測数|
|previously_blocked_episode_results.csv|旧EQW期間ごとの累積比較|
|monthly_gate_effects.csv|月次の差・グロスと費用の対数寄与|
|paired_block_uncertainty.csv|ペア再標本化の参考区間|
|transaction_cost_sensitivity.csv|片道0/10/25bp|
|net_wealth_primary.csv / relative_wealth_primary.csv|費用控除後の絶対・相対資産倍率|
|forecasts_used_UNCHANGED.csv|比較に用いた予測値・品質（未変更）|
|validation_checks.csv|新しい単体・回帰検査|

原版の入力仕様・処理はREADME_PA_TWOMONTH_BASELINE_ja.mdへ。
今回の数式と変更範囲はQUALITY_GATE_ABLATION_METHOD_ja.md。
実行結果と検査記録はQUALITY_GATE_ABLATION_VALIDATION_ja.md。

## 注意
提供ZIPは入力と最小限の前回状態を中心とする実行用です。全セル実行で結果を生成します。
出力・スナップショットは従来どおり増えるため、再実行後は容量が増えます。
最新ビンテージによる事後研究であり、取引承認や実運用推奨ではありません。
