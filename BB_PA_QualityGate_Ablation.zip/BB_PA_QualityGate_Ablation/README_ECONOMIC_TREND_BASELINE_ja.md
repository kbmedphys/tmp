# BB要因別 Economic Trend — 月次ローテーション

## 内容
既存のBB・FT/PT・月次C案の後段に、**要因への感応度 × 要因の経済トレンド**を使う月次資産選定を追加しました。
主は先1か月のEQW対比リターン、比較は先3か月です。両者とも毎月1ポートフォリオを選び、翌月リターンを会計します。
元の四半期BB、FT/PT、NewsOnly、レジーム、圧力感応度、月次Ridge・Top4は残します。
原論文やAQR・Macrosynergyの完成品を再現したものではなく、日本BB寄与へその思想を適用した研究実装です。

## 実行
ZIPを新しい空のフォルダへ展開し、`BB_Inflation_Economic_Trend/main.ipynb`をカーネル再起動後に全セル実行します。
Notebookの処理は1本に完結し、外部`.py`や他Notebookを実行・importしません。ネットワークからのデータ取得もありません。
既存uvプロジェクトで必要な依存を追加する場合：

```bash
uv add numpy pandas scipy statsmodels matplotlib ipykernel
```

追加のPythonパッケージや月次GDPは不要です。元の入力方式`provider`と`canonical_csv`をどちらも維持しています。
原CSV・Excelの更新、価格系列、Google完了月、月次公表カレンダーは従来と同じです。
`README_MONTHLY_BASELINE_ja.md`と`MONTHLY_METHOD_ja.md`も参照してください。

## 追加結果の場所
**`outputs/latest/economic_trend/report.html`**が総合レポートです。
四半期BB・FT/PT・圧力分析・従来の月次選定は、従来のフォルダに出力されます。
実行に必要な入力・参照値・前回比較の状態だけを同梱したZIPと、今回の結果ZIPを分けて提供しています。
実行用ZIPに閲覧用の`outputs/latest/`がなくても正常です。全セル実行後に作られます。

|ファイル|用途|
|---|---|
|exposure_maps_by_version.csv|四半期ごとの因子NewsOnly感応度・縮小・符号安定性|
|quarterly_fixed_trend_scales.csv|四半期固定のトレンドSD・使用終期|
|factor_trends_by_decision.csv|各判断月のP、N、D3、スケール済みトレンド|
|fixed_exposure_times_trend_scores.csv|各資産・要因のスコア内訳。期待リターンではない|
|quarterly_fixed_shared_coefficients.csv|先1・3か月の4共通係数、学習尺度|
|shared_model_training_audit.csv|各モデルの学習月数・終了済みラベル・品質許可月数|
|forecasts_1m_main_3m_comparison.csv|月次の将来リターン予測|
|forecast_factor_attribution.csv|予測への因子別寄与。実現リターンの因果分解ではない|
|monthly_selection_weights.csv|月次の目標比率・衛星比率・選定理由・品質|
|strategy_performance_common_period.csv|同じ評価期間でのコスト後成績|
|transaction_cost_sensitivity.csv|片道0/10/25bpの比較。費用に応じてスイッチ判断も再計算|
|factor_forward_support_diagnostic.csv|要因感応度バスケットの将来関係・時系列推論|
|strategy_block_bootstrap_intervals.csv|戦略実績の12か月ブロック再標本化|
|latest_primary_candidates.csv|最新主予測と、品質を反映した研究用目標ウェイト|
|observed_forecast_archive.csv|実行日時で記録した新戦略の予測履歴|
|production_gate.json|本番採用の未完了条件|
|unchanged_upstream_files.csv|追加前後で既存科学計算CSV/JSONが不変か|
|validation_checks.csv|追加処理の検査記録|

## 戦略の4層
### 1. 感応度の地図（四半期更新）
16セクターの同時12か月EQW対比リターンとBBの要因NewsOnlyの偏相関を、GDP成長ニュースで統制します。
要因はエネルギー・食品・供給不足・労働需給の4つ。Cost総合と内訳、laborとFT/PTを二重加算しません。
同時期の関係は翌月予測ではありません。12か月βを12で割って翌月βとする処理もありません。
標本数と期間による符号安定性で感応度を縮小し、共通の資産成分を取り除いて相対スコア化します。

### 2. Economic Trend（月次更新）
既存圧力PとNewsOnly N=P_m−P_(m−12)を維持。
比較として同位相3か月差 D3=P_m−P_(m−3)を加えます。N/D3は調査予想サプライズではありません。
経済的ゼロを維持して、四半期モデル終期までの固定SDで標準化し、±2SDで打切り。
商品市場50%、労働市場50%、商品内3等分という固定の信号配分です。

### 3. 将来リターンの共通係数（四半期更新）
各資産の過去時点の感応度×トレンドに対し、4つの非負・縮小付き共通係数を推定。
先1か月主、先3か月比較、NとD3を組み合わせる先1か月比較の3モデルを別々に推定します。
学習には当時のマップと当時のトレンド、終了済み目的変数のみを使います。最新マップで過去を上書きしません。
16資産×月数を独立したマクロ標本数とみなしたp値は計算しません。

### 4. ベンチマークからの傾斜（月次更新）
主はEQWを土台に上位4資産の衛星を混合。最大20%、信号・安定性・相殺・リスクでさらに縮小します。
正式HOLDは解除せずEQWへ戻します。取引コストを考慮し、小さなメンバー順位変化では入替えを抑えます。
1か月・3か月とも毎月1ポートフォリオを選択します。3か月分の損益を毎月加算しません。

## 初期設定
先頭セルの`ECONOMIC_TREND_CFG`に一元化しています。**文献の推奨値ではなく、収益を最適化して選んだものでもありません。**

|設定|既定|
|---|---:|
|感応度推定の最低四半期数|24|
|感応度の標本縮小|n/(n+24)|
|符号安定性|直近24四半期・終端4期除外との一致率0/0.5/1|
|トレンド尺度の最大履歴|120か月|
|トレンド打切り|±2SD|
|共通係数学習の最低履歴|36か月かつ12モデル版|
|共通係数の平均損失Ridge罰則|0.125|
|衛星配分上限|20%|
|衛星の資産数|4|
|予想年率アクティブTE上限|3%|
|成長ローディングの絶対上限|0.50pp / GDPニュース1SD（12か月関係のリスク指標）|
|月次共分散|直近60か月、対角への縮小25%|
|取引コスト|売買金額合計×片道10bp|
|戦略区間の参考bootstrap|12か月ブロック、999回|

24四半期でマップが始まり、その発行履歴を36か月以上集めて次段モデルを学習します。
この二段階のwarmupは、旧Ridgeの96か月1段階モデルとは別です。比較成績は全戦略が揃う共通期間で評価します。

## 比較戦略
- `et_news_1m`：主戦略。Nのトレンド、4共通係数、先1か月。
- `et_news_3m`：Nは同じ、先3か月を独立学習。
- `et_news_d3_1m`：NとD3を等加重した先1か月比較。
- `et_fixed_news`：将来係数を推定しない、感応度×Nの順位スコア比較。期待リターンではない。
- `ridge_1m_matched`：旧月次Ridge予測へ新しい衛星上限・リスク制限を適用。
- `legacy_monthly_1m/3m/quarterly_info_1m`：旧Top4選定規則を共通評価期間で再計算。
- `EQW`：同じコスト条件の月次リバランスEQW。

全て固定した比較です。結果が良かったモデルへ主仕様を自動的に切り替えません。

## 残る制約
原統計の過去公表ビンテージは復元していません。月次・四半期の利用可能日は元C案の公表カレンダーを使い、未入力なら従来のラグ仮定です。
最新原系列での疑似時点計算であり、真のリアルタイムOOSとは呼べません。研究で既に参照した期間は未使用holdoutでもありません。
四半期のGDP・期待を月次観測として補完しない代わりに、完全な月次歴史分解ではなく選択された経路の条件付き寄与です。
月末価格を観測し、同じ境界で取引する近似は元版のままです。実際の翌営業日・2営業日後発注には日次価格が必要です。
指数の配当・通貨・投資可能なETF／先物・約定費用は未確認です。全部production_eligible=Falseです。
経済トレンドが有効だという仮説を実装したのであって、超過収益を保証したり本番投入を承認したりしたものではありません。

## 保存・再実行
新モジュールの差分・観測履歴を追加保存します。旧BB・旧Ridge・月次C案の観測履歴は変更しません。
全検査を通過した場合だけ最新出力を更新します。再実行すると出力・スナップショットが増えます。
軽量版に残した前回比較用`outputs/`は継続に必要なので、全体を一括削除しないでください。

## 出所
- Bernanke & Blanchard (2024), PIIE WP24-11：符号付き動学寄与・識別範囲。
- Nakamura et al. (2024), BOJ WP24-E-1：FT/PTと相関する残差。
- AQR Alternative Thinking 2026 Issue 3, Inflation Redux?：pp.6–7の感応度、pp.15–16・21のEconomic Trend。
- Macrosynergy “Inflation as a trading signal” (2026) / “Macro trends and equity allocation” (2024)：情報時点と将来相対リターン検証。
詳細は`ECONOMIC_TREND_METHOD_ja.md`と実行結果内`method_contract.json`に記録しています。
