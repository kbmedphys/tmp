# テーマ選定手法調査

**User:**   
**Created:** 4/14/2026 20:18:28  
**Updated:** 4/14/2026 21:44:40  
**Exported:** 4/14/2026 21:45:00  
**Link:** [https://chatgpt.com/c/69de227b-d98c-83ab-bbcb-c94bd6aa175f](https://chatgpt.com/c/69de227b-d98c-83ab-bbcb-c94bd6aa175f)  

## Prompt:
2026/4/14 20:18:26

所与のテーマバスケットがあり、テーマの名前・おおまかな内容、構成銘柄は分かっている。日々のニュースデータをもとに、テーマ群の中から魅力的なテーマを目がトレンド的に選択したい。学術的・実務的に有力な手法を調査せよ。出典元は明記。

## Response:
2026/4/14 20:18:28

調査対象を、ニュースを使った「テーマ選択」にそのまま接続できる手法に絞って整理します。学術論文を軸に、実務で実装しやすい形まで落としていきます。

いまのところ、単なるニュース sentiment 単独よりも、  
「どのテーマに関するニュースか」をまず精度高く割り当て、その上で **量・加速度・センチメント・新規性・拡散** を別々に測る設計が有力です。  
次に、その根拠になる論文を拾っています。

> **検索：テーマ投資と資産価格設定に関する論文**
>
> [BERTopic - Advanced Transformer-Based Topic Modeling](https://bertopic.com/)
> [FinBERT: Financial Sentiment Analysis with Pre-trained Language Models](https://arxiv.org/abs/1908.10063)
> [Dynamic Topic Modeling - BERTopic](https://maartengr.github.io/BERTopic/getting_started/topicsovertime/topicsovertime.html)
> [Dynamic topic modelling for exploring the scientific literature ...](https://link.springer.com/article/10.1007/s41060-024-00610-0)
> [BERTopic – Advanced Transformer Topic Modeling](https://bertopic.org/)
> [FinBERT: Financial Sentiment Analysis with Pre-trained ...](https://www.researchgate.net/publication/335441873_FinBERT_Financial_Sentiment_Analysis_with_Pre-trained_Language_Models)
> [BERT-based Topic Modeling on New York Times ...](https://github.com/bengsoon/NYT_topic_modeling)
> [A Comparative Study of BERTopic and Dynamic Topic](https://epub.fh-joanneum.at/obvfhjoa/download/pdf/8942862)
> [Finbert: financial sentiment analysis with pre-trained ...](https://scispace.com/pdf/finbert-financial-sentiment-analysis-with-pre-trained-3v1apdk8ie.pdf)
> [ProsusAI/finbert](https://huggingface.co/ProsusAI/finbert)
> [BERTopic — BERTopic latest documentation](https://bertopic.readthedocs.io/)
> [FinBERT: Financial Sentiment Analysis with Pre-trained ...](https://www.semanticscholar.org/paper/FinBERT%3A-Financial-Sentiment-Analysis-with-Language-Araci/7102bb3fe73bd057ff161d9db5214a267c1ef312)
> [Evaluating Topic Modeling Approaches for News Analysis](https://dl.acm.org/doi/10.1145/3766918.3766974)
> [Dynamic Topic Modeling with BERTopic | by Sejal Dua](https://medium.com/data-science/dynamic-topic-modeling-with-bertopic-e5857e29f872)
> [PLTA-FinBERT: Pseudo-Label Generation-Based Test- ...](https://www.mdpi.com/2504-2289/10/2/59)
>
> **ニュースやテキスト要因による資産価格分析の検索**
>
> [Retail Investors' Contrarian Behavior Around News, ...](https://www.nber.org/system/files/working_papers/w34086/w34086.pdf)
> [On the Impact of Thematic ETFs on Index Investing](https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID4641347_code5078456.pdf?abstractid=4048988&mirid=1)
>
> **ETFテーママッピングと洗浄に関する文献検索**
>
> [Enhancing Asset Allocation and Portfolio Rebalancing ...](https://papers.ssrn.com/sol3/Delivery.cfm/6178158.pdf?abstractid=6178158&mirid=1)
> [A Close Look at Exchange-Traded Funds and Their Investors](https://www.ici.org/publication/a-close-look-at-exchangetraded-funds-and-their-investors-pdf)
> [Gender-themed financial products](https://sseinitiative.org/sites/sseinitiative/files/publications-files/sse-ifc-unw-gender-themed-products-inventory-2025.pdf)
> [Investigating Greenwashing in the US Equity ETF Market](https://www.researchgate.net/publication/390657334_Investigating_Greenwashing_in_the_US_Equity_ETF_Market)
> [“ETFs in 2025: Defining Market Themes and Innovation ...](https://www.msci.com/downloads/web/msci-com/indexes/markets-in-motion/trending-topics/etfs-in-2025-defining-market-themes-and-innovation-trends/ETFs%20in%202025%20Defining%20Market%20Themes%20and%20Innovation%20Trends.pdf)
> [RETAIL INVESTORS AND ETFs](https://www.theia.org/sites/default/files/2025-09/Retail%20Investors%20ETFs%20report_Final.pdf)
> [Thematic ETF report Q4 2025 - Asset Management](https://am.landg.com/asset/48f76b/globalassets/lgim/_document-library/capabilities/etfs/etf_thematics_q4_2025.pdf)
> [Trend Monitor 2025](https://www.afm.nl/~/profmedia/files/publicaties/2024/trendzicht-2025/trend-monitor-2025.pdf)
> [The Puzzle of ESG Fund Fees](https://sustainablefinancealliance.org/wp-content/uploads/2025/06/GRASFI_2025_paper_201.pdf)
> [Strengthening Portfolios: The ETF Advantage | BlackRock](https://www.blackrock.com/corporate/literature/whitepaper/strenghtening-portfolios-the-etf-advantage.pdf)
>
> **調査中の手法と文献**
>
> ユーザーが求めているのは強力な手法なので、クラシックなLDAや実際的なBERTopicを紹介するつもりです。ダイナミックトピック、ゼロショット学習、文書埋め込みについても考えています。弱い監視や財務テキストへの適用には、正確な出典が必要ですね。
>
> **Searching literature on dynamic topic modeling and methods**
>
> [Dynamic Topic Models](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf)
> [arXiv:1908.10084v1 [cs.CL] 27 Aug 2019](https://arxiv.org/pdf/1908.10084)
> [News Sentiment, Factor Models and Abnormal Stock Returns](https://www.ssrn.com/abstract%3D2695360)
> [News-based investor disagreement and stock returns](https://link.springer.com/article/10.1007/s11142-025-09897-1)
> [Dynamic topic models | Proceedings of the 23rd ...](https://dl.acm.org/doi/10.1145/1143844.1143859)
> [(PDF) Stock returns and investor sentiment: textual ...](https://www.researchgate.net/publication/335588022_Stock_returns_and_investor_sentiment_textual_analysis_and_social_media)
> [Sentence Embeddings using Siamese BERT-Networks, ...](https://github.com/AkihikoWatanabe/paper_notes/issues/462)
> [Textual Analysis of News and the Cross-section of Stock Returns](https://centaur.reading.ac.uk/102355/1/24881912_Tao_thesis.pdf)
> [トピックモデルの応用： 関係データ](https://www.ism.ac.jp/~daichi/lectures/H24-TopicModel/ISM-2012-TopicModels_day2_3_timeseries.pdf)
> [Sentence Embeddings using Siamese BERT-Networks](https://www.semanticscholar.org/paper/Sentence-BERT%3A-Sentence-Embeddings-using-Siamese-Reimers-Gurevych/93d63ec754f29fa22572615320afe0521f7ec66d)
> [1: Stock market forecasting under the Novelty-Narrative ...](https://www.elgaronline.com/abstract/book/9781035357604/chapter1.xml)
> [News-based investor disagreement and stock returns](https://ideas.repec.org/a/spr/reaccs/v30y2025i3d10.1007_s11142-025-09897-1.html)
> [Continuous Time Dynamic Topic Models](https://www.cs.columbia.edu/~blei/papers/WangBleiHeckerman2008a.pdf)
> [Sentence Embeddings using Siamese BERT-Networks](https://huggingface.co/papers/1908.10084)
> [Multifrequency News and Stock Returns](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=752019)
> [Stock Return Predictability based on Textual Sentiment ...](https://repec.org.br/repec/article/download/3111/1779)
>
> **調査中の情報源と制限事項**
>
> 短期的なニュースセンチメントの限界についての情報源が必要です。SSRN 2024を使うのも一つの方法ですが、注意点を示すために使うかも。また、LLM予測に関する情報源も探していますが、生産用途優先ではない点については言及を避けるべきかも。
>
> **Searching for event studies on news sentiment and returns**
>
> [News Diffusion in Social Networks and Stock Market ...](https://www.nber.org/system/files/working_papers/w30860/w30860.pdf)
> [Media reporting and asset pricing models](https://www.sciencedirect.com/science/article/pii/S037842662500216X?dgcid=rss_sd_all)
> [Media News and Cross Industry Information Diffusion](https://www.aeaweb.org/conference/2018/preliminary/paper/zz9sYG3Q)
> [Media Coverage and the Cross-Section of Stock Returns](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=971202&pos=4&rec=1&srcabs=1669724)
> [Attention and Underreaction-Related Anomalies - PubsOnLine](https://pubsonline.informs.org/doi/10.1287/mnsc.2022.4332)
> [Media Coverage and Sustainable Stock Returns: Evidence ...](https://www.mdpi.com/2071-1050/11/8/2335)
> [Institutional Investor Attention and Underreaction to News](https://academicweb.nd.edu/~zda/AIA.pdf)
> [Media Coverage and the Cost of Debt](https://www.jstor.org/stable/26887957)
> [Predicting Stock Market Returns Using Sentiment in ...](https://journals.sagepub.com/doi/10.1177/21582440251415069)
> [Media Coverage and the Cross-Section of Stock Returns](https://www.researchgate.net/publication/227360756_Media_Coverage_and_the_Cross-Section_of_Stock_Returns)
> [Does Industry Sentiment Explain Industry Returns?](https://www.efmaefm.org/0EFMAMEETINGS/EFMA%20ANNUAL%20MEETINGS/2025-Greece/Does_Industry_Sentiment_Explain_Industry_Returns_Thi%20Thuy%20Trang%20Truong.pdf)
> [1 Introduction](https://arxiv.org/html/1703.02715v6)
> [PRESS COVERAGE AND STOCK PRICE DEVIATION ...](https://www.hillsdaleinv.com/uploads/Press_Coverage_and_Stock_Price_Deviation_From_Fundamental_Value%2C_Chia-Wei_Chen%2C_Christos_Pantzalis%2C_Jung_Chul_Park.pdf)
> [No News Is News: Do Markets Underreact to Nothing?](https://www.ssrn.com/abstract%3D2139564)
> [Asset returns, news topics, and media effects* - Larsen](https://onlinelibrary.wiley.com/doi/full/10.1111/sjoe.12469)
> [Investor attention, information diffusion and industry returns](https://ideas.repec.org/a/eee/pacfin/v30y2014icp30-43.html)
> [Media Coverage and Investors' Attention to Earnings ...](https://www.fmg.ac.uk/sites/default/files/2020-08/J-Peress.pdf)
> [The Effect of News Senti- ment on Firms' Stock Market ...](https://www.nationalbanken.dk/media/iy4mmotm/working-paper-nr-141.pdf)
> [Ninety Years of Media Coverage and the Cross-Section of ...](https://www.cfr-cologne.de/download/kolloquium/2016/HillertUngeheuer.pdf)
>
> **調査中のテーマ投資と関連情報**
>
> テーマ投資における「テーマアテンションインデックス」について調べる必要があります。また、ニューストピックが資産リターンに与える予測的役割や、業界間の情報拡散についても調査しようと思います。テーマ投資バスケットの純度についての警告も考慮しつつ、関連する論文を探してみます。
>
> **Searching thematic fund underperformance and asset performance**
>
> [White Paper Thematic Investing](https://cpram.com/pdfDocuments/mkt/download/da25c04b-9b7e-4fb2-989d-2e67442f7165/White%20Paper%20%20Thematic%20Investing.pdf)
> [You're likely going to underperform with a thematic ETF](https://www.morningstar.com.au/etfs/chart-week-youre-likely-going-underperform-with-thematic-etf)
> [Thematic Concentration and Mutual Fund Performance](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1)
> [How to seek powerful themes in client portfolios - BlackRock](https://www.blackrock.com/us/financial-professionals/insights/seek-powerful-themes)
> [Thematic Investing: More Than Just a Good Story](https://www.alliancebernstein.com/content/dam/global/insights/insights-whitepapers/final_equ-8464.pdf)
> [Death by thematic investing](https://www.linkedin.com/pulse/death-thematic-investing-victor-cianni-frm)
> [Global Thematic Funds Landscape](https://www.investmentofficer.nl/sites/default/files/Global-Thematic-Funds-Landscape-May-2021.pdf)
> [thematic funds – profitable investment alternative for smart ...](https://www.researchgate.net/publication/384553449_THEMATIC_FUNDS_-_PROFITABLE_INVESTMENT_ALTERNATIVE_FOR_SMART_INVESTORS_IN_STOCK_MARKETS)
> [Thematics Meta Fund - Natixis](https://api-esb.im.natixis.com/adobe-aem-fund-explorer/api/files?did=a0R0J00000MsYhyUAF)
> [Evolving Thematic Landscapes and Megatrends in 2026](https://am.gs.com/en-hk/advisors/insights/article/investment-outlook/megatrends-thematic-investing-2026)
>
> **結果ページを開いて詳細を確認**
>
> 重要な参考文献を確認するために、いくつかの結果ページを開いて詳細を確認する必要があるかもしれません。そうすることで、必要な情報を確実に得られると思います。
>
> **重要な参照を確認するためにページを開く**
>
> [Which News Moves Stock Prices? A Textual Analysis | NBER](https://www.nber.org/papers/w18725)
> [dtm.dvi](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf)
> [BERTopic - Advanced Transformer-Based Topic Modeling](https://bertopic.com/)
> [arxiv.org](https://arxiv.org/pdf/1908.10084)
> [academicweb.nd.edu](https://academicweb.nd.edu/~zda/AIA.pdf)
> [Thematic Concentration and Mutual Fund Performance by John (Jianqiu) Bai, Yuehua Tang, Chi Wan, H. Zafer Yuksel :: SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1)
>
> **SSRNでテーマ集中の詳細を確認**
>
> SSRNにあるテーマ集中に関する詳細を調べて、必要な情報や関連部分を見つけることができるかもしれません。開いている資料の中で、関連する部分を探し直すのが良さそうです。
>
> **SSR内でのテーマ集中度の検索**
>
> [Thematic Concentration and Mutual Fund Performance by John (Jianqiu) Bai, Yuehua Tang, Chi Wan, H. Zafer Yuksel :: SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1)
>
> **検索結果の特定のフレーズを確認**
>
> 検索結果のスニペットから、特定のフレーズを探して確認しようと思います。それで、必要な情報がすぐに見つかるかもしれません。
>
> **検索結果からフレーズを抽出**
>
> [Thematic Concentration and Mutual Fund Performance](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1)
> [Thematic Investing: More Than Just A Good Story](https://seekingalpha.com/article/4726217-thematic-investing-more-than-just-good-story)
>
> **メディア効果とアセットの情報を確認**
>
> アセットに関する情報やメディア効果を確認するために、関連するウェブサイトや資料を開く必要があるかもしれません。検索結果をもう少し詳しく確認して、DOIから直接アクセスできる情報を探すの
>
> **検索：資産リターン、ニュース、メディア効果**
>
>
> **検索スニペットと他の情報源を利用**
>
> 検索スニペットから引用はできるけど、他のリソースを探すためにタイトル検索を試してみるのも良さそう。SSRNを使って情報を開く方法も考えています。新しい検索を始めて、最適な出典を探してみます。
>
> **検索中：論文「Asset returns, news topics, and media effects」**
>
> [Working Paper 17/2017: Asset returns, news topics, and media ...](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)
> [Asset returns, news topics, and media effects* - Larsen](https://onlinelibrary.wiley.com/doi/full/10.1111/sjoe.12469)
> [[PDF] Asset Returns, News Topics, and Media Effects](https://www.semanticscholar.org/paper/9f1db17b90c1713da792e254905dd5eb22bb3e84)
> [Asset returns, news topics, and media effects | Request PDF](https://www.researchgate.net/publication/356738240_Asset_returns_news_topics_and_media_effects)
> [Asset Returns, News Topics, and Media Effects](https://www.econstor.eu/handle/10419/210127?locale=de)
> [UNIVERSIDADE DO RIO GRANDE DO SUL FACULDADE DE ...](https://repositorioceme.ufrgs.br/bitstream/handle/10183/198031/001098954.pdf?isAllowed=y&sequence=1)
> [Time Variation in the News–Returns Relationship](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/01300E364B37863AC469C6D3FA85FBC8/S0022109023001369a.pdf/time_variation_in_the_newsreturns_relationship.pdf)
>
> **業界ごとのセンチメントと注目度の指標**
>
> テーマ別センチメントが業界ごとに変動する可能性について言及する必要がありそう。2025年は最良の年ではないかもしれませんが、業界ごとのセンチメントに関する最新の研究を引用したいですね。また、Google Trendsの注目度指標を用いるべきかもしれません。
>
> **調査：業界sentimentとGoogle Trends関連**
>
> [www.nber.org](https://www.nber.org/conferences/2009/mms09/Da_Engelberg_Gao.pdf)
>
> **多言語モデルの資料を探す**
>
> ユーザーが日本語を使っている可能性を考え、sentence-transformersの多言語モデルに関する実践的な資料が必要かもしれません。BERTopicが多言語モデルについて言及している情報もありますが、代わりに「paraphrase-multilingual-MiniLM-L12-v2」やSBERTの公式ラインが良いかも。
>
> **Searching multilingual Sentence-Transformers model documentation**
>
> [sentence-transformers/paraphrase-multilingual-MiniLM- ...](https://huggingface.co/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2)
> [Pretrained Models — Sentence Transformers documentation](https://www.sbert.net/docs/sentence_transformer/pretrained_models.html)
> [Semantic Textual Similarity](https://sbert.net/docs/sentence_transformer/usage/semantic_textual_similarity.html)
> [huggingface/sentence-transformers: State-of-the-Art Text ...](https://github.com/huggingface/sentence-transformers)
> [semantic similarity analysis using transformer-based ...](https://www.researchgate.net/publication/394616542_SEMANTIC_SIMILARITY_ANALYSIS_USING_TRANSFORMER-BASED_SENTENCE_EMBEDDINGS)
> [Multilingual Domain-Specific Sentence Transformers](https://blog.ml6.eu/multilingual-domain-specific-sentence-transformers-d34f071763d0)
> [sentence transformersで日本語を扱えるモデルのまとめ](https://tech.yellowback.net/posts/sentence-transformers-japanese-models)
> [Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks](https://arxiv.org/abs/1908.10084)
>
> **回答の構成と引用の方針**
>
> 今回は日本語で回答します。日付の正確な記載は必要ないかもしれませんが、混乱を避けるため触れた方が良い場合もあります。最小限のヘッダーと箇条書き、必要に応じて番号付きリストを使う形式で進めます。また、"芽がトレンド的"や"萌芽トレンド的"という表現は、出現したテーマのトレンドを追う意味として解釈できますね。それに基づいた内容で進めるつもりです。
>
> **テーマ注目の今後予測と関連理論**
>
> まず、テーマに対する注目を今後予測する方法として、ニュースの量、加速、広がりを追跡します。SBERTやBERTopicなどを活用した語彙やトピックを探索する方法も有効です。株式リターン予測やメディアの反響を関連付け、ディスアグリゲーション、テーマの汚染を注意深く扱う必要があります。
>
> 思考時間: 2m 6s

以下では、**「所与のテーマバスケットの中から、日々のニュースを使って魅力的なテーマをトレンド的に選ぶ」**という目的に絞って、学術的・実務的に有力な手法を整理します。結論から言うと、いちばん筋が良いのは、**(i) ニュースをまず各テーマへ高精度に割り当て、(ii) その後にニュース量・加速度・センチメント・新規性・拡散の遅さを別々の特徴量として作り、(iii) 最後にテーマ横断で順位付けする**やり方です。単純なポジネガ分類だけでテーマを選ぶ設計より、こちらのほうが文献的にも実務的にも強いです。[NBER+3NBER+3NBER+3](https://www.nber.org/papers/w26186)

まず結論
----

最有力なのは、次の3層構造です。

1.  **テーマ帰属層**  
    各ニュースを「どのテーマに属するか」に割り当てる。ここはキーワードだけでなく、**埋め込み類似度**と**構成銘柄ベースの帰属**を併用するのが有力です。Sentence-BERT系は大規模な意味類似検索やクラスタリングに向いており、動的な話題抽出には Dynamic Topic Model や BERTopic 系が実務上使いやすいです。[Hugging Face+3arXiv+3mimno.infosci.cornell.edu+3](https://arxiv.org/pdf/1908.10084)
2.  **ニュース特徴量層**  
    テーマごとに、**ニュース量、量の増加率、構成銘柄の何社に広がっているか、センチメント、ニュースの新規性、議論のばらつき、話題の持続性**を計算する。投資家注意やニュース拡散の遅さが価格形成に効くという文献は多く、ニュース量だけでなく「注意の立ち上がり」や「拡散の遅さ」を別シグナルとして持つのが理にかないます。[fmg.ac.uk+3NBER+3Academic Web Service+3](https://www.nber.org/conferences/2009/mms09/Da_Engelberg_Gao.pdf)
3.  **選択層**  
    最後に、テーマ横断でスコア化して上位テーマを選ぶ。ここは実務では、**単純な線形合成から始めて、十分な履歴が溜まったら教師あり学習へ移行**が堅いです。ニュースから直接「リターン予測に効くテキスト特徴」を学習する手法は学術的にも強く、一般的な sentiment 辞書より、目的変数に合わせた supervised text scoring のほうが有効とされています。[NBER+1](https://www.nber.org/papers/w26186)

有力な手法を、優先順位つきで整理すると
-------------------

### 1\. テーマ注意量インデックス型

最も実務導入しやすいのはこれです。各テーマに対して、そのテーマ名・説明文・構成銘柄を使ってニュースを紐付けし、日次で「そのテーマへの注意量」を作ります。特徴量は最低でも、**当日件数、5日増加率、20日比の異常件数、構成銘柄カバレッジ、ニュースソース数**を持たせるのがよいです。投資家注意は価格形成に影響し、Google検索量や Bloomberg 端末上のニュース閲覧量のような“直接的な注意指標”は、従来の間接指標と異なる情報を持つことが示されています。[NBER+1](https://www.nber.org/conferences/2009/mms09/Da_Engelberg_Gao.pdf)

この方法の強みは、**テーマ投資の実務にそのまま載せやすい**ことです。とくにテーマETFやテーマバスケットでは、「そのテーマに関する報道が増えたか」よりも、**テーマ内の複数銘柄に報道が広がっているか**のほうが重要です。1銘柄だけの材料は個別株ニュースであり、テーマの追い風とは限らないからです。ニュース拡散の遅さが価格の継続反応を生むという研究とも整合的です。[NBER+1](https://www.nber.org/system/files/working_papers/w30860/w30860.pdf)

### 2\. 埋め込み類似度 + 動的トピックモデル型

テーマ名が抽象的で、ニュース本文中にテーマ名そのものが出にくい場合は、**埋め込みによる意味マッチング**がかなり有効です。Sentence-BERT は意味的に近い文同士をベクトル空間で近く配置できるので、**ニュース本文 ↔ テーマ説明文 ↔ 構成銘柄の事業説明**を同じ空間で比較できます。さらに、Dynamic Topic Model は時系列で話題の遷移を追うモデルで、BERTopic は transformer embedding と c-TF-IDF を組み合わせて、短いニュースでも比較的扱いやすいのが実務上の利点です。[arXiv+2mimno.infosci.cornell.edu+2](https://arxiv.org/pdf/1908.10084)

この型は、**「AI」「電力インフラ」「肥満治療」のように、同じテーマでも表現が日々変わる**局面で強いです。単語辞書ベースだと、言い換えや派生表現に弱い一方、埋め込みベースならそこをかなり吸収できます。さらに、動的トピックモデルを被せると、ニュース量だけでなく、**そのテーマの“語られ方”自体が変わってきているか**まで追えます。萌芽トレンド検知にはここが重要です。[mimno.infosci.cornell.edu+2BERTopic+2](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf)

### 3\. 教師ありのリターン予測テキスト型

学術的に最も強いのは、最終的にはこの方向です。Boudoukh らは、ニュースの**タイプ**と**トーン**を区別することが重要だと示し、Ke・Kelly・Xiu は、辞書ベース sentiment ではなく、**将来リターン予測に最適化した supervised text score** を構築して、経済的にも有意な成果を示しています。つまり、「ポジティブかネガティブか」を測るだけでは不十分で、**“どの種類のニュースが価格に効くか”を学習したほうが強い**ということです。[NBER+1](https://www.nber.org/papers/w18725)

ただし、これはラベル設計が難しいです。テーマ選択問題なら、個別記事を直接ラベル付けするより、まずは  
**ニュース集合 → テーマ日次特徴量 → 5日/20日先のテーマ超過収益**  
の形で学習するのが現実的です。個別記事単位よりノイズが減り、テーマ選択という目的にも合います。これは文献の考え方を、テーマバスケットに自然に移植した形です。[NBER+1](https://www.nber.org/papers/w26186)

### 4\. センチメント単独より、「新規性」「拡散」「不一致」を足す型

ニュース sentiment は有用ですが、単独では弱い場面が多いです。むしろ、**新規性が高く、まだ市場に十分拡散していない話題**のほうがトレンド選択に向きます。Larsen and Thorsrud はニューストピック自体の予測力を示し、Hirshleifer らはニュースの社会的拡散の遅さが価格反応の遅れに関係すると示しています。また、ニュース起因の投資家 disagreement を測る研究も出ており、**強いポジティブ consensus** と **賛否が割れる話題** は分けて扱うべきです。[norges-bank.no+2NBER+2](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952&utm_source=chatgpt.com)

実務では、テーマごとに少なくとも  
**sentiment 水準 / sentiment 変化 / novelty / disagreement / persistence**  
を分けて持つのがよいです。テーマ投資はしばしば「物語」が先行するため、単なる件数や tone より、**語りが新しく、広がりつつあり、まだ価格に完全には織り込まれていないか**が重要になります。[norges-bank.no+1](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952&utm_source=chatgpt.com)

### 5\. テーマ純度を明示的に入れる型

テーマ選択では、ニュース信号が正しくても、**テーマバスケット自体の純度が低いと収益化しにくい**です。最近の研究では、テキスト分析から各銘柄・各ファンドの thematic exposure を測る枠組みや、ETF の theme washing を測る研究が出ています。テーマ名は魅力的でも、中身が薄い、あるいはテーマと無関係な銘柄が多いと、ニュースシグナルを取っても効きが鈍ります。[SSRN+1](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1&utm_source=chatgpt.com)

したがって、各テーマのニューススコアをそのまま使うのではなく、  
**テーマスコア × テーマ純度 × 実装可能性（流動性・コスト）**  
で最終順位を決めるのが実務的です。これはテーマETF実務ではかなり重要です。テーマ洗浄があると、ニュース上は盛り上がっていても、投資対象がそのテーマに十分連動しない可能性があるからです。[SSRN+1](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2)

実務でいちばんおすすめの設計
--------------

現時点で、学術性と実装容易性のバランスが最も良いのは次のハイブリッドです。

### A. ニュースのテーマ帰属

各記事を、次の3経路でテーマへ割り当てます。

*   **銘柄経由**: 記事内の企業名・ティッカーを抽出し、その企業が属するテーマへ配賦
*   **説明文経由**: 記事 embedding とテーマ説明文 embedding の類似度
*   **保有銘柄集合経由**: 記事 embedding と、各テーマの構成銘柄説明文の重心 embedding の類似度

この3つを混ぜると、単なるキーワード漏れをかなり防げます。SBERT系は意味類似検索に向いており、BERTopic系は未分類ニュースの新しい塊を見つけるのに向いています。[arXiv+2BERTopic+2](https://arxiv.org/pdf/1908.10084)

### B. テーマ日次特徴量

各テーマについて、毎日以下を作ります。

*   **Attention level**: 当日件数、過去20日 z-score
*   **Attention acceleration**: 5日増加率、1日差分
*   **Breadth**: その日にニュースが付いた構成銘柄数 / 総構成銘柄数
*   **Sentiment**: FinBERT などによる記事 sentiment の加重平均
*   **Novelty**: 当日記事 embedding と直近30日テーマ記事中心との距離
*   **Disagreement**: 記事ごとの sentiment 分散、または相反する見出し比率
*   **Persistence**: 3日・5日連続で attention z-score が閾値超えか

FinBERT は金融文脈で fine-tune された sentiment モデルで、一般用途モデルより金融文書に適しています。[arXiv+1](https://arxiv.org/abs/1908.10063?utm_source=chatgpt.com)

### C. スコアリング

まずはシンプルに、  
**ThemeScore = 0.30×AttentionAcceleration + 0.20×Breadth + 0.20×Sentiment + 0.15×Novelty + 0.15×Persistence**  
のような線形合成から始めるのがよいです。次に、履歴が溜まったら、将来5営業日や20営業日のテーマ超過収益を目的変数にして、**rank regression / gradient boosting / regularized linear model** に移行するのが自然です。これは Ke・Kelly・Xiu 型の「目的に合わせてテキスト情報を学習する」考え方の、テーマ版です。[NBER](https://www.nber.org/papers/w26186)

どの手法を採るべきか
----------

目的別に言うと、こうです。

**最初の実装として最善**  
埋め込み類似度でニュースをテーマへ割り当て、日次で **attention・breadth・sentiment・novelty** を作ってランキングする方法です。実装しやすく、しかも単純なキーワード集計より壊れにくいです。[arXiv+2arXiv+2](https://arxiv.org/pdf/1908.10084)

**学術的に最も筋がいい発展先**  
ニュース特徴量からテーマ将来収益を予測する **教師あり supervised text model** です。一般 sentiment ではなく、将来収益に効く表現を学習する方向です。[NBER+1](https://www.nber.org/papers/w26186)

**新しいテーマの芽を拾いたい場合**  
BERTopic / Dynamic Topic Model を並走させ、既存テーマに十分割り当てられないニュース群から**新興トピック**を検出します。既存テーマ選択だけだと、バスケット外から芽が出てきた変化を見逃しやすいからです。[mimno.infosci.cornell.edu+1](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf)

重要な注意点
------

テーマ投資では、ニュースで盛り上がったテーマをそのまま買うと、**過熱した“物語”を高値で掴む**危険があります。テーマ洗浄やテーマ商品の長期劣後を示す研究もあり、ニュースシグナルは **「魅力」そのもの**ではなく、\*\*「関心の立ち上がり」や「情報拡散の途中」\*\*を測る道具として使うほうがよいです。したがって、価格モメンタム、バリュエーション、純度、流動性と必ず組み合わせるべきです。[NBER+3SSRN+3SSRN+3](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2)

推奨順位
----

私なら、次の順で進めます。

**第1段階**  
埋め込み類似度 + 銘柄経由マッチングでテーマ帰属し、  
**Attention / Acceleration / Breadth / FinBERT sentiment / Novelty** を作ってランキング。[arXiv+2arXiv+2](https://arxiv.org/pdf/1908.10084)

**第2段階**  
未分類記事だけ BERTopic に流し、新興トピックを監視。[BERTopic+1](https://bertopic.com/)

**第3段階**  
十分な履歴が溜まったら、テーマ日次特徴量から将来テーマ収益を予測する supervised model に移行。[NBER](https://www.nber.org/papers/w26186)

主な出典
----

*   Boudoukh, Feldman, Kogan, Richardson, Whitelaw, **Which News Moves Stock Prices? A Textual Analysis**. NBER Working Paper 18725. [NBER](https://www.nber.org/papers/w18725)
*   Ke, Kelly, Xiu, **Predicting Returns With Text Data**. NBER Working Paper 26186. [NBER](https://www.nber.org/papers/w26186)
*   Blei, Lafferty, **Dynamic Topic Models**. [mimno.infosci.cornell.edu](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf)
*   Reimers, Gurevych, **Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks**. [arXiv](https://arxiv.org/pdf/1908.10084)
*   Araci, **FinBERT: Financial Sentiment Analysis with Pre-trained Language Models**. [arXiv](https://arxiv.org/abs/1908.10063?utm_source=chatgpt.com)
*   Larsen, Thorsrud, **Asset Returns, News Topics, and Media Effects**. [norges-bank.no](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952&utm_source=chatgpt.com)
*   Hirshleifer et al., **News Diffusion in Social Networks and Stock Market Reactions**. NBER Working Paper 30860. [NBER](https://www.nber.org/system/files/working_papers/w30860/w30860.pdf)
*   Ben-Rephael, Da, Israelsen, **Institutional Investor Attention and Underreaction to News**. [Academic Web Service](https://academicweb.nd.edu/~zda/AIA.pdf)
*   Bai, Tang, Wan, Yuksel, **Thematic Concentration and Mutual Fund Performance**. [SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1&utm_source=chatgpt.com)
*   He, Wang, Ward, **Theme Washing in the ETF Space**. [SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/5844262.pdf?abstractid=5844262&mirid=1&type=2)

次に進めるなら、これを前提に **「あなたのテーマバスケット向けの具体的なシグナル設計」** まで落とし込みます。

---

**Sources:**

- [Predicting Returns With Text Data | NBER](https://www.nber.org/papers/w26186)
- [](https://arxiv.org/pdf/1908.10084)
- [dtm.dvi](https://mimno.infosci.cornell.edu/info6150/readings/dynamic_topic_models.pdf)
- [Working Paper 17/2017: Asset returns, news topics, and media ...](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952&utm_source=chatgpt.com)
- [Thematic Concentration and Mutual Fund Performance](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1&utm_source=chatgpt.com)
- [BERTopic - Advanced Transformer-Based Topic Modeling](https://bertopic.com/)
- [](https://academicweb.nd.edu/~zda/AIA.pdf)

## Prompt:
2026/4/14 20:48:50

信仰テーマを捉える必要はありません、再整理して

## Response:
2026/4/14 20:48:51

前回は「新興テーマの芽」まで含めて広く取りました。今回はそれを外して、**既知のテーマ群の中でどれを選ぶか**だけに絞って再整理します。

> **Searching key papers on financial text analysis**
>
> [Which News Moves Stock Prices? A Textual Analysis](https://www.nber.org/papers/w18725)
> [FinBERT: Financial Sentiment Analysis with Pre-trained Language Models](https://arxiv.org/abs/1908.10063)
> [Financial Sentiment Analysis with Pre-trained Language Models](https://ar5iv.labs.arxiv.org/html/1908.10063)
>
> 思考時間: 12s

承知しました。**「新興テーマの発見」は不要**で、前提として **テーマ群は既知**、必要なのは **日々のニュースから既知テーマの中でどれを選ぶか** だけ、という形で再整理します。

この条件なら、手法はかなり絞れます。  
結論は、**最有力なのは「テーマ帰属 → テーマ別ニュース特徴量化 → テーマ順位付け」の3段階設計**です。ここで重要なのは、ニュースから新しいテーマを見つけることではなく、**既知テーマごとにニュースの強さ・広がり・方向性を毎日測る**ことです。辞書的な sentiment 単独より、**テーマ関連度、ニュース量、加速度、カバレッジ、センチメント**を分離して持つほうが、学術的にも実務的にも筋が良いです。[arXiv+3NBER+3NBER+3](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

何をやるべきか
-------

### 1\. まず「そのニュースはどのテーマの話か」を決める

既知テーマ選択では、最初のボトルネックは sentiment ではなく、**帰属精度**です。  
各記事を各テーマに割り当てる方法として有力なのは、次の2系統です。

*   **ルールベース**  
    テーマ名、テーマ説明文、構成銘柄名、ティッカー、主要製品名でマッチさせる
*   **埋め込みベース**  
    ニュース本文と、テーマ説明文・構成銘柄説明文の embedding 類似度で割り当てる

実務ではこの **ハイブリッド** が最も安定します。Sentence-BERT は文同士の意味類似検索を高速に行うために設計されており、大規模なニュース集合を既知テーマに意味的に割り当てる用途に向いています。[arXiv](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)

この段階では、**新テーマ検知のためのクラスタリングや BERTopic は不要**です。今回の目的では、未分類記事を新しいトピックにまとめるより、**既知テーマに正しく寄せること**のほうが重要です。

2\. 各テーマについて、毎日どんな特徴量を作るべきか
---------------------------

既知テーマの中から選ぶなら、最低限この5つを持つのが有力です。

### A. 関心の強さ（attention level）

その日に、そのテーマに割り当てられたニュース件数。  
ただし生件数だけでなく、**過去20日平均との差の z-score** のように異常度へ正規化したほうがよいです。ニュースが多いだけでは大型テーマが常に有利になるためです。  
ニュースが価格変動に関係すること、またニュース内容の識別が重要であることは Boudoukh らが示しています。[NBER](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

### B. 関心の立ち上がり（attention acceleration）

テーマ選択では、絶対件数より **増え方** が効きやすいです。  
たとえば、

*   1日差分
*   5日移動平均の変化率
*   当日件数 / 過去20日平均

のような指標です。  
これは「話題であり続けているテーマ」より、**いま注目が加速しているテーマ**を拾うためです。

### C. テーマ内の広がり（breadth / coverage）

これがかなり重要です。  
あるテーマのニュース件数が多くても、それが構成銘柄1社だけに集中していれば、個別材料にすぎない可能性があります。したがって、

**breadth = 当日ニュースが付いた構成銘柄数 / テーマ構成銘柄数**

を入れるべきです。  
テーマ投資で欲しいのは個別株ニュースではなく、**テーマ全体への追い風**だからです。

### D. ニュースの方向性（sentiment）

センチメントは必要ですが、**単独では弱い**です。  
使うなら一般辞書より、金融文脈に特化した FinBERT 系が妥当です。FinBERT は金融テキスト向けに設計されており、一般用途モデルより金融センチメント判定で有効とされています。[arXiv](https://arxiv.org/abs/1908.10063?utm_source=chatgpt.com)

テーマ単位では、

*   記事 sentiment の平均
*   強気記事比率
*   sentiment の5日変化

あたりが基本です。

### E. テーマ関連度の強さ（relevance strength）

記事をテーマへ割り当てたあとも、**どれくらい強くそのテーマの話か**を残したほうがよいです。  
つまり 0/1 で所属を切るだけでなく、SBERT 類似度やルール一致スコアを使って、**重み付き集計**にします。  
これで「少しだけAIに触れている記事」と「AIテーマそのものの記事」を分けられます。[arXiv](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)

3\. どのモデルでテーマ順位を付けるべきか
----------------------

ここは2段階で考えるのがよいです。

### 実務の初期段階

まずは**ルールベースの合成スコア**で十分です。たとえば、

$$
Score_{k,t} = 0.30 \cdot Accel_{k,t} + 0.25 \cdot Breadth_{k,t} + 0.25 \cdot Sentiment_{k,t} + 0.20 \cdot AttentionZ_{k,t}
$$

のような形です。  
この形の利点は、解釈しやすく、テーマ選択の理由も説明しやすいことです。

### 履歴が溜まった後

十分な期間のデータができたら、  
**テーマ日次特徴量 → 5日先/20日先のテーマ超過収益**  
を目的変数にして教師あり学習へ移行するのが有力です。

Ke・Kelly・Xiu は、一般的な辞書ベース sentiment よりも、**将来リターン予測という目的に合わせて教師ありで学習したテキストスコアのほうが有効**であると示しています。これはそのままテーマ選択にも応用できます。[NBER+1](https://www.nber.org/papers/w26186?utm_source=chatgpt.com)

つまり、学術的に強い順でいうと、

1.  単純 sentiment
2.  sentiment + attention 指標
3.  **テーマ特徴量を使った supervised ranking**  
    の順です。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

学術的・実務的に見た推奨順位
--------------

### 最もおすすめ

**既知テーマへのニュース帰属 + attention/acceleration/breadth/sentiment で日次ランキング**

理由は、

*   実装難易度が低い
*   解釈しやすい
*   既知テーマ選択という目的にぴったり合う  
    からです。SBERT と FinBERT を使うと、実務上かなり自然な形になります。[arXiv+1](https://arxiv.org/abs/1908.10063?utm_source=chatgpt.com)

### 次点

**上記特徴量を説明変数にした supervised ranking / return prediction**

こちらのほうが最終的には強い可能性が高いですが、学習期間と検証設計が必要です。Ke・Kelly・Xiu の方向性はこちらです。[NBER+1](https://www.nber.org/papers/w26186?utm_source=chatgpt.com)

### 優先度を下げてよいもの

*   新興テーマ抽出
*   未分類記事クラスタリング
*   Dynamic Topic Model / BERTopic の本格導入

今回は既知テーマ選択が目的なので、これらは主戦力ではありません。

実務での最適構成
--------

今回の条件に一番合う実装方針を一言で言うと、

**「ニュースを既知テーマに割り当て、テーマごとに attention・acceleration・breadth・FinBERT sentiment を作り、テーマ横断で毎日ランキングする」**

です。

かなり素直に書くと、こんな流れです。

1.  テーマごとに
    *   テーマ名
    *   テーマ説明
    *   構成銘柄一覧
    *   構成銘柄の事業説明  
        を準備する
2.  各ニュース記事について
    *   銘柄名・ティッカー抽出
    *   テーマ文との SBERT 類似度
    *   FinBERT sentiment  
        を計算する
3.  テーマ日次で集計して
    *   件数
    *   件数加速度
    *   構成銘柄カバレッジ
    *   sentiment 平均
    *   類似度加重件数  
        を作る
4.  その日の上位テーマを選ぶ

この設計は、ニュースの内容識別の重要性を示す研究とも、return prediction に合わせてテキストを使う研究とも整合的です。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

再整理した結論
-------

新興テーマを捉えないなら、論点はかなり明快です。

*   やるべきことは **テーマ発見** ではなく **既知テーマへの正しい帰属**
*   使うべき主特徴量は  
    **attention / acceleration / breadth / sentiment / relevance**
*   最初はルールベース合成でよい
*   本命は、その後の **supervised なテーマ順位付け**
*   BERTopic や動的トピックモデルは、今回の主目的には不要

出典
--

*   Boudoukh, Feldman, Kogan, Richardson, Whitelaw, _Which News Moves Stock Prices? A Textual Analysis_. NBER Working Paper 18725. [NBER](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)
*   Ke, Kelly, Xiu, _Predicting Returns With Text Data_. NBER Working Paper 26186. [NBER+1](https://www.nber.org/papers/w26186?utm_source=chatgpt.com)
*   Araci, _FinBERT: Financial Sentiment Analysis with Pre-trained Language Models_. [arXiv](https://arxiv.org/abs/1908.10063?utm_source=chatgpt.com)
*   Reimers, Gurevych, _Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks_. [arXiv](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)

次は、この整理を前提に **「テーマバスケット選択のための具体的なシグナル設計」** まで落とします。

---

**Sources:**

- [Which News Moves Stock Prices? A Textual Analysis](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)
- [Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)

## Prompt:
2026/4/14 21:03:00

テーマ帰属 → テーマ別ニュース特徴量化　について具体的な手法を学術論文・実務手法をもとに出展元を明記して調査

## Response:
2026/4/14 21:03:04

今回は「テーマ帰属」と「テーマ別ニュース特徴量化」を分けて、どこまでが学術的根拠で、どこからが実務上の設計定石かを切り分けて整理します。既知テーマへの割り当て精度と、日次集計特徴量の設計が中心です。

ここまでで、手法の骨格はかなりはっきりしています。  
学術的には「ニュースの内容をまず意味的に整理してから、量とトーンを別々に測る」が主流で、実務ではそれを既知テーマへ割り当てる形に変換するのが自然です。

> **検索：金融ニュースの分類と特徴抽出**
>
> [Financial News and the Equity Market: A Machine Learning ...](https://repositum.tuwien.at/bitstream/20.500.12708/193735/1/Salbrechter%20Stefan%20-%202024%20-%20Financial%20news%20and%20the%20equity%20market%20a%20machine...pdf)
> [Quantifying a firm's AI engagement: Constructing objective ...](https://www.sciencedirect.com/science/article/pii/S0040162524007637)
> [Financial sentiment analysis using FinBERT with ...](https://arxiv.org/html/2306.02136v2)
> [A Comparative Study of Fine-Tuned Deep Learning Models](https://www.researchgate.net/publication/391446592_Financial_Sentiment_Analysis_and_Classification_A_Comparative_Study_of_Fine-Tuned_Deep_Learning_Models)
> [Leveraging State-of-the-Art Topic Modeling for News ...](https://www.mdpi.com/2079-9292/12/12/2605)
> [Full article: Thematic Investing: A Risk-Based Perspective](https://www.tandfonline.com/doi/full/10.1080/0015198X.2025.2526483)
> [Sentiment and stock price volatility: a multilayer ...](https://www.nature.com/articles/s41599-026-06661-x)
> [Financial News Classification Model for NLP-based Bond ...](https://2025.ic-dsp.org/wp-content/uploads/2023/05/DSP2023-103.pdf)
> [Topic modeling of investment style news.](https://matheo.uliege.be/bitstream/2268.2/10346/4/MT_BOEMER_2020.pdf)
> [limitations of news sentiment analysis in short-term stock ...](https://papers.ssrn.com/sol3/Delivery.cfm/5086825.pdf?abstractid=5086825&mirid=1)
> [Asset returns, news topics, and media effects* - Larsen](https://onlinelibrary.wiley.com/doi/10.1111/sjoe.12469)
> [A News Textual Analysis Approach to Measuring ESG ...](https://jums.academy/wp-content/uploads/2025/06/MA_Imron.pdf)
> [Predicting Stock Prices with FinBERT-LSTM](https://dl.acm.org/doi/fullHtml/10.1145/3694860.3694870)
> [AI: In a Bubble](https://www.goldmansachs.com/pdfs/insights/goldman-sachs-research/ai-in-a-bubble/report.pdf)
> [Social Media Sentiment and Over-the-Counter Equity ...](https://cigs.canon/uploads/2025/12/econometrics_20250708_p.pdf)
>
> **調査のための新しい情報源を検討中**
>
> より良い情報源が必要です。オリジナルのFinBERT arxiv、SBERT、BERTopicはおそらく不要かもしれません。むしろ、テーマ別の露出に関連する論文を探して、NLPを通じたテーマごとの分析を重点的に調べるべきかもしれません。
>
> **検索: テーマ別エクスポージャーとNLPの文献**
>
> [Risk & Reward](https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID3680041_code2677369.pdf?abstractid=3680041&mirid=1)
> [THEME: Enhancing Thematic Investing with Semantic ...](https://arxiv.org/html/2508.16936v2)
> [NLP Framework for Thematic Investing | PDF](https://www.scribd.com/document/916177389/NLP-Thematic-Investment-Basket-Creation)
> [Text Mining Techniques for Financial Texts: A New Frontier ...](https://www.researchgate.net/publication/390056641_Text_Mining_Techniques_for_Financial_Texts_A_New_Frontier_in_Investor_Sentiment_Analysis)
> [II. Natural Language Understanding, Processing, and ...](https://rpc.cfainstitute.org/sites/default/files/-/media/documents/article/rf-brief/ai-and-big-data-in-investments-Part-II.pdf)
> [complete-issue.pdf](https://www.pm-research.com/content/iijpormgmt/52/1/local/complete-issue.pdf)
> [Topic modeling of investment style news.](https://matheo.uliege.be/bitstream/2268.2/10346/4/MT_BOEMER_2020.pdf)
>
> **情報源の再検討**
>
> BERTopicの公式ドキュメントは必ずしも必要ないかもしれませんが、注意に関する資料が必要です。Da et al、Hirshleifer、Larsenなどの文献を参考にして、特定の情報源を探してみることが重要そうです。
>
> **指定された論文と投資家の注目に関する検索**
>
> [In Search of Attention!](https://www.nber.org/conferences/2009/mms09/Da_Engelberg_Gao.pdf)
> [Working Paper 17/2017: Asset returns, news topics, and media ...](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)
> [Institutional Investor Attention and Underreaction to News](https://academicweb.nd.edu/~zda/AIA.pdf)
> [In Search of Attention*](https://www.ou.edu/dam/price/Finance/files/Paul%20Gao%20Paper.pdf)
> [Asset returns, news topics, and media effects* - Larsen](https://onlinelibrary.wiley.com/doi/full/10.1111/sjoe.12469)
> [Institutional Investor Attention and Under-Reaction to News](https://www.ssrn.com/abstract%3D2692181)
> [News Diffusion in Social Networks and Stock Market ...](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4334939)
> [Asset returns, news topics, and media effects | Request PDF](https://www.researchgate.net/publication/356738240_Asset_returns_news_topics_and_media_effects)
> [Institutional Investor Attention and Underreaction to News](https://academic.oup.com/rfs/article-abstract/30/9/3009/3830159)
> [Asset returns, news topics, and media effects](https://ideas.repec.org/p/bny/wpaper/0054.html)
> [[PDF] Asset Returns, News Topics, and Media Effects](https://www.semanticscholar.org/paper/9f1db17b90c1713da792e254905dd5eb22bb3e84)
> [Asset Returns, News Topics, and Media Effects](https://www.econstor.eu/handle/10419/210127)
>
> **FinBERTの正確な情報源を確認**
>
> FinBERTについて、正確な情報源を探さないといけないかもしれません。公式なソースを調べてみるべきだと思います。どこからその情報を取得するのがベストかを確認するために、さらに調査を進める必要があります。
>
> **FinBERTに関する公式情報を検索中**
>
> [FinBERT: Financial Sentiment Analysis with Pre-trained Language Models](https://arxiv.org/abs/1908.10063)
> [Textual analysis in finance](https://scispace.com/pdf/textual-analysis-in-finance-23jwnbunbz.pdf)
> [WHICH NEWS MOVES STOCK PRICES? A TEXTUAL ...](https://www.stern.nyu.edu/sites/default/files/assets/documents/con_038156.pdf)
> [Financial Sentiment Analysis with Pre-trained Language Models](https://ar5iv.labs.arxiv.org/html/1908.10063)
> [ProsusAI/finbert](https://huggingface.co/ProsusAI/finbert)
> [Loughran-McDonald Master Dictionary w/ Sentiment Word Lists](https://sraf.nd.edu/loughranmcdonald-master-dictionary/)
> [WHICH NEWS MOVES STOCK PRICES? A TEXTUAL ...](https://faculty.runi.ac.il/kobi/text_20121223.pdf)
> [FinBERT: Financial Sentiment Analysis with Pre-trained ...](https://www.researchgate.net/publication/335441873_FinBERT_Financial_Sentiment_Analysis_with_Pre-trained_Language_Models)
> [Textual Analysis in Finance by Tim Loughran, Bill McDonald](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3470272)
> [Which News Moves Stock Prices? A Textual Analysis](https://www.nber.org/papers/w18725)
> [FinBERT: Financial Sentiment Analysis | PDF](https://www.scribd.com/document/456724166/1908-10063-pdf)
> [Dictionaries for Financial Texts](https://yurkevi.ch/data/Dictionaries_for_Financial_Texts.pdf)
> [Which News Moves Stock Prices? A Textual Analysis](https://ideas.repec.org/p/nbr/nberwo/18725.html)
> [MaterialBERT for Natural Language Processing of ...](https://jxiv.jst.go.jp/index.php/jxiv/preprint/view/119)
> [FinBERT: Financial Sentiment Analysis with Pre-trained ...](https://www.semanticscholar.org/paper/FinBERT%3A-Financial-Sentiment-Analysis-with-Language-Araci/7102bb3fe73bd057ff161d9db5214a267c1ef312)
>
> **投資信託によるテーマ別情報源を探す**
>
> 投資信託に関連するテーマ別のテキスト情報源が必要かもしれません。オープンな資料を調査して、どの情報が有益かを確認する必要があります。関連する情報をしっかり見つけて、テーマごとの知識を得ることが課題です。
>
> **検索: 投資信託のテーマ的なテキスト露出**
>
> [Thematic Concentration and Mutual Fund Performance by John (Jianqiu) Bai, Yuehua Tang, Chi Wan, H. Zafer Yuksel :: SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1)
> [Leveraging State-of-the-Art Topic Modeling for News Impact Analysis on Financial Markets: A Comparative Study](https://www.mdpi.com/2079-9292/12/12/2605)
> [[1908.10063] FinBERT: Financial Sentiment Analysis with Pre-trained Language Models](https://arxiv.org/abs/1908.10063)
> [Which News Moves Stock Prices? A Textual Analysis | NBER](https://www.nber.org/papers/w18725)
> [Working Paper 17/2017: Asset returns, news topics, and media effects](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)
> [academicweb.nd.edu](https://academicweb.nd.edu/~zda/AIA.pdf)
> [rpc.cfainstitute.org](https://rpc.cfainstitute.org/sites/default/files/-/media/documents/article/rf-brief/ai-and-big-data-in-investments-Part-II.pdf)
>
> **FinBERT内のキーワード検索と行番号特定**
>
> [Thematic Concentration and Mutual Fund Performance by John (Jianqiu) Bai, Yuehua Tang, Chi Wan, H. Zafer Yuksel :: SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1)
> [[1908.10063] FinBERT: Financial Sentiment Analysis with Pre-trained Language Models](https://arxiv.org/abs/1908.10063)
> [Leveraging State-of-the-Art Topic Modeling for News Impact Analysis on Financial Markets: A Comparative Study](https://www.mdpi.com/2079-9292/12/12/2605)
> [Working Paper 17/2017: Asset returns, news topics, and media effects](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)
>
> **調査の方向性を再確認**
>
> 弱い監視やSnorkelについて調べる必要があるかもしれませんが、多すぎるかもしれません。ユーザーが求めている具体的な手法に基づいて、学術的かつ実践的な方法を中心に語るべきです。Loughran-McDonaldやSentence BERT、Boudoukhに関連する資料を探る必要があります。また、ReutersとLarsenからの会社やテキストのトピック連携も有用かもしれません。
>
> **検索: weak supervision, Sentence-BERT, Loughran-McDonaldなど**
>
> [Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks](https://arxiv.org/abs/1908.10084)
> [Latent Dirichlet Allocation](https://www.jmlr.org/papers/volume3/blei03a/blei03a.pdf)
> [When Is a Liability Not a Liability? Textual Analysis, ...](https://www.uts.edu.au/globalassets/sites/default/files/adg_cons2015_loughran-mcdonald-je-2011.pdf)
> [Latent Dirichlet Allocation](https://jmlr.csail.mit.edu/papers/v3/blei03a.html)
> [When is a Liability not a Liability? Textual Analysis, ...](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1331573)
> [arXiv:2203.05794v1 [cs.CL] 11 Mar 2022](https://elearning.unimib.it/pluginfile.php/2037266/mod_resource/content/1/2203.05794v1.pdf)
> [Sentence Embeddings using Siamese BERT-Networks](https://huggingface.co/papers/1908.10084)
> [Latent Dirichlet Allocation - Stanford AI Lab](https://ai.stanford.edu/~ang/papers/jair03-lda.pdf)
> [When is a Liability not a Liability? ...](https://www.spglobal.com/content/dam/spglobal/mi/en/documents/general/qa-leveraging-natural-language-proccessing-to-speed-read-company-filings.pdf)
> [【入門】Sentence BERT](https://zenn.dev/en2enzo2/articles/a574b52bb8d116)
> [(PDF) Latent Dirichlet Allocation](https://www.researchgate.net/publication/221620547_Latent_Dirichlet_Allocation)
> [When Is a Liability Not a Liability? Textual Analysis, ...](https://onlinelibrary.wiley.com/doi/10.1111/j.1540-6261.2010.01625.x)
> [BERTopic](https://maartengr.github.io/BERTopic/index.html)
> [Sentence Embeddings using Siamese BERT-Networks](https://www.opentrain.ai/papers/sentence-bert-sentence-embeddings-using-siamese-bert-networks--arxiv-1908.10084/)
> [Internet Appendix for “When is a Liability not ...](https://afajof.org/wp-content/uploads/files/supplements/Internet_Appendix_for_When_I.pdf)
>
> **テーマ別集中と実践的アプローチについて**
>
> ユーザーが求める実践的な方法に焦点をあて、10-Kからのテキスト分析がテーマ別露出を定義できることを示す証拠を挙げるべきかもしれません。Invescoの記事から実務的アプローチを引用することも考えますが、方法論の詳細は避け、主要な主張には信頼できる情報源を引用する必要あります。
>
> **トピックモデリングに関する実務的な情報源を探求**
>
> S&PやCFAからの情報源が役立つかもしれませんが、期限に合わせて文献と調査結果を使うべきかも。金融業界のトピックモデリングに関する実践的な詳細な情報が必要です。また、Loughran-McDonaldのドメイン用語に関わる警告も役立つでしょう。
>
> **調査：金融分野におけるテキスト分析実践方法**
>
> [[1908.10084] Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks](https://arxiv.org/abs/1908.10084)
> [blei03a.dvi](https://www.jmlr.org/papers/volume3/blei03a/blei03a.pdf)
> [When Is a Liability Not a Liability Textual Analysis, Dictionaries, and 10Ks](https://www.uts.edu.au/globalassets/sites/default/files/adg_cons2015_loughran-mcdonald-je-2011.pdf)
> [BERTopic](https://maartengr.github.io/BERTopic/index.html)
>
> 思考時間: 1m 23s

以下、**既知のテーマ群に対して**  
**(1) ニュースをどのテーマへ帰属させるか** と  
**(2) テーマ別にニュース特徴量をどう作るか**  
を、**学術論文**と**実務で使いやすい実装手法**に分けて整理します。

結論から言うと、最も筋が良いのは、

**テーマ帰属**  
→ ルールベースだけでなく、**テキスト類似度ベースで「明示的にテーマ名が書かれていない記事」も拾う**

**テーマ別特徴量化**  
→ 単純件数ではなく、**量・加速度・トーン・関連度・広がり**を分けて持つ

という設計です。これは、ニュースを「型」と「トーン」で識別すると予測力が改善するという金融テキスト研究や、ニューストピックを企業へ意味的にリンクして時系列化する研究と整合的です。[NBER+2norges-bank.no+2](https://www.nber.org/papers/w18725)

* * *

1\. テーマ帰属の具体的手法
---------------

### 1-1. 最低限のベースライン: ルールベース帰属

最も単純なのは、各テーマについて辞書を作り、記事本文・見出し・メタデータと照合する方法です。

典型的な辞書要素は次です。

*   テーマ名そのもの
*   テーマ説明文の主要語
*   構成銘柄名
*   ティッカー
*   構成銘柄の主要製品・サービス語
*   同義語・略称

たとえば「AI」テーマなら、`AI / generative AI / data center / inference / GPU / training / model` のような表現と、構成銘柄群を辞書に含めます。  
この方法の利点は、**透明で監査しやすい**ことです。欠点は、言い換えや新しい表現に弱いことです。

金融テキスト分析では、辞書法は依然として重要ですが、**一般辞書をそのまま使うと金融文脈で誤分類が多い**ことが知られています。Loughran and McDonald は、一般目的辞書の negative word が金融文脈ではかなり誤判定を起こすことを示し、金融専用辞書の必要性を示しました。[uts.edu.au](https://www.uts.edu.au/globalassets/sites/default/files/adg_cons2015_loughran-mcdonald-je-2011.pdf)

### 1-2. 実務上の本命: 埋め込み類似度によるテーマ帰属

既知テーマ選択では、実務的にはこれが本命です。

考え方はシンプルで、以下を全部ベクトル化して、コサイン類似度で結びます。

*   ニュース記事
*   テーマ名
*   テーマ説明文
*   構成銘柄の事業説明文
*   必要ならテーマごとの代表キーフレーズ

Sentence-BERT は、**意味的に近い文同士を近いベクトルへ写像し、類似検索を高速化する**ためのモデルです。元論文でも、通常の BERT では類似検索が重すぎる一方、SBERT は semantic similarity search や clustering に向くよう設計されていると説明されています。[arXiv](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)

この方法のよい点は、ニュースにテーマ名が直接出ていなくても拾えることです。  
たとえば「AI」という単語がなくても、「推論向け半導体需要」「学習用電力需要」「データセンター冷却」などがAIテーマへ近いと判定できます。

### 1-3. 学術的に非常に重要: “ニュース中の名前一致”だけに頼らない

Larsen and Thorsrud は、新聞記事を LDA でトピック分解したうえで、**各トピックを Reuters の企業説明文との語彙一致で企業へリンク**しています。重要なのは、**企業名が明示されていないニュースでも、企業に関連しうる**という発想です。彼らは、これは従来の「社名や略称の明示一致」に頼る方法より制約が少ないと述べています。[norges-bank.no](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)

この含意は、既知テーマ選択でもそのまま使えます。  
つまり、ニュースをテーマへ帰属させる際には、

*   **明示的一致**: テーマ名・構成銘柄名・ティッカーが出た
*   **意味的一致**: 記事内容がテーマ説明や銘柄説明と近い

の二層構造にするのが正しいです。[norges-bank.no+1](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)

### 1-4. 実装上おすすめのスコア

実務では、各記事  $d$  と各テーマ  $k$  に対して次のような帰属スコアを作るのが扱いやすいです。

$$
A_{d,k} = w_1 \cdot \text{NameMatch}_{d,k} + w_2 \cdot \text{TickerMatch}_{d,k} + w_3 \cdot \cos(e_d, e_k^{theme}) + w_4 \cdot \max_{j \in \mathcal{C}_k}\cos(e_d, e_j^{firm})
$$

ここで

*    $\text{NameMatch}$ : テーマ名や主要語の一致
*    $\text{TickerMatch}$ : 構成銘柄の明示一致
*    $e_d$ : 記事 embedding
*    $e_k^{theme}$ : テーマ説明文 embedding
*    $e_j^{firm}$ : 構成銘柄  $j$  の事業説明文 embedding
*    $\mathcal{C}_k$ : テーマ  $k$  の構成銘柄集合

です。

そのうえで

*   最大スコアのテーマに hard assignment する
*   もしくは上位2〜3テーマへ soft assignment する

のどちらかを選びます。  
**既知テーマバスケット選択**なら、最初は hard assignment でも十分です。

### 1-5. トピックモデルは「主役」ではなく補助

LDA や BERTopic は、今回のような **既知テーマへの帰属** では主役ではありません。  
ただし補助的には有効です。

*   **LDA** は、文書を複数トピックの混合として表す古典的モデルです。Blei らの原論文では、各文書を topic mixture として表現する生成モデルとして定式化されています。[jmlr.org](https://www.jmlr.org/papers/volume3/blei03a/blei03a.pdf)
*   **BERTopic** は、transformer embeddings と c-TF-IDF を組み合わせた topic modeling 手法で、ガイド付き・半教師あり・ゼロショットなどの拡張が可能です。公式ドキュメントでもその構成とモジュール性が示されています。[maartengr.github.io](https://maartengr.github.io/BERTopic/index.html)
*   金融ニュース比較研究では、あるニュース影響分析設定で **BERTopic が coherence・interpretability で最良** と報告されています。[MDPI](https://www.mdpi.com/2079-9292/12/12/2605)

ただし、今回の目的は「新テーマ発見」ではなく「既知テーマ選択」なので、  
**topic model は記事の整理や監査用**、  
**本番のテーマ帰属は embedding 類似度 + ルールベース**  
に寄せるのが実務的です。[MDPI+1](https://www.mdpi.com/2079-9292/12/12/2605)

* * *

2\. テーマ別ニュース特徴量化の具体的手法
----------------------

テーマ帰属ができた後は、各テーマ  $k$  について日次で特徴量を作ります。  
学術的に筋が良く、実務でも使いやすいのは次の分解です。

### 2-1. 量: News Volume / Attention Level

最も基本なのは、テーマ  $k$  に帰属した記事数です。

$$
N_{k,t}=\sum_{d \in \mathcal{D}_t} \mathbf{1}(A_{d,k}>\tau)
$$

ただし生件数のままだと、常に報道が多い大テーマが有利になります。  
そのため実務では、

$$
Z^{vol}_{k,t} = \frac{N_{k,t} - \mu_{k,t-60:t-1}}{\sigma_{k,t-60:t-1}}
$$

のような rolling z-score にするのが普通です。

この考え方の背景には、投資家 attention が重要であり、検索量やニュース閲覧量のような attention 指標が価格反応と結びつくという研究があります。Da, Engelberg, Gao は Google Search Volume Index を direct measure of attention として用い、既存 proxy と異なる timely な attention を捉えると示しました。Ben-Rephael, Da, Israelsen も Bloomberg terminal 上の検索・閲覧行動から institutional attention を直接測っています。[NBER+1](https://www.nber.org/conferences/2009/mms09/Da_Engelberg_Gao.pdf)

### 2-2. 変化率: Attention Acceleration

テーマ選択では、絶対量より **立ち上がり** が重要なことが多いです。  
そのため、量だけでなく加速度も持ちます。

典型例は以下です。

$$
Accel^{1}_{k,t}=N_{k,t}-N_{k,t-1}
$$
 
$$
Accel^{5}_{k,t}=\frac{\overline{N}_{k,t-4:t}}{\overline{N}_{k,t-24:t-5}}-1
$$

これは、単に「いつも話題なテーマ」ではなく、**今まさに attention が加速しているテーマ**を拾うためです。  
学術論文でこの式がそのまま定番というより、attention literature の含意を実務に移したものです。attention の level と change を分けるのは、投資家注意研究の実務実装として自然です。[NBER+1](https://www.nber.org/conferences/2009/mms09/Da_Engelberg_Gao.pdf)

### 2-3. トーン: Sentiment / Tone

各記事  $d$  の sentiment を  $s_d$  として、テーマ日次 sentiment を集計します。

$$
Sent_{k,t}= \frac{\sum_{d \in \mathcal{D}_t} A_{d,k} \cdot s_d} {\sum_{d \in \mathcal{D}_t} A_{d,k}}
$$

ここで重要なのは、**一般辞書より金融特化モデルを使うこと**です。  
Loughran-McDonald は一般辞書の誤分類問題を示しましたし、FinBERT は金融文脈向けに事前学習・微調整され、金融センチメントデータセットで改善を示しています。[uts.edu.au+1](https://www.uts.edu.au/globalassets/sites/default/files/adg_cons2015_loughran-mcdonald-je-2011.pdf)

実務では、以下の3本を別々に持つのが有効です。

*   平均 sentiment
*   正/負記事比率
*   sentiment の変化率

Boudoukh らも、ニュースの説明力は **tone だけでなく type の識別**に依存すると示しており、tone は重要だが単独では不十分です。[NBER](https://www.nber.org/papers/w18725)

### 2-4. 関連度加重: Relevance-Weighted Features

実務では、記事がテーマに「少し関係ある」だけなのか、「ど真ん中」なのかを分ける必要があります。  
そのため、件数やセンチメントを単純平均せず、帰属スコア  $A_{d,k}$  で重み付けします。

$$
RelVol_{k,t} = \sum_{d \in \mathcal{D}_t} A_{d,k}
$$
 
$$
RelSent_{k,t}= \frac{\sum_d A_{d,k}s_d}{\sum_d A_{d,k}}
$$

こうすると、「AI に一言だけ触れた記事」より「AI 向け半導体需要を主題にした記事」が強く効きます。  
これは学術論文で完全に同じ形が固定されているわけではありませんが、**意味的一致を距離で扱う** embedding-based classification の自然な実務拡張です。[arXiv+1](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)

### 2-5. 広がり: Breadth / Coverage

テーマ投資で特に重要なのがこれです。

$$
Breadth_{k,t}= \frac{\#\{j \in \mathcal{C}_k : \exists d \text{ s.t. } d \text{ mentions or maps to } j\}} {|\mathcal{C}_k|}
$$

つまり、テーマ構成銘柄のうち、その日にニュースで触れられた銘柄割合です。

これを入れる理由は明快で、  
**1社だけの材料**と  
**テーマ全体へ広がった材料**  
を分けたいからです。

Larsen and Thorsrud の研究は、ニューストピックを firms にリンクしたうえで topic series を構築しています。テーマ版では、それを firms の集合に拡張し、**テーマ内 breadth** を作るのが自然です。[norges-bank.no+1](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)

### 2-6. トピック量 × トーンの分離

Larsen and Thorsrud は、ニュースをトピックへ分解したうえで、**各トピックについて「どれくらい量があり、どのようなトーンか」の時系列を作る**と明示しています。これはテーマ別ニュース特徴量化のかなり直接的な先行例です。[norges-bank.no](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)

したがって、テーマ別特徴量は最低でも

*   量
*   トーン

を分けるべきです。  
実務ではさらに

*   量の変化率
*   breadth
*   relevance-weighted aggregates

まで拡張するのがよいです。

### 2-7. 拡散・持続性: Persistence / Diffusion

ニュースが市場にすぐ完全反映されるとは限らず、**拡散の遅さ**がその後の価格ドリフトに関係するという研究があります。Hirshleifer, Peng, Wang は、社会的ネットワークで news diffusion が強いほど初期反応が強く、その後のドリフトが弱くなることを示しています。[NBER](https://www.nber.org/system/files/working_papers/w30860/w30860.pdf)

テーマ選択に落とすなら、実務では

$$
Persist_{k,t} = \sum_{h=0}^{4} \mathbf{1}(Z^{vol}_{k,t-h} > c)
$$

のように、直近5日で何日 attention shock が続いたかを作るのが簡単です。  
また、複数ソースで同一テーマが反復されているかを数えるのも有効です。  
これは厳密には論文の測度そのものではありませんが、**news diffusion を観測可能 proxy に落とした実務設計**です。[NBER](https://www.nber.org/system/files/working_papers/w30860/w30860.pdf)

* * *

3\. 実務で最も使いやすい推奨パイプライン
----------------------

### 推奨フロー

1.  **テーマ辞書を作る**  
    テーマ名、説明文、構成銘柄、各銘柄の事業説明
2.  **記事単位で前処理**  
    見出し、本文、日時、媒体、企業名・ティッカー抽出
3.  **記事→テーマ帰属**
    *   ルール一致
    *   SBERT 類似度
    *   銘柄 mention 経由  
        を合成して  $A_{d,k}$  を作る
4.  **記事 sentiment 推定**  
    FinBERT など金融特化モデルで  $s_d$  を作る
5.  **テーマ日次集計**
    *   Volume
    *   Volume z-score
    *   Acceleration
    *   Relevance-weighted volume
    *   Sentiment
    *   Breadth
    *   Persistence
6.  **テーマ横断ランキング**  
    まずは線形合成、履歴が溜まったら教師ありへ

### 最初に持つべき特徴量

最小セットならこれです。

$$
X_{k,t} = \{ Z^{vol}_{k,t}, Accel^{5}_{k,t}, Sent_{k,t}, Breadth_{k,t}, RelVol_{k,t}, Persist_{k,t} \}
$$

この6本で、既知テーマ選択としてはかなり十分です。  
量だけ、sentiment だけ、のような単独設計より明らかに良いです。これはニュースの **type と tone を区別する** という Boudoukh らの含意とも一致します。[NBER](https://www.nber.org/papers/w18725)

* * *

4\. 学術ベースと実務ベースを分けると
--------------------

### 学術ベースで強いもの

*   **トピック分解して量とトーンの時系列を作る**  
    Larsen and Thorsrud [norges-bank.no+1](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)
*   **ニュースの型とトーンを分けて扱う**  
    Boudoukh et al. [NBER](https://www.nber.org/papers/w18725)
*   **attention を直接測る**  
    Da et al., Ben-Rephael et al. [NBER+1](https://www.nber.org/conferences/2009/mms09/Da_Engelberg_Gao.pdf)
*   **金融専用 sentiment モデル/辞書を使う**  
    Loughran-McDonald, FinBERT [uts.edu.au+1](https://www.uts.edu.au/globalassets/sites/default/files/adg_cons2015_loughran-mcdonald-je-2011.pdf)
*   **テキストから thematic exposure を定義する**  
    Bai et al. [papers.ssrn.com+1](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1)

### 実務で使いやすいもの

*   **SBERT によるニュース↔テーマ説明の類似度帰属**  
    大規模類似検索向けに相性がよい。[arXiv](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)
*   **構成銘柄事業説明への類似度も併用**
*   **帰属スコアで重み付け集計**
*   **breadth を入れる**
*   **volume と acceleration を分ける**
*   **persistence を入れる**

* * *

5\. 私の推奨
--------

既知テーマの中からニュースで選ぶだけなら、現実的な最適解はこれです。

### テーマ帰属

**ルールベース + SBERT 類似度 + 銘柄 mention**

### テーマ別特徴量

**volume z-score + acceleration + FinBERT sentiment + breadth + relevance-weighted volume + persistence**

### 使わなくてよいもの

*   新興テーマ検知
*   大掛かりな unsupervised clustering を主役にすること
*   一般辞書 sentiment の単独利用

* * *

主要出典
----

*   Boudoukh, Feldman, Kogan, Richardson, Whitelaw, **Which News Moves Stock Prices? A Textual Analysis**. NBER. [NBER](https://www.nber.org/papers/w18725)
*   Larsen, Thorsrud, **Asset Returns, News Topics, and Media Effects**. Norges Bank / Scandinavian Journal of Economics. [norges-bank.no+1](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)
*   Da, Engelberg, Gao, **In Search of Attention**. [NBER](https://www.nber.org/conferences/2009/mms09/Da_Engelberg_Gao.pdf)
*   Ben-Rephael, Da, Israelsen, **Institutional Investor Attention and Underreaction to News**. [Academic Web Service](https://academicweb.nd.edu/~zda/AIA.pdf)
*   Loughran, McDonald, **When Is a Liability Not a Liability? Textual Analysis, Dictionaries, and 10-Ks**. [uts.edu.au](https://www.uts.edu.au/globalassets/sites/default/files/adg_cons2015_loughran-mcdonald-je-2011.pdf)
*   Araci, **FinBERT: Financial Sentiment Analysis with Pre-trained Language Models**. [arXiv](https://arxiv.org/abs/1908.10063)
*   Reimers, Gurevych, **Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks**. [arXiv](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)
*   Blei, Ng, Jordan, **Latent Dirichlet Allocation**. [jmlr.org](https://www.jmlr.org/papers/volume3/blei03a/blei03a.pdf)
*   Chen et al., **Leveraging State-of-the-Art Topic Modeling for News Impact Analysis on Financial Markets**. [MDPI](https://www.mdpi.com/2079-9292/12/12/2605)
*   Bai, Tang, Wan, Yuksel, **Thematic Concentration and Mutual Fund Performance**. [papers.ssrn.com+1](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1)

次は、これを前提に **あなたの「テーマ名・内容・構成銘柄」が既にある前提で、実装用に特徴量定義を数式つきで一覧化** します。

---

**Sources:**

- [Which News Moves Stock Prices? A Textual Analysis | NBER](https://www.nber.org/papers/w18725)
- [When Is a Liability Not a Liability Textual Analysis, Dictionaries, and 10Ks](https://www.uts.edu.au/globalassets/sites/default/files/adg_cons2015_loughran-mcdonald-je-2011.pdf)
- [Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)
- [Working Paper 17/2017: Asset returns, news topics, and media effects](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)
- [blei03a.dvi](https://www.jmlr.org/papers/volume3/blei03a/blei03a.pdf)
- [BERTopic](https://maartengr.github.io/BERTopic/index.html)
- [Leveraging State-of-the-Art Topic Modeling for News Impact Analysis on Financial Markets: A Comparative Study](https://www.mdpi.com/2079-9292/12/12/2605)
- [Thematic Concentration and Mutual Fund Performance by John (Jianqiu) Bai, Yuehua Tang, Chi Wan, H. Zafer Yuksel :: SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/4164823.pdf?abstractid=4164823&mirid=1)
- [](https://academicweb.nd.edu/~zda/AIA.pdf)

## Prompt:
2026/4/14 21:08:29

実装を念頭に手法をまとめて。手法が散らかっている

## Response:
2026/4/14 21:08:35

実装前提で、候補を削って「何を作るか」に落とし込みます。今回は枝葉を捨てて、**最小で強い一本の実装方針**としてまとめます。

> **検索: 株価動向、金融感情分析、関連研究**
>
> [Which News Moves Stock Prices? A Textual Analysis](https://www.nber.org/papers/w18725)
> [Sentence Embeddings using Siamese BERT-Networks](https://aclanthology.org/D19-1410/)
> [FinBERT: Financial Sentiment Analysis with Pre-trained Language Models](https://arxiv.org/abs/1908.10063)
> [Working Paper 17/2017: Asset returns, news topics, and media ...](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)
> [Which News Moves Stock Prices? A Textual Analysis](https://ideas.repec.org/p/nbr/nberwo/18725.html)
> [FinBERT: Financial Sentiment Analysis with Pre-trained ...](https://www.researchgate.net/publication/335441873_FinBERT_Financial_Sentiment_Analysis_with_Pre-trained_Language_Models)
> [Asset returns, news topics, and media effects* - Larsen](https://onlinelibrary.wiley.com/doi/10.1111/sjoe.12469)
> [WHICH NEWS MOVES STOCK PRICES? A TEXTUAL ...](https://www.stern.nyu.edu/sites/default/files/assets/documents/con_038156.pdf)
> [[PDF] Asset Returns, News Topics, and Media Effects](https://www.semanticscholar.org/paper/9f1db17b90c1713da792e254905dd5eb22bb3e84)
> [Sentence Embeddings using Siamese BERT-Networks ...](https://scispace.com/papers/sentence-bert-sentence-embeddings-using-siamese-bert-5dz0n53mvi)
> [Which News Moves Stock Prices? A Textual Analysis](https://cris.huji.ac.il/en/publications/which-news-moves-stock-prices-a-textual-analysis/)
> [Sentence Embeddings using Siamese BERT-Networks](https://huggingface.co/papers/1908.10084)
> [FinBERT:事前訓練言語モデルによる財務感情分析【JST・京大 ...](https://jglobal.jst.go.jp/detail?JGLOBAL_ID=202302216291993049)
>
> 思考時間: 15s

了解です。散らかっていた候補を切って、**実装するならこれ**という一本に絞って整理します。

結論として、既知のテーマ群に対して日々のニュースから選ぶなら、実装すべき手法は次の **2段階 + 1スコア** です。

**Step 1. 記事をテーマに帰属させる**  
**Step 2. テーマごとに日次特徴量を集計する**  
**Step 3. その特徴量でテーマをランキングする**

この形にすると、ニュースの「何についての話か」と「その話がどの程度強いか」を分離できます。ニュースの予測力は、単なるトーンだけでなく、**ニュースの type と tone を分けて識別すること**で改善するという研究と整合的です。意味類似検索には SBERT、金融文脈のトーン推定には FinBERT が適しています。[norges-bank.no+3NBER+3ACL Anthology+3](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

* * *

まず、採用する手法を一本に絞る
---------------

採用するのはこれです。

### 採用

**ルールベース + 埋め込み類似度** で記事を既知テーマへ帰属  
その後、各テーマについて  
**volume / acceleration / sentiment / breadth / relevance**  
を日次で作る

### 今回は採用しない

*   新興テーマ検出
*   BERTopic を主役にしたクラスタリング
*   LDA を本番の帰属器にすること
*   一般辞書ベース sentiment 単独

理由は単純で、今回の目的は **既知テーマの中で順位を付けること** だからです。SBERT は文の意味類似検索向けに設計されており、BERT をそのまま使うよりこの用途に向いています。FinBERT は金融テキスト向け sentiment で一般モデルより有効です。Larsen and Thorsrud も、ニュースを意味的に整理したうえで量とトーンの時系列を使う方向を示しています。[ACL Anthology+2arXiv+2](https://aclanthology.org/D19-1410/?utm_source=chatgpt.com)

* * *

実装方針
====

1\. テーマ定義を作る
------------

各テーマ  $k$  について、最低限これを持ちます。

*   `theme_name`
*   `theme_description`
*   `constituents`（構成銘柄一覧）
*   `aliases`（略称・言い換え）
*   各構成銘柄の `company_description`

ここはニュースモデルではなく、**テーママスタ**です。  
記事をどのテーマへ載せるかの基準面になります。テーマ名だけでは弱く、**テーマ説明文**と**構成銘柄の事業説明文**まで持つことで、明示的にテーマ名が書かれていない記事も意味的に拾えます。これは、ニュースを firms/topics に意味的に結び付ける方向の研究と整合的です。[ACL Anthology+1](https://aclanthology.org/D19-1410/?utm_source=chatgpt.com)

* * *

2\. 記事単位で作るもの
-------------

各記事  $d$  について作るのは次です。

*   `headline`
*   `body`
*   `published_at`
*   `source`
*   `mentioned_tickers`
*   `doc_embedding`
*   `sentiment_score`

`doc_embedding` は SBERT 系、`sentiment_score` は FinBERT 系で作るのが実装上もっとも自然です。SBERT は cosine similarity による大規模な意味類似比較を想定していますし、FinBERT は金融文脈のセンチメント推定に向いています。[ACL Anthology+1](https://aclanthology.org/D19-1410/?utm_source=chatgpt.com)

* * *

3\. 記事→テーマ帰属
------------

ここがいちばん重要です。  
各記事  $d$  と各テーマ  $k$  に対して、次のスコアを作ります。

$$
A_{d,k} = w_1 \cdot \text{NameMatch}_{d,k} + w_2 \cdot \text{TickerMatch}_{d,k} + w_3 \cdot \cos(e_d, e_k^{theme}) + w_4 \cdot \max_{j \in \mathcal{C}_k}\cos(e_d, e_j^{firm})
$$

意味は次の通りです。

*   `NameMatch`: テーマ名や別名が記事に出たか
*   `TickerMatch`: 構成銘柄や企業名が出たか
*   `cos(e_d, e_k^theme)`: 記事とテーマ説明文の意味類似度
*   `max cos(e_d, e_j^firm)`: 記事がテーマ内のどの企業説明に一番近いか

この形にしておくと、  
**明示的一致** と **意味的一致** を両方使えます。  
ルールだけだと取りこぼし、埋め込みだけだと誤帰属が出るので、混ぜるのが実務上いちばん安定します。ニュースを type と tone で識別する重要性や、トピックを意味的に企業へ紐づける考え方とも整合的です。[NBER+2ACL Anthology+2](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

### 実装ルール

まずは hard assignment で十分です。

*   `argmax_k A_{d,k}` を記事の所属テーマにする
*   ただし `max_k A_{d,k} < τ` なら未所属にする

最初はこれでよいです。  
soft assignment は後で追加すれば足ります。

* * *

テーマ別ニュース特徴量
===========

ここは **最小6本** に絞るのがよいです。これ以上増やすと散らかります。

Feature 1. Volume
-----------------

その日にテーマへ帰属した記事件数です。

$$
Vol_{k,t} = \sum_{d \in \mathcal{D}_t} \mathbf{1}(A_{d,k}>\tau)
$$

ただし、生件数ではなく rolling z-score に変換して使います。

$$
VolZ_{k,t} = \frac{Vol_{k,t} - \mu_{k,t-60:t-1}}{\sigma_{k,t-60:t-1}}
$$

理由は、大型テーマは常に記事数が多いからです。  
比較したいのは「多いか」ではなく「いつもより異常に多いか」です。attention 指標を直接測る研究とも整合的です。[norges-bank.no+1](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952&utm_source=chatgpt.com)

* * *

Feature 2. Acceleration
-----------------------

ニュース量の立ち上がりです。

$$
Accel_{k,t} = \frac{\overline{Vol}_{k,t-4:t}}{\overline{Vol}_{k,t-24:t-5}+ \epsilon} - 1
$$

これは **盛り上がっているテーマ** ではなく、**いま盛り上がり始めたテーマ** を拾うための特徴量です。  
論文でこの式が固定されているわけではありませんが、attention の水準と変化を分けて扱うのは実務上自然です。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

* * *

Feature 3. Sentiment
--------------------

記事 sentiment のテーマ内平均です。

$$
Sent_{k,t} = \frac{\sum_d A_{d,k}\, s_d}{\sum_d A_{d,k} + \epsilon}
$$

ここで  $s_d$  は FinBERT のスコアです。  
重み付き平均にするのは、テーマに強く関連する記事をより効かせるためです。金融文脈では一般辞書より専用モデルの方が有効です。[arXiv+1](https://arxiv.org/abs/1908.10063?utm_source=chatgpt.com)

* * *

Feature 4. Breadth
------------------

テーマ内の広がりです。

$$
Breadth_{k,t} = \frac{\#\{j \in \mathcal{C}_k : j \text{ に関連する記事が当日ある}\}} {|\mathcal{C}_k|}
$$

これがかなり重要です。  
1社だけのニュースか、テーマ全体へ広がっているのかを分けるためです。テーマ選択では、個別銘柄材料ではなくテーマ全体への追い風を見たいので、件数だけでは足りません。ニューストピックを企業へリンクする発想を、テーマの構成銘柄集合へ拡張した指標です。[norges-bank.no](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952&utm_source=chatgpt.com)

* * *

Feature 5. Relevance-Weighted Volume
------------------------------------

関連度で重み付けした量です。

$$
RelVol_{k,t} = \sum_d A_{d,k}
$$

単純件数よりこちらの方が使いやすい場面が多いです。  
「テーマ名に一言だけ触れた記事」より、「そのテーマそのものの記事」を重くできるからです。SBERT のような意味類似検索を帰属スコアに使うなら、集計も重み付きにするのが自然です。[ACL Anthology](https://aclanthology.org/D19-1410/?utm_source=chatgpt.com)

* * *

Feature 6. Persistence
----------------------

ニュースショックの持続です。

$$
Persist_{k,t} = \sum_{h=0}^{4}\mathbf{1}(VolZ_{k,t-h} > c)
$$

直近5日で何日、異常件数状態が続いたかです。  
一過性のヘッドラインではなく、話題が継続しているテーマを拾います。Larsen and Thorsrud はニューストピックの予測力と持続性を示しています。[norges-bank.no](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952&utm_source=chatgpt.com)

* * *

ここまでをそのまま実装に落とすと
================

入力
--

*   `themes.csv/json`
    *   theme\_name
    *   theme\_description
    *   aliases
    *   constituents
    *   constituent\_descriptions
*   `news.parquet/csv`
    *   article\_id
    *   published\_at
    *   headline
    *   body
    *   source

中間生成物
-----

*   `article_features.parquet`
    *   article\_id
    *   doc\_embedding
    *   sentiment\_score
    *   mentioned\_tickers
*   `article_theme_scores.parquet`
    *   article\_id
    *   theme\_id
    *   assignment\_score
    *   assigned\_flag

出力特徴量
-----

*   `theme_daily_features.parquet`
    *   date
    *   theme\_id
    *   vol
    *   vol\_z
    *   accel
    *   sent
    *   breadth
    *   rel\_vol
    *   persist

この粒度なら、バックテスト側は `theme_daily_features` を読むだけで済みます。

* * *

最終スコア
=====

最初は学習モデルを使わず、線形合成で十分です。

$$
Score_{k,t} = 0.30 \cdot Accel_{k,t} + 0.25 \cdot Breadth_{k,t} + 0.20 \cdot Sent_{k,t} + 0.15 \cdot VolZ_{k,t} + 0.10 \cdot Persist_{k,t}
$$

そして毎日または週次で、`Score` 上位のテーマを選びます。  
最初から複雑な学習器に行くより、まずこの形で動かし、あとで将来リターンを目的変数にして supervised ranking に移行する方がよいです。ニュースの type と tone を分けることが重要だという研究とも整合的です。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

* * *

これで十分、という最小実装
=============

散らからない最小構成はこれです。

採用するモジュール
---------

*   **帰属**: `ルール一致 + SBERT`
*   **トーン**: `FinBERT`
*   **集計特徴量**: `VolZ, Accel, Sent, Breadth, RelVol, Persist`
*   **選択**: 線形スコア上位

いったん捨てるもの
---------

*   BERTopic
*   LDA
*   未分類記事クラスタリング
*   一般辞書 sentiment
*   複雑な GNN や cross-encoder 再順位付け

これで十分に「実装可能で、学術的にも筋が良い」設計になります。

* * *

一言でまとめると
========

実装すべき手法は、**記事を既知テーマへスコア付きで割り当て、そのスコアを使ってテーマごとの日次ニュース量・加速度・トーン・広がりを集計し、最終的にランキングする**、これだけです。  
候補を増やすより、この一本を丁寧に作るほうが強いです。SBERT は帰属、FinBERT はトーン、Larsen–Thorsrud と Boudoukh らは「内容を分解して量とトーンを時系列化する」根拠として効きます。[norges-bank.no+3NBER+3ACL Anthology+3](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

必要なら次に、これをそのまま **Codex に渡せる実装指示書** の形にします。

---

**Sources:**

- [Which News Moves Stock Prices? A Textual Analysis](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)
- [Sentence Embeddings using Siamese BERT-Networks](https://aclanthology.org/D19-1410/?utm_source=chatgpt.com)
- [Working Paper 17/2017: Asset returns, news topics, and media ...](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952&utm_source=chatgpt.com)
- [FinBERT: Financial Sentiment Analysis with Pre-trained Language Models](https://arxiv.org/abs/1908.10063?utm_source=chatgpt.com)

## Prompt:
2026/4/14 21:14:18

main.ipynb

ファイル

\_\_init\_\_.py

Python

config.py

Python

embed.py

Python

io.py

Python

label\_store.py

Python

preprocess.py

Python

reporting.py

Python

theme\_assign.py

Python

topic\_model.py

Python

添付のプログラムを元に提案手法を実装してください。

## Response:
2026/4/14 21:14:20

添付コードの構成を確認して、最小変更で「テーマ帰属 + テーマ別ニュース特徴量 + ランキング」まで通るように実装へ寄せます。まずノートブックの流れと既存モジュールの責務を確認しています。

既存ノートブックは「埋め込みで既知テーマへ多ラベル付与 → residual をBERTopic」で完結しています。ここに、前に整理した本命部分である **ルール一致の併用・センチメント・テーマ日次特徴量・ランキング** を追加する形で拡張します。

実装自体はモジュール追加で進められています。次に、これがそのまま動くように **ノートブック側の実行フロー** を更新し、成果物をひとまとまりで返せる形にします。

> **Inspecting notebook file contents**
>
>
> **コード修正と機能追加の検討**
>
> 現在のプログラムにはティッカーなどが不足しているので、コードを修正して機能を追加する必要がありそうです。テーマ定義やスコアリング、感情分析を組み込むため、データの形式や互換性を確認しつつ、オプションの列を使ってテストを行なうのが良さそうです。モジュールの確認と修正が必要です。
>
> **計画と実装の確認**
>
> 設定ファイルや前処理、テーマ割り当て、レポート、ノートブックなどを更新する方向で進めようと思います。FinBERTを使いたいけれど、欠如時のフォールバックとして辞書方式も採用可能。テーマ割り当てや感情分析を追加し、モジュール化してコードをシンプルに保ちつつ柔軟性も持たせる予定です。
>
> **提案の実装と互換性の維持**
>
> BERTopicをそのままにして、新しい提案を追加する方向で進めます。テーマ割り当てのスコアリングを拡張し、既存の類似度スコアと組み合わせる方法を検討中。互換性を維持しつつ新しいルールスコア機能を追加し、ノートブックを調整します。
>
> **Building theme-related daily features and rankings**
>
>
> **モジュール作成とパッチ適用**
>
> 実際のファイルを慎重にパッチしながら、テーマ割り当ての補助モジュールも作成する必要があります。コードを丁寧に記述して、安全に実装を進める方が良さそうです。モジュールをうまく組み合わせてシステム全体が動作するようにしようと思います。
>
> **パッチ適用とモジュール作成**
>
>
> **スクリプト修正の実行**
>
> config.py、io.py、preprocess.py、theme_assign.py、reporting.py、__init__.py、そして場合によってはノートブックを修正する必要があります。それぞれのファイルをPythonスクリプトで適切に編集して、必要な変更を加えていこうと思います。慎重に進めて、全体の流れがちゃんと動作するようにします。
>
> **Modifying Python scripts for configuration and processing**
>
>
> **インポートの修正とパッケージ構造の調整**
>
> theme_assign.pyのインポートを修正し、相対インポートを使うべきですね。ノートブックのインポート方法も確認して、パッケージ構造が適切かチェックします。ユーザーが直接アップロードしたファイルをパッケージに整理するか、修正してインポートが機能するように対応します。
>
> **センチメント分析の依存関係修正**
>
> センチメント分析において、内部のインポート依存関係がないことを確認しました。これを修正して、パッチを適用します。
>
> **修正型インポートの適用**
>
>
> **構文エラーの確認**
>
> ファイルに構文エラーがないか確認する必要があります。`python -m py_compile` コマンドを使ってファイルをチェックして、エラーを見つけても修正できるようにします。
>
> **Pythonファイルの構文エラー検査**
>
>
> **前処理の確認**
>
> 前処理に問題がないか確認する必要があります。すべてが正しく設定されているかをチェックして、必要に応じて修正を行いましょう。
>
> **Inspecting preprocess script**
>
>
> **改行リテラルの修正**
>
> 改行のリテラルに問題があるようです。適切に修正を加えて、意図した通りに動作するように調整します。
>
> **修正ニューラインリテラル**
>
>
> **再度py_compileを実行する必要がある**
>
> 再度、py_compileを使ってコードを確認する必要がありますね。これで構文エラーがないかチェックできるので、再実行して問題がないか確かめます。
>
> **Pythonファイルのコンパイル実行**
>
>
> **整理してパッケージ構造を更新する必要がある**
>
> ノートブックのインポートパスとセル
>
> **更新ノートブックとパッケージの構造作成**
>
>
> **sentiment.pyが保存されていないか確認**
>
> あれ、sentiment.pyがうまく保存されていないかもしれませんね。ちゃんと保存されているか、`ls`コマンドでディレクトリを確認してみます。
>
> **確認ディレクトリ内のファイル一覧**
>
>
> **新しいノートブックを作成してプロジェクト構造を整える**
>
> どうやら、`sentiment.py`と`theme_features.py`が保存されていなかったようです。エラーがあったのかもしれません。再度ファイルを作成して、慎重に進めますね。ノートブックを新しく作成する方が手っ取り早そうです。`nbformat`を使って各セルを追加し、プロジェクト構造を整えましょう。
>
> **作成と更新によるPythonファイル生成**
>
>
> **プロジェクトの作成を続ける**
>
> 現在の状態から進めて、プロジェクトを作成する必要があります。次はプロジェクトの構成を決めて、それに基づいて作業を進めます。整理して、きちんと進める方法を考えますね。
>
> **Creating project from state and building notebook**
>
>
> **ラベルストアの確認と修正**
>
> ラベルストアの問題を確認する必要があります。ノートブック内で、`assigned_flag`を`over_threshold`に変更すると、元のカラムを上書きしてしまうかもしれません。既存の`over_threshold`と重複するので、`assigned_flag`を使えるようにラベルストアを修正する必要があります。パッチを当てて、パッケージと関連ファイルを再コンパイルします。
>
> **パッチを適用してlabel_store修正**
>
>
> **ノートブックセル14の修正**
>
> セル14の`rename`を削除する必要があります。これにより、誤った重複が避けられ、不要な変更を防げるはずです。修正後に動作確認を行って、期待通りに動作するか確認します。
>
> **ノートブックのセル14を更新**
>
>
> **煙突テスト実行とアーカイブ作成**
>
>
> **ZIPファイルの作成が必要**
>
> おそらく、何かの内容をまとめてZIPファイルにする必要がありそうです。この作業を進めるために、必要なファイルをまとめて圧縮する方法を考えます。
>
> **圧縮ファイルの作成と確認**
>
>
> 思考時間: 11m 26s

実装版をまとめました。元のパイプラインを残しつつ、以下を追加しています。

\_\_init\_\_

config

*   **テーマ帰属の強化**  
    既存の埋め込み類似度に加えて、**テーマ名・別名・構成銘柄のルール一致**を併用する `hybrid assignment score` を実装しました。ベースになった既存の類似度付与ロジックは `theme_assign.py` です。
    topic\_model
*   **FinBERT による記事センチメント**
*   **テーマ別日次特徴量**  
    `VolZ / Accel / Sent / Breadth / RelVol / Persist`
*   **テーマ日次ランキング**
*   既存の **residual → BERTopic** フローは維持

成果物はこちらです。

実装済みプロジェクト一式(zip)  
更新済みノートブック

主な追加・変更ファイルはこの中に入っています。

*   `src/news_theme_pipeline/sentiment.py`
*   `src/news_theme_pipeline/theme_features.py`
*   `src/news_theme_pipeline/theme_assign.py`
*   `src/news_theme_pipeline/config.py`
*   `src/news_theme_pipeline/io.py`
*   `src/news_theme_pipeline/preprocess.py`
*   `src/news_theme_pipeline/reporting.py`

補足です。今回は**コード実装まで**行っており、添付コードの既存構成に沿う形で組み込みましたが、**実データを使った通し実行まではしていません**。特に FinBERT モデル取得と、テーマ定義ファイル内の `aliases / constituents / constituent_descriptions` の有無は実行時に確認が必要です。既存コードの入出力前提は `config.py` と `io.py` に合わせています。

config

io

必要なら次に、**あなたの実際のテーマ定義 YAML/JSON の想定フォーマット**まで合わせて、すぐ走るように微調整します。

## Prompt:
2026/4/14 21:27:15

意味類似検索には SBERT、金融文脈のトーン推定には FinBERTが使われていますか？

## Response:
2026/4/14 21:27:17

実装ファイルを見て、SBERT と FinBERT が「設計上の想定」なのか「実際にコードで呼んでいる」のかを切り分けて確認します。

> **検証ツールの使用確認**
>
>
> **Clarifying SBERT vs. FinBERT usage**
>
> 「使われていますか？」の質問に対して、更新版ではSBERTとFinBERTの両方を使用しています。ただし、最初のコードにはSBERTのみが含まれており、私が実装を追加してFinBERTを組み込みました。更新版に関する情報は、元ファイルの引用ではなく、新しい実装に基づいて回答します。
>
> 思考時間: 44s

はい。**更新版の実装**では、

*   **意味類似検索に SBERT**
*   **金融文脈のトーン推定に FinBERT**  
    を使う形にしています。

切り分けるとこうです。

**元の添付コード**

*   SBERT は使われています。`embed.py` で `SentenceTransformer` を読み込み、埋め込みを作る実装です。
    embed
*   既定の埋め込みモデル名も `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` です。
    config
*   一方で、**元の添付コードには FinBERT は入っていません**。元コードの `theme_assign.py` は類似度ベースの割当だけです。
    theme\_assign

**私が返した更新版**

*   SBERT はそのまま利用しています。
*   そこに **FinBERT ベースの sentiment 推定** を追加しました。設定名は `ProsusAI/finbert` にしてあり、ノートブックでも sentiment ステップを呼ぶようにしています。

なので、正確には  
**「元コードは SBERT のみ」**  
**「更新版は SBERT + FinBERT」**  
です。

必要なら次に、`main_implemented.ipynb` のどのセルで

1.  SBERT 埋め込み
2.  FinBERT sentiment
3.  テーマ特徴量生成  
    をやっているか、セル順に抜き出して示します。

## Prompt:
2026/4/14 21:32:04

お願いします。加えて、各処理フローで何が行われているか順を追って説明し、学術的な説明も付け加えて

## Response:
2026/4/14 21:32:06

ノートブックと主要モジュールの対応を、セル順と処理順でたどれる形にします。あわせて、各処理がどの学術的発想に対応するかも付けます。

> **Inspecting project files and processing flow**
>
> I need to check if I can access the original notebook, not the zipped version, to inspect its cells. The user wants details about the flow, so maybe I should explain the module flow instead of citing exact cells. Since the artifact is accessible, I can mention its path without needing citations.
>
> **確認するためにコンテナでノートブックを開く**
>
> もし内容について正確であるなら、サンドボックスから引用できるかもしれませんが、難しいです。そのため、「生成されたノートブックにおいて」と透明に述べる方が良いかもしれません。代わりに、コンテナを使用してセル構造を抽出してみます。
>
> **ノートブックセルの内容確認**
>
>
> **プロジェクトに追加されたファイルの確認**
>
> 追加されたファイルをプロジェクト内で確認する必要があるかもしれません。コンテナを使用して、詳細をチェックしてみます。
>
> **ファイルの内容確認と表示**
>
>
> **学術的な参考文献の確認**
>
> 現在の日付では必要ないかもしれませんが、引用は必要です。以前のように公式の論文を探して、SBERT、FinBERT、Boudoukh、Larsen、BERTopicのドキュメントを調べてみます。それらの文献を確認すれば、必要な情報を手に入れるはずです。
>
> **学術論文と公式資料の検索**
>
> [Sentence Embeddings using Siamese BERT-Networks](https://arxiv.org/abs/1908.10084)
> [Which News Moves Stock Prices? A Textual Analysis](https://www.nber.org/papers/w18725)
> [Asset returns, news topics, and media effects* - Larsen](https://onlinelibrary.wiley.com/doi/10.1111/sjoe.12469)
> [WHICH NEWS MOVES STOCK PRICES? A TEXTUAL ...](https://www.stern.nyu.edu/sites/default/files/assets/documents/con_038156.pdf)
> [Asset returns, news topics, and media effects](https://econpapers.repec.org/RePEc%3Abny%3Awpaper%3A0054)
> [Working Paper 17/2017: Asset returns, news topics, and media ...](https://www.norges-bank.no/contentassets/b19465af1c824d478493f22c4623f731/working_paper_17_17.pdf?v=20092017120952)
> [Which News Moves Stock Prices? A Textual Analysis](https://ideas.repec.org/p/nbr/nberwo/18725.html)
> [Self-Guided Contrastive Learning for BERT Sentence ...](https://aclanthology.org/2021.acl-long.197.pdf)
> [FinBERT: Financial Sentiment Analysis with Pre-trained ...](https://www.researchgate.net/publication/335441873_FinBERT_Financial_Sentiment_Analysis_with_Pre-trained_Language_Models)
> [[PDF] Asset Returns, News Topics, and Media Effects](https://www.semanticscholar.org/paper/9f1db17b90c1713da792e254905dd5eb22bb3e84)
> [Exploring Multiple Negative Ranking Losses for Sentence ...](https://www.techrxiv.org/doi/10.36227/techrxiv.23950530)
>
> **元のファイルでの関連する行の確認**
>
> 元のファイルから必要な行を確認する必要があるかもしれません。行の引用のために、mclickを使って調べてみます。それで、正確な参照ができるようにします。
>
> **ノートブックのセルマッピングと学術的説明**
>
> まず、元のアップロードモジュールにはSBERTのみが含まれていて、生成されたノートブックではFinBERTと特徴/ランキングが追加された点を述べます。その後、セル0-15の内容と各セルが実行する機能をリスト化し、モジュールファイルと関数を明記します。必要に応じて、生成されたノートブックに関しては引用せずに記述します。學術的な説明にはウェブで適切な引用を加えます。
>
> **ウェブ検索に基づく引用必須の記述**
>
> ウェブ検索を一度行ったので、インターネットに基づくすべての記述に引用が必要です。ただし、引用を多くしすぎないように注意。重要な段落としては、SBERTの意味論的検索やコサイン類似度の理由、FinBERTやBoudoukhの理論、Larsen/Thorsrudによるトピック時系列について触れ、もしBERTopicについて言及するなら、それに関する学術的な根拠を探す必要もあります。
>
> **生成されたノートブックのセルと説明**
>
> [BERTopic: Neural topic modeling with a class-based TF-IDF procedure](https://arxiv.org/abs/2203.05794)
> [5. c-TF-IDF - BERTopic](https://maartengr.github.io/BERTopic/getting_started/ctfidf/ctfidf.html)
> [Neural topic modeling with a class-based TF-IDF procedure](https://ar5iv.labs.arxiv.org/html/2203.05794)
> [BERTopic - Advanced Transformer-Based Topic Modeling](https://bertopic.com/)
> [Neural topic modeling with a class-based TF-IDF procedure](https://www.semanticscholar.org/paper/BERTopic%3A-Neural-topic-modeling-with-a-class-based-Grootendorst/5493aefc07e331045be76003ea516aef57f76cb9)
> [BERTopic — BERTopic latest documentation](https://bertopic.readthedocs.io/)
> [BERTopic - Neural topic modeling with a class-based TF-IDF ...](https://www.youtube.com/watch?v=-VOG2esUc6I)
> [MaartenGr/BERTopic: Leveraging BERT and c-TF-IDF to ...](https://github.com/maartengr/bertopic)
> [Neural topic modeling with a class-based TF-IDF procedure](https://www.zotero.org/groups/1332658/items/ZP4TD63G)
> [Grootendorst, M. (2022) BERTopic Neural Topic Modeling ...](https://www.scirp.org/reference/referencespapers?referenceid=3865663)
> [BERTopic – Advanced Transformer Topic Modeling](https://bertopic.org/)
> [Neural topic modeling with a class-based TF-IDF procedure](https://huggingface.co/papers/2203.05794)
> [Topic Modeling with BERT. | TDS Archive](https://medium.com/data-science/topic-modeling-with-bert-779f7db187e6)
> [Neural topic modeling with a class-based TF-IDF procedure](https://www.researchgate.net/publication/359208013_BERTopic_Neural_topic_modeling_with_a_class-based_TF-IDF_procedure)
>
> 思考時間: 1m 14s

はい。生成した `main_implemented.ipynb` では、**SBERT はセル 4–5、FinBERT はセル 6** で使う流れにしてあります。以下、**セル順**に「何をしているか」と「なぜそうするのか」をまとめます。元の添付コードで確認できる部分はファイル引用を付け、追加した実装部分は生成したノートブック／追加モジュールに基づいて説明します。元コードでは、前処理で `title + summary + body_short` を結合した `text_for_embedding` を作り、`SentenceTransformer` で埋め込みを計算し、コサイン類似度に相当する内積でテーマ類似度を出す構成になっています。

preprocess

embed

theme\_assign

ノートブックの処理フロー
------------

### セル 0: 環境確認と import

ここでは、パッケージ import と `PROJECT_ROOT` 設定を行います。  
役割は単純で、以降のセルが同じディレクトリ前提で再現可能に動くようにすることです。

### セル 1: config 読み込み

ここで `build_default_config()` と `ensure_directories()` を呼びます。  
元コードの `PipelineConfig` は、ニュース入力、テーマ定義、埋め込みキャッシュ、スコア表、assignment 表、residual topic 表、可視化出力先までを一括管理する設計です。`EMBEDDING_MODEL_NAME` の既定値は `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` です。

config

**学術的な意味**  
この段階自体に学術的中身はありませんが、実証研究で重要な **再現性** の基盤です。テキスト研究は前処理や出力先の差で結果がぶれやすいので、設定一元化は実務でもかなり重要です。

### セル 2: 入力ニュース・テーマ定義読み込み

ここで `load_articles_csv()` と `load_theme_definitions()` を使って、記事とテーママスタを読み込みます。元コードでは、記事に `article_id, published_at, source, title, summary, body, url` を要求し、テーマ定義には最低限 `theme_id, name_ja, description, threshold` を要求します。

io

生成版ではここを少し拡張して、テーマ定義に

*   `aliases`
*   `keywords`
*   `constituents`
*   `constituent_descriptions`  
    も入れられるようにしています。これは後で**ルール一致**と**テーマ内 breadth**を作るためです。

**学術的な意味**  
ここで「テーマ名」だけでなく「説明文」や「構成銘柄説明」も持つのは重要です。ニュースを単なる社名一致ではなく、**内容の近さ**で結びつける発想は、Larsen–Thorsrud がニューストピックを企業説明文へ意味的にリンクする枠組みと整合的です。[Wiley Online Library+1](https://onlinelibrary.wiley.com/doi/10.1111/sjoe.12469?utm_source=chatgpt.com)

### セル 3: 前処理

`build_text_for_embedding()` で、`title + summary + body_short` を結合して `text_for_embedding` を作ります。本文は `MAX_BODY_CHARS` で切っています。元コードの実装はそのままこれです。

preprocess

生成版では加えて、テーマ側にも `theme_reference_text` を作ります。  
これは

*   テーマ名
*   説明文
*   alias
*   keyword
*   構成銘柄
*   構成銘柄説明  
    を連結した、**テーマの参照テキスト**です。

**学術的な意味**  
ここでやっているのは、記事とテーマを同じテキスト空間に載せるための整形です。後段の意味類似検索は、表層語ではなく**文脈を含む文ベクトル**で比較する前提なので、この参照テキスト設計がかなり重要です。SBERT は、文や短文をコサイン類似度で比較できるようにした sentence embedding モデルで、semantic search を強く意識して作られています。[arXiv+1](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)

### セル 4: 記事 embedding 生成

ここで `load_embedding_model()` と `generate_embeddings_with_cache()` を呼びます。  
元コードでは `SentenceTransformer(model_name)` を読み、`model.encode(..., normalize_embeddings=True)` で正規化済み embedding を作り、`article_embeddings.parquet` にキャッシュします。

embed

**ここが SBERT を使っている箇所です。**

**学術的な意味**  
SBERT は BERT をそのまま pairwise 比較に使うより、**文埋め込みを事前計算してコサイン類似度で高速検索できる**ことが強みです。テーマ選択では「ニュース本文 ↔ テーマ説明文」の大量比較が必要なので、この用途にかなり合っています。[arXiv+1](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)

### セル 5: テーマ embedding 生成

ここでは記事と同じ SBERT モデルで、今度はテーマ側の `theme_reference_text` を埋め込みます。  
元コードのテーマ埋め込みは `description` 中心でしたが、生成版では**テーマ説明 + aliases + keywords + 構成銘柄情報**まで含めています。

**学術的な意味**  
これは「クエリ」と「検索対象」を同一表現空間に入れる semantic retrieval の定石です。テーマ名だけでなく、周辺表現も一緒に埋め込むことで、ニュースにテーマ名が直接出なくても拾いやすくなります。SBERT の本来用途と一致しています。[arXiv](https://arxiv.org/abs/1908.10084?utm_source=chatgpt.com)

### セル 6: FinBERT によるセンチメント推定

ここで追加した `sentiment.py` の

*   `load_sentiment_pipeline(config.SENTIMENT_MODEL_NAME)`
*   `score_article_sentiment(...)`  
    を呼びます。モデル名は生成版で `ProsusAI/finbert` を想定しています。

**ここが FinBERT を使っている箇所です。**

実装上は、記事テキストを `transformers.pipeline("text-classification")` に流し、出力ラベルを

*   positive → 正スコア
*   negative → 負スコア
*   それ以外 → 0  
    へ写像して `sentiment_score` を作っています。

**学術的な意味**  
FinBERT は金融文脈向けに訓練された BERT 系 sentiment モデルで、一般用途モデルより金融テキストで良い性能を示したのが出発点です。金融ニュースでは、一般辞書や汎用 sentiment モデルだと文脈を外しやすいので、ここを FinBERT に寄せるのは自然です。[arXiv+1](https://arxiv.org/abs/1908.10063?utm_source=chatgpt.com)

### セル 7: 類似度 + ルール一致で hybrid assignment score を構築

ここが生成版の中心です。  
元コードは `build_similarity_scores()` により、記事 embedding とテーマ embedding の内積行列を作り、テーマごとの `similarity`, `threshold`, `over_threshold` を出しています。

theme\_assign

生成版ではこれに加えて、

*   テーマ名・別名一致
*   keyword 一致
*   構成銘柄名や ticker 一致  
    を `rule_score` として作り、

**assignment\_score = 類似度 + ルール一致の合成スコア**

にしています。さらに、どの構成銘柄がマッチしたかも `matched_constituents` として残しています。

**学術的な意味**  
ここでやっていることは、ニュースの **type** をまず見分ける工程です。Boudoukh らは、価格に効くのは単なる tone だけでなく、**どんな種類のニュースか**を正しく識別することだと示しています。つまり、センチメントだけ先に測るのではなく、「そもそもこのニュースはこのテーマの話なのか」を先に詰めるのが正しいです。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

### セル 8: 多ラベル付与

ここでは、各記事について `assignment_score` が閾値を超えたテーマを `theme_ids` にまとめます。  
元コードの `assign_multilabels()` は、`over_threshold` なテーマを similarity 順に集め、0 件なら `unclassified=True` にします。さらに `apply_assignment_overrides()` で manual / BERTopic 昇格ラベルを上書きできます。

theme\_assign

生成版でも基本思想は同じで、**1記事→複数テーマ** を許しています。たとえば「AI 半導体と電力需要」の記事が、AI と電力インフラの両方に乗る余地を残します。

**学術的な意味**  
ニュースは単一ラベルとは限らないので、多ラベル化は実務上自然です。特にテーマ投資では、サプライチェーンや隣接テーマにまたがる記事が多いので、この設計は重要です。

### セル 9: テーマ別ニュース特徴量とランキング

ここで追加した `theme_features.py` を使い、日次テーマ特徴量を作ります。計算している主な列は次です。

*   `article_count`
*   `rel_vol` = assignment score の合計
*   `sentiment` = relevance-weighted sentiment
*   `mean_similarity`
*   `mean_rule_score`
*   `breadth` = 当日ヒットした構成銘柄数 / テーマ構成銘柄総数
*   `vol_z`
*   `accel`
*   `persist`
*   `theme_rank_score`

そして最後に

$$
0.30\cdot accel + 0.25\cdot breadth + 0.20\cdot sentiment + 0.15\cdot vol\_z + 0.10\cdot persist
$$

で `theme_rank_score` を作り、日次で順位付けしています。

**学術的な意味**  
ここは、これまでの議論を「実務で回る特徴量」に落とした部分です。

*   `vol_z` と `accel` は attention の水準と立ち上がり
*   `sentiment` は tone
*   `breadth` はテーマ全体への広がり
*   `persist` は話題の持続  
    を表します。

Boudoukh らの **type と tone**、Larsen–Thorsrud の **ニューストピック時系列**、その両方の発想を既知テーマ選択に移した形です。単なる件数や sentiment 単独より、こうした分解のほうが理にかなっています。[NBER+2Wiley Online Library+2](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

### セル 10: residual 抽出

ここでは `unclassified=True` の記事だけを取り出します。  
つまり、「既知テーマのどれにも十分には乗らなかった記事群」です。

**学術的な意味**  
今回の主目的は既知テーマ選択ですが、実務では未分類を捨てずに監視するのが大切です。既知テーマの辞書や reference text が弱いのか、本当に周辺ノイズなのかを後で点検できます。

### セル 11: BERTopic 実行

元コードの `topic_model.py` では、residual 記事に対して

*   UMAP
*   HDBSCAN
*   BERTopic  
    でトピックを作り、topic keywords、representative docs、outliers を保存します。実装上も `_build_topic_model()` で UMAP と HDBSCAN を設定し、`BERTopic(..., calculate_probabilities=True)` を使っています。
    topic\_model
    topic\_model

**学術的な意味**  
BERTopic は、transformer embeddings をクラスタリングし、最後に c-TF-IDF で topic 表現を作る方法です。今回の用途では主役ではありませんが、**未分類記事の監査・整理**にはかなり相性が良いです。[arXiv+2ar5iv+2](https://arxiv.org/abs/2203.05794?utm_source=chatgpt.com)

### セル 12: outlier 保存・週次再クラスタリング

元コードには、outlier を週次ウィンドウで再クラスタリングする `recluster_outliers_weekly()` があります。`rolling_4w` なら直近4週間、`cumulative` なら累積で再整理します。

**学術的な意味**  
これは既知テーマ選択の本体ではなく、監査・保守運用のための補助です。ニュースの未分類率が高い時、テーマ定義の不足なのか、単発ノイズなのかを見るのに使います。

### セル 13: 教師データ保存

元コードの `build_label_store()` は、

*   高信頼 similarity
*   BERTopic から昇格したラベル
*   manual label  
    を優先順位付きで統合し、`labels_long` と `labels_wide` を作ります。

**学術的な意味**  
これは将来 SetFit などの教師あり多ラベル分類へ移るための布石です。最初は弱教師ありで回し、あとから教師ありへ移行する設計です。

### セル 14: 集計・可視化

元コードの `reporting.py` は、

*   テーマ別件数
*   未分類率
*   既知テーマ件数の時系列
*   residual topic 件数
*   outlier 件数  
    を作図します。
    reporting

生成版ではこれに加え、**theme rank score の時系列**も出すようにしています。

**学術的な意味**  
これはモデル評価の入口です。テーマ選択では、どのテーマがどの日に上がったかだけでなく、未分類率や breadth の挙動を見ることで、帰属器の質を確認できます。

### セル 15: サマリー

最後に件数や主要出力パスを辞書でまとめて表示します。  
ここは運用確認用です。

どこで SBERT と FinBERT が使われているか
----------------------------

簡潔に言うと、こうです。

*   **SBERT**  
    セル 4 で記事 embedding、セル 5 でテーマ embedding を作るために使っています。元コード側でも `SentenceTransformer` と `normalize_embeddings=True` が実装されています。
*   **FinBERT**  
    セル 6 で記事ごとの `sentiment_score` を作るために使っています。これは生成版で追加した部分です。
*   **両者の役割分担**  
    SBERT は **「何のテーマの話か」** を測り、FinBERT は **「その話が強気か弱気か」** を測っています。この分離は、金融ニュースでは news type と news tone を分けるべきだという文献と一致します。[NBER+1](https://www.nber.org/papers/w18725?utm_source=chatgpt.com)

いちばん大事なポイント
-----------

この実装の本体は、BERTopic ではなく、

**記事 → テーマ帰属（SBERT + ルール） → テーマ日次特徴量（FinBERT を含む） → テーマ順位付け**

です。  
BERTopic は residual 管理の補助です。

必要なら次に、`main_implemented.ipynb` の各セルを**そのままコード断片つきで**追えるように、セル番号ごとの要約表を作ります。

## Prompt:
2026/4/14 21:39:16

spacyは使われていますか？

## Response:
2026/4/14 21:39:19

> 思考時間: 2 ～ 3 秒

いいえ、**少なくとも元の添付コードでは spaCy は使われていません**。確認できるモジュールは、

*   `sentence_transformers`（SBERT 用）
    embed
*   `bertopic`, `umap`, `hdbscan`（residual topic 用）
    topic\_model
*   `pandas`, `numpy`, `matplotlib` など

で、提示されたソース群に `spacy` の import はありません。

私が提案した更新版でも、基本方針は

*   **SBERT で意味類似**
*   **FinBERT でセンチメント**
*   **ルール一致は Python の文字列処理ベース**  
    を想定しており、**spaCy を必須にはしていません**。

ただし、spaCy を入れる余地はあります。使うとすると主に次です。

*   **企業名抽出 / 固有表現抽出** を少し丁寧にやる
*   **ティッカーや銘柄名の表記ゆれ吸収**
*   **日本語の形態素単位のキーワード一致** を改善する

一方で、今回の実装方針では必須ではありません。  
既知テーマ帰属の主役は **SBERT 類似度 + テーマ辞書/銘柄辞書一致** なので、まずは spaCy なしで十分です。

必要なら次に、**spaCy を入れるとどの処理がどう改善するか** を、実装差分ベースで整理します。

## Prompt:
2026/4/14 21:42:08

テーマ説明へのラベル付与はどのようにしていますか

## Response:
2026/4/14 21:42:11

> 思考時間: 8s

この実装では、**「テーマ説明そのものに別途ラベルを学習して付与する」ことはしていません**。  
役割は次のように分かれています。

*   **テーマ側**: すでに与えられた教師情報
*   **記事側**: そのテーマに属するかどうかを判定してラベル付与

つまり、`theme_id / name_ja / description / threshold` を持つテーマ定義ファイルがまずあり、ここで **テーマ説明は“ラベル付け対象”ではなく、“ラベルの基準”** になっています。`load_theme_definitions()` でも、テーマ定義の必須項目は `theme_id, name_ja, description, threshold` です。

io

流れとしてはこうです。

### 1\. テーマ説明を埋め込み化する

テーマ定義の `description` を使って、テーマごとの embedding を作ります。  
元コードでは `SentenceTransformer` を使って埋め込みを生成する前提で、記事にもテーマにも同じ embedding モデルを当てる構成です。

### 2\. 記事との類似度を計算する

`build_similarity_scores()` で、**記事 embedding × テーマ embedding** の行列積を取り、各記事について各テーマとの `similarity` を計算しています。ここで `theme_id` と `theme_name_ja` が付与され、各テーマごとに `threshold` を超えたかどうかも判定されます。

theme\_assign

### 3\. 閾値を超えたテーマを記事ラベルにする

`assign_multilabels()` では、各記事について `over_threshold=True` のテーマを集めて `theme_ids` にしています。  
つまり、**テーマ説明は記事ラベルを付けるための参照文**として使われています。テーマ説明自体に新しいラベルを付けているわけではありません。

theme\_assign

### 4\. 最後にラベルストアへ保存する

`build_label_store()` では、`scores_df` のうち閾値超えかつ高信頼な `article_id - theme_id` の組を `similarity_high_conf` として保存します。ここでも保存されるのは **記事に対するテーマラベル** です。

label\_store

要するに、この実装の「ラベル付与」は

*   **テーマ説明 → ラベル付与される対象ではない**
*   **記事 → テーマ説明との類似度で theme\_id ラベルが付く**

という構造です。

数式で書くと、記事  $d$  とテーマ  $k$  の間で

$$
\text{similarity}(d,k)= e_d^\top e_k
$$

を計算し、これがテーマごとの閾値  $\tau_k$  を超えたら、その記事にテーマ  $k$  のラベルを付けます。元コードでは `over_threshold = similarity >= threshold` です。

theme\_assign

なので、質問に直接答えると、

**テーマ説明へのラベル付与はしていません。テーマ説明は、記事へ `theme_id` ラベルを付けるための基準テキストとして使っています。**

必要なら次に、  
**「description だけで十分か、それとも alias・keywords・構成銘柄説明まで混ぜるべきか」**  
を実装観点で整理します。

## Prompt:
2026/4/14 21:43:56

テーマ定義の内訳を教えて

## Response:
2026/4/14 21:44:00

> 思考時間: 2 ～ 3 秒

元の添付コードで、**テーマ定義として必須なのは4項目**です。

*   `theme_id`
*   `name_ja`
*   `description`
*   `threshold`
    io

`io.py` の `REQUIRED_THEME_COLUMNS` がこれを明示しており、`load_theme_definitions()` でもこの4つが存在しないとエラーになります。さらに型変換として、

*   `theme_id`: 文字列化
*   `name_ja`: 文字列化
*   `description`: 欠損を空文字にして文字列化
*   `threshold`: 数値化

を行っています。`threshold` は数値でないとエラーになります。

io

それぞれの意味
-------

### `theme_id`

内部的な一意キーです。  
記事へのラベル付与、集計、保存テーブルではこの `theme_id` が主キーとして使われます。たとえば `build_similarity_scores()` や `assign_multilabels()` でも、最終的に記事へ付くのは `theme_id` です。

theme\_assign

### `name_ja`

日本語のテーマ表示名です。  
主に可読性のためで、スコア表では `theme_name_ja` として保存されています。

theme\_assign

### `description`

テーマ説明文です。  
これが**テーマの意味表現の中核**で、記事本文と意味類似度を取るときの参照テキストになります。元コードは description を持つテーマ定義を読み込み、テーマ側の埋め込みを作って記事埋め込みと比較する前提です。

### `threshold`

そのテーマに記事を割り当てるときの閾値です。  
`build_similarity_scores()` では、各記事×各テーマの `similarity` を計算し、`similarity >= threshold` なら `over_threshold=True` になります。`USE_THEME_SPECIFIC_THRESHOLD=True` のときはテーマごとの `threshold` を使い、そうでなければ `DEFAULT_THRESHOLD` を使います。

元コード上のテーマ定義の役割
--------------

要するに、元のテーマ定義は

*   **識別子**: `theme_id`
*   **表示名**: `name_ja`
*   **意味内容**: `description`
*   **判定基準**: `threshold`

の4層です。  
かなりミニマルな設計です。

io

私が拡張を提案した内訳
-----------

前に提案した実装方針では、実務上はこの4項目に加えて次を持つと強いです。

*   `aliases`  
    テーマの別名、略称、言い換え
*   `keywords`  
    そのテーマを表す代表語
*   `constituents`  
    構成銘柄一覧
*   `constituent_descriptions`  
    各構成銘柄の事業説明

ただし、**これは元の添付コードの必須仕様ではありません**。元コードとして本当に要求されているのはあくまで  
`theme_id / name_ja / description / threshold`  
の4つです。

io

必要なら次に、**この4項目だけで作る最小の theme\_definitions.yaml の具体例** を示します。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)