"""金融ニュース向けセンチメント推定。"""

from __future__ import annotations

import numpy as np
import pandas as pd


def load_sentiment_pipeline(model_name: str, device: int = -1):
    from transformers import pipeline
    return pipeline(
        task="text-classification",
        model=model_name,
        tokenizer=model_name,
        truncation=True,
        max_length=512,
        device=device,
    )


FINBERT_POSITIVE = {"positive", "pos", "bullish", "label_2"}
FINBERT_NEGATIVE = {"negative", "neg", "bearish", "label_0"}


def _map_label_score(label: str, score: float) -> float:
    normalized = str(label).strip().lower()
    if normalized in FINBERT_POSITIVE:
        return float(score)
    if normalized in FINBERT_NEGATIVE:
        return -float(score)
    return 0.0


def score_article_sentiment(df: pd.DataFrame, text_col: str, sentiment_pipe, batch_size: int = 16) -> pd.DataFrame:
    if text_col not in df.columns:
        raise ValueError(f"必須カラム不足: {text_col}")

    work = df.copy()
    texts = work[text_col].fillna("").astype(str).tolist()
    labels = []
    confidences = []
    scores = []
    for start in range(0, len(texts), batch_size):
        outputs = sentiment_pipe(texts[start:start+batch_size])
        if isinstance(outputs, dict):
            outputs = [outputs]
        for out in outputs:
            label = str(out.get("label", "neutral"))
            confidence = float(out.get("score", 0.0))
            labels.append(label)
            confidences.append(confidence)
            scores.append(_map_label_score(label, confidence))
    work["sentiment_label"] = labels
    work["sentiment_confidence"] = confidences
    work["sentiment_score"] = np.array(scores, dtype=float)
    return work
