"""SetFit 移行用ラベルストア。"""

from __future__ import annotations

from datetime import datetime, timezone

import pandas as pd


LABEL_SOURCE_PRIORITY = {
    "manual": 3,
    "bertopic_promoted": 2,
    "similarity_high_conf": 1,
}



def build_label_store(
    articles_df: pd.DataFrame,
    themes_df: pd.DataFrame,
    scores_df: pd.DataFrame,
    min_high_confidence: float,
    bertopic_promoted_df: pd.DataFrame | None = None,
    manual_labels_df: pd.DataFrame | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    now = datetime.now(timezone.utc).isoformat()

    records: list[dict[str, object]] = []

    positive_flag_col = "assigned_flag" if "assigned_flag" in scores_df.columns else "over_threshold"
    high_conf = scores_df[
        (scores_df[positive_flag_col])
        & (scores_df["similarity"] >= float(min_high_confidence))
    ][["article_id", "theme_id"]].copy()

    for _, row in high_conf.drop_duplicates().iterrows():
        records.append(
            {
                "article_id": row["article_id"],
                "theme_id": row["theme_id"],
                "label": 1,
                "label_source": "similarity_high_conf",
                "created_at": now,
            }
        )

    if bertopic_promoted_df is not None and not bertopic_promoted_df.empty:
        if {"article_id", "theme_id"}.issubset(bertopic_promoted_df.columns):
            for _, row in bertopic_promoted_df[["article_id", "theme_id"]].drop_duplicates().iterrows():
                records.append(
                    {
                        "article_id": row["article_id"],
                        "theme_id": row["theme_id"],
                        "label": 1,
                        "label_source": "bertopic_promoted",
                        "created_at": now,
                    }
                )

    if manual_labels_df is not None and not manual_labels_df.empty:
        if {"article_id", "theme_id"}.issubset(manual_labels_df.columns):
            use_cols = ["article_id", "theme_id"]
            has_label = "label" in manual_labels_df.columns
            if has_label:
                use_cols.append("label")

            for _, row in manual_labels_df[use_cols].iterrows():
                label = int(row["label"]) if has_label else 1
                records.append(
                    {
                        "article_id": row["article_id"],
                        "theme_id": row["theme_id"],
                        "label": label,
                        "label_source": "manual",
                        "created_at": now,
                    }
                )

    labels_long = pd.DataFrame(records)
    if labels_long.empty:
        labels_long = pd.DataFrame(columns=["article_id", "theme_id", "label", "label_source", "created_at"])

    if not labels_long.empty:
        labels_long["source_priority"] = labels_long["label_source"].map(LABEL_SOURCE_PRIORITY).fillna(0)
        labels_long = labels_long.sort_values(["article_id", "theme_id", "source_priority"], ascending=[True, True, False])
        labels_long = labels_long.drop_duplicates(subset=["article_id", "theme_id"], keep="first")
        labels_long = labels_long.drop(columns=["source_priority"])

    labels_long = labels_long.merge(
        articles_df[["article_id", "text_for_embedding"]].rename(columns={"text_for_embedding": "text"}),
        on="article_id",
        how="left",
    )

    labels_long = labels_long[["article_id", "text", "theme_id", "label", "label_source", "created_at"]]

    all_theme_ids = themes_df["theme_id"].astype(str).tolist()

    base = articles_df[["article_id", "text_for_embedding"]].rename(columns={"text_for_embedding": "text"}).copy()

    if labels_long.empty:
        for theme_id in all_theme_ids:
            base[theme_id] = 0
        return labels_long, base

    positive = labels_long[labels_long["label"] == 1].copy()
    indicator = (
        positive.assign(value=1)
        .pivot_table(index="article_id", columns="theme_id", values="value", aggfunc="max", fill_value=0)
        .reset_index()
    )

    labels_wide = base.merge(indicator, on="article_id", how="left").fillna(0)

    for theme_id in all_theme_ids:
        if theme_id not in labels_wide.columns:
            labels_wide[theme_id] = 0

    value_cols = [col for col in labels_wide.columns if col not in {"article_id", "text"}]
    labels_wide[value_cols] = labels_wide[value_cols].astype(int)

    return labels_long, labels_wide
