"""BERTopic 処理。"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

import numpy as np
import pandas as pd
from bertopic import BERTopic
from umap import UMAP
from hdbscan import HDBSCAN


@dataclass
class TopicModelResult:
    residual_topics: pd.DataFrame
    residual_topic_keywords: pd.DataFrame
    residual_topic_representative_docs: pd.DataFrame
    residual_outliers: pd.DataFrame



def _build_topic_model(min_topic_size: int, nr_top_words: int, random_seed: int, n_samples: int) -> BERTopic:
    n_neighbors = max(2, min(15, n_samples - 1))
    n_components = max(2, min(5, n_samples - 1))

    umap_model = UMAP(
        n_neighbors=n_neighbors,
        n_components=n_components,
        metric="cosine",
        random_state=random_seed,
    )
    hdbscan_model = HDBSCAN(
        min_cluster_size=max(2, min(min_topic_size, n_samples)),
        metric="euclidean",
        prediction_data=True,
    )

    return BERTopic(
        embedding_model=None,
        top_n_words=nr_top_words,
        min_topic_size=min_topic_size,
        umap_model=umap_model,
        hdbscan_model=hdbscan_model,
        calculate_probabilities=True,
        verbose=False,
    )



def run_residual_bertopic(
    residual_df: pd.DataFrame,
    residual_embeddings: np.ndarray,
    min_topic_size: int,
    nr_top_words: int,
    use_reduce_outliers: bool,
    random_seed: int,
) -> TopicModelResult:
    if residual_df.empty:
        empty_topics = pd.DataFrame(columns=["article_id", "published_at", "topic_id", "topic_probability", "reduced_topic_id"])
        empty_keywords = pd.DataFrame(columns=["topic_id", "topic_name", "keyword_rank", "keyword", "score"])
        empty_representatives = pd.DataFrame(columns=["topic_id", "representative_rank", "article_id", "title", "text_for_embedding"])
        empty_outliers = pd.DataFrame(columns=["article_id", "published_at", "topic_id", "reduced_topic_id", "text_for_embedding", "embedding"])
        return TopicModelResult(empty_topics, empty_keywords, empty_representatives, empty_outliers)

    docs = residual_df["text_for_embedding"].fillna("").astype(str).tolist()
    n_samples = len(docs)

    if n_samples < 3:
        residual_topics = residual_df[["article_id", "published_at"]].copy()
        residual_topics["topic_id"] = -1
        residual_topics["topic_probability"] = float("nan")
        residual_topics["reduced_topic_id"] = -1

        residual_outliers = residual_topics.merge(
            residual_df[["article_id", "published_at", "text_for_embedding"]],
            on=["article_id", "published_at"],
            how="left",
        )
        residual_outliers["embedding"] = [vec.astype(float).tolist() for vec in residual_embeddings]

        return TopicModelResult(
            residual_topics=residual_topics,
            residual_topic_keywords=pd.DataFrame(columns=["topic_id", "topic_name", "keyword_rank", "keyword", "score"]),
            residual_topic_representative_docs=pd.DataFrame(
                columns=["topic_id", "representative_rank", "article_id", "title", "text_for_embedding"]
            ),
            residual_outliers=residual_outliers,
        )

    topic_model = _build_topic_model(
        min_topic_size=min_topic_size,
        nr_top_words=nr_top_words,
        random_seed=random_seed,
        n_samples=n_samples,
    )

    try:
        topics, probs = topic_model.fit_transform(docs, embeddings=residual_embeddings)
    except Exception:
        residual_topics = residual_df[["article_id", "published_at"]].copy()
        residual_topics["topic_id"] = -1
        residual_topics["topic_probability"] = float("nan")
        residual_topics["reduced_topic_id"] = -1

        residual_outliers = residual_topics.merge(
            residual_df[["article_id", "published_at", "text_for_embedding"]],
            on=["article_id", "published_at"],
            how="left",
        )
        residual_outliers["embedding"] = [vec.astype(float).tolist() for vec in residual_embeddings]

        return TopicModelResult(
            residual_topics=residual_topics,
            residual_topic_keywords=pd.DataFrame(columns=["topic_id", "topic_name", "keyword_rank", "keyword", "score"]),
            residual_topic_representative_docs=pd.DataFrame(
                columns=["topic_id", "representative_rank", "article_id", "title", "text_for_embedding"]
            ),
            residual_outliers=residual_outliers,
        )

    topic_probabilities: list[float] = []
    if probs is None:
        topic_probabilities = [float("nan")] * len(topics)
    else:
        prob_array = np.array(probs)
        if prob_array.ndim == 1:
            topic_probabilities = [float(x) for x in prob_array]
        else:
            topic_probabilities = [float(np.max(row)) for row in prob_array]

    residual_topics = residual_df[["article_id", "published_at"]].copy()
    residual_topics["topic_id"] = topics
    residual_topics["topic_probability"] = topic_probabilities
    residual_topics["reduced_topic_id"] = residual_topics["topic_id"]

    if use_reduce_outliers and (residual_topics["topic_id"] == -1).any():
        reduced = topic_model.reduce_outliers(
            docs,
            topics,
            probabilities=probs,
            strategy="probabilities",
        )
        residual_topics["reduced_topic_id"] = reduced

    topic_info = topic_model.get_topic_info()

    keyword_rows: list[dict[str, object]] = []
    for _, info_row in topic_info.iterrows():
        topic_id = int(info_row["Topic"])
        if topic_id == -1:
            continue

        topic_words = topic_model.get_topic(topic_id) or []
        for rank, (word, score) in enumerate(topic_words, start=1):
            keyword_rows.append(
                {
                    "topic_id": topic_id,
                    "topic_name": str(info_row.get("Name", "")),
                    "keyword_rank": rank,
                    "keyword": str(word),
                    "score": float(score),
                }
            )

    residual_topic_keywords = pd.DataFrame(keyword_rows)

    representative_rows: list[dict[str, object]] = []
    topic_doc_df = residual_topics.merge(
        residual_df[["article_id", "title", "text_for_embedding"]],
        on="article_id",
        how="left",
    )

    for topic_id, group in topic_doc_df[topic_doc_df["topic_id"] != -1].groupby("topic_id"):
        ordered = group.sort_values("topic_probability", ascending=False).head(3)
        for rank, (_, row) in enumerate(ordered.iterrows(), start=1):
            representative_rows.append(
                {
                    "topic_id": int(topic_id),
                    "representative_rank": rank,
                    "article_id": row["article_id"],
                    "title": row.get("title", ""),
                    "text_for_embedding": row.get("text_for_embedding", ""),
                }
            )

    residual_topic_representative_docs = pd.DataFrame(representative_rows)

    residual_outliers = residual_topics[residual_topics["topic_id"] == -1].merge(
        residual_df[["article_id", "published_at", "text_for_embedding"]],
        on=["article_id", "published_at"],
        how="left",
    )
    residual_outliers["embedding"] = [vec.astype(float).tolist() for vec in residual_embeddings[residual_topics["topic_id"] == -1]]

    return TopicModelResult(
        residual_topics=residual_topics,
        residual_topic_keywords=residual_topic_keywords,
        residual_topic_representative_docs=residual_topic_representative_docs,
        residual_outliers=residual_outliers,
    )



def recluster_outliers_weekly(
    outliers_df: pd.DataFrame,
    mode: str,
    lookback_weeks: int,
    min_topic_size: int,
    nr_top_words: int,
    random_seed: int,
) -> pd.DataFrame:
    if outliers_df.empty:
        return pd.DataFrame(
            columns=[
                "processing_week",
                "window_start",
                "window_end",
                "article_id",
                "recluster_topic_id",
                "source_mode",
            ]
        )

    work = outliers_df.copy()
    work["published_at"] = pd.to_datetime(work["published_at"])
    work["week_start"] = work["published_at"].dt.to_period("W").apply(lambda p: p.start_time)

    all_rows: list[dict[str, object]] = []
    weeks = sorted(work["week_start"].dropna().unique())

    for week in weeks:
        week_ts = pd.Timestamp(week)
        if mode == "cumulative":
            window_start = work["week_start"].min()
        else:
            window_start = week_ts - timedelta(weeks=max(1, lookback_weeks) - 1)

        window_df = work[(work["week_start"] >= window_start) & (work["week_start"] <= week_ts)].copy()
        window_end = week_ts

        if window_df.empty:
            continue

        docs = window_df["text_for_embedding"].fillna("").astype(str).tolist()
        embeddings = np.vstack(window_df["embedding"].apply(lambda x: np.array(x, dtype=float)).values)

        if len(window_df) < 3:
            topics = [-1] * len(window_df)
        else:
            try:
                topic_model = _build_topic_model(
                    min_topic_size=min_topic_size,
                    nr_top_words=nr_top_words,
                    random_seed=random_seed,
                    n_samples=len(window_df),
                )
                topics, _ = topic_model.fit_transform(docs, embeddings=embeddings)
            except Exception:
                topics = [-1] * len(window_df)

        for article_id, recluster_topic in zip(window_df["article_id"].tolist(), topics):
            all_rows.append(
                {
                    "processing_week": week_ts,
                    "window_start": pd.Timestamp(window_start),
                    "window_end": window_end,
                    "article_id": article_id,
                    "recluster_topic_id": int(recluster_topic),
                    "source_mode": mode,
                }
            )

    return pd.DataFrame(all_rows)
