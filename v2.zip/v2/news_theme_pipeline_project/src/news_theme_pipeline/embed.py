"""埋め込み生成とキャッシュ。"""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer



def _hash_text(text: str) -> str:
    return sha256(text.encode("utf-8")).hexdigest()



def load_embedding_model(model_name: str) -> SentenceTransformer:
    return SentenceTransformer(model_name)



def _to_numpy_vector(value: object) -> np.ndarray:
    if isinstance(value, np.ndarray):
        return value.astype(float)
    if isinstance(value, list):
        return np.array(value, dtype=float)
    return np.array([], dtype=float)



def _encode_texts(
    model: SentenceTransformer,
    texts: Iterable[str],
    batch_size: int = 32,
) -> np.ndarray:
    return model.encode(
        list(texts),
        batch_size=batch_size,
        normalize_embeddings=True,
        show_progress_bar=False,
        convert_to_numpy=True,
    )



def generate_embeddings_with_cache(
    df: pd.DataFrame,
    id_col: str,
    text_col: str,
    cache_path: Path,
    model: SentenceTransformer,
    batch_size: int = 32,
) -> tuple[pd.DataFrame, np.ndarray]:
    required_cols = {id_col, text_col}
    if not required_cols.issubset(df.columns):
        raise ValueError(f"必須カラム不足: {required_cols - set(df.columns)}")

    request_df = df[[id_col, text_col]].copy()
    request_df[text_col] = request_df[text_col].fillna("").astype(str)
    request_df["text_hash"] = request_df[text_col].map(_hash_text)

    cache_df = pd.DataFrame(columns=[id_col, "text_hash", "embedding"])
    if cache_path.exists():
        cache_df = pd.read_parquet(cache_path)
        for col in [id_col, "text_hash", "embedding"]:
            if col not in cache_df.columns:
                raise ValueError(f"キャッシュ形式が不正です: {cache_path} に {col} がありません")

    merged = request_df.merge(cache_df[[id_col, "text_hash", "embedding"]], on=[id_col, "text_hash"], how="left")
    missing_mask = merged["embedding"].isna()

    if missing_mask.any():
        target_texts = merged.loc[missing_mask, text_col].tolist()
        new_vectors = _encode_texts(model=model, texts=target_texts, batch_size=batch_size)

        new_df = merged.loc[missing_mask, [id_col, "text_hash"]].copy()
        new_df["embedding"] = [vec.astype(float).tolist() for vec in new_vectors]

        cache_df = pd.concat([cache_df, new_df], ignore_index=True)
        cache_df = cache_df.drop_duplicates(subset=[id_col, "text_hash"], keep="last")
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_df.to_parquet(cache_path, index=False)

        merged = request_df.merge(cache_df[[id_col, "text_hash", "embedding"]], on=[id_col, "text_hash"], how="left")

    vectors = np.vstack(merged["embedding"].map(_to_numpy_vector).values)
    result_df = merged[[id_col, "text_hash", "embedding"]].copy()
    return result_df, vectors
