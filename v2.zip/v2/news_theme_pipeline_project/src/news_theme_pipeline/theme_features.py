from __future__ import annotations

import numpy as np
import pandas as pd


def build_theme_daily_features(
    scored_assignments_df: pd.DataFrame,
    articles_df: pd.DataFrame,
    themes_df: pd.DataFrame,
    volume_lookback_days: int = 60,
    accel_short_days: int = 5,
    accel_long_days: int = 20,
    persist_days: int = 5,
    persist_z_threshold: float = 1.0,
) -> pd.DataFrame:
    """テーマ別日次ニュース特徴量を構築する。"""
    required_score_cols = {
        "article_id",
        "theme_id",
        "assignment_score",
        "assigned_flag",
        "similarity",
        "rule_score",
        "sentiment_score",
        "matched_constituents",
    }
    required_article_cols = {"article_id", "published_at"}
    required_theme_cols = {"theme_id", "constituents"}

    missing = required_score_cols - set(scored_assignments_df.columns)
    if missing:
        raise ValueError(f"scored_assignments_df に必須カラムが不足しています: {sorted(missing)}")
    missing = required_article_cols - set(articles_df.columns)
    if missing:
        raise ValueError(f"articles_df に必須カラムが不足しています: {sorted(missing)}")
    missing = required_theme_cols - set(themes_df.columns)
    if missing:
        raise ValueError(f"themes_df に必須カラムが不足しています: {sorted(missing)}")

    article_dates = articles_df[["article_id", "published_at"]].copy()
    article_dates["published_at"] = pd.to_datetime(article_dates["published_at"], errors="coerce")
    article_dates["date"] = article_dates["published_at"].dt.normalize()

    work = scored_assignments_df.copy()
    work = work[work["assigned_flag"]].copy()
    work = work.merge(article_dates[["article_id", "date"]], on="article_id", how="left")
    work = work[work["date"].notna()].copy()

    if work.empty:
        return pd.DataFrame(
            columns=[
                "date",
                "theme_id",
                "article_count",
                "rel_vol",
                "sentiment",
                "mean_similarity",
                "mean_rule_score",
                "breadth",
                "vol_z",
                "accel",
                "persist",
                "theme_rank_score",
            ]
        )

    def _sum_unique_constituents(series: pd.Series) -> int:
        seen: set[str] = set()
        for value in series:
            if isinstance(value, list):
                seen.update(str(x) for x in value if str(x))
        return len(seen)

    daily = (
        work.groupby(["date", "theme_id"], as_index=False)
        .agg(
            article_count=("article_id", "nunique"),
            rel_vol=("assignment_score", "sum"),
            sentiment_num=("assignment_score", lambda s: float(s.sum())),
            sent_weighted=("sentiment_score", lambda s: float(np.nanmean(s)) if len(s) else np.nan),
            mean_similarity=("similarity", "mean"),
            mean_rule_score=("rule_score", "mean"),
            matched_constituent_count=("matched_constituents", _sum_unique_constituents),
        )
        .sort_values(["theme_id", "date"])
    )

    # Recompute relevance-weighted sentiment correctly.
    sent_weighted = (
        work.assign(weighted_sent=work["assignment_score"] * work["sentiment_score"])
        .groupby(["date", "theme_id"], as_index=False)
        .agg(weighted_sent=("weighted_sent", "sum"), rel_vol=("assignment_score", "sum"))
    )
    daily = daily.drop(columns=["sentiment_num", "sent_weighted", "rel_vol"]).merge(
        sent_weighted, on=["date", "theme_id"], how="left"
    )
    daily["sentiment"] = daily["weighted_sent"] / daily["rel_vol"].replace(0, np.nan)
    daily = daily.drop(columns=["weighted_sent"])

    constituent_counts = themes_df[["theme_id", "constituents"]].copy()
    constituent_counts["constituent_total"] = constituent_counts["constituents"].apply(
        lambda x: len(x) if isinstance(x, list) and len(x) > 0 else np.nan
    )
    daily = daily.merge(constituent_counts[["theme_id", "constituent_total"]], on="theme_id", how="left")
    daily["breadth"] = daily["matched_constituent_count"] / daily["constituent_total"]
    daily["breadth"] = daily["breadth"].fillna(0.0).clip(lower=0.0, upper=1.0)
    daily = daily.drop(columns=["matched_constituent_count", "constituent_total"])

    all_dates = pd.date_range(daily["date"].min(), daily["date"].max(), freq="D")
    all_themes = themes_df["theme_id"].astype(str).tolist()
    panel = pd.MultiIndex.from_product([all_dates, all_themes], names=["date", "theme_id"]).to_frame(index=False)
    daily = panel.merge(daily, on=["date", "theme_id"], how="left")

    fill_zero_cols = ["article_count", "rel_vol", "mean_similarity", "mean_rule_score", "breadth"]
    daily[fill_zero_cols] = daily[fill_zero_cols].fillna(0.0)
    daily["sentiment"] = daily["sentiment"].fillna(0.0)

    def _calc_group_features(group: pd.DataFrame) -> pd.DataFrame:
        out = group.sort_values("date").copy()
        mean = out["article_count"].rolling(volume_lookback_days, min_periods=5).mean()
        std = out["article_count"].rolling(volume_lookback_days, min_periods=5).std(ddof=0)
        out["vol_z"] = ((out["article_count"] - mean) / std.replace(0, np.nan)).fillna(0.0)

        short_ma = out["article_count"].rolling(accel_short_days, min_periods=1).mean()
        long_ma = out["article_count"].rolling(accel_long_days, min_periods=5).mean()
        out["accel"] = (short_ma / long_ma.replace(0, np.nan) - 1.0).replace([np.inf, -np.inf], np.nan).fillna(0.0)

        out["persist"] = (
            (out["vol_z"] > persist_z_threshold)
            .astype(int)
            .rolling(persist_days, min_periods=1)
            .sum()
            .astype(float)
        )
        return out

    daily = (
        daily.groupby("theme_id", group_keys=False)
        .apply(_calc_group_features)
        .reset_index(drop=True)
    )

    daily["theme_rank_score"] = (
        0.30 * daily["accel"]
        + 0.25 * daily["breadth"]
        + 0.20 * daily["sentiment"]
        + 0.15 * daily["vol_z"]
        + 0.10 * (daily["persist"] / max(1, persist_days))
    )
    return daily



def build_theme_daily_ranking(theme_daily_features_df: pd.DataFrame, top_n: int = 3) -> pd.DataFrame:
    if theme_daily_features_df.empty:
        return pd.DataFrame(columns=["date", "theme_id", "theme_rank", "theme_rank_score"])

    out = theme_daily_features_df.copy()
    out["theme_rank"] = (
        out.groupby("date")["theme_rank_score"]
        .rank(ascending=False, method="first")
        .astype(int)
    )
    out = out[out["theme_rank"] <= int(top_n)].sort_values(["date", "theme_rank", "theme_id"])
    return out
