"""類似度計算と多ラベル付与。"""

from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd

try:
    from .preprocess import normalize_text_for_rules
except ImportError:  # pragma: no cover
    from preprocess import normalize_text_for_rules



def build_similarity_scores(
    article_ids: Iterable[str],
    article_embeddings: np.ndarray,
    theme_df: pd.DataFrame,
    theme_embeddings: np.ndarray,
    default_threshold: float,
    use_theme_specific_threshold: bool,
    top_k: int,
) -> pd.DataFrame:
    article_ids_list = list(article_ids)
    if article_embeddings.ndim != 2 or theme_embeddings.ndim != 2:
        raise ValueError("embedding 行列は 2 次元である必要があります。")

    score_matrix = np.matmul(article_embeddings, theme_embeddings.T)

    rows: list[dict[str, object]] = []
    for article_idx, article_id in enumerate(article_ids_list):
        similarities = score_matrix[article_idx]
        ranking = np.argsort(-similarities)

        for rank, theme_idx in enumerate(ranking, start=1):
            theme_id = str(theme_df.iloc[theme_idx]["theme_id"])
            threshold = float(default_threshold)
            if use_theme_specific_threshold:
                threshold = float(theme_df.iloc[theme_idx]["threshold"])

            similarity = float(similarities[theme_idx])
            rows.append(
                {
                    "article_id": article_id,
                    "theme_id": theme_id,
                    "theme_name_ja": str(theme_df.iloc[theme_idx]["name_ja"]),
                    "similarity": similarity,
                    "similarity_rank": rank,
                    "threshold": threshold,
                    "over_threshold": similarity >= threshold,
                    "is_top_k": rank <= int(top_k),
                }
            )

    return pd.DataFrame(rows)



def _contains_term(text: str, term: str) -> bool:
    term = normalize_text_for_rules(term)
    if not term:
        return False
    return term in text



def build_rule_based_scores(articles_df: pd.DataFrame, theme_df: pd.DataFrame) -> pd.DataFrame:
    required_article_cols = {"article_id", "text_for_embedding"}
    required_theme_cols = {"theme_id", "name_ja", "aliases", "constituents"}
    if not required_article_cols.issubset(articles_df.columns):
        raise ValueError(f"articles_df に必須カラムが不足しています: {required_article_cols - set(articles_df.columns)}")
    if not required_theme_cols.issubset(theme_df.columns):
        raise ValueError(f"theme_df に必須カラムが不足しています: {required_theme_cols - set(theme_df.columns)}")

    rows: list[dict[str, object]] = []
    article_texts = {
        str(row.article_id): normalize_text_for_rules(row.text_for_embedding)
        for row in articles_df[["article_id", "text_for_embedding"]].itertuples(index=False)
    }

    for theme_row in theme_df.itertuples(index=False):
        theme_id = str(theme_row.theme_id)
        name = str(getattr(theme_row, "name_ja", "") or "")
        aliases = list(getattr(theme_row, "aliases", []) or [])
        constituents = list(getattr(theme_row, "constituents", []) or [])

        for article_id, text in article_texts.items():
            name_match = 1.0 if _contains_term(text, name) else 0.0
            alias_hits = [alias for alias in aliases if _contains_term(text, str(alias))]
            constituent_hits = [c for c in constituents if _contains_term(text, str(c))]

            alias_score = min(1.0, len(alias_hits) / max(1, len(aliases))) if aliases else 0.0
            constituent_score = min(1.0, len(constituent_hits) / max(1, min(5, len(constituents)))) if constituents else 0.0
            rule_score = 0.50 * name_match + 0.30 * alias_score + 0.20 * constituent_score

            rows.append(
                {
                    "article_id": article_id,
                    "theme_id": theme_id,
                    "name_match": name_match,
                    "alias_match_count": len(alias_hits),
                    "constituent_match_count": len(constituent_hits),
                    "matched_aliases": sorted(set(str(x) for x in alias_hits)),
                    "matched_constituents": sorted(set(str(x) for x in constituent_hits)),
                    "rule_score": float(rule_score),
                }
            )

    return pd.DataFrame(rows)



def build_assignment_scores(
    similarity_scores_df: pd.DataFrame,
    rule_scores_df: pd.DataFrame,
    articles_with_sentiment_df: pd.DataFrame,
    rule_weight: float,
    similarity_weight: float,
) -> pd.DataFrame:
    required_similarity_cols = {"article_id", "theme_id", "theme_name_ja", "similarity", "threshold", "over_threshold", "is_top_k"}
    required_rule_cols = {"article_id", "theme_id", "rule_score", "matched_constituents"}
    if not required_similarity_cols.issubset(similarity_scores_df.columns):
        raise ValueError(f"similarity_scores_df に必須カラムが不足しています: {required_similarity_cols - set(similarity_scores_df.columns)}")
    if not required_rule_cols.issubset(rule_scores_df.columns):
        raise ValueError(f"rule_scores_df に必須カラムが不足しています: {required_rule_cols - set(rule_scores_df.columns)}")

    article_sent = articles_with_sentiment_df[["article_id", "sentiment_score", "sentiment_label", "sentiment_confidence"]].copy()
    out = similarity_scores_df.merge(rule_scores_df, on=["article_id", "theme_id"], how="left")
    out = out.merge(article_sent, on="article_id", how="left")
    out["rule_score"] = out["rule_score"].fillna(0.0)
    out["assignment_score"] = similarity_weight * out["similarity"] + rule_weight * out["rule_score"]
    out["effective_threshold"] = out["threshold"]
    out["assigned_flag"] = (out["assignment_score"] >= out["effective_threshold"]) & out["is_top_k"]
    out["matched_constituents"] = out["matched_constituents"].apply(lambda x: x if isinstance(x, list) else [])
    return out



def assign_multilabels(scores_df: pd.DataFrame) -> pd.DataFrame:
    if scores_df.empty:
        return pd.DataFrame(columns=["article_id", "theme_ids", "max_similarity", "unclassified", "assigned_by"])

    score_col = "assignment_score" if "assignment_score" in scores_df.columns else "similarity"
    flag_col = "assigned_flag" if "assigned_flag" in scores_df.columns else "over_threshold"

    def collect_theme_ids(group: pd.DataFrame) -> list[str]:
        over = group[group[flag_col]].sort_values(score_col, ascending=False)
        return over["theme_id"].astype(str).tolist()

    theme_ids_series = scores_df.groupby("article_id", as_index=True).apply(collect_theme_ids)
    max_similarity = scores_df.groupby("article_id")[score_col].max()

    assignments = pd.DataFrame(
        {
            "article_id": theme_ids_series.index,
            "theme_ids": theme_ids_series.values,
            "max_similarity": max_similarity.reindex(theme_ids_series.index).values,
        }
    )
    assignments["unclassified"] = assignments["theme_ids"].map(lambda x: len(x) == 0)
    assignments["assigned_by"] = "hybrid" if "assignment_score" in scores_df.columns else "similarity"
    return assignments.reset_index(drop=True)



def apply_assignment_overrides(
    assignments_df: pd.DataFrame,
    bertopic_promoted_df: pd.DataFrame | None = None,
    manual_labels_df: pd.DataFrame | None = None,
) -> pd.DataFrame:
    out = assignments_df.copy()

    if bertopic_promoted_df is not None and not bertopic_promoted_df.empty:
        required = {"article_id", "theme_id"}
        if required.issubset(bertopic_promoted_df.columns):
            promoted_map = (
                bertopic_promoted_df.groupby("article_id")["theme_id"]
                .apply(lambda s: sorted(set(s.astype(str).tolist())))
                .to_dict()
            )

            mask = out["article_id"].isin(promoted_map.keys())
            out.loc[mask, "theme_ids"] = out.loc[mask, "article_id"].map(promoted_map)
            out.loc[mask, "unclassified"] = False
            out.loc[mask, "assigned_by"] = "bertopic"

    if manual_labels_df is not None and not manual_labels_df.empty:
        required = {"article_id", "theme_id"}
        if required.issubset(manual_labels_df.columns):
            manual_positive = manual_labels_df.copy()
            if "label" in manual_positive.columns:
                manual_positive = manual_positive[manual_positive["label"].astype(int) == 1]

            manual_map = (
                manual_positive.groupby("article_id")["theme_id"]
                .apply(lambda s: sorted(set(s.astype(str).tolist())))
                .to_dict()
            )
            mask = out["article_id"].isin(manual_map.keys())
            out.loc[mask, "theme_ids"] = out.loc[mask, "article_id"].map(manual_map)
            out.loc[mask, "unclassified"] = False
            out.loc[mask, "assigned_by"] = "manual"

    return out
