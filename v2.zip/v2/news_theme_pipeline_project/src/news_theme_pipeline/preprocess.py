"""前処理。"""

from __future__ import annotations

import pandas as pd



def _truncate_text(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars]



def build_text_for_embedding(df: pd.DataFrame, max_body_chars: int = 1200) -> pd.DataFrame:
    out = df.copy()

    out["title"] = out["title"].fillna("").astype(str)
    out["summary"] = out["summary"].fillna("").astype(str)
    out["body"] = out["body"].fillna("").astype(str)

    out["body_short"] = out["body"].map(lambda x: _truncate_text(x, max_body_chars))

    out["text_for_embedding"] = (
        out["title"].str.strip()
        + "\n"
        + out["summary"].str.strip()
        + "\n"
        + out["body_short"].str.strip()
    ).str.strip()

    return out



def build_theme_reference_text(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    def _join_parts(row: pd.Series) -> str:
        parts: list[str] = [str(row.get("name_ja", "")).strip(), str(row.get("description", "")).strip()]
        for col in ["aliases", "keywords", "constituents", "constituent_descriptions"]:
            value = row.get(col, [])
            if isinstance(value, list):
                parts.extend([str(x).strip() for x in value if str(x).strip()])
            elif pd.notna(value) and str(value).strip():
                parts.append(str(value).strip())
        return "\n".join([p for p in parts if p])

    out["theme_reference_text"] = out.apply(_join_parts, axis=1)
    return out



def normalize_text_for_rules(text: str) -> str:
    return " ".join(str(text).lower().split())
