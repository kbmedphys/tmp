# Table 4: アブレーション結果の要約

| run_id | purpose | ΔN(T) mean | ΔI_lambda mean | classical N(T) mean | qctsp N(T) mean |
| --- | --- | --- | --- | --- | --- |
| A0 | baseline | -1.220 | -1.113 | 12.600 | 11.380 |
| A1 | S sweep (coarse) | -4.750 | -9.730 | 12.600 | 7.850 |
| A2 | S sweep (fine) | -1.300 | -0.828 | 12.600 | 11.300 |
| A3 | R sweep (coarse) | -2.830 | -3.701 | 12.600 | 9.770 |
| A4 | R sweep (fine) | -0.395 | 0.929 | 12.600 | 12.205 |
| A5 | tau_repr condexp | -1.335 | -1.122 | 12.600 | 11.265 |
| A6 | tau_edges exp-quantile | 0.820 | 0.901 | 12.600 | 13.420 |
| A7 | n_steps small (auto off) | -10.600 | -1.738 | 12.600 | 2.000 |
| A8 | n_steps large (auto off) | -8.610 | -0.853 | 12.600 | 3.990 |
| B1 | parameter set: low excitation | 0.375 | 0.138 | 4.570 | 4.945 |
| B2 | parameter set: higher excitation | -0.785 | 0.441 | 14.935 | 14.150 |
