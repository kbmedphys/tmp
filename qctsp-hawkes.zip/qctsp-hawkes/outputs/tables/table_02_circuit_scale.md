# Table 2: 回路規模の概算

| 項目 | 依存関係 | ベースライン例 (S=8, R=16) | 備考 |
| --- | --- | --- | --- |
| ηレジスタ | n_x = ceil(log2 S) | n_x = 3 | ηビン数Sに依存 |
| τレジスタ | n_tau = ceil(log2 R) | n_tau = 4 | τビン数Rに依存 |
| 量子ビット数(1ステップ) | 2*n_x + n_tau | 10 | x_prev/x_next + τ |
| 量子ビット数( n_steps 展開) | (n_steps+1)*n_x + n_tau | 16 (n_steps=3) | unroll回路 |
| State prep制御数 | O(S) blocks | 8 blocks | ηごとの条件付き準備 |
| State prepコスト | O(S * 2^{n_tau}) | 約 8 * 16 | 分解方法に依存 |
| Transitionオラクル | O(S * R * n_x) | 約 8 * 16 * 3 | 多制御Xの数 |
| 回路深さ | O(S * R) | 数百規模 | 低最適化の概算 |

注: gate数や深さは実装・分解方法で大きく変わるため、ここではオーダーの目安を示す。
