# Figure 5: N(T)ヒストグラム

目的: 古典 vs QCTSP の分布比較

想定入力:
- compare_report.json または集計済みメトリクス

生成方法(案):
- matplotlibで図を生成しoutputs/figuresへ保存

備考:
- 本ファイルは図の説明テンプレート
