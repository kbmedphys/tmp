# Figure 2: QCTSP拡張フロー

目的: state preparation -> transition -> extraction の流れ

想定入力:
- compare_report.json または集計済みメトリクス

生成方法(案):
- matplotlibで図を生成しoutputs/figuresへ保存

備考:
- 本ファイルは図の説明テンプレート
