# Figure 4: 回路ブロック図

目的: 条件付き状態準備と遷移オラクル

想定入力:
- compare_report.json または集計済みメトリクス

生成方法(案):
- matplotlibで図を生成しoutputs/figuresへ保存

備考:
- 本ファイルは図の説明テンプレート
