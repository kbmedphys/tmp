# Figure 7: アブレーション結果

目的: S/R/τ_repr/τ_edges依存性

想定入力:
- compare_report.json または集計済みメトリクス

生成方法(案):
- matplotlibで図を生成しoutputs/figuresへ保存

備考:
- 本ファイルは図の説明テンプレート
