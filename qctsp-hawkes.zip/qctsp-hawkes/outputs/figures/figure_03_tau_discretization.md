# Figure 3: τ離散化と代表値

目的: midpoint/condexpの概念図

想定入力:
- compare_report.json または集計済みメトリクス

生成方法(案):
- matplotlibで図を生成しoutputs/figuresへ保存

備考:
- 本ファイルは図の説明テンプレート
