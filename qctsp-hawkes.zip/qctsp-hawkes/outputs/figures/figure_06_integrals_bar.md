# Figure 6: I_eta/I_lambda比較

目的: 平均値の棒グラフ比較

想定入力:
- compare_report.json または集計済みメトリクス

生成方法(案):
- matplotlibで図を生成しoutputs/figuresへ保存

備考:
- 本ファイルは図の説明テンプレート
