# Figure 1: Hawkes過程の保持時間表現

目的: ηとτの関係を時系列上に可視化

想定入力:
- compare_report.json または集計済みメトリクス

生成方法(案):
- matplotlibで図を生成しoutputs/figuresへ保存

備考:
- 本ファイルは図の説明テンプレート
