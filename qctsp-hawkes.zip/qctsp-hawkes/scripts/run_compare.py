"""CLI for classical-vs-qctsp validation comparison."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

from qctsp_hawkes.validation.compare import (
    ComparisonConfig,
    build_qctsp_tau_debug,
    run_validation_comparison,
    save_json_artifact,
)


LOGGER = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    """Build parser for validation comparison workflow."""

    parser = argparse.ArgumentParser(description="Compare classical Hawkes and QCTSP samples.")
    parser.add_argument("--T", type=float, default=10.0, help="Time horizon.")
    parser.add_argument("--mu", type=float, default=0.8, help="Hawkes baseline.")
    parser.add_argument("--alpha", type=float, default=0.6, help="Hawkes excitation.")
    parser.add_argument("--beta", type=float, default=1.5, help="Hawkes decay.")
    parser.add_argument("--S", type=int, default=8, help="Eta-state bin count.")
    parser.add_argument("--R", type=int, default=16, help="Tau bin count.")
    parser.add_argument("--tau-max", type=float, default=5.0, help="Last finite tau edge.")
    parser.add_argument("--eta-max", type=float, default=8.0, help="Eta grid maximum.")
    parser.add_argument(
        "--tau-repr",
        type=str,
        default="midpoint",
        choices=("midpoint", "condexp"),
        help="Tau representative value mode.",
    )
    parser.add_argument(
        "--tau-edges",
        type=str,
        default="linear",
        choices=("linear", "exp-quantile"),
        help="Tau edge construction mode.",
    )
    parser.add_argument(
        "--lambda-ref",
        type=str,
        default="mu",
        choices=("mu", "lambda_x0", "lambda_mean"),
        help="Reference intensity mode used by tau discretization options.",
    )
    parser.add_argument("--n-steps", type=int, default=3, help="Unrolled QCTSP steps.")
    parser.add_argument("--shots", type=int, default=200, help="QCTSP sampling shots.")
    parser.add_argument("--classical-paths", type=int, default=200, help="Classical simulation paths.")
    parser.add_argument("--seed", type=int, default=7, help="Base random seed.")
    parser.add_argument("--x0", type=int, default=0, help="Initial eta-state index.")
    parser.add_argument(
        "--auto-n-steps",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Automatically raise n_steps to max(user_n_steps, ceil(1.5 * mean classical N(T))).",
    )
    parser.add_argument(
        "--debug-qctsp",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Write per-shot tau debug artifact to outputs/qctsp_tau_debug.json.",
    )
    parser.add_argument(
        "--qctsp-backend",
        type=str,
        default="auto",
        choices=("auto", "aer", "classical"),
        help="QCTSP sampler backend mode.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("outputs/compare_report.json"),
        help="Output report path (JSON).",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Run comparison and write JSON report."""

    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    logging.getLogger("qiskit").setLevel(logging.WARNING)

    config = ComparisonConfig(
        T=args.T,
        mu=args.mu,
        alpha=args.alpha,
        beta=args.beta,
        S=args.S,
        R=args.R,
        tau_max=args.tau_max,
        eta_max=args.eta_max,
        tau_repr_mode=args.tau_repr,
        tau_edges_mode=args.tau_edges,
        lambda_ref_mode=args.lambda_ref,
        n_steps=args.n_steps,
        shots=args.shots,
        classical_paths=args.classical_paths,
        seed=args.seed,
        x0=args.x0,
        qctsp_backend=args.qctsp_backend,
        auto_n_steps=args.auto_n_steps,
    )

    report, report_path = run_validation_comparison(config=config, output_path=args.output)
    n_t_samples = report["qctsp"]["N_T"]["samples"]
    unique_nt = sorted(set(int(v) for v in n_t_samples))
    LOGGER.info(
        "QCTSP N_T stats: min=%d, max=%d, n_unique=%d",
        min(unique_nt),
        max(unique_nt),
        len(unique_nt),
    )

    if args.debug_qctsp:
        n_steps_effective = int(report["qctsp"]["n_steps_effective"])
        debug_payload = build_qctsp_tau_debug(
            config=config,
            n_steps=n_steps_effective,
            max_shots=20,
        )
        debug_path = save_json_artifact(
            payload=debug_payload,
            output_path=Path("outputs/qctsp_tau_debug.json"),
        )
        LOGGER.info("Saved QCTSP tau debug artifact: %s", debug_path)

    LOGGER.info(
        "Saved comparison report: %s (classical mean N_T=%.3f, qctsp mean N_T=%.3f, n_steps_effective=%d)",
        report_path,
        report["classical"]["N_T"]["mean"],
        report["qctsp"]["N_T"]["mean"],
        int(report["qctsp"]["n_steps_effective"]),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
