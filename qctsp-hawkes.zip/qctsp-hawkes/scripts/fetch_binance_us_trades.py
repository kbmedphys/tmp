"""Download Binance.US historical trades data (daily/monthly)."""

from __future__ import annotations

import argparse
import logging
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable
from urllib.error import HTTPError, URLError
from urllib.request import urlretrieve


LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class DownloadTarget:
    url: str
    output_path: Path


def _parse_date(value: str) -> date:
    return datetime.strptime(value, "%Y-%m-%d").date()


def _month_start(d: date) -> date:
    return date(d.year, d.month, 1)


def _month_iter(start: date, end: date) -> Iterable[date]:
    current = _month_start(start)
    end_month = _month_start(end)
    while current <= end_month:
        yield current
        year = current.year + (current.month // 12)
        month = 1 if current.month == 12 else current.month + 1
        current = date(year, month, 1)


def _day_iter(start: date, end: date) -> Iterable[date]:
    current = start
    while current <= end:
        yield current
        current += timedelta(days=1)


def _build_targets(
    symbol: str,
    start: date,
    end: date,
    mode: str,
    base_url: str,
    pattern: str,
    subdir: str,
    out_dir: Path,
) -> list[DownloadTarget]:
    symbol = symbol.upper()
    if mode not in {"daily", "monthly"}:
        raise ValueError("mode must be daily or monthly")

    dates: Iterable[date] = _day_iter(start, end) if mode == "daily" else _month_iter(start, end)
    targets: list[DownloadTarget] = []
    for d in dates:
        date_str = d.strftime("%Y-%m-%d") if mode == "daily" else d.strftime("%Y-%m")
        filename = pattern.format(symbol=symbol, date=date_str)
        rel_dir = subdir.format(symbol=symbol, mode=mode)
        url = f"{base_url.rstrip('/')}/{rel_dir}/{filename}"
        output_path = out_dir / symbol / mode / filename
        targets.append(DownloadTarget(url=url, output_path=output_path))
    return targets


def _download(target: DownloadTarget, overwrite: bool) -> bool:
    target.output_path.parent.mkdir(parents=True, exist_ok=True)
    if target.output_path.exists() and not overwrite:
        LOGGER.info("Skip (exists): %s", target.output_path.name)
        return True
    try:
        urlretrieve(target.url, target.output_path)
        LOGGER.info("Downloaded: %s", target.output_path.name)
        return True
    except HTTPError as exc:
        LOGGER.warning("HTTP error %s for %s", exc.code, target.url)
        return False
    except URLError as exc:
        LOGGER.warning("URL error %s for %s", exc.reason, target.url)
        return False


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Download Binance.US historical trades data.")
    parser.add_argument("--symbol", type=str, default="BTCUSD", help="Symbol, e.g., BTCUSD.")
    parser.add_argument("--start", type=str, required=True, help="Start date YYYY-MM-DD.")
    parser.add_argument("--end", type=str, required=True, help="End date YYYY-MM-DD.")
    parser.add_argument(
        "--mode",
        type=str,
        default="daily",
        choices=("daily", "monthly"),
        help="Download granularity.",
    )
    parser.add_argument(
        "--base-url",
        type=str,
        default="https://data.binance.us/public_data/spot",
        help="Base URL for historical data.",
    )
    parser.add_argument(
        "--pattern",
        type=str,
        default="{symbol}-trades-{date}.zip",
        help="Filename pattern.",
    )
    parser.add_argument(
        "--subdir",
        type=str,
        default="{mode}/trades/{symbol}",
        help="Subdirectory pattern under base URL.",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("outputs/real_data/raw"),
        help="Output directory for downloaded files.",
    )
    parser.add_argument(
        "--overwrite",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Overwrite existing files.",
    )
    parser.add_argument(
        "--dry-run",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Only print target URLs without downloading.",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    start = _parse_date(args.start)
    end = _parse_date(args.end)
    if end < start:
        raise ValueError("end date must be >= start date")

    targets = _build_targets(
        symbol=args.symbol,
        start=start,
        end=end,
        mode=args.mode,
        base_url=args.base_url,
        pattern=args.pattern,
        subdir=args.subdir,
        out_dir=args.out_dir,
    )

    if args.dry_run:
        for target in targets:
            print(target.url)
        LOGGER.info("Dry run complete: %d URLs", len(targets))
        return 0

    success = 0
    for target in targets:
        if _download(target=target, overwrite=args.overwrite):
            success += 1
    LOGGER.info("Downloaded %d/%d files", success, len(targets))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
