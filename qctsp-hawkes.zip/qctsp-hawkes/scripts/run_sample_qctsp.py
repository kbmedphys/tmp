"""CLI for sampling the lookup-based QCTSP Hawkes prototype."""

from __future__ import annotations

import argparse
import logging
import platform
from collections import Counter
from pathlib import Path

import numpy as np
from qiskit import transpile

from qctsp_hawkes.circuits.unroll import (
    build_qctsp_unroll_circuit,
    parse_qctsp_counts,
    sample_qctsp_classically,
    samples_to_counts,
)
from qctsp_hawkes.discretization import build_eta_grid, build_p_tau_given_x, build_tau_edges, build_tau_midpoints
from qctsp_hawkes.transition_tables import build_transition_table


LOGGER = logging.getLogger(__name__)


def _is_aer_runtime_safe() -> bool:
    """Best-effort guard against known OpenMP SHM failures in restricted sandboxes."""

    if platform.system() == "Darwin" and not Path("/dev/shm").exists():
        return False
    return True


def _get_aer_backend(seed: int | None):
    """Return an Aer simulator backend across qiskit/qiskit-aer API variants."""

    try:
        from qiskit_aer import AerSimulator

        return AerSimulator(seed_simulator=seed, max_parallel_threads=1)
    except Exception:  # pragma: no cover - fallback for older Aer API
        from qiskit import Aer

        backend = Aer.get_backend("qasm_simulator")
        if seed is not None:
            backend.set_options(seed_simulator=seed)
        return backend


def build_parser() -> argparse.ArgumentParser:
    """Build the parser for QCTSP sampling workflow."""

    parser = argparse.ArgumentParser(description="Sample QCTSP Hawkes lookup prototype.")
    parser.add_argument("--shots", type=int, default=500, help="Sampling shots.")
    parser.add_argument("--seed", type=int, default=7, help="Random seed for simulator/transpiler.")
    parser.add_argument("--x0", type=int, default=0, help="Initial eta-state index.")
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Build QCTSP tables, sample the circuit, and log sanity stats."""

    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    logging.getLogger("qiskit").setLevel(logging.WARNING)

    S = 8
    R = 16
    n_steps = 3
    eta_grid = build_eta_grid(S=S, eta_max=8.0)
    tau_edges = build_tau_edges(R=R, tau_max=4.0)
    tau_mid = build_tau_midpoints(edges=tau_edges)
    p_tau_given_x = build_p_tau_given_x(
        eta_grid=eta_grid,
        tau_edges=tau_edges,
        mu=0.6,
        alpha=0.3,
        beta=1.1,
    )
    transition_table = build_transition_table(eta_grid=eta_grid, tau_mid=tau_mid, alpha=0.3, beta=1.1)

    circuit, layout = build_qctsp_unroll_circuit(
        p_tau_given_x=p_tau_given_x,
        transition_table=transition_table,
        n_steps=n_steps,
        x0=args.x0,
        measure_x_path=True,
    )

    counts: dict[str, int]
    if _is_aer_runtime_safe():
        backend = _get_aer_backend(seed=args.seed)
        compiled = transpile(circuit, backend=backend, seed_transpiler=args.seed, optimization_level=0)
        job = backend.run(compiled, shots=args.shots, seed_simulator=args.seed)
        counts = dict(job.result().get_counts(compiled))
        LOGGER.info("Sampling backend: Aer qasm simulator.")
    else:
        # Sandbox-safe fallback that preserves the same lookup dynamics.
        classical_samples = sample_qctsp_classically(
            p_tau_given_x=p_tau_given_x,
            transition_table=transition_table,
            n_steps=n_steps,
            x0=args.x0,
            shots=args.shots,
            seed=args.seed,
            measure_x_path=True,
        )
        counts = samples_to_counts(samples=classical_samples, layout=layout)
        LOGGER.warning("Aer runtime unavailable in this environment; used classical fallback sampler.")

    samples = parse_qctsp_counts(counts=counts, layout=layout)

    if len(samples) != args.shots:
        raise RuntimeError("Parsed sample count does not match requested shots.")

    tau_values = np.asarray([tau for sample in samples for tau in sample.tau_indices], dtype=np.int64)
    x_values = np.asarray([x for sample in samples for x in sample.x_indices], dtype=np.int64)

    if np.any(tau_values < 0) or np.any(tau_values >= R):
        raise RuntimeError("Tau sample index out of range.")
    if np.any(x_values < 0) or np.any(x_values >= S):
        raise RuntimeError("State sample index out of range.")

    n_hat = [sum(1 for tau_idx in sample.tau_indices if tau_idx < (R - 1)) for sample in samples]
    n_hat_hist = dict(sorted(Counter(n_hat).items()))

    LOGGER.info(
        "Sampled QCTSP: shots=%d, S=%d, R=%d, n_steps=%d, x0=%d",
        args.shots,
        S,
        R,
        n_steps,
        args.x0,
    )
    LOGGER.info(
        "Range checks: tau min=%d max=%d, x min=%d max=%d",
        int(np.min(tau_values)),
        int(np.max(tau_values)),
        int(np.min(x_values)),
        int(np.max(x_values)),
    )
    LOGGER.info("N_hat histogram (non-tail tau count per path): %s", n_hat_hist)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
