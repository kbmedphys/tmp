"""CLI to execute experiment plan sweeps for QCTSP-Hawkes."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path


def _ensure_src_on_path() -> Path:
    project_root = Path(__file__).resolve().parents[1]
    src_path = project_root / "src"
    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))
    return project_root


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run experiment plan for QCTSP-Hawkes.")
    parser.add_argument(
        "--plan",
        type=Path,
        default=Path("outputs/experiment_plan.json"),
        help="Path to experiment plan JSON.",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("outputs/experiments"),
        help="Output directory for per-run reports and summaries.",
    )
    parser.add_argument(
        "--overwrite",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Overwrite existing per-run reports.",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def _summarize_section(section: dict) -> dict:
    return {
        "N_T_mean": section["N_T"]["mean"],
        "N_T_var": section["N_T"]["var"],
        "I_eta_mean": section["I_eta"]["mean"],
        "I_eta_var": section["I_eta"]["var"],
        "I_lambda_mean": section["I_lambda"]["mean"],
        "I_lambda_var": section["I_lambda"]["var"],
        "ks_pvalue_mean": section["ks_pvalue"]["mean"],
    }


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    logger = logging.getLogger(__name__)

    project_root = _ensure_src_on_path()
    plan_path = args.plan
    if not plan_path.is_absolute():
        plan_path = project_root / plan_path

    if not plan_path.exists():
        raise FileNotFoundError(f"experiment plan not found: {plan_path}")

    plan = json.loads(plan_path.read_text())
    runs = plan.get("runs", [])
    if not runs:
        raise ValueError("experiment plan has no runs")

    from qctsp_hawkes.validation.compare import ComparisonConfig, run_validation_comparison

    out_dir = args.out_dir
    if not out_dir.is_absolute():
        out_dir = project_root / out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    summary_rows: list[dict] = []

    for run in runs:
        run_id = run.get("run_id", "unknown")
        purpose = run.get("purpose", "")
        run_dir = out_dir / f"run_{run_id}"
        run_dir.mkdir(parents=True, exist_ok=True)
        report_path = run_dir / "compare_report.json"

        if report_path.exists() and not args.overwrite:
            logger.info("Skip %s (report exists)", run_id)
            report = json.loads(report_path.read_text())
        else:
            logger.info("Run %s: %s", run_id, purpose)
            config = ComparisonConfig(
                T=run["T"],
                mu=run["mu"],
                alpha=run["alpha"],
                beta=run["beta"],
                S=run["S"],
                R=run["R"],
                tau_max=run["tau_max"],
                eta_max=run["eta_max"],
                n_steps=run["n_steps"],
                shots=run["shots"],
                classical_paths=run["classical_paths"],
                seed=run["seed"],
                x0=run["x0"],
                qctsp_backend=run["qctsp_backend"],
                auto_n_steps=run["auto_n_steps"],
                tau_repr_mode=run["tau_repr_mode"],
                tau_edges_mode=run["tau_edges_mode"],
                lambda_ref_mode=run["lambda_ref_mode"],
            )
            report, _ = run_validation_comparison(config=config, output_path=report_path)

        classical_summary = _summarize_section(report["classical"])
        qctsp_summary = _summarize_section(report["qctsp"])
        row = {
            "run_id": run_id,
            "purpose": purpose,
            "backend": report["qctsp"].get("backend"),
            "n_steps_effective": report["qctsp"].get("n_steps_effective"),
        }
        row.update({f"classical_{k}": v for k, v in classical_summary.items()})
        row.update({f"qctsp_{k}": v for k, v in qctsp_summary.items()})
        summary_rows.append(row)

    summary_json = out_dir / "summary.json"
    summary_json.write_text(json.dumps(summary_rows, indent=2, ensure_ascii=False))

    # write CSV
    if summary_rows:
        fieldnames = list(summary_rows[0].keys())
        lines = [",".join(fieldnames)]
        for row in summary_rows:
            values = [str(row.get(k, "")) for k in fieldnames]
            lines.append(",".join(values))
        summary_csv = out_dir / "summary.csv"
        summary_csv.write_text("\n".join(lines), encoding="utf-8")

    logger.info("Saved summary: %s", summary_json)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
