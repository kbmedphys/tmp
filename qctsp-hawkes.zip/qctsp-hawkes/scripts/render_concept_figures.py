"""Render conceptual figures (Figure 1-4) for the QCTSP-Hawkes paper."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle


LOGGER = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Render conceptual figures for QCTSP-Hawkes.")
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("outputs/figures"),
        help="Output directory for figures.",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def _style_axes(ax):
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)


def figure_01_holding_time(out_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(8, 3))

    t0, t1, t2, t3 = 1.0, 4.0, 7.0, 9.5

    # Timeline
    ax.plot([0.5, 10.0], [0.8, 0.8], color="black", linewidth=1.2)
    for t, label in [(t0, "t0"), (t1, "t1"), (t2, "t2")]:
        ax.plot([t, t], [0.7, 0.9], color="black", linewidth=1.0)
        ax.text(t, 0.95, label, ha="center", va="bottom", fontsize=9)

    ax.annotate("", xy=(t1, 1.1), xytext=(t0, 1.1), arrowprops=dict(arrowstyle="<->"))
    ax.text((t0 + t1) / 2, 1.15, r"$\tau_1$", ha="center", fontsize=9)
    ax.annotate("", xy=(t2, 1.1), xytext=(t1, 1.1), arrowprops=dict(arrowstyle="<->"))
    ax.text((t1 + t2) / 2, 1.15, r"$\tau_2$", ha="center", fontsize=9)

    # Eta step function (conceptual)
    eta_times = [0.5, t0, t1, t2, t3]
    eta_vals = [0.0, 1.0, 1.6, 1.2]
    y0 = 0.0
    scale = 0.35
    for i in range(len(eta_vals)):
        x_start = eta_times[i]
        x_end = eta_times[i + 1]
        y = y0 + eta_vals[i] * scale
        ax.plot([x_start, x_end], [y, y], color="#2b6cb0", linewidth=2)
        if i < len(eta_vals) - 1:
            y_next = y0 + eta_vals[i + 1] * scale
            ax.plot([x_end, x_end], [y, y_next], color="#2b6cb0", linewidth=1.5)

    ax.text(0.6, y0 - 0.05, "η(t)", color="#2b6cb0", fontsize=9)
    ax.text(0.5, 1.35, "Holding time representation", fontsize=10, weight="bold")

    ax.set_xlim(0.0, 10.5)
    ax.set_ylim(-0.1, 1.6)
    _style_axes(ax)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def figure_02_pipeline(out_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(8, 2.5))

    boxes = [
        (0.2, 0.4, 1.8, 0.4, "Discretize\n(η, τ)"),
        (2.5, 0.4, 2.0, 0.4, "State prep\np(τ|η)"),
        (5.0, 0.4, 2.0, 0.4, "Transition\noracle"),
        (7.5, 0.4, 1.8, 0.4, "Extraction\nmetrics"),
    ]
    for x, y, w, h, label in boxes:
        ax.add_patch(Rectangle((x, y), w, h, fill=False, linewidth=1.2))
        ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", fontsize=9)

    for x in [2.1, 4.6, 7.1]:
        ax.annotate("", xy=(x + 0.3, 0.6), xytext=(x - 0.1, 0.6), arrowprops=dict(arrowstyle="->"))

    ax.text(0.2, 1.1, "QCTSP pipeline (Hawkes extension)", fontsize=10, weight="bold")
    ax.set_xlim(0, 9.8)
    ax.set_ylim(0, 1.5)
    _style_axes(ax)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def figure_03_tau_discretization(out_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(8, 2.8))

    edges = np.array([0.0, 1.0, 2.0, 3.0, 4.0])
    midpoints = (edges[:-1] + edges[1:]) / 2
    condexp = midpoints + 0.15 * np.sin(np.linspace(0, np.pi, len(midpoints)))

    ax.plot([edges[0], edges[-1]], [0.0, 0.0], color="black")
    for e in edges:
        ax.plot([e, e], [-0.1, 0.1], color="black")
        ax.text(e, -0.2, f"e{int(e)}", ha="center", va="top", fontsize=8)

    ax.scatter(midpoints, [0.5] * len(midpoints), color="#2f855a", label="midpoint")
    ax.scatter(condexp, [-0.5] * len(condexp), color="#c05621", marker="x", label="condexp")

    ax.text(edges[0], 0.9, "Representative values", fontsize=10, weight="bold")
    ax.text(edges[-1], 0.5, "midpoint", color="#2f855a", ha="right", va="bottom", fontsize=8)
    ax.text(edges[-1], -0.5, "condexp", color="#c05621", ha="right", va="top", fontsize=8)

    ax.set_xlim(-0.2, 4.2)
    ax.set_ylim(-1.0, 1.1)
    _style_axes(ax)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def figure_04_circuit_blocks(out_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(8, 2.6))

    # Registers
    ax.plot([0.2, 9.5], [1.8, 1.8], color="black", linewidth=1.0)
    ax.plot([0.2, 9.5], [1.0, 1.0], color="black", linewidth=1.0)
    ax.text(0.1, 1.8, "|x⟩", va="center", fontsize=9)
    ax.text(0.1, 1.0, "|τ⟩", va="center", fontsize=9)

    # Blocks
    blocks = [
        (1.5, 1.35, 1.8, 0.9, "State\nprep"),
        (4.2, 1.35, 2.0, 0.9, "Transition\noracle"),
        (7.2, 1.35, 1.8, 0.9, "Measure"),
    ]
    for x, y, w, h, label in blocks:
        ax.add_patch(Rectangle((x, y), w, h, fill=False, linewidth=1.2))
        ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", fontsize=9)

    ax.text(0.2, 2.2, "Circuit block diagram", fontsize=10, weight="bold")
    ax.set_xlim(0, 9.8)
    ax.set_ylim(0.5, 2.4)
    _style_axes(ax)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    out_dir = args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    figure_01_holding_time(out_dir / "figure_01_holding_time.png")
    figure_02_pipeline(out_dir / "figure_02_qctsp_pipeline.png")
    figure_03_tau_discretization(out_dir / "figure_03_tau_discretization.png")
    figure_04_circuit_blocks(out_dir / "figure_04_circuit_blocks.png")

    LOGGER.info("Rendered conceptual figures in %s", out_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
