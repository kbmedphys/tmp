"""CLI for classical Hawkes parameter fitting."""

from __future__ import annotations

import argparse
import logging

from qctsp_hawkes.classical.hawkes_exp import HawkesParams, fit_hawkes_exp_mle, simulate_hawkes_exp_ogata


LOGGER = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    """Build the command-line parser for the fitting entry point."""

    parser = argparse.ArgumentParser(description="Run classical Hawkes fitting.")
    parser.add_argument("--T", type=float, default=40.0, help="Simulation horizon.")
    parser.add_argument("--mu", type=float, default=0.5, help="True baseline intensity.")
    parser.add_argument("--alpha", type=float, default=0.35, help="True excitation weight.")
    parser.add_argument("--beta", type=float, default=1.0, help="True exponential decay.")
    parser.add_argument("--seed", type=int, default=13, help="Random seed for synthetic data.")
    parser.add_argument("--init-mu", type=float, default=0.4, help="Initial mu for fitting.")
    parser.add_argument("--init-alpha", type=float, default=0.2, help="Initial alpha for fitting.")
    parser.add_argument("--init-beta", type=float, default=0.8, help="Initial beta for fitting.")
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Parse CLI arguments and run fitting workflow on synthetic data."""

    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    true_params = HawkesParams(mu=args.mu, alpha=args.alpha, beta=args.beta)
    init_params = HawkesParams(mu=args.init_mu, alpha=args.init_alpha, beta=args.init_beta)

    times = simulate_hawkes_exp_ogata(
        T=args.T,
        mu=true_params.mu,
        alpha=true_params.alpha,
        beta=true_params.beta,
        seed=args.seed,
    )
    estimated, optimize_result = fit_hawkes_exp_mle(times=times, T=args.T, init=init_params)

    LOGGER.info("Synthetic dataset: count=%d, T=%.3f, seed=%d", times.size, args.T, args.seed)
    LOGGER.info(
        "True params     : mu=%.6f, alpha=%.6f, beta=%.6f",
        true_params.mu,
        true_params.alpha,
        true_params.beta,
    )
    LOGGER.info(
        "Estimated params: mu=%.6f, alpha=%.6f, beta=%.6f",
        estimated.mu,
        estimated.alpha,
        estimated.beta,
    )
    LOGGER.info(
        "Optimizer status: success=%s, nit=%d, fun=%.6f",
        optimize_result.success,
        optimize_result.nit,
        optimize_result.fun,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
