"""Render figures and tables for the QCTSP-Hawkes paper from JSON outputs."""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np


LOGGER = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Render figures/tables for QCTSP-Hawkes paper.")
    parser.add_argument(
        "--report",
        type=Path,
        default=Path("outputs/compare_report.json"),
        help="Baseline comparison report JSON.",
    )
    parser.add_argument(
        "--summary",
        type=Path,
        default=Path("outputs/experiments/summary.json"),
        help="Experiment summary JSON (from run_experiment_plan).",
    )
    parser.add_argument(
        "--fig-dir",
        type=Path,
        default=Path("outputs/figures"),
        help="Output directory for figures.",
    )
    parser.add_argument(
        "--table-dir",
        type=Path,
        default=Path("outputs/tables"),
        help="Output directory for tables.",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def _load_json(path: Path):
    if not path.exists():
        raise FileNotFoundError(f"missing file: {path}")
    return json.loads(path.read_text())


def _as_array(values: Iterable[float | int]) -> np.ndarray:
    return np.asarray(list(values), dtype=float)


def plot_nt_hist(report: dict, out_path: Path) -> None:
    classical_nt = _as_array(report["classical"]["N_T"]["samples"])
    qctsp_nt = _as_array(report["qctsp"]["N_T"]["samples"])

    bins = np.arange(0, max(classical_nt.max(), qctsp_nt.max()) + 2) - 0.5
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(classical_nt, bins=bins, alpha=0.6, label="classical")
    ax.hist(qctsp_nt, bins=bins, alpha=0.6, label="qctsp")
    ax.set_xlabel("N(T)")
    ax.set_ylabel("count")
    ax.set_title("N(T) histogram")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_integrals(report: dict, out_path: Path) -> None:
    labels = ["classical", "qctsp"]
    i_eta_means = [np.mean(report[sec]["I_eta"]["samples"]) for sec in labels]
    i_lambda_means = [np.mean(report[sec]["I_lambda"]["samples"]) for sec in labels]

    x = np.arange(len(labels))
    width = 0.35
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(x - width / 2, i_eta_means, width, label="I_eta")
    ax.bar(x + width / 2, i_lambda_means, width, label="I_lambda")
    ax.set_xticks(x, labels)
    ax.set_ylabel("value")
    ax.set_title("Integral comparison")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_ablation(summary_rows: list[dict], out_path: Path) -> None:
    run_ids = [row.get("run_id", "") for row in summary_rows]
    if not run_ids:
        LOGGER.warning("No summary rows to plot ablation figure")
        return

    diff_nt = [
        float(row.get("qctsp_N_T_mean", 0.0)) - float(row.get("classical_N_T_mean", 0.0))
        for row in summary_rows
    ]
    diff_il = [
        float(row.get("qctsp_I_lambda_mean", 0.0)) - float(row.get("classical_I_lambda_mean", 0.0))
        for row in summary_rows
    ]

    x = np.arange(len(run_ids))
    width = 0.4
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.bar(x - width / 2, diff_nt, width, label="Δ N(T) mean")
    ax.bar(x + width / 2, diff_il, width, label="Δ I_lambda mean")
    ax.set_xticks(x, run_ids, rotation=45, ha="right")
    ax.set_ylabel("difference (QCTSP - classical)")
    ax.set_title("Ablation: mean differences")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def write_ablation_table(summary_rows: list[dict], out_path: Path) -> None:
    header = [
        "scenario",
        "metric",
        "classical_mean",
        "classical_var",
        "qctsp_mean",
        "qctsp_var",
        "notes",
    ]
    lines = [",".join(header)]

    metric_map = {
        "N_T": ("classical_N_T_mean", "classical_N_T_var", "qctsp_N_T_mean", "qctsp_N_T_var"),
        "I_eta": ("classical_I_eta_mean", "classical_I_eta_var", "qctsp_I_eta_mean", "qctsp_I_eta_var"),
        "I_lambda": (
            "classical_I_lambda_mean",
            "classical_I_lambda_var",
            "qctsp_I_lambda_mean",
            "qctsp_I_lambda_var",
        ),
        "ks_pvalue": ("classical_ks_pvalue_mean", "", "qctsp_ks_pvalue_mean", ""),
    }

    for row in summary_rows:
        scenario = str(row.get("run_id", ""))
        for metric, keys in metric_map.items():
            c_mean_key, c_var_key, q_mean_key, q_var_key = keys
            c_mean = row.get(c_mean_key, "") if c_mean_key else ""
            c_var = row.get(c_var_key, "") if c_var_key else ""
            q_mean = row.get(q_mean_key, "") if q_mean_key else ""
            q_var = row.get(q_var_key, "") if q_var_key else ""
            line = [scenario, metric, str(c_mean), str(c_var), str(q_mean), str(q_var), ""]
            lines.append(",".join(line))

    out_path.write_text("\n".join(lines), encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    fig_dir = args.fig_dir
    table_dir = args.table_dir
    fig_dir.mkdir(parents=True, exist_ok=True)
    table_dir.mkdir(parents=True, exist_ok=True)

    # Baseline figures
    report_path = args.report
    if report_path.exists():
        report = _load_json(report_path)
        plot_nt_hist(report, fig_dir / "figure_05_nt_histogram.png")
        plot_integrals(report, fig_dir / "figure_06_integrals_bar.png")
        LOGGER.info("Rendered baseline figures from %s", report_path)
    else:
        LOGGER.warning("Baseline report missing: %s", report_path)

    # Ablation figures + table
    summary_path = args.summary
    if summary_path.exists():
        summary_rows = _load_json(summary_path)
        if not isinstance(summary_rows, list):
            raise ValueError("summary.json must be a list of rows")
        plot_ablation(summary_rows, fig_dir / "figure_07_ablation.png")
        write_ablation_table(summary_rows, table_dir / "table_04_ablation_summary.csv")
        LOGGER.info("Rendered ablation assets from %s", summary_path)
    else:
        LOGGER.warning("Summary missing: %s", summary_path)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
