"""CLI for building prototype QCTSP discretization and transition tables."""

from __future__ import annotations

import argparse
import logging

import numpy as np

from qctsp_hawkes.discretization import build_eta_grid, build_p_tau_given_x, build_tau_edges, build_tau_midpoints
from qctsp_hawkes.transition_tables import build_transition_table


LOGGER = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    """Build parser for the table generation workflow."""

    parser = argparse.ArgumentParser(description="Build QCTSP Hawkes prototype tables.")
    parser.add_argument("--S", type=int, default=16, help="Number of eta bins.")
    parser.add_argument("--R", type=int, default=8, help="Number of tau bins.")
    parser.add_argument("--eta-max", type=float, default=8.0, help="Maximum eta-grid value.")
    parser.add_argument("--tau-max", type=float, default=4.0, help="Last finite tau edge.")
    parser.add_argument("--mu", type=float, default=0.6, help="Baseline intensity parameter.")
    parser.add_argument("--alpha", type=float, default=0.3, help="Excitation parameter.")
    parser.add_argument("--beta", type=float, default=1.1, help="Decay parameter.")
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Build tables and log basic consistency checks."""

    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    eta_grid = build_eta_grid(S=args.S, eta_max=args.eta_max)
    tau_edges = build_tau_edges(R=args.R, tau_max=args.tau_max)
    tau_mid = build_tau_midpoints(edges=tau_edges)
    p_tau_given_x = build_p_tau_given_x(
        eta_grid=eta_grid,
        tau_edges=tau_edges,
        mu=args.mu,
        alpha=args.alpha,
        beta=args.beta,
    )
    trans = build_transition_table(
        eta_grid=eta_grid,
        tau_mid=tau_mid,
        alpha=args.alpha,
        beta=args.beta,
    )

    row_sums = np.sum(p_tau_given_x, axis=1)
    max_abs_err = float(np.max(np.abs(row_sums - 1.0)))

    LOGGER.info(
        "Built grids: eta shape=%s, tau edges shape=%s, tau mid shape=%s",
        eta_grid.shape,
        tau_edges.shape,
        tau_mid.shape,
    )
    LOGGER.info(
        "p_tau_given_x shape=%s, row sum min=%.12f, max=%.12f, max_abs_err=%.3e",
        p_tau_given_x.shape,
        float(np.min(row_sums)),
        float(np.max(row_sums)),
        max_abs_err,
    )
    LOGGER.info(
        "trans shape=%s, min index=%d, max index=%d",
        trans.shape,
        int(np.min(trans)),
        int(np.max(trans)),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
