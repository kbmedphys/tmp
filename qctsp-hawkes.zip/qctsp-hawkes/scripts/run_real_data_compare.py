"""Run QCTSP-Hawkes comparison on real data sources."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class RealDataConfig:
    symbol: str
    start: str
    end: str
    time_unit: str
    max_events: int | None
    horizon: float | None


def _ensure_src_on_path() -> None:
    project_root = Path(__file__).resolve().parents[1]
    src_path = project_root / "src"
    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))


def _iter_data_files(data_dir: Path, symbol: str) -> Iterable[Path]:
    patterns = [f"*{symbol}*trades*.zip", f"*{symbol}*trades*.csv"]
    files: list[Path] = []
    for pattern in patterns:
        files.extend(sorted(data_dir.rglob(pattern)))
    return files


def _load_trade_times(paths: Iterable[Path], time_col: str) -> np.ndarray:
    times: list[np.ndarray] = []
    for path in paths:
        if path.suffix == ".zip":
            df = pd.read_csv(path, compression="zip", usecols=[time_col])
        else:
            df = pd.read_csv(path, usecols=[time_col])
        arr = pd.to_numeric(df[time_col], errors="coerce").dropna().to_numpy(dtype=np.float64)
        if arr.size > 0:
            times.append(arr)
    if not times:
        raise ValueError("no valid trade times loaded")
    return np.concatenate(times)


def _to_seconds(times: np.ndarray, unit: str) -> np.ndarray:
    if unit == "ms":
        return times / 1000.0
    if unit == "s":
        return times
    raise ValueError("time_unit must be 'ms' or 's'")


def _subsample(times: np.ndarray, max_events: int | None, seed: int) -> np.ndarray:
    if max_events is None or times.size <= max_events:
        return times
    rng = np.random.default_rng(seed)
    idx = rng.choice(times.size, size=max_events, replace=False)
    return np.sort(times[idx])


def _sanitize_tag(value: str) -> str:
    return value.replace("/", "-").replace(":", "-").replace(" ", "")


def _extract_event_mask(close: pd.Series, mode: str, threshold: float) -> np.ndarray:
    close = pd.to_numeric(close, errors="coerce")
    if mode == "bar":
        mask = np.ones(close.size, dtype=bool)
        return mask
    if mode == "price_change":
        metric = close.diff().abs()
    elif mode == "log_return":
        metric = np.log(close).diff().abs()
    else:
        raise ValueError("event_mode must be one of: bar, price_change, log_return")

    metric = metric.fillna(0.0)
    if threshold <= 0.0:
        mask = metric > 0.0
    else:
        mask = metric >= threshold
    return mask.to_numpy(dtype=bool)


def _load_yfinance_events(
    symbol: str,
    start: str,
    end: str,
    period: str,
    interval: str,
    event_mode: str,
    event_threshold: float,
    max_events: int | None,
    seed: int,
    raw_dir: Path,
) -> tuple[np.ndarray, dict]:
    try:
        import yfinance as yf
        from yfinance import cache as yf_cache
    except ImportError as exc:
        raise ImportError("yfinance is required; install via uv add yfinance --project /Users/kencharoff/workspace/envs/qc") from exc

    cache_dir = raw_dir / "yfinance_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    try:
        yf_cache.set_cache_location(str(cache_dir))
        yf_cache.set_tz_cache_location(str(cache_dir))
    except Exception:
        pass

    kwargs: dict[str, object] = {"interval": interval, "progress": False}
    if start or end:
        if start:
            kwargs["start"] = start
        if end:
            kwargs["end"] = end
    else:
        kwargs["period"] = period

    df = yf.download(symbol, **kwargs)
    if df.empty:
        raise ValueError("yfinance returned no data (check symbol/period/interval)")

    df = df.sort_index()
    close = df.get("Close")
    if close is None:
        raise ValueError("yfinance data missing Close column")

    mask = _extract_event_mask(close=close, mode=event_mode, threshold=event_threshold)
    event_index = df.index[mask]
    if event_index.size == 0:
        raise ValueError("no events selected from yfinance data (adjust event_mode/threshold)")

    times = pd.to_datetime(event_index, utc=True)
    seconds = times.view("int64").astype(np.float64) / 1e9
    seconds = np.sort(np.unique(seconds))
    seconds = _subsample(seconds, max_events=max_events, seed=seed)

    raw_dir.mkdir(parents=True, exist_ok=True)
    period_tag = _sanitize_tag(period) if period else "custom"
    range_tag = f"{_sanitize_tag(start)}_{_sanitize_tag(end)}" if (start or end) else period_tag
    filename = f"yfinance_{_sanitize_tag(symbol)}_{interval}_{range_tag}.csv"
    raw_path = raw_dir / filename
    df.to_csv(raw_path)

    meta = {
        "source": "yfinance",
        "symbol": symbol,
        "start": start,
        "end": end,
        "period": period,
        "interval": interval,
        "event_mode": event_mode,
        "event_threshold": event_threshold,
        "raw_path": str(raw_path),
        "n_bars": int(df.shape[0]),
    }
    return seconds, meta


def _load_ohlcv_csv_events(
    path: Path,
    event_mode: str,
    event_threshold: float,
    max_events: int | None,
    seed: int,
) -> tuple[np.ndarray, dict]:
    if not path.exists():
        raise FileNotFoundError(f"OHLCV CSV not found: {path}")

    df = pd.read_csv(path)
    if df.empty:
        raise ValueError("OHLCV CSV is empty")

    time_col = df.columns[0]
    if "Close" in df.columns:
        close_col = "Close"
    elif "Adj Close" in df.columns:
        close_col = "Adj Close"
    else:
        raise ValueError("OHLCV CSV missing Close column")

    times = pd.to_datetime(
        df[time_col],
        errors="coerce",
        utc=True,
        format="%Y-%m-%d %H:%M:%S%z",
    )
    close = pd.to_numeric(df[close_col], errors="coerce")
    clean = pd.DataFrame({"time": times, "close": close}).dropna()
    if clean.empty:
        raise ValueError("No valid OHLCV rows after cleaning")

    clean = clean.sort_values("time")
    close_series = clean["close"].reset_index(drop=True)
    mask = _extract_event_mask(close=close_series, mode=event_mode, threshold=event_threshold)
    event_times = clean.loc[mask, "time"]
    if event_times.empty:
        raise ValueError("no events selected from OHLCV CSV (adjust event_mode/threshold)")

    seconds = event_times.astype("int64").to_numpy(dtype=np.float64) / 1e9
    seconds = np.sort(np.unique(seconds))
    seconds = _subsample(seconds, max_events=max_events, seed=seed)

    meta = {
        "source": "ohlcv_csv",
        "ohlcv_path": str(path),
        "event_mode": event_mode,
        "event_threshold": event_threshold,
        "max_events": max_events,
        "time_col": time_col,
        "close_col": close_col,
        "n_bars": int(clean.shape[0]),
    }
    return seconds, meta


def _estimate_hawkes(times: np.ndarray, T: float, seed: int) -> "HawkesParams":
    rate = max(times.size / T, 1.0e-3)
    from qctsp_hawkes.classical.hawkes_exp import HawkesParams, fit_hawkes_exp_mle

    init = HawkesParams(mu=0.5 * rate, alpha=0.5 * rate, beta=1.0)
    fitted, result = fit_hawkes_exp_mle(times=times, T=T, init=init)
    if not result.success:
        LOGGER.warning("MLE did not converge: %s", result.message)
    if fitted.alpha / fitted.beta >= 0.98:
        LOGGER.warning("alpha/beta >= 0.98; applying shrinkage")
        fitted = HawkesParams(mu=fitted.mu, alpha=0.98 * fitted.beta, beta=fitted.beta)
    return fitted


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run real-data comparison for QCTSP-Hawkes.")
    parser.add_argument(
        "--source",
        type=str,
        default="files",
        choices=("files", "yfinance", "ohlcv_csv"),
        help="Data source: local trade files, yfinance, or OHLCV CSV.",
    )
    parser.add_argument("--data-dir", type=Path, default=Path("outputs/real_data/raw"))
    parser.add_argument("--ohlcv-path", type=Path, default=Path("data/btc-usd.csv"))
    parser.add_argument("--symbol", type=str, default="BTCUSD", help="Symbol or ticker.")
    parser.add_argument("--start", type=str, default="", help="YYYY-MM-DD (optional)")
    parser.add_argument("--end", type=str, default="", help="YYYY-MM-DD (optional)")
    parser.add_argument("--time-col", type=str, default="time")
    parser.add_argument("--time-unit", type=str, default="ms", choices=("ms", "s"))
    parser.add_argument("--max-events", type=int, default=200000)
    parser.add_argument("--horizon", type=float, default=None)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--yf-period", type=str, default="30d")
    parser.add_argument("--yf-interval", type=str, default="5m")
    parser.add_argument(
        "--event-mode",
        type=str,
        default="price_change",
        choices=("bar", "price_change", "log_return"),
        help="Event definition for OHLCV (yfinance or CSV).",
    )
    parser.add_argument(
        "--event-threshold",
        type=float,
        default=0.0,
        help="Threshold for event_mode (price/log-return).",
    )

    parser.add_argument("--S", type=int, default=8)
    parser.add_argument("--R", type=int, default=16)
    parser.add_argument("--tau-max", type=float, default=5.0)
    parser.add_argument("--eta-max", type=float, default=8.0)
    parser.add_argument("--n-steps", type=int, default=3)
    parser.add_argument("--shots", type=int, default=200)
    parser.add_argument("--qctsp-backend", type=str, default="classical", choices=("classical", "auto", "aer"))
    parser.add_argument("--auto-n-steps", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--tau-repr-mode", type=str, default="midpoint", choices=("midpoint", "condexp"))
    parser.add_argument("--tau-edges-mode", type=str, default="linear", choices=("linear", "exp-quantile"))
    parser.add_argument("--lambda-ref-mode", type=str, default="mu", choices=("mu", "lambda_x0", "lambda_mean"))

    parser.add_argument("--out-dir", type=Path, default=Path("outputs/real_data"))
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    _ensure_src_on_path()

    from qctsp_hawkes.validation.compare import ComparisonConfig, run_validation_comparison

    if args.source == "files":
        data_dir = args.data_dir
        files = list(_iter_data_files(data_dir=data_dir, symbol=args.symbol))
        if not files:
            raise FileNotFoundError(f"no trade files found in {data_dir}")

        raw_times = _load_trade_times(paths=files, time_col=args.time_col)
        seconds = _to_seconds(times=raw_times, unit=args.time_unit)
        seconds = np.sort(np.unique(seconds))
        seconds = _subsample(seconds, max_events=args.max_events, seed=args.seed)
        if seconds.size < 2:
            raise ValueError("not enough events after preprocessing")
        meta_source = {"source": "files", "source_files": [str(p) for p in files]}
    elif args.source == "yfinance":
        seconds, meta_source = _load_yfinance_events(
            symbol=args.symbol,
            start=args.start,
            end=args.end,
            period=args.yf_period,
            interval=args.yf_interval,
            event_mode=args.event_mode,
            event_threshold=args.event_threshold,
            max_events=args.max_events,
            seed=args.seed,
            raw_dir=args.data_dir,
        )
        if seconds.size < 2:
            raise ValueError("not enough events from yfinance after preprocessing")
    else:
        seconds, meta_source = _load_ohlcv_csv_events(
            path=args.ohlcv_path,
            event_mode=args.event_mode,
            event_threshold=args.event_threshold,
            max_events=args.max_events,
            seed=args.seed,
        )
        if seconds.size < 2:
            raise ValueError("not enough events from OHLCV CSV after preprocessing")

    rel_times = seconds - seconds[0]
    rel_times = rel_times[rel_times > 0.0]
    if rel_times.size < 2:
        raise ValueError("not enough events after removing t=0")

    horizon = float(args.horizon) if args.horizon is not None else float(rel_times[-1])
    rel_times = rel_times[rel_times <= horizon]
    if rel_times.size < 2:
        raise ValueError("not enough events within horizon")

    fitted = _estimate_hawkes(times=rel_times, T=horizon, seed=args.seed)
    LOGGER.info("Estimated params: mu=%.6f alpha=%.6f beta=%.6f", fitted.mu, fitted.alpha, fitted.beta)

    config = ComparisonConfig(
        T=horizon,
        mu=fitted.mu,
        alpha=fitted.alpha,
        beta=fitted.beta,
        S=args.S,
        R=args.R,
        tau_max=args.tau_max,
        eta_max=args.eta_max,
        n_steps=args.n_steps,
        shots=args.shots,
        classical_paths=min(200, rel_times.size),
        seed=args.seed,
        x0=0,
        qctsp_backend=args.qctsp_backend,
        auto_n_steps=args.auto_n_steps,
        tau_repr_mode=args.tau_repr_mode,
        tau_edges_mode=args.tau_edges_mode,
        lambda_ref_mode=args.lambda_ref_mode,
    )

    out_dir = args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    report_path = out_dir / "real_data_report.json"

    report, saved_path = run_validation_comparison(config=config, output_path=report_path)
    LOGGER.info("Saved report: %s", saved_path)

    meta = {
        "symbol": args.symbol,
        "start": args.start,
        "end": args.end,
        "n_events": int(rel_times.size),
        "T": horizon,
        "mu": fitted.mu,
        "alpha": fitted.alpha,
        "beta": fitted.beta,
        "alpha_over_beta": float(fitted.alpha / fitted.beta),
        "n_steps": args.n_steps,
        "auto_n_steps": args.auto_n_steps,
        "tau_repr_mode": args.tau_repr_mode,
        "tau_edges_mode": args.tau_edges_mode,
        "lambda_ref_mode": args.lambda_ref_mode,
        "qctsp_backend": args.qctsp_backend,
        "shots": args.shots,
        "S": args.S,
        "R": args.R,
        "tau_max": args.tau_max,
        "eta_max": args.eta_max,
    }
    meta.update(meta_source)
    meta_path = out_dir / "real_data_meta.json"
    meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False))

    # Append to table_05
    table_path = Path("outputs/tables/table_05_real_data_summary.csv")
    if table_path.exists():
        note_parts = [
            f"source={meta_source.get('source', 'unknown')}",
            f"event_mode={args.event_mode}",
            f"event_threshold={args.event_threshold}",
            f"tau_repr={args.tau_repr_mode}",
            f"tau_edges={args.tau_edges_mode}",
            f"n_steps={args.n_steps}",
            f"auto_n_steps={args.auto_n_steps}",
        ]
        if args.source == "ohlcv_csv":
            note_parts.append(f"ohlcv={Path(args.ohlcv_path).name}")
        elif args.source == "yfinance":
            note_parts.append(f"interval={args.yf_interval}")
        else:
            note_parts.append(f"time_col={args.time_col}")
        note = "note: " + ";".join(note_parts)

        line = (
            f"{args.symbol},{args.start},{args.end},{rel_times.size},{horizon:.6f},"
            f"{fitted.mu:.6f},{fitted.alpha:.6f},{fitted.beta:.6f},{fitted.alpha / fitted.beta:.6f},"
            f"{report['classical']['N_T']['mean']},{report['qctsp']['N_T']['mean']},"
            f"{report['classical']['I_lambda']['mean']},{report['qctsp']['I_lambda']['mean']},"
            f"{report['classical']['ks_pvalue']['mean']},{report['qctsp']['ks_pvalue']['mean']},"
            f"{note}"
        )
        with table_path.open("a", encoding="utf-8") as fp:
            fp.write(line + "\n")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
