# qctsp-hawkes

Prototype implementation of a Hawkes process in the QCTSP framework, including
classical simulation, discretization, lookup-based quantum circuits, and
validation comparisons.

## Environment

- Use the shared uv environment at `/Users/kencharoff/workspace/envs/qc`.
- Sync dependencies with uv (no direct pip):

```bash
uv sync --project /Users/kencharoff/workspace/envs/qc
```

- Run commands with the qc interpreter:

```bash
/Users/kencharoff/workspace/envs/qc/.venv/bin/python --version
```

## Quickstart

```bash
/Users/kencharoff/workspace/envs/qc/.venv/bin/python scripts/run_build_tables.py --help
/Users/kencharoff/workspace/envs/qc/.venv/bin/python scripts/run_sample_qctsp.py --help
/Users/kencharoff/workspace/envs/qc/.venv/bin/python scripts/run_compare.py --help
/Users/kencharoff/workspace/envs/qc/.venv/bin/python -m pytest
```

## Notebook

古典 Hawkes と QCTSP の比較は以下のノートブックで確認できます。

- `output/jupyter-notebook/qctsp_hawkes_compare.ipynb`

ノートブックを開いて上から実行すると、`outputs/compare_report.json` と
`outputs/figures/` 配下に図が生成されます。

## Real Data (yfinance)

実データ比較は `yfinance` を用いて OHLCV データからイベント時刻を作成します。
依存関係は qc 環境に追加してください。

```bash
uv add yfinance --project /Users/kencharoff/workspace/envs/qc
```

実行例:

```bash
/Users/kencharoff/workspace/envs/qc/.venv/bin/python scripts/run_real_data_compare.py \
  --source yfinance \
  --symbol BTC-USD \
  --yf-period 30d \
  --yf-interval 5m \
  --event-mode price_change \
  --event-threshold 0.0
```

## Real Data (local OHLCV CSV)

ローカルの OHLCV CSV（例: `data/btc-usd.csv`）からイベント時刻を作成して比較できます。

```bash
/Users/kencharoff/workspace/envs/qc/.venv/bin/python scripts/run_real_data_compare.py \
  --source ohlcv_csv \
  --ohlcv-path data/btc-usd.csv \
  --event-mode price_change \
  --event-threshold 0.0 \
  --max-events 50000
```

## Outputs

Generated artifacts (reports, debug dumps) are written under `outputs/`.
