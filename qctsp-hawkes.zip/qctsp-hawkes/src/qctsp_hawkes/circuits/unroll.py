"""Circuit unrolling and measurement parsing for the QCTSP Hawkes prototype."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Mapping

import numpy as np
from qiskit import ClassicalRegister, QuantumCircuit, QuantumRegister

from qctsp_hawkes.circuits.state_prep_lookup import append_conditional_tau_preparation
from qctsp_hawkes.circuits.transition_lookup import append_transition_update


@dataclass(frozen=True, slots=True)
class QCTSPMeasurementLayout:
    """Classical-bit layout used to decode measured QCTSP samples."""

    n_x_bits: int
    n_tau_bits: int
    n_steps: int
    measure_x_path: bool
    x0_slice: tuple[int, int]
    tau_slices: tuple[tuple[int, int], ...]
    x_slices: tuple[tuple[int, int], ...]
    total_bits: int


@dataclass(frozen=True, slots=True)
class ParsedQCTSPSample:
    """One decoded sample path from measured bitstrings."""

    x0: int
    tau_indices: tuple[int, ...]
    x_indices: tuple[int, ...]


def _require_positive_int(name: str, value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise ValueError(f"{name} must be an integer.")
    if int(value) <= 0:
        raise ValueError(f"{name} must be > 0.")
    return int(value)


def _required_qubits(n_states: int) -> int:
    _require_positive_int(name="n_states", value=n_states)
    return int(np.ceil(np.log2(n_states)))


def _bits_little_endian(index: int, width: int) -> list[int]:
    return [(index >> bit) & 1 for bit in range(width)]


def _validate_small_scale(S: int, R: int, n_steps: int) -> None:
    if S > 16:
        raise ValueError("Small-scale prototype supports S<=16.")
    if R > 32:
        raise ValueError("Small-scale prototype supports R<=32.")
    if n_steps > 6:
        raise ValueError("Small-scale prototype supports n_steps<=6.")


def _build_layout(n_x_bits: int, n_tau_bits: int, n_steps: int, measure_x_path: bool) -> QCTSPMeasurementLayout:
    offset = 0
    x0_slice = (offset, offset + n_x_bits)
    offset += n_x_bits

    tau_slices_list: list[tuple[int, int]] = []
    x_slices_list: list[tuple[int, int]] = []
    for _ in range(n_steps):
        tau_slice = (offset, offset + n_tau_bits)
        tau_slices_list.append(tau_slice)
        offset += n_tau_bits
        if measure_x_path:
            x_slice = (offset, offset + n_x_bits)
            x_slices_list.append(x_slice)
            offset += n_x_bits

    return QCTSPMeasurementLayout(
        n_x_bits=n_x_bits,
        n_tau_bits=n_tau_bits,
        n_steps=n_steps,
        measure_x_path=measure_x_path,
        x0_slice=x0_slice,
        tau_slices=tuple(tau_slices_list),
        x_slices=tuple(x_slices_list),
        total_bits=offset,
    )


def _parse_uint_from_bits_little_endian(bits: str, start: int, stop: int) -> int:
    value = 0
    for bit_idx in range(start, stop):
        if bits[bit_idx] == "1":
            value |= 1 << (bit_idx - start)
    return value


def build_unroll_plan(n_steps: int) -> list[tuple[int, int]]:
    """Return pair indices (k-1, k) for each unrolled update step."""

    n = _require_positive_int(name="n_steps", value=n_steps)
    return [(k - 1, k) for k in range(1, n + 1)]


def build_qctsp_unroll_circuit(
    p_tau_given_x: np.ndarray,
    transition_table: np.ndarray,
    n_steps: int,
    x0: int = 0,
    measure_x_path: bool = True,
) -> tuple[QuantumCircuit, QCTSPMeasurementLayout]:
    """Build unrolled circuit for x/tau path sampling.

    The circuit measures x0 and tau_1..tau_n; by default it also measures x_1..x_n.
    A single tau register is reused across steps with mid-circuit measure+reset.
    """

    probs = np.asarray(p_tau_given_x, dtype=np.float64)
    trans = np.asarray(transition_table)
    if probs.ndim != 2:
        raise ValueError("p_tau_given_x must be a 2D array [S, R].")
    if trans.ndim != 2:
        raise ValueError("transition_table must be a 2D array [S, R].")
    if probs.shape != trans.shape:
        raise ValueError("p_tau_given_x and transition_table must share shape [S, R].")

    S, R = int(probs.shape[0]), int(probs.shape[1])
    if S < 2 or R < 2:
        raise ValueError("Need S>=2 and R>=2.")

    n = _require_positive_int(name="n_steps", value=n_steps)
    _validate_small_scale(S=S, R=R, n_steps=n)
    if x0 < 0 or x0 >= S:
        raise ValueError("x0 must satisfy 0 <= x0 < S.")

    n_x_bits = _required_qubits(n_states=S)
    n_tau_bits = _required_qubits(n_states=R)

    x_registers = [QuantumRegister(n_x_bits, name=f"x{k}") for k in range(n + 1)]
    tau_register = QuantumRegister(n_tau_bits, name="tau")
    layout = _build_layout(
        n_x_bits=n_x_bits,
        n_tau_bits=n_tau_bits,
        n_steps=n,
        measure_x_path=measure_x_path,
    )
    c_meas = ClassicalRegister(layout.total_bits, name="m")
    circuit = QuantumCircuit(*x_registers, tau_register, c_meas, name="qctsp_unroll")

    for bit_pos, bit_val in enumerate(_bits_little_endian(index=x0, width=n_x_bits)):
        if bit_val == 1:
            circuit.x(x_registers[0][bit_pos])

    for step_idx, (prev_idx, curr_idx) in enumerate(build_unroll_plan(n_steps=n)):
        append_conditional_tau_preparation(
            circuit=circuit,
            x_qubits=x_registers[prev_idx],
            tau_qubits=tau_register,
            p_tau_given_x=probs,
        )
        append_transition_update(
            circuit=circuit,
            x_prev_qubits=x_registers[prev_idx],
            tau_qubits=tau_register,
            x_next_qubits=x_registers[curr_idx],
            transition_table=trans,
        )

        tau_start, tau_stop = layout.tau_slices[step_idx]
        circuit.measure(tau_register, c_meas[tau_start:tau_stop])
        if step_idx < (n - 1):
            circuit.reset(tau_register)

    x0_start, x0_stop = layout.x0_slice
    circuit.measure(x_registers[0], c_meas[x0_start:x0_stop])
    for step_idx in range(n):
        if measure_x_path:
            x_start, x_stop = layout.x_slices[step_idx]
            circuit.measure(x_registers[step_idx + 1], c_meas[x_start:x_stop])

    return circuit, layout


def parse_qctsp_bitstring(bitstring: str, layout: QCTSPMeasurementLayout) -> ParsedQCTSPSample:
    """Decode one measured bitstring into x/tau indices."""

    compact = bitstring.replace(" ", "")
    if len(compact) != layout.total_bits:
        raise ValueError(
            "bitstring length does not match measurement layout: "
            f"{len(compact)} != {layout.total_bits}"
        )
    bits_little_endian = compact[::-1]

    x0 = _parse_uint_from_bits_little_endian(
        bits=bits_little_endian,
        start=layout.x0_slice[0],
        stop=layout.x0_slice[1],
    )
    tau_indices = tuple(
        _parse_uint_from_bits_little_endian(bits=bits_little_endian, start=start, stop=stop)
        for start, stop in layout.tau_slices
    )
    x_indices = tuple(
        _parse_uint_from_bits_little_endian(bits=bits_little_endian, start=start, stop=stop)
        for start, stop in layout.x_slices
    )
    return ParsedQCTSPSample(x0=x0, tau_indices=tau_indices, x_indices=x_indices)


def parse_qctsp_counts(
    counts: Mapping[str, int],
    layout: QCTSPMeasurementLayout,
) -> list[ParsedQCTSPSample]:
    """Decode sampled count dictionary into per-shot parsed samples."""

    samples: list[ParsedQCTSPSample] = []
    for bitstring, freq in counts.items():
        freq_int = int(freq)
        if freq_int < 0:
            raise ValueError("counts frequencies must be non-negative.")
        parsed = parse_qctsp_bitstring(bitstring=bitstring, layout=layout)
        samples.extend([parsed] * freq_int)
    return samples


def encode_qctsp_sample(sample: ParsedQCTSPSample, layout: QCTSPMeasurementLayout) -> str:
    """Encode one parsed sample into a count-key-compatible bitstring."""

    bits_little_endian = ["0"] * layout.total_bits

    def _write_uint(value: int, start: int, stop: int) -> None:
        if value < 0:
            raise ValueError("sample indices must be non-negative.")
        width = stop - start
        if value >= (1 << width):
            raise ValueError("sample index does not fit in allocated bit width.")
        for bit_idx in range(width):
            bits_little_endian[start + bit_idx] = "1" if ((value >> bit_idx) & 1) else "0"

    _write_uint(value=sample.x0, start=layout.x0_slice[0], stop=layout.x0_slice[1])
    if len(sample.tau_indices) != layout.n_steps:
        raise ValueError("tau_indices length must match layout.n_steps.")
    for (start, stop), tau_idx in zip(layout.tau_slices, sample.tau_indices):
        _write_uint(value=tau_idx, start=start, stop=stop)
    if layout.measure_x_path:
        if len(sample.x_indices) != layout.n_steps:
            raise ValueError("x_indices length must match layout.n_steps when measure_x_path=True.")
        for (start, stop), x_idx in zip(layout.x_slices, sample.x_indices):
            _write_uint(value=x_idx, start=start, stop=stop)

    return "".join(bits_little_endian[::-1])


def samples_to_counts(
    samples: list[ParsedQCTSPSample],
    layout: QCTSPMeasurementLayout,
) -> dict[str, int]:
    """Aggregate parsed samples into a qiskit-compatible count dictionary."""

    return dict(Counter(encode_qctsp_sample(sample=sample, layout=layout) for sample in samples))


def sample_qctsp_classically(
    p_tau_given_x: np.ndarray,
    transition_table: np.ndarray,
    n_steps: int,
    x0: int,
    shots: int,
    seed: int | None = None,
    measure_x_path: bool = True,
) -> list[ParsedQCTSPSample]:
    """Classical reference sampler for the same lookup model used by the circuit."""

    probs = np.asarray(p_tau_given_x, dtype=np.float64)
    trans = np.asarray(transition_table, dtype=np.int64)
    if probs.ndim != 2 or trans.ndim != 2 or probs.shape != trans.shape:
        raise ValueError("p_tau_given_x and transition_table must be same-shape 2D arrays.")
    if n_steps <= 0:
        raise ValueError("n_steps must be > 0.")
    if shots <= 0:
        raise ValueError("shots must be > 0.")

    S, R = probs.shape
    if x0 < 0 or x0 >= S:
        raise ValueError("x0 must satisfy 0 <= x0 < S.")
    if np.any(trans < 0) or np.any(trans >= S):
        raise ValueError("transition_table entries must be in [0, S-1].")

    row_sums = probs.sum(axis=1, keepdims=True)
    if np.any(row_sums <= 0.0):
        raise ValueError("every p_tau_given_x row must have positive sum.")
    normalized = probs / row_sums

    rng = np.random.default_rng(seed)
    samples: list[ParsedQCTSPSample] = []
    for _ in range(shots):
        x_curr = int(x0)
        taus: list[int] = []
        xs: list[int] = []
        for _step in range(n_steps):
            tau_idx = int(rng.choice(R, p=normalized[x_curr]))
            taus.append(tau_idx)
            x_curr = int(trans[x_curr, tau_idx])
            if measure_x_path:
                xs.append(x_curr)
        samples.append(
            ParsedQCTSPSample(
                x0=int(x0),
                tau_indices=tuple(taus),
                x_indices=tuple(xs),
            )
        )
    return samples


__all__ = [
    "ParsedQCTSPSample",
    "QCTSPMeasurementLayout",
    "encode_qctsp_sample",
    "build_qctsp_unroll_circuit",
    "build_unroll_plan",
    "parse_qctsp_bitstring",
    "parse_qctsp_counts",
    "sample_qctsp_classically",
    "samples_to_counts",
]
