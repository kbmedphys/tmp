"""Lookup-based conditional state preparation helpers for tau registers."""

from __future__ import annotations

from typing import Sequence

import numpy as np
from numpy.typing import NDArray
from qiskit import QuantumCircuit
from qiskit.circuit import Qubit
from qiskit.circuit.library import StatePreparation


FloatArray = NDArray[np.float64]


def _require_positive_int(name: str, value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise ValueError(f"{name} must be an integer.")
    if int(value) <= 0:
        raise ValueError(f"{name} must be > 0.")
    return int(value)


def _required_qubits(n_states: int) -> int:
    _require_positive_int(name="n_states", value=n_states)
    return int(np.ceil(np.log2(n_states)))


def _bits_little_endian(index: int, width: int) -> list[int]:
    return [(index >> bit) & 1 for bit in range(width)]


def _validate_probability_row(probabilities: np.ndarray) -> FloatArray:
    row = np.asarray(probabilities, dtype=np.float64)
    if row.ndim != 1:
        raise ValueError("probabilities must be a 1D array.")
    if row.size < 2:
        raise ValueError("probabilities must contain at least 2 entries.")
    if not np.all(np.isfinite(row)):
        raise ValueError("probabilities must contain finite values.")
    if np.any(row < 0.0):
        raise ValueError("probabilities must be non-negative.")
    total = float(np.sum(row))
    if total <= 0.0:
        raise ValueError("probabilities must have positive sum.")
    return row / total


def _validate_probability_table(probabilities: np.ndarray) -> FloatArray:
    table = np.asarray(probabilities, dtype=np.float64)
    if table.ndim != 2:
        raise ValueError("probabilities must be a 2D array with shape [S, R].")
    if table.shape[0] < 2 or table.shape[1] < 2:
        raise ValueError("probabilities must have shape [S, R] with S>=2 and R>=2.")
    if not np.all(np.isfinite(table)):
        raise ValueError("probabilities must contain finite values.")
    if np.any(table < 0.0):
        raise ValueError("probabilities must be non-negative.")

    row_sums = np.sum(table, axis=1, keepdims=True)
    if np.any(row_sums <= 0.0):
        raise ValueError("each row of probabilities must have positive sum.")
    return table / row_sums


def _build_amplitudes_for_row(probabilities: FloatArray, n_tau_qubits: int) -> NDArray[np.complex128]:
    if probabilities.size > (1 << n_tau_qubits):
        raise ValueError("tau register is too small for the probability row.")
    amplitudes = np.zeros(1 << n_tau_qubits, dtype=np.complex128)
    amplitudes[: probabilities.size] = np.sqrt(probabilities.astype(np.complex128))
    return amplitudes


def _apply_control_pattern(circuit: QuantumCircuit, controls: Sequence[Qubit], pattern: Sequence[int]) -> None:
    if len(controls) != len(pattern):
        raise ValueError("control qubits and bit pattern lengths must match.")
    for qubit, bit in zip(controls, pattern):
        if bit == 0:
            circuit.x(qubit)


def build_state_prep_lookup(probabilities: Sequence[float]) -> dict[str, float]:
    """Build a classical lookup from basis index bitstrings to probabilities."""

    row = _validate_probability_row(probabilities=np.asarray(probabilities, dtype=np.float64))
    width = _required_qubits(n_states=row.size)
    lookup: dict[str, float] = {}
    for idx, prob in enumerate(row):
        if prob > 0.0:
            key = format(idx, f"0{width}b")
            lookup[key] = float(prob)
    return lookup


def append_conditional_tau_preparation(
    circuit: QuantumCircuit,
    x_qubits: Sequence[Qubit],
    tau_qubits: Sequence[Qubit],
    p_tau_given_x: np.ndarray,
) -> None:
    """Append lookup-based tau preparation controlled on |x>.

    Complexity is O(S) controlled state-preparation blocks, where S is the number
    of eta states. This is intentionally simple and not depth-optimal.
    """

    controls = list(x_qubits)
    targets = list(tau_qubits)
    table = _validate_probability_table(probabilities=p_tau_given_x)
    n_x_required = _required_qubits(n_states=table.shape[0])
    n_tau_required = _required_qubits(n_states=table.shape[1])

    if len(controls) != n_x_required:
        raise ValueError(f"x register size must be {n_x_required} qubits.")
    if len(targets) != n_tau_required:
        raise ValueError(f"tau register size must be {n_tau_required} qubits.")

    for x_idx in range(table.shape[0]):
        pattern = _bits_little_endian(index=x_idx, width=n_x_required)
        _apply_control_pattern(circuit=circuit, controls=controls, pattern=pattern)
        amplitudes = _build_amplitudes_for_row(
            probabilities=table[x_idx],
            n_tau_qubits=n_tau_required,
        )
        state_prep_gate = StatePreparation(amplitudes).control(num_ctrl_qubits=n_x_required)
        circuit.append(state_prep_gate, controls + targets)
        _apply_control_pattern(circuit=circuit, controls=controls, pattern=pattern)


__all__ = ["append_conditional_tau_preparation", "build_state_prep_lookup"]
