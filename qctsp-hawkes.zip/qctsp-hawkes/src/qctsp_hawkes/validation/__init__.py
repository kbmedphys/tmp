"""Validation and comparison utilities."""

from qctsp_hawkes.validation.compare import (
    ComparisonArtifacts,
    ComparisonConfig,
    build_comparison_report,
    build_qctsp_tau_debug,
    compare_samples,
    run_validation_comparison,
    save_comparison_report,
    save_json_artifact,
)
from qctsp_hawkes.validation.metrics import (
    PathMetrics,
    ValidationSummary,
    compute_path_metrics,
    compute_validation_summary,
    integral_eta_rect,
    integral_lambda_rect,
    summarize_path_metrics,
)

__all__ = [
    "ComparisonArtifacts",
    "ComparisonConfig",
    "PathMetrics",
    "ValidationSummary",
    "build_comparison_report",
    "build_qctsp_tau_debug",
    "compare_samples",
    "compute_path_metrics",
    "compute_validation_summary",
    "integral_eta_rect",
    "integral_lambda_rect",
    "run_validation_comparison",
    "save_comparison_report",
    "save_json_artifact",
    "summarize_path_metrics",
]
