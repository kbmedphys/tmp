"""Comparison pipeline for classical-vs-qctsp Hawkes validation."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import logging
from math import ceil
from pathlib import Path
import platform
from typing import Any, Literal, Sequence

import numpy as np
from qiskit import transpile

from qctsp_hawkes.classical.hawkes_exp import simulate_hawkes_exp_ogata
from qctsp_hawkes.circuits.unroll import (
    ParsedQCTSPSample,
    build_qctsp_unroll_circuit,
    parse_qctsp_counts,
    sample_qctsp_classically,
)
from qctsp_hawkes.discretization import (
    build_eta_grid,
    build_p_tau_given_x,
    build_tau_edges,
    tau_bin_representative_condexp,
    tau_bin_representative_midpoint,
)
from qctsp_hawkes.transition_tables import build_transition_table
from qctsp_hawkes.validation.metrics import (
    PathMetrics,
    ValidationSummary,
    compute_path_metrics,
    compute_validation_summary,
    summarize_path_metrics,
)


LOGGER = logging.getLogger(__name__)

BackendMode = Literal["auto", "aer", "classical"]
TauReprMode = Literal["midpoint", "condexp"]
TauEdgesMode = Literal["linear", "exp-quantile"]
LambdaRefMode = Literal["mu", "lambda_x0", "lambda_mean"]


@dataclass(frozen=True, slots=True)
class ComparisonArtifacts:
    """Bundle of sequence-level comparison inputs and metrics."""

    classical_samples: Sequence[float]
    qctsp_samples: Sequence[float]
    metrics: ValidationSummary


@dataclass(frozen=True, slots=True)
class ComparisonConfig:
    """Configuration for end-to-end classical-vs-qctsp comparison."""

    T: float = 10.0
    mu: float = 0.8
    alpha: float = 0.6
    beta: float = 1.5
    S: int = 8
    R: int = 16
    tau_max: float = 5.0
    eta_max: float = 8.0
    n_steps: int = 3
    shots: int = 200
    classical_paths: int = 200
    seed: int = 7
    x0: int = 0
    qctsp_backend: BackendMode = "auto"
    auto_n_steps: bool = True
    tau_repr_mode: TauReprMode = "midpoint"
    tau_edges_mode: TauEdgesMode = "linear"
    lambda_ref_mode: LambdaRefMode = "mu"


def _validate_config(config: ComparisonConfig) -> None:
    if not np.isfinite(config.T) or config.T <= 0.0:
        raise ValueError("T must be a finite positive float.")
    if not np.isfinite(config.mu) or config.mu <= 0.0:
        raise ValueError("mu must be a finite positive float.")
    if not np.isfinite(config.alpha) or config.alpha < 0.0:
        raise ValueError("alpha must be a finite non-negative float.")
    if not np.isfinite(config.beta) or config.beta <= 0.0:
        raise ValueError("beta must be a finite positive float.")
    if config.S < 2 or config.S > 16:
        raise ValueError("S must satisfy 2 <= S <= 16.")
    if config.R < 2 or config.R > 32:
        raise ValueError("R must satisfy 2 <= R <= 32.")
    if not np.isfinite(config.tau_max) or config.tau_max <= 0.0:
        raise ValueError("tau_max must be a finite positive float.")
    if not np.isfinite(config.eta_max) or config.eta_max <= 0.0:
        raise ValueError("eta_max must be a finite positive float.")
    if config.n_steps <= 0:
        raise ValueError("n_steps must be positive.")
    if config.shots <= 0:
        raise ValueError("shots must be positive.")
    if config.classical_paths <= 0:
        raise ValueError("classical_paths must be positive.")
    if config.x0 < 0 or config.x0 >= config.S:
        raise ValueError("x0 must satisfy 0 <= x0 < S.")
    if config.qctsp_backend not in {"auto", "aer", "classical"}:
        raise ValueError("qctsp_backend must be one of: auto, aer, classical.")
    if config.tau_repr_mode not in {"midpoint", "condexp"}:
        raise ValueError("tau_repr_mode must be one of: midpoint, condexp.")
    if config.tau_edges_mode not in {"linear", "exp-quantile"}:
        raise ValueError("tau_edges_mode must be one of: linear, exp-quantile.")
    if config.lambda_ref_mode not in {"mu", "lambda_x0", "lambda_mean"}:
        raise ValueError("lambda_ref_mode must be one of: mu, lambda_x0, lambda_mean.")


def _is_aer_runtime_safe() -> bool:
    """Best-effort guard against OpenMP shared-memory issues in restricted runtime."""

    if platform.system() == "Darwin" and not Path("/dev/shm").exists():
        return False
    return True


def _get_aer_backend(seed: int):
    """Return an Aer backend for qasm sampling across qiskit version variants."""

    try:
        from qiskit_aer import AerSimulator

        return AerSimulator(seed_simulator=seed, max_parallel_threads=1)
    except Exception:  # pragma: no cover - fallback for older Aer API
        from qiskit import Aer

        backend = Aer.get_backend("qasm_simulator")
        backend.set_options(seed_simulator=seed)
        return backend


def _resolve_lambda_ref(config: ComparisonConfig, eta_grid: np.ndarray) -> float:
    if config.lambda_ref_mode == "mu":
        lambda_ref = float(config.mu)
    elif config.lambda_ref_mode == "lambda_x0":
        lambda_ref = float(config.mu + (config.alpha * float(eta_grid[config.x0])))
    elif config.lambda_ref_mode == "lambda_mean":
        lambda_ref = float(config.mu + (config.alpha * float(np.mean(eta_grid))))
    else:  # pragma: no cover
        raise ValueError(f"Unsupported lambda_ref_mode: {config.lambda_ref_mode}")

    if not np.isfinite(lambda_ref) or lambda_ref <= 0.0:
        raise ValueError("Resolved lambda_ref must be finite and positive.")
    return lambda_ref


def _build_qctsp_discretization(
    config: ComparisonConfig,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]:
    eta_grid = build_eta_grid(S=config.S, eta_max=config.eta_max)
    lambda_ref = _resolve_lambda_ref(config=config, eta_grid=eta_grid)
    tau_edges = build_tau_edges(
        R=config.R,
        tau_max=config.tau_max,
        mode=config.tau_edges_mode,
        lambda_ref=lambda_ref,
    )
    if config.tau_repr_mode == "midpoint":
        tau_repr = tau_bin_representative_midpoint(tau_edges=tau_edges)
    else:
        tau_repr = tau_bin_representative_condexp(tau_edges=tau_edges, rate=lambda_ref)

    transition_table = build_transition_table(
        eta_grid=eta_grid,
        tau_mid=tau_repr,
        alpha=config.alpha,
        beta=config.beta,
    )
    return eta_grid, tau_edges, tau_repr, transition_table, lambda_ref


def _tau_indices_to_values(sample: ParsedQCTSPSample, tau_repr: np.ndarray) -> np.ndarray:
    tau_idx = np.asarray(sample.tau_indices, dtype=np.int64)
    if np.any(tau_idx < 0) or np.any(tau_idx >= tau_repr.size):
        raise ValueError("tau index out of range.")
    return tau_repr[tau_idx]


def _tau_values_to_times(tau_values: np.ndarray, T: float) -> np.ndarray:
    """Convert tau durations to event times and truncate with cumsum<=T."""

    cumulative_times = np.cumsum(tau_values, dtype=np.float64)
    return cumulative_times[cumulative_times <= T]


def _clip_eta_tau_to_horizon(
    eta_seq: np.ndarray,
    tau_seq: np.ndarray,
    T: float,
    eta_tail: float | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Clip/extend rectangle sequences so durations cover [0, T]."""

    eta = np.asarray(eta_seq, dtype=np.float64)
    tau = np.asarray(tau_seq, dtype=np.float64)
    if eta.ndim != 1 or tau.ndim != 1 or eta.size != tau.size:
        raise ValueError("eta_seq and tau_seq must be 1D arrays with the same length.")
    if not np.isfinite(T) or T <= 0.0:
        raise ValueError("T must be a finite positive float.")

    eta_out: list[float] = []
    tau_out: list[float] = []
    remaining = float(T)
    for eta_k, tau_k in zip(eta, tau):
        if remaining <= 0.0:
            break
        dt = min(max(float(tau_k), 0.0), remaining)
        if dt > 0.0:
            eta_out.append(float(eta_k))
            tau_out.append(dt)
            remaining -= dt

    if remaining > 0.0:
        if eta_tail is not None:
            tail_eta = float(eta_tail)
        elif eta.size > 0:
            tail_eta = float(eta[-1])
        else:
            tail_eta = 0.0
        eta_out.append(tail_eta)
        tau_out.append(remaining)

    return np.asarray(eta_out, dtype=np.float64), np.asarray(tau_out, dtype=np.float64)


def _classical_rect_sequences(times: np.ndarray, T: float, beta: float) -> tuple[np.ndarray, np.ndarray]:
    """Rectangle convention for classical paths.

    We use eta just-after-event on each next inter-arrival interval and add
    the initial [0, t1) segment with eta=0 so durations cover [0, T].
    """

    arr = np.asarray(times, dtype=np.float64)
    if arr.ndim != 1:
        raise ValueError("times must be a 1D array.")
    if arr.size == 0:
        return np.asarray([0.0], dtype=np.float64), np.asarray([float(T)], dtype=np.float64)

    arr = np.sort(arr)
    arr = arr[(arr > 0.0) & (arr <= T)]
    if arr.size == 0:
        return np.asarray([0.0], dtype=np.float64), np.asarray([float(T)], dtype=np.float64)

    n_events = int(arr.size)
    eta_after = np.empty(n_events, dtype=np.float64)
    prev_time = 0.0
    eta_after_prev = 0.0
    for idx, t_i in enumerate(arr):
        dt = float(t_i - prev_time)
        eta_before = eta_after_prev * np.exp(-beta * dt)
        eta_after[idx] = eta_before + 1.0
        prev_time = float(t_i)
        eta_after_prev = eta_after[idx]

    eta = np.empty(n_events + 1, dtype=np.float64)
    tau = np.empty(n_events + 1, dtype=np.float64)
    eta[0] = 0.0
    tau[0] = float(arr[0])
    eta[1:] = eta_after
    if n_events > 1:
        tau[1:n_events] = np.diff(arr)
    tau[n_events] = max(float(T - arr[-1]), 0.0)
    return eta, tau


def _qctsp_rect_sequences(
    sample: ParsedQCTSPSample,
    eta_grid: np.ndarray,
    tau_repr: np.ndarray,
    T: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Build eta/tau rectangle sequences from parsed QCTSP sample."""

    tau_values = _tau_indices_to_values(sample=sample, tau_repr=tau_repr)
    n_steps = int(tau_values.size)

    if len(sample.x_indices) >= n_steps and n_steps > 0:
        start_states = np.asarray((sample.x0, *sample.x_indices[:-1]), dtype=np.int64)
    else:
        start_states = np.full(n_steps, int(sample.x0), dtype=np.int64)

    if n_steps > 0:
        if np.any(start_states < 0) or np.any(start_states >= eta_grid.size):
            raise ValueError("sample x state index out of range for eta grid.")
        eta_values = eta_grid[start_states]
        tail_state_idx = int(sample.x_indices[-1]) if len(sample.x_indices) > 0 else int(sample.x0)
        if tail_state_idx < 0 or tail_state_idx >= eta_grid.size:
            raise ValueError("sample tail x state index out of range for eta grid.")
        tail_eta = float(eta_grid[tail_state_idx])
    else:
        eta_values = np.asarray([], dtype=np.float64)
        tail_eta = float(eta_grid[int(sample.x0)])

    return _clip_eta_tau_to_horizon(
        eta_seq=eta_values,
        tau_seq=tau_values,
        T=T,
        eta_tail=tail_eta,
    )


def _tau_indices_to_times(
    sample: ParsedQCTSPSample,
    tau_repr: np.ndarray,
    T: float,
) -> np.ndarray:
    tau_values = _tau_indices_to_values(sample=sample, tau_repr=tau_repr)
    return _tau_values_to_times(tau_values=tau_values, T=T)


def _recommend_n_steps(mean_classical_nt: float, user_n_steps: int, auto_n_steps: bool) -> tuple[int, int]:
    recommended = max(1, int(ceil(1.5 * mean_classical_nt)))
    if not auto_n_steps:
        return user_n_steps, recommended
    return max(user_n_steps, recommended), recommended


def _sample_qctsp_paths(
    config: ComparisonConfig,
    p_tau_given_x: np.ndarray,
    transition_table: np.ndarray,
    n_steps: int,
) -> tuple[list[ParsedQCTSPSample], str]:
    if config.qctsp_backend == "aer":
        if n_steps > 6:
            raise ValueError("Aer circuit mode supports n_steps<=6 for this prototype.")
        if not _is_aer_runtime_safe():
            raise RuntimeError("Aer backend requested but runtime is not safe for this environment.")
        use_aer = True
    elif config.qctsp_backend == "auto":
        if n_steps > 6:
            LOGGER.warning("n_steps=%d exceeds circuit prototype limit; using classical QCTSP sampler.", n_steps)
            use_aer = False
        elif not _is_aer_runtime_safe():
            LOGGER.warning("Aer runtime unavailable; falling back to classical QCTSP sampler.")
            use_aer = False
        else:
            use_aer = True
    else:
        use_aer = False

    if use_aer:
        circuit, layout = build_qctsp_unroll_circuit(
            p_tau_given_x=p_tau_given_x,
            transition_table=transition_table,
            n_steps=n_steps,
            x0=config.x0,
            measure_x_path=True,
        )
        backend = _get_aer_backend(seed=config.seed)
        compiled = transpile(circuit, backend=backend, seed_transpiler=config.seed, optimization_level=0)
        counts = dict(
            backend.run(compiled, shots=config.shots, seed_simulator=config.seed).result().get_counts(compiled)
        )
        return parse_qctsp_counts(counts=counts, layout=layout), "aer"

    samples = sample_qctsp_classically(
        p_tau_given_x=p_tau_given_x,
        transition_table=transition_table,
        n_steps=n_steps,
        x0=config.x0,
        shots=config.shots,
        seed=config.seed,
        measure_x_path=True,
    )
    return samples, "classical"


def compare_samples(
    classical_samples: Sequence[float], qctsp_samples: Sequence[float]
) -> ComparisonArtifacts:
    """Build typed artifact for paired sequence-level comparison."""

    summary = compute_validation_summary(reference=classical_samples, candidate=qctsp_samples)
    return ComparisonArtifacts(
        classical_samples=classical_samples,
        qctsp_samples=qctsp_samples,
        metrics=summary,
    )


def build_comparison_report(config: ComparisonConfig) -> dict[str, Any]:
    """Run end-to-end comparison and return JSON-serializable report dict."""

    _validate_config(config)

    eta_grid, tau_edges, tau_repr, transition_table, lambda_ref_value = _build_qctsp_discretization(
        config=config
    )
    p_tau_given_x = build_p_tau_given_x(
        eta_grid=eta_grid,
        tau_edges=tau_edges,
        mu=config.mu,
        alpha=config.alpha,
        beta=config.beta,
    )

    classical_metrics: list[PathMetrics] = []
    for path_idx in range(config.classical_paths):
        times = simulate_hawkes_exp_ogata(
            T=config.T,
            mu=config.mu,
            alpha=config.alpha,
            beta=config.beta,
            seed=config.seed + path_idx,
        )
        eta_rect, tau_rect = _classical_rect_sequences(times=times, T=config.T, beta=config.beta)
        classical_metrics.append(
            compute_path_metrics(
                times=times,
                T=config.T,
                mu=config.mu,
                alpha=config.alpha,
                beta=config.beta,
                eta_seq=eta_rect,
                tau_seq=tau_rect,
            )
        )

    mean_classical_nt = float(np.mean([metric.N_T for metric in classical_metrics]))
    effective_n_steps, recommended_n_steps = _recommend_n_steps(
        mean_classical_nt=mean_classical_nt,
        user_n_steps=config.n_steps,
        auto_n_steps=config.auto_n_steps,
    )

    qctsp_samples, backend_used = _sample_qctsp_paths(
        config=config,
        p_tau_given_x=p_tau_given_x,
        transition_table=transition_table,
        n_steps=effective_n_steps,
    )
    qctsp_metrics: list[PathMetrics] = []
    for sample in qctsp_samples:
        eta_rect, tau_rect = _qctsp_rect_sequences(
            sample=sample,
            eta_grid=eta_grid,
            tau_repr=tau_repr,
            T=config.T,
        )
        qctsp_metrics.append(
            compute_path_metrics(
                times=_tau_indices_to_times(sample=sample, tau_repr=tau_repr, T=config.T),
                T=config.T,
                mu=config.mu,
                alpha=config.alpha,
                beta=config.beta,
                eta_seq=eta_rect,
                tau_seq=tau_rect,
            )
        )

    config_payload = asdict(config)
    config_payload["lambda_ref_value"] = lambda_ref_value
    config_payload["mean_classical_N_T"] = mean_classical_nt
    config_payload["recommended_n_steps"] = recommended_n_steps
    config_payload["effective_n_steps"] = effective_n_steps

    qctsp_summary = summarize_path_metrics(path_metrics=qctsp_metrics, count_key="shots")
    qctsp_summary["n_steps_effective"] = effective_n_steps
    qctsp_summary["backend"] = backend_used

    report: dict[str, Any] = {
        "config": config_payload,
        "classical": summarize_path_metrics(path_metrics=classical_metrics, count_key="N_paths"),
        "qctsp": qctsp_summary,
        "notes": [
            (
                "QCTSP event times are reconstructed from tau indices via "
                f"tau_repr_mode={config.tau_repr_mode}."
            ),
            (
                "Classical rectangle integrals use eta just-after-event on each next inter-arrival, "
                "with an initial eta=0 segment on [0,t1)."
            ),
            (
                "Tau edges are built with "
                f"tau_edges_mode={config.tau_edges_mode} and lambda_ref_mode={config.lambda_ref_mode}."
            ),
            f"Resolved lambda_ref value: {lambda_ref_value:.6f}.",
            "QCTSP N(T) is computed as count(cumsum(tau_values) <= T).",
            "Events with cumulative time > T are truncated before per-path metrics.",
            "Inter-arrival mean/var and KS p-value exclude paths with insufficient events.",
            f"QCTSP sampling backend: {backend_used}.",
        ],
    }
    return report


def build_qctsp_tau_debug(
    config: ComparisonConfig,
    n_steps: int,
    max_shots: int = 20,
) -> dict[str, Any]:
    """Build per-shot tau debugging artifact for the first max_shots samples."""

    _validate_config(config)
    if max_shots <= 0:
        raise ValueError("max_shots must be positive.")
    if n_steps <= 0:
        raise ValueError("n_steps must be positive.")

    eta_grid, tau_edges, tau_repr, transition_table, lambda_ref_value = _build_qctsp_discretization(
        config=config
    )
    p_tau_given_x = build_p_tau_given_x(
        eta_grid=eta_grid,
        tau_edges=tau_edges,
        mu=config.mu,
        alpha=config.alpha,
        beta=config.beta,
    )
    samples, backend_used = _sample_qctsp_paths(
        config=config,
        p_tau_given_x=p_tau_given_x,
        transition_table=transition_table,
        n_steps=n_steps,
    )

    n_t_all: list[int] = []
    first_shots: list[dict[str, Any]] = []
    for shot_idx, sample in enumerate(samples):
        tau_values = _tau_indices_to_values(sample=sample, tau_repr=tau_repr)
        cumulative = np.cumsum(tau_values, dtype=np.float64)
        N_T = int(np.count_nonzero(cumulative <= config.T))
        n_t_all.append(N_T)
        if shot_idx < max_shots:
            first_shots.append(
                {
                    "shot_index": shot_idx,
                    "tau_idx": [int(v) for v in sample.tau_indices],
                    "tau_val": [float(v) for v in tau_values.tolist()],
                    "cum_times": [float(v) for v in cumulative.tolist()],
                    "N_T": N_T,
                }
            )

    unique_nt = sorted({int(v) for v in n_t_all})
    return {
        "config": {
            "T": config.T,
            "shots": config.shots,
            "max_shots": max_shots,
            "n_steps_effective": n_steps,
            "backend": backend_used,
            "tau_repr_mode": config.tau_repr_mode,
            "tau_edges_mode": config.tau_edges_mode,
            "lambda_ref_mode": config.lambda_ref_mode,
            "lambda_ref_value": lambda_ref_value,
        },
        "N_T_summary": {
            "min": int(min(n_t_all)) if n_t_all else None,
            "max": int(max(n_t_all)) if n_t_all else None,
            "n_unique": int(len(unique_nt)),
            "unique_values": unique_nt,
        },
        "shots": first_shots,
    }


def save_json_artifact(payload: dict[str, Any], output_path: Path) -> Path:
    """Save JSON payload and return resolved path."""

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as fp:
        json.dump(payload, fp, indent=2, sort_keys=True)
    return output_path.resolve()


def save_comparison_report(report: dict[str, Any], output_path: Path) -> Path:
    """Save comparison report JSON and return the resolved path."""

    return save_json_artifact(payload=report, output_path=output_path)


def run_validation_comparison(
    config: ComparisonConfig,
    output_path: Path = Path("outputs/compare_report.json"),
) -> tuple[dict[str, Any], Path]:
    """Build and persist comparison report."""

    report = build_comparison_report(config=config)
    report_path = save_comparison_report(report=report, output_path=output_path)
    return report, report_path


__all__ = [
    "ComparisonArtifacts",
    "ComparisonConfig",
    "build_comparison_report",
    "build_qctsp_tau_debug",
    "compare_samples",
    "run_validation_comparison",
    "save_comparison_report",
    "save_json_artifact",
]
