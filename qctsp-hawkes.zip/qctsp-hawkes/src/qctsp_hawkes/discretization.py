"""Deterministic discretization and holding-time distribution helpers."""

from __future__ import annotations

from typing import Literal

import numpy as np
from numpy.typing import NDArray


FloatArray = NDArray[np.float64]
TauEdgesMode = Literal["linear", "exp-quantile"]


def _validate_int_at_least(name: str, value: int, minimum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise ValueError(f"{name} must be an integer.")
    if int(value) < minimum:
        raise ValueError(f"{name} must be >= {minimum}.")
    return int(value)


def _validate_positive_float(name: str, value: float) -> float:
    if not np.isfinite(value) or value <= 0.0:
        raise ValueError(f"{name} must be a finite positive float.")
    return float(value)


def _validate_tau_edges_array(edges: np.ndarray) -> FloatArray:
    arr = np.asarray(edges, dtype=np.float64)
    if arr.ndim != 1:
        raise ValueError("tau_edges must be a 1D array.")
    if arr.size < 3:
        raise ValueError("tau_edges must have length >= 3 (R+1 with R>=2).")
    finite_part = arr[:-1] if np.isinf(arr[-1]) else arr
    if not np.all(np.isfinite(finite_part)):
        raise ValueError("tau_edges finite part must contain only finite values.")
    if np.any(np.diff(finite_part) <= 0.0):
        raise ValueError("tau_edges finite part must be strictly increasing.")
    if arr[0] < 0.0:
        raise ValueError("tau_edges must start at a non-negative value.")
    return arr


def _validate_eta_grid(eta_grid: np.ndarray) -> FloatArray:
    eta = np.asarray(eta_grid, dtype=np.float64)
    if eta.ndim != 1:
        raise ValueError("eta_grid must be a 1D array.")
    if eta.size < 2:
        raise ValueError("eta_grid must contain at least 2 bins.")
    if not np.all(np.isfinite(eta)):
        raise ValueError("eta_grid must contain finite values.")
    if np.any(eta < 0.0):
        raise ValueError("eta_grid must be non-negative.")
    if np.any(np.diff(eta) <= 0.0):
        raise ValueError("eta_grid must be strictly increasing.")
    return eta


def _validate_mu_alpha_beta(mu: float, alpha: float, beta: float) -> tuple[float, float, float]:
    if not np.isfinite(mu) or mu <= 0.0:
        raise ValueError("mu must be a finite positive float.")
    if not np.isfinite(alpha) or alpha < 0.0:
        raise ValueError("alpha must be a finite non-negative float.")
    if not np.isfinite(beta) or beta <= 0.0:
        raise ValueError("beta must be a finite positive float.")
    return float(mu), float(alpha), float(beta)


def build_eta_grid(S: int, eta_max: float) -> FloatArray:
    """Build S eta-bin centers uniformly on [0, eta_max]."""

    n_bins = _validate_int_at_least(name="S", value=S, minimum=2)
    max_eta = _validate_positive_float(name="eta_max", value=eta_max)
    return np.linspace(0.0, max_eta, n_bins, dtype=np.float64)


def build_tau_edges(
    R: int,
    tau_max: float,
    mode: TauEdgesMode = "linear",
    lambda_ref: float | None = None,
) -> FloatArray:
    """Build tau bin edges (length R+1) with a tail sentinel +inf.

    - mode="linear": finite edges are uniform on [0, tau_max].
    - mode="exp-quantile": finite edges are Exp(lambda_ref) quantiles
      on evenly spaced u in [0, u_max], where
      u_max = min(0.995, 1 - exp(-lambda_ref * tau_max)).

    For backward compatibility and probability-mass closure in downstream tables,
    this function always appends a tail-bin sentinel, so the last bin is [a, +inf).
    """

    n_bins = _validate_int_at_least(name="R", value=R, minimum=2)
    max_tau = _validate_positive_float(name="tau_max", value=tau_max)
    if mode not in {"linear", "exp-quantile"}:
        raise ValueError("mode must be 'linear' or 'exp-quantile'.")

    if mode == "linear":
        finite_edges = np.linspace(0.0, max_tau, n_bins, dtype=np.float64)
    else:
        if lambda_ref is None:
            raise ValueError("lambda_ref is required when mode='exp-quantile'.")
        rate = _validate_positive_float(name="lambda_ref", value=lambda_ref)
        u_cap = min(0.995, 1.0 - float(np.exp(-rate * max_tau)))
        u_max = max(u_cap, 1.0e-6)
        u = np.linspace(0.0, u_max, n_bins, dtype=np.float64)
        finite_edges = -np.log1p(-u) / rate

    edges = np.empty(n_bins + 1, dtype=np.float64)
    edges[:-1] = finite_edges
    edges[-1] = np.inf
    return edges


def tau_bin_representative_midpoint(tau_edges: np.ndarray) -> FloatArray:
    """Representative tau per bin using midpoint/extrapolated-midpoint rule.

    For finite bins [e_r, e_{r+1}), use the arithmetic midpoint.
    For the tail bin [e_{R-1}, +inf), use e_{R-1} + 0.5 * delta_last,
    where delta_last is the width of the last finite bin.
    """

    edges = _validate_tau_edges_array(edges=tau_edges)
    n_bins = edges.size - 1

    mid = np.empty(n_bins, dtype=np.float64)
    if np.isinf(edges[-1]):
        mid[:-1] = 0.5 * (edges[:-2] + edges[1:-1])
        delta_last = edges[-2] - edges[-3]
        mid[-1] = edges[-2] + 0.5 * delta_last
    else:
        mid[:] = 0.5 * (edges[:-1] + edges[1:])
    return mid


def tau_bin_representative_condexp(tau_edges: np.ndarray, rate: float) -> FloatArray:
    """Representative tau per bin as Exp(rate) conditional expectation.

    Finite bin [a, b): E[tau | a <= tau < b]
      = a + 1/rate - (b-a) / (exp(rate*(b-a)) - 1)
    Tail bin [a, +inf): E[tau | tau >= a] = a + 1/rate.
    """

    edges = _validate_tau_edges_array(edges=tau_edges)
    lam = _validate_positive_float(name="rate", value=rate)
    n_bins = tau_edges.size - 1

    repr_values = np.empty(n_bins, dtype=np.float64)
    for idx in range(n_bins):
        a = float(edges[idx])
        b = float(edges[idx + 1])
        if np.isinf(b):
            repr_values[idx] = a + (1.0 / lam)
        else:
            delta = b - a
            repr_values[idx] = a + (1.0 / lam) - (delta / np.expm1(lam * delta))
            repr_values[idx] = min(max(repr_values[idx], a), b)
    return repr_values


def build_tau_midpoints(edges: np.ndarray) -> FloatArray:
    """Backward-compatible alias for midpoint tau representatives."""

    return tau_bin_representative_midpoint(tau_edges=edges)


def _survival_function(u: np.ndarray, eta: np.ndarray, mu: float, alpha: float, beta: float) -> np.ndarray:
    """Compute survival S(u|eta) for the Hawkes holding time.

    S(u|eta) = exp(-mu*u - (alpha*eta/beta) * (1 - exp(-beta*u))).
    """

    term = -np.expm1(-beta * u)
    exponent = -(mu * u) - (alpha * eta / beta) * term
    return np.exp(exponent)


def build_p_tau_given_x(
    eta_grid: np.ndarray,
    tau_edges: np.ndarray,
    mu: float,
    alpha: float,
    beta: float,
) -> FloatArray:
    """Build p_tau_given_x[S, R] from Hawkes survival function with tail bin.

    For bins [e_r, e_{r+1}),
      P_r = S(e_r | eta) - S(e_{r+1} | eta),
    and the tail bin [e_{R-1}, +inf) uses P_{R-1} = S(e_{R-1} | eta).
    """

    eta = _validate_eta_grid(eta_grid=eta_grid)
    edges = _validate_tau_edges_array(edges=tau_edges)
    baseline, excitation, decay = _validate_mu_alpha_beta(mu=mu, alpha=alpha, beta=beta)

    if not np.isinf(edges[-1]):
        raise ValueError("tau_edges must end with +inf sentinel.")

    n_states = eta.size
    n_tau_bins = edges.size - 1

    finite_edges = edges[:-1]
    u = finite_edges[None, :]
    eta_col = eta[:, None]

    survival = _survival_function(u=u, eta=eta_col, mu=baseline, alpha=excitation, beta=decay)
    probs = np.empty((n_states, n_tau_bins), dtype=np.float64)

    if n_tau_bins > 1:
        probs[:, :-1] = survival[:, :-1] - survival[:, 1:]
    probs[:, -1] = survival[:, -1]

    np.maximum(probs, 0.0, out=probs)
    row_sums = probs.sum(axis=1, keepdims=True)
    if np.any(row_sums <= 0.0):
        raise ValueError("each row of probabilities must have positive sum.")
    probs /= row_sums
    return probs


__all__ = [
    "build_eta_grid",
    "build_p_tau_given_x",
    "build_tau_edges",
    "build_tau_midpoints",
    "tau_bin_representative_condexp",
    "tau_bin_representative_midpoint",
]
