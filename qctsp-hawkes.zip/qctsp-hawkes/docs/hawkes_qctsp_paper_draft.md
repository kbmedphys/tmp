# QCTSP-Hawkes 論文ドラフト（本文下書き）

## Abstract
本稿では、Quantum Encoding and Analysis on CTSP で提案されたQCTSP枠組みを、履歴依存の自己励起過程であるHawkes過程に拡張する。Hawkesの非マルコフ性は強度状態ηを導入することで拡張状態のマルコフ性に還元でき、保持時間表現に基づいて量子状態準備と遷移更新を構成できる。本稿では、保持時間分布の離散化と条件付き振幅準備、遷移オラクルの設計を示し、離散化誤差・回路近似誤差・サンプリング誤差を分解して評価する。さらに合成データによる古典Ogata法との比較実験を行い、N(T)やI_eta, I_lambdaなど主要指標においてQCTSP拡張の整合性を検証する。

## 1. Introduction / Motivation
連続時間確率過程（CTSP）は金融、保険、神経科学など幅広い領域で重要であるが、履歴依存性や不連続ジャンプを持つ場合、古典シミュレーションは高コストになる。QCTSPはCTSPを量子状態として効率的にエンコードし、期待値計算を高速化する枠組みとして提案された。しかし、原論文では履歴依存性が強い自己励起過程への適用が明確に整理されていない。本稿は、Hawkes過程に対してQCTSPを拡張することで、履歴依存を保持時間表現に統合し、量子状態準備と情報抽出を具体化することを目的とする。

### 1.1 Notation（記号）
- T: 観測区間の上限。
- μ, α, β: Hawkesのパラメータ（基底強度、励起強度、減衰率）。
- η: 強度状態（履歴を集約する内部状態）。
- τ: 連続時間上の保持時間。
- S, R: ηとτのビン数。
- e_r: τビンの境界（r=0..R）。

### 1.2 Contributions（本稿の貢献）
- QCTSPの保持時間表現をHawkes過程に拡張する具体手順を提示。
- 条件付き生存関数に基づく状態準備と遷移オラクルの設計を示す。
- 離散化誤差と回路誤差の分解を行い、実験で妥当性を検証する。

### 1.3 Related Work（関連研究）
CTSP向けの量子エンコード枠組みとしてQCTSPが提案されている[1]。自己励起型の点過程であるHawkes過程は金融・地震・神経科学などで広く用いられ、指数核モデルの基礎理論と推定手法が確立している[2]。古典的なシミュレーション手法としてはOgata法が広く用いられる[3]。一方、期待値推定に対して量子振幅推定(QAE)や量子モンテカルロ(QMC)が提案されており、本稿はそれらの適用可能性を将来課題として位置付ける[4,5]。

## 2. Hawkes in QCTSP (Holding Time Formulation)
単変量指数核Hawkes過程の強度関数は

λ(t) = μ + Σ_{t_i < t} α exp(-β(t - t_i))

で与えられる。履歴依存性は強度状態

η_j = Σ_{t_i ≤ t_j} exp(-β(t_j - t_i))

によって要約でき、保持時間τ_{j+1} = t_{j+1} - t_jに対して

η_{j+1} = η_j exp(-β τ_{j+1}) + 1

が成り立つ。これにより、(η_j, τ_{j+1})の列として過程を表現できる。条件付き生存関数は

S(u|η) = exp(- μ u - (α η / β)(1 - exp(-β u)))

となる。安定条件α/β < 1を仮定し、定常性に基づく解析を可能にする。

本節では保持時間表現の概念図をFigure 1に示す。原論文のholding time representationと整合的であり、履歴依存性はηに集約される点が重要である。


## 3. Method

本節では、Hawkes過程をQCTSPに落とし込むための具体的な処理手順を示す。入力・出力、離散化、状態準備、遷移オラクル、測定と推定量の計算までを一貫した流れとして整理する。

### 3.1 Inputs/Outputs
**入力**
- Hawkesパラメータ: (μ, α, β)
- 離散化設定: ηビン数S、τビン数R、τ境界{e_r}
- 観測区間: T
- 量子回路設定: n_steps, shots

**出力**
- QCTSPサンプル（η, τ系列）
- 指標: N(T), I_eta, I_lambda, KS p-value

**初学者向け補足（直感）**
- **μ**は「基礎発生率」で、自己励起がなくても起きるイベントの頻度を表す。  
- **α**は「自己励起の強さ」、**β**は「自己励起の減衰の速さ」。  
- **N(T)**は「T秒間で何回イベントが起きたか」、**I_lambda**は「全体のイベント強度の合計」に近い量と解釈できる。

### 3.2 Discretization
ηは[0, η_max]をS分割し、τは[0, τ_max]をR分割した境界{e_r}で表す。条件付き生存関数

S(u|η) = exp(-μu - (αη/β)(1 - exp(-βu)))

から確率質量を

P(τ ∈ [e_r, e_{r+1}) | η) = S(e_r|η) - S(e_{r+1}|η)

で定義する。最後のビンはテール確率としてS(e_{R-1}|η)を割り当てる。代表値はmidpointまたはcondexpを用いる。

### 3.3 Conditional State Preparation
ηレジスタの状態に応じてτレジスタへ条件付き振幅準備を行う。実装はlookup型の制御状態準備であり、回路規模はO(S * 2^{n_tau})程度を要する。

**Algorithm 1: Conditional State Preparation**
```text
Input: eta_grid, tau_edges, mu, alpha, beta
Output: p_tau_given_x (S x R)

for each eta in eta_grid:
    for each tau bin [e_r, e_{r+1}):
        p_r = S(e_r|eta) - S(e_{r+1}|eta)
    normalize row probabilities
Prepare tau register conditioned on |eta> using amplitudes sqrt(p_r)
```

### 3.4 Transition Oracle
状態更新は

η_next = η * exp(-β τ) + 1

に従う。η_nextを最近傍ビンへ量子化してη'を決定し、(η, τ)→η'の遷移オラクルを多制御Xで実装する。

**Algorithm 2: Transition Update**
```text
Input: eta_grid, tau_repr, beta
Output: transition_table (S x R)

for each eta_index:
    for each tau_index:
        eta_next = eta_grid[eta_index] * exp(-beta * tau_repr[tau_index]) + 1
        eta_prime = nearest_bin(eta_next, eta_grid)
        transition_table[eta_index, tau_index] = eta_prime
Apply multi-controlled X gates to map |eta, tau, 0> -> |eta, tau, eta'>
```

### 3.5 Unrolling & Measurement
n_steps回の更新を展開し、τレジスタを測定・リセットして再利用する。x0, τ_1..τ_n, x_1..x_nの測定レイアウトを設計し、サンプル列を復元する。

**初学者向け補足**
- `n_steps` は「何回の保持時間(τ)を生成するか」に相当する。  
- 小さすぎると N(T) が不足し、古典と比較したときに不一致が大きくなる。  

### 3.6 Estimators
- N(T): 累積和cumsum(τ_k)がT以下の個数
- I_eta: 矩形近似でΣ η_k * τ_k
- I_lambda: Σ (μ + α η_k) * τ_k
- KS p-value: time-rescalingのz系列に対するExp(1)検定

**初学者向け補足（見方）**
- **N(T)**が大きいほど、イベントが頻発している。  
- **I_eta**は「自己励起の総量」に相当し、自己励起の影響が強いほど大きくなる。  
- **I_lambda**は「期待される総イベント数」に近い値で、古典とQCTSPの一致性を見る際の代表指標になる。  

## 4. Quantum Encoding and Data Preparation
保持時間表現に基づき、ηとτを量子レジスタに符号化する。τはビン分割 {e_r} を導入し、確率質量

P(τ ∈ [e_r, e_{r+1}) | η) = S(e_r|η) - S(e_{r+1}|η)

で定義する。代表値はmidpointまたはcondexpを用いて離散化誤差を制御する。量子状態準備はηレジスタを条件とした振幅準備で実装し、必要量子ビット数はO(log S + log R)で与えられる。制御ゲート数や回路深さはSとRに比例して増加するため、精度と回路資源のトレードオフが生じる。

状態準備のフローはFigure 2に示し、τ離散化と代表値の概念図はFigure 3に示す。回路規模の概算はTable 2で整理する。

## 5. Transition Oracle and Information Extraction
遷移写像(η, τ)→η'は

η' = η exp(-β τ) + 1

で与えられる。η'は離散ビンに最近傍量子化され、遷移オラクルとして多制御ゲートで実装できる。情報抽出はN(T), I_eta=∫η dt, I_lambda=∫λ dtなどの期待値を対象とする。本稿では量子優位性の主張ではなく、古典シミュレーションとの整合性検証に重点を置く。QAE/QMCの適用は将来の発展的議論として位置付ける。

遷移オラクルの回路ブロック図はFigure 4に示す。

## 6. Complexity and Error Analysis
誤差は以下の要素に分解できる。

- 離散化誤差: η, τのビン幅による近似。
- 代表値誤差: midpoint/condexpによる近似差。
- 回路近似誤差: 状態準備および遷移回路の近似精度。
- サンプリング誤差: shots数依存。

理論的にはビン幅に比例した誤差上界が得られる一方、実験ではアブレーションにより実効誤差を評価する。

本稿では誤差分解をTable 3に整理し、S/Rやτ_repr/τ_edgesの変更による誤差推移をFigure 7で示す。

## 7. Experiments (Synthetic and Real-Data)
合成データとしてOgata法で古典Hawkesを生成し、QCTSPによるサンプルと比較する。主要指標はN(T), I_eta, I_lambda, KS検定p値、inter-arrivalの平均・分散である。アブレーションとしてS/R/τ_repr/τ_edges/n_stepsを変化させ、比較結果の安定性を検証する。すべての設定はJSONに保存し、再現性を確保する。

ベースラインの設定はTable 1に整理し、比較結果の代表例はFigure 5とFigure 6に示す。


### 7.1 Baseline Results
ベースライン(A0)では自動n_steps選択により n_steps_effective=19 が採用された。古典とQCTSPの主要指標は以下の通りである。

- N(T): classical mean=12.600, var=27.370 / qctsp mean=11.380, var=16.026 (Δ=-1.220)
- I_lambda: classical mean=17.730, var=8.473 / qctsp mean=16.617, var=3.064 (Δ=-1.113)
- I_eta: classical mean=16.217, var=23.535 / qctsp mean=14.362, var=8.512 (Δ=-1.855)
- KS p-value (mean): classical=0.517, qctsp=0.459

![Figure 5: N(T)ヒストグラム](../outputs/figures/figure_05_nt_histogram.png)
![Figure 6: I_eta/I_lambda比較](../outputs/figures/figure_06_integrals_bar.png)

### 7.2 Ablation Summary
アブレーションではΔN(T)の範囲が -10.600 〜 0.820、ΔI_lambdaの範囲が -9.730 〜 0.929 となった。最小ΔN(T)は run A7 (n_steps small (auto off)) で観測され、最小ΔI_lambdaは run A1 (S sweep (coarse)) に対応する。粗いη離散化(Sが小さい場合)やn_stepsの不足はバイアス増大の要因であり、適切な分割とステップ数が重要である。

![Figure 7: アブレーション結果](../outputs/figures/figure_07_ablation.png)

### Table 4: アブレーション結果の要約

| run_id | purpose | ΔN(T) mean | ΔI_lambda mean | classical N(T) mean | qctsp N(T) mean |
| --- | --- | --- | --- | --- | --- |
| A0 | baseline | -1.220 | -1.113 | 12.600 | 11.380 |
| A1 | S sweep (coarse) | -4.750 | -9.730 | 12.600 | 7.850 |
| A2 | S sweep (fine) | -1.300 | -0.828 | 12.600 | 11.300 |
| A3 | R sweep (coarse) | -2.830 | -3.701 | 12.600 | 9.770 |
| A4 | R sweep (fine) | -0.395 | 0.929 | 12.600 | 12.205 |
| A5 | tau_repr condexp | -1.335 | -1.122 | 12.600 | 11.265 |
| A6 | tau_edges exp-quantile | 0.820 | 0.901 | 12.600 | 13.420 |
| A7 | n_steps small (auto off) | -10.600 | -1.738 | 12.600 | 2.000 |
| A8 | n_steps large (auto off) | -8.610 | -0.853 | 12.600 | 3.990 |
| B1 | parameter set: low excitation | 0.375 | 0.138 | 4.570 | 4.945 |
| B2 | parameter set: higher excitation | -0.785 | 0.441 | 14.935 | 14.150 |



### 7.3 Real-Data Study (Yahoo Finance OHLCV)
実データ適用としてYahoo FinanceのOHLCVバーをyfinance経由で取得し、価格変化イベントの到着時刻を用いる。yfinanceの取得条件（期間・間隔）には制約があるため、取得時点のパラメータとメタ情報を記録する。[6,7]

**手順**
1. yfinanceでBTC-USDのOHLCVを取得する（例: 30日・5分足）。[6,7]
2. タイムスタンプを秒単位に変換し、価格変化が発生したバーのみをイベント時刻として抽出する（または対数リターン閾値でフィルタ）。
3. MLEで(μ, α, β)を推定し、α/β < 1を満たさない場合は正則化する。
4. 推定パラメータで古典Ogataシミュレーションを行い、QCTSPと比較する。
5. N(T), I_eta, I_lambda, KS p-valueで整合性を評価する。

結果は`outputs/real_data/`に保存し、要約をTable 5に整理する。

**初学者向け補足（OHLCV→イベント化）**
- OHLCVは「バー（一定時間の集計）」データであり、本来のイベント（約定）とは異なる。  
- ここでは**バーをイベントの代理**とみなし、価格変化が起きたバーをイベントとして抽出する。  
- しきい値を上げると「大きな変動のみ」をイベントとするため、イベント数は減少する。  
- この近似は簡便だが、**イベント定義に依存した結果**になる点に注意する。  

**結果の概要（例）**
- 価格変化イベント（`event_mode=price_change`, threshold=0.0）では、  
  N(T)平均は古典 8530.465、QCTSP 7753.655、KS p-valueは古典 0.496、QCTSP 0.0。  
- 対数リターン閾値（`event_mode=log_return`, threshold=0.0015）では、  
  N(T)平均は古典 2025.535、QCTSP 1946.905、KS p-valueは古典 0.496、QCTSP 4.04e-08。  
  しきい値を上げることでイベント数が減少し、推定パラメータと指標のスケールが変化する。  

**しきい値スイープの傾向（初学者向け）**
- しきい値を 0.0015 → 0.003 → 0.005 と上げると、イベント数は 2157 → 825 → 278 に減少する。  
- 同時に N(T) の平均も小さくなり、強度推定(μ, α, β)のスケールが変化する。  
- これは「イベントの定義が変わるとモデルも変わる」ことを示しており、比較では**同じ定義**を使う必要がある。  

**Figure 8-9: しきい値スイープの可視化**
![Figure 8](../outputs/figures/real_data_nt_mean_sweep.png)
![Figure 9](../outputs/figures/real_data_ilambda_mean_sweep.png)

**QCTSP側の感度分析（初学者向け）**
- `n_steps` を小さくすると、**サンプルできる保持時間の数が不足**し、N(T)やKSが悪化する。  
- `tau_repr` と `tau_edges` はτの離散化の仕方で、分布近似の誤差に影響する。  
- 実データ（log_return, threshold=0.0015）を基準に、これらの設定を変えた結果をTable 6に整理した。  

**Figure 10-11: QCTSP側の感度可視化**
![Figure 10](../outputs/figures/real_data_nsteps_sensitivity.png)
![Figure 11](../outputs/figures/real_data_tau_sensitivity.png)

**まとめ（初学者向け）**
実データでは、**イベントの定義**（価格変化のしきい値）と**QCTSPの設定**（n_stepsやτ離散化）が結果に強く影響する。  
そのため、比較では「同じイベント定義」「十分なn_steps」を揃えることが重要であり、  
Table 5（しきい値スイープ）とTable 6（QCTSP感度）を併せて解釈するのが有効である。

**KS p-valueの読み方（初学者向け）**
- KSは「理論分布（ここではExp(1))と一致しているか」を見る検定。  
- p-valueが**大きいほど**「一致している可能性が高い」。  
- ただし、**p-valueが小さい＝モデルが完全にダメ**ではなく、  
  イベント定義や離散化（τビン）などの近似が影響している可能性もある。  
  そのため、KSだけでなく N(T) や I_lambda と合わせて判断する。  

## 8. Discussion & Limitations
本稿は単変量指数核に限定している。多変量Hawkesや非指数核は状態表現と回路構成が拡張されるため、今後の課題である。実データ評価はYahoo FinanceのOHLCVバー（yfinance経由）に限定しており、他市場や期間への一般化、データ取得条件の違いによる影響は今後の検討課題である。

## Figure Captions（案）
- Figure 1: Hawkes過程の保持時間表現。イベント時刻と保持時間τ、および強度状態ηの概念図。
- Figure 2: QCTSP拡張フロー。離散化、条件付き状態準備、遷移オラクル、情報抽出の流れ。
- Figure 3: τ離散化と代表値。midpointとcondexpの代表値の違いを示す。
- Figure 4: 回路ブロック図。状態準備と遷移更新、測定の関係。
- Figure 5: N(T)ヒストグラム。古典Ogata法とQCTSPの分布比較。
- Figure 6: I_eta/I_lambda比較。平均値の棒グラフによる比較。
- Figure 7: アブレーション結果。S/R/τ_repr/τ_edges変更に対する差分比較。
- Figure 8: 実データしきい値スイープにおけるN(T)平均の比較。
- Figure 9: 実データしきい値スイープにおけるI_lambda平均の比較。
- Figure 10: n_steps変更時のQCTSP感度（N(T)平均）。
- Figure 11: tau_repr/tau_edges変更時のQCTSP感度（N(T)平均）。

## Table Captions（案）
- Table 1: ベースライン実験設定。
- Table 2: 回路規模の概算（ビット数、ゲート数、深さのオーダー）。
- Table 3: 誤差分解（離散化、代表値、回路、サンプリング）。
- Table 4: アブレーション結果の要約。
- Table 5: 実データ結果の要約。
- Table 6: 実データにおけるQCTSP感度分析（n_steps / τ離散化）。

## References
[1] Xi-Ning Zhuang, Zhao-Yun Chen, Cheng Xue, Yu-Chun Wu, Guo-Ping Guo. "Quantum Encoding and Analysis on Continuous Time Stochastic Process with Financial Applications." Quantum 7, 1127 (2023). doi:10.22331/q-2023-10-03-1127.
[2] A. G. Hawkes. "Spectra of some self-exciting and mutually exciting point processes." Biometrika 58(1), 83-90 (1971). doi:10.1093/biomet/58.1.83.
[3] Y. Ogata. "On Lewis' simulation method for point processes." IEEE Transactions on Information Theory 27(1), 23-31 (1981).
[4] G. Brassard, P. Hoyer, M. Mosca, A. Tapp. "Quantum amplitude amplification and estimation." Contemporary Mathematics 305, 53-74 (2002). doi:10.1090/conm/305/05215.
[5] A. Montanaro. "Quantum speedup of Monte Carlo methods." Proceedings of the Royal Society A 471, 20150301 (2015). doi:10.1098/rspa.2015.0301.

[6] Ran Aroussi. "yfinance: Yahoo! Finance market data downloader." (Python package).
[7] Yahoo Finance. "Historical market data" (data access page).
