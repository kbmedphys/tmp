# QCTSPのHawkes拡張論文: 論点整理と分析計画

## 目的と位置付け
- 原論文（Quantum Encoding and Analysis on CTSP）のデータ準備と情報抽出の枠組みを、履歴依存のHawkes過程へ拡張する。
- Hawkesの非マルコフ性を強度状態ηによって拡張状態のマルコフ性へ置換し、保持時間表現のQCTSPに落とし込む。
- 理論導出と合成データ実験を両輪とし、QCTSP拡張の妥当性と限界を学術的に示す。

## 想定読者
- 量子アルゴリズム研究者（QCTSP/量子状態準備/量子モンテカルロ）
- 連続時間確率過程・金融工学の研究者
- Hawkes過程の応用研究者

## 主要貢献（想定）
- 履歴依存過程をQCTSP枠組みに組み込む一般的方針の提示。
- Hawkes過程の保持時間表現を用いた量子状態準備・遷移更新の明示的構成。
- 離散化誤差と量子回路誤差を分離した評価枠組みの提示。
- 古典Ogata法との比較により、QCTSPの整合性を定量的に検証。

## 数学的定式化（最低限の明示事項）
- 単変量指数核Hawkesの定義。
- 強度関数: λ(t)=μ+Σ_{t_i<t} α exp(-β(t-t_i))。
- 状態定義: η_j=Σ_{t_i≤t_j} exp(-β(t_j-t_i))。
- 状態更新: η_{j+1}=η_j exp(-β τ_{j+1}) + 1。
- 条件付き生存関数: S(u|η)=exp(-μu - (αη/β)(1-exp(-βu)))。
- 安定性条件: α/β < 1（必要なら定常性の仮定を明記）。

## QCTSP表現（保持時間表現）
- 状態は(η_j, τ_{j+1})の列として定義する。
- QCTSPの確率構造をp[η_j, τ_j | 過去]で整理し、Hawkesの履歴依存がη_jに集約されることを示す。
- 原論文のholding time / increment表現との対応を明示する。

## データ準備（量子状態準備）
- τをビン分割して確率質量P(τ∈[e_r,e_{r+1})|η)を定義。
- 代表値はmidpoint/condexpを比較対象とする。
- 条件付き振幅準備（controlled state-prep）でp(τ|η)を準備。
- 必要量子ビット数: O(log S + log R)。
- 回路深さや制御ゲート数のS,R依存を評価。

## 遷移オラクル（状態更新回路）
- 遷移規則: (η, τ)→η' を最近傍ビンに量子化。
- 量子化誤差（bin幅の関数）を明示。
- 回路規模と精度のトレードオフを整理。

## 情報抽出（Information extraction）
- 期待値指標: N(T), I_eta=∫η dt, I_lambda=∫λ dt。
- 量子優位性の主張は本論では必須とせず、整合性評価を主軸とする。
- QAE/QMCの適用可能性は議論として位置付ける。

## 誤差・複雑性分析
- 離散化誤差: η, τのビン幅による近似誤差。
- 代表値誤差: midpoint/condexpの差分。
- 回路近似誤差: state-prep/遷移オラクルの近似精度。
- サンプリング誤差: shots依存。
- 上記を誤差分解として整理し、理論的見積もりと実験的検証を両方示す。

## 実験設計（合成データ）
- 古典: Ogata法でシミュレーション。
- QCTSP: 離散化+回路（または古典サンプラ）でサンプル生成。
- メトリクス: N(T), I_eta, I_lambda, KS検定, inter-arrival平均/分散。
- アブレーション: S/R/τ_repr/τ_edges/n_steps の依存性を比較。
- 再現性: seed固定、設定はJSONに保存。
- 実験計画ファイル: `outputs/experiment_plan.json`, `outputs/experiment_plan.csv`。

## 比較の判定基準
- N(T)の分散が0でないこと（退化を除外）。
- 古典とQCTSPの平均・分散が同程度であること。
- τ_repr/τ_edges変更に対して結果が極端に不安定でないこと。

## 限界と今後課題
- 単変量・指数核に限定。
- 多変量Hawkesや非指数核は将来課題。
- 実データ評価は本論では行わず、議論として位置付け。

## 論文構成案
- Section 1: Introduction / Motivation
- Section 2: Hawkes in QCTSP (holding time formulation)
- Section 3: Quantum encoding and preparation
- Section 4: Information extraction and complexity
- Section 5: Experiments (synthetic)
- Section 6: Discussion & Limitations

## 図表構成案（ドラフト）
### 図
- Figure 1: Hawkes過程の保持時間表現（時系列上のηとτの対応図）
- Figure 2: QCTSP拡張の全体フロー（state preparation → transition → extraction）
- Figure 3: τ離散化と代表値（midpoint/condexp）の概念図
- Figure 4: 回路ブロック図（条件付き状態準備 + 遷移オラクル）
- Figure 5: N(T)ヒストグラム（古典 vs QCTSP）
- Figure 6: I_eta/I_lambdaの比較（棒グラフ）
- Figure 7: アブレーション結果（S/R/τ_repr/τ_edgesの依存性）

### 表
- Table 1: 実験パラメータ設定（ベースライン）
- Table 2: 回路規模の概算（qubits/gates/depthのS,R依存）
- Table 3: 誤差分解（離散化/代表値/回路/サンプリング）
- Table 4: アブレーション結果の要約（指標の平均・分散）

## 既存実装との対応（補足）
- QCTSPの実験基盤は`qctsp-hawkes`の比較パイプラインを利用可能。
- 主要比較指標は`outputs/compare_report.json`で確認可能。
