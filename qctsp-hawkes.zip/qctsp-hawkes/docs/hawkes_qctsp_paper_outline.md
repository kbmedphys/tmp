# QCTSP-Hawkes 論文アウトライン（ドラフト）

## Title（案）
- Quantum Encoding and Analysis of Hawkes Processes in the QCTSP Framework
- QCTSP Extension for Self-Exciting Hawkes Processes: Theory and Empirical Validation

## Abstract（要旨の骨子）
- CTSP向けQCTSP枠組みをHawkes過程に拡張することを提案。
- 強度状態ηによるマルコフ化と保持時間表現により、量子状態準備と遷移更新が可能であることを示す。
- 合成データで古典Ogata法と比較し、主要指標の整合性を定量評価。
- 離散化・回路・サンプリング誤差の分解を提示。

## 1. Introduction / Motivation
- CTSPの量子エンコードに関する原論文の背景整理。
- 履歴依存プロセス（Hawkes）への拡張の必要性。
- 本研究の貢献（理論拡張 + 実験的検証）。

### 1.3 Related Work（想定）
- QCTSP/CTSP量子エンコードの先行研究 [1]
- Hawkes過程の基礎理論と応用 [2]
- Ogata法など古典シミュレーション [3]
- QAE/QMCなど量子期待値推定 [4,5]

### References（想定）
- [1] Zhuang et al., Quantum (2023)
- [2] Hawkes, Biometrika (1971)
- [3] Ogata, IEEE Trans. Inf. Theory (1981)
- [4] Brassard et al., Contemp. Math. (2002)
- [5] Montanaro, Proc. R. Soc. A (2015)

## 2. Hawkes in QCTSP (Holding Time Formulation)
- 単変量指数核Hawkesの定義。
- 強度状態ηによるマルコフ化。
- 状態更新式と保持時間表現。
- 生存関数S(u|η)と離散化確率の定義。
- 安定条件（α/β < 1）と仮定。

## 3. Method
- 入出力の定義（パラメータ、ビン数、観測区間）。
- 離散化の定義（ηグリッド、τ境界、S(u|η)とP(τ|η)）。
- 条件付き状態準備（Algorithm 1）。
- 遷移オラクル（Algorithm 2）。
- Unrollingと測定レイアウト。
- 推定量（N(T), I_eta, I_lambda, KS）。

## 4. Quantum Encoding and Data Preparation (Overview)
- QCTSPのholding time表現と状態空間。
- 量子レジスタ構成（x, τ など）。
- 条件付き振幅準備の構成（p(τ|η)）。
- ビン幅と代表値（midpoint/condexp）の扱い。
- 必要量子ビット数と回路深さの評価（S, R依存）。

## 5. Transition Oracle and Information Extraction (Overview)
- 遷移写像(η, τ)→η'と量子化。
- 遷移オラクルの回路構成と正確性。
- 情報抽出指標（N(T), I_eta, I_lambda）。
- QAE/QMC適用可能性の議論（本論は整合性評価重視）。

## 6. Complexity and Error Analysis
- 離散化誤差（η/τビン幅）
- 代表値誤差（midpoint/condexp）
- 回路近似誤差（state-prep/遷移）
- サンプリング誤差（shots依存）
- 誤差分解の整理と見積もり方針

## 7. Experiments (Synthetic and Real-Data)
- 実験設計（合成データ・パラメータ設定）
- 古典OgataとQCTSPの比較
- メトリクス: N(T), I_eta, I_lambda, KS, inter-arrival stats
- アブレーション: S/R/τ_repr/τ_edges/n_steps
- 結果の要約と解釈

## 8. Discussion & Limitations
- 単変量・指数核に限定した理由
- 多変量/非指数核への拡張課題
- 実データ評価の必要性

## 付録（想定）
- 証明の詳細（生存関数導出、誤差上界）
- 回路構成の補足
- 追加実験

## 図表の紐付け（例）
- Figure 1: Holding time representation
- Figure 2: QCTSP拡張フロー
- Figure 3: τ離散化・代表値
- Figure 4: 回路ブロック図
- Figure 5: N(T)比較
- Figure 6: I_eta/I_lambda比較
- Figure 7: アブレーション結果
- Figure 8: 実データしきい値スイープ（N(T)平均）
- Figure 9: 実データしきい値スイープ（I_lambda平均）
- Figure 10: QCTSP感度（n_steps）
- Figure 11: QCTSP感度（tau_repr/tau_edges）
- Table 1: パラメータ設定
- Table 2: 回路規模
- Table 3: 誤差分解
- Table 4: アブレーション要約
- Table 5: 実データ結果（しきい値スイープ）
- Table 6: 実データのQCTSP感度分析
