"""Smoke tests for lookup-based QCTSP sampling circuits."""

from __future__ import annotations

import platform
from pathlib import Path

import numpy as np
from qiskit import transpile

from qctsp_hawkes.circuits.unroll import (
    build_qctsp_unroll_circuit,
    parse_qctsp_counts,
    sample_qctsp_classically,
    samples_to_counts,
)
from qctsp_hawkes.discretization import build_eta_grid, build_p_tau_given_x, build_tau_edges, build_tau_midpoints
from qctsp_hawkes.transition_tables import build_transition_table


def _is_aer_runtime_safe() -> bool:
    if platform.system() == "Darwin" and not Path("/dev/shm").exists():
        return False
    return True


def test_qctsp_sampling_smoke_indices_in_range() -> None:
    """Build/run a small lookup model and verify parsed indices are within bounds."""

    S = 8
    R = 16
    n_steps = 3
    shots = 200
    seed = 19

    eta_grid = build_eta_grid(S=S, eta_max=8.0)
    tau_edges = build_tau_edges(R=R, tau_max=4.0)
    tau_mid = build_tau_midpoints(edges=tau_edges)
    p_tau_given_x = build_p_tau_given_x(eta_grid=eta_grid, tau_edges=tau_edges, mu=0.55, alpha=0.25, beta=1.0)
    transition_table = build_transition_table(eta_grid=eta_grid, tau_mid=tau_mid, alpha=0.25, beta=1.0)

    circuit, layout = build_qctsp_unroll_circuit(
        p_tau_given_x=p_tau_given_x,
        transition_table=transition_table,
        n_steps=n_steps,
        x0=1,
        measure_x_path=True,
    )

    if _is_aer_runtime_safe():
        from qiskit_aer import AerSimulator

        backend = AerSimulator(seed_simulator=seed, max_parallel_threads=1)
        compiled = transpile(circuit, backend=backend, seed_transpiler=seed, optimization_level=0)
        counts = dict(backend.run(compiled, shots=shots, seed_simulator=seed).result().get_counts(compiled))
    else:
        classical_samples = sample_qctsp_classically(
            p_tau_given_x=p_tau_given_x,
            transition_table=transition_table,
            n_steps=n_steps,
            x0=1,
            shots=shots,
            seed=seed,
            measure_x_path=True,
        )
        counts = samples_to_counts(samples=classical_samples, layout=layout)

    samples = parse_qctsp_counts(counts=counts, layout=layout)

    assert len(samples) == shots

    tau_all = np.asarray([tau for sample in samples for tau in sample.tau_indices], dtype=np.int64)
    x_all = np.asarray([x for sample in samples for x in sample.x_indices], dtype=np.int64)
    x0_all = np.asarray([sample.x0 for sample in samples], dtype=np.int64)

    assert np.all((tau_all >= 0) & (tau_all < R))
    assert np.all((x_all >= 0) & (x_all < S))
    assert np.all((x0_all >= 0) & (x0_all < S))
