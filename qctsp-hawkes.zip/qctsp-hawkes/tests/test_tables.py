"""Tests for Hawkes QCTSP discretization and transition tables."""

from __future__ import annotations

import numpy as np

from qctsp_hawkes.discretization import (
    build_eta_grid,
    build_p_tau_given_x,
    build_tau_edges,
    build_tau_midpoints,
    tau_bin_representative_condexp,
)
from qctsp_hawkes.transition_tables import build_transition_table


def _build_small_fixture() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    eta_grid = build_eta_grid(S=12, eta_max=6.0)
    tau_edges = build_tau_edges(R=7, tau_max=3.5)
    tau_mid = build_tau_midpoints(edges=tau_edges)
    return eta_grid, tau_edges, tau_mid


def test_p_tau_given_x_rows_sum_to_one() -> None:
    """Each conditional holding-time row should sum to one."""

    eta_grid, tau_edges, _ = _build_small_fixture()
    probs = build_p_tau_given_x(eta_grid=eta_grid, tau_edges=tau_edges, mu=0.7, alpha=0.2, beta=1.3)
    row_sums = np.sum(probs, axis=1)

    assert np.allclose(row_sums, 1.0, rtol=0.0, atol=1.0e-10)


def test_transition_indices_within_valid_range() -> None:
    """Transition table must contain valid eta-bin indices."""

    eta_grid, _, tau_mid = _build_small_fixture()
    trans = build_transition_table(eta_grid=eta_grid, tau_mid=tau_mid, alpha=0.2, beta=1.3)

    assert np.issubdtype(trans.dtype, np.integer)
    assert int(np.min(trans)) >= 0
    assert int(np.max(trans)) < eta_grid.size


def test_transition_monotonic_sanity_in_tau() -> None:
    """For fixed x, larger tau should not increase quantized eta (plateaus are allowed)."""

    eta_grid, _, tau_mid = _build_small_fixture()
    trans = build_transition_table(eta_grid=eta_grid, tau_mid=tau_mid, alpha=0.2, beta=1.3)

    x_idx = eta_grid.size - 1
    mapped_eta = eta_grid[trans[x_idx]]
    assert np.all(np.diff(mapped_eta) <= 1.0e-12)


def test_condexp_representative_is_within_bin_bounds() -> None:
    """Conditional-expectation representative should lie inside finite bins."""

    rate = 1.3
    finite_edges = np.asarray([0.0, 0.4, 1.5, 3.0], dtype=np.float64)
    repr_finite = tau_bin_representative_condexp(tau_edges=finite_edges, rate=rate)
    assert repr_finite.shape == (finite_edges.size - 1,)
    for idx in range(repr_finite.size):
        assert finite_edges[idx] <= repr_finite[idx] <= finite_edges[idx + 1]

    tail_edges = np.asarray([0.0, 0.8, 1.6, np.inf], dtype=np.float64)
    repr_tail = tau_bin_representative_condexp(tau_edges=tail_edges, rate=rate)
    assert repr_tail.shape == (tail_edges.size - 1,)
    assert repr_tail[-1] > tail_edges[-2]
