"""Integration test for classical-vs-qctsp validation report generation."""

from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

from qctsp_hawkes.validation.compare import ComparisonConfig, run_validation_comparison


def test_run_validation_comparison_writes_report_and_has_required_keys(tmp_path: Path) -> None:
    """Run modest config and verify report structure, file output, and non-degenerate QCTSP N(T)."""

    output_path = tmp_path / "outputs" / "compare_report.json"
    config = ComparisonConfig(
        T=4.0,
        mu=0.7,
        alpha=0.3,
        beta=1.2,
        S=8,
        R=16,
        tau_max=3.0,
        eta_max=8.0,
        n_steps=3,
        shots=100,
        classical_paths=30,
        seed=5,
        x0=0,
        qctsp_backend="classical",
        auto_n_steps=True,
    )

    report, saved_path = run_validation_comparison(config=config, output_path=output_path)

    assert saved_path == output_path.resolve()
    assert output_path.exists()

    with output_path.open("r", encoding="utf-8") as fp:
        saved = json.load(fp)

    assert set(report.keys()) == {"config", "classical", "qctsp", "notes"}
    assert set(saved.keys()) == {"config", "classical", "qctsp", "notes"}

    for section in ("classical", "qctsp"):
        assert "N_T" in saved[section]
        assert "inter_arrival_mean" in saved[section]
        assert "inter_arrival_var" in saved[section]
        assert "ks_pvalue" in saved[section]
        assert "I_eta" in saved[section]
        assert "I_lambda" in saved[section]

    assert saved["classical"]["N_paths"] == 30
    assert saved["qctsp"]["shots"] == 100
    assert saved["qctsp"]["n_steps_effective"] >= saved["config"]["n_steps"]
    assert float(saved["qctsp"]["N_T"]["var"]) > 0.0
    mu = float(saved["config"]["mu"])
    T = float(saved["config"]["T"])
    assert min(saved["classical"]["I_lambda"]["samples"]) >= (mu * T - 1.0e-9)
    assert min(saved["qctsp"]["I_lambda"]["samples"]) >= (mu * T - 1.0e-9)


def test_run_validation_comparison_with_condexp_and_exp_quantile_modes(tmp_path: Path) -> None:
    """CLI smoke test for condexp + exp-quantile discretization settings."""

    output_path = tmp_path / "outputs" / "compare_report_condexp.json"
    env = dict(os.environ)
    env["PYTHONPATH"] = "src"
    subprocess.run(
        [
            sys.executable,
            "scripts/run_compare.py",
            "--T",
            "4.0",
            "--mu",
            "0.7",
            "--alpha",
            "0.3",
            "--beta",
            "1.2",
            "--S",
            "8",
            "--R",
            "16",
            "--tau-max",
            "3.0",
            "--eta-max",
            "8.0",
            "--n-steps",
            "3",
            "--shots",
            "50",
            "--classical-paths",
            "20",
            "--seed",
            "9",
            "--x0",
            "0",
            "--qctsp-backend",
            "classical",
            "--no-auto-n-steps",
            "--tau-repr",
            "condexp",
            "--tau-edges",
            "exp-quantile",
            "--lambda-ref",
            "lambda_mean",
            "--output",
            str(output_path),
        ],
        check=True,
        cwd=Path(__file__).resolve().parents[1],
        env=env,
    )

    assert output_path.exists()
    with output_path.open("r", encoding="utf-8") as fp:
        report = json.load(fp)
    assert report["config"]["tau_repr_mode"] == "condexp"
    assert report["config"]["tau_edges_mode"] == "exp-quantile"
