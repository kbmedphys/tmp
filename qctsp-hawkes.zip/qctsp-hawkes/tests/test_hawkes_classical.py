"""Tests for classical exponential Hawkes APIs."""

from __future__ import annotations

import numpy as np

from qctsp_hawkes.classical.hawkes_exp import (
    HawkesParams,
    fit_hawkes_exp_mle,
    hawkes_loglik_exp_1d,
    simulate_hawkes_exp_ogata,
)


def test_alpha_zero_matches_poisson_count_in_expectation() -> None:
    """alpha=0 should recover Poisson counts with mean mu*T."""

    T = 20.0
    mu = 0.7
    alpha = 0.0
    beta = 1.5
    counts = np.asarray(
        [
            simulate_hawkes_exp_ogata(T=T, mu=mu, alpha=alpha, beta=beta, seed=seed).size
            for seed in range(40)
        ],
        dtype=np.float64,
    )
    empirical_mean = float(np.mean(counts))
    expected = mu * T
    relative_error = abs(empirical_mean - expected) / expected

    assert relative_error < 0.15


def test_loglik_finite_for_reasonable_synthetic_dataset() -> None:
    """Log-likelihood should be finite for valid synthetic data."""

    T = 15.0
    mu = 0.6
    alpha = 0.2
    beta = 1.1
    times = simulate_hawkes_exp_ogata(T=T, mu=mu, alpha=alpha, beta=beta, seed=11)
    loglik = hawkes_loglik_exp_1d(times=times, T=T, mu=mu, alpha=alpha, beta=beta)

    assert np.isfinite(loglik)


def test_fit_recovers_order_of_magnitude_on_synthetic_data() -> None:
    """MLE fit should recover parameters within loose order-of-magnitude bounds."""

    T = 45.0
    true_params = HawkesParams(mu=0.55, alpha=0.35, beta=1.2)
    init_params = HawkesParams(mu=0.3, alpha=0.15, beta=0.7)
    times = simulate_hawkes_exp_ogata(
        T=T,
        mu=true_params.mu,
        alpha=true_params.alpha,
        beta=true_params.beta,
        seed=123,
    )

    estimated, result = fit_hawkes_exp_mle(times=times, T=T, init=init_params)

    assert np.isfinite(result.fun)
    assert true_params.mu / 4.0 < estimated.mu < true_params.mu * 4.0
    assert true_params.alpha / 4.0 < estimated.alpha < true_params.alpha * 4.0
    assert true_params.beta / 4.0 < estimated.beta < true_params.beta * 4.0
