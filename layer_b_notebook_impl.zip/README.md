# Layer B Notebook-only 実装

## ファイル

- `main_layer_b.ipynb`: Layer B本体。Layer A parquet出力を読み込み、baseline/fullのTopic Lineageを実行・可視化。
- `test_layer_b.ipynb`: Layer B単体テスト。人工Layer A出力でHellinger距離、linkage、lineage、可視化を確認。
- `test_layer_ab_methods.ipynb`: baseline/full比較用Notebook。
- `config_layer_b.yaml`: baseline/full切替、距離・リンク閾値、表示方針の設定。

## 入力

Layer Aの出力を想定します。

- `data/processed/clean_news.parquet`
- `data/processed/weekly_topics_baseline.parquet`
- `data/processed/article_topic_assignment_baseline.parquet`
- optional: `weekly_topics_full.parquet`, `article_topic_assignment_full.parquet`

ファイルがない場合は、検証用サンプルデータで動作します。

## 出力

原則Notebook上に表・プロットを表示します。
Layer C接続用に限り、以下のparquetを保存します。

- `data/processed/topic_links_baseline.parquet`
- `data/processed/topic_lineage_baseline.parquet`
- `data/processed/lineage_summary_baseline.parquet`
- full実行時は `_full.parquet` も保存します。

## 実装内容

- baseline:
  - topic word distribution
  - Hellinger distance
  - adjacent nearest alignment
  - continue / birth / death
  - lineage_id
  - novelty / persistence

- full:
  - mutual nearest / multiple links
  - split / merge / drift簡易判定
  - rare_topic_score
  - lineage network可視化