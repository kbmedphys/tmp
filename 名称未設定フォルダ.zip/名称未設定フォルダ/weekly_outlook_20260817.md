# Sector Gamma 週次見通し・リバランス案 — 2026年8月17日

**データ基準:** 2026年8月14日米国引け / 2026年8月17日JST更新  
**振り返り期間:** 2026年8月7日引け → 8月14日引け  
**見通し期間:** 2026年8月17日 → 8月21日  
**対象:** S&P 500 11セクターETF + IEF（米国7–10年国債）

> 本資料は研究・モデル運用のためのもので、個別の投資助言ではない。GEXは公開オプションチェーンからcallを正、putを負として計算した需給プロキシであり、実際のディーラーポジションを直接観測したものではない。

## 結論

今週のリバランス案は、**株式60.0% / IEF 40.0%を維持**し、株式内で **XLE・XLF・XLBをOverweight、XLP・XLY・XLI・XLCをUnderweight** とする。XLK・XLV・XLRE・XLUは基準配分に戻す、または据え置く。

マクロ環境は「インフレ鈍化」と「消費減速」が同居している。7月CPIは前年比3.4%へ鈍化し、PPIも前年比4.7%、前月比0.0%だった一方、7月小売売上高は前月比0.6%減となった。油価上昇が再び物価を押し上げる余地もあり、単純なリスクオンではなく、**エネルギー価格上昇に強いXLE、金利上昇時に相対的に耐えやすいXLFを買い、消費・景気敏感かつ負GammaのXLY・XLI・XLCを削る**のが中心となる。[CPI](https://apnews.com/article/consumer-prices-inflation-fed-interest-rates-150e179a6c6b3182ba05cedf0188394b) / [PPI](https://apnews.com/article/pipeline-inflation-prices-inflation-tariffs-f9bf278f4550a956b1f350722817371d) / [小売売上高](https://apnews.com/article/retail-inflation-consumer-sentiment-economy-3e2bc5807d7396b8e6c5f599941cb2a9)

IEFは現値93.04がGamma Flip 92.95とPut Wall 93.00の近傍にあり、方向感が弱い。株式合成スコアとIEFスコアの差が小さく、モデル上の株式増額は+0.26ポイントにとどまって0.5ポイントのノートレード帯に入ったため、**IEF 40.0%を維持**する。

## 先週の振り返り

### 市場で確認された事実

- 週間ではS&P 500が+0.4%、Nasdaqが+0.1%、Dowが-0.6%、Russell 2000が+1.1%。金曜は弱い小売統計と油価上昇を受け、S&P 500が0.2%下落した。[APの週間指数集計](https://apnews.com/article/wall-street-stocks-dow-nasdaq-41b7cf2acc6562758183b1c5eae73635)
- 7月CPIは前年比3.4%（6月3.5%）、コアCPIは2.5%（6月2.6%）。前月比は総合+0.1%、コア+0.2%で、基調的な価格圧力は鈍化したが、総合インフレはなお3%を超える。
- 7月PPIは前月比0.0%、前年比4.7%（6月5.5%）。川上の物価圧力は緩和した。
- 7月小売売上高は前月比-0.6%、自動車・ガソリンを除いて-0.2%。消費の耐久性に警戒を要する結果だった。

### 前回配分の実績 — 継続保有ベース

8月2日スナップショットの配分を継続保有したものとして、配当調整済みETF終値で8月7日→14日を評価した。

| 指標 | 収益率 |
|---|---:|
| 60/40基準配分 | +0.585% |
| 前回戦術配分 | +0.586% |
| 超過収益 | **+0.16bp** |

主なActive寄与は以下の通り。

| セクター | 前回判断 | ETF騰落率 | Active寄与 | 評価 |
|---|---|---:|---:|---|
| XLRE | Overweight | +0.64% | +0.64bp | 小幅上昇を増額していたためプラス |
| XLY | Underweight | -1.38% | +0.39bp | 小売減速と整合し、減額が奏功 |
| XLK | Underweight | +1.09% | -0.39bp | 上昇を取り逃がしマイナス |
| XLC | Underweight | +1.53% | -0.35bp | 反発を取り逃がしマイナス |
| XLU | 小幅Underweight | +1.61% | -0.08bp | ディフェンシブ上昇を取り逃がし |
| XLI | 小幅Underweight | +0.72% | -0.06bp | 上昇をやや取り逃がし |

XLEは+7.67%と最大の上昇だったが、前回はNeutralのためActive寄与はゼロだった。今回のXLE Overweightは、この取り逃がしを単純に追いかけるのではなく、正Gamma、Flip上方、20日トレンド、油価・地政学リスクが同時に上向いていることに基づく。

なお、60/40基準は11セクターETFとIEFの固定ウェイトで計算したモデル内ベンチマークであり、S&P 500指数そのものではない。外部の指数騰落率はクロスチェックとして併記し、モデル損益とは混同しない。

## 今週のリバランス案

### 売買一覧

| ETF | 新配分 | 前回配分 | 売買 | 60/40基準比 | 判断 |
|---|---:|---:|---:|---:|---|
| IEF | **40.00%** | 40.00% | 0.00pt | 0.00pt | Neutral |
| XLK | **19.72%** | 19.36% | +0.36pt | 0.00pt | Neutralへ戻す |
| XLF | **8.63%** | 7.55% | **+1.08pt** | +1.08pt | Overweight |
| XLV | **5.69%** | 5.69% | 0.00pt | 0.00pt | Neutral |
| XLY | **5.38%** | 5.65% | -0.28pt | -0.56pt | Underweight |
| XLC | **5.34%** | 5.94% | **-0.61pt** | -0.83pt | Underweight |
| XLI | **4.60%** | 5.32% | **-0.72pt** | -0.79pt | Underweight |
| XLE | **3.32%** | 2.40% | **+0.92pt** | +0.92pt | Overweight |
| XLP | **2.97%** | 3.18% | -0.20pt | -0.20pt | Underweight |
| XLB | **1.65%** | 1.26% | +0.39pt | +0.39pt | Overweight |
| XLU | **1.50%** | 1.45% | +0.05pt | 0.00pt | Neutralへ戻す |
| XLRE | **1.20%** | 2.19% | **-1.00pt** | 0.00pt | Neutralへ戻す |

配分合計は100.0%、株式60.0%、IEF40.0%。片道売買回転率は約2.80%である。実務上は、まずXLRE・XLI・XLCの売却を行い、その資金をXLF・XLE・XLBへ振り向け、残りでXLK・XLUのUnderweightを解消する。

### 執行方法

- 月曜寄りで全量を動かさず、**50%を初回、25%を水曜FOMC議事要旨後、25%を木曜主要決算後**に分ける。
- XLEは現値61.91が7日1σ上限64.14へ近づくほど追随買いを控え、60.00–61.00への押しを優先する。
- XLFは58.00のCall Wall近傍のため、58を明確に上抜けて定着しない限り、指値を分散する。
- XLBは7日1σレンジが47.53–57.55と非常に広く、データ品質・イベント感応度を考慮して小幅Overweightに限定する。
- IEFは92.95–93.00を割れたままFOMC議事要旨を通過する場合、追加増額を行わない。逆に93.78–94.00を上抜けても、今週中は40%を上限とする。

## 各セクターとIEFの根拠

以下で「事実」は8月14日終値と8月17日JSTに取得したオプションチェーンから計算したモデル入力、「推論」はマクロ・決算との対応づけである。

### XLE — Energy: Overweight 3.32%

- **事実:** Adjusted Score +0.417で12資産中首位。現値61.91はGamma Flip 58.02とCall Wall 60を上回り、Net GEXは正。20日騰落率+7.33%、IVレンジ59.68–64.14。
- **マクロ推論:** Iran・Hormuzを巡る供給不安と油価上昇は売上単価を支える。一方、油価反落は最大の逆風なので、64.14超では追わない。
- **ボトムアップ推論:** 今週はXLE主要構成銘柄の集中決算週ではないため、個社サプライズより原油・精製マージン・地政学ニュースへの感応度を優先する。

### XLF — Financials: Overweight 8.63%

- **事実:** Adjusted Score +0.204、正Gamma、現値58.16はFlip 56.80より上。Put Wall 56、Call Wall 58、IVレンジ56.44–59.88。20日騰落率+3.38%。
- **マクロ推論:** FOMC議事要旨がタカ派なら中長期金利上昇と利ざや期待が支えとなりやすい。ただし、小売・雇用の悪化が信用コスト懸念へ移る場合は逆風。
- **ボトムアップ推論:** 今週の小売大手決算はカード利用、延滞、在庫金融、決済量の間接指標になる。58のWallを上抜けられるかを増額継続の条件とする。

### XLB — Materials: Overweight 1.65%

- **事実:** Adjusted Score +0.077、正Gamma、現値52.54はFlip 49.60を上回る。Call Wall 55、Put Wall 47.5、IVレンジ47.53–57.55。高Vanna/高Charmフラグはない。
- **マクロ推論:** 住宅着工、建築許可、鉱工業生産、PMIの改善に上方向の感応度がある。一方、景気減速や中国需要懸念には弱い。
- **ボトムアップ推論:** 個社決算より住宅・製造業データの読み替えが中心。IVレンジが広いため、XLE・XLFより小さいOverweightとする。

### XLK — Information Technology: Neutral 19.72%

- **事実:** Adjusted Score +0.067、正Gamma、現値190.01はFlip 183.45より上だがPut Wall 190上にほぼ一致。Call Wall 195、IVレンジ181.89–198.13。短期GEX集中と高CharmがHard Ruleに抵触し、Overweight不可。
- **マクロ推論:** 金利低下は長期成長株に追い風、タカ派議事要旨はバリュエーション逆風。PMI・設備投資の強さはAI・半導体需要の下支えになる。
- **ボトムアップ推論:** 月曜引け後のFabrinet、火曜引け後のKeysight、水曜朝のAnalog DevicesがAI通信・計測・半導体需要の読み替え材料。195を超えれば上値余地が広がるが、190割れでは183.45までの不安定化を警戒する。

### XLV — Health Care: Neutral 5.69%

- **事実:** Adjusted Score +0.231と良好で、現値167.37はFlip 154.62より上。Call Wall 170、Put Wall 160、IVレンジ160.26–174.48。ただし170のCall Wall近傍と高CharmでHard RuleによりOverweight不可。
- **マクロ推論:** 消費減速・景気不安時のディフェンシブ性はプラス。一方、金利上昇と政策ヘッドラインはバリュエーションを抑える。
- **ボトムアップ推論:** 今週は大型ヘルスケア決算の集中が薄く、個社より資金のディフェンシブ回帰を重視する。170突破までは基準配分を維持する。

### XLRE — Real Estate: Neutral 1.20%

- **事実:** Adjusted Score +0.410と高いが、現値45.27はPut/Call Wall 45近傍。短期GEX集中と高CharmでHard Ruleに抵触。Flip 43.62、IVレンジ44.22–46.32。
- **マクロ推論:** 金利低下と住宅データ改善は追い風、タカ派FOMC議事要旨と長期金利上昇は逆風。方向は良くてもイベント前の凸性リスクが高い。
- **ボトムアップ推論:** NAHB、住宅着工・許可、Pending Home Sales、Toll Brothers、Home Depot/Lowe'sが住宅需要の連続テストになる。前回Overweightの利益を確定し、今週はいったん基準へ戻す。

### XLU — Utilities: Neutral 1.50%

- **事実:** Adjusted Score +0.094、正Gammaだが現値44.31はPut Wall 45を下回り、Flip 43.49に近い。IVレンジ43.17–45.45、高CharmでHard Ruleに抵触。
- **マクロ推論:** 金利低下は配当・設備投資価値に追い風、油価由来のインフレと金利上昇は逆風。AI向け電力需要は中期支援材料だが、今週は金利感応度が優先される。
- **ボトムアップ推論:** 45回復までは強気に傾けず、前回の小幅Underweightだけを解消する。

### XLP — Consumer Staples: Underweight 2.97%

- **事実:** Adjusted Score -0.093、Net GEXは負、現値86.09はFlip 91.80を下回る。Put/Call OI比3.49、Call Wall 85、Put Wall 78、IVレンジ83.61–88.57。高Charm。
- **マクロ推論:** ディフェンシブ性はあるが、油価・輸送費・食品価格がマージンを圧迫しやすい。負Gammaと高いput需要を優先し、小幅Underweight。
- **ボトムアップ推論:** 水曜Target、木曜Walmart、金曜BJ'sの売上構成・価格投資・粗利が重要。好決算に加え88.57超へ定着すればUnderweight縮小を検討する。

### XLY — Consumer Discretionary: Underweight 5.38%

- **事実:** Adjusted Score -0.159、Net GEXは負、現値118.20はFlip 141.84を大きく下回る。Put/Call OI比3.00、Call Wall 120、Put Wall 110、IVレンジ112.57–123.83。
- **マクロ推論:** 小売売上高-0.6%、高いガソリン価格、住宅関連支出の弱さが同時に逆風。利下げ期待だけで景気懸念を相殺できるかを確認する局面。
- **ボトムアップ推論:** Home Depot、Lowe's、TJX、Ross、Toll Brothersが集中する最重要セクター。TargetはXLP構成銘柄だが、裁量消費全体の読み替えにも使う。120–123.83を上抜けるまではUnderweightを維持する。

### XLI — Industrials: Underweight 4.60%

- **事実:** Adjusted Score -0.282、Net GEXは負、現値186.51はFlip 197.76を下回る。Put/Call OI比2.93、Call Wall 195、Put Wall 175、IVレンジ179.46–193.56。高Charm。
- **マクロ推論:** 鉱工業生産、設備稼働率、Empire/Philadelphia Fed、PMIの悪化に弱い。中東情勢による物流・燃料コストも逆風。
- **ボトムアップ推論:** 木曜Deereは農機・大型設備投資、月曜Fabrinetや水曜Nordsonは製造投資の読み替え材料。193.56–195回復までは減額を維持する。

### XLC — Communication Services: Underweight 5.34%

- **事実:** Adjusted Score -0.325で最下位。Net GEXは負、現値112.95はFlip 124.23を下回る。Put/Call OI比5.74、Call Wall 115、Put Wall 104、IVレンジ105.92–119.98。
- **マクロ推論:** 広告・娯楽需要は消費減速に影響され、金利上昇は大型成長株の評価を圧迫する。
- **ボトムアップ推論:** 今週は構成上位企業の大型決算が少なく、個別の上振れ触媒よりオプション需給を優先する。115超、次いで119.98超をUnderweight縮小条件とする。

### IEF — 7–10年米国国債: Neutral 40.00%

- **事実:** Adjusted Score +0.051、現値93.04、Gamma Flip 92.95、Call Wall 94、Put Wall 93、IVレンジ92.30–93.78。Net GEXは正だが、Vanna集中75.8%、Charm集中93.0%と高い。
- **マクロ推論:** 7月FOMCは3.50–3.75%で据え置き、9対3で3名が利上げを主張した。水曜議事要旨がタカ派ならIEFは92.95/92.30を試し、消費・住宅・PMIが弱ければ93.78/94を試す。[7月FOMC声明](https://www.federalreserve.gov/newsevents/pressreleases/monetary20260729a.htm)
- **運用判断:** 株式対IEFの相対スコア差は株式+0.26ポイント相当にすぎずノートレード帯内。40%を維持し、92.30割れまたは94上抜けを翌週のバケット調整条件とする。

## 日別イベントとポジション対応

今週の中心は、住宅・製造業統計、FOMC議事要旨、小売・半導体・資本財決算である。[経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar) / [決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks) / [APの週次プレビュー](https://apnews.com/article/wall-street-home-depot-target-fed-7dd75609981e7e96b40aa82523b0ea57)

| 日付 | 主なイベント（米東部時間） | 主なETF | 観測ポイント |
|---|---|---|---|
| 8/17 月 | 8:30 Empire State、10:00 NAHB、引け後Fabrinet | XLI, XLB, XLRE, XLY, XLK, IEF | 製造・住宅が弱ければXLI/XLYには逆風、IEFには追い風 |
| 8/18 火 | 8:30 住宅着工・許可・輸入物価、9:15 鉱工業生産・稼働率、10:00 Pending Home Sales、HD朝、Keysight/Toll Brothers引け後 | XLY, XLRE, XLB, XLI, XLK, IEF | 輸入物価は金利、住宅一式はXLRE/XLY、製造はXLI/XLBに直結 |
| 8/19 水 | ADI・Lowe's・Target・TJX朝、14:00 FOMC議事要旨 | XLK, XLY, XLP, XLF, XLRE, XLU, IEF | 今週最大の金利イベント。IEF 92.95、XLRE 45、XLU 43.49を同時監視 |
| 8/20 木 | 8:30 新規失業保険・Philadelphia Fed、Walmart・Deere・Alibaba朝、Ross引け後 | XLP, XLI, XLY, XLC, XLF, IEF | 消費と設備投資の質を確認。弱い雇用はIEF支援でも景気敏感株には逆風 |
| 8/21 金 | 9:45 S&P Flash製造業・サービス業PMI、BJ's朝 | XLI, XLB, XLK, XLE, XLP, IEF | 成長・価格指数の組み合わせで週末のリスク量を調整 |

## Vanna / Charmとガンマ運営

- **高Vannaフラグ:** 11セクターにはなし。ただしIEFはVanna集中75.8%で、IV変化と現物ヘッジの相互作用に注意する。
- **高Charmフラグ:** XLF、XLE、XLK、XLV、XLI、XLRE、XLP、XLU。時間経過だけでもデルタヘッジ需要が変化しやすく、イベント通過後の値動きが初動と逆になる可能性がある。
- **負Gamma:** XLP、XLY、XLI、XLC。悪材料時に値動きが拡大しやすいため、Underweightを維持する。
- **正GammaだがHard Rule:** XLKはPut Wall・短期GEX・Charm、XLVはCall Wall、XLREはPut Wall・短期GEX・Charm、XLUはFlip近傍・Put Wall割れ・Charmが制約となる。

## シナリオ

### 中立シナリオ — 基本配分

インフレ鈍化と消費減速が相殺し、FOMC議事要旨も新たな方向を示さない。株式60 / IEF40を維持し、XLE・XLF・XLBのOverweightとXLY・XLI・XLCのUnderweightを継続する。

### 強気シナリオ

住宅・小売決算が底堅く、PMIが改善、議事要旨が想定よりハト派。XLKが195、XLYが123.83、XLCが119.98、XLIが193.56を上抜けば、Underweightの半分を解消する。IEFが94を超えても、株式も同時上昇する「金利低下型リスクオン」なら40%維持でよい。

### 弱気シナリオ

油価再上昇、輸入物価上振れ、タカ派議事要旨、弱い小売決算が重なる。IEFが92.95を割り92.30も下抜け、XLKが190、XLYが112.57、XLIが179.46、XLCが105.92を割る場合、株式を55–57.5%へ落とす次回調整を準備する。ただし、今週の途中で機械的にIEFを増やすのではなく、金利上昇局面では現金・短期国債を含む別ヘッジも検討対象とする。

## 監視水準一覧

| ETF | 配分 | Score | Spot | Flip | Call Wall | Put Wall | 7日1σレンジ | Gamma / 2次感応度 |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| XLE | 3.32% | +0.417 | 61.91 | 58.02 | 60.00 | 55.00 | 59.68–64.14 | 正Gamma / Charm高 |
| XLRE | 1.20% | +0.410 | 45.27 | 43.62 | 45.00 | 45.00 | 44.22–46.32 | 正Gamma / Charm高・短期集中 |
| XLV | 5.69% | +0.231 | 167.37 | 154.62 | 170.00 | 160.00 | 160.26–174.48 | 正Gamma / Charm高 |
| XLF | 8.63% | +0.204 | 58.16 | 56.80 | 58.00 | 56.00 | 56.44–59.88 | 正Gamma / Charm高 |
| XLU | 1.50% | +0.094 | 44.31 | 43.49 | 44.00 | 45.00 | 43.17–45.45 | 正Gamma / Flip近傍・Charm高 |
| XLB | 1.65% | +0.077 | 52.54 | 49.60 | 55.00 | 47.50 | 47.53–57.55 | 正Gamma / 集中フラグなし |
| XLK | 19.72% | +0.067 | 190.01 | 183.45 | 195.00 | 190.00 | 181.89–198.13 | 正Gamma / Charm高・短期集中 |
| IEF | 40.00% | +0.051 | 93.04 | 92.95 | 94.00 | 93.00 | 92.30–93.78 | 正Gamma / Vanna・Charm集中高 |
| XLP | 2.97% | -0.093 | 86.09 | 91.80 | 85.00 | 78.00 | 83.61–88.57 | 負Gamma / Charm高 |
| XLY | 5.38% | -0.159 | 118.20 | 141.84 | 120.00 | 110.00 | 112.57–123.83 | 負Gamma |
| XLI | 4.60% | -0.282 | 186.51 | 197.76 | 195.00 | 175.00 | 179.46–193.56 | 負Gamma / Charm高 |
| XLC | 5.34% | -0.325 | 112.95 | 124.23 | 115.00 | 104.00 | 105.92–119.98 | 負Gamma |

## データと外部参照

- モデル生成物: `outputs/tables/consistent_12asset_allocation.csv`
- 最新保有週検証: `outputs/tables/latest_holding_week_attribution.csv`
- オプション指標: `outputs/tables/consistent_option_metrics.csv`
- IEFダッシュボード表: `outputs/tables/ief_dashboard.csv`
- HTMLダッシュボード: `outputs/dashboard/sector_gamma_dashboard.html`
- [AP: 8月14日までの主要指数](https://apnews.com/article/wall-street-stocks-dow-nasdaq-41b7cf2acc6562758183b1c5eae73635)
- [AP: 7月CPI](https://apnews.com/article/consumer-prices-inflation-fed-interest-rates-150e179a6c6b3182ba05cedf0188394b)
- [AP: 7月PPI](https://apnews.com/article/pipeline-inflation-prices-inflation-tariffs-f9bf278f4550a956b1f350722817371d)
- [AP: 7月小売売上高](https://apnews.com/article/retail-inflation-consumer-sentiment-economy-3e2bc5807d7396b8e6c5f599941cb2a9)
- [Federal Reserve: 2026年7月FOMC声明](https://www.federalreserve.gov/newsevents/pressreleases/monetary20260729a.htm)
- [Kiplinger: 8月17–21日の経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)
- [Kiplinger: 8月17–21日の決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)
- [BLS: 2026年8月の公表日程](https://www.bls.gov/schedule/2026/08_sched.htm)
