# 2026年10月19日から23日のセクターとIEF週間見通し

更新日：2026年10月18日JST。先週の評価期間は10月9日引けから16日引け、来週の対象は10月19–23日。価格は配当調整済みETF終値、オプションは10月18日取得の週末スナップショットで、全12銘柄の最終売買日は10月16日。予定時刻は米東部時間。

**提案目標は株式58.56%、IEF41.44%。XLK・XLI・XLCを減らし、XLV・XLE・XLUとIEFを増やす。** 前回のIV異常は今回の取得で解消した。半導体企業の好業績とXLKの価格・オプションの弱さが併存するため、決算の良さだけで技術株のOverweightを継続しない。IEFは実質金利低下と正GEXを評価するが、BEIは小幅上昇している。まず差分の半分に相当する株式59.40%・IEF40.60%へ寄せ、決算と金利を確認して残りを判断する。

実保有・約定・承認は未入力。以下はDRAFTの研究用配分とペーパー検証である。前回採用したのは株式60.25%・IEF39.75%の据置目標であり、10月12日の未採用機械候補とは区別する。[前回週報](weekly_outlook_20261012.md) / [今回の配分と寄与度CSV](../tables/weekly_review_20261018.csv)

## 先週の市場と前回案の結果

S&P 500は週間約−1.9%。金曜はS&P 500が−1.1%、Nasdaqが−2.1%となり、技術株の下落が目立った。週末終値を報じた[AP](https://apnews.com/article/c27809783ae3230b44c26e5ee4bea056)と[当日の市場解説](https://www.kiplinger.com/investing/stocks/nasdaq-buckles-on-fear-this-boom-is-an-ai-bubble-stock-market-today)は、AI関連株の調整と債券利回り低下を報告している。ニュースとETF変動の同時発生を、単独の因果関係とは断定しない。

経済統計では9月CPIが前月比+0.6%、コア+0.3%。ガソリン+9.1%が総合上昇の半分超を占めた。PPIは前月比+1.3%、前年比+6.3%、食品・エネルギー・商業マージンを除く指数も前月比+0.5%となった。小売売上高+0.8%は物価未調整の名目値である。鉱工業生産+0.7%に対して製造業は+0.3%、公益は+3.5%で、需要の強さは一様ではない。[BLS CPI](https://www.bls.gov/news.release/archives/cpi_10142026.htm) / [BLS PPI](https://www.bls.gov/news.release/archives/ppi_10152026.htm) / [Census小売](https://www.census.gov/retail/sales.html) / [Fed鉱工業生産](https://www.federalreserve.gov/releases/g17/20261016/)

**ペーパー検証は前回採用した目標ウェイトを10月9日終値で固定した反実仮想。収益率は−0.966%、同時点のセクター時価総額加重60%＋IEF40%基準は−0.892%、超過は−7.40bp。** XLKの−7.70%下落とOverweightが最大の負担だった。XLE・XLUのOverweightはプラス、XLPのUnderweightはマイナスに寄与した。

| 資産 | 先週ETF騰落 | 前回Active寄与 |
|---|---:|---:|
| XLK | −7.70% | −8.69bp |
| XLY | −0.35% | +0.17bp |
| XLP | +5.02% | −4.54bp |
| XLE | +4.86% | +3.16bp |
| XLF | +1.44% | +0.05bp |
| XLV | +3.45% | −0.82bp |
| XLI | −0.88% | +0.45bp |
| XLC | −0.05% | +0.04bp |
| XLB | +3.01% | +0.79bp |
| XLRE | +1.32% | −0.08bp |
| XLU | +1.93% | +2.33bp |
| IEF | +1.14% | −0.28bp |

計算は各資産の前回採用ウェイト×調整後価格リターン。前回採用目標の原本は[10月4日のv2保存値](../../data/processed/20261002/v2/SGV2-20261005/20261004T123304930176Z/portfolio_target.csv)、比較基準は[10月12日の保存値](../../data/processed/20261009/v2/SGV2-20261012/20261012T103337790355Z/portfolio_target.csv)。実口座の売買や、10月2日から無売買で保有し続けた場合のウェイト変動を再現した成績ではない。調整後価格に含まれる分配金を重ねて加算せず、費用・税金は含めない。CSV上で目標収益−基準収益＝Active収益を照合した。

## 金利とBEIから見たIEFの増額

同じ日付の比較では、FRED名目10年金利は10月9日5.24%から15日5.10%へ−14bp、実質10年は2.91%から2.78%へ−13bp。両者がそろう最新日は15日で、この日の10年BEIは2.32%。その後16日の10年BEIは2.35%、5年BEIは2.37%となり、9日比でそれぞれ+2bp、+3bpだった。16日の名目・実質FRED値はまだそろっていないため、16日BEIと15日金利を引き算しない。[FRED名目10年](https://fred.stlouisfed.org/series/DGS10) / [実質10年](https://fred.stlouisfed.org/series/DFII10) / [10年BEI](https://fred.stlouisfed.org/series/T10YIE) / [5年BEI](https://fred.stlouisfed.org/series/T5YIE)

Notebookのマクロ表にある`change_5d`は系列ごとの直近観測数に基づくため、祝日と公表ラグのある今回は週次比較にそのまま流用せず、上記の10月9日を起点に再計算した。[日付別マクロ履歴](../../data/processed/20261016/v2/SGV2-20261019/20261018T124205833941Z/macro_history.csv)

**判断はIEFを小幅増額する方向。** CPI上昇だけなら債券に逆風だが、実際には実質金利が低下し、IEFは90.42へ上昇、20日平均89.59を上回った。正GEX約1.97億、Flip89.33、Call Wall91も支えになる。一方、50日平均90.96は未回復で、BEI上昇はインフレ補償の再拡大を示す。物価沈静化を前提に大幅な債券Overweightへ進む根拠は弱く、41.44%を段階的な目標とする。

当面はIEF40.60%を第一段階とし、90前後を維持、名目10年金利が5.15%以下、10年BEIが2.40%未満で推移するなら41.44%への残りを検討する。IEFが89.33を終値で割るか、BEI2.40%以上と金利反発がそろえば増額を止め、40%へ戻す案を再計算する。これらは人手の監視条件であり、Notebookの既存スコア係数を変更したものではない。BEIは期待インフレに加えリスク・流動性プレミアムを含む。

## 来週の目標配分とリバランス案

| 資産 | 基準 | 前回採用目標 | 新目標 | 基準比 | 前回比 |
|---|---:|---:|---:|---:|---:|
| XLK | 24.27% | 25.40% | **22.20%** | −2.07pt | −3.19pt |
| XLY | 5.24% | 4.75% | **4.44%** | −0.80pt | −0.31pt |
| XLP | 2.60% | 1.69% | **2.64%** | +0.04pt | +0.94pt |
| XLE | 2.04% | 2.69% | **3.72%** | +1.68pt | +1.03pt |
| XLF | 6.72% | 6.75% | **6.25%** | −0.47pt | −0.50pt |
| XLV | 5.56% | 5.32% | **6.94%** | +1.38pt | +1.62pt |
| XLI | 4.52% | 4.01% | **2.70%** | −1.83pt | −1.31pt |
| XLC | 5.97% | 5.14% | **4.41%** | −1.56pt | −0.73pt |
| XLB | 0.94% | 1.20% | **1.28%** | +0.34pt | +0.08pt |
| XLRE | 1.02% | 0.96% | **0.95%** | −0.07pt | −0.01pt |
| XLU | 1.13% | 2.34% | **3.04%** | +1.92pt | +0.71pt |
| IEF | 40.00% | 39.75% | **41.44%** | +1.44pt | +1.68pt |

端数丸め前の新目標は合計100%、Active合計0。表示値合計100.01%は丸め差。モデルの最終目標に対する予測Tracking Errorは基準比年率1.12%で、設定予算3%以内。前回採用目標からの理論上の片道変更は6.06%。実保有が未入力なので、実際の回転率・株数・売買費用は確定できない。[不変の新目標](../../data/processed/20261016/v2/SGV2-20261019/20261018T124205833941Z/portfolio_target.csv) / [リスク推計](../../data/processed/20261016/v2/SGV2-20261019/20261018T124205833941Z/risk_summary.csv)

基準は取得できたSPYセクター比率×60%＋IEF40%。ベンダーは構成比の実効日を提供しておらず、10月16日を判断基準日として保存している。公式S&P 500指数そのものではない。既存のスコア係数・配分制約は維持し、マクロと決算は案の採否、実施順序、撤回条件に使う。

実施案は差分の半分を第一段階にする。これなら株式59.40%・IEF40.60%となり、XLKへの集中と決算前のリスクを減らしながら、反発を取り逃す度合いを抑えられる。残りはNetflix、Meta、Tesla、NextEra、P&Gなどの発表後に確認する。XLEの70、XLVの175、XLUの42、IEFの89.33を下記の建玉・価格監視と結びつけ、目標到達を急いで上値を追わない。

## 各セクターの先週の決算と来週への接続

ここで記す企業の発表・日程は確認された事実、配分への波及は条件付きの推論。ASML・TSMC・Alcoaは関連業界の参考材料で、ETFへの直接寄与と混同しない。

- **XLK 22.20%、Underweightへ変更。** 先週のASMLは売上117億ユーロ、粗利率57.5%、TSMCは台湾ドル売上が前年比+50.9%、粗利率66.4%と好調だった。それでもXLKは−7.70%、現値183.47は20日平均195.82・50日平均189.80を下回る。負GEXとFlip201.24を併せ、好決算の織り込み直しを警戒する。来週は21日のIBMなどでAI案件が継続収益とキャッシュフローに変わるかを見る。業績上振れでも価格が回復しない間は上乗せを戻さない。[ASML決算](https://www.investor.asml.com/news-releases/news-release-details/asml-reports-eu11.7-billion-total-net-sales-and-eu5.0-billion-net-income-q3-2026) / [TSMC決算](https://pr.tsmc.com/english/news/3346) / [IBM公式発表一覧](https://newsroom.ibm.com/press-releases-corporate?l=5)
- **XLY 4.44%、Underweight維持。** Domino'sの米国既存店売上は+0.3%。小売全体は名目+0.8%でも、ガソリン高が家計の裁量支出を圧迫しうる。先週ETF−0.35%、負GEX。来週21日のTeslaでは納車台数だけでなく自動車利益率、価格、FCF、設備投資を確認する。利益率と需要見通しが改善すればUW縮小、値下げ依存なら維持。Gamma Flipの134.95はゼロ交差未確認の近似値なので判断閾値には使わない。[Domino's決算](https://ir.dominos.com/news-releases/news-release-details/dominos-pizzar-announces-third-quarter-2026-financial-results) / [Tesla公式日程](https://ir.tesla.com/press-release/tesla-third-quarter-2026-production-deliveries-and-deployments)
- **XLP 2.64%、Underweightをほぼ解消。** 先週ETF+5.02%を取り逃した。CPIの食品全体は前月比横ばいでも、エネルギー・物流費上昇が企業の採算に響く。来週は21日のPhilip Morris、22日のP&Gで販売数量、値上げ、粗利率を確認する。生活必需需要と価格転嫁を評価して基準並みへ戻す一方、負GEXが残るため強いOWにはしない。Call Wall90はIVレンジ内で上値の確認点。[CPI内訳](https://www.bls.gov/news.release/archives/cpi_10142026.htm) / [PM公式日程](https://www.pmi.com/media-center/press-releases/press-details?newsId=30436) / [P&G公式日程](https://origprod-cus-us.pg.com/newsroom/news-releases/PG-to-Webcast-Discussion-of-First-Quarter-2627-Earnings-Results-on-October-22/)
- **XLE 3.72%、Overweight拡大。** 先週ETF+4.86%。IEAは15日に残る備蓄放出の加速と、2,000万バレル超のディーゼル供給を進めると表明した。供給制約が続く原油には追い風がある一方、政策対応や輸送正常化は反落要因。正GEX、現値68.24がFlip63.88の上であることを評価する。来週23日のSLBでは原油価格と別に、顧客の設備投資・中東事業・受注採算を見る。Call Wall70への接近では増額を分割する。[IEA声明](https://www.iea.org/news/iea-governing-board-statement-on-energy-markets-and-security) / [SLB公式日程](https://www.slb.com/newsroom/press-release/2026/pr-2026-0928-q3-earnings-call-announcement)
- **XLF 6.25%、Underweight。** JPMorganは純利益153億ドル、純金利収入前年比+13%を発表した。先週ETF+1.44%と銀行決算を評価する動きはあったが、信用スプレッドは拡大し、XLFのGEXは約−9,918万で今回12資産中最も負が大きい。来週23日のAmerican Expressではカード支出と貸倒れ・延滞を確認する。56のCall Wallと56.95のFlipを回復できればUWを再検討し、好業績だけで信用リスクを無視しない。[JPMorgan決算](https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2026/3rd-quarter/6c1f8114-1be4-4174-8292-f75bbb59bc21.pdf) / [AXP会社発表の配信](https://www.nasdaq.com/press-release/american-express-plans-live-audio-webcast-third-quarter-2026-earnings-conference-call)
- **XLV 6.94%、Overweightへ変更。** J&Jは売上+5.9%で通期見通しを引き上げ、UnitedHealthも通期調整後EPS見通しを20.50ドル以上へ引き上げた。先週ETF+3.45%、正GEX、現値176.71はCall Wall175を上回る。来週21日のDanaherでは診断・ライフサイエンス需要の広がりを確認する。医療需要と利益見通しの改善を評価する一方、保険コストや薬価の個別リスクは残す。175を割り戻すなら追加分を見直す。[J&J決算](https://www.investor.jnj.com/investor-news/news-details/2026/Johnson--Johnson-reports-Q3-2026-results-raises-2026-guidance/default.aspx) / [UNH決算](https://www.unitedhealthgroup.com/newsroom/2026/2026-10-13-uhg-reports-third-quarter-2026-results.html) / [Danaher公式日程](https://investors.danaher.com/2026-09-22-Danaher-Schedules-Third-Quarter-2026-Earnings-Conference-Call)
- **XLI 2.70%、Underweight拡大。** Fastenalは営業利益率21.5%と前年20.7%から改善、製造業生産も+0.3%だったが、ETFは−0.88%。好調な一社の実績と業界全体の見通しは一致せず、燃料・投入費も負担になる。負GEX、20日・50日平均未満を重視する。来週20日のGE Aerospaceでエンジン・サービス受注、23日のPMIで新規受注と販売価格を確認。受注と利益率が改善し価格も回復すればUW縮小を再検討する。[Fastenal決算](https://investor.fastenal.com/news/news-details/2026/Fastenal-Company-Reports-2026-Third-Quarter-Earnings/default.aspx) / [GE公式日程](https://www.geaerospace.com/investor-relations/events-reports/ge-aerospace-3rd-quarter-2026-earnings-webcast)
- **XLC 4.41%、Underweight維持。** 先週ETFは−0.05%とXLKより底堅かったが、現値110.32はPut Wall110のすぐ上で負GEX。来週20日のNetflix、21日のMetaで売上成長、広告単価・表示回数、コンテンツ費、AI設備投資とFCFを確認する。売上成長が費用増を吸収し、Flip114.42とCall Wall115を回復すればUW縮小を検討する。費用計画だけの拡大なら慎重姿勢を維持する。[Netflix公式日程](https://ir.netflix.net/investor-news-and-events/financial-releases/press-release-details/2026/Netflix-to-Announce-Third-Quarter-2026-Financial-Results/default.aspx) / [Meta公式日程](https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-to-Announce-Third-Quarter-2026-Results/default.aspx)
- **XLB 1.28%、小幅Overweight。** Alcoaは増産とキャッシュ創出を発表したが、売上は前四半期比−7%、調整後EBITDAも前四半期を下回り、資源高が一律に増益へつながるとは限らない。先週ETF+3.01%、正GEXで現値50.92はPut Wall50の上。来週19日のSteel Dynamics、22日のNewmontで出荷量、金属マージン、採掘コストを確認する。製造業の需要とインフレ対応の分散枠として小幅に保ち、50を割れば見直す。[Alcoa決算](https://investors.alcoa.com/press-releases/press-release-details/2026/Alcoa-Corporation-Reports-Third-Quarter-2026-Results/default.aspx) / [STLD公式日程](https://ir.steeldynamics.com/steel-dynamics-announces-third-quarter-2026-earnings-conference-call-and-webcast/) / [Newmont公式日程](https://investors.newmont.com/investors/news-release/news-details/2026/Newmont-Announces-Third-Quarter-2026-Results-Conference-Call/default.aspx)
- **XLRE 0.95%、ほぼ基準並み。** PrologisのCore FFOは1株1.60ドルと前年1.49ドルから増え、現金同一物件NOIは+5.9%。先週ETF+1.32%と金利低下も支えになった。来週19日のNAHB、20日の住宅着工・中古住宅成約で需要を確認する。ただし住宅統計は物流REITの需要そのものではなく、資金調達環境の補助指標。現値42.16はFlip42.44の直下、GEXも負で、50日平均42.89の回復前は大きく増やさない。[Prologis決算](https://ir.prologis.com/news-events/press-releases/detail/1055/prologis-reports-third-quarter-2026-results) / [Census日程](https://www.census.gov/economic-indicators/calendar-listview.html) / [経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)
- **XLU 3.04%、Overweight拡大。** 先週ETF+1.93%、公益生産+3.5%と金利低下が確認された。ただし一か月の生産増をそのままAI電力需要の恒久成長とは見なさない。来週21日のNextEraで電力販売、受注残、資本支出、資金調達費を確認する。正GEXと現値42.21のCall Wall42超えを評価するが、燃料費上昇やBEI反発で金利が戻れば逆風。決算後42を維持するかが追加増額の確認点。[Fed公益生産](https://www.federalreserve.gov/releases/g17/20261016/) / [NextEra公式日程](https://newsroom.nexteraenergy.com/2026-10-07-NextEra-Energy-announces-date-for-release-of-third-quarter-2026-financial-results)

## 来週の日別イベントと配分判断

企業日程は上記IR、経済日程は[Census](https://www.census.gov/economic-indicators/calendar-listview.html)、[NAR](https://www.nar.realtor/press-releases/nar-releases-2026-statistical-news-release-schedule)、[ミシガン大学](https://www.sca.isr.umich.edu/)、[10月19–23日の経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)を確認した。来週はCPIの再発表ではなく、企業の費用見通しとPMI・消費者のインフレ期待が焦点。

| 日付 | 主な予定 | 配分への接続 |
|---|---|---|
| 10/19 月 | 10:00 NAHB、引け後Steel Dynamics | XLRE・XLBの需要。新配分への差分半分を第一段階とする |
| 10/20 火 | 8:30住宅着工、10:00中古住宅成約、GE Aerospace、引け後Netflix | XLIの受注・採算、XLCの広告/動画収益、XLREの資金調達環境 |
| 10/21 水 | NextEra・Philip Morris・Danaher、引け後Meta・Tesla・IBM | XLU・XLP・XLVの増額妥当性と、XLC・XLY・XLKの決算後反応を確認 |
| 10/22 木 | 8:30失業保険、10:00景気先行指数、P&G、引け後Newmont | XLPの数量/採算、XLBのコスト、IEFの景気ヘッジを再評価 |
| 10/23 金 | 9:45製造業/サービスPMI速報、10:00消費者心理確報、AXP・SLB | 物価と新規受注、家計支出・信用、エネルギー設備投資。残り半分の実施可否を判断 |

## オプション監視水準とVanna Charm

下表の7日1σは既存モデルの近傍ATM IVから7暦日へ換算した`expected_low/high`。固定満期7日IVの補間値とは異なる。週末取得の建玉・IVに基づく研究値で、将来価格や損失上限を表さない。[不変のオプション表](../../data/processed/20261016/v2/SGV2-20261019/20261018T124205833941Z/option_signal_snapshot.csv) / [7日変動幅の計算表](../../data/processed/20261018/consistent_option_metrics.parquet)

| 資産 | 終値 | GEX符号 | Gamma Flip | Call / Put Wall | 7日1σ |
|---|---:|:---:|---:|---:|---:|
| XLK | 183.47 | − | 201.24 | 200 / 170 | 174.91–192.03 |
| XLY | 112.46 | − | 未確認* | 115 / 107.5 | 106.23–118.69 |
| XLP | 87.62 | − | 未確認* | 90 / 80 | 84.79–90.45 |
| XLE | 68.24 | + | 63.88 | 70 / 60 | 64.95–71.53 |
| XLF | 55.52 | − | 56.95 | 56 / 54 | 53.88–57.16 |
| XLV | 176.71 | + | 167.48 | 175 / 160 | 169.37–184.05 |
| XLI | 167.76 | − | 186.31 | 180 / 160 | 160.20–175.32 |
| XLC | 110.32 | − | 114.42 | 115 / 110 | 104.11–116.53 |
| XLB | 50.92 | + | 48.50 | 60 / 50 | 48.05–53.79 |
| XLRE | 42.16 | − | 42.44 | 41 / 41 | 40.96–43.36 |
| XLU | 42.21 | + | 39.50 | 42 / 40 | 40.94–43.48 |
| IEF | 90.42 | + | 89.33 | 91 / 89 | 89.36–91.48 |

*XLY・XLPは現値の80–120%グリッド内でGEXのゼロ交差がない。保存された134.95・105.14は絶対GEX最小点の近似であり、実在する反転水準として使わない。他の10資産はグリッドの符号交差を再確認した。固定満期7日IVが両側の満期で挟まれるのはXLE・XLF・IEFの3資産で、残る9資産の固定7日値は近傍満期による参考値である。

IEFのVanna/Charm絶対集中比は62.1%/81.2%と高い。Call Wall91は7日レンジ内であり、金利イベント後のIV低下と時間経過でヘッジ感応度が変わりやすい。XLFは29.2%/44.9%、XLUは18.8%/47.3%。集中比や符号だけで買い・売りフローを断定せず、価格がFlip・Wallを維持するかと合わせて見る。Call正・Put負のGEXは建玉由来のプロキシであり、実際のディーラー保有を観測したものではない。

## 来週の条件付きシナリオ

- **基本**：物価圧力は残り、技術株の評価修正が続く。第一段階59.40/40.60から、決算後に最終58.56/41.44を検討。XLV・XLUを防御、XLEを供給インフレの分散枠にする。
- **業績で反発**：Meta・Tesla・IBMなどの利益率/FCFが改善し、XLCが114.42–115、XLKがまず50日平均189.80を回復。残りの削減を急がず、オプションを更新して再計算する。好決算だけで旧XLK25.40%へ戻さない。
- **再インフレ**：PMI価格や消費者の期待が上昇し、BEI2.40%以上、名目金利反発、IEF89.33割れが重なる。IEF追加を停止して40%への調整を再検討し、XLRE/XLUの金利リスクも点検する。XLEだけで株債同時下落を十分に相殺できるとは限らない。
- **成長失速**：新規受注・雇用・カード信用が悪化し、金利は下がるが信用スプレッドがさらに広がる。IEFは価格維持を確認して増額し、XLF・XLY・XLIのUWを継続する。

## データと検証

[実行済みNotebook](../executed/main_20261018_executed.ipynb)を上から実行し、[10月18日の12資産ダッシュボード](../dashboard/sector_gamma_dashboard_v2_SGV2-20261019_20261018T124205833941Z.html)、raw/processed、CSV/parquetを更新した。[保存ラン](../../data/processed/20261016/v2/SGV2-20261019/20261018T124205833941Z/)は価格カットオフ10月16日、次の取引日10月19日。Notebook例外0、12チェーン非空、形式検証815件PASS。7日IV中央値は前回約1.1%から38.7%へ戻り、前回の全体的な異常低下は今回は見られない。満期補間と近似Flipの制限は上記のとおり残る。

金利・実質金利の最新FRED観測日は15日、BEIは16日。価格と取得日を混同しない。前週の寄与度は旧モデルの`tactical_portfolio_weight`を流用せず、前回採用したv2目標と保存済み基準を明示的に結合した。新目標、基準、Active、変更幅は[週報CSV](../tables/weekly_review_20261018.csv)と照合した。更新前のNotebook・HTML・CSV・前回週報は[バックアップ](../backups/20261018_weekly_update/)に保存した。

外部参照は当局統計・企業IRを中心とし、市場報道を補助に用いた。確認時点でLPLの10月16日版は取得できず、10月9日版を今回週の実績根拠へ転用していない。参照した決算カレンダーの一部も前週表示だったため、来週の主要日程は企業の公表で確認した。
