# 決算戦略論文分析

**User:** Anonymous  
**Created:** 6/26/2026 0:19:38  
**Updated:** 6/26/2026 7:27:49  
**Exported:** 6/26/2026 7:46:06  
**Link:** [https://chatgpt.com/c/6a3d4709-5b8c-83ee-8919-d97de4f708fb](https://chatgpt.com/c/6a3d4709-5b8c-83ee-8919-d97de4f708fb)  

## Response:
2026/6/26 0:19:38

> **Searching for academic citations and references**
>
> [Earnings Extrapolation And Predictable Stock Market Returns](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3480863)
> [THE Co. Ltd.](https://the-web.co.jp/?srsltid=AfmBOoowCD9-86Ik71vINfNPIj8C0fpDErhLm_msWkaYqGTYWUfrTzFh)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://academic.oup.com/rfs/article/38/6/1730/8101501)
> [Hongye Guo - Research](https://sites.google.com/view/hongyeguo/research)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://ideas.repec.org/a/oup/rfinst/v38y2025i6p1730-1782..html)
> [Correlation neglect in asset prices](https://afajof.org/management/viewp.php?n=168756)
> [EARNINGS EXTRAPOLATION AND PREDICTABLE STOCK ...](https://fnce.wharton.upenn.edu/wp-content/uploads/2022/07/Paper4_Guo.pdf)
> [Correlation Neglect in Asset Prices: New Research on ...](https://www.linkedin.com/posts/whartonfinance_correlationneglect-quantfinance-financewebinar-activity-7467218855665500160-bijx)
> [Hongye Guo](https://scholar.google.com/citations?hl=en&user=pBiNV-wAAAAJ)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://hub.hku.hk/handle/10722/356538)
> [Correlation neglect in asset prices](https://www.researchgate.net/publication/392329757_Correlation_neglect_in_asset_prices)
> [【例文付き】冠詞「a」と「the」の違いと特徴を分かりやすく ...](https://online.ecc.co.jp/column/a-the-difference/)
> [The Information Cliff](https://osf.io/download/bf8cx/)
> [英語の「the」の意味とは？付けるor付けないを判断するポイント ...](https://h-full.co.jp/fullstudy/english-the/)
> [earnings extrapolation and predictable stock market returns](https://www.semanticscholar.org/paper/EARNINGS-EXTRAPOLATION-AND-PREDICTABLE-STOCK-MARKET-Guo/e658f07284e2e5d97b2ebff644534090413e51b4)
> [Working Paper Series - Jacobs Levy Equity Management ...](https://jacobslevycenter.wharton.upenn.edu/research-papers/working-paper-series/)
> [「the」をつけるルールとは？冠詞「the」の判断ルールを完全 ...](https://qqenglish.jp/the/)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://discovery.researcher.life/article/earnings-extrapolation-and-predictable-stock-market-returns/156ee8fd829c359bb479d148138fec13)
> [英語 文法 「その～」の表し方 (the)：解説](https://www.coelang.tufs.ac.jp/mt/en/gmod/contents/explanation/024.html)
> [China International Conference in Finance 2026 (CICF)](https://www.evolkova.info/uploads/conferences/2026/cicf.pdf)
> [THE（ザ）商品一覧（洗濯用品など）](https://mall.kinarino.jp/brand-213)
> [Theをつけるのはどんな時ですか。 - Yahoo!知恵袋](https://detail.chiebukuro.yahoo.co.jp/qa/question_detail/q13298416078)
>
> **特定の文献を引用した論文の検索**
>
> [Earnings Extrapolation And Predictable Stock Market Returns](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3480863)
> [Hongye Guo - Research](https://sites.google.com/view/hongyeguo/research)
> [THE Co. Ltd.](https://the-web.co.jp/?srsltid=AfmBOorQS6VCmTIppZO6XZFym8UnarFS4FYJvttsuPWgjyNRgNGRhfH2)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://ideas.repec.org/a/oup/rfinst/v38y2025i6p1730-1782..html)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://academic.oup.com/rfs/article/38/6/1730/8101501)
> [Correlation neglect in asset prices](https://afajof.org/management/viewp.php?n=168756)
> [EARNINGS EXTRAPOLATION AND PREDICTABLE STOCK ...](https://fnce.wharton.upenn.edu/wp-content/uploads/2022/07/Paper4_Guo.pdf)
> [Correlation Neglect in Asset Prices: New Research on ...](https://www.linkedin.com/posts/whartonfinance_correlationneglect-quantfinance-financewebinar-activity-7467218855665500160-bijx)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://www.researchgate.net/publication/390359252_Earnings_Extrapolation_and_Predictable_Stock_Market_Returns)
> [earnings extrapolation and predictable stock market returns](https://www.semanticscholar.org/paper/EARNINGS-EXTRAPOLATION-AND-PREDICTABLE-STOCK-MARKET-Guo/e658f07284e2e5d97b2ebff644534090413e51b4)
> [Hongye Guo](https://scholar.google.com/citations?hl=en&user=pBiNV-wAAAAJ)
> [【例文付き】冠詞「a」と「the」の違いと特徴を分かりやすく ...](https://online.ecc.co.jp/column/a-the-difference/)
> [An NLP Study on r/WallStreetBets](https://search.proquest.com/openview/eb9bca4f565f3fcd2daaf0fcdd6ee6c3/1?cbl=18750&diss=y&pq-origsite=gscholar)
> [Working Paper Series - Jacobs Levy Equity Management ...](https://jacobslevycenter.wharton.upenn.edu/research-papers/working-paper-series/)
> [英語の「the」の意味とは？付けるor付けないを判断するポイント ...](https://h-full.co.jp/fullstudy/english-the/)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://discovery.researcher.life/article/earnings-extrapolation-and-predictable-stock-market-returns/156ee8fd829c359bb479d148138fec13)
> [The Information Cliff](https://osf.io/download/bf8cx/)
> [Theをつけるのはどんな時ですか。 - Yahoo!知恵袋](https://detail.chiebukuro.yahoo.co.jp/qa/question_detail/q13298416078)
> [Earnings Extrapolation And Predictable Stock Market Returns](https://repository.upenn.edu/entities/publication/cdff3e53-c67d-47b2-8321-3268a22d609f)
> [What Can Survey Forecasts Tell Us about Information ...](https://www.journals.uchicago.edu/doi/abs/10.1086/665662)
> [Asset Price Dynamics with Value-at-Risk Constrained ...](https://www.fmg.ac.uk/publications/discussion-papers/asset-price-dynamics-value-risk-constrained-traders)
> [「the」をつけるルールとは？冠詞「the」の判断ルールを完全 ...](https://qqenglish.jp/the/)
> [英語 文法 「その～」の表し方 (the)：解説](https://www.coelang.tufs.ac.jp/mt/en/gmod/contents/explanation/024.html)
>
> **探索したい引用の文献を整理**
>
> ウェブをもっと体系的に調べる必要がありそうです。Google Scholarのスニペットが十分かもしれません。ユーザーは「引用している情報も必要に応じて探索」と言っているので、直接的な関係を識別するには、引用ネットワークの戦略とともに有用な文献を見つけるのが焦点かもしれません。
>
> **Searching for citations of Frazzini 2006 paper**
>
> [The Disposition Effect and Underreaction to News - FRAZZINI](https://onlinelibrary.wiley.com/doi/10.1111/j.1540-6261.2006.00896.x)
> [THE Co. Ltd.](https://the-web.co.jp/?srsltid=AfmBOooZSUV_6q-Uc3x8BhPKVW2R2Ye5BPxHAtJLGfyKzCS4H70hYcst)
> [The Disposition Effect and Underreaction to News](https://ideas.repec.org/a/bla/jfinan/v61y2006i4p2017-2046.html)
> [The Disposition Effect and the Under-Reaction to News](https://www.aqr.com/Insights/Research/Journal-Article/The-Disposition-Effect-and-the-UnderReaction-to-News)
> [The Disposition Effect and Under-Reaction to News](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=761026)
> [Frazzini JF（2006）The Disposition Effect and ...](https://e-learning.uibe.edu.cn/meol/common/script/preview/download_preview.jsp?fileid=89500&lid=13638&preview=preview&resid=39381)
> [Disposition effect and investor underreaction to information](https://www.researchgate.net/publication/303544516_Disposition_effect_and_investor_underreaction_to_information)
> [【例文付き】冠詞「a」と「the」の違いと特徴を分かりやすく ...](https://online.ecc.co.jp/column/a-the-difference/)
> [Frazzini, A. (2006). The Disposition Effect and ...](https://www.scirp.org/reference/referencespapers?referenceid=2719848)
> [英語の「the」の意味とは？付けるor付けないを判断するポイント ...](https://h-full.co.jp/fullstudy/english-the/)
> [The Disposition Effect and Underreaction to News](https://cir.nii.ac.jp/crid/1360021396334971136)
> [「the」をつけるルールとは？冠詞「the」の判断ルールを完全 ...](https://qqenglish.jp/the/)
> [Debiasing the disposition effect by reducing the saliency of ...](https://pmc.ncbi.nlm.nih.gov/articles/PMC4357845/)
> [英語 文法 「その～」の表し方 (the)：解説](https://www.coelang.tufs.ac.jp/mt/en/gmod/contents/explanation/024.html)
> [Theをつけるのはどんな時ですか。 - Yahoo!知恵袋](https://detail.chiebukuro.yahoo.co.jp/qa/question_detail/q13298416078)
>
> **調査と引用探索の実施**
>
> [Earnings Extrapolation And Predictable Stock Market Returns by Hongye Guo :: SSRN](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3480863)
> [The Disposition Effect and Underreaction to News](https://ideas.repec.org/a/bla/jfinan/v61y2006i4p2017-2046.html)
>
> **SSR検索とRePEcによる被引用リスト確認**
>
> [Citations of The Disposition Effect and Underreaction to News](https://ideas.repec.org/r/bla/jfinan/v61y2006i4p2017-2046.html)
>
> **引用論文の検索と関連文献の特定**
>
> Guo 2025と「Correlation neglect」を引用した実際の論文を探す必要がありそうです。正確なタイトルで新しい引用文献を検索して、関連性の高いものを見つけます。特に、「The Information Cliff」や「Same-weekday momentum」などは引用していないかもしれませんが、正確に調べてみます。
>
> **Searching for recent citations of specific papers**
>
> [Pre-Earnings Announcement Over-Extrapolation](https://mendoza.nd.edu/wp-content/uploads/2019/01/2016_spring_finance_seminar_series_peter_kelly_paper_updated_3_22_2016.pdf)
> [Earnings Extrapolation And Predictable Stock Market Returns](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3480863)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://academic.oup.com/rfs/article/38/6/1730/8101501)
> [Stern Finance Sem.: "Correlation neglect in asset prices"](https://as.nyu.edu/departments/econ/events/spring-2026/stern-finance/wednesday/Wachter.html)
> [Diagnostic Expectations and Stock Returns](https://didattica.unibocconi.it/mypage/upload/154156_20170919_051604_DIAG_STOCKS_BGLS_NBER.PDF)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://www.researchgate.net/publication/390359252_Earnings_Extrapolation_and_Predictable_Stock_Market_Returns)
> [Correlation Neglect: Challenging the Unpredictability of ...](https://finance-pillar.wharton.upenn.edu/blog/correlation-neglect-asset-prices/)
> [What Does ChatGPT Make of Historical Stock Returns? ...](https://www.aeaweb.org/conference/2026/program/paper/zNrQ4Yn6)
> [earnings extrapolation and predictable stock market returns](https://www.semanticscholar.org/paper/EARNINGS-EXTRAPOLATION-AND-PREDICTABLE-STOCK-MARKET-Guo/e658f07284e2e5d97b2ebff644534090413e51b4)
> [Correlation neglect in asset prices](https://afajof.org/management/viewp.php?n=168756)
> [Earnings Extrapolation and Predictable Stock Market Returns](https://discovery.researcher.life/article/earnings-extrapolation-and-predictable-stock-market-returns/156ee8fd829c359bb479d148138fec13)
> [Correlation neglect in asset prices](https://www.fmg.ac.uk/seminars/correlation-neglect-asset-prices)
> [Earnings Quality and Stock Returns*](https://www.jstor.org/stable/10.1086/500669)
> [Hongye Guo - Research](https://sites.google.com/view/hongyeguo/research)
> [Impact of Earnings Smoothness on Stock Prices, ...](https://efaj.actavia.vse.cz/pdfs/efa/2014/03/04.pdf)
> [Correlation Neglect in Asset Prices: New Research on ...](https://www.linkedin.com/posts/whartonfinance_correlationneglect-quantfinance-financewebinar-activity-7467218855665500160-bijx)
> [Price-Path Convexity and Short-Horizon Return Predictability](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/02CDE05B2C35A6D8E7581851B690F35D/S0022109025101725a.pdf/pricepath_convexity_and_shorthorizon_return_predictability.pdf)
> [Man vs. Machine Learning](https://www.nber.org/system/files/working_papers/w27843/w27843.pdf)
> [Webinar: Correlation Neglect in Asset Prices](https://jacobslevycenter.wharton.upenn.edu/webinarspring26/)
> [Streaks in Earnings Surprises and the Cross-Section of ...](https://ink.library.smu.edu.sg/cgi/viewcontent.cgi?article=4203&context=lkcsb_research)
>
> **調査：Guo 2025および関連引用の情報**
>
> [JFQ_2510172 580..611](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/02CDE05B2C35A6D8E7581851B690F35D/S0022109025101725a.pdf/pricepath_convexity_and_shorthorizon_return_predictability.pdf)
> [Correlation neglect in asset prices | Financial Markets Group](https://www.fmg.ac.uk/seminars/correlation-neglect-asset-prices)
> [www.aeaweb.org](https://www.aeaweb.org/conference/2026/program/paper/zNrQ4Yn6)
>
> **検索と文献レビューの計画**
>
> [academic.oup.com](https://academic.oup.com/rfs/article/38/6/1730/8101501)
>
> **整理した分析とモデル調整案**
>
> Frazziniの信号はモメンタムやPEAD、キャピタルゲインのオーバーハングと重複する可能性があります。過去のリターンや規模、回転率を除去してから扱う必要がありそうです。個別株の信号は産業固有の要素として組み込むべきですね。
>
> **Searching recent replications of capital gains overhang**
>
> [Citations of The Disposition Effect and Underreaction to News](https://ideas.repec.org/r/bla/jfinan/v61y2006i4p2017-2046.html)
>
> **検索して主要な資料を確認**
>
> [Extrapolative Bubbles and Trading Volume - Oxford Academic](https://academic.oup.com/rfs/article-pdf/35/4/1682/42970048/hhab070.pdf)
> [Earnings Autocorrelation and the Post- ...](https://www.cambridge.org/core/journals/journal-of-financial-and-quantitative-analysis/article/earnings-autocorrelation-and-the-postearningsannouncement-drift-experimental-evidence/61CD6A2065A4686418A3C47DEF3AC24B)
>
> **フォローアップ文献の整理と検索**
>
> RePEc/CitEcの275件は参考にしつつ、Google/SSRNなどのデータベース依存で異なる引用数になるので、あまり重要ではないかもしれません。次に挙げた文献を正確に説明し、必要な場合は元のソース（タイトルや概要）を検索して確認します。
>
> **ストレステストの実施とインタラクション分析**
>
> 公開日が2025年以降だと短期間の履歴しか得られず不可能なので、他条件としてターンオーバーやスリッページを考慮。ストレステストでは、四半期のタイミングやニュースの影響をチェック。信号の対立が発生する月やタイミングの相互作用も確認。
>
> **公開後の証拠と発表遅延の考慮**
>
> 2025年や2026年の論文は公開後の証拠が限られているので注意が必要です。発表スケジュールの遅延も考慮に入れてリスクを管理したいですね。Frazzini やGuo-Wachterの研究など、引用基盤がまだ薄いものについては、発表やプレゼンテーションに注目します。
>
> **Searching abstracts for key citation sources**
>
> [Disposition Sales and Stock Market Liquidity by Darwin Choi](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1885298)
> [Overselling winners and losers: How mutual fund ...](https://ideas.repec.org/a/eee/finmar/v55y2021ics1386418120300495.html)
> [What Drives the Disposition Effect? An Analysis of a Long ...](https://wxiong.mycpanel.princeton.edu/papers/disposition.pdf)
> [Li AN - Research](https://sites.google.com/site/lianfinancesite/research)
> [A Study of Disposition Effect among China's Individual ...](https://www.jryj.org.cn/EN/abstract/abstract713.shtml)
> [‪Bronson Argyle‬ - ‪Google Scholar‬](https://scholar.google.co.il/citations?hl=th&user=c1Y2LdcAAAAJ)
> [Realization Utility Nicholas C. Barberis and Wei Xiong ...](https://www.nber.org/system/files/working_papers/w14440/revisions/w14440.rev0.pdf)
> [What Drives the Disposition Effect? An Analysis of a Long‐ ...](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1540-6261.2009.01448.x)
> [Market-wide impact of the disposition effect - Trading](https://www.researchgate.net/publication/222689089_Market-wide_impact_of_the_disposition_effect_Evidence_from_IPO_trading_volume)
> [[PDF] Professional trader discipline and trade disposition](https://www.semanticscholar.org/paper/Professional-trader-discipline-and-trade-Locke-Mann/90598d6513e50dec74fce36d282fee0a93e933bf)
> [How mutual fund managers' trading behavior affects asset prices](https://eng.pbcsf.tsinghua.edu.cn/__local/1/F1/95/EE831A4231515AB0E2A98DBEA79_68D1C346_8AA47.pdf?e=.pdf)
> [Summary of: “REALIZATION UTILITY” (Authors](https://nicholasbarberis.github.io/ru_nonac.pdf)
> [Discussion Papers In Economics And Business](https://www2.econ.osaka-u.ac.jp/econ_society/dp/1302R2.pdf)
> [Fund manager skill: selling matters more!](https://ouci.dntb.gov.ua/en/works/9jqMRepl/)
> [Dynamic Trading with Realization Utility](https://english.ckgsb.edu.cn/wp-content/uploads/2022/08/RealizationUtility-JF-forthcoming-posting.pdf)
> [The Value of (Stock) Liquidity in the M&A Market](https://www.cambridge.org/core/journals/journal-of-financial-and-quantitative-analysis/article/value-of-stock-liquidity-in-the-ma-market/8CF3F82E07AF0E9296F74D41AA1FBECC)
> [Does Disposition Effect Appear on Investor Decision During ...](https://koreascience.kr/article/JAKO202208951456721.pub?lang=en&orgId=kodisa)
> [Dynamic Trading with Realization Utility](https://business.columbia.edu/sites/default/files-efs/citation_file_upload/Dai_Qin_Wang_RealizationUtility-JF-forthcoming.pdf)
> [Probability Weighting, Stop-Loss and the Disposition Effect.](https://discovery.ucl.ac.uk/id/eprint/10137459/1/JET_ProbWeighting.pdf)
>
> **モデルと残差化の重要性**
>
> 比較行列を作成する必要がありますね。7列くらいのマトリックスだと少し広くなるかもしれませんが、ユーザーは専門家なので問題ないと思います。ただ、システムが密なテーブルを避けるように言っているので、コンパクトにまとめる方法を考えます。
>
> **最適化モデルと重みの決定**
>
> 70/30の比率を指定しない方がいいかも。代わりに共分散を考慮した最適化を使うのが良いかもね。これを使うことでマーケットベータやセクター、取引制約を適用できる。さらに、イベントごとの重みが月ごとの強化される効果を反映させるのも重要だね。
>
> **検証結果と金融戦略**
>
> Frazziniの古いコスト予測は適用できません。新しいデータや手法検
>
> **提案された戦略とデータ分析の調査**
>
>
> **情報の検索**
>
> 「The Information Cliff」というタイトルで検索するのが良さそう。これで必要な情報をより正確に見つけられそうだね。タイトルをそのまま使うことで関連性の高い結果を得られると思うから、試してみる価値がありそう！
>
> **検索: 「The Information Cliff」に関する情報**
>
> [The Information Cliff](https://osf.io/download/bf8cx/)
> [Ralph Koijen](https://ideas.repec.org/f/c/pko589.html)
>
> **PDFの読み込みガイド**
>
> ユーザーはPDFの分析を求めており、作成や編集を要求していないようですね。このPDF関連のタスクには「読み込み」と言われているので、システムで提供されているツールを利用するために、PDF読み込みスキルを確認する必要がありそうです。
>
> **Reading PDF skill documentation**
>
>
> **未来月の市場動向について**
>
> 投資家は、現在のニュースを未来のニュースのある月に過大に予測し、逆にニュースの少ない月には過小に予測しがちです。このため、未来の反転や継続が生まれます。特に、ニュースが繰り返される2ヶ月目には、過剰反応が起きます。
>
> **調査と文献引用のサポート**
>
>
> **検索中：論文の要約テキスト**
>
> [What Drives the Disposition Effect? An Analysis of a Long ...](https://wxiong.mycpanel.princeton.edu/papers/disposition.pdf)
> [What Drives the Disposition Effect? An Analysis of a Long‐ ...](https://ideas.repec.org/a/bla/jfinan/v64y2009i2p751-784.html)
> [A Study of Disposition Effect among China's Individual ...](https://www.jryj.org.cn/EN/abstract/abstract713.shtml)
> [Realization Utility Nicholas C. Barberis and Wei Xiong ...](https://www.nber.org/system/files/working_papers/w14440/revisions/w14440.rev0.pdf)
> [Discussion Papers In Economics And Business](https://www2.econ.osaka-u.ac.jp/econ_society/dp/1302R2.pdf)
> [Debiasing the disposition effect by reducing the saliency of ...](https://pmc.ncbi.nlm.nih.gov/articles/PMC4357845/)
> [What Drives the Disposition Effect? An Analysis of a Long- ...](https://www.researchgate.net/publication/46538110_What_Drives_the_Disposition_Effect_An_Analysis_of_a_Long-Standing_Preference-Based_Explanation)
> [Probability Weighting, Stop-Loss and the Disposition Effect.](https://discovery.ucl.ac.uk/id/eprint/10137459/1/JET_ProbWeighting.pdf)
> [Prospect Theory and the Disposition Effect](https://www.aalto.fi/sites/default/files/2018-12/prospect_theory_and_disposition_effect.pdf)
> [Implications of Prospect Theory for Asset Prices and Trading ...](https://individual.utoronto.ca/liyanyang/jobmktpaper.pdf)
> [What Drives the Disposition Effect? An Analysis of a Long‐ ...](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1540-6261.2009.01448.x)
> [Disposition effect](https://en.wikipedia.org/wiki/Disposition_effect)
> [Efecto de disposición](https://es.wikipedia.org/wiki/Efecto_de_disposici%C3%B3n)
> [Effetto di disposizione](https://it.wikipedia.org/wiki/Effetto_di_disposizione)
>
> 思考時間: 10m 15s

## 結論

3本は競合する説明ではなく、異なる階層の収益予測を扱っています。

- **Guo**：市場・業種の「決算サイクル・レジーム」
- **Guo-Wachter**：同一四半期情報の「二重計上」による継続と反転
- **Frazzini**：個別銘柄の保有者原価に起因する決算後ドリフト

個別銘柄戦略では、前2本を**市場・業種共通成分のタイミングモデル**、Frazziniを**個別銘柄固有成分の選択モデル**として使うのが最も整合的です。単純に3シグナルを加算すると、同じ決算イベントに対して「固有成分は継続、共通成分は将来反転」という反対方向の予測を相殺してしまいます。`Paper4_Guo.pdf` `ssrn-5268329.pdf` `The Disposition Effect and Underreaction to news - Frazzini.pdf`

---

# 1. Guo, *Earnings Extrapolation and Predictable Stock Market Returns*

添付版は2021年の草稿ですが、中核的結果は2025年に *Review of Financial Studies* に掲載されています。`Paper4_Guo.pdf` ([OUP Academic](https://academic.oup.com/rfs/article/38/6/1730/8101501))

## 1.1 基本的な実証結果

米国について、

$$
N=\{\text{Jan, Apr, Jul, Oct}\}
$$

を四半期第1月、すなわち **newsy month** とします。これは前四半期の決算が最初に集中的に公表される月です。

$N(t,j)$を時点 $t$ より前の第 $j$ 番目の newsy month とし、

$$
S_t^{PC}=\sum_{j=1}^{4}r_{N(t,j)}
$$

を直近4回の newsy month の累積市場リターンとします。主要回帰式は

$$
r_t
=
\alpha+\beta S_t^{PC}
+\gamma S_t^{PC}I_t^N
+\delta I_t^N+\varepsilon_t,
$$

です。ここで $I_t^N=1$ は予測対象月が newsy month であることを示します。

したがって予測係数は、

$$
\frac{\partial E_t[r_t]}{\partial S_t^{PC}}
=
\begin{cases}
\beta,&t\notin N,\\
\beta+\gamma,&t\in N.
\end{cases}
$$

添付版のTable 4では、

$$
\beta=0.129,\qquad
\gamma=-0.232,
$$

なので、

$$
\beta+\gamma=-0.103.
$$

つまり、過去の決算シーズンで市場が上昇していた場合、

- 第2・第3月ではリターンが**継続**
- 次の第1月ではリターンが**反転**

します。両者を無条件で平均すると相殺されるため、通常の自己相関は小さく見えます。`Paper4_Guo.pdf`

## 1.2 経済メカニズム：パラメータ圧縮

投資家は過去の利益を用いて将来利益を予測します。過去のキャッシュフロー成長の状態変数を

$$
x_t=\sum_{j=0}^{\infty}\delta^j\Delta d_{t-j}
$$

とし、投資家が

$$
\Delta d_{t+1}=m x_t+u_{t+1}
$$

と考えているとします。

しかし真の過程は月によって異なり、

$$
\Delta d_{t+1}
=
\kappa_t x_t+u_{t+1},
\qquad
\kappa_t=
\begin{cases}
h,&\text{利益の持続性が高い月},\\
l,&\text{利益の持続性が低い月},
\end{cases}
$$

かつ

$$
l<m<h
$$

です。

投資家は本来使うべき $l,h$ を区別せず、代表的な平均値 $m$ に圧縮しています。したがって利益予想誤差は

$$
FE_{t+1}
=
\Delta d_{t+1}-E_t[\Delta d_{t+1}]
=
(\kappa_t-m)x_t+u_{t+1}.
$$

- 非newsy月では $h-m>0$：過去の良い利益を十分に織り込まず、正のサプライズ
- newsy月では $l-m<0$：過去の良い利益を過大に外挿し、負のサプライズ

となります。

論文の株式ストリップ価格は

$$
\frac{P_{n,t}}{D_t}
=
\exp(a_n+b_nx_t+c_n\Delta d_t)
$$

と表され、

$$
c_n=-\rho,
\qquad
b_n=
\frac{1-(m+\delta)^n}{1-m-\delta}
m(1-\rho)>0.
$$

実現リターンは

$$
\begin{aligned}
\log(1+R_{n,t+1})
=&\;a_{n-1}-a_n\\
&+(\kappa_t-m)
\bigl(b_{n-1}+1-\rho\bigr)x_t\\
&+\bigl(b_{n-1}+1-\rho\bigr)u_{t+1}.
\end{aligned}
$$

したがって予測可能部分の符号は

$$
\operatorname{sgn}E_t[R_{n,t+1}]
=
\operatorname{sgn}\bigl((\kappa_t-m)x_t\bigr)
$$

で決まります。これが継続と反転を一つのメカニズムで生成します。`Paper4_Guo.pdf`

## 1.3 なぜ第1月の利益持続性が低いのか

第1月の企業は、前回とは異なる新しい会計四半期の利益を報告します。したがって過去利益との「財務時間上の距離」が離れています。

一方、第2・第3月の企業は、第1月の企業と同じ会計四半期について報告することが多いため、業種・マクロ共通利益との相関が高くなります。この離散的な持続性低下を投資家が滑らかな減衰だと誤認する、という説明です。

論文はこれを以下で検証しています。

- 月次集計ROEの自己相関は newsy month で有意に低い
- I/B/E/S予想誤差にも同様の周期性がある
- 四半期最初の5営業日には反転がなく、決算発表が始まってから反転する
- キャッシュフロー連結性の高い業種ほど効果が強い
- 架空のランダム業種では効果が消える
- 国・国×業種にも類似パターンがある

掲載版ではリアルタイム推定による月次市場リターン予測のOOS $R^2$ が概ね3.6～4.3%と報告されています。`Paper4_Guo.pdf` ([OUP Academic](https://academic.oup.com/rfs/article/38/6/1730/8101501))

## 1.4 個別銘柄への含意

この効果は個別株にも見えますが、論文自身が指摘するように、基本的には**業種成分を通じた効果**です。

したがって、これは個別株選択シグナルというより、

$$
\beta_{i,M}\hat r_{M,t}
+
\beta_{i,G}\hat r_{G,t}
$$

という市場・業種ベータ部分の期待リターンを予測するモデルとして使うべきです。

---

# 2. Guo and Wachter, *Correlation Neglect in Asset Prices*

これは現在ワーキングペーパーです。公開版は2025年にSSRNへ掲載され、添付資料は2026年2月版です。`ssrn-5268329.pdf` ([SSRN](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5268329))

## 2.1 第1月→第2月→次の第1月

この論文は四半期の月を次のように分類します。

- 第1月：newsy month $N$
- 第2月：repetitive month $R$
- 第3月：発表数が少ないため基本回帰から除外

$nr(t)$を、予測対象月 $t$ より前の最も近い $N$ または $R$ とすると、

$$
r_t=\alpha+\beta r_{nr(t)}+\varepsilon_t
$$

を推定します。

結果は、

$$
\beta_R=+0.279
$$

で第1月リターンが第2月リターンを正に予測し、

$$
\beta_N=-0.279
$$

で第2月リターンが次四半期の第1月リターンを負に予測します。

統合回帰では

$$
r_t
=
\alpha+\beta_1r_{nr(t)}
+\beta_2r_{nr(t)}I_t^N
+\gamma I_t^N+\varepsilon_t,
$$

で、

$$
\beta_2=-0.557.
$$

つまり月次自己相関が、

$$
N_q \longrightarrow R_q:\quad \text{継続}
$$

$$
R_q \longrightarrow N_{q+1}:\quad \text{反転}
$$

と交互に変わります。`ssrn-5268329.pdf`

## 2.2 モデル：同じ情報を独立情報として数える

経済の良好状態の確率を $p$ とし、投資家は $p$ についてBeta事前分布を持つとします。論文の正規化では、事前価格は

$$
P_0=\frac{p^*+1}{3}.
$$

第1月に

$$
s_1\sim\operatorname{Bernoulli}(p)
$$

というシグナルを観測すると、

$$
P_1=\frac{s_1+p^*+1}{4}.
$$

第2月の観測シグナルは、

$$
\hat s_2=
\begin{cases}
s_1,&x=1,\\
s_2,&x=0,
\end{cases}
\qquad
x\sim\operatorname{Bernoulli}(p_x).
$$

つまり、確率 $p_x$ で第1月の情報が事実上反復され、確率 $1-p_x$ で新しい独立情報が来ます。

合理的投資家はこの相関を考慮するため、価格はマルチンゲールとなり、

$$
\operatorname{Cov}(R_1,R_2)=0,
\qquad
\operatorname{Cov}(R_2,R_3)=0.
$$

一方、相関無視をする投資家は $\hat s_2$ を独立情報として加え、

$$
P_2^{CN}
=
\frac{s_1+\hat s_2+p^*+1}{5}
$$

と評価します。

反復が起きた $x=1$ の場合、

$$
R_1=P_1-P_0
=
\frac{3s_1-p^*-1}{12},
$$

$$
R_2=P_2-P_1
=
\frac{3s_1-p^*-1}{20}.
$$

両者は同符号なので、

$$
E[R_2R_1]
=
p_xE\left[
\frac{(3s_1-p^*-1)^2}{240}
\right]>0.
$$

第2月で余分に織り込んだ価格は次の新しい情報時点で修正されるため、

$$
E[R_3R_2]
=
-p_xE[R_2^2]<0.
$$

したがって、**同じ情報を2回数えることが第2月の継続を生み、その過剰反応が次の第1月に反転する**という構造です。`ssrn-5268329.pdf`

## 2.3 $p_x$ の実証的代理変数

モデル上、効果の強さは反復確率 $p_x$ に比例します。

論文は $p_x$ が高いと考えられる状況として、

- 第1月と第2月の集計ROEが近い
- 業種内の利益連結性が高い
- 業種構成銘柄数が多い
- 第1月と第2月の情報が同じ方向

を使っています。これらの条件で継続・反転が強くなり、ランダムに作った架空業種では効果が出ません。

I/B/E/Sの長期成長率予想でも、通常の予想改定の遅延を制御した後、

$$
Rev_R \sim +Rev_N,
\qquad
Rev_{N_{q+1}}\sim -Rev_{R_q}
$$

というパターンが確認されます。`ssrn-5268329.pdf`

## 2.4 Guo第1論文との違い

両者は似ていますが、誤認している対象が違います。

- 第1論文：時変の持続性 $l,h$ を平均値 $m$ に圧縮
- 第2論文：相関した2つのシグナルを独立シグナルとして二重計上

第1論文のシグナルは

$$
\sum_{j=1}^{4}r_{N(t,j)}
$$

という複数四半期の情報です。

第2論文のシグナルは

$$
r_{nr(t)}
$$

という直近の第1月または第2月の情報です。

第2論文のTable 11では両方を同時に回帰へ入れても両者が有意であり、少なくとも標本内では別の予測成分を持つことが示されています。また、添付された2021年版Guo論文のAppendix Aにあった「correlation neglect」の補足分析を、独立したモデルと包括的実証へ発展させたものと位置づけられます。`Paper4_Guo.pdf` `ssrn-5268329.pdf`

---

# 3. Frazzini, *The Disposition Effect and Underreaction to News*

この論文は、前2本と異なり、個別銘柄の決算後ドリフトを保有者の含み損益から説明します。`The Disposition Effect and Underreaction to news - Frazzini.pdf`

## 3.1 投資家の参照価格

時点 $t-n$ に購入され、時点 $t$ まで元の保有者に保有されている株数を $V_{t,t-n}$ とすると、集計参照価格は

$$
RP_t
=
\frac{\sum_{n=0}^{t}V_{t,t-n}P_{t-n}}
{\sum_{n=0}^{t}V_{t,t-n}}.
$$

資本利得オーバーハングは

$$
G_t
=
\frac{P_t-RP_t}{P_t}.
$$

したがって、

- $G_t>0$：平均的保有者は含み益
- $G_t<0$：平均的保有者は含み損

です。

論文では投資信託保有データとFIFO仮定を使って $RP_t$ を構築します。また、売買回転率だけを使う近似として、

$$
\widehat V_{t,t-n}
=
TO_{t-n}
\prod_{\tau=1}^{n-1}
(1-TO_{t-n+\tau})
$$

も用いています。これは「$t-n$ に取引され、その後一度も取引されていない確率」に相当します。`The Disposition Effect and Underreaction to news - Frazzini.pdf`

## 3.2 処分効果が決算後ドリフトを生む理由

投資家は、

- 含み益銘柄を早く売る
- 含み損銘柄を売りたがらない

傾向を持ちます。

### 好材料かつ含み益

好材料で本源価値が上昇しても、含み益を確定したい売りが増えます。売り供給によって発表時価格の上昇が抑制されるため、その後に正のドリフトが生じます。

### 悪材料かつ含み損

悪材料が出ても、保有者は損失確定を避けて売却を制限します。価格は本来の低い価値まで直ちに下がらず、その後に負のドリフトが生じます。

論文の予測を縮約形で書くと、符号付きニュースを $E_{i,t}$ として、

$$
E[r^{abn}_{i,t+1:t+H}]
\approx
\theta E_{i,t}
\max\left\{
0,\operatorname{sgn}(E_{i,t})G_{i,t}
\right\}.
$$

- $E>0,G>0$：正のドリフト
- $E<0,G<0$：負のドリフト
- ニュースと含み損益が逆符号：効果は弱い

という非対称性を表します。

## 3.3 ポートフォリオ

ニュースは決算発表日前後

$$
[-2,+1]
$$

日の累積異常リターンで測定し、ニュース五分位と $G_t$ 五分位で独立ソートします。

**Overhang spread** は、

- ロング：好材料かつ大きな含み益
- ショート：悪材料かつ大きな含み損

です。

3カ月ローリング戦略の歴史的な月次3ファクター・アルファは、

$$
2.433\%
$$

で、過去リターン、時価総額、売買回転率を除去した残差CGOでも

$$
2.201\%
$$

でした。

論文の推定取引コスト控除後では、

$$
0.885\%\quad\text{（3カ月保有）},
$$

$$
1.062\%\quad\text{（6カ月保有）}
$$

ですが、標本は1980～2002年であり、これらの数値を現在の期待収益率として使うべきではありません。`The Disposition Effect and Underreaction to news - Frazzini.pdf`

## 3.4 識別上の強み

特に重要なのは、指数ファンドとETFの保有だけで参照価格を計算したプラセボでは、CGOによる大きな差が消えることです。

指数ファンドは銘柄入替えが指数構成に依存し、処分効果に基づいて売買しにくいため、この結果は単なる価格モメンタムや流動性ではなく、能動的保有者の売買行動を支持します。`The Disposition Effect and Underreaction to news - Frazzini.pdf`

---

# 4. 3論文の比較

|  | Guo | Guo-Wachter | Frazzini |
|---|---|---|---|
| 主な単位 | 市場・業種月次 | 市場・業種月次 | 個別株×決算イベント |
| 行動バイアス | パラメータ圧縮 | 相関無視・二重計上 | 参照価格依存の売買 |
| 予測子 | 過去4回のnewsyリターン | 直近のnewsy/repetitiveリターン | 決算ニュース×CGO |
| 価格経路 | 非newsyで継続、newsyで反転 | 第1月→第2月継続→次第1月反転 | 同符号条件でPEADを増幅 |
| 予測対象 | 共通リターン | 反復された共通情報 | 個別銘柄固有ドリフト |
| 個別株戦略での役割 | 市場・業種ベータの調整 | 共通成分の保有・反転時期 | 銘柄選択・方向決定 |

共通点は、いずれも「決算情報が価格へ一度で正しく反映されない」とする点です。

最大の相違は、Frazziniが基本的に**過少反応と継続**を予測する一方、Guo-Wachterは反復された共通情報への**過剰反応と将来反転**を予測する点です。

---

# 5. 個別銘柄決算戦略への統合

## 5.1 最重要：決算ニュースを共通成分と固有成分に分ける

銘柄 $i$、業種 $g$、四半期 $q$ の決算サプライズを

$$
z_{i,q}
=
\lambda_{i,g}F^{early}_{g,q}
+
\eta_{i,q}
$$

と分解します。

- $F^{early}_{g,q}$：同業の早期発表企業から既に判明した共通利益要因
- $\lambda_{i,g}F^{early}_{g,q}$：反復的な市場・業種情報
- $\eta_{i,q}$：その企業固有の新情報

第2月に発表する企業ほど、前者が大きくなりやすいと考えられます。

ここで、

- **相関無視モデルは共通成分に適用**
- **処分効果モデルは固有成分に適用**

します。

これをしないと、例えば第2月の好決算・含み益銘柄について、

- Frazzini：買い、決算後上昇継続
- Guo-Wachter：共通情報は過剰反応、次のnewsy月に反転

という反対の予測が混ざります。

正しい取引は、単純なアウトライト・ロングではなく、しばしば

$$
\text{Long stock}
-
\widehat\beta_{i,g}\text{ Short industry}
-
\widehat\beta_{i,M}\text{ Short market}
$$

という**企業固有サプライズのロング**です。

## 5.2 固有成分のFrazziniシグナル

決算直前のCGOを使い、過去リターン・時価総額・回転率で残差化します。

$$
G_{i,t}^{\perp}
=
G_{i,t}
-
\widehat\pi'X_{i,t}.
$$

決算後固有リターン予測を

$$
\widehat u_{i,e,h}
=
a_h\eta_{i,e}
+
b_h\eta_{i,e}
\max\left\{
0,\operatorname{sgn}(\eta_{i,e})G_{i,e}^{\perp}
\right\}
$$

とします。

第1項は通常のPEAD、第2項が処分効果による増幅です。

CGOは必ず**発表前価格までの情報**で計算すべきです。発表後価格を使うと、好決算による価格上昇が機械的に $G$ を正にし、ニュースとの同符号関係が人工的に作られます。

## 5.3 パラメータ圧縮の共通リターン予測

業種 $g$ について、

$$
S_{g,t}^{PC}
=
\sum_{j=1}^{4}r_{g,N(t,j)}
$$

を計算します。

二値の月ダミーより、実際の決算発表密度を使った連続的なnewsynessが望ましいでしょう。Guoの方法に沿えば、

$$
New_{g,m}
\propto
\sum_{e\in(g,m)}
2^{-L_e/HL},
\qquad
\sum_{m\in q}New_{g,m}=1,
$$

です。$L_e$ は会計期末から発表までの日数です。

予測値は

$$
P_{g,t}^{PC}
=
\left(
\beta_{PC}
+
\gamma_{PC}New_{g,t}
\right)S_{g,t}^{PC},
\qquad
\gamma_{PC}<0.
$$

newsynessが高いほど、過去決算シーズン・リターンに対する係数が継続側から反転側へ移ります。

## 5.4 相関無視の反復確率を推定する

モデルの $p_x$ を直接観測できないため、

$$
\widehat p_{x,g,q}
=
\operatorname{logit}^{-1}
\left(
c_0
+c_1Similarity_{g,q}
+c_2Connectivity_g
+c_3\log N_{g,q}
\right)
$$

と推定できます。

- $Similarity$：第1月と第2月の業種集計利益の近さ
- $Connectivity$：業種内企業利益の共分散
- $N$：業種構成企業数

相関無視による業種予測値は、

$$
C_{g,t}^{CN}
=
\begin{cases}
+\kappa_R\widehat p_{x,g,q}r_{g,N_q},
&t=R_q,\\[4pt]
-\kappa_N\widehat p_{x,g,q-1}r_{g,R_{q-1}},
&t=N_q,\\[4pt]
0,&t=T_q.
\end{cases}
$$

となります。

ただし、実現した第2月の類似度は第2月終了時まで分かりません。したがって、

- 第2月の継続予測：過去の業種連結性、業種規模、予定発表構成だけを使用
- 次の第1月の反転予測：実現済みの第1・第2月類似度も使用

と分けないとルックアヘッドになります。

## 5.5 階層的な総合予測

個別株リターンを

$$
r_{i,t+h}
=
\beta_{i,M}r_{M,t+h}
+
\beta_{i,g}r_{g,t+h}
+
u_{i,t+h}
$$

と分解します。

市場・業種について、

$$
\widehat r_{g,t+h}
=
P_{g,t+h}^{PC}
+
C_{g,t+h}^{CN},
$$

固有成分について、

$$
\widehat u_{i,t+h}
=
\widehat u_{i,e,h}^{Frazzini}
$$

とし、

$$
\boxed{
\widehat r_{i,t+h}
=
\beta_{i,M}\widehat r_{M,t+h}
+
\beta_{i,g}\widehat r_{g,t+h}
+
\widehat u_{i,t+h}
}
$$

を最終予測とします。

この階層構造なら、共通成分の将来反転と固有PEADの継続を同時に扱えます。

---

# 6. 決算月ごとの運用解釈

| 発表時期 | 共通成分 | 個別固有成分 |
|---|---|---|
| 第1月・newsy | 過去newsyリターンに対して反転。ただし最初の約1週間は効果が弱い | 新しい決算情報。CGO同符号ならPEADを強く見る |
| 第2月・repetitive | 第1月から継続。ただし次の第1月に反転しやすい | 早期発表企業で説明できない残差サプライズだけを追随 |
| 第3月 | Guo型の継続は残り得るが、相関無視シグナルは弱い | 遅延発表・選択効果を強く管理 |

例えば4月に好決算、正のCGOを持つ銘柄なら、企業固有部分をロングし、5～6月までは業種共通成分も追随し得ます。ただし7月前には市場・業種ベータを縮小または反転させます。

5月の好決算が4月の同業決算と極めて似ている場合、企業固有残差だけをロングし、業種をショートする方が3論文に整合的です。

---

# 7. 推奨バックテスト設計

モデルは次の順番で追加し、増分寄与を評価すべきです。

1. **M0**：通常のPEAD
2. **M1**：PEAD＋残差CGO
3. **M2**：M1＋Guoパラメータ圧縮
4. **M3**：M2＋Guo-Wachter相関無視
5. **M4**：M3＋業種類似度・連結性との交差項

共通スリーブは月次で指数・業種ポートフォリオを取引し、個別株スリーブは決算日の翌営業日から日次で管理する方が、月次シグナルを無理に日次へ配分するよりも明瞭です。

推定では特に、

- 発表時刻を考慮した翌営業日処理
- 発表直前時点のコンセンサス
- expandingまたはrolling window
- 重複保有期間に対するNewey-Westまたはブロック・ブートストラップ
- 月×企業または月×業種の二方向クラスタリング
- 取引コスト・空売りコスト・決算ギャップリスク
- 発表予定日の変更を含むタイミング情報

を管理する必要があります。

---

# 8. 被引用状況と後続研究

Guo論文は2025年にRFSへ掲載され、検索時点のRePEc/OUP表示では被引用数18です。Guo-Wachterはまだワーキングペーパーで、Google Scholar表示では被引用数4と新しい研究です。FrazziniはGoogle Scholar/RePEc系で約1,500件、WileyのCrossref表示で635件と、非常に広く引用されています。データベースごとに集計対象が異なるため、件数は目安です。([IDEAS/RePEc](https://ideas.repec.org/a/oup/rfinst/v38y2025i6p1730-1782..html?utm_source=chatgpt.com))

Frazziniに対する重要な後続研究は一枚岩ではありません。

- Birruは、処分効果が情報反映を遅らせる証拠を確認する一方、モメンタム全体を説明するには規模が小さいと結論づけています。([OUP Academic](https://academic.oup.com/rfs/article-pdf/28/7/1849/5457246/hhv007.pdf))
- Ciciは、処分効果を示す投資信託は相当数存在するものの、平均的ファンドでは必ずしも強くなく、ファンド成績への明確な影響も確認できないと報告しています。([Cambridge University Press & Assessment](https://www.cambridge.org/core/journals/journal-of-financial-and-quantitative-analysis/article/prevalence-of-the-disposition-effect-in-mutual-funds-trades/809AD8AB83172BCA995E97425427A73A))
- Weisbrodは、含み損益が決算時の売買と短期価格反応を左右することを再確認しつつ、純粋なプロスペクト理論だけでなく、後悔回避・誇り追求の要素も必要だとしています。([IDEAS/RePEc](https://ideas.repec.org/a/bla/jfinan/v74y2019i2p899-942.html?utm_source=chatgpt.com))
- Ben-David and Hirshleiferは売却確率が単純な損益境界ではなくV字型であり、「利益なら売る、損失なら保有」という単純モデルだけでは説明できないと示しています。([OUP Academic](https://academic.oup.com/rfs/article/25/8/2485/1572667?utm_source=chatgpt.com))

Guo系については、Guo-Wachterが最も直接的な後続研究です。また2025年のワーキングペーパー *Extrapolation and Market Reactions to News* は、過去ニュースが新しい企業ニュースへの反応に混入し、その歪みが後に反転すること、効果がニュースの近さ・整合性・不確実性に依存することを報告しています。これは統合モデルへ「過去ニュースとの類似度」を追加する根拠になりますが、まだワーキングペーパー段階です。([SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/5489586.pdf?abstractid=5489586&mirid=1))

**実装優先順位**は、①固有決算サプライズ×残差CGO、②Guoの市場・業種レジーム、③Guo-Wachterの反復・類似度調整、の順が妥当です。最も重要なのは、3シグナルを生のまま加算せず、**共通／固有成分と予測ホライズンを分離すること**です。

---

**Sources:**

- [](https://academic.oup.com/rfs/article/38/6/1730/8101501)
- [Correlation neglect in asset prices by Hongye Guo, Jessica A. Wachter :: SSRN](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5268329)
- [Earnings Extrapolation and Predictable Stock Market Returns](https://ideas.repec.org/a/oup/rfinst/v38y2025i6p1730-1782..html?utm_source=chatgpt.com)
- [The Prevalence of the Disposition Effect in Mutual Funds’ Trades | Journal of Financial and Quantitative Analysis | Cambridge Core](https://www.cambridge.org/core/journals/journal-of-financial-and-quantitative-analysis/article/prevalence-of-the-disposition-effect-in-mutual-funds-trades/809AD8AB83172BCA995E97425427A73A)

## Response:
2026/6/26 0:47:07

> **Considering runtime requirements and environments**
>
> 考慮すべき点として、32GBのメモリで20年間のデータを処理するのに30分以内で実行できるように設定したいですが、環境は不明です。設定を柔軟かつキャッシュ利用ができるようにノートブックで設定するのが良さそうです。標準的なパッケージに加え、DuckDBも検討するかもしれません。
>
> **Considering data loading options and configuration structure**
>
> データの読み込みは、ローカルのParquetファイルとWRDSの両方に対応する必要があります。ユーザーが選択できるようにすると良いでしょう。環境変数を使い、SQLクエリや認証なしで動作するよう設計するのがカギです。また、設定を`Config`データクラスで定義する方法も検討しています。
>
> **Considering user data access and schema requirements**
>
> ユーザーからの質問として、データアクセス方法や設定の詳細について考えています。具体的には、WRDS（CRSP/Compustat/IBES）やThomsonの保有情報、CGOの設定などです。また、データスキーマに関する情報も必要です。例えば、`security_daily`や`fundamentals_q`など、正確なIDとリンクの保持が重要です。
>
> 思考時間: 7m 43s

# 実装要件定義ドラフト

## 1. 実装目的

単一のJupyter Notebookを上から順に実行するだけで、以下を完結させます。

1. point-in-timeデータの読込・検証  
2. 決算ニュースの共通成分／企業固有成分への分解  
3. Frazzini型のニュース×含み損益シグナル生成  
4. Guo型のパラメータ圧縮シグナル生成  
5. Guo-Wachter型の相関無視シグナル生成  
6. 予測値の統合  
7. ポートフォリオ構築・取引コスト控除後バックテスト  
8. モデル別寄与分析、最新シグナル、監査用データの出力  

実装は、日次の個別銘柄決算戦略と月次の市場・業種戦略を無理に一つの回帰式へ押し込まず、以下の**2スリーブ構成**とします。

| スリーブ | 頻度 | 主対象 | 中核モデル |
|---|---:|---|---|
| Idiosyncratic sleeve | 決算イベント／日次 | 個別銘柄 | 企業固有ニュース×CGO |
| Common sleeve | 月次 | 市場・業種 | パラメータ圧縮＋相関無視 |

最終ポートフォリオは両スリーブをリスク予算で合成します。これにより、個別株固有のPEAD継続と、市場・業種共通成分の将来反転を分離できます。

---

## 2. 実装スコープ

### 必須機能

- 米国株または指定市場の決算イベント・バックテスト
- point-in-timeの決算発表日時、コンセンサス、価格データの利用
- 過去データのみを使うexpanding-window推定
- 企業固有ニュースの算出
- turnoverベースまたは保有明細ベースのCGO
- newsy／repetitive／third-monthレジーム
- 個別株、業種、市場のリターン分解
- 重複保有期間を正しく処理する日次P&L
- 売買コスト、空売りコスト、流動性制約
- モデルM0～M4の増分比較

### 拡張機能

- 保有明細を使ったFIFO参照価格
- 定量的newsyness
- 業種利益connectivity
- 相関無視確率 $\hat p_x$ の推定
- 制約付きポートフォリオ最適化
- ライブ運用向け最新ポジション出力

---

# 3. 入力データ要件

## 3.1 必須データ

| データセット | 必須フィールド | 頻度 |
|---|---|---:|
| Security master | `security_id`, ticker, exchange, share class, country, industry code, listing/delisting date | 履歴 |
| 株価・リターン | date, open, close, adjusted return, price, shares outstanding, volume, delisting return | 日次 |
| 決算イベント | fiscal period end, announcement timestamp, actual EPS, announcement source | イベント |
| コンセンサス | estimate timestamp, forecast period, consensus EPS, analyst count | point-in-time |
| 財務データ | book equity, quarterly income, shares | 四半期 |
| 市場・業種 | market return, risk-free rate, factor returns, industry membership | 日次／月次 |
| 取引コスト | spreadまたは推定spread、ADV、borrow fee、short availability | 日次 |

### 特に重要な時刻情報

すべてのレコードに、可能な限り次の二つを持たせます。

- `effective_at`：情報が表す時点
- `available_at`：実際に利用可能になった時点

特徴量 $x_{i,t}$ は必ず

$$
available\_at(x_{i,t})\leq signal\_timestamp
$$

を満たす必要があります。

決算発表時刻が取得できる場合は、BMO、intraday、AMCを区別します。時刻がない場合は、保守的に翌営業日利用とします。CompustatとI/B/E/Sの日付を併用する場合は、両論文で採用されている日付統合と、引け後発表の翌営業日シフトを再現可能にします。`Paper4_Guo.pdf` `ssrn-5268329.pdf`

## 3.2 CGO用データ

優先順位は以下です。

1. ファンドまたは13F等の保有明細
2. turnoverベースの近似
3. CGOを省略したPEADのみのベンチマーク

保有明細を用いる場合は、`manager_id`, `security_id`, `asof_date`, `public_date`, `shares_held` が必要です。`asof_date`ではなく、必ず`public_date`を情報利用可能日とします。

---

# 4. 決算イベントの時刻定義

Notebook内で、各イベントについて以下を一意に生成します。

| フィールド | 定義 |
|---|---|
| `event_timestamp` | 実際の発表日時 |
| `event_trading_date` | 市場がニュースを最初に取引可能な日 |
| `news_measure_end` | ニュース測定に用いる最後の日 |
| `signal_timestamp` | 全特徴量が確定する時刻 |
| `entry_date` | バックテスト上の約定日 |
| `exit_date_H` | 保有期間 $H$ の終了日 |

Frazziniの再現ではイベントニュースを

$$
CAR_{i,e}^{[-2,+1]}
=
\sum_{\tau=-2}^{+1}
\left(
r_{i,e+\tau}
-\widehat\alpha_i
-\widehat\beta_i r_{M,e+\tau}
\right)
$$

で測るため、売買開始は原則として $+1$ 日終値より後とします。論文ではこのCARを決算ニュースとして利用しています。`The Disposition Effect and Underreaction to news - Frazzini.pdf`

実運用モードでは、決算発表直後に利用できるEPSサプライズを主変数とし、

$$
ES_{i,e}
=
\frac{EPS^{actual}_{i,e}-EPS^{consensus}_{i,e^-}}
     {P_{i,e^-}}
$$

を使います。Notebookでは以下を設定可能にします。

```text
NEWS_MODE = "eps" | "car" | "hybrid"
```

---

# 5. 特徴量仕様

## 5.1 ニュースの標準化

生の決算ニュース $z_{i,e}^{raw}$ を、同一発表月または同一業種・発表月内でwinsorizeし、標準化します。

$$
z_{i,e}
=
\frac{
\operatorname{winsor}(z_{i,e}^{raw})-\mu_{g,t}
}{
\sigma_{g,t}
}
$$

分散が不足する小規模業種では、sector、marketの順にフォールバックします。

---

## 5.2 共通ニュースと企業固有ニュースの分解

企業 $i$ の発表時点より前に、同じ会計四半期について発表済みの同業企業集合を

$$
\mathcal A_{g,q}(t_e^-)
$$

とします。早期発表企業の共通ニュースは、

$$
F_{g,q,e}^{pre}
=
\frac{
\sum_{j\in\mathcal A_{g,q}(t_e^-)}
w_{j,e}z_{j,q}
}{
\sum_{j\in\mathcal A_{g,q}(t_e^-)}w_{j,e}
}
$$

で計算します。基準ウェイトは発表直前時価総額です。

企業固有ニュースは、

$$
\eta_{i,e}
=
z_{i,e}
-\widehat\alpha_{g,e^-}
-\widehat\lambda_{g,e^-}F_{g,q,e}^{pre}
$$

とします。

### $\lambda_g$ の推定

- 過去データだけを使うexpandingまたはrolling推定
- 原則として業種単位
- サンプル不足時はsector/global係数へ縮約
- 最低推定期間：5年または20四半期
- ridge shrinkageを許容
- 現在の四半期の将来発表企業は使用禁止

### 同業発表数不足時

```text
industry → sector → market → 0
```

の順にフォールバックし、フォールバック階層を出力データに記録します。

---

## 5.3 Capital Gains Overhang

### 保有明細ベース

$$
RP_{i,t}
=
\frac{
\sum_{n=0}^{L}V_{i,t,t-n}P_{i,t-n}
}{
\sum_{n=0}^{L}V_{i,t,t-n}
}
$$

$$
G_{i,t}
=
\frac{P_{i,t}-RP_{i,t}}{P_{i,t}}
$$

売却ロットの消去はFIFOを基準とします。

### Turnoverベース

保有明細がない場合は、

$$
\widehat V_{i,t,t-n}
=
h_{i,t-n}
\prod_{\tau=1}^{n-1}
(1-h_{i,t-n+\tau})
$$

を使います。ここで生のturnoverが1を超え得るため、実装上は

$$
h_{i,t}=1-\exp(-TO_{i,t})
$$

として取引確率へ変換します。比較用に、論文に近い`clip(TO,0,0.95)`版も計算します。

参照価格は、

$$
\widehat{RP}_{i,t}
=
\frac{
\sum_{n=1}^{L}\widehat V_{i,t,t-n}P_{i,t-n}
}{
\sum_{n=1}^{L}\widehat V_{i,t,t-n}
}
$$

です。Frazziniは保有明細ベースを主分析とし、turnoverベースの近似でも同方向の結果を報告しています。`The Disposition Effect and Underreaction to news - Frazzini.pdf`

### 実装条件

- 基準CGOは決算直前の前月末で固定
- 決算発表後の価格をCGOに含めない
- lookback $L$：60カ月を基準、36・120カ月を感応度分析
- 株式分割、配当、上場廃止を調整
- CGO coverageと参照価格の実効ロット数を記録

---

## 5.4 Residual CGO

CGOは過去リターンやturnoverとの機械的相関が強いため、毎月のクロスセクションで次を推定します。

$$
\begin{aligned}
G_{i,t}
=&\;\pi_{0,t}
+\pi_{1,t}R_{i,t-12:t-1}
+\pi_{2,t}R_{i,t-36:t-13}\\
&+\pi_{3,t}\overline{TO}_{i,t-12:t-1}
+\pi_{4,t}\log ME_{i,t-1}
+\nu_{i,t}.
\end{aligned}
$$

$$
G^\perp_{i,t}=\widehat\nu_{i,t}
$$

を戦略変数とします。生CGOは頑健性検証用に残します。

---

## 5.5 Frazzini型個別銘柄シグナル

ニュースとCGOが同符号の場合だけ処分効果を強く評価します。

$$
D_{i,e}
=
\eta_{i,e}
\max
\left(
0,\operatorname{sgn}(\eta_{i,e})G^\perp_{i,e^-}
\right)
$$

- $\eta>0,G^\perp>0$：正
- $\eta<0,G^\perp<0$：負
- 異符号：ゼロまたは小さい値

予測モデルは保有期間 $H$ ごとに、

$$
\widehat u_{i,e,H}
=
\widehat a_H
+\widehat b_H\eta_{i,e}
+\widehat c_HD_{i,e}
+\widehat\gamma_H'X_{i,e}
$$

とします。

$X$ は、size、value、momentum、volatility、turnover、analyst coverage等の統制変数です。

### 推定方法

- 推定はexpanding window
- 最低60カ月の学習期間
- 推論用：パネルOLS、企業×月または企業×発表月の二方向クラスタリング
- 売買用：OLSまたはridgeを設定可能
- 特徴量の標準化パラメータも過去データのみで推定
- 基準保有期間：63営業日
- 追加評価：21、126営業日

---

# 6. Guo型パラメータ圧縮シグナル

## 6.1 離散版

月 $m$ より前の直近4回のnewsy monthにおける業種超過リターンを、

$$
X^{PC}_{g,m}
=
\sum_{j=1}^{4}
r^{ex}_{g,N(m,j)}
$$

とします。

$$
r^{ex}_{g,m}
=
\alpha
+\beta X^{PC}_{g,m}
+\gamma X^{PC}_{g,m}I^N_m
+\delta I^N_m
+\varepsilon_{g,m}
$$

を過去データのみで推定します。

- 非newsy月の係数：$\beta$
- newsy月の係数：$\beta+\gamma$
- 理論・実証上の想定：$\beta>0,\gamma<0$

Guoは、過去newsy monthリターンが非newsy月では継続、将来のnewsy月では反転を予測することを示しています。また、個別株の効果は主として業種成分を通じて発生すると報告しています。`Paper4_Guo.pdf`

## 6.2 定量的newsyness

拡張版では、

$$
RawNew_{g,m}
=
\sum_{e\in(g,m)}
2^{-L_e/HL}
$$

$$
New_{g,m}
=
\frac{RawNew_{g,m}}
{\sum_{m'\in q}RawNew_{g,m'}}
$$

とします。

- $L_e$：会計期末から発表までの日数
- $HL$：half-life。基準4日、感応度3・5・7日
- 月別newsynessプロファイルはexpanding windowで計算
- 現在四半期の将来発表実績を使わない

加重過去リターンは、

$$
X^{PC,Q}_{g,m}
=
\sum_{j=1}^{12}
r^{ex}_{g,m-j}New_{g,m-j}
$$

です。

---

# 7. Guo-Wachter型相関無視シグナル

月を次のように分類します。

- $N_q$：四半期第1月、newsy
- $R_q$：四半期第2月、repetitive
- $T_q$：四半期第3月

基準シグナルは、

$$
X^{CN}_{g,m}
=
\begin{cases}
r^{ex}_{g,N_q}, & m=R_q,\\[4pt]
-r^{ex}_{g,R_{q-1}}, & m=N_q,\\[4pt]
0, & m=T_q.
\end{cases}
$$

すなわち、

$$
N_q\rightarrow R_q
$$

は継続、

$$
R_q\rightarrow N_{q+1}
$$

は反転を予測します。Guo-Wachterは、市場と業種の双方についてこの交互の自己相関を報告し、パラメータ圧縮シグナルを同時に投入しても両者が残ることを示しています。`ssrn-5268329.pdf`

## 7.1 反復確率の拡張

データが十分な場合は、

$$
\widehat p_{x,g,q}
=
\sigma
\left(
c_0
+c_1Similarity_{g,q}
+c_2Connectivity_{g,q}
+c_3\log N_{g,q}
\right)
$$

を推定し、

$$
X^{CN,p}_{g,m}
=
\widehat p_{x,g,q}X^{CN}_{g,m}
$$

とします。

### 変数定義

- `Similarity`：newsy月とrepetitive月の集計ROEまたはニュース距離
- `Connectivity`：過去の企業ROE共分散の業種内平均
- $N_{g,q}$：事前時点の業種構成銘柄数

### ルックアヘッド制約

- repetitive月を予測する時点では、当該月終了後の実現Similarityを使用しない
- 次のnewsy月を予測する時点では、終了済みのnewsy/repetitive月Similarityを使用可能
- 業種サイズとconnectivityは必ず前月末までのデータで計算

---

# 8. 共通成分モデルの統合

業種月次予測は、

$$
\begin{aligned}
\widehat r^{common}_{g,m}
=&\;\widehat\alpha
+\widehat\beta_{PC}X^{PC}_{g,m}
+\widehat\gamma_{PC}X^{PC}_{g,m}New_{g,m}\\
&+\widehat\beta_{CN}X^{CN}_{g,m}
+\widehat\beta_{CNP}X^{CN,p}_{g,m}
\end{aligned}
$$

とします。

- 市場モデル：月次時系列OLS
- 業種モデル：業種固定効果付きパネル
- 回帰ウェイト：前月末時価総額
- 標準誤差：市場モデルはNewey-West、業種モデルは月クラスタ
- 業種構成銘柄数：基準20、感応度10
- 係数は月 $m-1$ までのデータで推定

---

# 9. 最終統合方法

## 9.1 推奨方式：2スリーブ合成

### Idiosyncratic sleeve

企業固有予測 $\widehat u_{i,e,H}$ に基づく個別株ロング・ショートです。

初期ウェイトを

$$
\widetilde w_{i,e}
\propto
\frac{
\operatorname{rankscore}(\widehat u_{i,e,H})
}{
\widehat\sigma_{i,e}
}
$$

とし、以下を中立化します。

$$
\sum_iw_i=0
$$

$$
\sum_iw_i\widehat\beta_{i,M}=0
$$

$$
\sum_iw_iI(i\in g)=0,\quad \forall g
$$

### Common sleeve

$\widehat r^{common}_{g,m}$ に基づいて業種ポートフォリオまたは業種ETFを売買します。

- 月次リバランス
- market-neutralを基準
- 業種予測のクロスセクションをdemean
- inverse-volまたは共分散行列によるリスク調整
- 最大ウェイト制約

### 合成

$$
w_t^{total}
=
\rho_{idio}w_t^{idio}
+
\rho_{common}w_t^{common}
$$

$\rho$ は予測値の平均ではなく、各スリーブの事前リスクで決定します。

## 9.2 参考出力：銘柄別統合期待収益率

分析用には、

$$
\widehat r_{i,e,H}
=
\widehat u_{i,e,H}
+
\widehat\beta_{i,M}
\widehat r_{M,e:H}^{common}
+
\widehat\beta_{i,g}
\widehat r_{g,e:H}^{common}
$$

も出力します。

月次共通予測は、保有期間に含まれる各月の日数に応じて按分します。

---

# 10. バックテスト仕様

## 10.1 基本ルール

| 項目 | 基準仕様 |
|---|---|
| 個別株エントリー | シグナル確定後の次の取引可能価格 |
| 個別株保有期間 | 63営業日 |
| Common sleeve | 月末シグナル、翌月取引 |
| リバランス | Idioはイベントごと、Commonは月次 |
| 重複ポートフォリオ | 日次で独立ロット管理 |
| 上場廃止 | delisting returnを含める |
| 欠損価格 | 最終価格で固定せず、定義済みの清算処理 |
| 配当・分割 | total returnベース |
| 空売り不能 | その銘柄を除外し、残存銘柄で再正規化 |

## 10.2 売買コスト

日次売買額 $\Delta w_{i,t}$ に対して、

$$
TC_{i,t}
=
|\Delta w_{i,t}|
\left(
\frac{Spread_{i,t}}{2}
+Commission_{i,t}
+Impact_{i,t}
\right)
+
ShortValue_{i,t}BorrowFee_{i,t}
$$

を適用します。

Impactは設定可能なsquare-rootモデルとします。

$$
Impact_{i,t}
=
k\sigma_{i,t}
\sqrt{
\frac{TradeValue_{i,t}}{ADV_{i,t}}
}
$$

必須制約は以下です。

- 1銘柄ウェイト上限
- 1日ADV参加率上限
- 業種グロス上限
- ポートフォリオ総グロス上限
- 空売り在庫・borrow feeフィルター

---

# 11. モデル比較

Notebookは同一データ、同一取引ルールで以下を順に評価します。

| モデル | 内容 |
|---|---|
| M0 | 標準PEAD：ニュースのみ |
| M1 | M0＋Residual CGO相互作用 |
| M2 | M1＋Guoパラメータ圧縮 |
| M3 | M2＋Guo-Wachter相関無視 |
| M4 | M3＋Similarity、Connectivity、業種サイズ |

各モデルについて、gross/netの両方を出力します。

---

# 12. Notebook構成

| セクション | 処理内容 |
|---:|---|
| 00 | 仕様、CONFIG、データパス、乱数seed |
| 01 | import、共通関数、ログ設定 |
| 02 | データ読込、型変換、主キー検査 |
| 03 | point-in-time時刻整合、取引カレンダー |
| 04 | 投資ユニバース、流動性フィルター |
| 05 | 日次・月次リターン、業種リターン |
| 06 | 決算ニュース、EPS surprise、event CAR |
| 07 | early-announcer共通因子、固有ニュース |
| 08 | holdings／turnover CGO、Residual CGO |
| 09 | Frazzini型イベントモデル |
| 10 | newsy／repetitive／third分類 |
| 11 | Guoパラメータ圧縮モデル |
| 12 | Guo-Wachter相関無視モデル |
| 13 | 共通成分統合モデル |
| 14 | Idio/Commonポートフォリオ構築 |
| 15 | 日次バックテスト、コスト、空売り |
| 16 | パフォーマンス、IC、イベントドリフト |
| 17 | M0～M4比較、頑健性分析 |
| 18 | 最新シグナル、ポジション、CSV出力 |
| 19 | look-ahead監査、assertion、run manifest |

外部の自作Pythonモジュールには依存させません。すべての関数、クラス、テストをNotebook内に置きます。中間結果のParquetキャッシュは許容しますが、キャッシュを削除しても`Restart & Run All`で再生成できることを要件とします。

---

# 13. 出力要件

## 13.1 データ出力

- `event_features.parquet`
- `industry_month_features.parquet`
- `model_forecasts.parquet`
- `daily_target_positions.parquet`
- `daily_realized_positions.parquet`
- `daily_pnl.parquet`
- `latest_signals.csv`
- `performance_summary.csv`
- `run_manifest.json`

## 13.2 必須分析表

- 変数coverage、欠損率、外れ値
- ニュース五分位×CGO五分位の将来収益
- PEAD decay curve
- newsy／repetitive別の自己回帰係数
- PCとCNを同時投入した回帰
- M0～M4の増分リターン
- gross/net Sharpe、最大DD、turnover、capacity
- factor alpha、market beta、業種エクスポージャー
- long側／short側の寄与
- newsy月／repetitive月／third-month別寄与

## 13.3 必須グラフ

- 累積gross/net P&L
- drawdown
- rolling Sharpe
- rolling beta
- signal IC
- 決算後累積異常収益
- CGO×ニュースのヒートマップ
- Common sleeveとIdio sleeveの寄与
- 取引コスト対gross alpha

---

# 14. 品質保証・受入条件

## 14.1 ハード受入条件

- `Restart & Run All`がエラーなく完了
- 乱数seed固定時に同一結果
- 主キー重複ゼロ
- 全特徴量で`available_at <= signal_timestamp`
- 推定窓に将来データが入っていない
- 発表後価格が発表前CGOに入っていない
- ポジションとP&Lの会計一致
- 上場廃止リターンを含む
- 各時点で設定したgross、net、beta、industry制約を満たす
- 出力ファイルとrun manifestを生成
- CONFIG以外の手修正なしで再実行可能

## 14.2 経済的sanity check

以下は実装診断であり、採用を強制する収益条件ではありません。

- Frazzini相互作用係数 $c_H$ が期待方向
- 同符号ニュース×CGOでPEADが相対的に大きい
- newsy→repetitiveの係数が相対的に正
- repetitive→次newsyの係数が相対的に負
- PCの`signal × newsy`係数が相対的に負
- 実在業種でfake industryより効果が強い
- OOSとin-sampleを明確に分離

---

# 15. 確定に必要な質問

| 論点 | 質問 | 未指定時の暫定値 |
|---|---|---|
| 対象市場 | 米国株、日本株、グローバルのどれですか | 米国普通株 |
| データ | 利用可能なベンダーとファイル形式は何ですか。発表時刻とpoint-in-timeコンセンサスはありますか | CRSP/Compustat/I/B/E/S相当 |
| CGO | ファンド・13F等の保有履歴がありますか | turnoverベース |
| 目的 | 論文再現が主目的か、実運用可能なOOS戦略が主目的か | 実運用寄りOOS |
| 売買仕様 | long-short／long-only、保有期間、執行価格、目標ボラはどうしますか | market/industry-neutral、63営業日 |
| 制約 | 想定AUM、ADV上限、単一銘柄上限、borrow costの有無はどうしますか | すべてCONFIG化 |
| 業種分類 | SIC、GICS、東証33業種等のどれを使いますか | 再現はSIC、実運用はGICS |
| ニュース変数 | EPS surprise、event CAR、または両者の合成のどれを主変数にしますか | EPS surprise主、CARを頑健性検証 |

特に、**対象市場、データベンダー、保有明細の有無、売買制約**の4点が確定すれば、実装仕様を固定できます。

## Response:
2026/6/26 7:08:29

> **実装ノートブックの作成**
>
> ユーザーから「対象市場：日本株、データベンダー：LSEG 実装して」とのリクエスト。実際のLSEGデータはないが、テンプレートにはLSEGデータへのプレースホルダーを用意する。ノートブックは自己完結型で、入力スキーマやコード関数の設定が可能で、データは実行しない。必要に応じてデモ/合成モードを含める可能性あり。
>
> **引用の確認と実装**
>
> 引用について、最終的な出力は簡潔にリンクを含める必要がある。前回のファイルから引用情報は既にあるので、それを基に仮定や詳細について触れる必要があるかも。ただし、行番号がない引用情報もあるため、指示通り簡単なウェブリンクで引用を完
>
> **LSEGデータ接続の実装方法**
>
> LSEGのAPIやデータフィールドに関しては、変更があるかもしれないため、Web検索または公式ドキュメントを参照する必要がありそうです。ユーザーの要望に対応するため、CSV形式で正規化されたデータを実装可能かもしれません。APIの詳細については、必要に応じて公式のLSEGドキュメントを調べるべきです。
>
> **Searching official LSEG Data Library Python documentation**
>
> [LSEG Data Library for Python](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation)
> [get_history - Download LSEG Workspace](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html)
> [lseg-data](https://pypi.org/project/lseg-data/)
> [LD Lib. Python Tutorial 4 - get_history.ipynb](https://github.com/LSEG-API-Samples/Example.DataLibrary.Python/blob/lseg-data-examples/Tutorials/1.Access/LD%20Lib.%20Python%20Tutorial%204%20-%20get_history.ipynb)
> [ld.get_history() and ek.get_timeseries() equivalent fields](https://community.developers.lseg.com/discussion/132320/ld-get-history-and-ek-get-timeseries-equivalent-fields)
> [Webinar Python Finance - Beginners' Guide to Python and the ...](https://www.youtube.com/watch?v=0tW0LdTo9bo)
> [PypeIt: The Python Spectroscopic Data Reduction Pipeline](https://arxiv.org/abs/2005.06505)
>
> **ノートブック実装の計画**
>
> 実際のコードを含むノートブックを作成します。必要な内容は：設定用のデータクラス、LSEGアダプター（CSVやparquetテーブル対応）、LSEGデータ呼び出し用のスケルトン（フィールドマッピング付き）。データが欠けている場合はシミュレーションデータを使用可能にしますが、ユーザーには実際のLSEGデータを使用してもらいたいです。
>
> **日本の決算サイクルについて**
>
> 日本の企業は四半期末（3月、6月、9
>
> **日本株のニュースサイクル設定**
>
> 日本株のニュースサイクルについて、四半期後の月が新鮮なニュースを含み、2ヶ月目は繰り返しが多くなる傾向がある。LSEGの発表日に基づいて、柔軟に対応できるように設定を行いたい。デフォルト設定は `newsy_months = [1,4,7,10]` ですが、カスタム設定を可能にする方法も検討します。
>
> **LSEGフィールドマッピングの確認**
>
> ノートブック内の設定で、`LSEG_FIELD_MAP`として例えば`TR.PriceClose`や`TR.TotalReturn`などのフィールドをマッピングすることが考えられますが、これらが正確であるかを確認する必要があります。フィールド名は`Data Item Browser`で検証すべきです。ユーザーには、可能な限り一般的な形式で提供しつつ、正確な名前を使用します。
>
> **ノートブックの構成**
>
> ノートブックには以下の
>
> **商品リターンの計算とモデル実装**
>
> まず、リスクプレミアム（RP）とキャピタルゲインオーバーパフォーマンス（CGO）を月末に計算します。これにはローリングウェイトと過去数ヶ月のデータを使います。また、残差分析を通じて`CGO  ret_12_1 + ret_36_13 + avg_to_12 + log_mcap`を達成します。
> 
> Frazzini信号では、`D = eta * max(0, sign(eta) * resid_cgo)`として予測しますが、データが不十分な場合はランクスコアを使用します。
>
> **実装の進行状況**
>
> まず、`pc_forecast`
>
> **ノートブック作成のためのコード整理**
>
> まず、予測はデータに基づいてスケーリングして、異常値を取り除いた上で解析。統計のパッケージには、`pandas`, `numpy`, `matplotlib`を必須にして、`statsmodels`や`scikit-learn`はオプションとして扱います。私が作成するノートブックでは、日本語ドキュメントの記述も考えて採用。
>
> **ノートブックの作成と実装に関する計画**
>
> コードは文字列のセルとして作成し、実行してエラーが出ないか確認します。ファイルをきれいに保ちつつ、コンテナとPython環境に合わせた作業にします。また、`use_sample_data=False`や`csvパス`といった設定を記載し、LSEGに関する公式ドキュメントの引用も追加します。
>
> **日本の株式データ処理ノートブック作成**
>
> まず、80銘柄、6年間のデータ（約1500日）を使って、月次データを含むサンプルを作成します。日本の株式市場の祝日を考慮し、取引日はLSEGから得た実際のデータを使用します。ノートブックには、タイトル、設定、ユーティリティ関数、データ準備の各セルを作成します。
>
> **TSEの変更に伴う実装の考慮**
>
> TSEの取引終了時間が2024年11月に変更され、15:30になったので、これを基にして設定を行います。ただし、正確な終了時刻は必須ではなく、イベント発表時間に基づいて取引日を決定します。遅延設定や市場・業界別のリターン計算も行います。
>
> **イベントの計算とzスコアに基づく調整**
>
> 5760のイベントを扱い、異なる手法で「eps」や「car」を使って英字やハイブリッドを実装します。業界ごとにイベントを分類し、zスコアを使った加重平均を算出。shrinkage λ=1とし、推定ルーチンで誤差最小化を進めます。
>
> **信号と類似度の計算**
>
> `pc_inter`は新しいニュースがあるかによって補正された信号。次に、以前のニュースのリターンや、分回し計算などで影響を与える`similarity`と`connectivity`を定義していくことになります。業界ごとのROEや相関を使って、企業間関係を分析しスコア化。
>
> **ポートフォリオ構築と重み付けの計算**
>
> 月別に業界の重みを計算し、その日々のポジションを構築します。業界全体のP&Lを算出し、それを個別の株式にマッピングできます。また、ポートフォリオのリターンは、重みと過去のリターンに基づく計算を行い、リスク調整を加えます。
>
> **TRANSACTIONコストと簡易的なアプローチ**
>
> 取引コストは、ポジションの転換率から計算されます。アイデアとしては、各株式の転換を基に、一定の手数料やスプレッドを掛け算してコストを算出。コードは長くなりそうなので、テストが必要だと思います。また、よりシンプルにNotebookで定義して実行してみるのも良いかも。
>
> **環境確認とノートブック生成**
>
>
> **ノートブックの作成**
>
> ノートブックの作成には、慎重にコードを記述する必要がありそうです。サンプル生成器がランダムシードを使用するので、十分なデータが必要だな、と。まず`notebook_code.py`を作成し、コードをセクションに分けてテストし、最終的にはノートブックに結合していこうと思います。
>
> **Evaluating teaser text performance on different audience segments**
>
>
> **スクリプトのバグ修正と表示の問題**
>
> スクリプトに`#%%`のマーカーがあるので、まずは実行してバグを探す必要がありそうです。プロットが表示されるかもしれませんが、インタラクティブでない場合でも作成されるはず。テスト時には`display`を使っていますが、スクリプトでは未定義になる可能性があるので、`from IPython.display import display`を追加しようと思います。
>
> **パッチ適用とインポート修正**
>
>
> **スクリプトのタイムアウトと最適化**
>
> スクリプトが300秒でタイムアウトしたのは、サンプルサイズ120やイベント予測の処理に時間がかかっている可能性があります。出力を部分的に確認し、タイムアウトまたは出力がない場合は、サンプルを縮小したり、プロファイルを確認して最適化する必要があります。タイムアウトを回避するために、サンプル数を減らして実行時間を短縮し、効率的に処理を行いたいと思います。
>
> **再実行による出力確認**
>
> 「build_daily_common_returns」も再度実行して、出力を確認する必要があるかもしれません。再実行の際に出力がどのようになるかを確認したいのですが、この処理をどう進めるかを決めるため、試してみるべきです。
>
> **更新日の共通リターンを計算**
>
>
> **タイムアウト問題の調査**
>
> タイムアウトが続いているので、インタラクティブに実行して進行状況を確認する必要があるかもしれません。出力がバッファリングされている可能性があります。`python -u`で小さなタイムアウトを使用して進行状況を確認し、問題の原因を特定してみます。
>
> **実行中の進行状況確認**
>
>
> **サンプルデータ生成の最適化**
>
> タイムアウト問題が発生しています。サンプルデータ生成が遅く、12年間の120銘柄をループ処理する際、膨大なDataFrameが生成され、特にFPEとSECを処理する際に遅くなります。`price_lookup`を使用してクローズ価格を前もって保存するか、`prices_wide`を作成して処理を最適化すべきです。
>
> **イベントループの最適化**
>
> `dates.searchsorted(fpe, side='right')-1` を使ってイベントループを最適化する方法を実装すべきですね。また、`fpe` の頻度に関する警告も扱う必要があります。サンプル生成コードを更新し、`price_arrays` 辞書を利用してデータを効率的に取得するように変更します。
>
> **パフォーマンス向上のためサンプルデータ生成の最適化**
>
>
> **バグ修正とポジションの調整**
>
> `common_pnl`の出力で列インデックスが日付ではなく、問題が発生しています。`reset_index`前に`out.index.name="date"`を設定して修正が必要です。さらに、業界ごとの中立化処理でイベントが少ない日にポジションがゼロにならないよう、市場の中立化を優先し、業界別調整は選択的に行います。
>
> **中立化処理の調整と出力の修正**
>
> 業界ごとにアクティブな銘柄が1つ以上のときだけ業界中立化を行うように修正します。全体では市場中立化後、業界の平均を引いた後に再度市場中立化を行います。出力が切り取られていますが問題ないので、`reset_index`部分も修正が必要です。
>
> **パッチの実装と修正**
>
>
> **出力パスの修正と整理**
>
> スクリプトは現在実行されており、出力が`/jp_earnings_strategy_output`に保存されているが、これは実行元ディレクトリが原因の可能性があります。セルフコンテナ内で出力されるのを防ぐために、出力ディレクトリを`/mnt/data/jp_earnings_strategy_output`として設定するのが良いかもしれません。
>
> **修正出力パスと警告抑制**
>
>
> **ノートブックの作成とMarkdownの改善**
>
> スクリプトからノートブックを作成する際、Jupytextの使用が考えられますが、インストールされていないかもしれません。セルの区切り（`# %%`）を解析し、Markdownセルを含める方法を検討中です。上部にタイトルを置き、実装概要やデータスキーマに関するリッチなMarkdownを追加したいと思います。
>
> **Converting script to Jupyter notebook with markdown and code cells**
>
>
> **ノートブックの構造確認**
>
> ノートブックの構造を確認するために、実行してみるかもしれません。デフォルトのサンプルデータと同じコードが使用されているため、すでにスクリプトを実行しています。ただ、ノートブックは最初に紹介部分があり、その後にコードセルがありますが、最初のセルに「# This cell marker source...」が含まれているか確認しましょう。
>
> **Inspecting first few cells of notebook**
>
>
> **ノートブック実行の確認**
>
> ノートブックをnbconvertを使って実行する必要があるかもしれません。実行は問題なく行われるはずですが、非対話型環境では`plt.show()`が大丈夫かもしれませんね。スクリプトの実行はおおよそ100秒以内で完了しますが、念のため実行時間を300秒に設定してみようと思います。
>
> **実行可能なノートブックの変換**
>
>
> **ノートブックのタイムアウトとサンプルデータ調整**
>
> nbconvertが420秒でタイムアウトしたのは、表示の多さやルートディレクトリへの書き込みが原因かもしれません。サンプルデータを小さくしてデフォルトで高速に動作させる必要があります。`sample_n_stocks`を60、`sample_n_industries`を6に設定し、2016年から開始すると良さそうです。十分な訓練期間を確保できるので、実データに合わせた設定に変更する予定です。
>
> **Configuring notebook performance for testing**
>
>
> **ノートブックを再生成する必要がある**
>
> パッチを適用した後、ノートブックを再生成する必要があります。これにより、変更が反映され、正しく動作するか確認できます。
>
> **Regenerating notebook after patch**
>
>
> **ノートブックを小さなデータで実行する必要があるかも**
>
> 今、ノートブックを小さめのデータで実行して、120秒の制限を試してみる必要があります。これにより、動作の早さを確認して、問題が解決しているかを見極めることができるかもしれません。
>
> **ノートブック実行と変換**
>
>
> **最終ノートブックを実行したか未実行かを選ぶ**
>
> ノートブックは実行されたので、ユーザーにどちらの形式を提供するか決める必要があります。完成版として実行されたノートブックを提供するのが良さそうですが、コードのみの未実行ノートブックも選べるようにした方がいいかもしれません。最終的に実行されたノートブックを「jp_lseg_earnings_strategy_implemented.ipynb」として提供する予定です。
>
> 思考時間: 19m 15s

実装済みです。以下のNotebookに、日本株・LSEG前提の一気通貫実装を入れました。

[日本株 LSEG 決算戦略 Notebook をダウンロード](sandbox:/mnt/data/jp_lseg_earnings_strategy_implemented.ipynb)

このNotebookは、サンプルデータ生成モードで `Restart & Run All` 済みです。実データでは、冒頭の `CONFIG.use_sample_data = False` に変更し、`CONFIG.data_dir` 配下に以下の正規化済みLSEGエクスポートを置いて実行してください。

- `security_master`
- `prices_daily`
- `earnings_events`
- `fundamentals_quarterly`

実装内容は、Guoのnewsy monthパラメータ圧縮シグナル、Guo-Wachterのnewsy→repetitive継続／repetitive→次newsy反転シグナル、Frazziniのニュース×Capital Gains Overhang相互作用を統合したものです。`Paper4_Guo.pdf` `ssrn-5268329.pdf` `The Disposition Effect and Underreaction to news - Frazzini.pdf`

LSEGについては、Notebook内では本番用に**canonical export方式**を主経路にし、`lseg.data` のライブ取得部分はスケルトンとして入れています。LSEG Data Library for PythonはDesktop SessionまたはPlatform Sessionで接続でき、`get_history()` は価格履歴だけでなくFundamental/Reference data historyも取得できる設計です。ただし、実際のフィールド名は契約・Workspace環境・Data Item Browserで確認が必要なので、Notebookではベンダー固有フィールドを固定せず、正規化テーブルに落とす方式にしています。([LSEG Developers](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation)) ([Refinitiv](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html))

Notebook内で実装済みの主な機能は以下です。

1. 日本株向けの決算月レジーム  
   `Jan/Apr/Jul/Oct` をfresh/news月、`Feb/May/Aug/Nov` をheavy/repetitive月として初期設定しつつ、実際の `announcement_datetime - fiscal_period_end` から定量的newsinessも計算します。

2. 決算ニュース生成  
   EPS surprise、決算日前後CAR、hybrid newsを選択可能です。

3. 共通成分／固有成分分解  
   同業早期発表企業のニュースを使って `common_news_pre` を作り、個別銘柄ニュースから控除して `idio_news` を作ります。

4. TurnoverベースCGO  
   Frazziniの保有明細ベースCGOを本番拡張可能な形にしつつ、現実的な初期実装としてturnoverベースCGOとResidual CGOを実装しています。

5. Frazzini型イベントモデル  
   $$
   D_{i,e}=\eta_{i,e}\max\{0,\operatorname{sgn}(\eta_{i,e})G^\perp_{i,e^-}\}
   $$
   を計算し、expanding ridgeまたはデータ不足時のrank heuristicで個別銘柄固有リターンを予測します。

6. Guo型共通成分モデル  
   $$
   X^{PC}_{g,m}=\sum_{j=1}^{4}r^{ex}_{g,N(m,j)}
   $$
   とnewsiness交差項を使って、業種月次リターンの継続／反転を予測します。

7. Guo-Wachter型相関無視モデル  
   $$
   X^{CN}_{g,m}
   =
   \begin{cases}
   r^{ex}_{g,N_q},&m=R_q,\\
   -r^{ex}_{g,R_{q-1}},&m=N_q,\\
   0,&m=T_q.
   \end{cases}
   $$
   を実装し、ROE similarityによる拡張項も入れています。

8. 2スリーブ・バックテスト  
   Idiosyncratic sleeveはイベント単位、Common sleeveは業種月次単位で構築し、コスト控除後P&L、ドローダウン、performance summary、latest signalsを出力します。

実データ接続後に最初に確認すべき箇所は、Notebook冒頭の `REQUIRED_SCHEMAS` と `CONFIG` です。特に `announcement_datetime`、`total_return`、`mcap`、`shares_out`、`actual_eps`、`consensus_eps` の定義がpoint-in-timeで揃っているかを確認してください。

---

**Sources:**

- [https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation](https://developers.lseg.com/en/api-catalog/lseg-data-platform/lseg-data-library-for-python/documentation)
- [https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html](https://cdn.refinitiv.com/public/lseg-lib-python-doc/2.0.0.2/book/en/sections/access-layer/access/get-history-function.html)



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)