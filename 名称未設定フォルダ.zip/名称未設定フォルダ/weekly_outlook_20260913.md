# Sector Gamma 週次見通し・リバランス案 — 2026年9月13日

**データ基準:** 2026年9月11日米国引け / 2026年9月13日JST更新  
**振り返り期間:** 2026年9月4日引け → 9月11日引け  
**見通し期間:** 2026年9月14日 → 9月18日  
**対象:** S&P 500 11セクターETF + IEF（米国7–10年国債）

> 本資料は研究・モデル運用のためのもので、個別の投資助言ではない。GEXは公開オプションチェーンからcallを正、putを負として計算した需給プロキシであり、実際のディーラーポジションを直接観測したものではない。損益はETFの配当調整済み終値によるモデル計算で、外部記事のセクター指数騰落率はクロスチェックに用いる。

## 結論

基本提案は、**株式を59.44%から57.48%へ1.96ポイント減らし、IEFを40.56%から42.52%へ増やす**。60/40基準比では株式−2.52ポイント、IEF＋2.52ポイントである。片道売買回転率は2.38%。

重要なのは、今週は11セクターすべてのモデル判断が**Neutral**で、株式内のActive Weightが0になったことである。つまり、各セクターは株式バケット内でベンチマーク比率へ戻し、セクター選択リスクをいったん解消する。各セクターのポートフォリオ比率が60/40基準を下回るのは、個別のUnderweight判断ではなく、株式バケット全体を57.48%へ縮めた結果である。

判断の中心は次の四点である。

1. **前回提案は−3.26bp負けた。** 60/40基準は−1.046%、戦術配分は−1.079%。XLV Overweightが−4.03bp、IEF Overweightが−0.75bpとなり、XLY・XLI・XLP Underweightの合計＋1.48bpを打ち消した。
2. **インフレと原油が再び金利を押し上げた。** 8月CPIは前月比＋0.4%・前年比＋3.4%、PPIは前月比＋0.4%・前年比＋5.4%。原油は週間＋9.12%、9月11日の10年国債利回りは4.96%まで上昇した。[BLS CPI](https://www.bls.gov/news.release/cpi.nr0.htm) / [BLS PPI](https://www.bls.gov/news.release/archives/ppi_09102026.htm) / [LPL週間実績](https://www.lpl.com/research/blog/weekly-market-performance-september-11-2026.html) / [米財務省](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
3. **株式オプションの強気幅が狭い。** Adjusted ScoreがプラスなのはXLE・XLV・XLBの3セクターだけで、株式のPositive Breadthは15.58%。負GammaはXLK・XLF・XLC・XLI・XLY・XLU・XLPの7セクターである。しかも全11セクターがHard Ruleに抵触し、Overweightを許可できない。
4. **IEFは絶対的な強気ではなく、株式に対する相対的な退避先である。** オプションAdjusted Scoreは＋0.143だが、BEIオーバーレイは−0.305、75/25合成後は＋0.031にとどまる。それでも株式Composite Scoreが−0.246と弱いため、12資産内の相対配分としてIEFを42.52%へ小幅増額する。

## 先週の振り返り

### 市場で確認された事実

- S&P 500は週間−0.70%、Dowは−1.42%、Nasdaqは−0.52%、Russell 2000は−2.22%。セクターではEnergy＋1.99%、Communication Services＋1.42%が上位、Health Care−3.45%、Materials−2.56%、Industrials−1.54%が下位だった。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-september-11-2026.html)
- 8月CPIは前月比＋0.4%、前年比＋3.4%。ガソリン＋3.9%、エネルギー＋2.1%、住居費＋0.3%。食品・エネルギー除くコアは前月比＋0.3%、前年比＋2.4%だった。[BLS](https://www.bls.gov/news.release/cpi.nr0.htm)
- 8月PPIは前月比＋0.4%、前年比＋5.4%。財は＋1.1%、サービスは＋0.1%、エネルギーは＋4.2%、ディーゼル燃料は＋24.1%。企業の投入・物流コスト圧力が残った。[BLS](https://www.bls.gov/news.release/archives/ppi_09102026.htm)
- 原油は週間＋9.12%。Brentは週中に110ドル近くまで上昇した後、金曜に2.8%下落して104.61ドル。9月11日は株式が反発したが、2年4.62%、10年4.97%近辺と高金利が続いた。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-september-11-2026.html) / [AP市場報道](https://apnews.com/article/financial-markets-stocks-oil-iran-war-bonds-rates-8c3272812f5e9b9238c6a3301921c17a)
- Oracleは売上＋30%、Cloud売上＋62%、IaaS＋121%、RPO 6,640億ドルを発表した。一方、設備投資増によりフリーキャッシュフローは−50億ドル。Adobeは売上＋13%、AI-first ARR＋150%で通期目標を引き上げた。AI需要は強いが、資本負担と高金利を同時に評価する局面である。[Oracle公式](https://investor.oracle.com/investor-news/news-details/2026/Oracle-Announces-Q1-Results-Driven-by-Triple-Digit-Growth-in-Cloud-Infrastructure-Revenues/default.aspx) / [Adobe公式](https://news.adobe.com/news/2026/09/adobe-q3fy26-financial-results)

### 前回提案の実績

60/40基準は**−1.046%**、戦術配分は**−1.079%**、超過収益は**−3.26bp**だった。モデル基準は株式60%・IEF40%で、株式部分も11セクターETFの固定ウェイトであるため、S&P 500単体の週間騰落率とは一致しない。

| ETF | 前回判断 | ETF騰落率 | Active寄与 | 評価 |
|---|---|---:|---:|---|
| XLY | Underweight | −1.70% | **＋0.64bp** | 消費裁量の弱さを減額で回避 |
| XLI | Underweight | −1.65% | **＋0.57bp** | 景気敏感・負Gammaの弱さを回避 |
| XLP | Underweight | −1.42% | ＋0.27bp | コスト圧力下の生活必需品を減額 |
| XLF | Neutral | −1.46% | ＋0.17bp | 小幅アンダー分が寄与 |
| XLU | Neutral | −1.60% | ＋0.10bp | 株式バケット縮小分が寄与 |
| XLB | Neutral | −2.84% | ＋0.03bp | ほぼ中立 |
| XLRE | Neutral | −1.16% | ＋0.01bp | ほぼ中立 |
| XLE | Neutral | ＋1.69% | −0.04bp | 原油高をわずかに取り切れず |
| XLK | Neutral | ＋0.21% | −0.04bp | ほぼ中立 |
| XLC | Underweight | ＋0.51% | **−0.19bp** | 上昇セクターを減額していた |
| IEF | Overweight | −1.34% | **−0.75bp** | インフレ・金利上昇で逆風 |
| XLV | Overweight | −3.55% | **−4.03bp** | 最大の失敗。ディフェンシブ期待が機能せず |

改善点は、**正Gammaやディフェンシブ性だけでOverweightを継続しないこと**である。XLVは前週の首位スコアから急落し、IEFもBEI上昇に負けた。今週は全セクターのHard Ruleを優先して株式内を中立化し、IEFの増額も＋2.52ポイントに限定する。

## 金利・BEIとIEF

### 確認された事実

- 9月4日から11日に、2年国債利回りは4.37%→4.63%、5年は4.54%→4.78%、7年は4.65%→4.87%、10年は4.78%→4.96%。短中期を中心にベア型の金利上昇となり、IEFは週間−1.34%だった。[米財務省](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- 5年BEIは2.40%、10年BEIは2.36%。5営業日変化は＋3bp/＋1bp、40/60加重BEIは2.376%、5日＋1.8bp、20日＋14.8bp。インフレ期待の上向きはIEFに逆風である。[FRED 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [FRED 10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- FOMCは9月15–16日。前回7月会合の政策金利レンジは3.50–3.75%で、3人の参加者が25bp利上げを支持した。今週の市場では25bp利上げが中心シナリオとして織り込まれている。[Federal Reserve](https://www.federalreserve.gov/monetarypolicy.htm) / [7月FOMC議事要旨](https://www.federalreserve.gov/monetarypolicy/fomcminutes20260729.htm) / [Kiplinger経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)

### モデル推論と調整方針

- IEFは91.01で、Gamma Flip 90.60の上だが20日線92.39・50日線92.63を下回る。Call/Put Wallはいずれも92、7日1σレンジは90.24–91.78、Net GEXは＋90.2百万。
- オプションAdjusted Score＋0.143に対し、BEIオーバーレイ−0.305。合成スコア＋0.031は「IEFそのものが強い」信号ではない。株式Composite Score−0.246との相対差が、IEF42.52%の根拠である。
- Vanna集中78.9%、Charm集中96.2%と高く、FOMC後のIV低下と時間経過でヘッジフローが急変しやすい。90.60/90.24割れでは増額を中止し、91.78–92を終値で回復して初めて42.52%を完成する。
- したがってIEFを動かす基本方向は**増額**だが、一括ではなく条件付きとする。利上げ＋タカ派SEPで10年金利とBEIが再上昇する場合は40.5–41.5%にとどめる。利上げでも長期インフレ期待が低下しIEFが92を回復する場合は42.52%、ハト派サプライズで92.63も回復する場合は43–44%を許容する。

## リバランス案

| ETF | 新配分 | 前回配分 | 売買 | 60/40基準比 | 今週の判断 |
|---|---:|---:|---:|---:|---|
| IEF | **42.52%** | 40.56% | **＋1.96pt** | **＋2.52pt** | Overweight |
| XLK | **18.89%** | 19.54% | −0.64pt | −0.83pt | Neutral（株式内） |
| XLF | **7.24%** | 7.44% | −0.20pt | −0.32pt | Neutral（株式内） |
| XLC | **5.91%** | 5.80% | ＋0.12pt | −0.26pt | Neutralへ戻す |
| XLY | **5.69%** | 5.56% | ＋0.13pt | −0.25pt | Neutralへ戻す |
| XLV | **5.46%** | 6.83% | **−1.37pt** | −0.24pt | Overweightを解消 |
| XLI | **5.17%** | 5.05% | ＋0.12pt | −0.23pt | Neutralへ戻す |
| XLP | **3.04%** | 2.98% | ＋0.06pt | −0.13pt | Neutralへ戻す |
| XLE | **2.30%** | 2.38% | −0.08pt | −0.10pt | Neutral |
| XLU | **1.44%** | 1.43% | ＋0.00pt | −0.06pt | Neutral |
| XLB | **1.21%** | 1.25% | −0.04pt | −0.05pt | Neutral |
| XLRE | **1.15%** | 1.19% | −0.04pt | −0.05pt | Neutral |

合計100.00%、株式57.48%、IEF42.52%。株式内のActive Weight合計は0、片道売買回転率は2.38%。XLC・XLY・XLI・XLPの買いは強気転換ではなく、前回Underweightの解消である。XLK・XLFなどの売りも個別Underweightではなく、株式バケット縮小に伴う比例調整である。

### 段階執行

1. **9月14–15日、50%:** XLV Overweightの大半を解消し、XLC・XLY・XLI・XLPを株式内ベンチマークへ戻す。IEFは約41.54%まで増やす。FOMC前に42.52%を完成させない。
2. **9月16日、25%:** 小売売上・輸入物価とFOMC声明後、IEFが90.60を維持し、5年BEIが2.40%を明確に上抜かなければ42.03%程度まで進める。XLKは190.47回復、XLFは57.39回復の有無も確認する。
3. **9月17–18日、25%:** 住宅着工・失業保険・鉱工業生産を確認し、IEFが91.78–92を終値で回復すれば42.52%へ完成。90.24割れなら追加を取り消して40.5–41.5%、92.63超なら43–44%を上限に再評価する。

## 各セクターとIEFのポジション根拠

以下の数値は9月11日終値と9月13日JST取得のオプションチェーンに基づく。「マクロ・ボトムアップ」は事実をイベントへ対応づけ、「判断」はモデル推論を示す。

### XLE — Energy: Neutral 2.30%

- **オプション・価格:** Adjusted Score＋0.123でセクター首位、Net GEX＋80.4百万。65.14はFlip 63.03を上回るがCall Wall 65付近。レンジ62.53–67.75、20日＋6.68%、60日＋18.51%。短期GEX集中38.4%でHard Ruleに抵触。
- **マクロ・ボトムアップ:** 原油週間＋9.12%と供給不安は収益に追い風だが、Brent 100ドル超は需要破壊、インフレ、金利上昇を通じて逆風も増やす。FOMCと鉱工業生産が需要面の確認材料。
- **判断:** 強いがCall Wall上で追わない。63.03維持ならNeutral、62.53割れで減額、67.75超かつ短期集中低下で初めてOverweight候補。

### XLV — Health Care: Neutral 5.46%

- **オプション・価格:** Adjusted Score＋0.077、Net GEX＋26.9百万。165.36はFlip 162.19の上だが20日線170.89を下回る。レンジ160.19–170.53、短期GEX集中41.8%。
- **マクロ・ボトムアップ:** CPIの医療項目だけでなく、保険償還・医薬品価格・病院コストを確認する必要がある。先週ETF−3.55%、LPLのHealth Care指数−3.45%はディフェンシブ需要が機能しなかった事実。
- **判断:** 前回Overweightを解消する。162.19を守り170.53/170.89を回復するまではNeutral。160.19割れは下方再評価。

### XLB — Materials: Neutral 1.21%

- **オプション・価格:** Adjusted Score＋0.069、Net GEX＋4.7百万。50.95はFlip 50.36近傍で、20日線52.50を下回る。レンジ47.31–54.59、IV/実現Vol比3.38、短期GEX集中39.8%。
- **マクロ・ボトムアップ:** PPIの財＋1.1%は価格転嫁と投入コストの双方を示す。住宅着工、建築許可、Lennar決算、鉱工業生産が建材・化学・金属需要を映す。
- **判断:** 高いIVプレミアムとFlip近傍のためNeutral。52.50回復までは増額せず、50.36/47.31を下値監視。

### XLRE — Real Estate: Neutral 1.15%

- **オプション・価格:** Adjusted Score−0.030。43.42はFlip 43.16とPut Wall 43に近く、Net GEXは＋0.2百万にすぎない。レンジ42.07–44.77、20日線44.43を下回る。
- **マクロ・ボトムアップ:** 10年4.96%と住宅ローン金利上昇が還元利回り・借換え・住宅取引を圧迫する。NAHB、着工・許可、Pending Home Sales、Lennarが一週間を通じた確認材料。
- **判断:** 43/42.07を守り、44.43–44.77を回復するまではNeutral。FOMC後の長期金利低下が伴えば上方再評価。

### XLK — Information Technology: Neutral 18.89%

- **オプション・価格:** Adjusted Score−0.053、Net GEX−24.9百万。187.67はFlip 190.47とCall Wall 190の下、Put Wall 185の上。レンジ179.63–195.71。短期GEX集中46.1%。
- **マクロ・ボトムアップ:** OracleのIaaS＋121%、AdobeのAI-first ARR＋150%はAI需要を裏付ける。一方、Oracleの負のFCFは大規模設備投資の資金負担を示し、10年金利5%近辺ではバリュエーション感応度が高い。
- **判断:** 良い決算でも負Gamma・Flip下なのでNeutral。190.47回復で改善、185割れで179.63方向の増幅を警戒。FOMC後に195.71を越えるまでOverweightしない。

### XLF — Financials: Neutral 7.24%

- **オプション・価格:** Adjusted Score−0.125、Net GEX−20.4百万。57.25はFlip 57.39直下、Call Wall 58、Put Wall 56、レンジ55.78–58.72。短期GEX集中48.7%。
- **マクロ・ボトムアップ:** 利上げは貸出利回りを支えるが、2年金利の週間＋26bpは調達コストを押し上げる。FOMCの政策経路、失業保険、住宅指標を信用コストと貸出需要の両面で読む。
- **判断:** 56–55.78を守ればNeutral。57.39/58回復で安定化、55.78割れならUnderweight候補。

### XLC — Communication Services: Neutral 5.91%

- **オプション・価格:** Adjusted Score−0.211、Net GEX−30.4百万。112.60はFlip 117.18、Call Wall 115の下。レンジ107.59–117.61。短期GEX集中78.5%、Vanna集中71.0%、Charm集中98.8%とイベント後フローが大きい。
- **マクロ・ボトムアップ:** 先週の外部セクター指数は＋1.42%、ETFも＋0.51%で前回Underweightは逆効果だった。広告・プラットフォーム収益には小売売上と消費者需要、評価には実質金利が効く。
- **判断:** UnderweightをNeutralへ戻すが、積極的には増やさない。115、次いで117.18–117.61の回復をOverweight条件とする。

### XLI — Industrials: Neutral 5.17%

- **オプション・価格:** Adjusted Score−0.337、Net GEX−173.6百万で12資産中最大の負Gamma。172.37はFlip 184.47、20日線177.58の下。レンジ164.94–179.80、60日ドローダウンが7%を超えHard Ruleに抵触。
- **マクロ・ボトムアップ:** 高いPPI、燃料・物流費、金利が設備投資採算を圧迫する。Empire/Philly Fed、住宅着工、鉱工業生産、設備稼働率で受注と生産を確認する。
- **判断:** 前回Underweightは＋0.57bp寄与したが、今週はルールに従い株式内Neutralへ戻す。177.58–179.80回復までは上積みしない。164.94割れは再Underweight条件。

### XLY — Consumer Discretionary: Neutral 5.69%

- **オプション・価格:** Adjusted Score−0.344、Net GEX−98.9百万。112.96はFlip 133.49を大きく下回り、Call Wall 120、Put Wall 110、レンジ107.86–118.06。短期GEX集中55.6%。
- **マクロ・ボトムアップ:** ガソリン高、利上げ、住宅ローン金利は可処分所得と耐久財需要に逆風。水曜の小売売上、Lennar、木曜のCarnivalが住宅・旅行・裁量消費の実需を映す。[Kiplinger決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)
- **判断:** Underweightを機械的にNeutralへ戻すが、110/107.86を割れば再び減額。118.06–120回復まではOverweight不可。

### XLU — Utilities: Neutral 1.44%

- **オプション・価格:** Adjusted Score−0.367、Net GEX−44.8百万。42.39はFlip 43.52の下、Put Wall 42近傍。レンジ41.24–43.54、60日ドローダウンが8%を超える。
- **マクロ・ボトムアップ:** 電力需要の構造的支援はあるが、5%近い長期金利と燃料費上昇が資本コスト・配当相対価値を圧迫する。FOMC後の10年金利が最重要。
- **判断:** 42/41.24を守ればNeutral。43.52回復と長期金利低下が揃うまで増額しない。

### XLP — Consumer Staples: Neutral 3.04%

- **オプション・価格:** Adjusted Score−0.379で最下位、Net GEX−71.6百万。83.38はFlip 90.47の下でPut Wall 83近傍。レンジ78.04–88.72、IV/実現Vol比3.12、短期GEX集中58.5%。
- **マクロ・ボトムアップ:** 食品・エネルギー・ディーゼル価格の上昇は物流・包装・原材料コストを押し上げる。Krogerは利益予想を上回ったが、基礎売上成長見通しを引き下げており、価格転嫁後の数量が課題である。[AP](https://apnews.com/article/financial-markets-stocks-oil-iran-war-bonds-rates-8c3272812f5e9b9238c6a3301921c17a)
- **判断:** 前回UnderweightをNeutralへ戻すが、83/78.04割れで再減額。86回復まではディフェンシブ性だけで上積みしない。

### IEF — 7–10年米国国債: Overweight 42.52%

- **オプション・価格:** Adjusted Score＋0.143、Net GEX＋90.2百万。91.01はFlip 90.60の上、Wall 92の下。レンジ90.24–91.78、20/50日線92.39/92.63の下。
- **マクロ・BEI:** 5年/10年BEI 2.40%/2.36%、20日加重変化＋14.8bpでインフレ逆風。FOMCの利上げ幅より、SEPと議長会見が示す終着金利、インフレ期待、10年金利の反応が重要。
- **判断:** 株式に対する相対Overweightであり、強いDuration買いではない。90.24割れなら40.5–41.5%、91.78–92回復なら42.52%、92.63回復とBEI低下が揃えば43–44%。

## 日別イベントとポジション対応

[Kiplinger経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)と[決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)を基準に整理する。

| 日付 | 主なイベント（米東部時間） | 主なETF | ポジションへの読み替え |
|---|---|---|---|
| 9/14 月 | 主要経済指標なし、Dave & Buster's決算 | XLY | FOMC前の大口方向賭けを避け、第1段階のみ |
| 9/15 火 | Empire State製造業、Trip.com決算、FOMC初日 | XLI, XLB, XLY, IEF | 製造業の価格・受注と旅行需要を確認。IEF増額は半分で止める |
| 9/16 水 | 小売売上、輸入物価、企業在庫、NAHB、FOMC声明・SEP・会見、Lennar決算 | IEF, XLK, XLF, XLRE, XLY, XLB | 最大イベント。物価・消費・政策金利・住宅を同時評価し第2段階を判断 |
| 9/17 木 | 失業保険、Philly Fed、住宅着工・許可、Pending Home Sales、Carnival決算 | XLF, XLI, XLB, XLRE, XLY | FOMC後の金利反応が実体指標と整合するか確認 |
| 9/18 金 | 鉱工業生産、設備稼働率、Bowman理事講演、景気先行指数 | XLI, XLB, XLE, XLU, IEF | 生産・電力・燃料需要とFedの追認を確認し最終配分 |

## Vanna / Charmとオプション運営

- **負Gamma:** XLK、XLF、XLC、XLI、XLY、XLU、XLP。特にXLI−173.6百万、XLY−98.9百万、XLP−71.6百万は、FOMC後の価格変動を増幅しやすい。
- **Flip/Wall近傍:** IEFはFlipの0.45%上でWall 92の下。XLKはFlip/Call Wall 190付近の下、XLFはFlip 57.39直下、XLREはFlip 43.16とPut Wall 43の近くにある。
- **高Charm:** IEF96.2%、XLC98.8%、XLY94.0%、XLI93.1%、XLP90.9%。FOMC通過後の時間価値減少に伴うヘッジ調整が、現物の追随売買を誘発しうる。
- **高Vanna:** IEF78.9%、XLC71.0%が突出する。イベント後のIV低下で価格がWallを越える可能性があるため、場中の一度の突破ではなく終値と翌日の継続を確認する。
- **実装:** 現物配分の段階調整を主とし、オプションを使う場合はFOMC前の短期プットスプレッドなど損失限定型に絞る。IV/実現Vol比が高いXLB・XLPでは、単純なオプション買いを避ける。

## シナリオ

### 中立シナリオ — 株式57.48% / IEF42.52%

Fedは25bp利上げするが追加経路をデータ依存とし、10年金利は4.8–5.1%、BEIは2.35–2.45%。IEFは90.24–92、XLKは179.63–195.71。全セクターNeutral、IEF小幅Overweightを段階的に完成する。

### ディスインフレ・ハト派シナリオ — IEF43–44%、株式56–57%

小売・輸入物価が弱く、SEPが追加利上げを強く示さず、5年BEIが2.35%未満へ低下。IEFが92.63を回復した場合、IEFを43–44%へ追加し、負GammaでFlip下のXLI・XLY・XLP・XLCから比例調達する。

### 成長・AI強気シナリオ — 株式60–62%、IEF38–40%

小売・製造業が底堅い一方、インフレ期待が上がらず、XLKが195.71、XLCが117.61、XLIが179.80を終値で上抜く。IEFを38–40%へ下げ、Hard Rule解除を確認したセクターからOverweightを再開する。

### スタグフレーション・弱気シナリオ — IEFも無条件には増やさない

輸入物価とBEIが上昇し、タカ派FedでIEFが90.24を割る一方、XLK179.63、XLI164.94、XLY107.86も割る。株式と中期債の同時安となるため、12資産内ではIEFを40.5–41.5%に抑える。現金・短期債を許容する別枠なら、全額をIEFへ逃がさず待機資金を置く。

## 監視水準

| ETF | 配分 | Adjusted Score | Spot | Flip | Call Wall | Put Wall | 7日1σレンジ | Gamma / 判断 |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| IEF | 42.52% | ＋0.031（BEI調整後） | 91.01 | 90.60 | 92 | 92 | 90.24–91.78 | 正 / OW |
| XLE | 2.30% | ＋0.123 | 65.14 | 63.03 | 65 | 60 | 62.53–67.75 | 正・短期集中 / Neutral |
| XLV | 5.46% | ＋0.077 | 165.36 | 162.19 | 170 | 160 | 160.19–170.53 | 正・Flip近傍 / Neutral |
| XLB | 1.21% | ＋0.069 | 50.95 | 50.36 | 55 | 48 | 47.31–54.59 | 正・Flip近傍 / Neutral |
| XLRE | 1.15% | −0.030 | 43.42 | 43.16 | 45 | 43 | 42.07–44.77 | 正小・Flip/Put近傍 / Neutral |
| XLK | 18.89% | −0.053 | 187.67 | 190.47 | 190 | 185 | 179.63–195.71 | 負・Flip下 / Neutral |
| XLF | 7.24% | −0.125 | 57.25 | 57.39 | 58 | 56 | 55.78–58.72 | 負・Flip近傍 / Neutral |
| XLC | 5.91% | −0.211 | 112.60 | 117.18 | 115 | 104 | 107.59–117.61 | 負・高Vanna/Charm / Neutral |
| XLI | 5.17% | −0.337 | 172.37 | 184.47 | 180 | 165 | 164.94–179.80 | 負大・Drawdown / Neutral |
| XLY | 5.69% | −0.344 | 112.96 | 133.49 | 120 | 110 | 107.86–118.06 | 負・Flip下 / Neutral |
| XLU | 1.44% | −0.367 | 42.39 | 43.52 | 44 | 42 | 41.24–43.54 | 負・Put近傍 / Neutral |
| XLP | 3.04% | −0.379 | 83.38 | 90.47 | 86 | 83 | 78.04–88.72 | 負・Put近傍 / Neutral |

## データ・外部参照

- モデル配分: `outputs/tables/consistent_12asset_allocation.csv`
- 前週寄与度: `outputs/tables/consistent_12asset_weekly_attribution.csv`
- オプション指標: `outputs/tables/consistent_option_metrics.csv`
- IEF・BEI: `outputs/tables/ief_dashboard.csv`, `outputs/tables/bei_overlay.csv`
- ダッシュボード: `outputs/dashboard/sector_gamma_dashboard.html`
- 実行済みNotebook: `outputs/executed/main_20260913_executed.ipynb`
- [LPL: 9月11日までの週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-september-11-2026.html)
- [BLS: 8月CPI](https://www.bls.gov/news.release/cpi.nr0.htm) / [8月PPI](https://www.bls.gov/news.release/archives/ppi_09102026.htm)
- [AP: 9月11日の市場・原油・金利](https://apnews.com/article/financial-markets-stocks-oil-iran-war-bonds-rates-8c3272812f5e9b9238c6a3301921c17a)
- [米財務省: 日次イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- [FRED: 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- [Federal Reserve: FOMC](https://www.federalreserve.gov/monetarypolicy.htm)
- [Kiplinger: 9月14–18日の経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar) / [決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)
- [Oracle公式Q1](https://investor.oracle.com/investor-news/news-details/2026/Oracle-Announces-Q1-Results-Driven-by-Triple-Digit-Growth-in-Cloud-Infrastructure-Revenues/default.aspx) / [Adobe公式Q3](https://news.adobe.com/news/2026/09/adobe-q3fy26-financial-results)

## モデル検証メモ

- Notebookは非表示状態に依存せず上から完走し、11セクターETF・SPY・IEFの13チェーン、計19,622行を取得した。
- 既存検証、前週検証、BEI、保存先、全Plotly図を含む**205/205項目がPASS**。有限なGreeks、配分合計100%、株式内Active合計0、parquet・CSV・HTML保存を確認した。
- 前週検証は12資産、期間2026年9月4日→11日。`戦術収益率 − 基準収益率 = 超過収益率`（−1.079% − (−1.046%) = −0.033%）を確認した。
- `outputs/tables/price_fallback.csv`はヘッダーのみで、今回は価格フォールバック未使用。取得不完全なチェーンを正常結果として扱っていない。
