# 2026年10月12–16日：11セクター＋IEF週間見通し

更新日：2026年10月12日JST（米国市場の寄り付き前）。価格・マクロ・オプションの評価基準日は原則10月9日米国引け。先週のペーパー検証は10月2日引けから10月9日引けまで。時刻は特記しない限り米東部時間。

**リバランス提案：CPI前は前回の研究用配分（株式60.25%、IEF39.75%）を据え置く。** 今回のNotebookが算出した新候補は株式61.15%、IEF38.85%だが、オプションIVの異常低下とGamma Flip推定の境界値集中があり、現時点では売買目標として採用しない。10月14日のCPI、15日のPPI・小売売上高と、オプション・チェーン再検証の両方を確認してから変更する。これはイベント前の単なる様子見ではなく、入力品質が壊れた時に配分の連続性を守る判断である。

保有・約定・承認は未入力であり、以下は**DRAFTのペーパーポートフォリオ**である。実口座の損益、売買数量、発注指示ではない。[実行台帳](../tables/v2_latest_run_manifest.csv) / [前回の保存目標](../../data/processed/20261002/v2/SGV2-20261005/20261004T123304930176Z/portfolio_target.csv)

## 先週の振り返り：市場で確認された事実

S&P 500は週間約+1.2%。[LPLの10月9日15:25 ET時点の集計](https://www.lpl.com/research/blog/weekly-market-performance-october-9-2026.html)では、公益・生活必需品・エネルギーが強く、情報技術・資本財が弱かった。これは**セクター指数の途中集計**で、下のETF終値による収益・寄与度の代替ではない。LPLは、中東情勢の報道、AI投資の収益化懸念、原油供給不安、債券反発が相場を揺らしたと整理している。個々のETF変動の原因をこれだけで断定しない。

9月[ISMサービス業PMI](https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/services/september/)は54.9で前月55.4から鈍化した一方、支払価格指数は74.0へ上昇。10月7日公表の[FOMC議事要旨](https://www.federalreserve.gov/monetarypolicy/fomcminutes20260916.htm)は、9月の25bp利上げと、年内追加利上げを妥当と見る参加者が多いことを示した。10月9日の[ミシガン大学消費者心理速報](https://www.sca.isr.umich.edu/)は46.3（9月48.1）、1年先インフレ期待は4.7%（4.6%）、長期は3.5%（3.4%）。成長の粘りと物価圧力、消費者の負担感が並存している。

企業の実績では、[PepsiCo](https://www.pepsico.com/docs/pepsico-5v9wci20/media/Files/investors/q3-2026-earnings-release.pdf)の第3四半期売上高は前年比+5.6%、オーガニック売上+3.1%だが、コア営業利益率は35bp低下した。[Delta](https://ir.delta.com/news/news-details/2026/Delta-Air-Lines-Announces-September-Quarter-2026-Financial-Results/default.aspx)は9月期売上高+16%で需要の強さを示す一方、燃料コストも重要なリスクとしている。XLPの価格転嫁、XLI・XLYの需要、XLEの原油高をそれぞれ別の経路で評価する材料であり、個社実績をETF全体へそのまま外挿しない。

## 前回案の検証（ペーパー、配当調整済みETF終値）

10月4日に保存した**v2 cap_60_40目標を10月2日終値で固定**し、10月9日終値までの12資産の調整後価格騰落率を掛けた。前回目標は**+0.721%**、同時点の時価総額加重セクター60%＋IEF40%基準は**+0.739%**、超過は**−1.78bp**。`目標収益−基準収益＝超過収益`であり、週中リバランス、配当の別払い、税金、手数料、スリッページは含めない。[前回目標](../../data/processed/20261002/v2/SGV2-20261005/20261004T123304930176Z/portfolio_target.csv) / [今回の調整後ETF終値とリターン](../tables/consistent_12asset_weekly_attribution.csv)

| 主な前回Active寄与 | bp | 検証の読み |
|---|---:|---|
| XLU Overweight | +4.55 | ETF+3.97%で最大のプラス |
| XLE Overweight | +2.17 | ETF+3.60%、原油ヘッジ枠が寄与 |
| XLP Underweight | −3.54 | ETF+3.60%の上昇を取り逃した |
| XLY Underweight | −2.15 | ETF+2.55%が逆風 |
| XLF Underweight、XLK Overweight | −2.25 | 金融上昇と技術下落がともに逆風 |
| IEF小幅Underweight | −0.10 | ETF+0.39%に対し若干の取り逃し |

前回案の方向が全面的に外れたわけではなく、XLU・XLEが助けた一方、XLP・XLY・XLFの上昇に対するUnderweightが上回った。`consistent_12asset_weekly_attribution.csv`の`tactical_portfolio_weight`は旧12資産モデルの列なので、このv2検証には**使用していない**。

## 金利・BEIとIEF

[FRED名目10年金利](https://fred.stlouisfed.org/series/DGS10)は10月8日観測で5.22%（5営業日前比−2bp）、[実質10年金利](https://fred.stlouisfed.org/series/DFII10)は同日2.87%（−1bp）。[10年BEI](https://fred.stlouisfed.org/series/T10YIE)は10月9日2.33%（−3bp）、[5年BEI](https://fred.stlouisfed.org/series/T5YIE)は2.34%（−3bp）。観測日が異なる金利を引き算して「10月9日の実質金利」とは呼ばない。BEIは純粋な予想インフレ率ではなく、リスク・流動性プレミアムも含む。[Notebookの観測日一覧](../tables/v2_latest_macro_snapshot.csv)

**推論：** 債券とBEIの小幅低下はIEFの短期的な支えだが、ISM価格指数と消費者のインフレ期待、追加利上げ余地は逆方向の材料。したがって、10月9日IEF終値89.40、先週+0.39%を理由にCPI前にIEFを40%超へ増やさない。他方、異常なオプション入力だけを根拠に新候補38.85%へ減らすこともしない。暫定目標39.75%を維持する。

## 今週の配分案

基準はSPYのセクター時価総額比率×60%＋IEF40%。「暫定目標」は10月4日の品質確認済みスナップショットからの据置案。「10/12機械候補」は10月9日価格と10月12日寄り付き前に取得したチェーンでNotebookが出した**未採用の参考値**。これらは実保有ウェイトではない。12資産の暫定目標合計は100%、株式60.25%・IEF39.75%。[新しい機械目標](../tables/v2_latest_portfolio_target.csv) / [12資産ダッシュボード](../dashboard/sector_gamma_dashboard_v2.html)

| 資産 | 10/2–9 ETF騰落 | 新基準 | 暫定目標＝前回 | 基準比 | 10/12機械候補・未採用 |
|---|---:|---:|---:|---:|---:|
| XLK | −0.52% | 24.27% | **25.40%** | +1.13pt | 26.42% |
| XLY | +2.55% | 5.24% | **4.75%** | −0.49pt | 5.15% |
| XLP | +3.60% | 2.60% | **1.69%** | −0.90pt | 2.10% |
| XLE | +3.60% | 2.04% | **2.69%** | +0.65pt | 2.50% |
| XLF | +2.32% | 6.72% | **6.75%** | +0.03pt | 6.32% |
| XLV | +2.79% | 5.56% | **5.32%** | −0.24pt | 6.03% |
| XLI | −0.41% | 4.52% | **4.01%** | −0.51pt | 4.45% |
| XLC | +0.05% | 5.97% | **5.14%** | −0.83pt | 5.06% |
| XLB | +1.17% | 0.94% | **1.20%** | +0.26pt | 0.00% |
| XLRE | +1.96% | 1.02% | **0.96%** | −0.06pt | 2.18% |
| XLU | +3.97% | 1.13% | **2.34%** | +1.21pt | 0.95% |
| IEF | +0.39% | 40.00% | **39.75%** | −0.25pt | 38.85% |

基準は10月9日の新しいSPYセクター比率で、暫定目標との基準比は**異なる観測日を組み合わせた比較**。10/12機械候補は合計100%、Active合計0、基準比予測Tracking Errorは年率0.58%で、形式検証815件は全件PASS。ただし**形式上のPASSはIVの経済的妥当性を保証しない**。前回目標から機械候補への理論上の片道変更は約4.19%であり、この回転を今すぐ発生させない。[検証結果](../tables/v2_latest_combined_validation_results.csv) / [リスク](../tables/v2_latest_risk_summary.csv)

### 11セクター別の先週の材料と今週の確認点

以下のETF騰落は10月2日引けから9日引け、Active寄与は**前回のv2配分を固定した場合の対60/40超過寄与**である。決算やニュースがETF騰落の何bpを生んだかという因果分解ではない。「寄与の見方」は発表内容からの**条件付き推論**で、未発表の決算結果を先取りしない。ASML・TSMC、AlcoaなどETFの直接保有とは限らない企業は、業界の需要・原価を読む参考材料とする。[ETF騰落](../tables/consistent_12asset_weekly_attribution.csv) / [前回v2配分](../../data/processed/20261002/v2/SGV2-20261005/20261004T123304930176Z/portfolio_target.csv)

- **XLK 25.40%、Overweight。** 先週は[TSMCの9月売上高が前年比+54.6%](https://pr.tsmc.com/english/news/3343)と半導体需要の強さを示した一方、[AI支出の収益化懸念](https://www.lpl.com/research/blog/weekly-market-performance-october-9-2026.html)もあり、ETF−0.52%、前回Active寄与−1.12bp。今週は[14日のASML決算](https://www.investor.asml.com/quarterly-results)と[15日のTSMC決算](https://investor.tsmc.com/english)を確認する。受注・先端工程の利益率・設備投資見通しが強ければXLKにプラスの波及を想定するが、CPI上振れで実質金利も上がれば高PER銘柄には逆風となる。
- **XLY 4.75%、Underweight。** 先週は[消費者心理46.3、現況指数44.7への低下](https://www.sca.isr.umich.edu/)と、[Deltaの売上高+16%](https://ir.delta.com/news/news-details/2026/Delta-Air-Lines-Announces-September-Quarter-2026-Financial-Results/default.aspx)という強弱混在の消費材料。ETF+2.55%で前回Active寄与−2.15bp。今週は[13日のDomino's決算](https://ir.dominos.com/news-releases/news-release-details/dominosr-announces-q3-2026-earnings-webcast)、既存住宅販売、15日の小売売上高を確認する。客数・販売数量の増加ならXLYのUW縮小を検討できるが、名目売上が値上げだけで伸びた場合は慎重姿勢を維持する。
- **XLP 1.69%、Underweight。** 先週は[Constellation Brandsのビール売上+5%、卸から小売への販売量を示すdepletionsは−0.6%](https://ir.cbrands.com/sec-filings/all-sec-filings/content/0000016918-26-000039/stzex991_83120268kearnings.htm)、[PepsiCoのオーガニック売上+3.1%とコア営業利益率−35bp](https://www.pepsico.com/docs/pepsico-5v9wci20/media/Files/investors/q3-2026-earnings-release.pdf)を確認した。ETF+3.60%、前回Active寄与−3.54bp。今週は主要企業の個別決算より14日のCPIと15日の小売売上高で値上げ・数量・原価のバランスを見る。販売数量が維持され価格転嫁が利益率に結びつけばUW縮小に寄与し、原価高だけなら逆風。
- **XLE 2.69%、Overweight。** 先週の中東供給不安に対し、[IEAは10月7日に備蓄約3.25億バレルの放出済みと追加余地を説明](https://www.iea.org/news/statement-by-iea-executive-director-on-meeting-of-iea-member-governments-on-7-october-2026)。ETF+3.60%、前回Active寄与+2.17bp。今週は[14日のIEA石油市場報告](https://www.iea.org/events/oil-market-report-october-2026)、[休日で15日12:00 ETへずれるEIA週間在庫](https://www.eia.gov/petroleum/supply/weekly/schedule.php)、CPIの燃料寄与を見る。供給逼迫・在庫減ならXLEに追い風、備蓄放出や需要下振れなら原油高の巻き戻しがリスク。
- **XLF 6.75%、ほぼ基準並み。** 先週は[10月7日のFOMC議事要旨](https://www.federalreserve.gov/monetarypolicy/fomcminutes20260916.htm)が追加利上げ余地を示し、ETF+2.32%、前回Active寄与−1.13bp。今週は13日のJPM・WFC・C・GS、14日のBAC・MS・BLK、15–16日の地銀決算を確認する。[決算日程](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks) 金利上昇だけで強気とはせず、純利鞘・貸出伸び・信用損失引当・商業不動産エクスポージャーが同時に改善すればプラス、預金調達費や延滞増が上回ればマイナスと見る。
- **XLV 5.32%、小幅Underweight。** 先週は注目度の高い構成企業決算が少なく、消費者心理の悪化と高金利下の防御需要が論点だった。ETF+2.79%、前回Active寄与−0.70bp。今週は[13日のJ&J](https://www.investor.jnj.com/investor-news/news-details/2026/Johnson--Johnson-to-Host-Investor-Conference-Call-on-Third-Quarter-Results/default.aspx)と[UnitedHealth](https://www.unitedhealthgroup.com/newsroom/2026/2026-09-15-uhg-announces-q3-earnings-release-date.html)の決算。前者の医薬品・医療機器売上、後者の医療費率・保険採算がともに改善すればXLVのUW縮小を検討し、一社の好決算だけではセクター全体に外挿しない。
- **XLI 4.01%、Underweight。** 先週は[Deltaの売上高+16%に対して調整後燃料費+62%](https://ir.delta.com/news/news-details/2026/Delta-Air-Lines-Announces-September-Quarter-2026-Financial-Results/default.aspx)と、需要・原価の両面が出た。ETF−0.41%、前回Active寄与+0.26bp。今週は[14日のFastenal決算](https://investor.fastenal.com/news/news-details/2026/Fastenal-Company-Announces-Conference-Call-to-Review-2026-Third-Quarter-Earnings/default.aspx)、15日のJ.B. Hunt、16日の鉱工業生産を確認する。工場向け販売量・貨物量が増え価格上昇を上回ればプラス、燃料・投入費によるマージン圧迫が続けばUWを維持する。
- **XLC 5.14%、Underweight。** 先週は[AI支出の収益化懸念](https://www.lpl.com/research/blog/weekly-market-performance-october-9-2026.html)と弱い消費者心理が広告・プラットフォームの評価材料となり、ETF+0.05%、前回Active寄与−0.03bp。確認した主要決算日程では今週の大型XLC決算は限られ、[Netflixは10月20日発表予定](https://ir.netflix.net/investor-news-and-events/financial-releases/press-release-details/2026/Netflix-to-Announce-Third-Quarter-2026-Financial-Results/default.aspx)。今週はCPIと小売売上高を広告需要・割引率の間接指標として見る。消費数量が弱ければ広告予算に逆風、金利低下なら長期成長株の評価には追い風となりうる。
- **XLB 1.20%、小幅Overweight。** 先週の[RPM決算は売上高+4.8%だったが原材料インフレを警戒](https://www.rpminc.com/media/skmgvfpr/1q27-rpm-earnings-release-final.pdf)。ETF+1.17%、前回Active寄与+0.22bp。今週は15日のPPI、[Alcoa決算](https://investors.alcoa.com/press-releases/press-release-details/2026/Alcoa-Schedules-Third-Quarter-2026-Earnings-Release-and-Conference-Call/default.aspx)、16日の鉱工業生産を確認する。出荷量と価格転嫁が採算を支えればプラス、資源・物流費高が上回れば逆風。新機械候補の0%はIV異常下では採用しない。
- **XLRE 0.96%、ほぼ基準並み。** 先週は名目10年金利が5営業日前比−2bp、ETF+1.96%、前回Active寄与−0.23bp。今週は[13日の既存住宅販売](https://www.nar.realtor/research-and-statistics/housing-statistics/existing-home-sales)、CPI/PPI、[15日のPrologis決算](https://ir.prologis.com/)を確認する。金利低下と賃料・稼働率の維持がそろえばプラス、融資コスト上昇や物流不動産の需要鈍化なら逆風。新機械候補2.18%への増額はオプション再検証前に見送る。[金利データ](../tables/v2_latest_macro_snapshot.csv)
- **XLU 2.34%、Overweight。** 先週は名目金利・BEIが小幅低下し、ETF+3.97%、前回Active寄与+4.55bpで最大のプラス。今週は大手公益企業の決算より14日のCPI・Beige Book、15日のPPIが焦点。金利低下は配当利回りの相対魅力と設備投資資金調達にプラスだが、再インフレと燃料費上昇は逆風。電力需要の成長を評価しつつ、異常IVに基づく機械候補0.95%への急減は避ける。[BLS日程](https://www.bls.gov/schedule/2026/) / [Fed日程](https://www.federalreserve.gov/newsevents/2026-october.htm)

## 今週のイベントとリバランス判断

[BLSの公式日程](https://www.bls.gov/schedule/2026/)、[Fedの10月日程](https://www.federalreserve.gov/newsevents/2026-october.htm)、[NARの住宅販売日程](https://www.nar.realtor/research-and-statistics/housing-statistics/existing-home-sales)、[経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)、[決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)に基づく。予定は変更されうるため公表前に再確認する。10月12日は米株式市場は開く一方、銀行・現物国債市場は休場。IEF ETFの値付け・スプレッドに注意し、この日に債券配分変更を急がない。

| 日付 | 予定（米東部時間） | 観測点と対応 |
|---|---|---|
| 10/12 月 | 米現物国債市場休場、米株式は通常取引 | IEFの流動性に注意。新オプション値の再検証を優先 |
| 10/13 火 | NFIB、既存住宅販売、JPM・WFC・C・GS、J&J・UNH、Domino'sなど | XLFの利鞘/信用、XLVの医療費、XLYの客数、XLREの住宅需要を再評価 |
| 10/14 水 | 8:30 CPI、14:00 Beige Book、ASML・BAC・MS・Fastenal、IEA石油市場報告 | 金利・BEIと半導体受注、工業販売、石油需給を同時確認。XLK・XLI・XLE・IEFを重視 |
| 10/15 木 | 8:30 PPI・小売売上高・失業保険、12:00 EIA石油在庫、TSMC・Prologis、引け後Alcoa・J.B. Hunt | 価格圧力と消費数量、原油在庫を分離。XLK・XLY・XLP・XLE・XLB・XLIの候補変更を判断 |
| 10/16 金 | 8:30輸入物価、9:15鉱工業生産、地銀決算 | 金利・原価・製造業需要の週末確認。翌週の配分へ反映 |

**条件付きの変更案：** CPI/PPIが物価減速を示し、同日ベースで10年BEI・名目金利がともに低下、IEFが終値で90を回復し、オプションIVも妥当な市場水準で再取得できれば、IEFを40–41%へ引き上げることを検討する。逆に物価上振れでBEI・名目金利がともに上昇し、IEFが89を終値で割るなら39%前後への小幅減額を検討する。いずれも株式側の相手勘定と総計100%を確認し、企業決算を踏まえてXLP/XLVとXLK/XLEの間で再配分する。**この条件は現行モデルへの自動入力ではなく、次の人手による判断基準**である。

## オプション品質、監視水準、シナリオ

10月12日寄り付き前に取得した12銘柄のチェーンには10月9日最終売買の契約がある。しかし7日IVの中央値は前回の約29.4%から約1.1%へ低下し、12銘柄中11銘柄で7日IVの満期補間が成立していない。さらに7銘柄のGamma Flipが推定グリッド端（現値の80%または120%）に位置し、実際のゼロ交差ではなく「絶対GEX最小値」の代用になっている。[今回のオプション入力](../tables/v2_latest_option_signal_snapshot.csv) / [前回の入力](../../data/processed/20261002/v2/SGV2-20261005/20261004T123304930176Z/option_signal_snapshot.csv) / [Notebookの推定ロジック](../../main.ipynb)

このため、**今回の7日1σ IVレンジ、Gamma Flip、Call/Put Wall、Vanna/Charmの方向フラグは売買閾値として使用しない**。WallとGreeksは建玉からの推計で、ディーラーの実際のポジションやヘッジ売買を直接観測したものでもない。ダッシュボード上の値は再取得・気配品質・満期補間・ゼロ交差の確認が済むまで参考表示にとどめる。特にXLKの7日IV 0.75%、IEFの1.08%と、そこから計算した極端に狭い予想変動幅は実務上不採用とする。

当面の**価格のみの観測点**は、10月9日調整後終値でXLK198.78、XLE65.08、XLU41.41、XLRE41.61、IEF89.40。IEFの89/90、XLKの200、XLEの65は便宜的な丸め水準であり、今回のオプションWallや保証された支持・抵抗線ではない。[調整後価格](../tables/consistent_12asset_weekly_attribution.csv)

- **基本：** 物価圧力と景気の粘りが混在。株式60.25%・IEF39.75%を維持し、決算とCPI後に再判定。
- **物価減速：** BEI・名目金利低下ならIEF増額、XLRE/XLUの金利感応度を再評価。ただし弱い需要が原因ならXLF/XLY/XLIを増やさない。
- **再インフレ：** BEI・名目金利上昇ならIEF・XLRE・高PERのXLKに逆風。XLEは相対ヘッジになりうるが、原油反落時のリスクを残す。
- **成長失速：** 小売売上・企業需要が弱く信用指標が悪化すれば、IEFの防御性を再評価し、XLY/XLI/XLFの増額を見送る。株式と債券の逆相関は保証されない。

## データ品質と再現性

Notebookを上から実行し、[実行済みNotebook](../executed/main_20261012_executed.ipynb)、[12資産ダッシュボード](../dashboard/sector_gamma_dashboard_v2.html)、raw/processed、CSV/parquetを更新した。日付別v2ランは`SGV2-20261012`、価格カットオフ10月9日、実行予定日10月12日。12銘柄のチェーンは非空で、保存・描画を含む形式検証815件はPASS、BLOCK/WARNは0。ただし上記の**経済的なIV品質異常は既存検証では検出できなかった**ため、新機械目標は承認不可と判断する。更新前のNotebook・HTML・上書きCSVは[バックアップ](../backups/20261012_weekly_update/)へ保存した。

前週寄与度は調整後ETF終値と前回不変v2ウェイトを明示的に結合して計算した反実仮想である。ニュースのセクター指数騰落は照合用に限定した。実保有・承認・オプション入力が確認できるまでは、新しい機械配分への注文を生成しない。
