> **追補版（2026年9月6日）**：元レポートをそのまま残し、末尾に「マクロ・市場環境を踏まえた最終判断とセクター別解説」を追加しています。配分・解釈の補足と修正点は追補をご参照ください。

# Sector Gamma 週次見通し・リバランス案 — 2026年9月6日

**データ基準:** 2026年9月4日米国引け / 2026年9月6日JST更新  
**振り返り期間:** 2026年8月28日引け → 9月4日引け  
**見通し期間:** 2026年9月7日 → 9月11日（9月7日はLabor Day休場）  
**対象:** S&P 500 11セクターETF + IEF（米国7–10年国債）

> 本資料は研究・モデル運用のためのもので、個別の投資助言ではない。GEXは公開オプションチェーンからcallを正、putを負として計算した需給プロキシであり、実際のディーラーポジションを直接観測したものではない。配分損益はETFの配当調整済み終値によるモデル計算で、外部記事のセクター指数騰落率はクロスチェックに用いる。

## 結論

今回の基本提案は、**株式を57.49%から59.44%へ1.95ポイント増やし、IEFを42.51%から40.56%へ減らす**。60/40基準に対しては株式-0.56ポイント、IEF+0.56ポイントで、前回の明確な債券Overweightからほぼ中立へ戻す。

株式内では **XLVだけをOverweight** とし、**XLC・XLP・XLY・XLIをUnderweight**、XLE・XLB・XLRE・XLK・XLF・XLUをNeutralとする。XLEとXLBはAdjusted Scoreがプラスでも、Hard Ruleにより新規Overweightを認めない。XLEはCall Wall 65まで1.5%しかなく、XLBは20日線を下回るためである。

判断の中心は四点である。

1. **先週の戦術配分は+2.76bp勝った。** 8月28日→9月4日の60/40基準は-0.163%、前回提案は-0.135%。XLY・XLI・XLCのUnderweightとXLE Overweightが寄与し、XLB Overweight、XLKの小幅アンダー、IEF Overweightが相殺要因だった。
2. **株式全体は横ばいでも内部ローテーションが大きかった。** S&P 500は+0.06%、Nasdaqは+0.40%。セクターではEnergy +2.23%、Technology +1.03%に対し、Consumer Discretionary -2.06%、Materials -1.50%、Industrials -1.19%だった。[LPL週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html)
3. **強い雇用と原油高で、IEFのBEI面が悪化した。** 8月雇用者数は+16.2万人、失業率4.1%、平均時給は前月比+0.3%。5年/10年BEIは2.37%/2.35%へ上がり、加重BEIの5日変化は+5.2bp、20日変化は+12.0bpとなった。[BLS雇用統計](https://www.bls.gov/news.release/archives/empsit_09042026.htm) / [FRED 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [10年BEI](https://fred.stlouisfed.org/series/T10YIE)
4. **オプションだけならIEFはPositiveだが、CPI前に追随買いはしない。** IEFのオプションAdjusted Scoreは+0.156、BEIオーバーレイは-0.387、75/25合成後は+0.020に低下した。現値92.25はPut Wall 92とGamma Flip 91.80の近くで、9月10日のPPI、11日のCPIが次の方向を決める。

## 先週の振り返り

### 市場で確認された事実

- S&P 500は週間+0.06%、Dowは-0.26%、Nasdaqは+0.40%。Energy +2.23%とTechnology +1.03%が支え、Consumer Discretionary -2.06%、Materials -1.50%、Industrials -1.19%が下位だった。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html)
- 8月非農業部門雇用者数は+16.2万人、失業率は4.1%で横ばい、平均時給は前月比+0.3%・前年比+3.1%。6–7月分は合計+5.5万人上方修正された。一方、情報産業は-2.3万人、医療は+1.3万人と過去12か月平均の+3.2万人を下回った。[BLS](https://www.bls.gov/news.release/archives/empsit_09042026.htm)
- 強い雇用を受け、9月4日に2年国債利回りは4.37%、10年は4.78%へ上昇。S&P 500は金曜単日-0.4%、IEFは週間-0.29%だった。[AP市場報道](https://apnews.com/article/stocks-markets-oil-trump-iran-war-1af16359af43eb8abc66445465f633c8) / [米財務省イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- 原油は週間+9.82%。Brentは96.28ドル、WTIは91.48ドルで金曜を終え、Hormuz海峡の実質閉鎖と中東の軍事緊張が供給プレミアムを押し上げた。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html) / [AP](https://apnews.com/article/stocks-markets-oil-trump-iran-war-1af16359af43eb8abc66445465f633c8)
- LPLはDellとBroadcomのAIコンピュート需要に関する好材料が大型テクノロジーを支えたと整理した。一方、Lululemonは売上が予想を下回り通期見通しを再度引き下げ、金曜に17.4%下落した。AI投資と一般消費の温度差がXLKとXLYの相対差になった。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html) / [AP](https://apnews.com/article/stocks-markets-oil-trump-iran-war-1af16359af43eb8abc66445465f633c8)

### 前回提案の実績

60/40基準は**-0.163%**、戦術配分は**-0.135%**、超過収益は**+2.76bp**だった。S&P 500の週間騰落率と異なるのは、本モデルの基準が株式60%・IEF40%で、株式部分も11セクターETFの固定ベンチマークだからである。

| ETF | 前回判断 | ETF騰落率 | Active寄与 | 評価 |
|---|---|---:|---:|---|
| XLY | Underweight | -1.96% | **+1.48bp** | Lululemonを含む消費裁量の弱さを回避 |
| XLE | Overweight | +2.20% | **+1.26bp** | 原油急騰と正Gammaが奏功 |
| XLI | Underweight | -1.06% | +0.84bp | Flip下・負Gammaの減額が奏功 |
| XLC | Underweight | -0.85% | +0.82bp | 弱いオプション需給に沿った下落 |
| XLP | Underweight | -1.02% | +0.36bp | 物価・マージン懸念への減額が寄与 |
| XLV | Overweight | +0.17% | +0.15bp | 小幅上昇を増額で取得 |
| XLRE | Neutral | -1.24% | +0.06bp | 小幅アンダーが寄与 |
| XLF | Underweight | 0.00% | 0.00bp | 方向感なし |
| XLU | Neutral | +0.82% | -0.12bp | 小幅アンダーで上昇を取り切れず |
| XLB | Overweight | -1.39% | **-0.66bp** | 高金利と景気敏感株の弱さで失敗 |
| XLK | Neutral | +0.86% | **-0.71bp** | 株式バケット縮小分でAI反発を取り切れず |
| IEF | Overweight | -0.29% | **-0.73bp** | 雇用・BEI上昇による金利上昇が逆風 |

前週の改善点は明確である。セクター内のUnderweightは概ね機能したが、**IEFを増やしたままインフレ期待の再上昇を受けたこと**と、**XLBを正GammaだけでOverweightしたこと**が弱点だった。今週はBEIをより強く反映してIEFをほぼ中立へ戻し、XLBはスコアがプラスでもHard Ruleに従ってNeutralへ落とす。

## 金利・BEIとIEFの見通し

### 確認された事実

- 9月4日の5年BEIは2.37%、10年BEIは2.35%。8月28日の2.30%/2.31%から+7bp/+4bp上昇し、40/60加重BEIは2.358%、5営業日変化+5.2bp、20営業日変化+12.0bpとなった。[FRED 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- 9月4日の2年国債利回りは4.37%、7年4.65%、10年4.78%、30年5.24%。雇用統計後に利上げ織り込みが強まり、IEFは92.52から92.25へ週間-0.29%となった。[米財務省](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- 9月15–16日のFOMC前のブラックアウト期間は9月5日に始まっており、今週はFed発言よりPPI/CPIそのものが価格形成の中心になる。[Fed 9月カレンダー](https://www.federalreserve.gov/newsevents/2026-september.htm) / [Kiplinger経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)

### モデル推論

- IEFの現値92.25はGamma Flip 91.80、Put Wall 92、Call Wall 92.5に挟まれ、7日1σレンジは91.57–92.93。Net GEXは+117.7百万で、オプション単体のAdjusted Scoreは+0.156である。
- ただしBEIオーバーレイは-0.387。「オプション75% + BEI25%」の金利調整後スコアは+0.020まで低下した。これはIEFをショートにする信号ではないが、42.51%のOverweightを維持する根拠としては弱い。
- Vanna集中80.8%、Charm集中93.6%と高いため、PPI/CPI後のIV低下や時間経過でヘッジフローが変化しやすい。92.5を場中で越えただけでは買い戻さず、92.93超の終値とBEI低下を併せて確認する。
- 基本配分は40.56%。PPI/CPIが鈍化し、IEFが92.93を終値で上抜き、5年/10年BEIが2.30%近辺へ低下すれば42–43%へ再増額する。反対にIEFが91.80、さらに91.57を割り、BEIが2.40%を越えるなら39–40%へ減額する。

## 今週のリバランス案

### 配分と売買

| ETF | 新配分 | 前回配分 | 売買 | 60/40基準比 | モデル判断 |
|---|---:|---:|---:|---:|---|
| IEF | **40.56%** | 42.51% | **-1.95pt** | +0.56pt | Overweight幅を縮小 |
| XLK | **19.54%** | 18.90% | +0.64pt | -0.18pt | Neutral |
| XLF | **7.44%** | 7.03% | +0.41pt | -0.11pt | Neutralへ引上げ |
| XLV | **6.83%** | 6.56% | +0.27pt | **+1.14pt** | Overweight |
| XLC | **5.80%** | 5.21% | +0.59pt | -0.38pt | Underweight |
| XLY | **5.56%** | 5.18% | +0.38pt | -0.38pt | Underweight |
| XLI | **5.05%** | 4.60% | +0.46pt | -0.34pt | Underweight |
| XLP | **2.98%** | 2.83% | +0.16pt | -0.19pt | Underweight |
| XLE | **2.38%** | 2.97% | **-0.59pt** | -0.02pt | Neutralへ引下げ |
| XLU | **1.43%** | 1.35% | +0.09pt | -0.06pt | Neutral |
| XLB | **1.25%** | 1.73% | **-0.48pt** | -0.01pt | Neutralへ引下げ |
| XLRE | **1.19%** | 1.15% | +0.04pt | -0.01pt | Neutral |

合計100.00%、株式59.44%、IEF40.56%。片道売買回転率は約3.03%。XLK・XLC・XLY・XLIの増加は強気転換ではなく、前回の株式バケット縮小を戻す機械的な増額である。60/40基準比ではXLKも小幅アンダー、XLC・XLY・XLIは引き続き明確なUnderweightとなる。

### 段階執行

- **第1段階（9月8日、50%）:** IEFを42.51%から約41.53%へ、XLEとXLBのOverweightを半分解消する。資金はXLVと、Neutralへ戻すXLK・XLFを中心に配る。連休明け寄り付きの初動ではなく、IEFが92、XLKが187.16付近を維持するか確認してから行う。
- **第2段階（9月10日、25%）:** PPI後、IEFが91.80以上でBEIが2.40%未満なら40.56%への減額を75%まで進める。PPIが弱くIEFが92.93を上抜く場合は減額を止め、41.5–42.0%に留める。
- **第3段階（9月11日、25%）:** CPI・ミシガン期待インフレ後に完成する。IEF 91.57割れかつBEI 2.40%超なら39–40%へ追加減額、IEF 92.93超かつBEI 2.30%近辺なら42–43%へ戻す。Oracle・Adobeの決算反応も確認し、XLKが194.07を越えなければNeutral以上には増やさない。

## 各セクターとIEFの根拠

以下の「事実」は9月4日終値と9月6日JST取得のオプションチェーンから計算した値、「見通し」はマクロ・企業イベントとの対応づけである。

### XLV — Health Care: Overweight 6.83%

- **オプション・価格事実:** Adjusted Score +0.251で11セクター首位。現値171.45はFlip 161.50を上回り、Net GEXは+46.7百万。Call/Put Wallは170、7日1σレンジは165.22–177.68。20日+3.48%、60日+12.66%。
- **マクロ:** 高金利・地政学・CPIイベントに対する収益のディフェンシブ性が、資本集約型ディフェンシブのXLU/XLREより優位。ただしBLSでは8月医療雇用+1.3万人と過去12か月平均を下回っており、無条件の景気非感応ではない。
- **ボトムアップ:** Cooperの決算で医療機器・消費者向けヘルス需要を確認する。170を終値で保てる間はOverweight。165.22割れでは増額を戻し、177.68近辺では追随買いを抑える。

### XLE — Energy: Neutral 2.38%

- **オプション・価格事実:** Adjusted Score +0.222、Net GEX+70.6百万。現値64.06はFlip 62.19とPut Wall 60を上回るが、Call Wall 65まで1.47%でHard Ruleの「Call Wallまで2%未満」に該当。IVレンジは61.81–66.31。
- **マクロ:** Hormuz供給制約と原油週間+9.82%は追い風だが、同時にBEIと長期金利を押し上げ、需要破壊のリスクも高める。EIAは8月時点で、Hormuz経由の流量が紛争前より大幅に制約され、9月に徐々に回復する前提を置いていた。[EIA STEO](https://www.eia.gov/outlooks/steo/archives/aug26.pdf)
- **ボトムアップ:** 先週のOverweightは+1.26bp寄与したため利益を確定し、65/66.31接近では追加しない。62.19を維持し原油供給不安が続くならNeutral、61.81割れでは60を次の支持として減額する。

### XLB — Materials: Neutral 1.25%

- **オプション・価格事実:** Adjusted Score +0.140、Net GEX+33.9百万。現値52.44はFlip 49.57を上回るが20日線52.82を下回り、Hard RuleでOverweight不可。Call Wall 55、Put Wall 48、IVレンジ48.88–56.00。IV/実現Vol比3.33は12資産で最大。
- **マクロ:** PPI上振れは販売価格には一時的にプラスでも、金利・ドル・投入コスト経由で需要とマージンを圧迫する。既存住宅販売の弱さも建材需要へ波及する。
- **ボトムアップ:** Core & Mainや建設関連企業の決算を、上下水道・インフラ需要の確認材料とする。前回Overweightは-0.66bp。52.82回復まではNeutral、55接近では利食いを優先する。

### XLRE — Real Estate: Neutral 1.19%

- **オプション・価格事実:** Adjusted Score +0.103、Net GEX+0.6百万。現値43.93はFlip 42.83とPut Wall 43を上回るが20日線44.65を下回る。Call Wall 45、IVレンジ41.86–46.00。
- **マクロ:** 10年金利4.78%とBEI上昇は資金調達コスト・還元利回りの両面で逆風。9月10日の既存住宅販売が数量回復を示し、同時に金利が低下する組み合わせが必要である。
- **ボトムアップ:** 物流・データセンターREITの需要は底堅くても、セクター全体では借換えコストが優先する。45と20日線を終値で越えるまでNeutral。42.83/41.86割れは減額条件。

### XLK — Information Technology: Neutral 19.54%

- **オプション・価格事実:** Adjusted Score +0.055。現値187.28はFlip 187.16のわずか0.06%上、Net GEXは+0.8百万にすぎない。Call Wall 190、Put Wall 175、IVレンジ180.49–194.07。FlipとCall Wallの近さによりOverweight不可。
- **マクロ:** AI設備投資は支えだが、10年4.78%と実質金利上昇は長期成長株の評価に逆風。今週はCPIとOracle/Adobe決算が、金利とAI・ソフトウェア収益化を同時に試す。
- **ボトムアップ:** Oracleは9月10日引け後にFY27 Q1を公表し、前回会社計画は売上+27–29%、Cloud売上+58–64%。Adobeも同日Q3を公表し、CEO移行発表後初の決算となる。[Oracle公式IR](https://investor.oracle.com/investor-news/news-details/2026/Oracle-Sets-the-Date-for-its-First-Quarter-Fiscal-Year-2027-Earnings-Announcement/default.aspx) / [Adobe公式](https://news.adobe.com/news/2026/09/adobe-announces-anil-chakravarthy-to-become-president-and-ceo) 187.16割れで180.49、194.07超で初めて上方再評価する。

### XLF — Financials: Neutral 7.44%

- **オプション・価格事実:** Adjusted Score -0.058。現値58.10はFlip 58.26のわずか下、Put Wall 58、Call Wall 60、IVレンジ56.63–59.57。Net GEXは-16.5百万だが、下位4セクターほど弱くないためNeutral。
- **マクロ:** 強い雇用と金利上昇は貸出利回りを支える一方、追加利上げと逆イールドは調達コスト・信用コストを悪化させうる。消費者信用、失業保険、CPIを、単なる金利上昇ではなく信用サイクルと併読する。
- **ボトムアップ:** 58を終値で維持し59.57–60へ戻ればNeutral継続。56.63割れでは信用不安優位と判断しUnderweightへ戻す。前回比+0.41ptはUnderweight解消であり、積極的な銀行株強気ではない。

### XLU — Utilities: Neutral 1.43%

- **オプション・価格事実:** Adjusted Score -0.174、Net GEX-5.4百万。現値43.08はFlip 43.23の直下。Call Wall 45、Put Wall 40、IVレンジ41.81–44.35。20日線43.36も下回る。
- **マクロ:** AIデータセンターの電力需要は中期支援だが、今週は長期金利と燃料費が優先する。原油高・BEI上昇は規制料金への転嫁ラグと資本コストを通じて逆風。
- **ボトムアップ:** 43.23/43.36回復と金利低下を確認するまでNeutral。41.81割れは40方向への値動き増幅に備える。配当利回りだけを根拠にIEFと同時に増やさない。

### XLC — Communication Services: Underweight 5.80%

- **オプション・価格事実:** Adjusted Score -0.257、Net GEX-37.2百万。現値112.03はFlip 117.71とCall Wall 115を下回る。Put Wall 104、IVレンジ108.02–116.04。負Gammaで20日+0.99%にとどまる。
- **マクロ:** 実質金利上昇は大型プラットフォームの評価を抑え、消費減速は広告需要へ波及する。CPIが落ち着き金利が下がる場合にはショートカバーが起きやすい。
- **ボトムアップ:** 今週の小売決算は広告・eコマース需要の補助指標。115/116.04を回復するまではUnderweight。前回比では+0.59ptだが、60/40基準比-0.38ptを維持する。

### XLP — Consumer Staples: Underweight 2.98%

- **オプション・価格事実:** Adjusted Score -0.258、Net GEX-82.7百万。現値84.58はFlip 89.69を下回り、Call Wall 86、Put Wall 78、IVレンジ82.36–86.80。Charm集中60.2%で、イベント後の時間経過フローにも注意が必要。
- **マクロ:** 原油・輸送費とPPI上昇は食品・日用品のマージンを圧迫する。景気防御性はあるが、価格転嫁が数量減へつながる局面では単純な安全資産にならない。
- **ボトムアップ:** 9月8日のUNFIで卸売価格と食品数量、9月11日のKrogerで既存店売上・粗利・販促を確認する。Krogerの公式決算会見は11日8:00 ET。[Kroger公式IR](https://ir.kroger.com/news/news-details/2026/Kroger-Announces-Second-Quarter-Conference-Call-with-Investors/default.aspx) 86/86.80回復までUnderweight。

### XLY — Consumer Discretionary: Underweight 5.56%

- **オプション・価格事実:** Adjusted Score -0.269。現値114.91はFlip 133.69を大きく下回り、Net GEX-87.9百万。Call Wall 120、Put Wall 110、IVレンジ109.94–119.88。IV/実現Vol比1.91でイベントリスクの織り込みも大きい。
- **マクロ:** 強い雇用は所得面で支援する一方、利上げ観測・住宅金利・ガソリン高は裁量支出を圧迫する。CPIと消費者センチメントが今週の中心。
- **ボトムアップ:** 先週Lululemonの弱い売上・見通しが警戒材料となった。今週はAcademy Sports、American Eagle、Chewy、Macy'sなどから低・中所得層の数量、値引き、在庫を確認する。[Kiplinger決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks) 120回復までUnderweight、109.94/110割れは追加減額条件。

### XLI — Industrials: Underweight 5.05%

- **オプション・価格事実:** Adjusted Score -0.269、Net GEX-121.2百万で12資産中最大の負Gamma。現値175.27はFlip 191.90と20日線180.22を下回る。Call Wall 180、Put Wall 170、IVレンジ169.76–180.78。
- **マクロ:** 8月製造業雇用+1.6万人は支援材料だが、高金利・原油高・輸送費は設備投資の採算を圧迫する。PPIと既存住宅販売から企業価格・建設需要を確認する。
- **ボトムアップ:** Core & Main、Sunbelt Rentals、AeroVironmentの決算がインフラ、レンタル稼働率、防衛需要を映す。AeroVironmentは9月2日に米陸軍から4.65億ドルの契約を獲得したと報じられたが、セクター全体の負Gammaを覆すかは180回復で確認する。[Kiplinger](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)

### IEF — 7–10年米国国債: Overweight幅縮小 40.56%

- **オプション・価格事実:** 現値92.25、Net GEX+117.7百万、Flip 91.80、Call Wall 92.5、Put Wall 92、IVレンジ91.57–92.93。オプションAdjusted Score+0.156。
- **BEI・金利事実:** 5年/10年BEIは2.37%/2.35%、加重5日変化+5.2bp・20日変化+12.0bp。BEIオーバーレイ-0.387、合成スコア+0.020。10年名目金利は4.78%。
- **見通し:** PPI/CPI鈍化とBEI低下なら上、強い物価と利上げ織り込みなら下。92.5–92.93を買い戻し確認帯、92/91.80を警戒帯、91.57割れを追加減額帯とする。

## 日別イベントとポジション対応

来週は四営業日で、9月10日のPPI、11日のCPIがIEFと金利感応セクターの主要変曲点。Oracle・Adobeが10日引け後、Krogerが11日朝に決算を公表する。[Kiplinger経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar) / [決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)

| 日付 | 主なイベント（米東部時間） | 主なETF | ポジションへの読み替え |
|---|---|---|---|
| 9/7 月 | Labor Day、株式・債券市場休場 | 全資産 | 取引なし。連休中の中東・原油ヘッドラインだけ監視 |
| 9/8 火 | 6:00 NFIB中小企業、15:00消費者信用、ABM/UNFI朝、Braze/Casey's等引け後 | XLI, XLP, XLY, XLF, IEF | 信用需要とコスト圧力を確認。第1段階50%を実施 |
| 9/9 水 | 主要経済指標なし、Academy Sports/Chewy/Core & Main等朝、AeroVironment/American Eagle等引け後 | XLY, XLI, XLB, XLV | 小売数量・在庫、インフラ、防衛需要をセクター判断へ反映 |
| 9/10 木 | 8:30失業保険・PPI/コアPPI、10:00卸売・既存住宅、Macy's等朝、Oracle/Adobe等引け後 | IEF, XLRE, XLF, XLB, XLI, XLK, XLY | PPIで第2段階。住宅はXLRE、ソフトウェア決算はXLKのFlip確認 |
| 9/11 金 | 8:00 Kroger、8:30 CPI/コアCPI、10:00ミシガン消費者信頼感、14:00財政収支 | 全資産、特にIEF/XLK/XLRE/XLU/XLY/XLP | 最大イベント。CPI・期待インフレ・BEIを揃えて最終配分を決定 |

## Vanna / Charmとガンマ運営

- **負Gamma:** XLF、XLU、XLC、XLP、XLY、XLI。特にXLI、XLY、XLPはNet GEXの負が大きく、指標・決算に対する値動きが増幅しやすい。
- **Flip近傍:** IEFはFlipの0.50%上、XLKは0.06%上、XLFは0.27%下、XLUは0.34%下。PPI/CPIとOracle/Adobe後にレジームが変わりやすいため、場中の突破ではなく終値で判定する。
- **高Vanna/Charm:** IEFはVanna集中80.8%、Charm集中93.6%で突出。株式ではXLRE/XLPのCharm、XLB/XLYのVannaが比較的高い。IV低下後のヘッジフローでWallを越える可能性があるため、Wallを固定的な抵抗・支持とはみなさない。
- **IVプレミアム:** XLB 3.33倍、XLRE 2.75倍、XLY 1.91倍、XLI 1.85倍とIV/20日実現Vol比が高い。方向が合ってもオプション買いの時間価値負担が大きく、現物配分調整を主、オプションは限定損失のイベントヘッジに使う。

## シナリオ

### 中立シナリオ — 株式59.44% / IEF40.56%へ

PPI/CPIは高止まりだが上振れず、BEIは2.32–2.40%、IEFは91.80–92.93、XLKは180.49–194.07で推移する。提案配分を段階的に完成し、XLV Overweight、XLC/XLP/XLY/XLI Underweightを維持する。

### ディスインフレ・金利低下シナリオ — IEFを42–43%へ再増額

PPI/CPIとミシガン期待インフレが鈍化し、5年/10年BEIが2.30%近辺へ低下。IEFが92.93を終値で上抜く場合、IEFを42–43%へ戻し、XLK・XLY・XLIから調達する。XLREは45を越えればNeutral内で増やす。

### 成長・AI強気シナリオ — 株式60–62%

物価が上振れず、Oracle/Adobeがクラウド・AI収益化を上方修正し、XLKが194.07、XLCが116.04、XLIが180.78を終値で上抜く。IEFを38–40%へ下げ、XLK・XLC・XLIのUnderweightを順に解消する。

### インフレ・金利上昇型弱気シナリオ — IEFも機械的に買わない

PPI/CPIが上振れ、BEIが2.40%超、IEFが91.57を割る。XLKも180.49を割る場合、株式と中期債が同時安になりうる。12資産内ではIEFを39–40%へ抑え、株式側はXLVを中心にXLE/XLFをNeutralまで使う。現金・短期債を許容する別枠運用なら、無理に12資産へ全額配分せず待機資金を置く。

## 監視水準一覧

| ETF | 配分 | Adjusted Score | Spot | Flip | Call Wall | Put Wall | 7日1σレンジ | Gamma / 判断 |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| XLV | 6.83% | +0.251 | 171.45 | 161.50 | 170 | 170 | 165.22–177.68 | 正 / OW |
| XLE | 2.38% | +0.222 | 64.06 | 62.19 | 65 | 60 | 61.81–66.31 | 正・Call Wall近傍 / Neutral |
| IEF | 40.56% | +0.020 | 92.25 | 91.80 | 92.5 | 92 | 91.57–92.93 | 正 / OW幅縮小（BEI調整後） |
| XLB | 1.25% | +0.140 | 52.44 | 49.57 | 55 | 48 | 48.88–56.00 | 正・20日線下 / Neutral |
| XLRE | 1.19% | +0.103 | 43.93 | 42.83 | 45 | 43 | 41.86–46.00 | 正・20日線下 / Neutral |
| XLK | 19.54% | +0.055 | 187.28 | 187.16 | 190 | 175 | 180.49–194.07 | 正・Flip近傍 / Neutral |
| XLF | 7.44% | -0.058 | 58.10 | 58.26 | 60 | 58 | 56.63–59.57 | 負・Flip/Put Wall近傍 / Neutral |
| XLU | 1.43% | -0.174 | 43.08 | 43.23 | 45 | 40 | 41.81–44.35 | 負・Flip近傍 / Neutral |
| XLC | 5.80% | -0.257 | 112.03 | 117.71 | 115 | 104 | 108.02–116.04 | 負 / UW |
| XLP | 2.98% | -0.258 | 84.58 | 89.69 | 86 | 78 | 82.36–86.80 | 負 / UW |
| XLY | 5.56% | -0.269 | 114.91 | 133.69 | 120 | 110 | 109.94–119.88 | 負 / UW |
| XLI | 5.05% | -0.269 | 175.27 | 191.90 | 180 | 170 | 169.76–180.78 | 負 / UW |

## データと外部参照

- モデル配分: `outputs/tables/consistent_12asset_allocation.csv`
- 最新保有週検証: `outputs/tables/latest_holding_week_attribution.csv`
- オプション指標: `outputs/tables/consistent_option_metrics.csv`
- IEFダッシュボード表: `outputs/tables/ief_dashboard.csv`
- BEI履歴・オーバーレイ: `outputs/tables/breakeven_inflation.csv`, `outputs/tables/bei_overlay.csv`
- 現在回の価格フォールバック監査表: `outputs/tables/price_fallback.csv`（今回はヘッダーのみ＝未使用）
- HTMLダッシュボード: `outputs/dashboard/sector_gamma_dashboard.html`
- 実行済みNotebook: `outputs/executed/main_20260906_executed.ipynb`
- [LPL: 9月4日までの週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html)
- [BLS: 8月雇用統計](https://www.bls.gov/news.release/archives/empsit_09042026.htm)
- [AP: 9月4日の市場・金利・原油](https://apnews.com/article/stocks-markets-oil-trump-iran-war-1af16359af43eb8abc66445465f633c8)
- [FRED: 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- [米財務省: 名目イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- [Federal Reserve: 2026年9月カレンダー](https://www.federalreserve.gov/newsevents/2026-september.htm)
- [Kiplinger: 9月7–11日の経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)
- [Kiplinger: 9月7–11日の決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)
- [Oracle公式決算予定](https://investor.oracle.com/investor-news/news-details/2026/Oracle-Sets-the-Date-for-its-First-Quarter-Fiscal-Year-2027-Earnings-Announcement/default.aspx)
- [Adobe公式Q3案内](https://news.adobe.com/news/2026/09/adobe-announces-anil-chakravarthy-to-become-president-and-ceo)
- [Kroger公式決算予定](https://ir.kroger.com/news/news-details/2026/Kroger-Announces-Second-Quarter-Conference-Call-with-Investors/default.aspx)
- [EIA: 2026年8月Short-Term Energy Outlook](https://www.eia.gov/outlooks/steo/archives/aug26.pdf)

## モデル検証メモ

- Notebookは非表示状態に依存せず上から完走し、オプションチェーンは11セクターETF、SPY、IEFの13銘柄すべて取得した。総行数は21,547行。
- 既存検証、前週検証、BEI、保存先、全Plotly図を含む **205/205項目がPASS**。有限なGreeks、配分合計100%、株式内Active合計0、BEIスコア恒等式、parquet・CSV・HTML保存を確認した。
- 前週検証は12資産、期間8月28日→9月4日。`戦術収益率 - 基準収益率 = 超過収益率` を確認した。
- 今回はyFinanceに9月4日の調整済み終値が揃い、価格フォールバックは未使用。最新CSVに前回の監査値が残らないよう、空監査表を毎回上書きする処理と検証をNotebookへ追加した。

---

# 追補：マクロ・市場環境を踏まえた最終判断とセクター別解説

**評価日：2026年9月6日（日本時間）／基本対象期間：2026年9月7～11日**  
**対象：米国11セクターETF＋IEF、株式60％・IEF40％のベンチマーク、ドル建て・為替効果を除く。**

本追補は、元レポートのモデル配分・Adjusted Score・GEX・Gamma Flip・Wall・価格レンジを入力として、外部のマクロ統計とETF構成を追加した判断である。オプションチェーン、元CSV、配分最適化、実績損益の再計算は行っていない。「確認事項」は公表資料または元レポートに基づき、「判断」「解説」「対応」は追加の分析・提案である。ETF構成比は特記がない限り運用会社公表の2026年9月3日時点。

## A. 最終判断

**元レポートの基本配分を概ね採用する。株式59.44％、IEF40.56％という、60/40から大きく離れない配分を基本とし、株式内ではXLVをOverweight、XLY・XLI・XLC・XLPをUnderweight、その他をNeutralとする。**

ただし、判断の中身は「景気後退に備えてディフェンシブを一律に買う」でも、「債券を減らすから株式に強気」でもない。現状は、**経済活動の拡大が続く一方、エネルギー・投入コストと金利の上振れが企業利益と株価評価の余地を狭める局面**と整理する。製造業・サービス業のISMと9月2日公表のベージュブックは、全面的な需要崩壊を基本シナリオに置くことを支持しない。[S1][S2][S3]

したがって、IEFの過大なOverweightを解消しながらも株式全体の積極的Overweightは見送り、株式内部で「相対的に安定した利益」「コスト転嫁力」「借換え負担」「AI・インフラ需要」の差を選別する。XLVのOWは相対配分であって、絶対リターンのプラスを保証するものではない。

### 最終配分の表示案

| 対象 | 最終判断 | 配分 | 判断の要旨 |
|---|---|---:|---|
| XLV ヘルスケア | Overweight | 6.83% | 収益防御性を選好。ただし医薬・保険固有のリスクは残る |
| XLE エネルギー | Neutral・マクロは強め | 2.38% | 供給制約の受益は残すが、イベント集中とHard Ruleを尊重 |
| XLB 素材 | Neutral | 1.25% | 化学の比重が大きく、原油高を一律の利益増とみなさない |
| XLRE 不動産 | Neutral・慎重 | 1.19% | 需要の底堅い用途もあるが、金利・借換え条件の改善待ち |
| XLK 情報技術 | Neutral | 19.53% | AI収益成長を残しつつ、金利と決算前の上乗せは見送る |
| XLF 金融 | Neutral | 7.44% | 順イールドと成長は支援、信用・調達コストと需給は要確認 |
| XLU 公益 | Neutral・慎重 | 1.43% | 電力需要だけでなく、資本コスト・規制・投資回収を重視 |
| XLC コミュニケーション | Underweight | 5.80% | 短期需給を警戒するが、広告事業の全面悪化は前提にしない |
| XLP 生活必需品 | Underweight | 2.98% | XLV対比で劣後。低価格小売の防御力があるため深追いしない |
| XLY 一般消費財 | Underweight | 5.56% | 実質購買力、借入コスト、主要構成銘柄の株価リスクを警戒 |
| XLI 資本財・サービス | Underweight | 5.05% | コスト・受注減速と短期需給を警戒。構造的な弱気ではない |
| IEF 米国7～10年国債 | ほぼNeutral・小幅OW | 40.56% | 景気悪化への保険は残すが、インフレヘッジとは扱わない |
| **合計** | **株式59.44%／IEF40.56%** | **100.00%** | |

**丸め処理の注記：** 元レポートの表示配分をそのまま合計すると100.01％となる。本表ではXLKのみ19.54％から19.53％へ0.01ポイント調整した。これは表示上の整合処理であり、XLKの投資判断変更や再最適化ではない。実際の発注には未丸めの元CSVを用いて合計と制約を再確認する。

「マクロは強め」「慎重」は同じNeutral内での優先順位を表し、別のOW/UW配分を暗黙に設定するものではない。元レポートと同様、セクター判断と株式バケット全体の判断は分ける。XLC等を前回比で買い増しても、ベンチマーク比ではUWのままである。

## B. マクロ・市場環境の追加解釈

### B1. 景気は拡大しているが、全面的な強気にはつながらない

BLSの8月雇用統計は雇用者数＋16.2万人、失業率4.1％、平均時給前月比＋0.3％・前年比＋3.1％だった。[S4] ISM製造業PMIは54.6、サービス業PMIは55.4と、双方が拡大圏にある。一方、製造業新規受注は56.7から53.7へ鈍化し、製造業価格指数は71.1、サービス業価格指数は72.6と高い。[S1][S2]

**判断：** 売上数量の崩壊よりも、「成長は続くが、その成長を実現するコストが高い」という利益率・割引率の問題を重視する。雇用の単月改善を持続的過熱と断定することも、裁量消費の一部企業の不振を全米消費の崩壊に一般化することも避ける。

9月2日公表のベージュブックも、12地区中10地区で小幅～緩やかな成長、消費の価格感応度上昇と高額品需要の底堅さ、防衛・データセンター関連受注の強さを併記している。これは所得層・用途別の選別を支持する材料と読む。なお、同書は8月24日までの聞き取りを集計したもので、9月初旬の全事象を織り込んだ報告ではない。[S3]

### B2. 金利は「水準」と「上昇の内訳」を分ける

| 10年金利の要素 | 2026年8月28日 | 2026年9月4日 | 変化 |
|---|---:|---:|---:|
| 名目国債利回り | 4.73% | 4.78% | +5bp |
| 実質国債利回り | 2.42% | 2.43% | +1bp |
| 両者の差＝BEI | 2.31% | 2.35% | +4bp |

出所：米財務省の名目・実質イールド。BEIは同年限の両者の差として計算し、9月4日値はFREDでも確認した。[S5][S6][S7]

**判断：** 先週を「実質金利の急上昇で成長株が一律に売られた週」と説明するのは強すぎる。実質金利は高い水準にあるものの、週間変化の中心はインフレ補償の拡大である。XLKを積極的に増やさない根拠は、実質金利上昇だけではなく、高い割引率、CPI前の不確実性、モデル上のFlip近接を合わせたものとなる。

また、BEIは純粋な平均インフレ予想だけでなく、インフレリスクプレミアムやTIPSの流動性プレミアムの影響を受ける。BEI上昇だけから、将来のCPIやIEFの価格方向を一意に決めない。[S8]

### B3. 金融セクターの「逆イールド」は修正が必要

9月4日の2年4.37％、10年4.78％から、10年－2年は**＋41bpの順イールド**である。8月28日は＋39bpなので、週間ではこの区間のスプレッドが2bp拡大した。元レポートのXLFにある「逆イールド」は、少なくとも2年―10年については当てはまらない。[S5]

ただし、順イールドであることから銀行の利ざや改善が直ちに確定するわけではない。保有資産と負債の金利改定速度、預金調達コスト、評価損、信用コスト、貸出需要を分けて確認する必要がある。曲線が順イールドであることと、金利上昇が金融株全体に有利であることは同義ではない。

### B4. 供給制約インフレでは、同じ「ディフェンシブ」「資源株」でも差が出る

EIAの8月STEOはホルムズ通航制約を予測前提としているが、それは将来シナリオであり、供給回復の確定情報ではない。同じ見通しで米国天然ガスには原油とは異なる需給を想定している。原油、米国天然ガス、電力価格を同方向と決めつけない。[S9]

**判断：** 原油高の直接的な収益感応度を持つXLE、原料・物流費増に直面する化学を多く含むXLB、資本コストが重要なXLU/XLRE、相対的な需要安定性を持つXLVを区別する。需要が安定していることだけでは、株価が金利上昇に強いことにはならない。

## C. 各セクターの最終判断と追加解説

### C1. XLV — Health Care：Overweight 6.83%

**元レポートの材料：** Adjusted Score＋0.251で11セクター首位。現値171.45はFlip161.50より上。20日・60日の価格モメンタムもプラス。

**マクロ・業種構成からの解説：** 今回の選好理由は、景気後退そのものを予想するからではなく、消費裁量・投入コスト・長期金利のショックに対して、利益の相対的な安定性を求めるためである。XLVは医薬品37.17％、バイオ19.56％、医療提供・サービス17.79％などを含む。公益やREITと同じ「配当・金利感応型のディフェンシブ」として一括りにせず、事業収益の性質から評価する。[S10]

**反対材料：** 医薬品価格、特許・治験、医療保険の医療費負担などの固有リスクは残る。大型の成長期待銘柄も含むため、XLV全体が低バリュエーション・低デュレーションとは限らない。また、医療雇用の減速から直ちにXLVの売上減速を推定することはできない。採用抑制はコスト調整の可能性もある。[S4][S10]

**最終判断・対応：** 唯一の明確なOWを維持するが、6.83％からさらに増やす判断は見送る。元レポートの170を維持できるかを確認し、165.22割れや固有の業績悪化で増額を見直す。177.68近辺への上昇を、それだけで追随買いの理由にはしない。

### C2. XLE — Energy：Neutral 2.38%、マクロ評価は強め

**元レポートの材料：** スコア＋0.222、現値64.06、Flip62.19。Call Wall65まで約1.47％で、「2％未満では新規OW不可」のHard Ruleに該当。

**マクロ・業種構成からの解説：** 供給制約が続く局面では、エネルギー関連企業の収益に対する上向きの感応度を残す意義がある。XLEは石油・ガス・消耗燃料89.92％、エネルギー設備・サービス10.08％で、XLBより直接的なエネルギー事業エクスポージャーである。ただし、採掘、統合石油、精製、サービスで収益構造は異なり、ETFは原油そのものではない。[S11]

**なぜOWではなくNeutralか：** 供給プレミアムの急低下、需要の下押し、短期急騰後のイベント集中を考えると、マクロの追い風がそのまま「現在値からの追加投資の優位性」を意味するわけではない。Hard Ruleを採用している以上、強いマクロ見通しだけで例外扱いにはしない。これはファンダメンタルズの弱気転換ではなく、既存の上乗せを解消して基準量は残す判断である。

**最終判断・対応：** 2.38％を維持し、積極的UWにも振らない。再OWには、原油需給に加え、最新チェーンによるWallの移動やHard Rule適合を確認する。65を一度上抜いただけで、自動的にOWを許可しない。9月9日公表予定のEIA最新STEOは重要な更新材料となる。[S9]

### C3. XLB — Materials：Neutral 1.25%

**元レポートの材料：** スコア＋0.140だが、現値52.44は20日線52.82を下回り、Hard RuleでOW不可。

**マクロ・業種構成からの解説：** XLBは化学49.78％、金属・鉱業22.75％、容器・包装15.33％、建設資材12.14％である。「資源価格高＝素材株全体の利益増」とは言えない。鉱山には販売価格上昇の恩恵があっても、化学や包装では原料・エネルギー・物流費の増加が先行し得る。[S12]

**評価の分岐：** 製造業の拡大は需要の下支えである一方、受注の減速と高い価格指数はマージンに注意を促す材料である。したがって、大きなUWではなく、価格転嫁と数量の組み合わせを確認するNeutralが整合的と考える。[S1]

**最終判断・対応：** 1.25％。52.82の回復は再評価の入口とするが、販売価格－投入コストの差や受注の改善が伴わなければ、移動平均回復だけでOWにはしない。米ドル上昇や中国需要悪化は条件付きのリスクであり、本追補ではその発生を確認済み事実とはしていない。

### C4. XLRE — Real Estate：Neutral 1.19%、慎重姿勢

**元レポートの材料：** スコア＋0.103、現値43.93はFlip42.83を上回る一方、20日線44.65を下回る。

**マクロ・業種構成からの解説：** 高い長期金利は、物件収益の評価に使う還元利回りと借換えコストの両面で評価上の負担になり得る。一方、XLREは特殊用途REIT、ヘルスケア、物流などを含み、オフィスREITは1.04％にとどまる。商業不動産不安をそのままETF全体の弱さへ読み替えることも適切でない。[S13]

**追加する確認指標：** 既存住宅販売は金利・住宅需要の補助指標であり、XLREの利益を直接測るものではない。保有REITの既存物件純営業利益、稼働率、賃料改定、調整後営業キャッシュフロー、債務満期と調達スプレッドを優先する。

**最終判断・対応：** 1.19％のNeutralを維持し、積極的OWは見送る。44.65～45の回復に金利低下と収益見通しの安定が伴えば再評価する。42.83、次いで41.86割れは減額検討。金利が低下しても、それが深刻な需要悪化による場合には、賃料や稼働率の悪化を差し引いて判断する。

### C5. XLK — Information Technology：Neutral 19.53%

**元レポートの材料：** スコア＋0.055、現値187.28はFlip187.16のわずか上。元配分は19.54％で、本追補では合計調整のみ0.01ポイント減らした。

**マクロ・業種構成からの解説：** 先週のLPLレポートは、Dell・Broadcomの決算から得られたAIコンピュート需要に関する材料が市場を支えたと整理している。この外部評価は、金利だけを理由に成長株を一律UWにしない根拠になる。[S14] ただし、売上成長と設備投資後のキャッシュフローは別であり、AI需要の強さだけで株価の上昇余地は確定しない。

XLKでは半導体・製造装置が43.44％、ソフトウェアが25.37％。9月10日のOracle・Adobeは重要だが、2社の決算だけでセクター全体の業績を代表させず、半導体・ハードウェアの価格反応も見る。[S15][S16][S17]

**最終判断・対応：** 大きく外さずNeutralとする。強い実質金利上昇を既成事実にするのではなく、高い割引率とイベント前の需給不安を理由に上乗せを控える。187.16を下回れば180.49を警戒。194.07超にCPIの落ち着きと収益・キャッシュフロー見通しの改善が伴えば、OWの再検討に進む。

### C6. XLF — Financials：Neutral 7.44%

**元レポートの材料：** スコア－0.058、現値58.10はFlip58.26をやや下回る。前回UWからNeutralへの引き上げ。

**マクロ・業種構成からの解説：** 2年―10年は＋41bpの順イールドであるため、逆イールドを現在の主たる弱気材料にはしない。[S5] また、XLFの銀行比率は28.47％で、金融サービス27.90％、資本市場26.30％、保険13.22％等も含む。「銀行の利ざや」だけでETF全体を説明しない。[S18]

**強弱材料の読み分け：** 成長持続、貸出需要、保険の再投資利回りは支援となり得る。一方、金利上昇には預金費用、保有債券の評価、与信先の返済負担という逆風もある。長短金利差が広がっても、こうした負担が上回れば株価に有利とは限らない。

**最終判断・対応：** UW解消は支持するが、新規OWには進まない。58の維持、58.26の回復に加え、信用スプレッドと貸倒れ・調達費用の見通しを確認する。56.63割れはUW再検討の条件であって、それ単独で信用危機の発生を認定する指標ではない。

### C7. XLU — Utilities：Neutral 1.43%、慎重姿勢

**元レポートの材料：** スコア－0.174、現値43.08はFlip43.23と20日線43.36の下。

**マクロ・業種構成からの解説：** データセンター電力需要は支援材料だが、利益に結びつくまでには発電・送配電投資、接続、規制判断、資金調達が必要になる。EIAは8月見通しでデータセンターに伴う電力需要増を示す一方、テキサスの開発見直しを受けて同州の2027年需要増加予想を引き下げている。需要テーマと実際の投資回収を区別する必要がある。[S19]

**元レポートへの補足：** 原油高から米国公益企業の燃料費悪化へ直結させるのは粗い。原油と米国天然ガスの需給は異なり、EIA8月見通しでも天然ガス価格には別方向の前提が置かれている。[S9][S19] 規制公益、独立発電、燃料転嫁条項、ヘッジの違いを見たうえで、セクター全体ではまず長期金利と資本コストを重視する。

**最終判断・対応：** 配当利回りやAI電力需要だけを理由にOWにしない。43.23～43.36の回復と金利安定を確認する。IEFと同時に増やす場合には、見かけ上の分散より共通の金利リスクを点検する。

### C8. XLC — Communication Services：Underweight 5.80%

**元レポートの材料：** スコア－0.257、現値112.03はFlip117.71を下回る。

**マクロ・業種構成からの解説：** XLCは伝統的通信株だけではない。9月3日時点のファンド構成でMetaとAlphabet2種類の株式を合計すると約36.0％となる。広告プラットフォーム、動画・メディア、通信の異なる収益要因を含むため、「通信だから守り」とはみなさない。[S20]

**UWの限界：** 成長持続は広告需要の下支えにもなり得る。したがって、今回のUWは広告利益の全面悪化を予測したものではなく、CPI・金利イベント前のモデル需給と価格確認不足を重視した戦術判断である。負GEXだけから将来リターンが負になるとは推論しない。

**最終判断・対応：** 5.80％を維持するが、過度にUWを拡大しない。115～116.04の回復はUW縮小を検討する材料とし、117.71のFlip回復とは区別する。需給と主要構成企業の業績が改善した場合、見直しを遅らせない。

### C9. XLP — Consumer Staples：Underweight 2.98%、相対的な小幅弱気

**元レポートの材料：** スコア－0.258、現値84.58はFlip89.69を下回る。

**マクロ・業種構成からの解説：** 食品・日用品メーカーには、原料・包装・輸送費の増加と、値上げ後の数量減少が同時に起こるリスクがある。一方、XLPはメーカーだけではなく、生活必需品流通・小売が33.40％を占め、WalmartとCostcoを含む。節約志向による需要移行が一部小売に有利に働く可能性もあり、「インフレ＝XLP全銘柄に悪い」とは言えない。[S21]

**なぜXLVより優先しないか：** 今回は、消費の価格感応度と投入コストの圧力が同時に存在するため、追加の防御的配分はXLVを優先する。これはXLPの絶対的な下落予測ではなく、防御的セクター間の相対判断である。

**最終判断・対応：** 2.98％のUWを維持するが、深いUWにはしない。86～86.80の回復、販売数量・粗利の安定を確認すればUW縮小候補とする。需要悪化とインフレ鈍化が同時に進む局面では、XLPの防御性が相対的に高まる可能性があり、今回のUWを固定化しない。

### C10. XLY — Consumer Discretionary：Underweight 5.56%

**元レポートの材料：** スコア－0.269、現値114.91はFlip133.69を大きく下回る。

**マクロ・業種構成からの解説：** 雇用改善は所得を支えるが、高い燃料費は他の裁量支出の余地を狭め、高金利は自動車・住宅関連の購買負担を増やし得る。ベージュブックでも自動車販売には消費者心理、燃料費、調達金利の負担が指摘されている。[S3]

ただし、XLYではAmazon24.36％、Tesla17.73％の合計が約42.1％となる。Lululemon等の小売決算をXLY全体に一般化せず、主要構成銘柄の固有業績と株価を併読する。[S22]

**最終判断・対応：** マクロとモデル価格・需給が同じ慎重方向を示すため、UW維持の優先度は高い。5.56％とし、109.94～110割れで追加減額を検討する。120回復はUW縮小の検討材料だが、133.69のFlip回復やファンダメンタルズ改善とは同義ではない。

### C11. XLI — Industrials：Underweight 5.05%、戦術判断に限定

**元レポートの材料：** スコア－0.269、現値175.27は20日線180.22とFlip191.90を下回る。Net GEXは元レポート内で最も大きい負値。

**マクロ・業種構成からの解説：** 高い投入価格と資金調達コストは設備投資の採算と受注の利益率を圧迫し得る。しかし製造業PMIは拡大圏であり、ベージュブックにも防衛・データセンター受注の強さがあるため、製造業不況を前提とした構造的弱気とはしない。[S1][S3]

XLIは航空宇宙・防衛25.44％、機械20.55％、電気設備13.35％などを含む。一部の防衛・電力投資需要は一般設備投資と異なるサイクルを持ち得るため、原油高だけで全構成業種を同じ方向に評価しない。[S23]

**最終判断・対応：** 5.05％のUWを維持しながら、180.22～180.78の回復と受注・利益率見通しの改善で縮小を検討する。これは191.90のFlip回復とは別段階である。また、GEXの絶対額の大小だけでETF間のリスク順位を確定せず、売買代金や時価総額等での正規化も必要と考える。

## D. IEF — 米国7～10年国債：40.56％、過大なOWを解消

**元レポートの材料：** オプションスコア＋0.156に対し、BEI調整後は＋0.020。価格92.25、Flip91.80、Put Wall92、Call Wall92.5、7日1σレンジ91.57～92.93。

### D1. 保有する理由と、増やさない理由

景気・需要の下振れで名目金利が低下する場合の受け皿は残す。しかしIEFは名目国債なので、供給ショック型のインフレに対する直接的なヘッジではない。成長が持続し、インフレ補償が拡大する局面で、オプション指標が正であることだけを根拠に42.51％を維持する合理性は弱い。

**判断：** 40.56％までのOW縮小を支持する。これは国債そのものへの全面弱気ではなく、今週の物価指標前に方向性の強い金利低下ポジションを持ちすぎない措置である。

### D2. 金利感応度の簡単な試算

iShares公表の9月3日時点のIEF実効デュレーションは6.96年である。[S24]

$$\frac{\Delta P}{P}\approx -D\,\Delta y$$

利回り曲線が平行に25bp上昇し、デュレーション一定、利息・凸性・為替等を無視すると、価格影響は約−1.74％。配分40.56％では、ポートフォリオ全体に約−0.71ポイントの寄与となる。これは感応度の例示であり、今週の金利予想ではない。

### D3. BEIだけで判定しない

名目金利は同年限の実質金利とBEIに分けられるため、BEIが低下しても実質金利がそれ以上に上昇すればIEFの支援にはならない。BEI上昇時も、実質金利低下が十分大きければ名目金利が下がる場合がある。IEF価格、7～10年名目金利、実質金利、BEI、信用・成長指標を組み合わせる。[S5][S6][S8]

元レポートの92.93上抜け／91.80・91.57下抜け、BEI2.30％／2.40％は監視目安として採用する。ただし、2.40％は経済学的な非連続点ではない。5年、10年、40/60加重BEIのどれに適用するかは、実装・運用ルールで統一する必要がある。本追補ではその元コードを確認していない。

## E. シナリオの補足・変更

| シナリオ | 経済・市場の識別 | 配分判断 |
|---|---|---|
| 基本：成長持続・物価高止まり | 活動は拡大、コア物価は大幅上振れせず、金利も急変しない | 株59.44／IEF40.56を基本。XLV OW、XLY・XLI・XLC・XLP UW |
| 良いディスインフレ | 供給制約・投入コストが改善し、需要・企業利益は保たれる | CPI低下だけでXLKを売ってIEF42～43へ機械的に移さない。株式側のリスクプレミアム低下も評価 |
| 需要悪化を伴うディスインフレ | 雇用・受注・消費の悪化と金利低下が同時進行 | IEF42～43を検討。資金は景気敏感・消費関連を中心に調達。XLPのUWは見直す |
| 成長・AI上振れ、物価安定 | 利益・キャッシュフロー見通し改善、CPIが落ち着き、価格が確認帯を回復 | 元レポートの株60～62／IEF38～40を再検討。セクター増額は最新モデル制約と整合させる |
| 供給ショック型インフレ | 原油・インフレ補償・名目金利が上昇し、株式とIEFがともに弱い | IEF減額だけをリスク削減と呼ばない。12資産制約下では相対リスクを再評価し、現金・短期債は許可された別枠の場合のみ使用 |

**重要な変更点：** 元レポートのディスインフレ案は、「物価低下＝IEFを増やしXLK等を減らす」と一般化すると、供給改善型の株・債券同時上昇を取り逃がす可能性がある。物価が低下した原因を確認して資金調達先を決める。

また、11セクター＋IEFに100％投資する制約下では、IEF39～40％は株式60～61％を意味する。これは株式と債券の両方を減らす運用ではない。インフレ型弱気局面でのIEF減額は、株式側の相対的な耐性や推定リスクを確認して初めて採用できる。「株債同時安だからIEFを減らす」だけでは絶対リスク抑制の説明として不十分である。

## F. 今週の確認項目と執行上の補足

PPIは9月10日8:30米東部時間、CPIは9月11日8:30米東部時間（いずれも日本時間21:30）。ミシガン大学調査は9月11日10:00米東部時間（日本時間23:00）。FOMCは9月15～16日で、今週の評価期間後も政策イベントが続く。[S25][S26][S27]

| 日付 | 追加・重点確認事項 | 判断への利用 |
|---|---|---|
| 9/8 | 元レポートの第1段階を基本とするが、連休明け価格とモデルの鮮度を確認 | IEF過大OWとXLE・XLB上乗せの解消を先行し、株式強気への転換と混同しない |
| 9/9 | EIA最新STEO、BLSの雇用者報酬コスト統計 | 原文の「主要経済指標なし」に追加。EIAで原油・米国ガスの前提更新を確認。報酬コスト統計はECIとは別統計 [S9][S25] |
| 9/10 | PPI、既存住宅販売、Oracle・Adobe | PPIは見出しだけでなく、サービス等の内訳を確認。住宅は住宅需要、決算は収益化と投資負担を確認 [S16][S17][S25][S28] |
| 9/11 | CPI、実質所得関連、ミシガン期待インフレ | 予想比、コアの広がり、名目・実質金利、BEI、ETF価格を照合して第3段階を判断 [S25][S26] |

原文の50％・25％・25％という段階執行は、予定配分までの売買差分を分割する考え方として支持する。ただし、悪材料が出た後も未完了の株式買いを機械的に完成させる約束にはしない。

終値判定を条件にする場合、当日終値を確認してから同じ終値で約定した扱いにはできない。9月11日終値を使った判断の執行は9月14日以降であり、2営業日の適用ラグを設定する運用なら9月15日になる。最終的な執行日がFOMCと接近する点も含め、実装上のラグと本レポートの時間軸を揃える。

## G. 解釈・検証上の注意

**オプション需給は条件付きの補助情報。** 元レポート自体が明記する通り、callを正、putを負としたGEXはディーラー保有を直接観測したものではない。正GEXは期待収益率のプラス、負GEXは期待収益率のマイナスを意味しない。Wallも絶対的な支持・抵抗線ではなく、更新される状態変数として扱う。

**モデルのスコアと価格レンジは予測確率ではない。** Adjusted Scoreを収益率や勝率へ変換する較正結果は添付されていない。7日1σレンジを確定的な目標価格や損失上限と表現しない。価格が特定の水準を回復しても、Gamma Flipの回復とは別である。

**1週の超過収益と内部検証は、将来の運用優位性の証明ではない。** 元レポートの＋2.76bpや205/205検証PASSは、その範囲の実績・内部整合性として尊重する。ただし、添付だけでは取引コスト控除、スリッページ、長期のアウト・オブ・サンプル成績を確認できない。

**外部指数とモデル実績の時点を混同しない。** LPLの9月4日付表にはBloombergデータの時点として米東部15:00と記載されている。したがって、同表の数値を厳密な16:00終値ベースの週間騰落率と同一視せず、元レポートのETF調整済み終値による実績は別系列として扱う。[S14]

## H. 発表用の結論

> 今週は、景気が崩れているというより、成長が続く一方でエネルギー価格と金利が利益率・株価評価を圧迫する局面と判断します。そのため株式・債券とも大きな方向性を取らず、60/40近辺へ戻します。株式内ではヘルスケアを相対的に厚くし、一般消費財と資本財のリスクを抑えます。エネルギーはインフレ耐性を残すため中立、情報技術はAI成長を取り逃がさないため中立とします。IEFは需要悪化への保険を残しますが、インフレヘッジとはみなしません。CPI低下時にも、供給改善なのか需要悪化なのかを区別して次の配分を決めます。

## 追補の外部出典

以下は追補で追加・再確認した出典。元レポートのモデル数値の出所は、前掲の元レポート各節およびその「データと外部参照」を参照。

[S1]: https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/pmi/august/
[S2]: https://www.ismworld.org/supply-management-news-and-reports/reports/ism-pmi-reports/services/august/
[S3]: https://www.federalreserve.gov/monetarypolicy/beigebook202608-summary.htm
[S4]: https://www.bls.gov/news.release/archives/empsit_09042026.htm
[S5]: https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve
[S6]: https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_real_yield_curve
[S7]: https://fred.stlouisfed.org/series/T10YIE
[S8]: https://www.federalreserve.gov/econres/notes/feds-notes/tips-from-tips-update-and-discussions-20190521.html
[S9]: https://www.eia.gov/outlooks/steo/report/index.php
[S10]: https://www.ssga.com/us/en/intermediary/etfs/state-street-health-care-select-sector-spdr-etf-xlv
[S11]: https://www.ssga.com/us/en/intermediary/etfs/state-street-energy-select-sector-spdr-etf-xle
[S12]: https://www.ssga.com/us/en/intermediary/etfs/state-street-materials-select-sector-spdr-etf-xlb
[S13]: https://www.ssga.com/us/en/intermediary/etfs/state-street-real-estate-select-sector-spdr-etf-xlre
[S14]: https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html
[S15]: https://www.ssga.com/us/en/intermediary/etfs/state-street-technology-select-sector-spdr-etf-xlk
[S16]: https://investor.oracle.com/investor-news/news-details/2026/Oracle-Sets-the-Date-for-its-First-Quarter-Fiscal-Year-2027-Earnings-Announcement/default.aspx
[S17]: https://news.adobe.com/news/2026/09/adobe-announces-anil-chakravarthy-to-become-president-and-ceo
[S18]: https://www.ssga.com/us/en/intermediary/etfs/state-street-financial-select-sector-spdr-etf-xlf
[S19]: https://www.eia.gov/outlooks/steo/report/elec_coal_renew.php
[S20]: https://www.ssga.com/us/en/intermediary/etfs/state-street-communication-services-select-sector-spdr-etf-xlc
[S21]: https://www.ssga.com/us/en/intermediary/etfs/state-street-consumer-staples-select-sector-spdr-etf-xlp
[S22]: https://www.ssga.com/us/en/intermediary/etfs/state-street-consumer-discretionary-select-sector-spdr-etf-xly
[S23]: https://www.ssga.com/us/en/intermediary/etfs/state-street-industrial-select-sector-spdr-etf-xli
[S24]: https://www.ishares.com/us/products/239456/ishares-710-year-treasury-bond-etf
[S25]: https://www.bls.gov/schedule/2026/home.htm
[S26]: https://www.sca.isr.umich.edu/
[S27]: https://www.federalreserve.gov/newsevents/2026-september.htm
[S28]: https://www.nar.realtor/research-and-statistics/housing-statistics/existing-home-sales

| 参照 | 資料・確認時点 |
|---|---|
| [S1]・[S2] | ISM、2026年8月の製造業・サービス業PMI |
| [S3] | FRB Beige Book、2026年9月2日公表、8月24日までの情報 |
| [S4] | BLS、2026年8月雇用統計、9月4日公表 |
| [S5]・[S6]・[S7] | 米財務省名目・実質イールド、FRED10年BEI、8月28日・9月4日 |
| [S8] | FRB FEDS Notes、Tips from TIPS: Update and Discussions、2019年5月21日 |
| [S9]・[S19] | EIA STEO、2026年8月11日公表、8月6日予測完成、次回9月9日 |
| [S10]～[S13]・[S15]・[S18]・[S20]～[S23] | State Street公式ETF構成、2026年9月3日時点 |
| [S14] | LPL Research、Weekly Market Performance — September 4, 2026。表は15:00 ET時点の表記 |
| [S16]・[S17] | Oracle・Adobe公式、9月10日の決算・決算会見予定 |
| [S24] | iShares IEF、2026年9月3日時点の実効デュレーション |
| [S25]～[S28] | BLS、ミシガン大学、FRB、NAR公式発表予定。2026年9月6日に確認 |
