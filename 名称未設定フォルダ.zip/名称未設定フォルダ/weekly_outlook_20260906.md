# Sector Gamma 週次見通し・リバランス案 — 2026年9月6日

**データ基準:** 2026年9月4日米国引け / 2026年9月6日JST更新  
**振り返り期間:** 2026年8月28日引け → 9月4日引け  
**見通し期間:** 2026年9月7日 → 9月11日（9月7日はLabor Day休場）  
**対象:** S&P 500 11セクターETF + IEF（米国7–10年国債）

> 本資料は研究・モデル運用のためのもので、個別の投資助言ではない。GEXは公開オプションチェーンからcallを正、putを負として計算した需給プロキシであり、実際のディーラーポジションを直接観測したものではない。配分損益はETFの配当調整済み終値によるモデル計算で、外部記事のセクター指数騰落率はクロスチェックに用いる。

## 結論

今回の基本提案は、**株式を57.49%から59.44%へ1.95ポイント増やし、IEFを42.51%から40.56%へ減らす**。60/40基準に対しては株式-0.56ポイント、IEF+0.56ポイントで、前回の明確な債券Overweightからほぼ中立へ戻す。

株式内では **XLVだけをOverweight** とし、**XLC・XLP・XLY・XLIをUnderweight**、XLE・XLB・XLRE・XLK・XLF・XLUをNeutralとする。XLEとXLBはAdjusted Scoreがプラスでも、Hard Ruleにより新規Overweightを認めない。XLEはCall Wall 65まで1.5%しかなく、XLBは20日線を下回るためである。

判断の中心は四点である。

1. **先週の戦術配分は+2.76bp勝った。** 8月28日→9月4日の60/40基準は-0.163%、前回提案は-0.135%。XLY・XLI・XLCのUnderweightとXLE Overweightが寄与し、XLB Overweight、XLKの小幅アンダー、IEF Overweightが相殺要因だった。
2. **株式全体は横ばいでも内部ローテーションが大きかった。** S&P 500は+0.06%、Nasdaqは+0.40%。セクターではEnergy +2.23%、Technology +1.03%に対し、Consumer Discretionary -2.06%、Materials -1.50%、Industrials -1.19%だった。[LPL週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html)
3. **強い雇用と原油高で、IEFのBEI面が悪化した。** 8月雇用者数は+16.2万人、失業率4.1%、平均時給は前月比+0.3%。5年/10年BEIは2.37%/2.35%へ上がり、加重BEIの5日変化は+5.2bp、20日変化は+12.0bpとなった。[BLS雇用統計](https://www.bls.gov/news.release/archives/empsit_09042026.htm) / [FRED 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [10年BEI](https://fred.stlouisfed.org/series/T10YIE)
4. **オプションだけならIEFはPositiveだが、CPI前に追随買いはしない。** IEFのオプションAdjusted Scoreは+0.156、BEIオーバーレイは-0.387、75/25合成後は+0.020に低下した。現値92.25はPut Wall 92とGamma Flip 91.80の近くで、9月10日のPPI、11日のCPIが次の方向を決める。

## 先週の振り返り

### 市場で確認された事実

- S&P 500は週間+0.06%、Dowは-0.26%、Nasdaqは+0.40%。Energy +2.23%とTechnology +1.03%が支え、Consumer Discretionary -2.06%、Materials -1.50%、Industrials -1.19%が下位だった。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html)
- 8月非農業部門雇用者数は+16.2万人、失業率は4.1%で横ばい、平均時給は前月比+0.3%・前年比+3.1%。6–7月分は合計+5.5万人上方修正された。一方、情報産業は-2.3万人、医療は+1.3万人と過去12か月平均の+3.2万人を下回った。[BLS](https://www.bls.gov/news.release/archives/empsit_09042026.htm)
- 強い雇用を受け、9月4日に2年国債利回りは4.37%、10年は4.78%へ上昇。S&P 500は金曜単日-0.4%、IEFは週間-0.29%だった。[AP市場報道](https://apnews.com/article/stocks-markets-oil-trump-iran-war-1af16359af43eb8abc66445465f633c8) / [米財務省イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- 原油は週間+9.82%。Brentは96.28ドル、WTIは91.48ドルで金曜を終え、Hormuz海峡の実質閉鎖と中東の軍事緊張が供給プレミアムを押し上げた。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html) / [AP](https://apnews.com/article/stocks-markets-oil-trump-iran-war-1af16359af43eb8abc66445465f633c8)
- LPLはDellとBroadcomのAIコンピュート需要に関する好材料が大型テクノロジーを支えたと整理した。一方、Lululemonは売上が予想を下回り通期見通しを再度引き下げ、金曜に17.4%下落した。AI投資と一般消費の温度差がXLKとXLYの相対差になった。[LPL](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html) / [AP](https://apnews.com/article/stocks-markets-oil-trump-iran-war-1af16359af43eb8abc66445465f633c8)

### 前回提案の実績

60/40基準は**-0.163%**、戦術配分は**-0.135%**、超過収益は**+2.76bp**だった。S&P 500の週間騰落率と異なるのは、本モデルの基準が株式60%・IEF40%で、株式部分も11セクターETFの固定ベンチマークだからである。

| ETF | 前回判断 | ETF騰落率 | Active寄与 | 評価 |
|---|---|---:|---:|---|
| XLY | Underweight | -1.96% | **+1.48bp** | Lululemonを含む消費裁量の弱さを回避 |
| XLE | Overweight | +2.20% | **+1.26bp** | 原油急騰と正Gammaが奏功 |
| XLI | Underweight | -1.06% | +0.84bp | Flip下・負Gammaの減額が奏功 |
| XLC | Underweight | -0.85% | +0.82bp | 弱いオプション需給に沿った下落 |
| XLP | Underweight | -1.02% | +0.36bp | 物価・マージン懸念への減額が寄与 |
| XLV | Overweight | +0.17% | +0.15bp | 小幅上昇を増額で取得 |
| XLRE | Neutral | -1.24% | +0.06bp | 小幅アンダーが寄与 |
| XLF | Underweight | 0.00% | 0.00bp | 方向感なし |
| XLU | Neutral | +0.82% | -0.12bp | 小幅アンダーで上昇を取り切れず |
| XLB | Overweight | -1.39% | **-0.66bp** | 高金利と景気敏感株の弱さで失敗 |
| XLK | Neutral | +0.86% | **-0.71bp** | 株式バケット縮小分でAI反発を取り切れず |
| IEF | Overweight | -0.29% | **-0.73bp** | 雇用・BEI上昇による金利上昇が逆風 |

前週の改善点は明確である。セクター内のUnderweightは概ね機能したが、**IEFを増やしたままインフレ期待の再上昇を受けたこと**と、**XLBを正GammaだけでOverweightしたこと**が弱点だった。今週はBEIをより強く反映してIEFをほぼ中立へ戻し、XLBはスコアがプラスでもHard Ruleに従ってNeutralへ落とす。

## 金利・BEIとIEFの見通し

### 確認された事実

- 9月4日の5年BEIは2.37%、10年BEIは2.35%。8月28日の2.30%/2.31%から+7bp/+4bp上昇し、40/60加重BEIは2.358%、5営業日変化+5.2bp、20営業日変化+12.0bpとなった。[FRED 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- 9月4日の2年国債利回りは4.37%、7年4.65%、10年4.78%、30年5.24%。雇用統計後に利上げ織り込みが強まり、IEFは92.52から92.25へ週間-0.29%となった。[米財務省](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- 9月15–16日のFOMC前のブラックアウト期間は9月5日に始まっており、今週はFed発言よりPPI/CPIそのものが価格形成の中心になる。[Fed 9月カレンダー](https://www.federalreserve.gov/newsevents/2026-september.htm) / [Kiplinger経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)

### モデル推論

- IEFの現値92.25はGamma Flip 91.80、Put Wall 92、Call Wall 92.5に挟まれ、7日1σレンジは91.57–92.93。Net GEXは+117.7百万で、オプション単体のAdjusted Scoreは+0.156である。
- ただしBEIオーバーレイは-0.387。「オプション75% + BEI25%」の金利調整後スコアは+0.020まで低下した。これはIEFをショートにする信号ではないが、42.51%のOverweightを維持する根拠としては弱い。
- Vanna集中80.8%、Charm集中93.6%と高いため、PPI/CPI後のIV低下や時間経過でヘッジフローが変化しやすい。92.5を場中で越えただけでは買い戻さず、92.93超の終値とBEI低下を併せて確認する。
- 基本配分は40.56%。PPI/CPIが鈍化し、IEFが92.93を終値で上抜き、5年/10年BEIが2.30%近辺へ低下すれば42–43%へ再増額する。反対にIEFが91.80、さらに91.57を割り、BEIが2.40%を越えるなら39–40%へ減額する。

## 今週のリバランス案

### 配分と売買

| ETF | 新配分 | 前回配分 | 売買 | 60/40基準比 | モデル判断 |
|---|---:|---:|---:|---:|---|
| IEF | **40.56%** | 42.51% | **-1.95pt** | +0.56pt | Overweight幅を縮小 |
| XLK | **19.54%** | 18.90% | +0.64pt | -0.18pt | Neutral |
| XLF | **7.44%** | 7.03% | +0.41pt | -0.11pt | Neutralへ引上げ |
| XLV | **6.83%** | 6.56% | +0.27pt | **+1.14pt** | Overweight |
| XLC | **5.80%** | 5.21% | +0.59pt | -0.38pt | Underweight |
| XLY | **5.56%** | 5.18% | +0.38pt | -0.38pt | Underweight |
| XLI | **5.05%** | 4.60% | +0.46pt | -0.34pt | Underweight |
| XLP | **2.98%** | 2.83% | +0.16pt | -0.19pt | Underweight |
| XLE | **2.38%** | 2.97% | **-0.59pt** | -0.02pt | Neutralへ引下げ |
| XLU | **1.43%** | 1.35% | +0.09pt | -0.06pt | Neutral |
| XLB | **1.25%** | 1.73% | **-0.48pt** | -0.01pt | Neutralへ引下げ |
| XLRE | **1.19%** | 1.15% | +0.04pt | -0.01pt | Neutral |

合計100.00%、株式59.44%、IEF40.56%。片道売買回転率は約3.03%。XLK・XLC・XLY・XLIの増加は強気転換ではなく、前回の株式バケット縮小を戻す機械的な増額である。60/40基準比ではXLKも小幅アンダー、XLC・XLY・XLIは引き続き明確なUnderweightとなる。

### 段階執行

- **第1段階（9月8日、50%）:** IEFを42.51%から約41.53%へ、XLEとXLBのOverweightを半分解消する。資金はXLVと、Neutralへ戻すXLK・XLFを中心に配る。連休明け寄り付きの初動ではなく、IEFが92、XLKが187.16付近を維持するか確認してから行う。
- **第2段階（9月10日、25%）:** PPI後、IEFが91.80以上でBEIが2.40%未満なら40.56%への減額を75%まで進める。PPIが弱くIEFが92.93を上抜く場合は減額を止め、41.5–42.0%に留める。
- **第3段階（9月11日、25%）:** CPI・ミシガン期待インフレ後に完成する。IEF 91.57割れかつBEI 2.40%超なら39–40%へ追加減額、IEF 92.93超かつBEI 2.30%近辺なら42–43%へ戻す。Oracle・Adobeの決算反応も確認し、XLKが194.07を越えなければNeutral以上には増やさない。

## 各セクターとIEFの根拠

以下の「事実」は9月4日終値と9月6日JST取得のオプションチェーンから計算した値、「見通し」はマクロ・企業イベントとの対応づけである。

### XLV — Health Care: Overweight 6.83%

- **オプション・価格事実:** Adjusted Score +0.251で11セクター首位。現値171.45はFlip 161.50を上回り、Net GEXは+46.7百万。Call/Put Wallは170、7日1σレンジは165.22–177.68。20日+3.48%、60日+12.66%。
- **マクロ:** 高金利・地政学・CPIイベントに対する収益のディフェンシブ性が、資本集約型ディフェンシブのXLU/XLREより優位。ただしBLSでは8月医療雇用+1.3万人と過去12か月平均を下回っており、無条件の景気非感応ではない。
- **ボトムアップ:** Cooperの決算で医療機器・消費者向けヘルス需要を確認する。170を終値で保てる間はOverweight。165.22割れでは増額を戻し、177.68近辺では追随買いを抑える。

### XLE — Energy: Neutral 2.38%

- **オプション・価格事実:** Adjusted Score +0.222、Net GEX+70.6百万。現値64.06はFlip 62.19とPut Wall 60を上回るが、Call Wall 65まで1.47%でHard Ruleの「Call Wallまで2%未満」に該当。IVレンジは61.81–66.31。
- **マクロ:** Hormuz供給制約と原油週間+9.82%は追い風だが、同時にBEIと長期金利を押し上げ、需要破壊のリスクも高める。EIAは8月時点で、Hormuz経由の流量が紛争前より大幅に制約され、9月に徐々に回復する前提を置いていた。[EIA STEO](https://www.eia.gov/outlooks/steo/archives/aug26.pdf)
- **ボトムアップ:** 先週のOverweightは+1.26bp寄与したため利益を確定し、65/66.31接近では追加しない。62.19を維持し原油供給不安が続くならNeutral、61.81割れでは60を次の支持として減額する。

### XLB — Materials: Neutral 1.25%

- **オプション・価格事実:** Adjusted Score +0.140、Net GEX+33.9百万。現値52.44はFlip 49.57を上回るが20日線52.82を下回り、Hard RuleでOverweight不可。Call Wall 55、Put Wall 48、IVレンジ48.88–56.00。IV/実現Vol比3.33は12資産で最大。
- **マクロ:** PPI上振れは販売価格には一時的にプラスでも、金利・ドル・投入コスト経由で需要とマージンを圧迫する。既存住宅販売の弱さも建材需要へ波及する。
- **ボトムアップ:** Core & Mainや建設関連企業の決算を、上下水道・インフラ需要の確認材料とする。前回Overweightは-0.66bp。52.82回復まではNeutral、55接近では利食いを優先する。

### XLRE — Real Estate: Neutral 1.19%

- **オプション・価格事実:** Adjusted Score +0.103、Net GEX+0.6百万。現値43.93はFlip 42.83とPut Wall 43を上回るが20日線44.65を下回る。Call Wall 45、IVレンジ41.86–46.00。
- **マクロ:** 10年金利4.78%とBEI上昇は資金調達コスト・還元利回りの両面で逆風。9月10日の既存住宅販売が数量回復を示し、同時に金利が低下する組み合わせが必要である。
- **ボトムアップ:** 物流・データセンターREITの需要は底堅くても、セクター全体では借換えコストが優先する。45と20日線を終値で越えるまでNeutral。42.83/41.86割れは減額条件。

### XLK — Information Technology: Neutral 19.54%

- **オプション・価格事実:** Adjusted Score +0.055。現値187.28はFlip 187.16のわずか0.06%上、Net GEXは+0.8百万にすぎない。Call Wall 190、Put Wall 175、IVレンジ180.49–194.07。FlipとCall Wallの近さによりOverweight不可。
- **マクロ:** AI設備投資は支えだが、10年4.78%と実質金利上昇は長期成長株の評価に逆風。今週はCPIとOracle/Adobe決算が、金利とAI・ソフトウェア収益化を同時に試す。
- **ボトムアップ:** Oracleは9月10日引け後にFY27 Q1を公表し、前回会社計画は売上+27–29%、Cloud売上+58–64%。Adobeも同日Q3を公表し、CEO移行発表後初の決算となる。[Oracle公式IR](https://investor.oracle.com/investor-news/news-details/2026/Oracle-Sets-the-Date-for-its-First-Quarter-Fiscal-Year-2027-Earnings-Announcement/default.aspx) / [Adobe公式](https://news.adobe.com/news/2026/09/adobe-announces-anil-chakravarthy-to-become-president-and-ceo) 187.16割れで180.49、194.07超で初めて上方再評価する。

### XLF — Financials: Neutral 7.44%

- **オプション・価格事実:** Adjusted Score -0.058。現値58.10はFlip 58.26のわずか下、Put Wall 58、Call Wall 60、IVレンジ56.63–59.57。Net GEXは-16.5百万だが、下位4セクターほど弱くないためNeutral。
- **マクロ:** 強い雇用と金利上昇は貸出利回りを支える一方、追加利上げと逆イールドは調達コスト・信用コストを悪化させうる。消費者信用、失業保険、CPIを、単なる金利上昇ではなく信用サイクルと併読する。
- **ボトムアップ:** 58を終値で維持し59.57–60へ戻ればNeutral継続。56.63割れでは信用不安優位と判断しUnderweightへ戻す。前回比+0.41ptはUnderweight解消であり、積極的な銀行株強気ではない。

### XLU — Utilities: Neutral 1.43%

- **オプション・価格事実:** Adjusted Score -0.174、Net GEX-5.4百万。現値43.08はFlip 43.23の直下。Call Wall 45、Put Wall 40、IVレンジ41.81–44.35。20日線43.36も下回る。
- **マクロ:** AIデータセンターの電力需要は中期支援だが、今週は長期金利と燃料費が優先する。原油高・BEI上昇は規制料金への転嫁ラグと資本コストを通じて逆風。
- **ボトムアップ:** 43.23/43.36回復と金利低下を確認するまでNeutral。41.81割れは40方向への値動き増幅に備える。配当利回りだけを根拠にIEFと同時に増やさない。

### XLC — Communication Services: Underweight 5.80%

- **オプション・価格事実:** Adjusted Score -0.257、Net GEX-37.2百万。現値112.03はFlip 117.71とCall Wall 115を下回る。Put Wall 104、IVレンジ108.02–116.04。負Gammaで20日+0.99%にとどまる。
- **マクロ:** 実質金利上昇は大型プラットフォームの評価を抑え、消費減速は広告需要へ波及する。CPIが落ち着き金利が下がる場合にはショートカバーが起きやすい。
- **ボトムアップ:** 今週の小売決算は広告・eコマース需要の補助指標。115/116.04を回復するまではUnderweight。前回比では+0.59ptだが、60/40基準比-0.38ptを維持する。

### XLP — Consumer Staples: Underweight 2.98%

- **オプション・価格事実:** Adjusted Score -0.258、Net GEX-82.7百万。現値84.58はFlip 89.69を下回り、Call Wall 86、Put Wall 78、IVレンジ82.36–86.80。Charm集中60.2%で、イベント後の時間経過フローにも注意が必要。
- **マクロ:** 原油・輸送費とPPI上昇は食品・日用品のマージンを圧迫する。景気防御性はあるが、価格転嫁が数量減へつながる局面では単純な安全資産にならない。
- **ボトムアップ:** 9月8日のUNFIで卸売価格と食品数量、9月11日のKrogerで既存店売上・粗利・販促を確認する。Krogerの公式決算会見は11日8:00 ET。[Kroger公式IR](https://ir.kroger.com/news/news-details/2026/Kroger-Announces-Second-Quarter-Conference-Call-with-Investors/default.aspx) 86/86.80回復までUnderweight。

### XLY — Consumer Discretionary: Underweight 5.56%

- **オプション・価格事実:** Adjusted Score -0.269。現値114.91はFlip 133.69を大きく下回り、Net GEX-87.9百万。Call Wall 120、Put Wall 110、IVレンジ109.94–119.88。IV/実現Vol比1.91でイベントリスクの織り込みも大きい。
- **マクロ:** 強い雇用は所得面で支援する一方、利上げ観測・住宅金利・ガソリン高は裁量支出を圧迫する。CPIと消費者センチメントが今週の中心。
- **ボトムアップ:** 先週Lululemonの弱い売上・見通しが警戒材料となった。今週はAcademy Sports、American Eagle、Chewy、Macy'sなどから低・中所得層の数量、値引き、在庫を確認する。[Kiplinger決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks) 120回復までUnderweight、109.94/110割れは追加減額条件。

### XLI — Industrials: Underweight 5.05%

- **オプション・価格事実:** Adjusted Score -0.269、Net GEX-121.2百万で12資産中最大の負Gamma。現値175.27はFlip 191.90と20日線180.22を下回る。Call Wall 180、Put Wall 170、IVレンジ169.76–180.78。
- **マクロ:** 8月製造業雇用+1.6万人は支援材料だが、高金利・原油高・輸送費は設備投資の採算を圧迫する。PPIと既存住宅販売から企業価格・建設需要を確認する。
- **ボトムアップ:** Core & Main、Sunbelt Rentals、AeroVironmentの決算がインフラ、レンタル稼働率、防衛需要を映す。AeroVironmentは9月2日に米陸軍から4.65億ドルの契約を獲得したと報じられたが、セクター全体の負Gammaを覆すかは180回復で確認する。[Kiplinger](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)

### IEF — 7–10年米国国債: Overweight幅縮小 40.56%

- **オプション・価格事実:** 現値92.25、Net GEX+117.7百万、Flip 91.80、Call Wall 92.5、Put Wall 92、IVレンジ91.57–92.93。オプションAdjusted Score+0.156。
- **BEI・金利事実:** 5年/10年BEIは2.37%/2.35%、加重5日変化+5.2bp・20日変化+12.0bp。BEIオーバーレイ-0.387、合成スコア+0.020。10年名目金利は4.78%。
- **見通し:** PPI/CPI鈍化とBEI低下なら上、強い物価と利上げ織り込みなら下。92.5–92.93を買い戻し確認帯、92/91.80を警戒帯、91.57割れを追加減額帯とする。

## 日別イベントとポジション対応

来週は四営業日で、9月10日のPPI、11日のCPIがIEFと金利感応セクターの主要変曲点。Oracle・Adobeが10日引け後、Krogerが11日朝に決算を公表する。[Kiplinger経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar) / [決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)

| 日付 | 主なイベント（米東部時間） | 主なETF | ポジションへの読み替え |
|---|---|---|---|
| 9/7 月 | Labor Day、株式・債券市場休場 | 全資産 | 取引なし。連休中の中東・原油ヘッドラインだけ監視 |
| 9/8 火 | 6:00 NFIB中小企業、15:00消費者信用、ABM/UNFI朝、Braze/Casey's等引け後 | XLI, XLP, XLY, XLF, IEF | 信用需要とコスト圧力を確認。第1段階50%を実施 |
| 9/9 水 | 主要経済指標なし、Academy Sports/Chewy/Core & Main等朝、AeroVironment/American Eagle等引け後 | XLY, XLI, XLB, XLV | 小売数量・在庫、インフラ、防衛需要をセクター判断へ反映 |
| 9/10 木 | 8:30失業保険・PPI/コアPPI、10:00卸売・既存住宅、Macy's等朝、Oracle/Adobe等引け後 | IEF, XLRE, XLF, XLB, XLI, XLK, XLY | PPIで第2段階。住宅はXLRE、ソフトウェア決算はXLKのFlip確認 |
| 9/11 金 | 8:00 Kroger、8:30 CPI/コアCPI、10:00ミシガン消費者信頼感、14:00財政収支 | 全資産、特にIEF/XLK/XLRE/XLU/XLY/XLP | 最大イベント。CPI・期待インフレ・BEIを揃えて最終配分を決定 |

## Vanna / Charmとガンマ運営

- **負Gamma:** XLF、XLU、XLC、XLP、XLY、XLI。特にXLI、XLY、XLPはNet GEXの負が大きく、指標・決算に対する値動きが増幅しやすい。
- **Flip近傍:** IEFはFlipの0.50%上、XLKは0.06%上、XLFは0.27%下、XLUは0.34%下。PPI/CPIとOracle/Adobe後にレジームが変わりやすいため、場中の突破ではなく終値で判定する。
- **高Vanna/Charm:** IEFはVanna集中80.8%、Charm集中93.6%で突出。株式ではXLRE/XLPのCharm、XLB/XLYのVannaが比較的高い。IV低下後のヘッジフローでWallを越える可能性があるため、Wallを固定的な抵抗・支持とはみなさない。
- **IVプレミアム:** XLB 3.33倍、XLRE 2.75倍、XLY 1.91倍、XLI 1.85倍とIV/20日実現Vol比が高い。方向が合ってもオプション買いの時間価値負担が大きく、現物配分調整を主、オプションは限定損失のイベントヘッジに使う。

## シナリオ

### 中立シナリオ — 株式59.44% / IEF40.56%へ

PPI/CPIは高止まりだが上振れず、BEIは2.32–2.40%、IEFは91.80–92.93、XLKは180.49–194.07で推移する。提案配分を段階的に完成し、XLV Overweight、XLC/XLP/XLY/XLI Underweightを維持する。

### ディスインフレ・金利低下シナリオ — IEFを42–43%へ再増額

PPI/CPIとミシガン期待インフレが鈍化し、5年/10年BEIが2.30%近辺へ低下。IEFが92.93を終値で上抜く場合、IEFを42–43%へ戻し、XLK・XLY・XLIから調達する。XLREは45を越えればNeutral内で増やす。

### 成長・AI強気シナリオ — 株式60–62%

物価が上振れず、Oracle/Adobeがクラウド・AI収益化を上方修正し、XLKが194.07、XLCが116.04、XLIが180.78を終値で上抜く。IEFを38–40%へ下げ、XLK・XLC・XLIのUnderweightを順に解消する。

### インフレ・金利上昇型弱気シナリオ — IEFも機械的に買わない

PPI/CPIが上振れ、BEIが2.40%超、IEFが91.57を割る。XLKも180.49を割る場合、株式と中期債が同時安になりうる。12資産内ではIEFを39–40%へ抑え、株式側はXLVを中心にXLE/XLFをNeutralまで使う。現金・短期債を許容する別枠運用なら、無理に12資産へ全額配分せず待機資金を置く。

## 監視水準一覧

| ETF | 配分 | Adjusted Score | Spot | Flip | Call Wall | Put Wall | 7日1σレンジ | Gamma / 判断 |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| XLV | 6.83% | +0.251 | 171.45 | 161.50 | 170 | 170 | 165.22–177.68 | 正 / OW |
| XLE | 2.38% | +0.222 | 64.06 | 62.19 | 65 | 60 | 61.81–66.31 | 正・Call Wall近傍 / Neutral |
| IEF | 40.56% | +0.020 | 92.25 | 91.80 | 92.5 | 92 | 91.57–92.93 | 正 / OW幅縮小（BEI調整後） |
| XLB | 1.25% | +0.140 | 52.44 | 49.57 | 55 | 48 | 48.88–56.00 | 正・20日線下 / Neutral |
| XLRE | 1.19% | +0.103 | 43.93 | 42.83 | 45 | 43 | 41.86–46.00 | 正・20日線下 / Neutral |
| XLK | 19.54% | +0.055 | 187.28 | 187.16 | 190 | 175 | 180.49–194.07 | 正・Flip近傍 / Neutral |
| XLF | 7.44% | -0.058 | 58.10 | 58.26 | 60 | 58 | 56.63–59.57 | 負・Flip/Put Wall近傍 / Neutral |
| XLU | 1.43% | -0.174 | 43.08 | 43.23 | 45 | 40 | 41.81–44.35 | 負・Flip近傍 / Neutral |
| XLC | 5.80% | -0.257 | 112.03 | 117.71 | 115 | 104 | 108.02–116.04 | 負 / UW |
| XLP | 2.98% | -0.258 | 84.58 | 89.69 | 86 | 78 | 82.36–86.80 | 負 / UW |
| XLY | 5.56% | -0.269 | 114.91 | 133.69 | 120 | 110 | 109.94–119.88 | 負 / UW |
| XLI | 5.05% | -0.269 | 175.27 | 191.90 | 180 | 170 | 169.76–180.78 | 負 / UW |

## データと外部参照

- モデル配分: `outputs/tables/consistent_12asset_allocation.csv`
- 最新保有週検証: `outputs/tables/latest_holding_week_attribution.csv`
- オプション指標: `outputs/tables/consistent_option_metrics.csv`
- IEFダッシュボード表: `outputs/tables/ief_dashboard.csv`
- BEI履歴・オーバーレイ: `outputs/tables/breakeven_inflation.csv`, `outputs/tables/bei_overlay.csv`
- 現在回の価格フォールバック監査表: `outputs/tables/price_fallback.csv`（今回はヘッダーのみ＝未使用）
- HTMLダッシュボード: `outputs/dashboard/sector_gamma_dashboard.html`
- 実行済みNotebook: `outputs/executed/main_20260906_executed.ipynb`
- [LPL: 9月4日までの週間市場実績](https://www.lpl.com/research/blog/weekly-market-performance-september-4-2026.html)
- [BLS: 8月雇用統計](https://www.bls.gov/news.release/archives/empsit_09042026.htm)
- [AP: 9月4日の市場・金利・原油](https://apnews.com/article/stocks-markets-oil-trump-iran-war-1af16359af43eb8abc66445465f633c8)
- [FRED: 5年BEI](https://fred.stlouisfed.org/series/T5YIE) / [10年BEI](https://fred.stlouisfed.org/series/T10YIE)
- [米財務省: 名目イールド](https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?field_tdr_date_value=2026&type=daily_treasury_yield_curve)
- [Federal Reserve: 2026年9月カレンダー](https://www.federalreserve.gov/newsevents/2026-september.htm)
- [Kiplinger: 9月7–11日の経済カレンダー](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)
- [Kiplinger: 9月7–11日の決算カレンダー](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)
- [Oracle公式決算予定](https://investor.oracle.com/investor-news/news-details/2026/Oracle-Sets-the-Date-for-its-First-Quarter-Fiscal-Year-2027-Earnings-Announcement/default.aspx)
- [Adobe公式Q3案内](https://news.adobe.com/news/2026/09/adobe-announces-anil-chakravarthy-to-become-president-and-ceo)
- [Kroger公式決算予定](https://ir.kroger.com/news/news-details/2026/Kroger-Announces-Second-Quarter-Conference-Call-with-Investors/default.aspx)
- [EIA: 2026年8月Short-Term Energy Outlook](https://www.eia.gov/outlooks/steo/archives/aug26.pdf)

## モデル検証メモ

- Notebookは非表示状態に依存せず上から完走し、オプションチェーンは11セクターETF、SPY、IEFの13銘柄すべて取得した。総行数は21,547行。
- 既存検証、前週検証、BEI、保存先、全Plotly図を含む **205/205項目がPASS**。有限なGreeks、配分合計100%、株式内Active合計0、BEIスコア恒等式、parquet・CSV・HTML保存を確認した。
- 前週検証は12資産、期間8月28日→9月4日。`戦術収益率 - 基準収益率 = 超過収益率` を確認した。
- 今回はyFinanceに9月4日の調整済み終値が揃い、価格フォールバックは未使用。最新CSVに前回の監査値が残らないよう、空監査表を毎回上書きする処理と検証をNotebookへ追加した。
