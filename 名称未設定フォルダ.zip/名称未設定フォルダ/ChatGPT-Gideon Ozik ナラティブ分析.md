# Gideon Ozik ナラティブ分析

**User:** Anonymous  
**Created:** 7/23/2026 17:57:34  
**Updated:** 7/27/2026 1:20:00  
**Exported:** 7/27/2026 7:45:00  
**Link:** [https://chatgpt.com/c/6a61d77c-1c38-83e8-8f80-946184369f20](https://chatgpt.com/c/6a61d77c-1c38-83e8-8f80-946184369f20)  

## Response:
2026/7/23 17:57:34

論文本文・補足資料・著者の講演資料・実装に言及する二次資料を突き合わせ、`narrative intensity` の定義、入力データ、正規化、集計頻度まで再現可能な形に落とします。公開情報だけでは一意に確定しない箇所は、推定部分と明示します。

中核定義は確認できました。日次 intensity は「当該ナラティブかつ所定センチメントの記事数」を、その日の当該メディア区分の**全記事数**で割る比率で、月次・週次はその日次系列の単純平均です。次に、記事分類・センチメント補正の公開範囲と非公開部分を切り分けます。

> **ウェブ検索で『Narrative Momentum』に関する論文を調査**
>
> [Narrative Momentum](https://papers.ssrn.com/sol3/Delivery.cfm/4912496.pdf?abstractid=4912496)
> [Global metrics](https://arxiv.org/html/2603.19225v2)
> [Narrative Attention Pricing](https://wp.lancs.ac.uk/fofi2024/files/2024/04/FoFI-2024-128-Hojoon-Lee.pdf)
> [Quantifying Narratives and their Impact on Financial Markets](https://www.statestreet.com/web/insights/articles/documents/ssa-quantifying-narratives-and-their-financial-impact_4862467.1.2.GBL.pdf)
> [Gideon OZIK | PhD | EDHEC Business School, Roubaix](https://www.researchgate.net/profile/Gideon-Ozik)
> [Gideon Ozik](https://scholar.google.com/citations?hl=en&user=qQUmjKAAAAAJ)
> [https://researchmap.jp/media-eng/published_papers/...](https://researchmap.jp/media-eng/published_papers/27100828?lang=en)
> [NOVEL RISKS AND SOURCES OF VOLATILITY:](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/428b4323-e4f3-4376-b2d4-0fe590d40582/jpm_the_power_of_narrative_attention.pdf)
> [Loading...](https://portal.wfsi-data.org/view/doi%3A10.60594/W43K5F)
> [Ronnie Sadka, PhD](https://sites.google.com/bc.edu/ronnie-sadka/home)
> [New Perspectives in Forecasting the Cross Section of ...](https://www.aeaweb.org/conference/2025/program/1842?q=eNqrVipOLS7OzM8LqSxIVbKqhnGVrJQMlWp1lJITS1LT84sqgXwlHaXE4uL8ZAizJLUoF8JKSYTKlmTmpkJYZZmp5SDDigoKgAKmBiCTChLTQbImSrVcMFnkXCJj)
> [https://digital.lib.washington.edu/researchworks/i...](https://digital.lib.washington.edu/researchworks/items/6c10a35f-043f-45a7-b2dd-fc0139dc09b6/full)
> [Hojoon Lee](https://hojoonlee300.github.io/documents/Lee_CV.pdf)
>
> **13 件のウェブサイトを検索しました**
>
> 
>
> **ダウンロードファイルの取得**
>
>
> **取得したダウンロードファイル**
>
> 
>
> **ウェブを検索中**
>
>
> **www.ei-navi.jp を検索**
>
> 
>
> **検索してナラティブモメンタムを分析**
>
> 
>
> **Searching for Narrative Momentum and related research**
>
> [Narrative Momentum](https://papers.ssrn.com/sol3/Delivery.cfm/4912496.pdf?abstractid=4912496)
> [Narrative](https://en.wikipedia.org/wiki/Narrative)
> [Narrative Attention Pricing](https://wp.lancs.ac.uk/fofi2024/files/2024/04/FoFI-2024-128-Hojoon-Lee.pdf)
> [「narrative」の意味・使い方・表現・読み方](https://eow.alc.co.jp/search?q=narrative)
> [How do media narratives influence the financial markets?](https://www.edhec.edu/en/research-and-faculty/edhec-vox/how-do-media-narratives-influence-financial-markets)
> [narrative Inc.](https://narratives.co.jp/)
> [NARRATIVE Definition & Meaning](https://www.merriam-webster.com/dictionary/narrative)
> [QUANTIFYING | English meaning - Cambridge Dictionary](https://dictionary.cambridge.org/dictionary/english/quantifying)
> [From Headlines to Forecasts: Narrative Econometrics in ...](https://www.mdpi.com/1911-8074/18/9/524)
> [Quantifying Narratives and their Impact on Financial Markets](https://www.statestreet.com/web/insights/articles/documents/ssa-quantifying-narratives-and-their-financial-impact_4862467.1.2.GBL.pdf)
> [CESifo Working Paper No. 12204](https://www.ifo.de/DocDL/cesifo1_wp12204.pdf)
> [narrative inc.](https://nrtv.co.jp/)
> [QUANTIFICATION](https://www.mcgill.ca/sociology/files/sociology/2008_--_qunatification.pdf)
> [Best Presentation Storytelling Techniques That Make Ideas ...](https://highbridgeacademy.com/presentation-storytelling-techniques-that-transform-data-into-decisions/)
> [Narrative: Why It's Important, and How It Works - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6701731/)
> [Telling a Good Story](https://www.lasanozfinance.com/telling-a-good-story)
> [Narrative - an overview | ScienceDirect Topics](https://www.sciencedirect.com/topics/social-sciences/narrative)
> [[Quantifying Qualitative Variables] Quantification II and its ...](https://www.youtube.com/watch?v=gqrrsAxM3r0)
> [An Analysis of Activist Short Sellers' Rhetoric* | Request PDF](https://www.researchgate.net/publication/346484649_Deploying_Narrative_Economics_To_Understand_Financial_Market_Dynamics_An_Analysis_of_Activist_Short_Sellers%27_Rhetoric)
> [Narrative-Driven Paper-to-Slide Generation via ArcDeck](https://arxiv.org/abs/2604.11969)
> [Quantifying in | Synthese | Springer Nature Link](https://link.springer.com/article/10.1007/BF00568057)
>
> **21 件のウェブサイトを検索しました**
>
> 
>
> **解析し、PDFのページのスクリーンショットを取得しました**
>
> 
>
> **ウェブを検索中**
>
> [How do media narratives influence the financial markets? | EDHEC BUSINESS SCHOOL](https://www.edhec.edu/en/research-and-faculty/edhec-vox/how-do-media-narratives-influence-financial-markets)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **調査したナラティブタグと関連事項**
>
> 
>
> **ウェブを検索中**
>
> [globalmarkets.statestreet.com](https://globalmarkets.statestreet.com/research/dam/public/docs/Product_Descriptions_Indicators.pdf)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> 8m 21s考えました

# 調査結果

Gideon Ozikらの **Narrative Momentum** について、2025年7月23日版の論文、先行する *Quantifying Narratives and Their Impact on Financial Markets*、State Street Mediastatsの仕様書、Ozikのインタビューを突き合わせました。

結論として、

> **Narrative intensity の集計式、分母、時間集計、media reservoir の統合方法、Narrative Momentumで使用する変化率は再現可能です。**  
> 一方、記事をナラティブへ分類するルールと、記事センチメントを決定する最終アルゴリズムが proprietary であるため、MKT MediaStatsと完全に同一の系列を公開情報だけで再現することはできません。

ただし、公開情報に基づく **経済的・統計的に同等な proxy series** は十分構築できます。

---

## 1. Narrative Momentum の位置づけ

最新版では、2012～2023年に point-in-time で収集された約2.3万のデジタルメディアソース、1,327万件の記事、日平均3,899件を利用し、記事を347のナラティブに分類しています。記事を後からアーカイブから取得するのではなく、その時点で収集・解析することで、削除記事や事後修正によるバックフィル・バイアスを抑えています。`Narrative Momentum.pdf`

347ナラティブのライブラリは、Reuters、IPTC、Bloombergのマクロニュースタグ、アナリストの関心テーマなどをもとに構築されています。このうち53テーマはJEL分類と対応する evergreen narratives として定義されています。`Narrative Momentum.pdf`

2023年の先行研究では、当時の73ナラティブについて、

- JEL分類
- アナリストへのインタビュー
- キーワード検索
- 文脈条件、近接条件などの textual conditions

を組み合わせた proprietary classifier を使用したと説明されています。73ナラティブの名称自体は付録で公開されています。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

したがって、2025年論文の347分類は73分類を拡張したものですが、完全な347テーマの判定辞書までは公開されていません。

---

# 2. Narrative intensity の正確な定義

## 2.1 記号

日付を $d$、media reservoirを $r$、ナラティブを $n$、記事を $a$ とします。

$$
\mathcal A_{r,d}
=
\{\text{日 }d\text{ に reservoir }r\text{ で収集された全記事}\}
$$

$$
N_{r,d}=|\mathcal A_{r,d}|
$$

記事がナラティブ $n$ に関連する場合、

$$
T_{a,n}=1
$$

それ以外は0とします。

記事のセンチメントについて、

$$
S_a^-=
\begin{cases}
1 & \text{記事 }a\text{ が negative}\\
0 & \text{otherwise}
\end{cases}
$$

$$
S_a^+=
\begin{cases}
1 & \text{記事 }a\text{ が positive}\\
0 & \text{otherwise}
\end{cases}
$$

とします。

---

## 2.2 通常の intensity

日次の通常 intensity は、

$$
\boxed{
I_{n,r,d}
=
\frac{
\sum_{a\in\mathcal A_{r,d}}T_{a,n}
}{
N_{r,d}
}
}
$$

です。

つまり、

> その日にそのmedia reservoirで収集された全記事のうち、ナラティブ $n$ に関連する記事の割合

です。

分母は、

- ナラティブ $n$ に関連する記事数
- 全ナラティブ記事数
- negative記事数

ではなく、**当該日・当該reservoirの全記事数**です。2023年論文とState Streetの仕様書の双方でこの点が明記されています。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

---

## 2.3 Negative intensity

Narrative Momentumのベースラインで使われるのは negative intensity です。

$$
\boxed{
I^-_{n,r,d}
=
\frac{
\sum_{a\in\mathcal A_{r,d}}
T_{a,n}S_a^-
}{
N_{r,d}
}
}
$$

すなわち、

> 当該ナラティブに関連し、かつnegativeと分類された記事数を、同日の全記事数で割った値

です。

重要なのは、分母がnegative記事数ではないことです。そのためこれは、

$$
P(\text{Narrative }n \cap \text{Negative})
$$

に相当し、

$$
P(\text{Negative}\mid\text{Narrative }n)
$$

ではありません。

最新版論文は、negativeおよびpositive intensityを「当該センチメントかつ当該ナラティブの記事がoverall discussionに占める割合」と定義し、値域を $[0,1]$ としています。`Narrative Momentum.pdf`

---

## 2.4 Positive intensity

同様に、

$$
\boxed{
I^+_{n,r,d}
=
\frac{
\sum_{a\in\mathcal A_{r,d}}
T_{a,n}S_a^+
}{
N_{r,d}
}
}
$$

です。

記事のセンチメント分類が positive、negative、neutral の相互排他的分類なら、

$$
I^-_{n,r,d}+I^+_{n,r,d}\le I_{n,r,d}
$$

となります。

論文の主仕様はnegative intensityですが、positive intensityを使ってもNarrative Momentumは観測されます。ただしリターンはやや弱く、positiveとnegativeの和を使った仕様でも結果は残っています。`Narrative Momentum.pdf`

---

# 3. Media reservoir

最新版では記事を次の4reservoirに分類しています。

| Reservoir | 内容 |
|---|---|
| General | CNN、Fox、NY Timesなど主要一般報道 |
| Corporate | 個別企業に関する記事 |
| FX | 通貨・外国為替に関する記事 |
| Country Equity | 国別株価指数・国別株式市場に関する記事 |

日次記事数の平均構成はGeneral 40.7%、Corporate 33.3%、FX 11.4%、Country Equity 14.7%です。`Narrative Momentum.pdf`

## Aggregate intensity

論文のメイン分析で使われるAggregateは、記事をすべてプールしてから比率を計算するのではなく、**各reservoirで計算したintensityの平均**です。

$$
\boxed{
I^{-,\mathrm{Agg}}_{n,d}
=
\frac{1}{|\mathcal R_d|}
\sum_{r\in\mathcal R_d}
I^-_{n,r,d}
}
$$

ここで $\mathcal R_d$ は日 $d$ にデータが利用可能なreservoir集合です。

収集開始日はreservoirごとに異なり、

- Corporate、Country Equity：2012年2月1日
- FX：2012年6月1日
- General：2015年9月15日

です。収集開始前のreservoirは0ではなくmissingとして扱い、Aggregateの平均から除外されます。`Narrative Momentum.pdf`

### 注意点

Aggregateは概念的に、

$$
\frac14
\left(
I_{\mathrm{General}}
+I_{\mathrm{Corporate}}
+I_{\mathrm{FX}}
+I_{\mathrm{Country}}
\right)
$$

という **reservoir equal-weight** です。

全記事をプールして計算する

$$
\frac{\sum_r N^-_{n,r,d}}{\sum_r N_{r,d}}
$$

とは異なります。後者はGeneralやCorporateの記事量に大きく左右されます。

---

# 4. 時間集計

## 4.1 月次 intensity

月 $m$ の日次intensityの単純平均です。

$$
\boxed{
I^-_{n,m}
=
\frac{1}{D_m}
\sum_{d\in m}I^-_{n,d}
}
$$

ここで $D_m$ は、その月に利用可能な日数です。

記事数を月間で合計してから分母で割る

$$
\frac{\sum_d N^-_{n,d}}{\sum_d N_d}
$$

ではありません。

したがって、記事量の多い日と少ない日は月次集計において同じ1日として扱われます。最新版論文はmonthly intensityを「当月の日次intensityの平均」と明記しています。`Narrative Momentum.pdf`

---

## 4.2 1か月の intensity change

初期の市場回帰等で用いる月次変化は、

$$
\boxed{
\Delta I^-_{n,m}
=
I^-_{n,m}-I^-_{n,m-1}
}
$$

です。`Narrative Momentum.pdf`

---

## 4.3 週次 intensity

Narrative beta推定では、水曜終値から翌水曜終値までのリターンと整合させるため、木曜から翌水曜までの日次intensityを平均します。

$$
\boxed{
I^-_{n,w}
=
\frac17
\sum_{d=\mathrm{Thu}(w-1)}^{\mathrm{Wed}(w)}
I^-_{n,d}
}
$$

$$
\boxed{
\Delta I^-_{n,w}
=
I^-_{n,w}-I^-_{n,w-1}
}
$$

週末の記事も含まれます。`Narrative Momentum.pdf`

2023年研究でも、直近7暦日の平均をweekly intensityとし、その7日前との差をweekly changeとしています。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

---

# 5. Narrative Momentumで用いる intensity signal

形成月を $t$、look-back期間を $J$ か月とします。

論文のNarrative Momentum signalは、単なる $J$ か月変化ではなく、**最近の $J$ か月平均と、その直前の $J$ か月平均との差**です。

$$
\boxed{
M^{(J)}_{n,t}
=
\frac1J\sum_{j=1}^{J}I^-_{n,t-j}
-
\frac1J\sum_{j=J+1}^{2J}I^-_{n,t-j}
}
$$

例えば $J=6$ なら、

$$
M^{(6)}_{n,t}
=
\operatorname{Avg}
\left(
I^-_{n,t-6},\ldots,I^-_{n,t-1}
\right)
-
\operatorname{Avg}
\left(
I^-_{n,t-12},\ldots,I^-_{n,t-7}
\right)
$$

です。

look-backは、

$$
J\in\{1,3,6,9,12\}\text{か月}
$$

です。

さらに、情報利用可能性を確保するため、**形成月 $t$ の直前月 $t-1$ の最終日をintensity計算から除外**します。`Narrative Momentum.pdf`

毎月、

- $M^{(J)}$ が最大の10ナラティブ：rising narratives
- $M^{(J)}$ が最小の10ナラティブ：declining narratives

に分類します。`Narrative Momentum.pdf`

ベースラインは、

$$
J=6,\qquad K=6
$$

すなわち6か月形成・6か月保有です。

---

# 6. センチメント分類で分かっていること

## 公開されている部分

最新版は、negative/positive sentimentをLoughran-McDonaldの金融センチメント分類に従うとしています。`Narrative Momentum.pdf`

2023年論文はさらに、

> 各記事のセンチメントスコアを、その記事が属するreservoirの当日のoverall toneで調整する

ことを明記しています。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

したがって概念的には、

$$
s^{\mathrm{adj}}_a
=
s^{\mathrm{raw}}_a
-
\operatorname{Tone}_{r,d}
$$

のような、日次・reservoir別のセンタリングまたは残差化が行われています。

## 公開されていない部分

次の仕様は確認できませんでした。

1. Loughran-McDonald単語数の正規化方法  
2. headlineと本文のウェイト  
3. negation処理  
4. daily tone調整が平均、中央値、回帰残差のいずれか  
5. positive／negative判定閾値  
6. 中立記事の定義  
7. 他言語記事の翻訳・辞書処理  
8. 重複記事・通信社転載記事の処理  
9. ソースごとのウェイト  
10. classifier更新時の過去データ再計算の有無  

したがって、この部分は完全再現ではなくproxy実装になります。

---

# 7. 公開情報に基づくセンチメントproxy

最も自然な再現仕様は以下です。

記事 $a$ のLoughran-McDonald positive／negative単語数を $P_a,N_a$、総単語数を $L_a$ とします。

## Raw tone

$$
s^{\mathrm{raw}}_a
=
\frac{P_a-N_a}{L_a}
$$

または、文書長への感応度を抑えるなら、

$$
s^{\mathrm{raw}}_a
=
\frac{P_a-N_a}{P_a+N_a+\epsilon}
$$

とします。

## Reservoir/day adjustment

$$
s^{\mathrm{adj}}_a
=
s^{\mathrm{raw}}_a
-
\operatorname{median}
\{s^{\mathrm{raw}}_j:j\in\mathcal A_{r,d}\}
$$

平均よりmedianのほうが極端な記事に対して頑健です。ただし、これは公開仕様ではなく推奨proxyです。

## 分類

$$
S_a^-=\mathbf 1(s^{\mathrm{adj}}_a<-\tau)
$$

$$
S_a^+=\mathbf 1(s^{\mathrm{adj}}_a>\tau)
$$

$$
S_a^0=\mathbf 1(|s^{\mathrm{adj}}_a|\le\tau)
$$

初期値は $\tau=0$ とし、人手ラベルデータを用いて $\tau$ を調整するのが自然です。

より頑健には、

- LM辞書のみ
- FinBERT
- LM＋FinBERT ensemble

の3仕様でintensityを計算し、rank correlationとNarrative Momentumの再現性を確認します。

---

# 8. ナラティブ分類の再現方法

2023年の公開説明から、単純なtopic modelよりも、**dictionary＋textual conditions型のmulti-label classifier** が原手法に近いと考えられます。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

例えばMarket Crashなら、論文中に次のような判定例があります。

- equity marketを示す語
- crash、bear、meltdown等の語
- 両者が近い位置に出現

という近接条件です。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

実装辞書は次の形式が適切です。

```yaml
narrative: market_crash

required_any:
  - stock market
  - equity market
  - s&p 500
  - nasdaq
  - nyse

event_any:
  - crash
  - meltdown
  - bear market
  - market collapse
  - selloff
  - correction

proximity:
  max_tokens: 30

exclude_any:
  - car crash
  - airplane crash
  - software crash
```

記事が複数ナラティブに該当することを許容するmulti-label方式にします。分母は全記事数であるため、ナラティブ間でintensityを足して1になる必要はありません。

公開された73テーマには、Inflation、Recession、Market Crash、Global Growth、Trade War、Federal Reserve、Labor Market、Liquidity、Housing Market、International Conflictなどが含まれています。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

---

# 9. 必要な記事データ

最低限、以下のpoint-in-timeテーブルが必要です。

| 列 | 内容 |
|---|---|
| `article_id` | 記事の一意ID |
| `published_at` | 公開日時 |
| `ingested_at` | 実際に取得した日時 |
| `source_id` | メディアソース |
| `title` | タイトル |
| `body` | 本文 |
| `language` | 言語 |
| `reservoir` | General / Corporate / FX / Country |
| `duplicate_cluster_id` | 転載・重複クラスタ |
| `narrative_tags` | 該当ナラティブのリスト |
| `sentiment_score` | 調整前または調整後スコア |
| `sentiment_label` | positive / negative / neutral |

特に `ingested_at` が重要です。バックテストでは、

$$
\mathrm{ingested\_at}\le\mathrm{signal\ cutoff}
$$

を満たす記事だけを使用しなければなりません。

---

# 10. intensity計算の参照実装

以下は、記事にreservoir、ナラティブタグ、センチメントラベルが付与済みであることを前提とします。

```python
from __future__ import annotations

import numpy as np
import pandas as pd

def calculate_narrative_intensity(
    articles: pd.DataFrame,
    narrative_universe: list[str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    MKT/Ozik型の日次 narrative intensity を計算する。

    Required columns
    ----------------
    article_id       : 記事ID
    published_at     : 公開日時
    reservoir        : General / Corporate / FX / Country
    narrative_tags   : list[str]
    sentiment_label  : negative / positive / neutral

    Returns
    -------
    reservoir_daily:
        date × reservoir × narrative の日次intensity

    aggregate_daily:
        date × narrative のreservoir等ウェイト平均
    """
    required = {
        "article_id",
        "published_at",
        "reservoir",
        "narrative_tags",
        "sentiment_label",
    }
    missing = required.difference(articles.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")

    x = articles.copy()

    x["published_at"] = pd.to_datetime(
        x["published_at"], utc=True, errors="coerce"
    )
    x = x.dropna(
        subset=["article_id", "published_at", "reservoir"]
    )

    # 実務ではduplicate_cluster_id単位で重複除去することが望ましい
    x = x.drop_duplicates(
        subset=["article_id", "reservoir"]
    )

    # midnight-to-midnightの日付。
    # 本番では採用タイムゾーンを明示する。
    x["date"] = x["published_at"].dt.floor("D").dt.tz_localize(None)

    # 分母：当日・reservoir内の全記事数
    denominator = (
        x.groupby(["date", "reservoir"], observed=True)["article_id"]
        .nunique()
        .rename("n_total")
        .reset_index()
    )

    # multi-label narrativeを縦持ち化
    tagged = x.explode("narrative_tags").rename(
        columns={"narrative_tags": "narrative"}
    )
    tagged = tagged[
        tagged["narrative"].isin(narrative_universe)
    ].copy()

    tagged["negative_article_id"] = tagged["article_id"].where(
        tagged["sentiment_label"].eq("negative")
    )
    tagged["positive_article_id"] = tagged["article_id"].where(
        tagged["sentiment_label"].eq("positive")
    )

    numerator = (
        tagged.groupby(
            ["date", "reservoir", "narrative"],
            observed=True,
        )
        .agg(
            n_narrative=("article_id", "nunique"),
            n_negative=("negative_article_id", "nunique"),
            n_positive=("positive_article_id", "nunique"),
        )
        .reset_index()
    )

    # 利用可能なdate-reservoirについて全ナラティブのグリッドを作る。
    # 該当記事がゼロのナラティブを0として扱うために必要。
    available = denominator[["date", "reservoir"]].drop_duplicates()
    narratives = pd.DataFrame({"narrative": narrative_universe})

    grid = available.merge(narratives, how="cross")

    reservoir_daily = (
        grid.merge(
            numerator,
            on=["date", "reservoir", "narrative"],
            how="left",
        )
        .merge(
            denominator,
            on=["date", "reservoir"],
            how="left",
        )
    )

    count_cols = ["n_narrative", "n_negative", "n_positive"]
    reservoir_daily[count_cols] = (
        reservoir_daily[count_cols].fillna(0)
    )

    reservoir_daily["intensity"] = (
        reservoir_daily["n_narrative"]
        / reservoir_daily["n_total"]
    )
    reservoir_daily["negative_intensity"] = (
        reservoir_daily["n_negative"]
        / reservoir_daily["n_total"]
    )
    reservoir_daily["positive_intensity"] = (
        reservoir_daily["n_positive"]
        / reservoir_daily["n_total"]
    )

    # MKT論文のAggregate：
    # 利用可能なreservoirのintensityを等ウェイト平均
    intensity_cols = [
        "intensity",
        "negative_intensity",
        "positive_intensity",
    ]

    aggregate_daily = (
        reservoir_daily
        .groupby(["date", "narrative"], observed=True)[intensity_cols]
        .mean()
        .reset_index()
    )

    return reservoir_daily, aggregate_daily
```

---

# 11. 月次・週次系列

```python
def aggregate_monthly(
    aggregate_daily: pd.DataFrame,
) -> pd.DataFrame:
    """
    月次 intensity = 日次 intensity の単純平均。
    """
    x = aggregate_daily.copy()
    x["month"] = x["date"].dt.to_period("M")

    cols = [
        "intensity",
        "negative_intensity",
        "positive_intensity",
    ]

    return (
        x.groupby(["month", "narrative"], observed=True)[cols]
        .mean()
        .reset_index()
    )

def aggregate_thursday_to_wednesday(
    aggregate_daily: pd.DataFrame,
) -> pd.DataFrame:
    """
    木曜から翌水曜までの7暦日平均。
    """
    x = aggregate_daily.copy()

    # Monday=0, Tuesday=1, Wednesday=2
    days_to_wednesday = (2 - x["date"].dt.weekday) % 7

    x["week_end"] = (
        x["date"]
        + pd.to_timedelta(days_to_wednesday, unit="D")
    )

    cols = [
        "intensity",
        "negative_intensity",
        "positive_intensity",
    ]

    weekly = (
        x.groupby(["week_end", "narrative"], observed=True)[cols]
        .mean()
        .reset_index()
        .sort_values(["narrative", "week_end"])
    )

    weekly["delta_negative_intensity"] = (
        weekly.groupby("narrative", observed=True)[
            "negative_intensity"
        ].diff()
    )

    return weekly
```

---

# 12. Narrative Momentum signal

```python
def calculate_narrative_momentum(
    aggregate_daily: pd.DataFrame,
    lookback_months: int = 6,
) -> pd.DataFrame:
    """
    Narrative Momentum signal:

    最近Jか月の平均negative intensity
    - その直前Jか月の平均negative intensity

    各月末最終日は除外する。
    """
    if lookback_months <= 0:
        raise ValueError("lookback_months must be positive.")

    x = aggregate_daily.copy()
    x["date"] = pd.to_datetime(x["date"])

    # 論文仕様：
    # 形成月直前月の最終日を除外。
    # 毎月シグナルを形成する場合、全月の月末日を除外すればよい。
    x = x[
        x["date"]
        != x["date"] + pd.offsets.MonthEnd(0)
    ].copy()

    x["month"] = x["date"].dt.to_period("M")

    monthly = (
        x.groupby(["month", "narrative"], observed=True)[
            "negative_intensity"
        ]
        .mean()
        .unstack("narrative")
        .sort_index()
    )

    recent_average = monthly.rolling(
        window=lookback_months,
        min_periods=lookback_months,
    ).mean()

    previous_average = recent_average.shift(lookback_months)

    signal = recent_average - previous_average

    # 月mまでのデータから、翌月m+1初に形成するシグナル
    signal.index = signal.index + 1
    signal.index.name = "formation_month"

    long_form = (
        signal.stack(dropna=False)
        .rename("narrative_momentum")
        .reset_index()
    )

    long_form["rank_descending"] = (
        long_form.groupby("formation_month")[
            "narrative_momentum"
        ]
        .rank(method="first", ascending=False)
    )

    long_form["rank_ascending"] = (
        long_form.groupby("formation_month")[
            "narrative_momentum"
        ]
        .rank(method="first", ascending=True)
    )

    long_form["group"] = "middle"
    long_form.loc[
        long_form["rank_descending"] <= 10, "group"
    ] = "rising"
    long_form.loc[
        long_form["rank_ascending"] <= 10, "group"
    ] = "declining"

    return long_form
```

---

# 13. Raw intensityとZ-scoreを混同しないこと

Narrative Momentum論文が用いるintensityは、基本的には $[0,1]$ の**記事比率そのもの**です。

一方、State Streetの会社・通貨・国別Media Indicatorsは、クロスセクションまたは履歴に対するz-scoreとして提供されることがあります。([State Street Markets](https://globalmarkets.statestreet.com/research/dam/public/docs/Product_Descriptions_Indicators.pdf))

また2023年研究のMarket Crash予測戦略では、別途、

$$
Z_{n,d}
=
\frac{
I^-_{n,d}-\mu_{n,d}^{(60)}
}{
\sigma_{n,d}^{(60)}
}
$$

という60日rolling z-scoreを使用しています。これはNarrative Momentumの6か月変化シグナルとは別仕様です。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

したがってベースライン再現では、最初からintensityをz-score化しないほうがよいです。

---

# 14. 完全再現に対する識別状況

| 要素 | 再現可能性 | 状況 |
|---|---:|---|
| 日次intensityの式 | 高 | 完全公開 |
| negative/positive intensityの分母 | 高 | 全記事数と判明 |
| 月次集計 | 高 | 日次単純平均 |
| 週次集計 | 高 | 木曜～水曜平均 |
| Aggregate reservoir | 高 | 利用可能reservoirの平均 |
| Momentum signal | 高 | 直近Jか月平均－その前Jか月平均 |
| 月末最終日の除外 | 高 | 明記あり |
| 73テーマ名称 | 高 | 2023年付録に公開 |
| 347テーマ名称 | 中～低 | 一部は表から取得可能、全辞書は未公開 |
| テーマ判定ロジック | 低 | keyword＋textual conditionのみ公開 |
| LMセンチメント | 中 | 辞書は公開、正規化・閾値は非公開 |
| daily tone adjustment | 低 | 調整の存在のみ公開 |
| 重複記事処理 | 低 | 非公開 |
| ソース選択・ウェイト | 低 | 非公開 |
| MKT系列との数値完全一致 | 不可能 | proprietary部分が必要 |

---

## 最終的な推奨再現仕様

論文に最も忠実な公開実装は次の仕様です。

1. point-in-timeで記事を保存  
2. 重複・転載をクラスタ単位で除去  
3. General、Corporate、FX、Country Equityへ分類  
4. 公開73テーマを起点にmulti-label rule-based classifierを構築  
5. Loughran-McDonald＋reservoir/day調整でセンチメントを分類  
6. 日次の分母をreservoir内全記事数とする  
7. reservoirごとにnegative intensityを計算  
8. 利用可能reservoirを等ウェイト平均  
9. 日次系列を単純平均して月次化  
10. 各月末最終日を除き、直近6か月平均－その前6か月平均を計算  
11. rising上位10、declining下位10を選択  
12. LM、FinBERT、辞書条件、重複処理について感応度分析を行う  

この構成なら、MKT固有の数値との完全一致ではなくとも、**Narrative Momentum論文の経済的仮説とシグナル生成過程を検証できる再現実装**になります。

---

**Sources:**

- [https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf)

## Response:
2026/7/27 0:24:44

公開73テーマと原論文の分類思想を確認し、日英混在向けの前処理・ルールエンジンを再現可能なPandas実装へ落とし込みます。

各テーマを必須概念・事象語・除外語・近接条件・言語別同義語へ分解し、監査可能な多段判定とスコアリング、検証まで一貫設計します。

> **Searching for 73 themes, docs, and tools**
>
> [GitHub - WorksApplications/SudachiPy: Python version of Sudachi, a Japanese tokenizer. · GitHub](https://github.com/WorksApplications/SudachiPy)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **検討中の実装方法**
>
> ユーザーは、73のテーマに基づくルールベースの分類子の実装に関するアーキテクチャを希望しているようです。すべてのルールを手動で記述するのは避け、YAMLやJSONでスケーラブルな設計を提案します。
>
> **検討した実装方法**
>
> 
>
> **ルールベース分類の検討**
>
> マルチラベル分類を行い、記事テーマごとにスコアリングを行います。文脈に基づいたルールを使い、証拠をリスト化。日本語と英語の正規化にも配慮し、監査可能なデータ形式にします。
>
> **検討したルールベース分類**
>
> 
>
> **ルールベース分類の設計**
>
> 候補生成の段階で、日本語と英語のルールをそれぞれ統合した正規表現を使用。後で追加された用語に対するバイアスを避けるため、辞書を日付バージョン管理します。
>
> **設計したルールベース分類**
>
> 
>
> **テーマの定義と分類**
>
> いくつかのテーマ、例えばインフレ、景気後退、労働市場などは文脈に依存。特定の用語が広すぎて誤分類しやすいため、より細かいコンテキストルールの設定が必要です。
>
> **ウェブを検索中**
>
> [GitHub - WorksApplications/sudachi.rs: Sudachi in Rust 🦀 and new generation of SudachiPy · GitHub](https://github.com/WorksApplications/sudachi.rs)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **テーマのカウントの検証**
>
>
> **検証したテーマのカウント**
>
> 
>
> **ウェブを検索中**
>
>
> **ウェブを検索中**
>
> 
>
> **ウェブを検索中**
>
> [globalmarkets.statestreet.com](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **PDFをダウンロードして保存**
>
>
> **ダウンロードしてPDFを保存した**
>
> 
>
> **WebでExhibit A1リストと関連情報検索**
>
>
> **6件のウェブサイトを検索しました**
>
> 
>
> **タイトル検出と分類の処理**
>
>
> **検出したタイトルを分類しSudachiを代替**
>
> 
>
> **Searching the web for citation sources and discrepancies**
>
> [Quantifying narratives and their impact on financial markets - More details - EconBiz](https://www.econbiz.de/Record/-/10014307598)
> [Quantifying Narratives and their Impact on Financial Markets by Rajeev Bhargava, Xiaoxia Lou, Gideon Ozik, Ronnie Sadka, Travis Whitmore :: SSRN](https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID4166640_code5355979.pdf?abstractid=4166640&type=2)
> [Insights | Research from State Street Markets | Quantifying Narratives and their Impact on Financial Markets](https://globalmarkets.statestreet.com/research/portal/insights/article/848315cc-28fb-4f47-8ce5-437ebf0acdf1)
> [Narratives in economics - Roos - 2024 - Journal of Economic Surveys - Wiley Online Library](https://onlinelibrary.wiley.com/doi/full/10.1111/joes.12576)
> [Quantifying Narratives and their Impact on Financial Markets | Request PDF](https://www.researchgate.net/publication/362573182_Quantifying_Narratives_and_their_Impact_on_Financial_Markets)
> [How do media narratives influence the financial markets? | EDHEC BUSINESS SCHOOL](https://www.edhec.edu/en/research-and-faculty/edhec-vox/how-do-media-narratives-influence-financial-markets)
> [UNDERSTANDING MARKET NARRATIVES: AN INTERDISCIPLINARY APPROACH TO IDENTIFICATION AND ANALYSIS | Modern Psychology](https://journals.ysu.am/modern-psychology/en/article/view/13030)
> [Narratives Driven Bull Market: The Indian Stock Market 2020-2024](https://www.ijraset.com/research-paper/narratives-driven-bull-market-the-indian-stock-market-2020-2024)
> [4: Instability of stock market predictability: a nod toward narratives in: Narrative Analytics and Stock Market Forecasting](https://doi.org/10.4337/9781035357604.00009)
> [From Headlines to Forecasts: Narrative Econometrics in Equity Markets](https://www.mdpi.com/1911-8074/18/9/524)
>
> **10件のウェブサイトを検索しました**
>
> 
>
> **分類器の設計提案**
>
> ニュース記事をpandas形式で扱い、精度の高い二段階の判定エンジンを設計します。日本語と英語の混在に対応し、具体的なテーマルールと証拠を出力します。
>
> **提案した分類器の設計**
>
> 
>
> **ブラウジングを使用して最新情報を取得**
>
> [Insights | Research from State Street Markets | Quantifying Narratives and their Impact on Financial Markets](https://globalmarkets.statestreet.com/research/portal/insights/article/848315cc-28fb-4f47-8ce5-437ebf0acdf1)
> [WordInfo subsetting — SudachiPy 0.6.12-a1 documentation](https://worksapplications.github.io/sudachi.rs/python/topics/subsetting.html)
> [PhraseMatcher · spaCy API Documentation](https://spacy.io/api/phrasematcher)
>
> **3件のウェブサイトを検索しました**
>
> 
>
> **リスト項目数の確認**
>
>
> **確認したリスト項目数**
>
> 
>
> **Webでunicodedataに関する情報を検索中**
>
> [unicodedata — Base de données Unicode — Documentation Python 3.9.24](https://docs.python.org/fr/3.9/library/unicodedata.html)
>
> **1件のウェブサイトを検索しました**
>
> 
>
> **Checking Sudachi package availability**
>
>
> **Checked Sudachi package availability**
>
> 
>
> **設計とルールベース文書分析**
>
>
> **設計と実装計画を策定し規則サンプルを作成**
>
> 
>
> 18m 9s考えました

# 結論

推奨する実装は、単純な「テーマ名・同義語が含まれたら該当」ではなく、各テーマについて

$$
\text{語句検出}
\rightarrow
\text{概念グループ集約}
\rightarrow
\text{論理条件}
\rightarrow
\text{近接条件}
\rightarrow
\text{除外条件}
\rightarrow
\text{テーマ別スコア判定}
$$

を順番に適用する、**監査可能なmulti-label rule engine**です。

元論文でも、73テーマへの分類は単純なkeyword countではなく、キーワード検索とtextual conditionsを組み合わせたproprietary algorithmと説明されています。例えばMarket Crashは、株式市場を示す表現と、crash・bear・meltdownなどの表現がテキスト上で近接していることを利用しています。したがって、公開情報に最も近い再現方法は、**concept groupとproximity条件を持つルールベース分類器**です。([globalmarkets.statestreet.com](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf?utm_source=chatgpt.com))

---

# 1. 全体構成

実装は、次の5つのPandasテーブルに分けるのが適切です。

## 1.1 記事テーブル `articles_df`

1行を1記事とします。

| 列 | 内容 |
|---|---|
| `article_id` | 記事の一意ID |
| `published_at` | 公開時刻 |
| `ingested_at` | システムが取得した時刻 |
| `source_id` | ニュースソース |
| `reservoir` | General / Corporate / FX / Country等 |
| `language_hint` | `ja` / `en` / `mixed` |
| `title` | 原文タイトル |
| `body` | 原文本文 |
| `duplicate_cluster_id` | 同一・転載記事クラスタ |
| `title_norm` | 正規化タイトル |
| `body_norm` | 正規化本文 |
| `rule_version` | 使用したルール版 |

`language_hint` は品質管理用であり、分類処理を日本語か英語の片方へ排他的に振り分けるためには使いません。日本語記事中に英語略称が含まれるため、同じ記事に日本語・英語両方のルールを適用します。

---

## 1.2 テーママスター `theme_master_df`

| 列 | 内容 |
|---|---|
| `theme_id` | 安定した内部ID |
| `theme_name_en` | 公開73テーマの英語名 |
| `theme_name_ja` | 日本語表示名 |
| `definition_en` | 英語の操作的定義 |
| `definition_ja` | 日本語の操作的定義 |
| `scope_in` | 含める文脈 |
| `scope_out` | 除外する文脈 |
| `parent_group` | Macro / Market / Politics等 |
| `threshold` | 自動採用閾値 |
| `review_threshold` | 人手確認閾値 |
| `rule_status` | `validated` / `provisional` / `disabled` |
| `valid_from` | テーマ・ルールの有効開始日 |
| `rule_version` | テーマ別ルール版 |

テーマ名だけでは分類ルールは定義できません。例えば以下は特に操作的定義が必要です。

- `Health` と `Healthcare`
- `Environment` と `ESG`
- `Investment` と `Equity Investing`
- `Risk`
- `Size`
- `Money`
- `Industry`
- `Governance`
- `Carry`
- `Momentum`

これらは単語単体では多くの誤検出が発生します。

---

## 1.3 語句ルール `term_rules_df`

| 列 | 内容 |
|---|---|
| `rule_id` | ルールID |
| `theme_id` | 対応テーマ |
| `concept_group` | 概念グループ |
| `lang` | `ja` / `en` / `both` |
| `expression` | 語句または正規表現 |
| `match_type` | `phrase` / `regex` / `token` |
| `field_scope` | `title` / `body` / `both` |
| `case_sensitive` | 大文字小文字を区別するか |
| `weight` | スコアウェイト |
| `effect` | `positive` / `soft_exclude` / `hard_exclude` |
| `valid_from` | ルール有効開始日 |
| `valid_to` | ルール有効終了日 |

重要なのは、同義語を直接テーマに紐付けるのではなく、いったん`concept_group`へ紐付けることです。

例えばMarket Crashでは、

- `market_scope`
- `crash_event`
- `hard_exclude`

のように分けます。

---

## 1.4 論理条件 `gate_rules_df`

テーマ判定条件は、DNF、すなわち「AND条件のOR」として保持すると柔軟です。

| `theme_id` | `clause_id` | `concept_group` |
|---|---|---|
| `inflation` | `c1` | `inflation_strong` |
| `inflation` | `c2` | `price_pressure` |
| `inflation` | `c2` | `macro_context` |

これは、

$$
\text{inflation\_strong}
\quad\lor\quad
(\text{price\_pressure}\land\text{macro\_context})
$$

を意味します。

したがって、

- 「インフレ」「CPI」「消費者物価指数」は単独で判定可能
- 「価格上昇」「値上げ」は、経済・中央銀行・金融政策等の文脈が必要

といったルールを表現できます。

---

## 1.5 近接条件 `proximity_rules_df`

| 列 | 内容 |
|---|---|
| `theme_id` | テーマ |
| `left_group` | 左側概念 |
| `right_group` | 右側概念 |
| `same_sentence` | 同一文を要求するか |
| `max_tokens` | 最大トークン距離 |
| `required` | 必須条件か |
| `weight` | 成立時の加点 |

Market Crashなら、

| theme | left | right | same sentence | max tokens |
|---|---|---|---:|---:|
| Market Crash | `market_scope` | `crash_event` | True | 30 |

とします。

---

# 2. 判定ロジックの定式化

記事 $a$、テーマ $n$、概念グループ $g$、ルール $r$、フィールド $f\in\{\text{title},\text{body}\}$ とします。

## 2.1 概念グループスコア

$$
G_{a,n,g}
=
\max_{r\in\mathcal R_{n,g}}
\left[
w_r
\max_f
\left\{
c_f\,
\mathbf 1(r\text{ がフィールド }f\text{ に一致})
\right\}
\right]
$$

初期値として、

$$
c_{\mathrm{title}}=2,\qquad
c_{\mathrm{body}}=1
$$

程度が自然です。

同じ単語が本文中に10回出たとしても、概念グループのスコアは原則1回分だけにします。記事の長さや転載文の反復による過大評価を防ぐためです。

---

## 2.2 論理ゲート

テーマ $n$ のAND条件集合を $C_n$ とすると、

$$
\Gamma_{a,n}
=
\bigvee_{c\in C_n}
\bigwedge_{g\in c}
\mathbf 1(G_{a,n,g}>0)
$$

です。

例えばMarket Crashなら、

$$
\Gamma_{a,\mathrm{MarketCrash}}
=
\text{market\_scope}
\land
\text{crash\_event}
$$

です。

---

## 2.3 最終スコア

$$
S_{a,n}
=
\sum_g G_{a,n,g}
+
\sum_p b_pP_{a,n,p}
-
\sum_e \lambda_eE_{a,n,e}
$$

ここで、

- $P_{a,n,p}$：近接条件成立
- $E_{a,n,e}$：soft exclusion成立
- hard exclusion成立時は無条件で棄却

とします。

最終ラベルは、

$$
Y_{a,n}
=
\mathbf 1
\left(
\Gamma_{a,n}=1,\,
P^{\mathrm{required}}_{a,n}=1,\,
E^{\mathrm{hard}}_{a,n}=0,\,
S_{a,n}\ge \tau_n
\right)
$$

です。

閾値 $\tau_n$ はテーマ別に設定します。全テーマに共通閾値を使うべきではありません。

---

# 3. 日本語・英語混在テキストの前処理

## 3.1 二つのテキスト表現を保持する

少なくとも以下の2種類を保持します。

1. `title_norm` / `body_norm`  
   NFKC正規化、HTML除去、空白統一を行うが、大文字小文字は保持。

2. `title_fold` / `body_fold`  
   上記に加えて英字を小文字化。

これは`Fed`のような表現を扱うために重要です。

英語の`Fed`はFederal Reserveを意味しますが、小文字の`fed`は動詞feedの過去形でもあります。したがって、`Fed`ルールについては大文字小文字を区別するか、金融政策文脈を要求します。

```python
import html
import re
import unicodedata

import pandas as pd

def normalize_text(value: object, fold_case: bool = False) -> str:
    if value is None or pd.isna(value):
        return ""

    text = html.unescape(str(value))
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"[\u2010-\u2015\u2212]", "-", text)
    text = re.sub(r"\s+", " ", text).strip()

    if fold_case:
        text = text.casefold()

    return text

articles_df["title_norm"] = articles_df["title"].map(
    lambda x: normalize_text(x, fold_case=False)
)
articles_df["body_norm"] = articles_df["body"].map(
    lambda x: normalize_text(x, fold_case=False)
)
articles_df["title_fold"] = articles_df["title"].map(
    lambda x: normalize_text(x, fold_case=True)
)
articles_df["body_fold"] = articles_df["body"].map(
    lambda x: normalize_text(x, fold_case=True)
)
```

---

## 3.2 日本語形態素解析

日本語では文字列の完全一致だけでもかなりのルールを実装できますが、以下には形態素解析が必要です。

- 活用形の吸収
- トークン距離の計算
- 複合語の分割
- 「引き締める」「引き締め」「引き締めた」等の統一
- 「落ち込む」「落ち込み」「落ち込んだ」等の統一

SudachiPyでは、現在は`Dictionary.create()`時に分割モードを指定し、`normalized_form()`や`dictionary_form()`を取得できます。SplitMode Cは長い単位を優先するため、金融用語や固有表現を保持する用途に向いています。ユーザー辞書も利用できます。([worksapplications.github.io](https://worksapplications.github.io/sudachi.rs/python/api/sudachipy.html?utm_source=chatgpt.com), [worksapplications.github.io](https://worksapplications.github.io/sudachi.rs/python/api/sudachipy.tokenizer.html?utm_source=chatgpt.com))

ユーザーの環境では依存関係を次のように追加します。

```bash
uv add sudachipy sudachidict-core
```

Notebook内では、

```python
from sudachipy import Dictionary, SplitMode

sudachi_dictionary = Dictionary(dict="core")
sudachi_tokenizer = sudachi_dictionary.create(
    mode=SplitMode.C,
    fields={
        "normalized_form",
        "dictionary_form",
        "pos",
    },
)

def tokenize_normalized(text: str) -> list[dict]:
    text = normalize_text(text, fold_case=False)

    tokens = []
    for morpheme in sudachi_tokenizer.tokenize(text):
        tokens.append(
            {
                "surface": morpheme.surface(),
                "normalized": morpheme.normalized_form(),
                "dictionary": morpheme.dictionary_form(),
                "pos": morpheme.part_of_speech(),
                "start": morpheme.begin(),
                "end": morpheme.end(),
            }
        )

    return tokens
```

Sudachi tokenizerは同一インスタンスを複数スレッドから同時利用できないため、並列化する場合はworkerごとにtokenizerを生成します。([Works Applications](https://worksapplications.github.io/sudachi.rs/python/api/sudachipy.tokenizer.html))

---

## 3.3 機械翻訳は主分類経路にしない

日本語記事を英訳して英語ルールだけで分類する方法は、ベースラインには推奨しません。

理由は、

- 翻訳モデル変更による時系列上の不連続
- 固有名詞・金融略語の翻訳揺れ
- 誤分類原因の監査が難しい
- 過去記事の再翻訳による系列改訂

です。

英語・日本語の語句を同じ`concept_group`へ登録します。

例えば、

```text
concept_group = fed_entity
```

に対して、

```text
Federal Reserve
Fed
FOMC
FRB
米連邦準備制度理事会
米連邦準備理事会
```

を登録します。

---

# 4. テーマ別ルールの作り方

## 4.1 Market Crash

### 概念グループ

```text
market_scope:
    stock market
    equity market
    S&P 500
    Nasdaq
    Dow Jones
    株式市場
    株価
    米国株
    日本株
    日経平均
    TOPIX

crash_event:
    market crash
    meltdown
    bear market
    selloff
    plunge
    暴落
    急落
    株安
    弱気相場
    市場崩壊
```

### 判定

```text
market_scope AND crash_event
AND 同一文
AND 30トークン以内
```

### 除外

```text
car crash
plane crash
system crash
自動車事故
航空事故
システムクラッシュ
アプリがクラッシュ
```

「crash」があるだけでは判定しません。

---

## 4.2 Inflation

### 強いアンカー

```text
inflation
inflationary
consumer price index
CPI
PCE deflator
インフレ
消費者物価指数
CPI
PCEデフレーター
物価高
```

### 弱い価格語

```text
price pressure
price increase
cost pass-through
価格上昇
値上げ
価格転嫁
原材料高
コスト上昇
```

### マクロ文脈

```text
central bank
monetary policy
interest rates
wages
economy
中央銀行
金融政策
金利
賃金
景気
経済
```

### 判定

$$
\text{strong anchor}
\quad\lor\quad
(\text{price pressure}\land\text{macro context})
$$

「企業が製品を100円値上げした」だけではInflationへ自動分類せず、価格転嫁や物価動向との関係が書かれている場合に分類します。

---

## 4.3 Trade War

```text
direct anchor:
    trade war
    tariff war
    貿易戦争
    関税戦争

trade_scope:
    trade
    import
    export
    tariff
    customs duty
    貿易
    輸出
    輸入
    関税

conflict_action:
    retaliatory tariff
    retaliation
    tariff escalation
    countermeasure
    報復関税
    対抗措置
    追加関税
    関税合戦
```

判定は、

$$
\text{direct anchor}
\quad\lor\quad
(\text{trade scope}\land\text{conflict action})
$$

とします。

単なる関税改定をすべてTrade Warに分類しないことが重要です。

---

## 4.4 Federal Reserve

```text
direct entity:
    Federal Reserve
    FOMC
    FRB
    米連邦準備制度理事会

person:
    Jerome Powell
    Powell
    パウエル議長

monetary context:
    policy rate
    rate cut
    rate hike
    monetary policy
    利下げ
    利上げ
    政策金利
    金融政策
```

判定は、

$$
\text{direct entity}
\quad\lor\quad
(\text{Fed person}\land\text{monetary context})
$$

とします。

`Federal Reserve`テーマに日銀記事を入れてはいけません。日本語記事であっても、

- FRB → Federal Reserve
- 日銀、BOJ → 別テーマ

です。

同様に、`Treasury Bonds`では「国債」単体を使わず、

- 米国債
- 米財務省証券
- U.S. Treasury
- Treasury note
- Treasury bond

を使用します。日本国債は含めません。

---

# 5. ルールテーブルの実装例

```python
theme_master_df = pd.DataFrame(
    [
        {
            "theme_id": "market_crash",
            "theme_name_en": "Market Crash",
            "theme_name_ja": "株式市場の暴落",
            "threshold": 5.0,
            "review_threshold": 3.0,
            "rule_status": "provisional",
            "rule_version": "1.0.0",
            "active": True,
        },
        {
            "theme_id": "inflation",
            "theme_name_en": "Inflation",
            "theme_name_ja": "インフレ",
            "threshold": 3.0,
            "review_threshold": 2.0,
            "rule_status": "provisional",
            "rule_version": "1.0.0",
            "active": True,
        },
    ]
)
```

```python
term_rules_df = pd.DataFrame(
    [
        # Market Crash: market scope
        {
            "rule_id": "mc_market_ja_001",
            "theme_id": "market_crash",
            "concept_group": "market_scope",
            "lang": "ja",
            "expression": "株式市場",
            "match_type": "phrase",
            "field_scope": "both",
            "case_sensitive": False,
            "weight": 2.0,
            "effect": "positive",
        },
        {
            "rule_id": "mc_market_en_001",
            "theme_id": "market_crash",
            "concept_group": "market_scope",
            "lang": "en",
            "expression": "stock market",
            "match_type": "phrase",
            "field_scope": "both",
            "case_sensitive": False,
            "weight": 2.0,
            "effect": "positive",
        },

        # Market Crash: crash event
        {
            "rule_id": "mc_event_ja_001",
            "theme_id": "market_crash",
            "concept_group": "crash_event",
            "lang": "ja",
            "expression": "暴落",
            "match_type": "phrase",
            "field_scope": "both",
            "case_sensitive": False,
            "weight": 3.0,
            "effect": "positive",
        },
        {
            "rule_id": "mc_event_en_001",
            "theme_id": "market_crash",
            "concept_group": "crash_event",
            "lang": "en",
            "expression": "market crash",
            "match_type": "phrase",
            "field_scope": "both",
            "case_sensitive": False,
            "weight": 3.0,
            "effect": "positive",
        },

        # Market Crash: hard exclusions
        {
            "rule_id": "mc_exclude_en_001",
            "theme_id": "market_crash",
            "concept_group": "exclude",
            "lang": "en",
            "expression": "car crash",
            "match_type": "phrase",
            "field_scope": "both",
            "case_sensitive": False,
            "weight": 10.0,
            "effect": "hard_exclude",
        },

        # Inflation
        {
            "rule_id": "inf_strong_ja_001",
            "theme_id": "inflation",
            "concept_group": "inflation_strong",
            "lang": "ja",
            "expression": "インフレ",
            "match_type": "phrase",
            "field_scope": "both",
            "case_sensitive": False,
            "weight": 3.0,
            "effect": "positive",
        },
        {
            "rule_id": "inf_strong_en_001",
            "theme_id": "inflation",
            "concept_group": "inflation_strong",
            "lang": "en",
            "expression": "inflation",
            "match_type": "phrase",
            "field_scope": "both",
            "case_sensitive": False,
            "weight": 3.0,
            "effect": "positive",
        },
        {
            "rule_id": "inf_weak_ja_001",
            "theme_id": "inflation",
            "concept_group": "price_pressure",
            "lang": "ja",
            "expression": "価格転嫁",
            "match_type": "phrase",
            "field_scope": "both",
            "case_sensitive": False,
            "weight": 1.5,
            "effect": "positive",
        },
        {
            "rule_id": "inf_context_ja_001",
            "theme_id": "inflation",
            "concept_group": "macro_context",
            "lang": "ja",
            "expression": "金融政策",
            "match_type": "phrase",
            "field_scope": "both",
            "case_sensitive": False,
            "weight": 1.5,
            "effect": "positive",
        },
    ]
)
```

論理条件は以下です。

```python
gate_rules_df = pd.DataFrame(
    [
        # Market Crash:
        # market_scope AND crash_event
        {
            "theme_id": "market_crash",
            "clause_id": "c1",
            "concept_group": "market_scope",
        },
        {
            "theme_id": "market_crash",
            "clause_id": "c1",
            "concept_group": "crash_event",
        },

        # Inflation:
        # inflation_strong
        # OR
        # price_pressure AND macro_context
        {
            "theme_id": "inflation",
            "clause_id": "c1",
            "concept_group": "inflation_strong",
        },
        {
            "theme_id": "inflation",
            "clause_id": "c2",
            "concept_group": "price_pressure",
        },
        {
            "theme_id": "inflation",
            "clause_id": "c2",
            "concept_group": "macro_context",
        },
    ]
)
```

```python
proximity_rules_df = pd.DataFrame(
    [
        {
            "theme_id": "market_crash",
            "left_group": "market_scope",
            "right_group": "crash_event",
            "same_sentence": True,
            "max_tokens": 30,
            "required": True,
            "weight": 1.0,
        }
    ]
)
```

---

# 6. 分類器の中核処理

処理フローは次のようにします。

```python
def classify_one_article(
    article: dict,
    theme_master_df: pd.DataFrame,
    compiled_term_rules: list[dict],
    gate_rules_df: pd.DataFrame,
    proximity_rules_df: pd.DataFrame,
) -> list[dict]:

    # 1. title/bodyについて全語句ルールを検出
    matches = collect_rule_matches(
        title=article["title_norm"],
        body=article["body_norm"],
        compiled_rules=compiled_term_rules,
    )

    results = []

    # 2. 各テーマを独立に判定
    for theme in theme_master_df.loc[
        theme_master_df["active"]
    ].to_dict("records"):

        theme_matches = [
            match
            for match in matches
            if match["theme_id"] == theme["theme_id"]
        ]

        # 3. hard exclusion
        hard_excluded = any(
            match["effect"] == "hard_exclude"
            for match in theme_matches
        )

        # 4. 概念グループごとの最大スコア
        group_scores = {}

        for match in theme_matches:
            if match["effect"] != "positive":
                continue

            field_multiplier = (
                2.0 if match["field"] == "title" else 1.0
            )
            score = match["weight"] * field_multiplier

            group = match["concept_group"]
            group_scores[group] = max(
                group_scores.get(group, 0.0),
                score,
            )

        matched_groups = set(group_scores)

        # 5. DNF論理条件
        gate_ok, passed_clause = evaluate_dnf_gate(
            theme_id=theme["theme_id"],
            matched_groups=matched_groups,
            gate_rules_df=gate_rules_df,
        )

        # 6. 近接条件
        proximity_ok, proximity_bonus = evaluate_proximity(
            theme_id=theme["theme_id"],
            matches=theme_matches,
            proximity_rules_df=proximity_rules_df,
        )

        # 7. スコア
        score = sum(group_scores.values()) + proximity_bonus

        if hard_excluded:
            decision = "hard_exclusion"
            is_match = False
        elif not gate_ok:
            decision = "gate_failed"
            is_match = False
        elif not proximity_ok:
            decision = "proximity_failed"
            is_match = False
        elif score >= theme["threshold"]:
            decision = "matched"
            is_match = True
        elif score >= theme["review_threshold"]:
            decision = "manual_review"
            is_match = False
        else:
            decision = "score_below_threshold"
            is_match = False

        results.append(
            {
                "article_id": article["article_id"],
                "theme_id": theme["theme_id"],
                "score": score,
                "is_match": is_match,
                "decision": decision,
                "passed_clause_id": passed_clause,
                "matched_concept_groups": sorted(matched_groups),
                "matched_rule_ids": sorted(
                    {
                        match["rule_id"]
                        for match in theme_matches
                    }
                ),
                "rule_version": theme["rule_version"],
            }
        )

    return results
```

全記事には`DataFrame.apply(axis=1)`ではなく、`itertuples()`を使います。

```python
classification_rows = []

for article in articles_df.itertuples(index=False):
    article_dict = article._asdict()

    classification_rows.extend(
        classify_one_article(
            article=article_dict,
            theme_master_df=theme_master_df,
            compiled_term_rules=compiled_term_rules,
            gate_rules_df=gate_rules_df,
            proximity_rules_df=proximity_rules_df,
        )
    )

article_theme_df = pd.DataFrame(classification_rows)
```

---

# 7. 出力はlong形式にする

主出力は記事テーブルにテーマリストを直接埋め込むのではなく、次のlong形式にします。

| article_id | theme_id | score | is_match | decision |
|---|---|---:|---:|---|
| A001 | inflation | 6.0 | True | matched |
| A001 | federal_reserve | 4.0 | True | matched |
| A002 | market_crash | 2.0 | False | gate_failed |

理由は、

- multi-labelを自然に表現できる
- テーマ別集計が容易
- ルール証跡を保存できる
- 検証用の混同行列を作りやすい
- テーマintensityへ直接変換できる

ためです。

必要なら記事テーブルへ集約表示列を戻します。

```python
assigned = (
    article_theme_df.loc[article_theme_df["is_match"]]
    .groupby("article_id")["theme_id"]
    .agg(list)
    .rename("assigned_theme_ids")
)

articles_df = articles_df.merge(
    assigned,
    on="article_id",
    how="left",
)

articles_df["assigned_theme_ids"] = (
    articles_df["assigned_theme_ids"]
    .map(lambda x: x if isinstance(x, list) else [])
)
```

---

# 8. 必ず証跡を保存する

各判定について以下を保存します。

```text
article_id
theme_id
matched_rule_ids
matched_concept_groups
matched_text
field
start_position
end_position
sentence_id
proximity_distance
exclusion_hits
passed_clause_id
score
threshold
decision
rule_version
classifier_version
```

例えば`evidence_json`に、

```json
{
  "matches": [
    {
      "rule_id": "mc_market_ja_001",
      "field": "title",
      "matched_text": "株式市場"
    },
    {
      "rule_id": "mc_event_ja_001",
      "field": "title",
      "matched_text": "暴落"
    }
  ],
  "proximity": {
    "same_sentence": true,
    "token_distance": 3
  }
}
```

を保持します。

この証跡がないと、ルール変更時に精度悪化の原因を追えません。

---

# 9. 73テーマを一度に同じ品質で実装しない

73テーマは、実装難易度によって分けるべきです。

## 比較的高精度で実装しやすいテーマ

- COVID-19
- Brexit
- Federal Reserve
- ETF
- ESG
- Buybacks
- Political Elections
- Donald Trump
- Joe Biden
- Natural Disasters
- Bankruptcy

## 文脈条件が必要なテーマ

- Inflation
- Recession
- Labor Market
- Housing Market
- International Trade
- Trade War
- Market Crash
- China Growth
- US Growth
- US Growth Slowdown
- Liquidity

## 単語単体の使用を禁止すべきテーマ

- Carry
- Momentum
- Size
- Risk
- Investment
- Money
- Industry
- Health
- Governance
- Profitability

例えば、

- `carry`ではなく`carry trade`
- `size`ではなく`size factor`、`small cap`、`小型株`
- `momentum`ではなく`momentum factor`、`price momentum`、`モメンタム投資`
- `risk`ではなく`risk appetite`、`risk-on`、`risk-off`、`市場リスク`

を使います。

全73テーマを`theme_master_df`には登録しますが、初期状態では、

```text
validated
provisional
disabled
```

を分け、検証済みテーマだけをベースラインのintensity計算に使うのが安全です。

---

# 10. 検証方法

## 10.1 人手ラベルデータ

テーマごとに次の3種類を抽出します。

1. ルールでpositiveとなった記事  
2. 一部概念だけ一致したnear miss  
3. 無作為抽出したnegative候補  

さらに、

- 日本語／英語
- タイトル一致／本文一致
- ニュースソース
- 時期
- reservoir

で層化します。

ラベルは、

```text
relevant
not_relevant
ambiguous
```

の3値で付け、評価時には`ambiguous`を別管理します。

---

## 10.2 評価指標

テーマ別に、

- Precision
- Recall
- F1
- $F_{0.5}$
- false positiveの主要原因
- false negativeの主要原因

を確認します。

multi-label評価では各テーマを独立した二値問題として評価できます。また、$F_\beta$は$\beta<1$とするとprecisionを重視できます。Narrative intensityでは誤検出が日次数値へ直接混入するため、初期ベースラインでは$F_{0.5}$またはprecision制約付きの閾値選択が適切です。([scikit-learn.org](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html?utm_source=chatgpt.com), [scikit-learn.org](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.fbeta_score.html?utm_source=chatgpt.com))

例えば、

$$
\max_{\tau_n}\operatorname{Recall}_n(\tau_n)
\quad
\text{s.t.}
\quad
\operatorname{Precision}_n(\tau_n)\ge 0.90
$$

のようにテーマ別閾値を選びます。0.90は固定ルールではなく、初期目標の例です。

---

## 10.3 ランダム分割だけで評価しない

以下を分けて評価します。

- out-of-time期間
- 未使用ニュースソース
- 日本語
- 英語
- mixed-language
- タイトルのみ短文
- 長文記事

ニュースソース固有の書き方を覚えたルールは、別ソースで急激に精度が落ちるためです。

---

## 10.4 ルールごとの回帰テスト

各テーマに、

- 必ず一致するpositive例
- 必ず除外するhard negative例
- 境界的なnear miss

を保存します。

```python
rule_test_cases_df = pd.DataFrame(
    [
        {
            "case_id": "mc_pos_001",
            "title": "米株が暴落、S&P500は3%安",
            "body": "景気懸念から株式市場で売りが加速した。",
            "expected_themes": ["market_crash"],
        },
        {
            "case_id": "mc_neg_001",
            "title": "高速道路で自動車事故",
            "body": "A car crash caused traffic delays.",
            "expected_themes": [],
        },
    ]
)
```

ルール変更ごとにこのテストを実行します。

---

# 11. 大量記事への対応

数千～数万記事なら、事前compileした正規表現を順次適用する実装で十分です。

数百万件以上では、

1. 全語句を高速matcherで一括検出  
2. 一致した語句からcandidate themeを生成  
3. candidate themeだけに論理条件・近接条件を適用  

という二段階にします。

spaCyの`PhraseMatcher`は大量の語句リストの完全一致に、`Matcher`はtoken属性や複雑な並び条件に適しています。日本語部分をSudachiで正規化したうえで、候補生成だけPhraseMatcherへ任せる構成も可能です。([spacy.io](https://spacy.io/usage/rule-based-matching/?utm_source=chatgpt.com))

Notebook実装では、

- `apply(axis=1)`を避ける
- ルールを毎記事compileしない
- 1万～5万記事程度のchunkで処理
- 正規化済みテキストをParquetへキャッシュ
- 出力を日付単位でpartition
- 同一`content_hash`を再計算しない

とします。

---

# 12. Narrative intensityへの接続

テーマ分類とセンチメント判定は別処理にします。

$$
\text{theme relevance}
\neq
\text{sentiment}
$$

です。

最終的に、

```text
article_theme_df
    article_id
    theme_id
    is_match

article_sentiment_df
    article_id
    sentiment_label
    sentiment_score
```

を結合します。

```python
matched_df = (
    article_theme_df.loc[article_theme_df["is_match"]]
    .drop_duplicates(["article_id", "theme_id"])
    .merge(
        articles_df[
            [
                "article_id",
                "published_at",
                "reservoir",
            ]
        ],
        on="article_id",
        how="left",
    )
    .merge(
        article_sentiment_df,
        on="article_id",
        how="left",
    )
)

matched_df["date"] = (
    pd.to_datetime(matched_df["published_at"])
    .dt.floor("D")
)
```

日次通常intensityは、

```python
numerator = (
    matched_df
    .groupby(["date", "reservoir", "theme_id"])["article_id"]
    .nunique()
    .rename("n_theme")
    .reset_index()
)

denominator = (
    articles_df.assign(
        date=lambda x: pd.to_datetime(x["published_at"]).dt.floor("D")
    )
    .groupby(["date", "reservoir"])["article_id"]
    .nunique()
    .rename("n_total")
    .reset_index()
)

daily_intensity_df = numerator.merge(
    denominator,
    on=["date", "reservoir"],
    how="left",
)

daily_intensity_df["intensity"] = (
    daily_intensity_df["n_theme"]
    / daily_intensity_df["n_total"]
)
```

negative intensityは、

```python
negative_numerator = (
    matched_df.loc[
        matched_df["sentiment_label"].eq("negative")
    ]
    .groupby(["date", "reservoir", "theme_id"])["article_id"]
    .nunique()
    .rename("n_theme_negative")
    .reset_index()
)
```

とします。

記事が複数テーマに該当する場合、各テーマの分子にそれぞれ1件として入ります。テーマ間で記事を按分する必要はありません。

---

# 13. 時系列研究上の重要事項

ルールには必ず、

```text
valid_from
valid_to
rule_version
```

を持たせます。

例えばCOVID-19の後から追加された別称を2015年の記事へ事後的に適用すると、厳密なpoint-in-time系列ではなくなります。

運用上は次の2系列を区別します。

### Research-recomputed series

現在の固定ルールセットを全過去期間へ適用する系列。テーマ比較や研究には使いやすいものの、完全なリアルタイム再現ではありません。

### Point-in-time production series

各時点で利用可能だったルールと記事だけを使用する系列。

$$
\mathrm{ingested\_at}
\le
\mathrm{signal\ cutoff}
$$

かつ、

$$
\mathrm{rule\ valid\ from}
\le t
<
\mathrm{rule\ valid\ to}
$$

を満たす必要があります。

---

# 14. 推奨Notebook構成

ユーザーの実装環境に合わせ、`main.ipynb`の単一Notebookで以下のセル構成にするのが適切です。

1. 環境・import  
2. パラメータ  
3. `articles_df`入力検証  
4. 公開73テーマの`theme_master_df`  
5. 日本語・英語ルールテーブル  
6. 正規化処理  
7. Sudachi tokenizer初期化  
8. ルールcompile  
9. phrase／regex検出  
10. concept group集約  
11. DNFゲート  
12. proximity判定  
13. exclusion判定  
14. multi-label分類  
15. 証跡表示  
16. 人手レビュー用サンプル  
17. テーマ別precision／recall  
18. 日本語・英語別評価  
19. 日次intensity計算  
20. Parquet保存  

最初に構築すべき成果物は、分類コードよりも、**73テーマそれぞれの`definition_ja`、`scope_in`、`scope_out`、concept groups、hard negative examplesを持つルール仕様表**です。ここが曖昧なまま実装すると、特にRisk、Investment、Health、Industry、Moneyなどのテーマで、再現不能な場当たり的ルールになります。

---

**Sources:**

- [sudachipy.tokenizer package — SudachiPy 0.6.12-a1 documentation](https://worksapplications.github.io/sudachi.rs/python/api/sudachipy.tokenizer.html)

## Response:
2026/7/27 0:50:17

前提は十分です。公開73テーマの日英ルール定義から証跡付き分類、検証、intensity集計まで、入力列を差し替え可能な自己完結Notebookとして実装します。

論文付録の一覧に合わせ、各テーマを直接アンカー、文脈付き弱語、AND・近接・除外条件へ分解し、曖昧なテーマは`provisional`として明示します。

付録で確認できる名称は72件のため、残る1件は推測せず無効プレースホルダー化します。初回実行で検出した型注釈の構文誤りを修正し、全テーマテストを継続します。

> **パーソナライズ中**
>
>
> **パーソナライズと実装要件の確認**
>
> 
>
> **監査と精査**
>
> ノートブックのコードを厳密にチェックし、重要なロジックのバグや入力処理に問題がないか確認します。出力の精度も高めるため、慎重な監査が必要です。
>
> **監査と精査を実施した**
>
> 
>
> **修正と検討**
>
> 月末除外の処理に不具合あり。直近月の最終日だけを除外し、それ以外の月は月別平均を使用する実装が必要です。
>
> **修正と検討を行った**
>
> 
>
> **タイムゾーンとパフォーマンス最適化**
>
> タイムゾーン設定を改善し、入力のローカルタイムゾーンに対応できるようにする必要があります。また、大量のデータの処理では効率性も重視すべきです。
>
> **最適化とタイムゾーンのパフォーマンス確認**
>
> 
>
> **月末除外と集計確認**
>
> 月末を除外し、データがない月にも対応した集計ロジックを検証中です。連続した月間指標が維持できるか、さらに確認して調整します。
>
> 29m 38s考えました

## 実装完了

単一のJupyter Notebookとして、ニュース記事の入力からmulti-label分類、監査ログ、Narrative Intensity、Narrative Momentum形成シグナルまで実装しました。

- [実装Notebook：narrative_73_multilabel_rule_classifier.ipynb](sandbox:/mnt/data/narrative_73_multilabel_rule_classifier.ipynb)
- [サンプル実行結果一式：narrative_classifier_sample_outputs.zip](sandbox:/mnt/data/narrative_classifier_sample_outputs.zip)

## 実装した内容

### 1. Pandas記事データの入力

最低限、次の4列があれば動作します。

```python
article_id
published_at
title
body
```

以下は任意です。

```python
ingested_at
source_id
reservoir
language_hint
duplicate_cluster_id
sentiment_label
```

実際の列名が異なる場合は、Notebook冒頭の`ARTICLE_COLUMN_MAP`で対応できます。

```python
ARTICLE_COLUMN_MAP = {
    "article_id": "storyId",
    "published_at": "versionCreated",
    "ingested_at": "ingestedAt",
    "source_id": "sourceCode",
    "reservoir": "reservoir",
    "language_hint": "language",
    "duplicate_cluster_id": "duplicateGroup",
    "title": "headline",
    "body": "body",
    "sentiment_label": "sentiment_label",
}
```

### 2. 日本語・英語テキストの正規化

次の処理を実装しています。

- Unicode NFKC正規化
- HTML tag・HTML entity処理
- 全角・半角、空白、dashの統一
- 原表記版とcasefold版の併存
- 日本語、英語、mixed-languageの簡易判定
- タイトル・本文別の処理
- exact content hashの生成
- naive timestampをAsia/TokyoとみなしてUTCへ統一

SudachiPyは任意です。分類器本体は`pandas`、`numpy`、Python標準ライブラリだけで動作します。SudachiPyがある場合は、日本語の辞書形・正規化形を監査用に表示できます。

### 3. 公開テーマ群

`theme_master_df`には73行を保持しています。

- 有効テーマ：72件
- 無効な未解決プレースホルダー：1件

論文本文は73テーマと記載していますが、公開付録Exhibit A1の機械可読テキストから確認できる固有テーマ名は72件でした。名称を推測して補わず、73件目を明示的に無効化しています。原研究の記事分類は、キーワード検索とtextual conditionsを組み合わせたproprietary algorithmと説明されています。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

73件目の名称が別資料等で確認できた場合は、プレースホルダー行を置換して`active=True`にするだけで追加できます。

### 4. 日英ルール辞書

初期状態で、次を生成します。

| テーブル | 内容 |
|---|---|
| `theme_master_df` | テーマ定義、閾値、適用範囲 |
| `term_rules_df` | 日本語・英語の語句ルール |
| `gate_rules_df` | DNF形式の論理条件 |
| `proximity_rules_df` | 同一文・最大文字距離条件 |
| `theme_conflict_rules_df` | テーマ間の優先関係 |

重複除去後の語句ルールは**1,009件**です。

`Risk`、`Money`、`Size`、`Investment`、`Industry`、`Carry`、`Momentum`などは、一般語としての誤検出を避けるため、単語単独ではなく次のような複合表現に限定しています。

```text
market risk
credit risk
money supply
size factor
business investment
industry outlook
carry trade
momentum factor
```

### 5. DNF形式の条件判定

曖昧性の高いテーマは、単純な語句一致ではなく「AND条件のOR」で判定します。

Inflationの例は、

$$
\text{direct}
\quad\lor\quad
(\text{price pressure}\land\text{macro context})
$$

です。

したがって、

```text
inflation
CPI
消費者物価指数
インフレ
```

は直接判定できますが、

```text
値上げ
価格転嫁
コスト上昇
```

だけでは判定せず、金融政策、中央銀行、賃金、経済などのマクロ文脈を要求します。

同様の条件を次のテーマに実装しています。

- China Growth
- Global Growth
- Inflation
- Trade War
- US Growth
- US Growth Slowdown
- Market Crash
- Federal Reserve

### 6. 近接条件

Market Crashは、公開資料の例に沿って、市場概念と暴落概念が同一文内で近接していることを要求します。原研究でも、市場を示す語とcrash、bear、meltdown等の語のtextual proximityが例示されています。([State Street Markets](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf))

実装例は、

$$
\text{market scope}
\land
\text{crash event}
\land
\text{same sentence}
\land
\text{distance}\le 140
$$

です。

これにより、

```text
U.S. stocks plunge as S&P 500 enters bear market
```

はMarket Crashへ分類されますが、

```text
高速道路で自動車事故
スマホアプリがクラッシュ
```

は分類されません。

### 7. タイトルと本文のウェイト

初期設定は、

$$
c_{\mathrm{title}}=2,\qquad
c_{\mathrm{body}}=1
$$

です。

同じconcept groupに複数語が一致しても、基本スコアには最大の一致だけを用います。長文記事や同義語の重複によってスコアが過大になることを抑制しています。

別文で繰り返し言及される場合だけ、小さい反復bonusを加えます。

### 8. Multi-labelとテーマ競合

同一記事へ複数テーマを付与できます。

例えば、

```text
ESG funds respond to tighter climate regulation
```

には、

```text
ESG
Environment
```

が同時に付与されます。

一方、ダミー記事の

```text
米国経済の成長鈍化が鮮明に
```

では、`US Growth Slowdown`と`US Growth`が同時に候補になり得るため、より特化した`US Growth Slowdown`を優先し、`US Growth`を次の状態へ変更します。

```text
suppressed_by_theme_priority
```

この競合解決は設定で無効化できます。

### 9. 完全な監査ログ

記事・テーマごとに、次を保存します。

- 一致したrule ID
- 一致した原文
- title／bodyのどちらか
- 開始・終了位置
- 文ID
- 一致した文
- concept group
- group別スコア
- 通過したDNF clause
- 近接距離
- exclusionの有無
- theme conflictの適用
- rule version
- classifier version

主な出力はlong形式です。

```text
article_id
theme_id
score
is_match
decision
passed_clause_id
matched_concept_groups
matched_rule_ids
matched_texts
evidence_json
```

`show_theme_evidence(article_id, theme_id)`を使うと、任意の判定証跡を展開表示できます。

### 10. Narrative Intensity

記事分類結果から、reservoir別の日次intensityを計算します。

$$
I_{n,r,d}
=
\frac{
N(\text{テーマ }n\text{ に分類された記事})
}{
N(\text{当日・reservoirの全記事})
}
$$

センチメント列があれば、negative intensityも計算します。

$$
I^-_{n,r,d}
=
\frac{
N(\text{テーマ }n\cap\text{negative})
}{
N(\text{当日・reservoirの全記事})
}
$$

Aggregateは、利用可能なreservoirの単純平均です。

$$
I^{\mathrm{Aggregate}}_{n,d}
=
\frac{1}{|\mathcal R_d|}
\sum_{r\in\mathcal R_d}
I_{n,r,d}
$$

全reservoirの記事をプールしてから比率を取る計算とは区別しています。

### 11. Narrative Momentum形成シグナル

月次intensityと、Narrative Momentumの形成シグナル関数も実装しています。

$$
M^{(J)}_{n,t}
=
\frac{1}{J}
\sum_{j=1}^{J}I_{n,t-j}
-
\frac{1}{J}
\sum_{j=J+1}^{2J}I_{n,t-j}
$$

既定値は、

```python
lookback_months = 6
intensity_column = "negative_intensity"
```

です。暦月末日の記事を除外するオプションもあります。

## 実行検証

クリーンカーネルでNotebook全体を実行し、以下を確認しました。

- コードセル17個がすべて正常終了
- テーママスター73行
- 有効テーマ72件
- 語句ルール1,009件
- 日英・mixed-language分類
- DNF条件判定
- Market Crashの交通事故除外
- Market Crashのsoftware crash除外
- US Growth Slowdownの競合解決
- reservoir別intensity
- Aggregate intensity
- 月次系列
- CSV出力

実データへ切り替える際は、Notebook冒頭を次のように変更します。

```python
USE_DUMMY_DATA = False
articles_df_input = your_news_dataframe.copy()
```

そのうえで`ARTICLE_COLUMN_MAP`だけを実際の列名へ合わせれば実行できます。

---

**Sources:**

- [https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/12452810-757d-4ce5-83a7-921292651788/jpm_quantifying_narratives.pdf)



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)