# 週次セクターGamma見通し — 2026年7月第5週

**更新日時:** 2026-07-26 22:53 JST  
**モデル基準:** 2026-07-24米国市場引け後  
**先週実績:** 2026-07-20終値〜7月24日終値  
**見通し対象:** 2026-07-27〜7月31日  
**対象:** S&P 500 11セクターETF

> 本レポートは、yFinanceの価格・オプションチェーンを用いた研究用モデルの出力であり、投資助言ではない。Signed GEXはcallを正、putを負とする簡易プロキシで、実際のディーラーポジションを直接表さない。IVレンジは7日、1標準偏差であり、週末までの実現レンジを保証しない。

## 1. エグゼクティブサマリー

先週の提案ポートフォリオはほぼ横ばいの**+0.015%**、ベンチマークは**-0.118%**で、**+0.134%（+13.37bp）**の超過収益となった。XLY Underweight、XLV・XLE・XLF Overweightがプラスに寄与し、XLI Underweightが主なマイナスだった。

今週のモデル配分は次の通り。

- **Overweight:** XLU +2.0%、XLF +1.5%、XLB +1.0%
- **Underweight:** XLY -2.0%、XLC -1.5%、XLK -1.0%
- **Neutral:** XLV、XLRE、XLE、XLI、XLP

総合1位のXLV、4位のXLRE、5位のXLEは、いずれもCall Wall直下のHard RuleによりOverweightを見送った。この結果、XLBが3番目のOverweightとなる。ただしXLBは総合スコアがマイナスでIVも高く、**強気確信ではなく、既存ルールが選んだ低確度の相対Overweight**である。

今週最大の焦点は、7月28–29日のFOMC、7月30日のGDP・PCE、Microsoft・Meta・Apple・Amazonの決算である。マクロと大型株決算が同時に集中するため、XLK・XLC・XLYの負のGammaレジームでは、好悪材料への値幅が通常より大きくなる可能性がある。

## 2. 先週の結果

### 2.1 ポートフォリオ実績

| 指標 | 7/20終値〜7/24終値 |
|---|---:|
| 前回提案ポートフォリオ | **+0.015%** |
| ベンチマーク | **-0.118%** |
| 超過収益 | **+0.134%（+13.37bp）** |

評価は前回スナップショット後の最初の利用可能な終値である7月20日から、7月24日終値までの配当調整済みETF価格を使用した。前回提案は7月20日の日中に生成されているため、7月20日の日中変動、取引コスト、税、リバランス時のスリッページは含まない。

### 2.2 Active寄与度

| ETF | 前回判断 | 実現騰落率 | Active Weight | Active寄与 |
|---|---|---:|---:|---:|
| XLY | Underweight | -4.537% | -2.00% | **+9.07bp** |
| XLV | Overweight | +2.085% | +1.50% | **+3.13bp** |
| XLE | Overweight | +2.900% | +1.00% | **+2.90bp** |
| XLF | Overweight | +0.482% | +2.00% | **+0.96bp** |
| XLK | Underweight | +0.097% | -1.50% | **-0.15bp** |
| XLI | Underweight | +2.549% | -1.00% | **-2.55bp** |

NeutralだったXLCは-4.061%、XLPは-0.860%だった一方、XLUは+3.004%、XLBは+2.459%、XLREは+1.592%だった。XLCをUnderweightにしなかったことと、XLUをOverweightにしなかったことは、結果論では改善余地となる。

### 2.3 ニュースとの対応

[LPLの週間集計](https://www.lpl.com/research/blog/weekly-market-performance-july-24-2026.html)では、S&P 500は-0.77%、Nasdaqは-2.28%。セクターはEnergy +4.07%、Utilities +2.33%、Industrials +1.60%が上位、Consumer Discretionary -6.38%、Communication Services -5.90%が下位だった。ETF実績とは計算時点・指数構成が異なるが、方向は概ね一致する。

- **XLY Underweight:** Teslaは利益が市場予想を下回り、7月23日に14.5%下落したと[AP](https://apnews.com/article/45b9165d6c518f5bea668b6ba7a89838)が報じた。前回の負のGEX、Gamma Flip下、総合最下位という警戒が実現し、最大のプラス寄与となった。
- **XLC Neutral:** Alphabetは業績自体よりAI設備投資の拡大が嫌気され、XLCは大幅下落した。前回モデルはOverweightを禁止していたが、Active Weightを0%にとどめたため、下落回避を十分に収益化できなかった。
- **XLE Overweight:** 原油が週間+8.56%、Brentが一時100ドルを超えた。前回、XLEを戦術的Overweightへ変更した判断は有効だった。
- **XLV Overweight:** 市場全体が下落する中でETFは+2.08%。正のGEXとディフェンシブ性が機能した。
- **XLI Underweight:** 資本財・防衛・輸送株が堅調で、モデルの弱気判断に反して上昇した。負のGEXを重視しすぎ、実体経済・受注の底堅さを過小評価した。
- **XLK Underweight:** XLKはほぼ横ばいで、Underweightは小幅なマイナス。AlphabetのAI投資懸念はあったが、Intelの良好な決算や半導体反発が相殺した。

### 2.4 先週からの修正点

- XLYの負のGammaとボトムアップ決算リスクを結びつけた判断は維持する。
- XLCはAlphabet決算後も負のGEX、20MA・50MA割れ、9%超のドローダウンとなったため、今週はNeutralからUnderweightへ下げる。
- XLUは正のGamma、価格モメンタム、FOMCの金利イベントを組み合わせ、今週は最大Overweightへ上げる。
- XLIは先週の上昇を受けUnderweightを解除する。ただしNet GEXは依然負で、185のCall Wallを突破できるか確認する。
- XLEは方向自体は強いが60のCall Wall直下となったため、利益を追わずNeutralへ戻す。

## 3. 今週のマクロ環境

### 確認できる事実

- FRB公式日程では[FOMCが7月28–29日](https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm)に開催される。7月会合は経済見通しの公表回ではない。
- [BEA公式日程](https://www.bea.gov/news/schedule)では7月30日8:30 ETに、4–6月期GDP速報値と6月Personal Income and Outlays/PCEが同時公表される。
- 7月31日8:30 ETには[BLSの雇用コスト指数](https://www.bls.gov/eci/)が公表される。7月雇用統計は今週ではなく8月7日の予定である。
- 6月新築住宅販売は年率62.8万戸、前月比+1.6%、在庫月数9.3カ月、中央値39万8,300ドルだった。ただし前月比の誤差範囲は大きい。[米国国勢調査局](https://www.census.gov/construction/nrs/current/index.html)
- 7月Flash PMIは製造業の拡大が続き、主要先進国全体でも活動が改善した一方、価格圧力と中東情勢がリスクとして残った。[S&P Global](https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/07/flash-pmis-signal-faster-growth-across-major-developed-economies-but-supply-chain-and-price-concerns-cloud-outlook)
- 先週は原油上昇と低い新規失業保険申請件数を受け、利下げ期待が後退し金利が上昇した。

### モデル推論

今週は「FOMCが動くか」だけでなく、声明・会見後に翌朝のGDP/PCEが政策解釈を上書きする点が重要である。

- **政策据え置き・インフレ警戒:** XLFには利鞘面で中立からプラス、XLU・XLRE・XLK・XLYには割引率上昇でマイナス。
- **据え置き・将来の緩和を示唆:** XLU・XLREに最も直接的な追い風。XLKも反発しうるが、決算とGamma Flip回復が必要。
- **利上げまたは強いタカ派:** 原油高と組み合わさると、XLY・XLK・XLCの負のGammaが下落を増幅しやすい。XLFも信用コスト上昇が利鞘改善を相殺する。
- **GDP堅調・PCE鈍化:** 最も株式に好都合。XLI・XLB・XLKの景気感応度とXLU・XLREの金利感応度が同時に改善する可能性がある。
- **GDP鈍化・PCE高止まり:** スタグフレーション型。XLE以外の幅広いセクターに逆風となる。

## 4. 更新配分

| 総合順位 | ETF | 総合 / IV調整スコア | Benchmark | Active | Proposed | Hard Rule | 判断 |
|---:|---|---:|---:|---:|---:|---|---|
| 1 | XLV | 1.350 / 1.150 | 9.49% | 0.00% | 9.49% | OW不可 | Neutral |
| 2 | XLU | 1.325 / 0.975 | 2.50% | **+2.00%** | **4.50%** | OW可 | Overweight |
| 3 | XLF | 1.275 / 0.925 | 12.59% | **+1.50%** | **14.09%** | OW可 | Overweight |
| 4 | XLRE | 1.275 / 1.175 | 2.00% | 0.00% | 2.00% | OW不可 | Neutral |
| 5 | XLE | 1.125 / 0.875 | 4.00% | 0.00% | 4.00% | OW不可 | Neutral |
| 6 | XLI | 0.125 / 0.025 | 8.99% | 0.00% | 8.99% | OW不可 | Neutral |
| 7 | XLB | -0.125 / -0.525 | 2.10% | **+1.00%** | **3.10%** | OW可 | Overweight・低確度 |
| 8 | XLP | -0.800 / -0.900 | 5.29% | 0.00% | 5.29% | OW不可 | Neutral |
| 9 | XLK | -1.275 / -1.525 | 32.87% | **-1.00%** | **31.87%** | OW不可 | Underweight |
| 10 | XLC | -1.500 / -1.600 | 10.29% | **-1.50%** | **8.79%** | OW不可 | Underweight |
| 11 | XLY | -2.100 / -2.200 | 9.89% | **-2.00%** | **7.89%** | OW不可 | Underweight |

**整合性:** Proposed Weight合計100.00%、Active Weight合計0.00%。既存のベンチマーク、スコア係数、Hard Rule、配分ルールは変更していない。

## 5. 全11セクターの見通し

### XLU 公益 — Overweight +2.0%

**マクロ:** FOMCの据え置き・将来緩和示唆なら最も素直な金利低下受益。反対に利上げや長期金利上昇は債券代替としての評価を圧迫する。AI・データセンター向け電力需要は中期追い風だが、規制投資と資金調達費用を差し引く必要がある。

**ボトムアップ:** CenterPoint、CMS、DTE、Entergy、WEC、American Water、AEP、Southern、Xcel、Dominionなどの決算が集中する。レートベース成長、設備投資、規制回収、燃料費転嫁、データセンター接続需要を確認する。

**オプション構造:** Spot 46.29、Net GEX +22.24m、Flip 45.06、Call Wall 46、Put Wall 45。7日レンジ44.85–47.73。正のGammaだが、主要3水準がレンジ内にありHigh Charm。

**判断:** モメンタムと正のGammaを評価し最大OW。ただし46を上抜けた後の追随であり、FOMCタカ派時は45.06が撤退線。44.85割れでNeutralへ戻す。

### XLF 金融 — Overweight +1.5%

**マクロ:** 高金利は利鞘・運用収益に追い風だが、利上げが信用需要や与信費用を悪化させる場合は逆効果。GDP、PCE、雇用コストを通じて「金利水準」より「金利上昇の理由」を分ける。

**ボトムアップ:** Visa、Mastercard、ICE、CBOE、S&P Global、Aon、KKR、カード・資産運用各社の決算から、決済数量、クロスボーダー、取引量、運用残高、信用費用を確認する。

**オプション構造:** Spot 56.31、Net GEX +63.98m、Flip 55.11、Call/Put Wall 56、7日レンジ54.50–58.12。正のGamma、強いモメンタムだがWallをわずかに上回り、High Charm。

**判断:** OW継続。ただし55.11のFlipが予想レンジ内にあるため、FOMC後に55.11を割ればNeutral。58.12付近は利食い候補。

### XLB 素材 — Overweight +1.0%、低確度

**マクロ:** 耐久財受注、GDP、住宅、原油・輸送費、ドルが同時に影響する。景気拡大なら数量に追い風だが、原油・関税・原材料上昇は化学・建材のマージンを圧迫する。

**ボトムアップ:** Nucor、Sherwin-Williams、PPG、Vulcan、Air Products、CRH、Martin Marietta、Corteva、Eastman、Olin、Lindeなどから、数量、価格、稼働率、原料スプレッド、建設需要を確認する。

**オプション構造:** Spot 51.26、Net GEX +19.54m、Flip 48.16、Call Wall 55、Put Wall 47.5。ATM IV 65.65%、7日レンジ46.60–55.92で、Flip・両Wallがすべてレンジ内。総合-0.125、IV調整-0.525、Option Demand -1.25。

**判断:** 3番目のOW可能銘柄として機械的に+1.0%となったが、絶対スコアは弱い。ポジションは小さく維持し、48.16割れで即Neutral。55到達は追わず利益管理を優先する。

### XLV ヘルスケア — Neutral、上方候補

**マクロ:** 景気減速に強く、金利への直接感応度も成長株より小さい。一方、医療費インフレ・政策・保険採算が企業間の差を広げる。

**ボトムアップ:** Universal Health、AstraZeneca、Biogen、Humana、GE HealthCare、Bristol Myers、Regeneron、Cigna、Labcorp、AbbVie、Strykerなど。病院数量・人件費、保険利用率、医薬品パイプライン、医療機器受注を確認する。

**オプション構造:** Spot 162.57、Net GEX +66.32m、Flip 142.02、Call Wall 165、Put Wall 155、7日レンジ153.42–171.72。総合1位だがCall Wallまで1.49%でHard Ruleに抵触。High Vanna。

**判断:** 弱気ではなく「買い位置待ち」。165を決算後に明確に上抜ければ最優先のOW候補。155割れでは正のGammaでもリスクを落とす。

### XLRE 不動産 — Neutral、上方候補

**マクロ:** FOMCと長期金利が最大要因。6月新築住宅販売は前月比増加したが在庫月数は9.3カ月で、住宅関連はまだ金利に敏感。

**ボトムアップ:** Brixmor、Kilroy、Sun Communities、UDR、Welltower、American Tower、BXP、Extra Space、Equinix、Essex、Invitation Homes、Public Storage、Ventas、VICIなど。FFO、入居率、更新賃料、借換金利、データセンター需要を確認する。

**オプション構造:** Spot 45.95、Net GEX +1.94m、Flip 42.32、Call Wall 46、7日レンジ44.71–47.19。IV調整スコアは全セクター1位だが、Call Wallまで0.11%でOW禁止。

**判断:** FOMCがハト派で46を明確に上抜ければ、XLVと並ぶ上方修正候補。44.71割れは金利上昇または決算失望として扱う。

### XLE エネルギー — Neutral

**マクロ:** Hormuz・Red Seaの供給リスクは上流企業に追い風だが、原油が100ドル近辺まで上昇した局面ではニュース反転時の下落も大きい。FOMC・PCEにはインフレ経路で影響する。

**ボトムアップ:** Noble、HF Sinclair、Expand Energy、Antero、Valero、TechnipFMCに加え、金曜のExxon MobilとChevronが週の総括となる。生産量、実現価格、精製マージン、LNG・天然ガス、設備投資、株主還元を確認する。

**オプション構造:** Spot 59.62、Net GEX +42.14m、Flip 57.21、Call Wall 60、Put Wall 55、7日レンジ56.23–63.01。強いモメンタムだがCall Wallまで0.64%、ATM IV 41.04%、High Charm。

**判断:** 前週OWからNeutralへ利益管理。60を決算前に追わない。60を出来高を伴って突破すれば再OW、57.21割れで弱気へ転換する。

### XLI 資本財 — Neutral

**マクロ:** 耐久財受注とGDPが数量面、原油と金利がコスト・評価面を左右する。防衛・電力設備は強い一方、運輸は燃料費と景気に敏感。

**ボトムアップ:** Boeing、UPS、ITW、PACCAR、Textron、General Dynamics、L3Harris、Vertiv、Old Dominion、Waste Management、Quanta、Eatonなど。受注、バックログ、納入、価格、燃料費、設備投資を確認する。

**オプション構造:** Spot 182.66、Net GEX -61.15m、Call Wall 185、Put Wall 165、7日レンジ172.69–192.63。Net GEXは負だが前週上昇で20MA・50MA上を維持。Call Wallまで1.28%でOW不可。

**判断:** 前週のUnderweightを解除。185を突破し、耐久財・企業ガイダンスが強ければOW候補。172.69割れなら負のGammaを重視して再Underweight。

### XLP 生活必需品 — Neutral

**マクロ:** PCEと雇用コストは価格転嫁力と実質消費を測る。原油高は包装・物流費を押し上げる一方、景気不安はディフェンシブ需要を支える。

**ボトムアップ:** Coca-Cola、Mondelez、Procter & Gamble、Altria、Hershey、Church & Dwight、Colgate-Palmoliveなど。値上げ、数量、販促、原材料、為替、粗利を確認する。

**オプション構造:** Spot 84.13、Net GEX -27.32m、Flip 100.96、Call Wall 85、Put Wall 78、7日レンジ80.67–87.59。20MAをわずかに下回り、Gamma Score -3.00、High Charm。

**判断:** Neutralだが弱含み。85を決算後に回復できなければ上値は重い。80.67割れでUnderweight候補、85突破と数量改善がそろえばNeutral維持。

### XLK 情報技術 — Underweight -1.0%

**マクロ:** AI設備投資は成長源だが、金利上昇と投資回収への疑問が同時にバリュエーションを圧迫する。今週はFOMCとGDP/PCEの間に大型決算が集中する。

**ボトムアップ:** MicrosoftはAzure・AI需要と設備投資回収、Qualcomm・Lam・Armは半導体需要、AppleはiPhone・Services・中国・AI機能、各社とも設備投資・粗利・フリーキャッシュフローを確認する。Microsoftは7月29日、Appleは7月30日に発表予定。[Apple IR](https://www.apple.com/investor/earnings-call/)

**オプション構造:** Spot 175.88、Net GEX -11.82m、Flip 181.04、Call Wall 200、Put Wall 170、7日レンジ166.50–185.26。20MA・50MA下、60日高値から-11.16%、IV調整後9位、High Charm。

**判断:** Underweight継続。ただし前週より幅を-1.0%へ縮小。181.04回復でNeutral、170割れでUW拡大、166.50割れは下方加速警戒。

### XLC コミュニケーション・サービス — Underweight -1.5%

**マクロ:** 広告はGDP・消費に、通信は金利と設備投資に左右される。大型プラットフォームのAI投資回収がセクター全体の評価を決めやすい。

**ボトムアップ:** Metaは7月29日引け後に発表予定で、広告単価・表示回数、AI推薦、設備投資、Reality Labs損失が焦点。[Meta IR](https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-to-Announce-Second-Quarter-2026-Results/default.aspx) Omnicom、Reddit、Sirius XMなども広告・利用者・価格動向を補完する。

**オプション構造:** Spot 106.30、Net GEX -66.79m、Flip 127.56、Call Wall 115、Put Wall 104、7日レンジ101.33–111.27。20MA・50MA下、60日高値から-9.20%、Put Wallがレンジ内。

**判断:** 前週NeutralからUnderweightへ。111.27回復でUW縮小、115突破でNeutral。104割れ、特に101.33割れは負のGamma下の下方加速を想定する。

### XLY 一般消費財 — Underweight -2.0%

**マクロ:** 名目消費が維持されても、金利・原油・雇用コストは自動車、住宅、旅行、外食、耐久財へ逆風。FOMCとPCEの双方に高い感応度を持つ。

**ボトムアップ:** Ford、Hilton、Starbucks、Chipotle、O'Reilly、Amazon、Crocs、Rivian、住宅・自動車関連企業の決算を確認する。Amazonは7月30日引け後で、EC販売、AWS、広告、設備投資、マージンが焦点。[Amazon IR](https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-to-Webcast-Second-Quarter-2026-Financial-Results-Conference-Call/default.aspx)

**オプション構造:** Spot 109.41、Net GEX -70.43m、Flip 131.29、Call Wall 120、Put Wall 107.5、7日レンジ103.77–115.05。総合・IV調整とも最下位、20MA・50MA下、60日高値から-10.19%、Put Wallまで1.75%。

**判断:** 最大Underweightを維持。115.05回復で縮小を検討、120回復でNeutral。107.5割れは103.77までの下方拡大を警戒する。

## 6. 日別イベント対応

### 7月27日（月）：耐久財受注

**事実:** 6月耐久財受注、資本財受注・出荷が中心。決算はCadence、Celestica、Nucor、REIT各社、Universal Healthなど。

**対応:**

- XLIは企業設備投資と輸送機器を185のCall Wallへ接続する。
- XLBはNucorと資本財需要を確認するが、高IVのため55方向を追いかけない。
- XLREはREIT決算で46突破を試すか確認する。
- XLKはCadence・半導体製造周辺のAI設備投資需要を確認する。

### 7月28日（火）：FOMC開始、住宅価格・消費者信頼感

**事実:** FOMC初日。貿易・在庫、Case-Shiller住宅価格、Consumer Confidence。Boeing、UPS、Coca-Cola、GSK、公益、資本財、Visaなどの決算。

**対応:**

- XLU/XLREはFOMC前の金利変化と46近辺のWallを監視する。
- XLIはBoeing・UPS・ITW・PACCARで受注と輸送数量を確認。
- XLPはCoca-Cola、XLFはVisaの数量・価格データを消費の先行情報として使う。
- XLEはHF Sinclair・Expand Energy等から原油高の実現収益と設備投資を確認。

### 7月29日（水）：FOMC、Microsoft、Meta

**事実:** 2:00 ETにFOMC声明、2:30 ETに議長会見。引け後にMicrosoft、Meta、Qualcomm、Lam Researchなど。日中はP&G、Humana、Biogen、General Dynamics、L3Harris、REIT・銀行・資本財決算。

**対応:**

- FOMC直後はXLU 45.06、XLRE 46、XLF 55.11を優先監視する。
- XLKはMicrosoftと半導体決算を181.04のFlipへ接続する。回復できなければAI業績が良くてもUW継続。
- XLCはMeta決算後の104–111.27レンジ離脱を重視する。
- XLP/XLV/XLIはP&G、Humana、防衛企業の実需ガイダンスで相対強弱を確認する。

### 7月30日（木）：GDP、PCE、Apple、Amazon

**事実:** 8:30 ETに4–6月期GDP速報、6月PCE、個人所得・支出、失業保険申請件数。引け後にAppleとAmazon。日中はMastercard、AEP、Bristol Myers、Regeneron、Cigna、Air Products、CRH、Martin Marietta、Valeroなど。

**対応:**

- GDP上振れ・PCE下振れならXLI/XLBとXLU/XLREが同時に改善しうる。
- PCE上振れならXLU/XLRE/XLY/XLKに逆風。XLFは利鞘と信用の綱引きとなる。
- XLKはApple決算後も181.04が分岐点。
- XLYはAmazon決算後に107.5と115.05のどちらを抜けるかで判断する。
- XLEはValero等の精製マージンを金曜の大手統合石油へつなぐ。

### 7月31日（金）：雇用コスト、Exxon、Chevron

**事実:** 8:30 ETに4–6月期Employment Cost Index、Chicago PMI、Michigan Sentiment確報。Exxon Mobil、Chevron、AbbVie、CBOE、Dominion、Eaton、Lindeなどの決算。

**対応:**

- ECI上振れは金利上昇を通じXLU・XLRE・XLK・XLYへ逆風。
- Exxon/Chevronの生産・株主還元が強く、XLEが60を突破すれば再OW候補。
- AbbVieはXLVの165突破、DominionはXLUの46定着、EatonはXLIの185突破を確認する材料。
- 週末の中東ヘッドラインをまたぐため、XLEのオプションIV低下と原油急変を別々に管理する。

## 7. Vanna / Charm

- **High Vanna:** XLV
- **High Charm:** XLU、XLF、XLE、XLP、XLK
- **両方High:** なし

モデル上の解釈は次の通り。

- XLVは大型医薬・保険・医療機器決算後のIV低下が、165突破または155接近時のヘッジ調整を増幅しうる。
- XLKはMicrosoft・Apple等の決算後にIVが低下し、181.04または170へ向かうCharmフローが変わりやすい。
- XLU、XLF、XLE、XLPは主要Wall近辺にあるため、時間経過によるピン留めとWall離脱時のフロー反転を監視する。
- Vanna/Charmフラグは方向予想ではなく、ニュースに対する値動きの出方を示す補助情報として使う。

## 8. シナリオ

### 強気

FOMC据え置きかつ将来の緩和余地を示唆、GDPは堅調、PCE・ECIは鈍化。Microsoft・Meta・Apple・AmazonがAI投資の回収可能性を示す。

- XLUは47.73、XLREは47.19、XLFは58.12を試す。
- XLKが181.04を回復し、XLCが111.27、XLYが115.05を超えればUWを縮小する。
- XLBは55到達で利益確定し、追い上がりを避ける。

### 中立

FOMCは据え置きでタカ派・ハト派が混在、GDP/PCEと大型決算もまちまち。主要ETFはIVレンジ内で推移する。

- 現行のXLU・XLF・XLB OW、XLK・XLC・XLY UWを維持する。
- XLV・XLRE・XLEはCall Wall突破待ち。
- これを基本シナリオとする。

### 弱気

利上げまたは強いインフレ警戒、PCE・ECI上振れ、GDP鈍化、AI設備投資の回収懸念、原油供給ショックが重なる。

- XLY 107.5、XLC 104、XLK 170割れで負のGammaによる下方加速を想定する。
- XLUは45.06、XLFは55.11、XLBは48.16割れでOWを解消する。
- XLEは相対的に強くても、60を超えられず57.21を割る場合は原油高メリットが株価に織り込み済みと判断する。

## 9. 監視水準

| ETF | 上方向 | 下方向 | 判断変更条件 |
|---|---|---|---|
| XLU | 47.73 | 45.06、44.85 | 45.06割れでOW解消 |
| XLF | 58.12 | 55.11、54.50 | 55.11割れでNeutral |
| XLB | 55、55.92 | 48.16、47.5、46.60 | 48.16割れでOW解消 |
| XLV | 165、171.72 | 155、153.42 | 165突破でOW候補 |
| XLRE | 46、47.19 | 44.71、42.32 | 46突破と金利低下でOW候補 |
| XLE | 60、63.01 | 57.21、56.23、55 | 60突破で再OW候補 |
| XLI | 185、192.63 | 172.69、165 | 185突破でOW候補 |
| XLP | 85、87.59 | 80.67、78 | 80.67割れでUW候補 |
| XLK | 181.04、185.26 | 170、166.50 | Flip回復でNeutral |
| XLC | 111.27、115 | 104、101.33 | 115突破でNeutral |
| XLY | 115.05、120 | 107.5、103.77 | 120回復でNeutral |

## 10. 外部参照

- [LPL Financial — Weekly Market Performance, July 24, 2026](https://www.lpl.com/research/blog/weekly-market-performance-july-24-2026.html)
- [Federal Reserve — FOMC Meeting Calendar](https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm)
- [BEA — Release Schedule](https://www.bea.gov/news/schedule)
- [BLS — Employment Cost Index](https://www.bls.gov/eci/)
- [U.S. Census Bureau — New Residential Sales, June 2026](https://www.census.gov/construction/nrs/current/index.html)
- [S&P Global — July Flash PMI Commentary](https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/07/flash-pmis-signal-faster-growth-across-major-developed-economies-but-supply-chain-and-price-concerns-cloud-outlook)
- [Kiplinger — Economic Calendar, July 27–31](https://www.kiplinger.com/investing/economy/this-weeks-economic-calendar)
- [Kiplinger — Earnings Calendar, July 27–31](https://www.kiplinger.com/investing/stocks/17494/next-week-earnings-calendar-stocks)
- [Meta Investor Relations — Q2 2026 Results Date](https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-to-Announce-Second-Quarter-2026-Results/default.aspx)
- [Apple Investor Relations — Q3 2026 Earnings Call](https://www.apple.com/investor/earnings-call/)
- [Amazon Investor Relations — Q2 2026 Results Date](https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-to-Webcast-Second-Quarter-2026-Financial-Results-Conference-Call/default.aspx)
- [AP — Alphabet, Tesla and oil market reaction](https://apnews.com/article/45b9165d6c518f5bea668b6ba7a89838)

## 11. 内部成果物

- 実行済みNotebook: `outputs/executed/main_20260726_executed.ipynb`
- 最新ダッシュボード: `outputs/dashboard/sector_gamma_dashboard.html`
- 更新配分: `outputs/tables/proposed_portfolio.csv`
- GEX判断表: `outputs/tables/gex_decision_table.csv`
- IV予想変動表: `outputs/tables/iv_expected_move_table.csv`
- Vanna/Charm表: `outputs/tables/second_order_greeks_table.csv`
- 前週寄与度: `outputs/tables/weekly_attribution.csv`
- 日付別処理済みデータ: `data/processed/20260726/`

---

**次回確認:** 7月29日FOMC後、7月30日GDP/PCEおよびApple/Amazon決算後に、負のGammaであるXLK・XLC・XLYと、Call Wall直下のXLV・XLRE・XLEを優先して再評価する。

## 12. 追記 — 11セクター＋IEFの一貫運用

2026-07-27取得のオプションチェーンで、11セクターとIEFを同じ正規化指標（GEX Balance、Gamma Flip距離、Wall位置、Put/Call需要、IV Skew、トレンド）により再評価した。IV/実現Vol、Vanna、Charmは方向ではなく確信度を減衰させる要因として扱う。

株式Composite Scoreは-0.156、IEF Adjusted Scoreは-0.149で差が小さく、算出上の株式シフトも-0.07ポイントにとどまった。0.50ポイントのノートレード帯を下回るため、**資産クラスは株式60.00% / IEF40.00%を維持**する。

株式60%の内部は固定Top 3ではなく、ベンチマークからの連続ティルトへ更新する。最終ポートフォリオは次の通り。

| 資産 | 60/40基準 | 一貫型モデル | 基準差 | 判断 |
|---|---:|---:|---:|---|
| XLK | 19.72% | **19.00%** | -0.72pt | Underweight |
| XLF | 7.55% | **8.65%** | +1.10pt | Overweight |
| XLV | 5.69% | **5.69%** | +0.00pt | Neutral |
| XLY | 5.93% | **5.21%** | -0.72pt | Underweight |
| XLC | 6.17% | **5.45%** | -0.72pt | Underweight |
| XLI | 5.39% | **5.39%** | +0.00pt | Neutral |
| XLP | 3.18% | **2.96%** | -0.22pt | Underweight |
| XLE | 2.40% | **2.40%** | +0.00pt | Neutral |
| XLU | 1.50% | **2.17%** | +0.67pt | Overweight |
| XLB | 1.26% | **1.87%** | +0.61pt | Overweight |
| XLRE | 1.20% | **1.20%** | +0.00pt | Neutral |
| **株式合計** | **60.00%** | **60.00%** | **0.00pt** | Neutral |
| **IEF** | **40.00%** | **40.00%** | **0.00pt** | Neutral |

第4節の`proposed_portfolio.csv`は既存スコアの履歴と前週寄与度検証のため維持する。**株式60%＋IEF40%を実際に運用する際の正データは`consistent_12asset_allocation.csv`**とする。個別セクターのマクロ・ボトムアップ・Options-Implied根拠、監視水準、イベント別対応は[クロスアセット詳細レポート](cross_asset_outlook_20260727.md)第8節に記載した。

- 最終12資産配分: `outputs/tables/consistent_12asset_allocation.csv`
- 共通Options-Implied指標: `outputs/tables/consistent_option_metrics.csv`
- 実行済みNotebook: `outputs/executed/main_20260727_executed.ipynb`
- 更新ダッシュボード: `outputs/dashboard/sector_gamma_dashboard.html`

Notebookは全セルを上から実行し、13チェーン、有限なGreeks、Confidence、配分合計、Active上限、Hard Rule、全図表・保存物を含む**166件をすべてPASS**した。
