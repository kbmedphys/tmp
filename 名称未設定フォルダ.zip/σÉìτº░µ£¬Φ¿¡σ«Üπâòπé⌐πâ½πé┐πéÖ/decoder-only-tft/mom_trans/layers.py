"""Core layers for Momentum Transformer (Decoder-Only TFT style)."""

from __future__ import annotations

import math
from typing import Optional, Tuple

import torch
from torch import nn
from torch.nn import functional as F


class AddNorm(nn.Module):
    def __init__(self, dim: int, dropout: float = 0.0):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor, residual: torch.Tensor) -> torch.Tensor:
        out = residual + self.dropout(x)
        return self.norm(out)


class GatedLinearUnit(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, dropout: float = 0.0):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(input_dim, output_dim)
        self.gate = nn.Linear(input_dim, output_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.dropout(x)
        return self.fc(x) * torch.sigmoid(self.gate(x))


class GatedResidualNetwork(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: Optional[int] = None,
        dropout: float = 0.0,
        context_dim: Optional[int] = None,
    ):
        super().__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim if output_dim is not None else input_dim

        self.skip = None
        if self.output_dim != input_dim:
            self.skip = nn.Linear(input_dim, self.output_dim)

        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.context_fc = None
        if context_dim is not None:
            self.context_fc = nn.Linear(context_dim, hidden_dim, bias=False)
        self.fc2 = nn.Linear(hidden_dim, self.output_dim)
        self.glu = GatedLinearUnit(self.output_dim, self.output_dim, dropout=dropout)
        self.norm = nn.LayerNorm(self.output_dim)

    def forward(self, x: torch.Tensor, context: Optional[torch.Tensor] = None) -> torch.Tensor:
        residual = x if self.skip is None else self.skip(x)
        hidden = self.fc1(x)
        if context is not None:
            hidden = hidden + self.context_fc(context)
        hidden = F.elu(hidden)
        hidden = self.fc2(hidden)
        gated = self.glu(hidden)
        return self.norm(residual + gated)


class VariableSelectionNetwork(nn.Module):
    """Selects relevant variables at each time step."""

    def __init__(self, num_vars: int, hidden_dim: int, dropout: float = 0.0):
        super().__init__()
        self.num_vars = num_vars
        self.hidden_dim = hidden_dim

        self.var_embeddings = nn.ModuleList(
            [nn.Linear(1, hidden_dim) for _ in range(num_vars)]
        )
        self.selection_grn = GatedResidualNetwork(
            input_dim=num_vars * hidden_dim,
            hidden_dim=hidden_dim,
            output_dim=num_vars,
            dropout=dropout,
        )
        self.var_grns = nn.ModuleList(
            [GatedResidualNetwork(hidden_dim, hidden_dim, dropout=dropout) for _ in range(num_vars)]
        )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        # x: [B, T, F]
        batch_size, time_steps, num_vars = x.shape
        if num_vars != self.num_vars:
            raise ValueError(f"Expected {self.num_vars} variables, got {num_vars}")

        embedded = []
        for i in range(num_vars):
            emb = self.var_embeddings[i](x[..., i : i + 1])
            embedded.append(emb)
        embedded_stack = torch.stack(embedded, dim=2)  # [B, T, F, H]

        flattened = embedded_stack.reshape(batch_size, time_steps, -1)
        selection_logits = self.selection_grn(flattened)
        selection_weights = torch.softmax(selection_logits, dim=-1)  # [B, T, F]

        transformed = []
        for i in range(num_vars):
            transformed.append(self.var_grns[i](embedded_stack[:, :, i, :]))
        transformed_stack = torch.stack(transformed, dim=2)  # [B, T, F, H]

        weighted = transformed_stack * selection_weights.unsqueeze(-1)
        combined = weighted.sum(dim=2)  # [B, T, H]
        return combined, selection_weights


class InterpretableMultiHeadAttention(nn.Module):
    def __init__(self, d_model: int, num_heads: int, dropout: float = 0.0):
        super().__init__()
        if d_model % num_heads != 0:
            raise ValueError("d_model must be divisible by num_heads")
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads

        self.q_layers = nn.ModuleList(
            [nn.Linear(d_model, self.d_k, bias=False) for _ in range(num_heads)]
        )
        self.k_layers = nn.ModuleList(
            [nn.Linear(d_model, self.d_k, bias=False) for _ in range(num_heads)]
        )
        self.v_layer = nn.Linear(d_model, self.d_k, bias=False)
        self.out = nn.Linear(self.d_k, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        return_attn: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        # q, k, v: [B, T, d_model]
        batch_size, time_steps, _ = q.shape

        if mask is None:
            mask = torch.triu(
                torch.ones(time_steps, time_steps, device=q.device, dtype=torch.bool),
                diagonal=1,
            )

        heads = []
        attn_weights = []
        v_proj = self.v_layer(v)
        scale = 1.0 / math.sqrt(self.d_k)

        for i in range(self.num_heads):
            q_proj = self.q_layers[i](q)
            k_proj = self.k_layers[i](k)

            scores = torch.matmul(q_proj, k_proj.transpose(1, 2)) * scale
            scores = scores.masked_fill(mask.unsqueeze(0), -1e9)
            attn = torch.softmax(scores, dim=-1)
            attn = self.dropout(attn)
            head = torch.matmul(attn, v_proj)
            head = self.dropout(head)
            heads.append(head)
            attn_weights.append(attn)

        head_stack = torch.stack(heads, dim=1)  # [B, H, T, d_k]
        outputs = head_stack.mean(dim=1)  # [B, T, d_k]
        outputs = self.out(outputs)
        outputs = self.dropout(outputs)

        if return_attn:
            attn_stack = torch.stack(attn_weights, dim=1)  # [B, H, T, T]
            return outputs, attn_stack
        return outputs, None


class TemporalEmbedding(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int):
        super().__init__()
        self.proj = nn.Linear(input_dim, hidden_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.proj(x)


class FeedForwardBlock(nn.Module):
    def __init__(self, dim: int, dropout: float = 0.0):
        super().__init__()
        self.fc1 = nn.Linear(dim, dim)
        self.fc2 = nn.Linear(dim, dim)
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        hidden = F.relu(self.fc1(x))
        hidden = self.dropout(self.fc2(hidden))
        return self.norm(x + hidden)
