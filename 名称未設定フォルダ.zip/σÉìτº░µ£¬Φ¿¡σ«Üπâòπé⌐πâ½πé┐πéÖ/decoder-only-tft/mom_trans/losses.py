"""Loss functions for Momentum Transformer."""

from __future__ import annotations

import math
from typing import Optional

import torch
from torch import nn


class SharpeLoss(nn.Module):
    def __init__(self, eps: float = 1e-9):
        super().__init__()
        self.eps = eps

    def forward(
        self,
        positions: torch.Tensor,
        target_returns: torch.Tensor,
        time_idx: torch.Tensor,
    ) -> torch.Tensor:
        return sharpe_loss(positions, target_returns, time_idx, eps=self.eps)


def sharpe_loss(
    positions: torch.Tensor,
    target_returns: torch.Tensor,
    time_idx: torch.Tensor,
    eps: float = 1e-9,
) -> torch.Tensor:
    """Negative annualized Sharpe ratio.

    Args:
        positions: [B, T, 1] or [B, T]
        target_returns: [B, T] or [B, T, 1]
        time_idx: [B, T] integer indices for dates
    """
    if positions.dim() == 3:
        positions = positions.squeeze(-1)
    if target_returns.dim() == 3:
        target_returns = target_returns.squeeze(-1)

    captured = positions * target_returns

    flat_returns = captured.reshape(-1)
    flat_idx = time_idx.reshape(-1).long()

    max_idx = int(flat_idx.max().item())
    sums = torch.zeros(max_idx + 1, device=flat_returns.device)
    counts = torch.zeros(max_idx + 1, device=flat_returns.device)

    sums.scatter_add_(0, flat_idx, flat_returns)
    counts.scatter_add_(0, flat_idx, torch.ones_like(flat_returns))

    mask = counts > 0
    avg_returns = sums[mask] / counts[mask]

    mean = avg_returns.mean()
    var = (avg_returns.pow(2).mean() - mean.pow(2)).clamp_min(0.0)
    sharpe = mean / torch.sqrt(var + eps) * math.sqrt(252.0)
    return -sharpe


class PortfolioReturnLoss(nn.Module):
    def __init__(self, k: int = 5, tau: float = 0.5, eps: float = 1e-9):
        super().__init__()
        self.k = k
        self.tau = tau
        self.eps = eps

    def forward(
        self,
        scores: torch.Tensor,
        raw_next_returns: torch.Tensor,
        daily_vol: torch.Tensor,
        abs_mom: torch.Tensor,
    ) -> torch.Tensor:
        return portfolio_return_loss(
            scores,
            raw_next_returns,
            daily_vol,
            abs_mom,
            k=self.k,
            tau=self.tau,
            eps=self.eps,
        )


def portfolio_return_loss(
    scores: torch.Tensor,
    raw_next_returns: torch.Tensor,
    daily_vol: torch.Tensor,
    abs_mom: torch.Tensor,
    k: int = 5,
    tau: float = 0.5,
    eps: float = 1e-9,
) -> torch.Tensor:
    """Negative mean portfolio return with soft Top-K and risk parity weights.

    Args:
        scores: [B, N] or [N]
        raw_next_returns: [B, N] or [N]
        daily_vol: [B, N] or [N]
        abs_mom: [B, N] or [N] absolute momentum signal (filter > 0)
    """
    if scores.dim() == 1:
        scores = scores.unsqueeze(0)
        raw_next_returns = raw_next_returns.unsqueeze(0)
        daily_vol = daily_vol.unsqueeze(0)
        abs_mom = abs_mom.unsqueeze(0)

    mask = abs_mom > 0
    masked_scores = scores.masked_fill(~mask, float("-inf"))
    weights_soft = torch.softmax(masked_scores / tau, dim=-1)

    if k is not None and k > 0:
        topk_idx = torch.topk(masked_scores, k=k, dim=-1).indices
        topk_mask = torch.zeros_like(weights_soft).scatter(1, topk_idx, 1.0)
        weights_soft = weights_soft * topk_mask
        weights_soft = weights_soft / (weights_soft.sum(dim=-1, keepdim=True) + eps)

    inv_vol = 1.0 / (daily_vol + eps)
    weights = weights_soft * inv_vol
    weights = weights / (weights.sum(dim=-1, keepdim=True) + eps)

    port_ret = (weights * raw_next_returns).sum(dim=-1)
    return -port_ret.mean()
