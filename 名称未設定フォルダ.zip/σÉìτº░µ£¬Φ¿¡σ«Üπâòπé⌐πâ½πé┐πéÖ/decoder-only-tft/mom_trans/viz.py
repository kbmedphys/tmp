"""Visualization helpers for attention and variable selection weights."""

from __future__ import annotations

import os
from typing import List

import numpy as np
import torch


def save_attention_plots(
    attn: torch.Tensor,
    var_weights: torch.Tensor,
    feature_names: List[str],
    output_dir: str,
    prefix: str = "attn",
) -> None:
    os.makedirs(output_dir, exist_ok=True)

    attn_mean = attn.mean(dim=(0, 1)).cpu().numpy()
    var_mean = var_weights.mean(dim=(0, 1)).cpu().numpy()

    np.save(os.path.join(output_dir, f"{prefix}_mean.npy"), attn_mean)
    np.save(os.path.join(output_dir, f"{prefix}_var_mean.npy"), var_mean)

    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return

    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(attn_mean, aspect="auto", origin="lower")
    ax.set_title("Attention (mean over batch/heads)")
    ax.set_xlabel("Key Time")
    ax.set_ylabel("Query Time")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"{prefix}_heatmap.png"), dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 3))
    ax.bar(range(len(var_mean)), var_mean)
    ax.set_title("Variable Importance (mean)")
    ax.set_xticks(range(len(var_mean)))
    ax.set_xticklabels(feature_names, rotation=45, ha="right")
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"{prefix}_var_importance.png"), dpi=150)
    plt.close(fig)
