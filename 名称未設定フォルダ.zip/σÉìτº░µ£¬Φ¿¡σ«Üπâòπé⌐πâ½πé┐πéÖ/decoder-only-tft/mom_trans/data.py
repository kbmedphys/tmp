"""Data loading and feature engineering for Momentum Transformer."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd
from torch.utils.data import Dataset

from mom_trans.config import (
    FEATURE_OFFSETS,
    MACD_WINDOWS,
    SEQ_LEN,
    TRAIN_RATIO,
    VAL_RATIO,
    VOL_LOOKBACK,
    VOL_TARGET,
)


@dataclass
class DatasetMeta:
    feature_cols: List[str]
    ticker_to_id: Dict[str, int]
    date_to_idx: Dict[pd.Timestamp, int]
    split_dates: Dict[str, Tuple[pd.Timestamp, pd.Timestamp]]
    tickers: List[str]


def load_price_data(data_path: str) -> pd.DataFrame:
    df = pd.read_csv(data_path, header=[0, 1])
    if df.shape[1] < 2:
        raise ValueError("prices.csv must have multi-index columns")

    date_col = df.columns[0]
    dates = pd.to_datetime(df[date_col], errors="coerce")
    df = df.drop(columns=[date_col])
    df.index = dates
    df = df.loc[~df.index.isna()].copy()

    level0 = df.columns.get_level_values(0)
    if "Adj Close" in level0:
        price_field = "Adj Close"
    elif "Close" in level0:
        price_field = "Close"
    else:
        raise ValueError("Adj Close or Close not found in prices.csv")

    prices = df.loc[:, (price_field, slice(None))].copy()
    prices.columns = prices.columns.get_level_values(1)
    prices = prices.apply(pd.to_numeric, errors="coerce")
    prices = prices.dropna(axis=1, how="all")
    return prices


def _calc_halflife(timescale: int) -> float:
    return np.log(0.5) / np.log(1 - 1 / timescale)


def _calc_macd_signal(srs: pd.Series, short: int, long: int) -> pd.Series:
    macd = srs.ewm(halflife=_calc_halflife(short), adjust=False).mean() - srs.ewm(
        halflife=_calc_halflife(long), adjust=False
    ).mean()
    macd_std = srs.rolling(63, min_periods=63).std()
    q = macd / macd_std
    q_std = q.rolling(252, min_periods=252).std()
    return q / q_std


def compute_features(prices: pd.DataFrame) -> pd.DataFrame:
    frames = []
    for ticker in prices.columns:
        srs = prices[ticker].dropna()
        if srs.empty:
            continue

        df = pd.DataFrame({"close": srs})
        df["daily_returns"] = df["close"] / df["close"].shift(1) - 1.0
        df["daily_vol"] = (
            df["daily_returns"]
            .ewm(span=VOL_LOOKBACK, min_periods=VOL_LOOKBACK, adjust=False)
            .std()
        )
        df.loc[df["daily_vol"] <= 0, "daily_vol"] = np.nan

        annual_vol = df["daily_vol"] * np.sqrt(252.0)
        vol_scaled = df["daily_returns"] * VOL_TARGET / annual_vol.shift(1)
        df["target_returns"] = vol_scaled.shift(-1)

        for offset in FEATURE_OFFSETS:
            returns = df["close"] / df["close"].shift(offset) - 1.0
            df[f"norm_ret_{offset}"] = returns / (df["daily_vol"] * np.sqrt(offset))

        df["raw_next_return"] = df["daily_returns"].shift(-1)
        df["abs_mom"] = df["norm_ret_252"]

        for short, long in MACD_WINDOWS:
            df[f"macd_{short}_{long}"] = _calc_macd_signal(df["close"], short, long)

        df = df.dropna()
        if df.empty:
            continue
        df["ticker"] = ticker
        df["date"] = df.index
        frames.append(df)

    if not frames:
        raise ValueError("No usable data after feature engineering")

    return pd.concat(frames).reset_index(drop=True)


class SequenceDataset(Dataset):
    def __init__(
        self,
        data_by_ticker: Dict[str, Dict[str, np.ndarray]],
        index_list: List[Tuple[str, int]],
        seq_len: int,
        feature_cols: List[str],
    ):
        self.data_by_ticker = data_by_ticker
        self.index_list = index_list
        self.seq_len = seq_len
        self.feature_cols = feature_cols

    def __len__(self) -> int:
        return len(self.index_list)

    def __getitem__(self, idx: int):
        ticker, start = self.index_list[idx]
        data = self.data_by_ticker[ticker]
        end = start + self.seq_len

        inputs = data["features"][start:end]
        targets = data["target_returns"][start:end]
        raw_next_returns = data["raw_next_returns"][start:end]
        time_idx = data["time_idx"][start:end]
        asset_id = data["asset_id"]

        return inputs, targets, raw_next_returns, time_idx, asset_id


def _build_index_list(
    dates: np.ndarray,
    split_start: pd.Timestamp,
    split_end: pd.Timestamp,
    seq_len: int,
) -> List[int]:
    idxs: List[int] = []
    for end in range(seq_len - 1, len(dates)):
        start = end - seq_len + 1
        if dates[start] >= split_start and dates[end] <= split_end:
            idxs.append(start)
    return idxs


def build_datasets(
    data_path: str,
    seq_len: int = SEQ_LEN,
    train_ratio: float = TRAIN_RATIO,
    val_ratio: float = VAL_RATIO,
    limit_tickers: Optional[int] = None,
) -> Tuple[SequenceDataset, SequenceDataset, SequenceDataset, DatasetMeta]:
    prices = load_price_data(data_path)
    if limit_tickers is not None:
        if limit_tickers <= 0:
            raise ValueError("limit_tickers must be positive")
        prices = prices.iloc[:, :limit_tickers]
    features = compute_features(prices)

    feature_cols = [
        f"norm_ret_{o}" for o in FEATURE_OFFSETS
    ] + [f"macd_{s}_{l}" for s, l in MACD_WINDOWS]

    unique_dates = np.sort(features["date"].unique())
    if len(unique_dates) < seq_len:
        raise ValueError("Not enough data to build sequences")

    n_dates = len(unique_dates)
    train_end_idx = int(n_dates * train_ratio) - 1
    val_end_idx = int(n_dates * (train_ratio + val_ratio)) - 1

    train_end_date = unique_dates[train_end_idx]
    val_end_date = unique_dates[val_end_idx]

    train_start_date = unique_dates[0]
    val_start_date = unique_dates[train_end_idx + 1] if train_end_idx + 1 < n_dates else unique_dates[-1]
    test_start_date = unique_dates[val_end_idx + 1] if val_end_idx + 1 < n_dates else unique_dates[-1]
    test_end_date = unique_dates[-1]

    split_dates = {
        "train": (train_start_date, train_end_date),
        "val": (val_start_date, val_end_date),
        "test": (test_start_date, test_end_date),
    }

    date_to_idx = {pd.Timestamp(d): i for i, d in enumerate(unique_dates)}
    tickers = sorted(features["ticker"].unique())
    ticker_to_id = {t: i for i, t in enumerate(tickers)}

    data_by_ticker: Dict[str, Dict[str, np.ndarray]] = {}
    for ticker in tickers:
        df_t = features[features["ticker"] == ticker].sort_values("date")
        dates = df_t["date"].to_numpy()
        data_by_ticker[ticker] = {
            "features": df_t[feature_cols].to_numpy(dtype=np.float32),
            "target_returns": df_t["target_returns"].to_numpy(dtype=np.float32),
            "raw_next_returns": df_t["raw_next_return"].to_numpy(dtype=np.float32),
            "daily_vol": df_t["daily_vol"].to_numpy(dtype=np.float32),
            "abs_mom": df_t["abs_mom"].to_numpy(dtype=np.float32),
            "time_idx": np.array([date_to_idx[pd.Timestamp(d)] for d in dates], dtype=np.int64),
            "dates": dates,
            "asset_id": np.int64(ticker_to_id[ticker]),
        }

    train_list: List[Tuple[str, int]] = []
    val_list: List[Tuple[str, int]] = []
    test_list: List[Tuple[str, int]] = []

    for ticker in tickers:
        dates = data_by_ticker[ticker]["dates"]
        train_idx = _build_index_list(dates, train_start_date, train_end_date, seq_len)
        val_idx = _build_index_list(dates, val_start_date, val_end_date, seq_len)
        test_idx = _build_index_list(dates, test_start_date, test_end_date, seq_len)

        train_list.extend([(ticker, i) for i in train_idx])
        val_list.extend([(ticker, i) for i in val_idx])
        test_list.extend([(ticker, i) for i in test_idx])

    train_ds = SequenceDataset(data_by_ticker, train_list, seq_len, feature_cols)
    val_ds = SequenceDataset(data_by_ticker, val_list, seq_len, feature_cols)
    test_ds = SequenceDataset(data_by_ticker, test_list, seq_len, feature_cols)

    meta = DatasetMeta(
        feature_cols=feature_cols,
        ticker_to_id=ticker_to_id,
        date_to_idx=date_to_idx,
        split_dates=split_dates,
        tickers=tickers,
    )
    return train_ds, val_ds, test_ds, meta


class CrossSectionalDataset(Dataset):
    def __init__(
        self,
        data_by_ticker: Dict[str, Dict[str, np.ndarray]],
        feature_cols: List[str],
        end_dates: List[pd.Timestamp],
        date_to_idx: Dict[pd.Timestamp, int],
        seq_len: int,
        k: int,
        require_abs_mom: bool = True,
    ):
        self.data_by_ticker = data_by_ticker
        self.feature_cols = feature_cols
        self.end_dates = end_dates
        self.date_to_idx = date_to_idx
        self.seq_len = seq_len
        self.k = k
        self.require_abs_mom = require_abs_mom
        self.asset_list = sorted(self.data_by_ticker.keys())

        # Precompute date -> index per ticker
        self._date_index = {
            t: {pd.Timestamp(d): i for i, d in enumerate(self.data_by_ticker[t]["dates"])}
            for t in self.data_by_ticker
        }

        # Filter valid dates where all assets exist and abs_mom >= k
        self.valid_end_dates: List[pd.Timestamp] = []
        self.valid_time_idx: List[int] = []
        for end_date in self.end_dates:
            eligible_count = 0
            available = True
            end_date = pd.Timestamp(end_date)
            for ticker in self.asset_list:
                date_idx = self._date_index[ticker].get(end_date)
                if date_idx is None:
                    available = False
                    break
                start = date_idx - self.seq_len + 1
                if start < 0:
                    available = False
                    break
                if self.require_abs_mom:
                    if self.data_by_ticker[ticker]["abs_mom"][date_idx] > 0:
                        eligible_count += 1
            if not available:
                continue
            if self.require_abs_mom and eligible_count < self.k:
                continue
            self.valid_end_dates.append(end_date)
            self.valid_time_idx.append(self.date_to_idx[end_date])

    def __len__(self) -> int:
        return len(self.valid_end_dates)

    def __getitem__(self, idx: int):
        end_date = pd.Timestamp(self.valid_end_dates[idx])
        time_idx = self.valid_time_idx[idx]
        inputs = []
        raw_next = []
        daily_vol = []
        abs_mom = []

        for ticker in self.asset_list:
            data = self.data_by_ticker[ticker]
            date_idx = self._date_index[ticker].get(end_date)
            if date_idx is None:
                raise IndexError("Missing asset data for date")
            start = date_idx - self.seq_len + 1
            if start < 0:
                raise IndexError("Insufficient history for asset")
            inputs.append(data["features"][start : date_idx + 1])
            raw_next.append(data["raw_next_returns"][date_idx])
            daily_vol.append(data["daily_vol"][date_idx])
            abs_mom.append(data["abs_mom"][date_idx])

        inputs = np.stack(inputs, axis=0).astype(np.float32)
        raw_next = np.array(raw_next, dtype=np.float32)
        daily_vol = np.array(daily_vol, dtype=np.float32)
        abs_mom = np.array(abs_mom, dtype=np.float32)

        return inputs, raw_next, daily_vol, abs_mom, time_idx


def build_cross_sectional_datasets(
    data_path: str,
    seq_len: int = SEQ_LEN,
    train_ratio: float = TRAIN_RATIO,
    val_ratio: float = VAL_RATIO,
    limit_tickers: Optional[int] = None,
    k: int = 5,
):
    prices = load_price_data(data_path)
    if limit_tickers is not None:
        if limit_tickers <= 0:
            raise ValueError("limit_tickers must be positive")
        prices = prices.iloc[:, :limit_tickers]
    features = compute_features(prices)

    feature_cols = [
        f"norm_ret_{o}" for o in FEATURE_OFFSETS
    ] + [f"macd_{s}_{l}" for s, l in MACD_WINDOWS]

    unique_dates = np.sort(features["date"].unique())
    if len(unique_dates) < seq_len:
        raise ValueError("Not enough data to build sequences")

    n_dates = len(unique_dates)
    train_end_idx = int(n_dates * train_ratio) - 1
    val_end_idx = int(n_dates * (train_ratio + val_ratio)) - 1

    train_end_date = unique_dates[train_end_idx]
    val_end_date = unique_dates[val_end_idx]

    train_start_date = unique_dates[0]
    val_start_date = unique_dates[train_end_idx + 1] if train_end_idx + 1 < n_dates else unique_dates[-1]
    test_start_date = unique_dates[val_end_idx + 1] if val_end_idx + 1 < n_dates else unique_dates[-1]
    test_end_date = unique_dates[-1]

    split_dates = {
        "train": (train_start_date, train_end_date),
        "val": (val_start_date, val_end_date),
        "test": (test_start_date, test_end_date),
    }

    date_to_idx = {pd.Timestamp(d): i for i, d in enumerate(unique_dates)}
    tickers = sorted(features["ticker"].unique())
    ticker_to_id = {t: i for i, t in enumerate(tickers)}

    data_by_ticker: Dict[str, Dict[str, np.ndarray]] = {}
    for ticker in tickers:
        df_t = features[features["ticker"] == ticker].sort_values("date")
        dates = df_t["date"].to_numpy()
        data_by_ticker[ticker] = {
            "features": df_t[feature_cols].to_numpy(dtype=np.float32),
            "raw_next_returns": df_t["raw_next_return"].to_numpy(dtype=np.float32),
            "daily_vol": df_t["daily_vol"].to_numpy(dtype=np.float32),
            "abs_mom": df_t["abs_mom"].to_numpy(dtype=np.float32),
            "dates": dates,
            "asset_id": np.int64(ticker_to_id[ticker]),
        }

    train_dates = [d for d in unique_dates if train_start_date <= d <= train_end_date]
    val_dates = [d for d in unique_dates if val_start_date <= d <= val_end_date]
    test_dates = [d for d in unique_dates if test_start_date <= d <= test_end_date]

    train_ds = CrossSectionalDataset(
        data_by_ticker, feature_cols, train_dates, date_to_idx, seq_len, k=k
    )
    val_ds = CrossSectionalDataset(
        data_by_ticker, feature_cols, val_dates, date_to_idx, seq_len, k=k
    )
    test_ds = CrossSectionalDataset(
        data_by_ticker, feature_cols, test_dates, date_to_idx, seq_len, k=k
    )

    meta = DatasetMeta(
        feature_cols=feature_cols,
        ticker_to_id=ticker_to_id,
        date_to_idx=date_to_idx,
        split_dates=split_dates,
        tickers=tickers,
    )

    return train_ds, val_ds, test_ds, meta
