"""Minimal training loop for Momentum Transformer."""

from __future__ import annotations

import argparse
import json
import os
from typing import Dict

import torch
from torch import nn
from torch.utils.data import DataLoader

from mom_trans.config import (
    BATCH_SIZE,
    DROPOUT,
    EPOCHS,
    HIDDEN_SIZE,
    LEARNING_RATE,
    MAX_GRAD_NORM,
    NUM_HEADS,
    PATIENCE,
    SEQ_LEN,
    TRAIN_RATIO,
    VAL_RATIO,
)
from mom_trans.data import build_datasets
from mom_trans.losses import SharpeLoss
from mom_trans.model import MomentumTransformer


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train Momentum Transformer (minimal).")
    parser.add_argument("--data", required=True, help="Path to prices.csv")
    parser.add_argument("--seq-len", type=int, default=SEQ_LEN)
    parser.add_argument("--hidden-size", type=int, default=HIDDEN_SIZE)
    parser.add_argument("--num-heads", type=int, default=NUM_HEADS)
    parser.add_argument("--dropout", type=float, default=DROPOUT)
    parser.add_argument("--lr", type=float, default=LEARNING_RATE)
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--patience", type=int, default=PATIENCE)
    parser.add_argument("--max-grad-norm", type=float, default=MAX_GRAD_NORM)
    parser.add_argument("--train-ratio", type=float, default=TRAIN_RATIO)
    parser.add_argument("--val-ratio", type=float, default=VAL_RATIO)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--limit-tickers", type=int, default=None)
    parser.add_argument("--max-train-batches", type=int, default=None)
    parser.add_argument("--max-val-batches", type=int, default=None)
    parser.add_argument("--export-attn", action="store_true", help="Export attention/VSN weights")
    parser.add_argument("--export-split", default="val", choices=["val", "test"])
    return parser.parse_args()


def set_seed(seed: int) -> None:
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def evaluate(
    model: nn.Module,
    loader: DataLoader,
    loss_fn: SharpeLoss,
    device: torch.device,
    max_batches: int | None = None,
) -> float:
    model.eval()
    losses = []
    with torch.no_grad():
        for i, (inputs, targets, _raw_next, time_idx, _) in enumerate(loader):
            if max_batches is not None and i >= max_batches:
                break
            inputs = inputs.to(device)
            targets = targets.to(device)
            time_idx = time_idx.to(device)
            positions, _ = model(inputs)
            loss = loss_fn(positions, targets, time_idx)
            losses.append(loss.item())
    if not losses:
        return float("inf")
    return float(sum(losses) / len(losses))


def export_attention(
    model: nn.Module,
    loader: DataLoader,
    feature_names: list,
    output_dir: str,
    device: torch.device,
) -> None:
    model.eval()
    try:
        batch = next(iter(loader))
    except StopIteration:
        print("No data available for attention export")
        return

    inputs, _, _raw_next, _, _ = batch
    inputs = inputs.to(device)
    with torch.no_grad():
        _, attn_dict = model(inputs, return_attn=True)

    if attn_dict is None:
        print("Attention export skipped: no attention returned")
        return

    from mom_trans.viz import save_attention_plots

    attn = attn_dict["attn"].detach().cpu()
    var_weights = attn_dict["var_weights"].detach().cpu()
    save_attention_plots(attn, var_weights, feature_names, output_dir)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)

    device = (
        torch.device("cuda")
        if args.device == "auto" and torch.cuda.is_available()
        else torch.device("cpu")
        if args.device == "auto"
        else torch.device(args.device)
    )

    os.makedirs("outputs", exist_ok=True)
    log_path = os.path.join("outputs", "train.log")

    train_ds, val_ds, test_ds, meta = build_datasets(
        args.data,
        seq_len=args.seq_len,
        train_ratio=args.train_ratio,
        val_ratio=args.val_ratio,
        limit_tickers=args.limit_tickers,
    )

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        drop_last=False,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        drop_last=False,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        drop_last=False,
    )

    model = MomentumTransformer(
        num_features=len(meta.feature_cols),
        hidden_size=args.hidden_size,
        num_heads=args.num_heads,
        dropout=args.dropout,
        output_mode="tanh",
    ).to(device)

    loss_fn = SharpeLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    best_sharpe = float("-inf")
    patience_counter = 0
    best_path = os.path.join("outputs", "best.pt")

    with open(log_path, "w", encoding="utf-8") as f:
        f.write("epoch,train_loss,val_loss,train_sharpe,val_sharpe\n")

    for epoch in range(1, args.epochs + 1):
        model.train()
        train_losses = []
        for i, (inputs, targets, _raw_next, time_idx, _) in enumerate(train_loader):
            if args.max_train_batches is not None and i >= args.max_train_batches:
                break
            inputs = inputs.to(device)
            targets = targets.to(device)
            time_idx = time_idx.to(device)

            optimizer.zero_grad()
            positions, _ = model(inputs)
            loss = loss_fn(positions, targets, time_idx)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
            optimizer.step()
            train_losses.append(loss.item())

        train_loss = float(sum(train_losses) / max(1, len(train_losses)))
        val_loss = evaluate(model, val_loader, loss_fn, device, args.max_val_batches)

        train_sharpe = -train_loss
        val_sharpe = -val_loss

        with open(log_path, "a", encoding="utf-8") as f:
            f.write(
                f"{epoch},{train_loss:.6f},{val_loss:.6f},{train_sharpe:.6f},{val_sharpe:.6f}\n"
            )

        print(
            f"epoch {epoch}: train_loss={train_loss:.6f} val_loss={val_loss:.6f} val_sharpe={val_sharpe:.6f}"
        )

        if val_sharpe > best_sharpe + 1e-4:
            best_sharpe = val_sharpe
            patience_counter = 0
            torch.save(model.state_dict(), best_path)
        else:
            patience_counter += 1
            if patience_counter >= args.patience:
                print("Early stopping triggered")
                break

    config_path = os.path.join("outputs", "train_config.json")
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(vars(args), f, indent=2)

    if args.export_attn:
        export_loader = val_loader if args.export_split == "val" else test_loader
        export_attention(model, export_loader, meta.feature_cols, "outputs", device)


if __name__ == "__main__":
    main()
