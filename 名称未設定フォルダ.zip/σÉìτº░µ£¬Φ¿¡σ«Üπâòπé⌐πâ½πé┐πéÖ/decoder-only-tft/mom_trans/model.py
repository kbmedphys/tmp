"""Decoder-Only TFT style Momentum Transformer (PyTorch)."""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import torch
from torch import nn

from mom_trans.layers import (
    AddNorm,
    FeedForwardBlock,
    InterpretableMultiHeadAttention,
    VariableSelectionNetwork,
)


class MomentumTransformer(nn.Module):
    def __init__(
        self,
        num_features: int,
        hidden_size: int = 32,
        num_heads: int = 4,
        dropout: float = 0.1,
        output_mode: str = "score",
    ):
        super().__init__()
        self.num_features = num_features
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        if output_mode not in {"score", "tanh"}:
            raise ValueError("output_mode must be 'score' or 'tanh'")
        self.output_mode = output_mode

        self.vsn = VariableSelectionNetwork(num_features, hidden_size, dropout=dropout)
        self.lstm = nn.LSTM(hidden_size, hidden_size, batch_first=True)
        self.attn = InterpretableMultiHeadAttention(
            d_model=hidden_size, num_heads=num_heads, dropout=dropout
        )
        self.attn_addnorm = AddNorm(hidden_size, dropout=dropout)
        self.ffn = FeedForwardBlock(hidden_size, dropout=dropout)
        self.output = nn.Linear(hidden_size, 1)

    def forward(
        self,
        inputs: torch.Tensor,
        asset_id: Optional[torch.Tensor] = None,
        time_idx: Optional[torch.Tensor] = None,
        return_attn: bool = False,
    ) -> Tuple[torch.Tensor, Optional[Dict[str, torch.Tensor]]]:
        # inputs: [B, T, F]
        selected, var_weights = self.vsn(inputs)
        lstm_out, _ = self.lstm(selected)
        attn_out, attn = self.attn(
            lstm_out, lstm_out, lstm_out, return_attn=return_attn
        )
        attn_out = self.attn_addnorm(attn_out, lstm_out)
        ffn_out = self.ffn(attn_out)
        scores = self.output(ffn_out)
        if self.output_mode == "tanh":
            scores = torch.tanh(scores)

        if return_attn:
            return scores, {"attn": attn, "var_weights": var_weights}
        return scores, None
