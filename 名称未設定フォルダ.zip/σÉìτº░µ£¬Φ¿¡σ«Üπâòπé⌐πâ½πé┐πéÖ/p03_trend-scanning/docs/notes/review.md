# Trend-Scanning Labeling Method レビュー（Phase A）

本ドキュメントは、以下原本を精読し、Phase B（再現実装）に必要な仕様を日本語で整理したレビューである。  
このターンでは実装は行わず、レビューと設計のみを定義する。

## 1. 論文情報

- タイトル: MetaTrader 5 Machine Learning Blueprint (Part 3): Trend-Scanning Labeling Method
- 著者: Patrick Murimi Njoroge
- 公開元: MQL5 Articles
- 公開日時（原本記載）: 2025-10-06 18:04
- 原本PDF: `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/docs/sources/MetaTrader 5 Machine Learning Blueprint (Part 3)_ Trend-Scanning Labeling Method - MQL5 Articles.pdf`
- 総ページ数: 16
- 参照日: 2026-02-23
- 原本URL（PDF内記載）: https://www.mql5.com/en/articles/19253

## 2. 背景と目的

- 固定ホライズン（例: 5日先、10日先）のラベル付けは、市場レジームの変化を吸収できない。
- Triple-Barrier は改善だが、縦バリアの時間長を事前固定する点は残る。
- Trend-Scanning は各時点で複数ホライズンを走査し、最も統計的に有意な窓を選ぶことで、予測ホライズンをデータ駆動で決定する。
- 目的は、将来のトレンド方向を「固定期間」ではなく「その時点で最も有意な期間」でラベル化し、ノイズを低減すること。

## 3. 数理仕様

時点 `t` と候補ホライズン集合 `H = {h_min, ..., h_max}` に対して、各 `h in H` で回帰を実施する。

- 回帰モデル（価格または対数価格系列 `y`）  
  `y_tau = alpha + beta * tau + epsilon_tau, tau = 0..h-1`
- 傾きの t 値  
  `t_h = beta_hat / se(beta_hat)`
- 最適窓  
  `h* = argmax_h |t_h|`
- イベント終点  
  `t1 = t + h* - 1`（lookforward の場合）
- 方向ラベル  
  `bin_t = sign(t_{h*})`（-1, 0, +1）
- 保有期間リターン  
  `ret_t = close[t1] / close[t] - 1`

原本の拡張実装では、低ボラ局面をマスクして `t_value/slope/r_squared` を 0 化する。  
ボラ閾値は expanding quantile で適応的に計算する。

## 4. アルゴリズム仕様（入出力・処理手順）

### 4.1 入力

- `close: pd.Series`
  - `DatetimeIndex`（単調増加、重複なし）
  - 単一銘柄の価格系列
- `span: tuple[int, int]` または `list[int]`
  - 走査窓長の候補
- `lookforward: bool`
  - `True`: ラベル生成（未来を見る）
  - `False`: 特徴量生成（過去のみ）
- `use_log: bool`
  - 対数変換を使用するか
- `volatility_threshold: float`
  - ボラマスクの分位点（0-1）

### 4.2 出力

`pd.DataFrame`（index はイベント時点 `t`）

- `t1`: イベント終点時刻
- `window`: 採用窓長 `h*`
- `slope`: 最適窓の傾き
- `t_value`: 最適窓の t 値
- `rsquared`: 最適窓の決定係数
- `ret`: `t -> t1` のリターン
- `bin`: `sign(t_value)` の 3値ラベル（`-1/0/+1`）

### 4.3 処理フロー（要約）

1. 入力を時系列順に整列し、境界外（未来不足/過去不足）を除外。
2. `use_log=True` なら `log(price)` に変換。
3. 各候補窓 `h` でスライド回帰し、`t_value/slope/r_squared` を計算。
4. ボラ閾値未満のサンプルを 0 マスク。
5. 各時点で `|t_value|` 最大の窓を選択。
6. `t1, ret, bin` を組み立てて返す。

## 5. リーク防止要件（時点整合）

- 原則: 特徴量は `t` まで、ターゲットは `t+1` 以降。
- `lookforward=False` を特徴量生成に使用し、未来データ参照を禁止。
- `lookforward=True` はラベル作成専用とし、モデル説明変数には混入させない。
- 境界処理:
  - 未来不足の末尾サンプル（`lookforward=True`）は除外。
  - 過去不足の先頭サンプル（`lookforward=False`）は除外。
- 月次リバランス等を導入する場合は「月末決定・翌営業日適用」を厳守する。

## 6. 著者実装の改良点（原本記載）

- Numba による高速化（原実装より大幅高速化）
- 低ボラ局面の統計量マスク（ノイズ削減）
- `lookforward` / `lookbackward` の双方向スキャン
- 境界保護を強化し、look-ahead leak を防止
- 対数価格を使うことで分散不均一性への耐性を高める

## 7. ローカルデータ適用方針（`data/prices.csv`）

### 7.1 データ概要

- ファイル: `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/data/prices.csv`
- 期間: 2011-01-03 から 2026-02-20
- 形式: MultiIndex 列（Price種別 x Ticker）
- 対象価格: `Adj Close`
- 銘柄: `XLB, XLE, XLF, XLI, XLK, XLP, XLU, XLV, XLY`（9銘柄）

### 7.2 適用時の注意

- 原本検証データは EURUSD M5 であり、本プロジェクトのETF日次とは時間解像度が異なる。
- `span=(5,100)` は「バー数」定義のため、日次データでは「営業日窓」に解釈が変わる。
- 原本の収益比較結果（Fixed/Triple/Trend）はデータ・戦略依存のため、そのまま数値一致は期待しない。
- 本プロジェクトではまずラベル生成機構の再現性を主眼とする。

## 8. 再現実装設計（Phase B確定仕様）

### 8.1 スコープ

- Trend-Scanning 単体を再現対象とする。
- Fixed Horizon / Triple Barrier の性能比較は本フェーズ外。

### 8.2 実装方式

- 同一ノートブック内で2系統を併記:
  - 忠実再現版（参照実装）
  - 最適化版（Numba）
- 同一入力・同一パラメータで両者の整合性を検証する。

### 8.3 公開インターフェース（次フェーズ実装時の固定）

```python
def trend_scanning_labels_reference(
    close: pd.Series,
    span: tuple[int, int] = (5, 100),
    lookforward: bool = True,
    use_log: bool = True,
    volatility_threshold: float = 0.05,
) -> pd.DataFrame:
    ...

def trend_scanning_labels_numba(
    close: pd.Series,
    span: tuple[int, int] = (5, 100),
    lookforward: bool = True,
    use_log: bool = True,
    volatility_threshold: float = 0.05,
) -> pd.DataFrame:
    ...
```

出力カラムは `t1, window, slope, t_value, rsquared, ret, bin`。  
ラベル体系は 3値 `{-1, 0, +1}` を正式仕様とする。

### 8.4 ノートブック方針

- 予定ファイル: `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/trend_scanning_reproduction.ipynb`
- 1論文1ノートブック原則に従う。
- セクション想定:
  - データ読込（Adj Close 抽出）
  - 参照実装
  - Numba実装
  - 整合性検証
  - 分布診断（`bin/window/t_value`）

### 8.5 テストケース/受入条件（設計固定）

1. 入力健全性: `DatetimeIndex` 単調増加、欠損なし、重複なし。
2. 境界整合性: `lookforward=True` で `t1 >= t`、未来不足末尾は除外。
3. リーク防止: 特徴量は `lookforward=False`、予測ターゲットは `t+1` 以降。
4. 実装整合性: 参照版と最適化版で `bin` 一致率を評価し、`t_value` 誤差を検証。
5. 分布確認: `bin` クラス分布、`window` 選択分布、`t_value` 分布を確認。

## 9. 制約・未解決事項

- 原本の添付ZIP（`trend_scanning.py` 等）は本レビュー時点で未取得。
- 原本の実験設定（EURUSD M5、MA20/50 交差イベント、meta-labeling）をローカルETF日次で完全一致再現することは前提外。
- よって Phase B では「ラベル生成ロジックの再現」と「時点整合・リーク防止の担保」を成功条件とする。

## 参考（本レビューの根拠ページ）

- 理論背景と原実装: PDF p.1-3
- 改良実装（Numba、閾値、境界保護）: PDF p.4-8
- 実験設定と評価表: PDF p.10-13
- 結論と制約示唆: PDF p.14
