# Phase B Evidence Log (minimal)

## 1. Run metadata
- Run timestamp: 2026-02-23 17:47:45 +0900
- Notebook: `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/trend_scanning_reproduction.ipynb`
- Data: `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/data/prices.csv`

## 2. Dependency versions
- python: 3.12.12
- numpy: 2.4.2
- pandas: 3.0.0
- statsmodels: 0.14.6
- numba: 0.64.0

## 3. Parameters
- span: (5, 100)
- volatility_threshold: 0.05
- use_log: True
- tickers: ['XLB', 'XLE', 'XLF', 'XLI', 'XLK', 'XLP', 'XLU', 'XLV', 'XLY']

## 4. Consistency summary (reference vs numba)
| ticker   |   n_rows |   bin_match_rate |   window_match_rate |   t_value_mae |   t_value_max_abs_diff |   reference_time_sec |   numba_time_sec |   speedup_x |
|:---------|---------:|-----------------:|--------------------:|--------------:|-----------------------:|---------------------:|-----------------:|------------:|
| XLB      |     3707 |                1 |                   1 |   6.15129e-07 |            0.000554132 |            0.0151961 |        0.0256342 |    0.592806 |
| XLE      |     3707 |                1 |                   1 |   3.97964e-07 |            0.000206008 |            0.0145103 |        0.0258995 |    0.560255 |
| XLF      |     3707 |                1 |                   1 |   7.84778e-07 |            0.0015629   |            0.0146527 |        0.0264563 |    0.553845 |
| XLI      |     3707 |                1 |                   1 |   1.11504e-06 |            0.00178594  |            0.0141075 |        0.0261931 |    0.538596 |
| XLK      |     3707 |                1 |                   1 |   4.74132e-07 |            0.000387331 |            0.0141082 |        0.0266999 |    0.528399 |
| XLP      |     3707 |                1 |                   1 |   7.79242e-07 |            0.000874775 |            0.0140146 |        0.0257188 |    0.544918 |
| XLU      |     3707 |                1 |                   1 |   2.04512e-06 |            0.0049405   |            0.0138932 |        0.0259437 |    0.535511 |
| XLV      |     3707 |                1 |                   1 |   1.03533e-06 |            0.000748635 |            0.014025  |        0.0252688 |    0.55503  |
| XLY      |     3707 |                1 |                   1 |   6.27923e-07 |            0.000497084 |            0.0467235 |        0.0267958 |    1.74369  |

## 5. Acceptance checks
- bin_match_all_1.0: True
- window_match_ge_0.999: True
- t_value_mae_le_1e-4: True
- t_value_max_abs_diff_le_1e-2: True
- no_non_finite: True
- leak_checks_all_pass: True


## 6. Full-SMFit check (XLK subset, span=(5,20), n=700)
| pair              |   bin_match_rate |   window_match_rate |   t_value_mae |   t_value_max_abs_diff |
|:------------------|-----------------:|--------------------:|--------------:|-----------------------:|
| smfit_vs_fast_ref |                1 |                   1 |   3.59929e-08 |            2.51281e-06 |
| smfit_vs_numba    |                1 |                   1 |   1.67189e-08 |            1.24088e-07 |

## 7. Generated artifacts
- `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/trend_scanning_reproduction.ipynb`
- `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/outputs/20260223/phase_b_evidence.md`
