# Evidence Log（最小限）

## 1. 使用ソース

- 原本PDF  
  `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/docs/sources/MetaTrader 5 Machine Learning Blueprint (Part 3)_ Trend-Scanning Labeling Method - MQL5 Articles.pdf`
- ページ数  
  16 pages（`pypdf` で確認）
- 抽出日時  
  2026-02-23 17:33:50 +0900
- 抽出方法  
  `/Users/kencharoff/workspace/envs/base/.venv/bin/python` + `pypdf`

## 2. 実行コマンド一覧（要約）

- ルール確認: `workspace/AGENTS.md`、`projects/momentum/p03_trend-scanning/AGENTS.md` を参照
- リポジトリ確認: `ls`, `rg --files`, `find` でファイル構成を確認
- PDF確認: `python + pypdf` でページ数、主要本文（p.1-14）を抽出
- データ確認: `python + pandas` で `data/prices.csv` の列構造、期間、対象銘柄を確認
- 成果物作成: `docs/notes/review.md`, `outputs/20260223/evidence.md` を新規作成

## 3. 生成成果物

- `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/docs/notes/review.md`
- `/Users/kencharoff/workspace/projects/momentum/p03_trend-scanning/outputs/20260223/evidence.md`
