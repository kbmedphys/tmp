# Phase B Evidence Summary (2026-02-23)

- 生成日時: 2026-02-23 20:36:02 JST
- 入力データ: `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/data/prices.csv`
- 任意MFデータ: `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/data/raw/mf_weekly_flows.csv`
- MFセクション状態: `skipped_missing_mf`
- 既存証跡バックアップ: `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/outputs/phaseB_evidence_summary_2026-02-23.md.bak.20260223203602`

## 近似定義
- `ret_{i,t} = AdjClose_{i,t} / AdjClose_{i,t-1} - 1`
- `flow_proxy_{i,t} = diff(log(Close_{i,t} * Volume_{i,t}))`
- `premium_proxy_{i,t} = Close_{i,t} / Open_{i,t} - 1`
- `market_ret_t = mean_i(ret_{i,t})`, `flow_aggr_t = mean_i(flow_proxy_{i,t})`

## パネル回帰主要符号（近似）
|   subperiod |   flow_t_coef |   flow_t_pvalue |   flow_t_minus_2_coef |   flow_t_minus_2_pvalue |
|------------:|--------------:|----------------:|----------------------:|------------------------:|
|   2011_2026 |   -0.00158638 |     1.59427e-09 |          -0.000654623 |               0.0399436 |
|   2018_2026 |   -0.001742   |     8.83452e-05 |          -0.000937653 |               0.0687541 |
|   2020_2026 |   -0.00180897 |     0.00266165  |          -0.00112491  |               0.0843663 |

## VAR主要係数（market_ret方程式のL2.flow_aggr）
|   subperiod |   coef_L2_flow_aggr_to_market_ret |   pvalue |
|------------:|----------------------------------:|---------:|
|   2011_2026 |                      -0.000101384 | 0.896074 |
|   2018_2026 |                       0.000104877 | 0.931672 |
|   2020_2026 |                       0.000734526 | 0.629128 |

## リーク防止検証
- `ret_(t+1) ~ flow_proxy_t` 補助回帰: coef=-0.000620341, p=0.016542
- 特徴量はすべて `t` 時点以前のラグのみで構築し、目的変数は `t+1` を別列化して検証。

## 未再現項目
- 原著のShrout/NAVベースflow、Premium、ICI週次MFフローが未提供のため厳密再現ではない。
- 本成果は `prices.csv` に基づく近似再現であり、論文の絶対値一致は目的外。

## 出力ファイル
- `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/outputs/phaseB_results/panel_coefficients.csv`
- `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/outputs/phaseB_results/var_coefficients.csv`
- `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/outputs/phaseB_results/cirf_table.csv`
- `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/outputs/phaseB_results/weekly_lead_coefficients.csv`
- `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/outputs/phaseB_evidence_summary_2026-02-23.md`
