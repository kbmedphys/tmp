# Phase A Evidence Summary (2026-02-23)

## 1. 実施情報

- 実施日時: 2026-02-23 19:47:08 JST
- 作業ルート: `/Users/kencharoff/workspace`
- 対象プロジェクト: `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows`
- 実施範囲: Phase A（文献レビューのみ、実装禁止）

## 2. 使用ソースPDF

- ファイル: `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/docs/sources/Fund Flows and Underlying Returns The Case of ETFs.pdf`
- サイズ: 851,962 bytes
- ページ数: 30
- メタ情報:
  - title: `None`
  - author: `Ares`
  - producer/creator: `Microsoft Word 2013`

## 3. 抽出方式と制約

- Python実行環境: `/Users/kencharoff/workspace/envs/base/.venv/bin/python`
- 抽出ライブラリ: `pypdf`（補助候補として `pdfplumber` も可）
- 確認方式: 抽出テキスト中心
- 制約:
  - `pdftoppm` / `pdfinfo` は未導入（コマンド未検出）
  - したがって、ページ画像レンダリングによる視覚確認は未実施

## 4. 主要主張と対応ページ一覧

- 研究目的（ETFフローと基礎資産リターンの関係、価格圧力と反転）: [p.1], [p.7]
- 仮説1/仮説2（同時点正、ラグ負）: [p.7]
- データ期間・サンプル構築（2000-2010、286本、レバレッジ除外）: [p.7], [p.8]
- フロー定義（式(1)）と外れ値処理: [p.9], [p.10]
- T+1報告ラグ補正（N-CSRS/N-30b-2照合）: [p.10]
- パネル回帰仕様（PCSE、AR(1)、ラグ構造）: [p.14], [p.15]
- Top10での価格反転（`Flow_{t-2}`負）と経済量: [p.15], [p.16]
- VAR仕様（集計フロー、ラグ4、2007-2010）: [p.17], [p.18]
- CIRFの定量結果（53%の早期反転、長期38%反転）: [p.19], [p.21]
- 投信フローを入れた週次回帰でETF反転継続: [p.24], [p.25]
- 結論（38%反転、34bps一時成分）: [p.26]

## 5. 生成物

- レビュー本文:
  - `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/docs/notes/review.md`
- 証跡サマリ（本ファイル）:
  - `/Users/kencharoff/workspace/projects/momentum/p04_fund_flows/outputs/phaseA_evidence_summary_2026-02-23.md`

## 6. 変更範囲チェック

- 追加/更新先は `docs/notes` と `outputs` のみ
- `.ipynb` / コード実装ファイルの変更なし
