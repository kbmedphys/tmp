# Phase B Summary (Sector ETF Comomentum)

- run_datetime: 2026-02-23T01:08:20+09:00
- data_period: 2011-01-03 to 2026-02-20
- universe: XLB,XLE,XLF,XLI,XLK,XLP,XLU,XLV,XLY
- quantile_rule:
  - full: Top3/Bottom3
  - pseudo_B_defensive: Top1/Bottom1
- comom_definition: 52-week residual correlation with equal-weight ETF market factor
- main_signs: year1=non_negative (0.000210), year2=non_negative (0.000202)
- robustness_pass_fail: pass (sign_match_count=7)
- investor_extension_result: nobs=1512
- external_extension_result:
  - pseudo_A_cyclical: y1_coef=-0.000759, y2_coef=-0.001647, nobs_y1=157
  - pseudo_B_defensive: y1_coef=-0.002612, y2_coef=-0.000881, nobs_y1=157
- leak_checks: feature_after_target_violations=0, comom_window_violations=0, all_zero=True

```json
{
  "run_datetime": "2026-02-23T01:08:20+09:00",
  "data_period": {
    "start": "2011-01-03",
    "end": "2026-02-20"
  },
  "universe": "XLB,XLE,XLF,XLI,XLK,XLP,XLU,XLV,XLY",
  "quantile_rule": {
    "full": "Top3/Bottom3",
    "pseudo_B_defensive": "Top1/Bottom1"
  },
  "comom_definition": "52-week residual correlation with equal-weight ETF market factor",
  "main_signs": {
    "year1_coef_sign": "non_negative",
    "year2_coef_sign": "non_negative",
    "year1_coef": 0.0002100471190937051,
    "year2_coef": 0.0002022118455395309
  },
  "robustness_pass_fail": "pass",
  "robustness_sign_match_count": 7,
  "investor_extension_result": {
    "nobs": 1512,
    "group_slopes": [
      {
        "group": "small",
        "comom_slope": 0.003453087998982566,
        "interaction_t": NaN
      },
      {
        "group": "mid",
        "comom_slope": 0.006516838653784189,
        "interaction_t": 1.025249184357978
      },
      {
        "group": "large",
        "comom_slope": 0.003096090806852919,
        "interaction_t": -0.11355071017484676
      }
    ]
  },
  "external_extension_result": [
    {
      "market": "pseudo_A_cyclical",
      "top_bottom": "Top3/Bottom3",
      "coef_y1": -0.0007588572227733409,
      "t_y1": -0.5429797093870684,
      "coef_y2": -0.0016468561877104632,
      "t_y2": -1.0993740635699103,
      "nobs_y1": 157,
      "nobs_y2": 145
    },
    {
      "market": "pseudo_B_defensive",
      "top_bottom": "Top1/Bottom1",
      "coef_y1": -0.0026120279339914877,
      "t_y1": -1.906519716998929,
      "coef_y2": -0.0008812024829682032,
      "t_y2": -0.792734027434231,
      "nobs_y1": 157,
      "nobs_y2": 145
    }
  ],
  "leak_checks": {
    "feature_after_target_violations": 0,
    "comom_window_violations": 0,
    "all_zero": true
  }
}
```
