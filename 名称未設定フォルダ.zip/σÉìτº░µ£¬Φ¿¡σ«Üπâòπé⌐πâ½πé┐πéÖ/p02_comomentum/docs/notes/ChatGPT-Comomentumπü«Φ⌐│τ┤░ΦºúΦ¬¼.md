# Comomentumの詳細解説

**User:** Anonymous (kencharoffx@gmail.com)  
**Created:** 2/23/2026 17:32:27  
**Updated:** 2/23/2026 17:44:41  
**Exported:** 2/23/2026 17:46:39  
**Link:** [https://chatgpt.com/c/699c1089-c8a8-83a9-9ac1-04f1605b8a38](https://chatgpt.com/c/699c1089-c8a8-83a9-9ac1-04f1605b8a38)  

## Prompt:
Comomentum.pdf

PDF

内容を詳細に解説してください。

## Response:
思考時間: 26s

以下は、論文 **「Comomentum: Inferring Arbitrage Activity from Return Correlations」**（Dong Lou & Christopher Polk, London School of Economics）の**中身を “再現できる粒度” で**整理した詳細解説です。

Comomentum

* * *

1\. この論文が解こうとしている問い（何が新しいのか）
----------------------------

論文の中心問題はシンプルで、

*   **裁定（arbitrage）活動は市場を効率化し安定化させるのか？**
*   それとも、**混雑（crowding）すると逆に価格を不安定化（destabilize）させるのか？**

という古典的論争を、**観測可能なデータから実証したい**というものです。ところが「裁定資本の量」「誰がどれだけレバレッジでどの戦略を回しているか」は直接観測できない。そこで著者は、裁定プロセスの“投入量”ではなく\*\*結果（アウトカム）\*\*を測る発想を取ります。

Comomentum

* * *

2\. コアアイデア：裁定取引が“同時に多銘柄を動かす”なら、残差相関が上がる
---------------------------------------

著者の着想は：

*   ニュースに反応して個別に売買する投資家（newswatchers）は、基本「銘柄ごと」に動く
*   一方、**モメンタムのような戦略**は「勝ち組をまとめて買い、負け組をまとめて売る」＝**同時に多数銘柄を動かす**

もしこの“同時売買”が価格にインパクトを与えるなら、**同じ戦略が触る銘柄同士のリターンに、リスクファクターでは説明できない余計な共動（excess comovement）が出る**はずです。

Comomentum

この「戦略に触られている銘柄集合の中での、ファクター調整後の高頻度相関」を、裁定活動（混雑度）の代理変数にします。

* * *

3\. 定義：Comomentum（COMOM）は何をどう計算するか
----------------------------------

### 3.1 モメンタム・ポートフォリオ（勝者/敗者）の作り方

毎月末  $t-1$  に、

*   過去12ヶ月累積リターン（直近1ヶ月はスキップ）で全株をデシルにソート
*   **勝者（winner）デシル**と**敗者（loser）デシル**を定義
*   マイクロストラクチャ対策として  
    **株価5ドル未満**、**NYSEサイズ下位デシル**を除外
    Comomentum

### 3.2 “高頻度”の共動を測る：週次52本で部分相関

COMOM は「形成期間中の高頻度（週次）」で測ります。具体的には：

*   ランキング（形成）期間の **週次リターン52本**を使う
*   その週次リターンから **Fama-French 3因子**の影響を落とした“残差”ベースの相関を測る
    Comomentum

ここが重要で、「単なる相関」ではなく、

*   市場・サイズ・バリュー（ $mktrf, smb, hml$ ）で説明される共動を**除いた**相関  
    ＝“異常な（abnormal）共動”だけを取りたい、という設計です。
    Comomentum

### 3.3 数式（論文の operational definition）

敗者側の comomentum（loser comomentum）:

$$
comom^{L}=\frac{1}{N_L}\sum_{i=1}^{N_L} partialCorr\left(r^{L}_i,\ r^{L}_{-i}\mid mktrf,smb,hml\right)
$$

勝者側も同様に：

$$
comom^{W}=\frac{1}{N_W}\sum_{i=1}^{N_W} partialCorr\left(r^{W}_i,\ r^{W}_{-i}\mid mktrf,smb,hml\right)
$$

ここで  $r^{L}_{-i}$  は「敗者デシル等ウェイトのリターン（ただし銘柄  $i$  を除いたもの）」です。つまり、

*   **各銘柄  $i$ ** と
*   **同じデシル“残り全部”の平均**  
    の部分相関を取り、それを平均します。
    Comomentum

> 直感：もし“デシル全体に同時売買インパクト”があるなら、どの銘柄も「デシル平均（自分抜き）」と一緒に動きやすい。

* * *

4\. 背景理論：なぜ「高COMOM＝危ない（クラッシュ/リバーサル）」が起こるのか
------------------------------------------

著者は、モメンタムを「アンカーがない（unanchored）」戦略だと位置付けます。

*   価値（バリュー）なら「バリュースプレッド」などの**基礎的アンカー**があり、乖離が縮めば資金が引く合理性がある
*   しかしモメンタムは「過去リターンが高いから買う」で、**いま既にどれだけ混雑しているか**を各参加者が把握しにくい

この状況では、Jeremy Stein（2009）の議論のように

*   混雑が小さいとき：裁定が**過小** → **アンダーリアクション補正**で安定的に利益
*   混雑が大きいとき：裁定が**過大** → **オーバーシュート**、さらに巻き戻しでクラッシュ

という「アンダーリアクション⇄オーバーリアクションが時変になる」ことが予測されます。

Comomentum

* * *

5\. メイン実証①：COMOMは“裁定資本っぽいもの”と連動する
---------------------------------

論文はまず、COMOM が「それっぽい proxy」と関係するかを確認します。結果として、

*   勝者側の機関投資家保有（institutional ownership）
*   シャドーバンキング規模（shadow）
*   ロング・ショート系ヘッジファンドAUM
*   過去のモメンタム戦略収益（mom12）

などが、将来の comomentum を予測する（＝混雑が増えると COMOM が上がる）と示します。

Comomentum

ここでの論理は明確で、

*   戦略が儲かる → 資金流入 → 同時売買圧力増 → residual correlation 上昇

という流れです。

* * *

6\. メイン実証②：COMOMが高いと、モメンタムは“形成期は良いが、その後崩れてリバースする”
-------------------------------------------------

### 6.1 イベントタイムの設計

毎月  $t-1$  にモメンタム・ポートフォリオを作り（直近1ヶ月スキップ）、その後

*   Year 1（保有1年）
*   Year 2（さらにその次の1年）
*   Year 3（さらに次の1年）

というイベントタイムで追跡して、「長期でリバースするか」を見る構造です。

Comomentum

### 6.2 主要結果（定性的まとめ）

*   **Year 0（形成期）**：COMOMが高いほどモメンタムは“良く見える”（形成期リターンが単調増加）
    Comomentum
*   **Year 1（形成後1年）**：COMOMが高いほど収益が悪化し、**最高COMOMではモメンタムがマイナスになり得る**
    Comomentum
*   **Year 2**：この単調悪化がさらに強く、COMOMが高いほど“より強い巻き戻し（リバーサル）”
    Comomentum

つまり、

> 高COMOM期のモメンタムは、**混雑トレードが価格を押し上げ（押し下げ）過ぎて、後で戻る**  
> ＝「儲かって見える→クラッシュ/リバース」になりやすい

という結論です（著者はこのパターンを underreaction vs overreaction の切替として解釈）。

Comomentum

* * *

7\. コントラスト実証：アンカーがある戦略（Value）では逆になる
-----------------------------------

著者は同じ発想を value にも適用し、

*   value銘柄側の“異常共動”＝ **covalue**
*   それが将来の value 戦略収益を **正に**予測し、
*   モメンタムのような「クラッシュや長期リバース」は見えにくい

と述べます。これは「アンカーがあると、混雑＝過剰投機ではなく、合理的な裁定配分（expected return が高いときに資本が集まる）」という読みです。

Comomentum

* * *

8\. 追加の外部妥当性：国際・ファンド・通貨でも同じ構造が出る
--------------------------------

論文は「米国株だけの特殊な話ではない」ことを確認します。

### 8.1 国別（非米国）でも：国別comomentumが高いほど国別モメンタムが弱い

19の非米国市場で、国別 comomentum が高いほど、その国のモメンタム収益が弱くなる（そして “低い国だけやる” で高い年率異常収益）という趣旨が述べられます。

Comomentum

### 8.2 ヘッジファンドの “タイミング” ：高COMOM期にモメンタムエクスポージャーを落とす

ヘッジファンドのリターンや因子エクスポージャーを、ラグ付き comomentum で説明する回帰（「Momentum Timing Ability」）を行い、典型的なロング・ショート株HFが **COMOMが高いとモメンタムへのエクスポージャーを下げる**、ただし **AUMが大きいほどタイミング能力が劣化**する、という「もっともらしい」結果を提示します。

Comomentum

（表の説明と回帰設定の断片はここでも確認できます。

Comomentum

）

### 8.3 通貨モメンタムでも：Currency COMOMが高いとその後の累積異常収益が悪化

通貨モメンタムでも、winner通貨群内の“部分相関ベースの異常共動”（Currency COMOM）で期間を3群に分けると、形成後の累積異常収益のパスが違う（高COMOMほど不利）という図を示します。

Comomentum

* * *

9\. 実務的にどう読むべきか（この論文の“使いどころ”）
-----------------------------

この論文の価値は、「モメンタムがダメな局面」を \*\*市場状態（market return/vol）\*\*ではなく、

*   **“戦略の混雑度”を、リターン相関から逆推定する**

という形で定量化した点にあります。実装的には次のように使えます：

*   **モメンタムの実行を、COMOMでゲートする**
    *   低COMOM：通常運用（アンダーリアクション補正局面）
    *   高COMOM：縮小/停止/ヘッジ（クラッシュ・リバース警戒）
*   「アンカーがある戦略（value等）」では同じシグナルでも読みが逆（covalueが高い＝期待収益が高い）になり得る

* * *

必要なら次に、あなたのETF/ファクターETF文脈（ロングオンリー、レバなし）へ落とすために、

1.  ETFユニバースでの **COMOMの定義の置き換え（銘柄→ETF、FF3→ETF向け因子）**
2.  月次リバランス戦略への **実装仕様（リーク防止・週次52本の取り方・部分相関の計算手順）**
3.  「モメンタムだけでなく“テーマETF回転”」での **crowding proxy** への拡張（テーマ内共動など）

まで、同じ粒度で設計に落とせます。

## Prompt:
Comomentum\_sector\_etf.ipynb

ファイル

添付のプログラムとドキュメントの内容を対応つけて解説して

## Response:
思考時間: 1m 0s

了解です。ここでは **添付ノートブック（Comomentum\_sector\_etf.ipynb）** の各処理が、論文のどの定義・図表・検定に対応しているかを **「関数名／変数名」単位**で対応づけて解説します。あわせて、\*\*論文とノートブックの差分（＝再現上のズレ）\*\*も明確化します。

* * *

0) まず論文側の「定義（何を再現すべきか）」
-----------------------

論文での comomentum（COMOM）は、

1.  月末に \*\*過去12ヶ月リターン（直近1ヶ月スキップ）\*\*で銘柄をデシルに分類
2.  ランキング（形成）期間中の **週次52本**を使い
3.  **Fama-French 3因子で調整した残差**同士の \*\*部分相関（partial correlation）\*\*の平均を COMOM とする  
    ——という定義です。
    Comomentum
    （さらにマイクロストラクチャ対策として低位株価・小型株の除外も明記。
    Comomentum
    ）

* * *

1) ノートブック全体の設計：論文のどこを狙っているか
---------------------------

ノートブックの章立て（markdown見出し）を見ると、狙いは明確に

*   **COMOMの構築（論文の式(1)(2)）**
*   **COMOMで月をビン分けして、その後1年/2年/3年のWMLがどう変わるか（論文 Figure 2 / イベントタイム分析）**
*   **Newey–Westで将来リターンをCOMOMで回帰（論文のTable III/IV系の発想）**
*   **ロバストネス（comom\_w代替、統合版、残差化、サブ期間等）**
*   **拡張（投資家/市場ごとの異質性、国際・通貨拡張のETF版）**

…という構造です（ノートブックの見出し「Main Tests (Table III / IV 相当)」がその宣言）。

* * *

2) セクション別：コード ↔ 論文 の対応
----------------------

### A. Data（データ読み込み） ↔ 論文のCRSP等の代替

**Notebook:**

*   `load_prices_csv(path)`
    *   CSVから **Adj Close / Volume** を2段ヘッダで読み込み、日次価格 `prices_daily` と出来高 `volume_daily` を作っています。

**Paper:**

*   論文は株式（CRSP等）＋機関投資家保有など複数ソースですが、ノートブックは **セクターETF（例：XLB…）の価格・出来高**に置換しています（ETF版の“擬似市場”）。

> 対応づけの意味：  
> 株式ではなくETFでも「同じ戦略（モメンタム）が触る集合内で残差相関が上がるなら、混雑度proxyとして使えるはず」という実験設計。

* * *

### B. Feature Engineering（形成リターン、週次化、COMOM測定窓） ↔ 論文の式(1)(2)の“入力作り”

**Notebook: `run_pipeline_for_universe(...)` の中核**

1.  **月次・週次系列の生成**
    *   `prices_m = prices_daily_u.resample('ME').last()`
*   `ret_m = prices_m.pct_change()`
*   `prices_w = prices_daily_u.resample('W-FRI').last().ffill()`
*   `ret_w = prices_w.pct_change()`

↔ 論文の「月次で形成」「週次52本で相関測定」に対応。

Comomentum

（週次が `W-FRI` なのも “週次データ” の作り方として妥当）

2.  **12-1モメンタム（直近1ヶ月スキップ）**
    *   `ret12_skip1 = (1.0 + ret_m.shift(1)).rolling(12).apply(np.prod, raw=True) - 1.0`

↔ 論文の「lagged 12-month cumulative returns (skipping the most recent month)」の直接実装に相当。

Comomentum

3.  Winner / Loser の定義（デシルの代替）
    *   `assign_groups(scores, top_n, bottom_n)`
    *   ここでは **デシルではなく**「上位 top\_n / 下位 bottom\_n」を winner/loser として採用
    *   実行箇所：`winners, losers, labels = assign_groups(signal, top_n=3, bottom_n=3)`（full\_9etf）

↔ 論文は「全株をデシルに分けて極端デシル」を使いますが、ETFが9本しかないので **極端デシルの代替として top3/bottom3** にしている、という対応です。

* * *

### C. COMOM計算（最重要） ↔ 論文の partialCorr 定義（式(1)(2)）

**Paper（定義）：**

*   Winner/Loserデシルの週次リターンについて、FF3因子をコントロールした **部分相関**を平均。
    Comomentum
*   実装上は「各銘柄の残差」と「自分を除いたデシル平均残差」の相関を平均する形で operationalize。
    Comomentum

**Notebook（実装）：**

1.  **因子調整（ただしFF3ではなく“市場因子のみ”）**
    *   `market_w = w.mean(axis=1)`
*   `resid_all = residualize_with_market(w, market_w)`
*   `residualize_with_market(frame, market)` は各ETFについて  
    `ret ~ const + mkt` をOLSして残差を取る

↔ “因子で説明される共動を落として residual correlation を見る” という思想は一致。  
ただし論文は **mktrf,smb,hml（FF3）** をコントロールする点が異なります。

Comomentum

2.  **COMOM本体（loser側 / winner側）**
    *   `comom_l = side_comomentum(resid_all, losers)`
*   `comom_w = side_comomentum(resid_all, winners)`
*   `side_comomentum` の中身は概ね：
    *   sideに2本以上あれば `avg_pairwise_corr(resid_all[side_cols])`（残差の**平均ペアワイズ相関**）
    *   1本しかなければ “自分 vs 残り平均” の相関（フォールバック）

↔ ここが論文の式(1)(2)に最も近い箇所ですが、**厳密には別物**です。

*   論文：**partialCorr**（FF3条件付き）を “各銘柄 vs 自分除き平均” で平均化
    Comomentum
*   Notebook：市場残差化した後に、**単純相関（pairwise corr）** を平均

> ただし、ETF本数が少ない状況では「pairwise平均」は計算安定性が高く、探索段階としては合理的な近似です。  
> “論文を正確に再現したい”なら後述の修正が必要です。

3.  **派生の“統合COMOM”**
    *   `signed = pd.concat([resid_all[winners], -resid_all[losers]], axis=1)`
*   `comom_comb = avg_pairwise_corr(signed)`

↔ 論文の「WML（winner - loser）という“戦略方向付き”の同時売買」を、符号反転で一つの集合にして相関を測る試み。  
論文の定義そのものではないですが、「戦略クラウディングの強さ」を測る発想としては筋が通っています。

* * *

### D. イベントタイムの将来WML（Year1/Year2/Year3） ↔ 論文 Figure 2 / 形成後のリバーサル

**Paper：**

*   形成後 **1年、2年、3年** のモメンタム収益が、ラグCOMOMの高低でどう変わるかをイベントタイムで提示（形成期Year0も示す）。
    Comomentum

**Notebook：**

*   `horizon_mean_wml(ret_m, signal_month, winners, losers, start_k, end_k)`
    *   `year1 = ... (1,12)`
    *   `year2 = ... (13,24)`
    *   `year3 = ... (25,36)`
    *   `year0 = ... (-12,-1)`（形成期を “過去12ヶ月平均WML” として出している）

↔ “COMOMで分類 → 形成後の累積/平均WMLを見る” という骨格は **論文 Figure 2 のETF版**です。

Comomentum

**重要なズレ（論文再現として）**

*   論文は “形成月の前12ヶ月” でCOMOMを測り、形成後のパフォーマンスを追います。ノートブックでも `window_end = prev_month_end` としており、**先読み回避の意図**は一致。
*   ただし、論文の Figure 2 は「5群（quintile）」分類が標準ですが、ノートブックは `rank_buckets(..., bins=3)` で **3群**です（本数が少ないETFでは妥当な簡略化）。

* * *

### E. Main Tests（Table III/IV相当） ↔ COMOMが将来収益を予測するか（NW回帰）

**Paper：**

*   COMOMが高い局面ほど形成後のモメンタム収益が弱い／クラッシュ的歪度が悪化、などを統計的に示す。  
    さらにコントロール（市場環境等）も入れる。
    Comomentum
    （図表の説明にある分類と追跡の枠組み）

**Notebook：**

*   `nw_ols(df, y_col, x_cols, lags=12)`
    *   `cov_type='HAC', maxlags=12` の \*\*Newey–West（HAC）\*\*で回帰
*   実行：
    *   `reg_y1 = nw_ols(analysis,'year1',['comom_rank_l'],lags=12)`
    *   `reg_y2 = ...`
    *   `reg_y1_ctrl = nw_ols(...,['comom_rank_l','mktret36','mktvol36'])`

↔ 「将来年次平均WMLを COMOMランクで説明」＋「市場状態（3年リターン/3年ボラ相当）でコントロール」という対応です。  
論文がいくつかのproxy（過去モメンタム、シャドーバンキング等）でCOMOM自体を説明したりするのに対し、ノートブックはまず **“COMOM→将来収益” の主効果**を検定する構造に寄せています。

* * *

### F. Robustness（主要6本） ↔ 代替定義でも結果が保たれるか

**Notebook（cell 10）**

1.  `comom_w_alt`：説明変数を `comom_rank_w` に変更
2.  `combined_signed_comom`：`comom_rank_comb` に変更
3.  `residualized_comom_l`：`comom_l` を `market_common_corr` と `mktvol36` で回帰して残差化→そのランクで回帰
4.  サブ期間：前半/後半で係数符号を見る（`year12`でチェック）

↔ 論文でも「comomLとcomomWどちらでも頑健」等の主張があり（“All our results are robust to using either comomL or comomW”）。

Comomentum

ノートブックはそれを ETF版で確認する設計です。

* * *

### G. Investor Extension（流動性サイズ3群） ↔ “投資家/裁定資本”の関与を示す方向

**Paper：**

*   機関投資家保有、ヘッジファンドAUM、シャドーバンキングなどが COMOM を予測する（＝裁定資本の流入と整合的）という検証を行う。
    Comomentum

**Notebook（cell 12）**

*   ここでは外部のIOやAUMデータが無いので、代替として
    *   `dollar_vol_m = (price*volume).resample('ME').mean()` を作り
    *   月次でETFを `pd.qcut(...,3)` で \*\*small/mid/large（流動性サイズproxy）\*\*に分類
    *   各ETFの次月リターン `ret_next` を、`umd_proxy`（12-1のzscore）と `comom_rank`、`size_group` でパネル化

↔ 「裁定活動の受け皿（大きい/流動性が高い）で効果が違うか」を見る、論文の“投資家資本”議論の \*\*簡易版（proxy版）\*\*です。

* * *

### H. External ETF Extension（擬似市場A/B） ↔ 国際・通貨拡張のETF版

**Paper：**

*   国別モメンタム・通貨モメンタムでも COMOM の枠組みが通る（外部妥当性）。
    Comomentum
    Comomentum

**Notebook（cell 14）**

*   擬似市場A（cyclical 6ETF）  
    `cyclical = ['XLB','XLE','XLF','XLI','XLK','XLY']`
*   擬似市場B（defensive 3ETF、top1/bottom1）  
    `defensive = ['XLP','XLU','XLV']`
*   各ユニバースで `run_pipeline_for_universe` を再実行して、係数符号が保たれるか比較

↔ これは “別市場でも同じ符号が出るか” のチェックで、論文の国際・通貨拡張の思想に対応します。

* * *

3) ノートブックが入れている「リーク（先読み）検査」↔ 論文の注意点への実装的対応
------------------------------------------

`run_pipeline_for_universe` 内の

*   `window_end = prev_month_end`（comom測定窓が形成月より前で終わる）
*   `leak_comom_window` カウント
*   `first_target_month = signal_month + MonthEnd(1)` と比較して `leak_feature_after_target` カウント

は、\*\*“COMOMが予測変数であるためには測定が先でないといけない”\*\*という論文の注意（形成後にCOMOMを測る場合の注意書き）に対する実装上のガードです。

Comomentum

* * *

4) 再現としての「差分」—ここを理解すると、結果の解釈がブレません
----------------------------------

あなたが「論文と対応づけて」読むうえで、差分は最低限ここを押さえるべきです。

### 差分1：FF3の partialCorr ではなく「市場で残差化→単純相関」

*   論文：`partialCorr( | mktrf,smb,hml )`
    Comomentum
*   Notebook：`residualize_with_market`（mktのみ）＋`avg_pairwise_corr`

**影響**

*   COMOMが “市場要因で共に動く” 部分を十分に除去できていない可能性
*   その場合、COMOMが「混雑」ではなく「単にセクターの共通ショック」を拾う比率が増えます

### 差分2：「自分を除いたデシル平均」との相関平均 ではなく、ペアワイズ平均

*   論文：各  $i$  と “デシル平均（除外i）” の相関を平均化
    Comomentum
*   Notebook：ペアワイズ相関の上三角平均（`avg_pairwise_corr`）

**影響**

*   小本数（ETF数が少ない）ではペアワイズ平均の方が安定
*   一方で、論文の operationalization そのものではない

### 差分3：ビン数（5群→3群）、デシル→top/bottom

*   ETFが9本しかないための実務的簡略化。  
    “方向性チェック”としてはOKですが、論文の図表と同じ見え方にはなりません。

* * *

5) 「対応づけ」を踏まえた読み方（実務的解釈）
------------------------

このノートブックは、論文の本質である

> **COMOM（＝同じ戦略で同時に触られる集合の residual comovement）が高い局面ほど、形成後のモメンタム（WML）が悪化しやすい**

という仮説を、**セクターETFで成立するか**を検定する骨格になっています。  
ただし上の差分のせいで、結果が出たとしてもそれは

*   “混雑（crowding）” の効果
*   “市場・セクター共通ショック” の効果

が混ざっている可能性があるため、あなたの次のステップは自然に

1.  FF3（あるいはETF向け因子）で残差化する
2.  論文の「除外iの平均」方式で comom を定義し直す
3.  ビン数を増やせるユニバース（ETF本数増）で再検定する

になります。

* * *

必要なら、次の返信で \*\*「ノートブックのどの関数をどう直せば論文の式(1)(2)に一致するか」\*\*を、差分1〜2を潰す形で **ピンポイントに修正案**として提示します（FF3の代替因子をETFでどう用意するか、除外i平均の実装、週次窓の厳密化、など）。

## Prompt:
お願いします

## Response:
思考時間: 1m 2s

了解です。**このノートブックを「論文どおりの COMOM（FF3条件付き partial correlation を、i vs “自分抜き平均”で平均）」に一致させる**ための **ピンポイント修正**を出します。

以下は \*\*Comomentum\_sector\_etf.ipynb の Cell\[4\]（関数定義が集まっているセル）\*\*だけを最小改造する想定です。  
（依存追加なし・ETFデータだけで FF3 近似を作る方針）

* * *

変更方針（何をどう直すか）
=============

現状（ノートブック）
----------

*   `residualize_with_market(w, market_w)`：市場（wの平均）だけで残差化
*   `side_comomentum(...)`：残差の **平均ペアワイズ相関**で comom を計算

論文どおりにする
--------

1.  **FF3（mktrf, smb, hml）条件付きの partialCorr**にする
    *   株式FF3を直接取れないので、ETFで **近似FF3** を作る（後述）
2.  comom の定義を論文の operational definition に合わせる
    *   各  $i$  と「同サイド平均（除外i）」の **partialCorr** を取り、それを平均する

* * *

Step 1) “ETFでFF3近似因子” を作る（依存追加なし）
=================================

このノートブックは CSV（Adj Close/Volume）読みです。  
**同じCSVに因子ETFの列を追加**して使うのが一番簡単です。

### 追加するティッカー（例）

*   `SPY`：市場（MKT）
*   `IWM`：小型（Small）
*   `IWD`：Value
*   `IWF`：Growth

そして **週次因子**をこう作ります（近似）：

*   `mktrf` 近似：`SPY` の週次リターン
*   `smb` 近似：`IWM - SPY`（small minus big の簡易proxy）
*   `hml` 近似：`IWD - IWF`（value minus growth の簡易proxy）

> 注：論文は厳密なFF3（超過収益）ですが、ETF版ではこれが実務的に一番軽くて再現性が高いです。  
> （将来、pandas\_datareaderで Ken French FF を取れるなら差し替え可能）

* * *

Step 2) Cell\[4\] に「因子で残差化」関数を追加（market-only を置換）
=================================================

Cell\[4\] の `residualize_with_market` の下あたりに、次を追加してください。

```
def build_etf_ff3_factors(ret_w: pd.DataFrame,
                          mkt: str = "SPY",
                          small: str = "IWM",
                          value: str = "IWD",
                          growth: str = "IWF") -> pd.DataFrame:
    """
    ETFから FF3 近似因子（週次）を作る。
    ret_w: 週次リターン（列に上記ETFが存在する必要）
    """
    need = [mkt, small, value, growth]
    miss = [c for c in need if c not in ret_w.columns]
    if miss:
        raise ValueError(f"Missing factor ETFs in ret_w: {miss}. "
                         f"Add them to the CSV (Adj Close/Volume).")

    f = pd.DataFrame(index=ret_w.index)
    f["mktrf"] = ret_w[mkt]
    f["smb"]   = ret_w[small] - ret_w[mkt]
    f["hml"]   = ret_w[value] - ret_w[growth]
    return f

def residualize_with_factors(y: pd.Series, factors: pd.DataFrame) -> pd.Series:
    """
    y ~ const + factors を OLS して残差を返す
    """
    work = pd.concat([y, factors], axis=1, join="inner").dropna()
    if len(work) < 20:
        return pd.Series(index=y.index, dtype=float)

    y2 = work.iloc[:, 0]
    X  = sm.add_constant(work.iloc[:, 1:], has_constant="add")

    # 因子が欠損/定数に近いケースを雑に回避
    if np.any(X.std(ddof=0).values == 0):
        return pd.Series(index=y.index, dtype=float)

    model = sm.OLS(y2, X).fit()
    out = pd.Series(index=y.index, dtype=float)
    out.loc[work.index] = model.resid
    return out
```

* * *

Step 3) “論文どおりの comomentum” 関数に差し替える（最重要）
=========================================

現状の `side_comomentum` は **平均ペアワイズ相関**です。  
これを \*\*論文の operational definition（i vs 自分抜き平均）\*\*へ置換します。

Cell\[4\] の `side_comomentum` を **丸ごと置き換え**してください：

```
def side_comomentum_paper(ret_w_window: pd.DataFrame,
                          factors_w_window: pd.DataFrame,
                          side_cols: list[str]) -> float:
    """
    論文の定義に合わせた comom(side):
      comom = (1/N) * sum_i Corr( resid(r_i | F), resid(r_-i | F) )
    ここで r_-i は side 内の「iを除いた等ウェイト平均」。
    """
    side_cols = [c for c in side_cols if c in ret_w_window.columns]
    if len(side_cols) < 2:
        return np.nan

    vals = []
    for i in side_cols:
        others = [c for c in side_cols if c != i]
        if len(others) == 0:
            continue

        r_i   = ret_w_window[i]
        r_m1i = ret_w_window[others].mean(axis=1)

        e_i   = residualize_with_factors(r_i,   factors_w_window)
        e_m1i = residualize_with_factors(r_m1i, factors_w_window)

        work = pd.concat([e_i, e_m1i], axis=1).dropna()
        if len(work) < 20 or work.iloc[:, 1].std(ddof=0) == 0:
            continue
        vals.append(float(work.iloc[:, 0].corr(work.iloc[:, 1])))

    if len(vals) == 0:
        return np.nan
    return float(np.nanmean(vals))
```

※ `avg_pairwise_corr` は残してOK（ロバストネスや診断用に使える）ですが、**主分析の comom は上の関数**を使います。

* * *

Step 4) `run_pipeline_for_universe` の comom 計算部分を書き換える
======================================================

Cell\[4\] の `run_pipeline_for_universe` 内で、下の部分を探してください：

```
market_w = w.mean(axis=1)
resid_all = residualize_with_market(w, market_w)

comom_l = side_comomentum(resid_all, losers)
comom_w = side_comomentum(resid_all, winners)

signed = pd.concat([resid_all[winners], -resid_all[losers]], axis=1)
comom_comb = avg_pairwise_corr(signed)
market_common_corr = avg_pairwise_corr(w)
```

これを **次に置き換え**ます（因子ETF列が必要）：

```
# 近似FF3因子（週次）
factors_w = build_etf_ff3_factors(ret_w, mkt="SPY", small="IWM", value="IWD", growth="IWF")
f_win = factors_w.loc[w.index].dropna()

# window内で因子とリターンの共通インデックスを揃える
w2 = w.loc[f_win.index]

comom_l = side_comomentum_paper(w2, f_win, losers)
comom_w = side_comomentum_paper(w2, f_win, winners)

# “signed comom” は論文の定義ではないので、残すなら補助指標として扱う
# （ここも論文準拠にしたい場合は、同様に signed の等ウェイト平均(除外i) を作って同じ式で計算）
market_common_corr = avg_pairwise_corr(w2)
```

> これで comom\_l / comom\_w は **論文の定義に一致**します（FF3はETF近似）。

* * *

Step 5) “signed comom（統合版）”も論文準拠に寄せたい場合（任意）
===========================================

今の `comom_comb = avg_pairwise_corr(signed)` は論文定義ではないので、もしこれも論文流に寄せるなら：

*   `signed` を “戦略方向付き資産集合” と見做し
*   同様に `side_comomentum_paper` と同型の「i vs 除外平均」式を適用

が良いです（関数をもう1つ用意しても良いですが、最小改造なら `side_comomentum_paper` を流用できます）。

* * *

修正後にチェックすべき「論文対応の合否」3点
======================

1.  **先読みなし**
    *   現状どおり `window_end = prev_month_end` で OK
2.  **partial correlation になっている**
    *   `residualize_with_factors` を通して相関を取っていれば OK（＝条件付き相関）
3.  **“自分抜き平均”で平均化**
    *   `side_comomentum_paper` がまさにそれ

* * *

注意（この修正で起こりがちなエラー）
==================

*   因子ETF（SPY/IWM/IWD/IWF）が CSV に無いと `ValueError` になります  
    → **CSVに列追加**が必要
*   window内で欠損が多いと `len(work)<20` で NaN が増えます  
    → ETF開始時期がズレている場合に起きがち

* * *

必要なら次の返信で、**(A) 因子ETF列をCSVに追加するための最短手順（yfinanceでの生成コード）**、または \*\*(B) Ken Frenchの本物FF3を取る版（pandas\_datareaderを使うが依存追加が必要）\*\*のどちらも、あなたの “uv運用ルール” 前提で提示します。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)