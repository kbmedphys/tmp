# Comomentum 論文レビュー（Phase A）

## 1. 論文情報
- タイトル: *Comomentum: Inferring Arbitrage Activity from Return Correlations*
- 著者: Dong Lou, Christopher Polk
- 所属: London School of Economics
- バージョン: January 2014（First draft: March 2012）
- JEL: G02, G12, G23
- 原本: `/Users/kencharoff/workspace/projects/momentum/p02_comomentum/docs/sources/Comomentum.pdf`
- 総ページ数: 54

## 2. 研究目的と主要仮説
本論文の目的は、裁定資本の規模を「保有残高」ではなく「価格への結果（高頻度異常相関）」から推定し、裁定活動が市場安定化か不安定化かを識別すること。

主要仮説は以下。
- 仮説A（モメンタム戦略）: comomentum（モメンタム銘柄間の異常相関）が低い局面では、モメンタムは過小反応の修正として機能し、将来収益は正でクラッシュしにくい。
- 仮説B（混雑取引）: comomentumが高い局面では、裁定取引が混雑し、価格オーバーシュートを通じて将来のモメンタム収益が低下・反転（クラッシュ/負の歪度）する。
- 仮説C（アンカー有無）: 価値戦略のようにアンカーがある戦略では同様の指標（covalue）はむしろ将来収益を正に予測し、不安定化は起きにくい。

## 3. データとサンプル定義
主要データは以下。
- 米国株: CRSP株価・リターン。
- ファクター: Fama-French 3因子（市場・SMB・HML）を部分相関計算で使用。
- 機関投資家保有: Thomson 13F。
- ヘッジファンド関連: Lipper TASS（AUM）、FRB系列（shadow banking proxy）。
- 投信/ヘッジファンドリターン: CRSP survivorship-bias free mutual fund DB, Lipper TASS。

サンプル制約と期間。
- 低価格・マイクロキャップ除外: 株価 $5 未満、または NYSE時価総額下位デシルを除外。
- 米国メインサンプル: 1964-2010（FF日次因子の利用可能期間に依存）。
- 国際株式: 米国除く19市場（フル重複期間は1986/12-2011/12）。
- 通貨モメンタム: 1972/06-2010/12、先進国通貨（米国外上位20）。

## 4. 指標定義（comomL/comomW/covalue）
### 4.1 comomL/comomW（論文コア）
各月末に、直近1か月をスキップした過去リターンで銘柄をモメンタム10分位に分類し、ランキング期間の52週次データで部分相関を計算する。

論文の定義（要約）:

```text
comomL_t = (1 / N_L,t) * Σ_i partialCorr(retrf^L_i, retrf^L_-i | mktrf, smb, hml)
comomW_t = (1 / N_W,t) * Σ_i partialCorr(retrf^W_i, retrf^W_-i | mktrf, smb, hml)
```

- `retrf^L_i` / `retrf^W_i`: loser/winnerデシル内の銘柄 i の週次超過リターン
- `retrf^L_-i` / `retrf^W_-i`: 同デシルの i 除外等ウェイト週次リターン
- 部分相関は3因子でコントロール

### 4.2 covalue（プラセボ）
同様の相関指標を価値戦略へ適用したもの。価値スプレッド（value spread）と正に連動し、将来のvalue-minus-growth収益を正に予測（モメンタムと逆の含意）。

## 5. ポートフォリオ形成と時点整合
本プロジェクトでの再現実装では、以下の時点整合を固定仕様にする。

1. 月末 `t-1` に、`t-1` 時点までに観測可能な情報のみで特徴量（`ret12_skip1`, `comom` 等）を計算。
2. 月 `t` はスキップ月（論文の skip-month 慣行）。
3. 月初 `t+1` の最初の営業日から、`t-1` 月末で決めたウェイトを適用。
4. 目的変数は `t+1` 以降の将来リターン（Year1/Year2/Year3 窓）。

リーク防止の明示ルール。
- 特徴量計算に `t+1` 以降データを絶対に使わない。
- 分位点（デシル/クインタイル）の閾値推定も月末 `t-1` 時点のクロスセクションのみで実施。
- 月次リバランスの注文執行は「月末決定 → 翌営業日以降適用」を厳守。

## 6. 実証デザイン（回帰・検定）
論文の主要実証は以下の層で構成。

- 時系列予測（Table II）:
  - 被説明: `comomL_t`, `comomW_t`
  - 説明: `mom12_{t-1}`, `institutional ownership`, `shadow`, `AUM`, trend

- 事後イベントタイム収益（Table III/IV/V）:
  - `comom` をクインタイル分割し、Year0/1/2/3 のWML収益を比較
  - OLSで comom rank に対する傾きを推定
  - FF3 alphaでも同様検証
  - 既存予測変数 `mktret36`, `mktvol36` を統制

- クラッシュ特性（Table VI）:
  - 歪度（skewness）と「bad week」頻度（例: 週次 -5% 未満）を比較

- 断面（Table IX）:
  - stock comomentum による Fama-MacBeth（`t+1` 収益予測）
  - `ret12`, size, BM, idiosyncratic vol, turnover を統制

- 外部妥当性:
  - 国際19市場（Table X）
  - ファンドのUMDエクスポージャ時変（Table XI）
  - 通貨モメンタム（Figure 5）

推定上の注意。
- オーバーラップ窓のため、標準誤差は Newey-West（12ラグ）が中心。
- ランキング期間と保有期間を混同しない（形成期間情報のみで予測）。

## 7. 主結果（Table/Figure対応）
- Table I: comomentumは時変性が大きい（loser comom平均 0.118、サンプル内で大幅変動）。
- Table II: `mom12`、機関投資家保有、shadow/AUM は将来comomentumを概ね正に予測。
- Table III:
  - Year0 は高comomほど高収益（高-低で +2.4%/月, t=2.76）。
  - Year1 は高comomほど低収益（高-低で -0.87%/月, t=-2.11）。
  - Year2 で反転がさらに強化（高-低で -1.20%/月, t=-2.72）。
- Figure 2: 低comom局面は累積WMLが正、高comom局面は長期で負方向へ。
- Table V: 多様な定義変更・サブサンプルでも主結果は頑健（Year1+2差分は基準で -1.03%/月, t=-2.67）。
- Table VI: 高comom局面は将来モメンタムの負の歪度・クラッシュ頻度が増える。
- Table VII: covalue は value 戦略を正に予測し、モメンタム型の長期反転は観察されない。
- Table VIII: 効果は機関投資家保有が高い銘柄群で強い。
- Table X: 国際サンプルでも低comom国のモメンタムが高comom国を有意に上回る。
- Table XI: とくに小規模ヘッジファンドで、comom高局面にUMDエクスポージャを落とす挙動。
- Figure 5: 通貨市場でも同方向の結果（高通貨comom局面で将来成績が劣後）。

## 8. ロバストネスと追加検証
論文が実施した主な頑健性確認。
- comomW使用、winner/loser統合定義、市場相関等を除去した残差comomでも結果維持。
- サブサンプル比較（1981年以降で効果強化）。
- 産業調整、DGTW調整、形成窓変更（echo効果との識別）でも概ね同方向。
- プラセボ: value（covalue）および短期リバーサル（coreversal）では「混雑による不安定化」ではなく安定化寄り。

## 9. 再現実装仕様（Phase B入力）
Phase Bノートブック（論文1本=ipynb1本）に渡す実装仕様。

1. 前処理
- 月次・週次リターン系列を同一銘柄IDで結合。
- 除外条件（低価格、下位サイズ）を月次で適用。
- 因子データ（mktrf/smb/hml）を週次頻度へ整合。

2. 特徴量生成（リーク防止）
- 各月末 `t-1` で銘柄をモメンタム分位化（skip-month規則）。
- 同時点までの52週次で `comomL_t`, `comomW_t` を算出。
- 集計特徴量（`mktret36`, `mktvol36` 等）も `t-1` 時点情報のみで生成。

3. ターゲット生成
- `t+1` から先のWML月次収益を Year1/2/3 窓で計算。
- 断面回帰用は銘柄 `t+1` リターンを目的変数化。

4. 推定
- 時系列回帰（OLS + Newey-West 12ラグ）。
- FF3調整alphaで再推定。
- Fama-MacBeth断面回帰（必要統制込み）。

5. 出力
- 論文対応テーブル再現（符号・相対順位・有意性の方向を最低要件）。
- 図の最低再現: comom時系列、低/高comom条件の累積WML。

6. 成否判定（Phase Bの受入基準草案）
- 高comomほど Year1/2 のWMLが低い符号を再現。
- covalueがvalue収益を正に予測する方向を再現。
- リーク防止チェック（時点・分位閾値・執行タイミング）を全セルで明示。

## 10. 未確定事項・追加調査項目
1. データアクセス
- 論文水準の厳密再現には CRSP/Compustat/13F/TASS 等が必要。現環境の `data/prices.csv` はETF中心で代替検証向け。

2. 定義の実装細部
- `ret12` の月次インデックス定義（skip-month境界）をコードで固定し、単体テストで確認する必要。
- Table V の一部代替定義（残差化・産業調整）の完全同一仕様は本文だけでは不足し、付録/元データコード確認が望ましい。

3. 通貨・国際要因の構成
- 通貨2因子（市場・carry）と国際ファクターの正確な系列定義を追加確認する必要。

4. 検証優先度
- Phase Bではまず Table III/IV（主命題）を優先し、次に Table V・VI、最後に国際/通貨へ拡張するのが効率的。
